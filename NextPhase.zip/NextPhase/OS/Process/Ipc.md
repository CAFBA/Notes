# IPC
每个进程的用户地址空间都是独立的，一般而言是不能互相访问的，但内核空间是每个进程都共享的，所以进程之间要通信必须通过内核。`Linux` 提供 `ipcs` 命令，以观察当前系统上拥有哪些共享资源实例。此外，可以使用 `ipcrm` 命令来删除遗留在系统中的共享资源。
## pipe
### 匿名管道
```shell
$ ps auxf | grep mysql
```
管道的功能是将前一个命令的输出，作为后一个命令的输入，管道传输数据是单向的，如果想相互通信，需要创建两个管道，而且上面这种管道是没有名字，所以 `|` 表示的管道称为匿名管道，用完就销毁。
匿名管道的创建，需要通过下面这个系统调用：
```c
#include＜unistd.h＞
int pipe(int fd[2]);
```
`pipe` 该函数成功时返回 0，并将一对打开的文件描述符值填入其参数指向的数组，一个是管道的读取端描述符 `fd[0]`，另一个是管道的写入端描述符 `fd[1]`，往 `fd[1]` 写入的数据可以从 `fd[0]` 读出。`fd[0]` 只能用于从管道读出数据，`fd[1]` 则只能用于往管道写入数据，而不能反过来使用。如果要实现双向的数据传输，就应该使用两个管道。
这个匿名管道是特殊的文件，只存在于内存，不存于文件系统中。其实，所谓的管道，就是内核里面的一串缓存。从管道的一段写入的数据，实际上是缓存在内核中的，另一端读取，也就是从内核中读取这段数据。
如果管道的写端文件描述符 `fd[1]` 的引用计数减少至 0，即没有任何进程需要往管道中写入数据，则针对该管道的读端文件描述符 `fd[0]` 的 `read` 操作将返回 0，反之，如果管道的读端文件描述符 `fd[0]` 的引用计数减少至 0，即没有任何进程需要从管道读取数据，则针对该管道的写端文件描述符 `fd[1]` 的 `write` 操作将失败，并引发 `SIGPIPE` 信号。只是没人写就不用读，没人读也就不用写，不代表管道是否有空闲空间。
默认情况下，这一对文件描述符都是阻塞的。此时如果用 `read/write` 系统调用来读取/写入一个空/满管道，则 `read/write` 将被阻塞，直到管道内有数据可读/管道有足够多的空闲空间可用。但应用程序可以将 `fd[0]` 和 `fd[1]` 都设置为非阻塞的。
管道内部传输的数据是字节流，这和 `TCP` 字节流的概念相同。但二者又有细微的区别。应用层程序能往一个 `TCP` 连接中写入多少字节的数据，取决于对方的接收通告窗口的大小和本端的拥塞窗口的大小。而管道本身拥有一个容量限制，它管道最多能被写入多少字节的数据。自 `Linux 2.6.11` 内核起，管道容量的大小默认是 65536 字节。可以使用 `fcntl` 函数来修改管道容量。
此外，`socket API` 中有一个 `socketpair` 函数可以方便地创建双向管道。其定义如下：
```c
#include＜sys/types.h＞
#include＜sys/socket.h＞
int socketpair(int domain, int type, int protocol, int fd[2]);
```
`socketpair` 前三个参数的含义与 `socket` 系统调用的三个参数完全相同，但 `domain` 只能使用 `UNIX` 本地域协议族 `AF_UNIX`，因为仅能在本地使用这个双向管道。最后一个参数则和 `pipe` 系统调用的参数一样，只不过 `socketpair` 创建的这对文件描述符都是既可读又可写的。 
### 通信
这两个描述符都是在一个进程里面，并没有起到进程间通信的作用，因此需要使用 `fork` 创建子进程，创建的子进程会复制父进程的文件描述符，这样就做到两个进程各有两个 `fd[0]` 与 `fd[1]`，两个进程就可以通过各自的 `fd` 写入和读取同一个管道文件实现跨进程通信。
管道能在父、子进程间传递数据，利用的是 `fork` 调用之后两个管道文件描述符都保持打开。一对这样的文件描述符只能保证父、子进程间一个方向的数据传输，父进程和子进程必须有一个关闭 `fd[0]`，另一个关闭 `fd[1]`。比如，要使用管道实现从父进程向子进程写数据，就应该：
- 父进程关闭读取的 `fd[0]`，只保留写入的 `fd[1]`。
- 子进程关闭写入的 `fd[1`]，只保留读取的 `fd[0]`。
![image-20230326134000082](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326134000082.png)
所以说如果需要双向通信，则应该创建两个管道，使用 `socketpair` 创建全双工管道。
但是在 `shell` 里面执行 `A | B` 命令的时候，`A` 进程和 `B` 进程都是 `shell` 创建出来的子进程，`A` 和 `B` 之间不存在父子关系，它俩的父进程都是 `shell`。
所以在 `shell` 里通过 `|` 匿名管道将多个命令连接在一起，实际上也就是创建多个子进程，那么在编写 `shell` 脚本时，能使用一个管道搞定的事情，就不要多用一个管道，这样可以减少创建子进程的系统开销。
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E8%BF%9B%E7%A8%8B%E9%97%B4%E9%80%9A%E4%BF%A1/8-%E7%AE%A1%E9%81%93-pipe-shell.jpg)
### 命名管道
管道的另一个类型是命名管道，也被叫做 `FIFO`，因为数据是先进先出的传输方式，它能用于无关联进程之间的通信。在使用命名管道前，先需要通过 `mkfifo` 命令来创建，并且指定管道名字：
```bash
$ mkfifo myPipe
$ ls -l
# 管道也是以文件的方式存在 p，也就是 pipe 的意思
prw-r--r--. 1 root    root         0 Jul 17 02:45 myPipe
```
接下来，往 `myPipe` 这个管道写入数据：
```bash
$ echo "hello" > myPipe  // 将数据写进管道
                         // 停住了 ...
```
会发现命令执行后就停在这，这是因为管道里的内容没有被读取，只有当管道里的数据被读完后，命令才可以正常退出。执行另外一个命令来读取这个管道里的数据：
```bash
$ cat < myPipe  // 读取管道里的数据
hello
```
可以看到，管道里的内容被读取出来了，并打印在终端上，另外一方面，`echo` 那个命令也正常退出。
**管道这种通信方式效率低，不适合进程间频繁地交换数据**。它的好处，就是简单，同时也很容易得知管道里的数据已经被另一个进程读取。
- 对于匿名管道，它的通信范围是存在父子关系的进程。因为管道没有实体，也就是没有管道文件，只能通过 `fork` 来复制父进程 `fd` 文件描述符，来达到通信的目的。
- 对于命名管道，它可以在不相关的进程间也能相互通信。因为命令管道，提前创建一个类型为管道的设备文件，在进程里只要使用这个设备文件，就可以相互通信。
不管是匿名管道还是命名管道，进程写入的数据都是缓存在内核中，另一个进程读取数据时候也是从内核中获取，同时通信数据都遵循先进先出原则，不支持 `lseek` 之类的文件定位操作。
## 消息队列
管道的通信方式效率低，因此不适合进程间频繁地交换数据，消息队列解决这一问题。
消息队列是保存在内核中的消息链表，在发送数据时，会分成一个一个独立的数据单元，也就是消息体，消息体是用户自定义的数据类型，消息的发送方和接收方要约定好消息体的数据类型。所以每个消息体都是固定大小的存储块，不像管道是无格式的字节流数据，而且发送方将数据放在对应的消息队列后就可以正常返回，接收方可以根据类型来有选择地接收数据，而不一定像管道那样必须以先进先出的方式接收数据。
消息队列生命周期随内核，如果没有释放消息队列或者没有关闭操作系统，消息队列会一直存在，而匿名管道的生命周期，是随进程的创建而建立，随进程的结束而销毁。
消息队列不适合比较大数据的传输，因为在内核中每个消息体都有一个最大长度的限制，同时所有队列所包含的全部消息体的总长度也是有上限。在 `Linux` 内核中，会有两个宏定义 `MSGMAX` 和 `MSGMNB`，它们以字节为单位，分别定义了一条消息的最大长度和一个队列的最大长度。
消息队列通信过程中，存在用户态与内核态之间的数据拷贝开销，因为进程写入数据到内核中的消息队列时，会发生从用户态拷贝数据到内核态的过程，同理另一进程读取内核中的消息数据时，会发生从内核态拷贝数据到用户态的过程。
### msgget
`msgget` 系统调用创建一个消息队列，或者获取一个已有的消息队列：
```c
#include<sys/msg.h>
int msgget(key_t key, int msgflg);
```
`key` 参数是一个键值，用来标识一个全局唯一的消息队列。`msgflg` 参数的使用和含义与 `semget` 系统调用的 `sem_flags` 参数相同。成功时返回一个正整数值，它是消息队列的标识符。
如果 `msgget` 用于创建消息队列，则与之关联的内核数据结构 `msqid_ds` 将被创建并初始化：
```c
struct msqid_ds
{
    struct ipc_perm msg_perm;/*消息队列的操作权限*/
    time_t msg_stime;/*最后一次调用msgsnd的时间*/
    time_t msg_rtime;/*最后一次调用msgrcv的时间*/
    time_t msg_ctime;/*最后一次被修改的时间*/
    unsigned long__msg_cbytes;/*消息队列中已有的字节数*/
    msgqnum_t msg_qnum;/*消息队列中已有的消息数*/
    msglen_t msg_qbytes;/*消息队列允许的最大字节数*/
    pid_t msg_lspid;/*最后执行msgsnd的进程的PID*/
    pid_t msg_lrpid;/*最后执行msgrcv的进程的PID*/
};
```
### msgsnd
`msgsnd` 系统调用把一条消息添加到消息队列中：
```c
#include<sys/msg.h>
int msgsnd(int msqid, const void* msg_ptr, size_t msg_sz, int msgflg);
```
`msqid` 参数是由 `msgget` 调用返回的消息队列标识符。`msg_ptr` 参数指向一个准备发送的消息，消息必须被定义为如下类型：
```c
struct msgbuf
{
    long mtype;/*消息类型*/
    char mtext[512];/*消息数据*/
};
```
`msg_sz` 参数是消息的数据部分 `mtext` 的长度。这个长度可以为 0，表示没有消息数据。
`msgflg` 参数控制 `msgsnd` 的行为。它通常仅支持 `IPC_NOWAIT` 标志，即以非阻塞的方式发送消息。默认情况下，发送消息时如果消息队列满，则 `msgsnd` 将阻塞。若 `IPC_NOWAIT` 标志被指定，则 `msgsnd` 将立即返回并设置 `errno=EAGAIN`。
处于阻塞状态的 `msgsnd` 调用可能被如下两种异常情况所中断： 
- 消息队列被移除。此时 `msgsnd` 调用将立即返回并设置 `errno=EIDRM`。 
- 程序接收到信号。此时 `msgsnd` 调用将立即返回并设置 `errno=EINTR`。 
`msgsnd` 成功时返回 0，并修改内核数据结构 `msqid_ds` 的部分字段，如下所示： 
- 将 `msg_qnum` 加 1。
- 将 `msg_lspid` 设置为调用进程的 `PID`。 
- 将 `msg_stime` 设置为当前的时间。
### msgrcv
`msgrcv` 系统调用从消息队列中获取消息：
```c
#include<sys/msg·h>
int msgrcv(int msqid, void* msg_ptr, size_t msg_sz, long int msgtype, int msgflg);
```
`msqid` 参数是由 `msgget` 调用返回的消息队列标识符，`msg_ptr` 参数用于存储接收的消息，`msg_sz` 参数指的是消息数据部分的长度。 
`msgtype` 参数指定接收何种类型的消息：
- `msgtype = 0`，读取消息队列中的第一个消息。 
- `msgtype > 0`，除非指定标志 `MSG_EXCEPT`，否则读取消息队列中第一个类型为 `msgtype` 的消息。 
- `msgtype < 0`，读取消息队列中第一个类型值比 `msgtype` 的绝对值小的消息。
参数 `msgflg` 控制 `msgrcv` 函数的行为。它可以是如下一些标志的按位或： 
- `IPC_NOWAIT`，如果消息队列中没有消息，则 `msgrcv` 调用立即返回并设置 `errno=ENOMSG`。 
- `MSG_EXCEPT`，如果 `msgtype` 大于 0，则接收消息队列中第一个非 `msgtype` 类型的消息。 
- `MSG_NOERROR`。如果消息数据部分的长度超过 `msg_sz`，就将它截断。
处于阻塞状态的 `msgrcv` 调用还可能被如下两种异常情况所中断：
- 消息队列被移除。此时 `msgrcv` 调用将立即返回并设置 `errno=EIDRM`。 
- 程序接收到信号。此时 `msgrcv` 调用将立即返回并设置 `errno=EINTR`。 
`msgrcv` 成功时返回0，并修改内核数据结构 `msqid_ds` 的部分字段，如下所示：
- 将 `msg_qnum` 减 1。
- 将 `msg_lrpid` 设置为调用进程的 `PID`。 
- 将 `msg_rtime` 设置为当前的时间。
### msgctl
`msgctl` 系统调用控制消息队列的某些属性。其定义如下：
```c
#include<sys/msg.h>
int msgctl(int msqid, int command, struct msqid_ds* buf);
```
`msqid` 参数是由 `msgget` 调用返回的共享内存标识符。`command` 参数指定要执行的命令。`msgctl` 成功时的返回值取决于 `command` 参数。
![image-20230326145137579](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326145137579.png)
## 共享内存
消息队列的读取和写入的过程，都会有发生用户态与内核态之间的消息拷贝过程。共享内存很好的解决这一问题。
共享内存是最高效的 `IPC` 机制，即将一块虚拟地址空间映射到相同的物理内存中。这样这个进程写入的东西，另外一个进程马上就能看到，不需要拷贝，不涉及进程之间的任何数据传输，大大提高进程间通信的速度。
这种高效率带来的问题是，必须用其他辅助手段来同步进程对共享内存的访问，否则会产生竞态条件。因此，共享内存通常和其他进程间通信方式一起使用。 
### shmget
`shmget` 系统调用创建一段新的共享内存，或者获取一段已经存在的共享内存。其定义如下：
```c
#include<sys/shm.h>
int shmget(key_t key, size_t size, int shmflg);
```
`key` 参数是一个键值，用来标识一段全局唯一的共享内存。`size` 参数指定共享内存的大小，单位是字节。如果是创建新的共享内存，则 `size` 值必须被指定，如果是获取已经存在的共享内存，则可以把 `size` 设置为 0。
`shmflg` 参数的使用和含义与 `semget` 系统调用的 `sem_flags` 参数相同，而且支持两个额外的标志：
- `SHM_HUGETLB`，类似于 `mmap` 的 `MAP_HUGETLB` 标志，系统将使用大页面来为共享内存分配空间。 
- `SHM_NORESERVE`，类似于 mmap 的 `MAP_NORESERVE` 标志，不为共享内存保留交换分区。这样，当物理内存不足的时候，对该共享内存执行写操作将触发 `SIGSEGV` 信号。
`shmget` 成功时返回一个正整数值，它是共享内存的标识符。
如果 `shmget` 用于创建共享内存，则这段共享内存的所有字节都被初始化为 0，与之关联的内核数据结构 `shmid_ds` 将被创建并初始化：
```c
struct shmid_ds
{
    struct ipc_perm shm_perm;/*共享内存的操作权限*/
    size_t shm_segsz;/*共享内存大小，单位是字节*/
    __time_t shm_atime;/*对这段内存最后一次调用shmat的时间*/
    __time_t shm_dtime;/*对这段内存最后一次调用shmdt的时间*/
    __time_t shm_ctime;/*对这段内存最后一次调用shmctl的时间*/
    __pid_t shm_cpid;/*创建者的PID*/
    __pid_t shm_lpid;/*最后一次执行shmat或shmdt操作的进程的PID*/
    shmatt_t shm_nattach;/*目前关联到此共享内存的进程数量*/
    /*省略一些填充字段*/
};
```
`shmget` 对 `shmid_ds` 结构体的初始化包括： 
- 将 `shm_perm.cuid` 和 `shm_perm.uid` 设置为调用进程的有效用户 `ID`。 
- 将 `shm_perm.cgid` 和 `shm_perm.gid` 设置为调用进程的有效组 `ID`。 
- 将 `shm_perm.mode` 的最低 9 位设置为 `shmflg` 参数的最低 9 位。 
- 将 `shm_segsz` 设置为 `size`。 
- 将 `shm_lpid`、`shm_nattach`、`shm_atime`、`shm_dtime` 设置为 0。 
- 将shm_ctime设置为当前的时间。
### shmat/shmdt
共享内存被创建/获取之后，不能立即访问它，需要先将它关联到进程的地址空间中。使用完共享内存之后，也需要将它从进程地址空间中分离。这通过下述两个系统调用实现：
```c
#include<sys/shm.h>
void* shmat(int shm_id, const void* shm_addr, int shmflg);
int shmdt(const void* shm_addr);
```
`shmat` 将共享内存关联到进程 `shm_addr` 处：
`shm_id` 参数是由 `shmget` 调用返回的共享内存标识符。`shm_addr` 参数指定将共享内存关联到进程的 `shm_addr` 地址，最终的效果还受到 `shmflg` 参数的可选标志 `SHM_RND` 的影响：
- 如果 `shm_addr=NULL`，则被关联的地址由操作系统选择。这是推荐的做法，以确保代码的可移植性。 
- 如果 `shm_addr` 非空，并且 `SHM_RND` 标志未设置，则共享内存被关联到 `addr` 指定的地址处。 
- 如果 `shm_addr` 非空，并且设置 `SHM_RND` 标志，则被关联的地址是 `[shm_addr-(shm_addr%SHMLBA)]`。
`SHMLBA` 的含义是段低端边界地址倍数 `Segment Low Boundary Address Multiple`，它必须是内存页面大小 `PAGE_SIZE` 的整数倍。SHM_RND 的含义是圆整，即将共享内存被关联的地址向下圆整到离 `shm_addr` 最近的 `SHMLBA` 的整数倍地址处。
除 `SHM_RND` 标志外，`shmflg` 参数还支持如下标志： 
- `SHM_RDONLY`，进程仅能读取共享内存中的内容。若没有指定该标志，则进程可同时对共享内存进行读写操作（这需要在创建共享内存的时候指定其读写权限）。 
- `SHM_REMAP`，如果地址 `shmaddr` 已经被关联到一段共享内存上，则重新关联。
- `SHM_EXEC`，它指定对共享内存段的执行权限。对共享内存而言，执行权限实际上和读权限是一样的。 
`shmat` 成功时返回共享内存被关联到的地址，并修改内核数据结构 `shmid_ds` 的部分字段，如下： 
- 将 `shm_nattach` 加 1。 
- 将 `shm_lpid` 设置为调用进程的 `PID`。 
- 将 `shm_atime` 设置为当前的时间。
`shmdt` 将关联到 `shm_addr` 处的共享内存从进程中分离，成功时返回 0，并修改 `shmid_ds`：
- 将 `shm_nattach` 减 1。 
- 将 `shm_lpid` 设置为调用进程的 `PID`。 
- 将 `shm_dtime` 设置为当前的时间。
### shmctl
`shmctl` 系统调用控制共享内存的某些属性：
```c
#include<sys/shm.h>
int shmctl(int shm_id, int command, struct shmid_ds* buf);
```
`shm_id` 参数是由 `shmget` 调用返回的共享内存标识符。`command` 参数指定要执行的命令，`shmctl` 成功时的返回值取决于 `command` 参数。
![image-20230326144829907](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326144829907.png)
### shm_open
`mmap` 函数利用 `MAP_ANONYMOUS` 标志可以实现父、子进程之间的匿名内存共享。但通过打开同一个文件，`mmap` 也可以实现无关进程之间的内存共享。`Linux` 提供另外一种利用 `mmap` 在无关进程之间共享内存的方式。这种方式无须任何文件的支持，但它需要先使用如下函数来创建或打开一个 `POSIX` 共享内存对象：
```c
#include<sys/mman.h>
#include<sys/stat.h>
#include<fcntl.h>
int shm_open(const char* name, int oflag, mode_t mode);
```
`shm_open` 的使用方法与 `open` 系统调用完全相同。
name 参数指定要创建/打开的共享内存对象。从可移植性的角度考虑，该参数应该使用 `/somename` 的格式。
oflag 参数指定创建方式。它可以是下列标志中的一个或者多个的按位或： 
- `O_RDONLY`，以只读方式打开共享内存对象。 
- `O_RDWR`，以可读、可写方式打开共享内存对象。 
- `O_CREAT`，如果共享内存对象不存在，则创建之。此时 `mode` 参数的最低 9 位将指定该共享内存对象的访问权限。共享内存对象被创建的时候，其初始长度为 0。 
- `O_EXCL`，和 `O_CREAT` 一起使用，如果由 `name` 指定的共享内存对象已经存在，则 `shm_open` 调用返回错误，否则就创建一个新的共享内存对象。 
- `O_TRUNC`，如果共享内存对象已经存在，则把它截断，使其长度为 0。
`shm_open` 调用成功时返回一个文件描述符，该文件描述符可用于后续的 `mmap` 调用，从而将共享内存关联到调用进程。
### shm_unlink
和打开的文件最后需要关闭一样，由 `shm_open` 创建的共享内存对象使用完之后也需要被删除。这个过程是通过如下函数实现的：
```c
#include<sys/mman.h>
#include<sys/stat.h>
#include<fcntl.h>
int shm_unlink(const char* name);
```
该函数将 `name` 参数指定的共享内存对象标记为等待删除。当所有使用该共享内存对象的进程都使用 `shmdt()` 将它从进程中分离之后，系统将销毁这个共享内存对象所占据的资源。如果代码中使用上述 `POSIX` 共享内存函数，则编译的时候需要指定链接选项 `-lrt`。
> 实例见书13.6.5 
## 信号量
用共享内存通信方式，带来新的问题，那就是如果多个进程同时修改同一个共享内存，很有可能就冲突。例如两个进程都同时写一个地址，那先写的那个进程会发现内容被别人覆盖。为防止多进程竞争共享资源，而造成的数据错乱，所以需要保护机制，以确保任一时刻只有一个进程可以拥有对资源的独占式访问，信号量用于实现这一保护机制。
## 信号
上面说的进程间通信，都是常规状态下的工作模式。对于异常情况下的工作模式，就需要用信号的方式来通知进程。
信号是由用户、系统或者进程发送给目标进程的信息，以通知目标进程某个状态的改变或系统异常，是进程间通信机制中唯一的异步通信机制。
1. 执行默认操作。Linux 对每种信号都规定了默认操作，例如，上面列表中的 SIGTERM 信号，就是终止进程的意思。
2. 捕捉信号。可以为信号定义一个信号处理函数。当信号发生时，就执行相应的信号处理函数。
3. 忽略信号。当不希望处理某些信号的时候，就可以忽略该信号，不做任何处理。有两个信号是应用进程无法捕捉和忽略的，即 `SIGKILL` 和 `SEGSTOP`，它们用于在任何时候中断或结束某一进程。
### kill
`Linux` 下，一个进程给其他进程发送信号的 `API` 是 `kill` 函数：
```c
#include<sys/types.h>
#include<signal.h>
int kill(pid_t pid,int sig);
```
该函数把信号 `sig` 发送给目标进程 `pid`：
![image-20230326002423903](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326002423903.png)
`Linux` 定义的信号值都大于 0，如果 sig 取值为 0，则 `kill` 函数不发送任何信号。但将 `sig` 设置为 0 可以用来检测目标进程或进程组是否存在，因为检查工作总是在信号发送之前就执行。不过这种检测方式是不可的。一方面由于进程 `PID` 的回绕，可能导致被检测的 `PID` 不是期望的进程的 `PID`，另一方面，这种检测方法不是原子操作。
可以通过 `kill -l` 命令，查看所有的信号。
运行在 `shell` 终端的进程，可以通过键盘输入某些组合键的时候，给进程发送信号。如果进程在后台运行，可以通过 `kill` 命令的方式给进程发送信号，但前提需要知道运行中的进程 `PID` 号，例如 `kill -9 1050` ，表示给 `PID` 为 `1050` 的进程发送 `SIGKILL` 信号，用来立即结束该进程。所以，信号事件的来源主要有硬件来源和软件来源。
发 `kill` 信号必须具有一定的权限，实际上 `kill` 执行的是系统调用，将控制权转移给内核，由内核来给指定的进程发送信号，然后操作系统根据情况执行相应的信号处理程序，如果进程没有注册自己的信号处理函数，那么操作系统会执行默认的信号处理程序，最后会让进程退出，但如果注册，则会执行自己的信号处理函数，这样的话就给进程一个垂死挣扎的机会，它收到 `kill` 信号后，可以调用 `exit()` 来退出，但也可以使用 `sigsetjmp`，`siglongjmp` 这两个函数来恢复进程的执行。
```c
// 自定义信号处理函数示例

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

// 自定义信号处理函数，处理自定义逻辑后再调用 exit 退出
void sigHandler(int sig) {
  printf("Signal %d catched!\n", sig);
  exit(sig);
}

int main(void) {
  signal(SIGSEGV, sigHandler);
  int *p = (int *)0xC0000fff;
  *p = 10; // 针对不属于进程的内核空间写入数据，崩溃
}

// 以上结果输出: Signal 11 catched!

// 另外当进程接收信号之后也可以不定义自己的信号处理函数，而是选择忽略信号，如下
int main(void) {
  // 忽略信号
  signal(SIGSEGV, SIG_IGN);

  // 产生一个 SIGSEGV 信号
  raise(SIGSEGV);

  printf("正常结束");
}
```
虽然给进程发送了 `kill` 信号，但如果进程自己定义信号处理函数或者无视信号就有机会逃出生天，当然 `kill -9` 命令例外，不管进程是否定义信号处理函数，都会马上被干掉。
该函数成功时返回 0，失败则返回 `-1` 并设置 `errno`：
![image-20230326002429611](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326002429611.png)
### sighandler
目标进程在收到信号时，需要定义一个接收函数来处理之。信号处理函数的原型如下：
```c
#include<signal.h>
typedef void(*__sighandler_t)(int);
```
信号处理函数只带有一个整型参数，该参数用来指示信号类型。信号处理函数应该是可重入的，否则很容易引发一些竞态条件。所以在信号处理函数中严禁调用一些不安全的函数。
除用户自定义信号处理函数外，`bits/signum.h` 头文件中还定义信号的两种其他处理方式：
```c
#include<bits/signum.h>
#define SIG_DFL((__sighandler_t)0)
#define SIG_IGN((__sighandler_t)1)
```
`SIG_IGN` 表示忽略目标信号，`SIG_DFL` 表示使用信号的默认处理方式。信号的默认处理方式有：结束进程 `Term`、忽略信号 `Ign` 、结束进程并生成核心转储文件 `Core`、暂停进程 `Stop`，以及继续进程 `Cont`。
### signal
要为一个信号设置处理函数，可以使用 `signal` 系统调用：
```c
#include<signal.h>
_sighandler_t signal(int sig,_sighandler_t_handler)
```
`sig` 参数指出要捕获的信号类型。`_handler` 参数是 `__sighandler_t` 类型的函数指针，用于指定信号 `sig` 的处理函数。 
`signal` 函数成功时返回一个函数指针，该函数指针的类型也是  `__sighandler_t` ，是前一次调用 `signal` 函数时传入的函数指针，但如果是第一次调用 `signal`，则是信号 `sig` 对应的默认处理函数指针 `SIG_DEF`。`signal` 系统调用出错时返回 `SIG_ERR`，并设置 `errno`。
### sigaction
设置信号处理函数的更好接口是如下的系统调用：
```c
#include<signal.h>
int sigaction(int sig, const struct sigaction* act, struct sigaction* oact);
```
`sig` 参数指出要捕获的信号类型，`act` 参数指定新的信号处理方式，`oact` 参数则输出信号先前的处理方式，成功时返回 0， 失败则返回 -1 并设置 `errno`。
`act` 和 `oact` 都是 `sigaction` 结构体类型的指针，`sigaction` 结构体描述信号处理的细节：
```c
struct sigaction
{
    #ifdef__USE_POSIX199309
    union
    {
        _sighandler_t sa_handler;
        void(*sa_sigaction)(int,siginfo_t*,void*);
    }
    _sigaction_handler;
    #define sa_handler__sigaction_handler.sa_handler
    #define sa_sigaction__sigaction_handler.sa_sigaction
    #else
    _sighandler_t sa_handler;
    #endif
    _sigset_t sa_mask;
    int sa_flags;
    void(*sa_restorer)(void);
};
```
该结构体中的 `sa_hander` 成员指定信号处理函数。`sa_mask` 成员添加进程的信号掩码，以指定哪些信号不能发送给本进程。`sa_mask` 是信号集 `sigset_t` 类型，该类型指定一组信号。`sa_flags` 成员用于设置程序收到信号时的行为。
![image-20230326132748971](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326132748971.png)
### sigset_t
`Linux` 使用数据结构 `sigset_t` 来表示一组信号：
```c
#include<bits/sigset.h>
#define_SIGSET_NWORDS(1024/(8*sizeof(unsigned long int)))
typedef struct
{
    unsigned long int__val[_SIGSET_NWORDS];
}__sigset_t;
```
由该定义可见，`sigset_t` 实际上是一个长整型数组，数组的每个元素的每个位表示一个信号。这种定义方式和文件描述符集 `fd_set` 类似。 Linux 提供如下一组函数来设置、修改、删除和查询信号集：
```c
#include<signal.h>
int sigemptyset(sigset_t*_set)/*清空信号集*/
int sigfillset(sigset_t*_set)/*在信号集中设置所有信号*/
int sigaddset(sigset_t*_set,int_signo)/*将信号_signo添加至信号集中*/
int sigdelset(sigset_t*_set,int_signo)/*将信号_signo从信号集中删除*/
int sigismember(_const sigset_t*_set,int_signo)/*测试_signo是否在信号集中*/
```
### sigprocmask
可以利用 `sigaction` 结构体的 `sa_mask` 成员来设置进程的信号掩码。此外，如下函数也可以用于设置或查看进程的信号掩码：
```c
#include<signal.h>
int sigprocmask(int _how, _const sigset_t* _set, sigset_t* _oset);
```
`_set` 参数指定新的信号掩码，`_oset` 参数则输出原来的信号掩码。如果 `_set` 参数不为 `NULL`，则 `_how` 参数指定设置进程信号掩码的方式。
![image-20230326132842994](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326132842994.png)
如果 `_set` 为NULL，则进程信号掩码不变，此时仍然可以利用 `_oset` 参数来获得进程当前的信号掩码，成功时返回 0。
### sigpending
设置进程信号掩码后，被屏蔽的信号将不能被进程接收。如果给进程发送一个被屏蔽的信号，则操作系统将该信号设置为进程的一个被挂起的信号。如果取消对被挂起信号的屏蔽，则它能立即被进程接收到。如下函数可以获得进程当前被挂起的信号集：
```c
#include<signal.h>
int sigpending(sigset_t*set);
```
`set` 参数用于保存被挂起的信号集，进程即使多次接收到同一个被挂起的信号，`sigpending` 函数也只能反映一次，并且，当再次使用 `sigprocmask` 使能该挂起的信号时，该信号的处理函数也只被触发一次，成功时返回 0。
要始终清楚地知道进程在每个运行时刻的信号掩码，以及如何适当地处理捕获到的信号。在多进程、多线程环境中，要以进程、线程为单位来处理信号和信号掩码，不能设想新创建的进程、线程具有和父进程、主线程完全相同的信号特征。比如，`fork` 调用产生的子进程将继承父进程的信号掩码，但具有一个空的挂起信号集。
## Socket
管道、消息队列、共享内存、信号量和信号都是在同一台主机上进行进程间通信，那要想跨网络与不同主机上的进程之间通信，就需要 `Socket` 通信。实际上，`Socket` 通信不仅可以跨网络与不同主机的进程间通信，还可以在同主机上进程间通信。
```c
int socket(int domain, int type, int protocal)
```
三个参数分别代表：
- `domain` 参数用来指定协议族，比如 `AF_INET` 用于 `IPV4`、`AF_INET6` 用于 `IPV6`、`AF_LOCAL/AF_UNIX` 用于本机。
- `type` 参数用来指定通信特性，比如 `SOCK_STREAM` 表示的是字节流，对应 `TCP`、`SOCK_DGRAM`  表示的是数据报，对应 `UDP`、`SOCK_RAW` 表示的是原始套接字。
- `protocal` 参数原本是用来指定通信协议的，但现在基本废弃。因为协议已经通过前面两个参数指定完成，`protocol` 目前一般写成 0 即可；
根据创建 `socket` 类型的不同，通信的方式也就不同：
- 实现 `TCP` 字节流通信：`socket` 类型是 `AF_INET` 和 `SOCK_STREAM`；
- 实现 `UDP` 数据报通信：`socket` 类型是 `AF_INET` 和 `SOCK_DGRAM`；
- 实现本地进程间通信：本地字节流 `socket` 类型是 `AF_LOCAL` 和 `SOCK_STREAM`，本地数据报 `socket` 类型是 `AF_LOCAL` 和 `SOCK_DGRAM`。另外，`AF_UNIX` 和 `AF_LOCAL` 是等价的，所以 `AF_UNIX` 也属于本地 `socket`。
### TCP
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E8%BF%9B%E7%A8%8B%E9%97%B4%E9%80%9A%E4%BF%A1/12-TCP%E7%BC%96%E7%A8%8B%E6%A8%A1%E5%9E%8B.jpg)
- 服务端和客户端初始化 `socket`，得到文件描述符；
- 服务端调用 `bind`，将绑定在 IP 地址和端口;
- 服务端调用 `listen`，进行监听；
- 服务端调用 `accept`，等待客户端连接；
- 客户端调用 `connect`，向服务器端的地址和端口发起连接请求；
- 服务端 `accept` 返回用于传输的 `socket` 的文件描述符；
- 客户端调用 `write` 写入数据；服务端调用 `read` 读取数据；
- 客户端断开连接时，会调用 `close`，那么服务端 `read` 读取数据的时候，就会读取到了 `EOF`，待处理完数据后，服务端调用 `close`，表示连接关闭。
这里需要注意的是，服务端调用 `accept` 时，连接成功会返回一个已完成连接的 `socket`，后续用来传输数据。所以，监听的 `socket` 和真正用来传送数据的 `socket`，是两个 `socket`，一个叫作监听 `socket`，一个叫作已完成连接 `socket`。成功连接建立之后，双方开始通过 `read` 和 `write` 函数来读写数据，就像往一个文件流里面写东西一样。
### UDP
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E8%BF%9B%E7%A8%8B%E9%97%B4%E9%80%9A%E4%BF%A1/13-UDP%E7%BC%96%E7%A8%8B%E6%A8%A1%E5%9E%8B.jpg)
`UDP` 是没有连接的，所以不需要三次握手，也就不需要像 `TCP` 调用 `listen` 和 `connect`，但是 `UDP` 的交互仍然需要 `IP` 地址和端口号，因此也需要 `bind`。
对于 `UDP` 来说，不需要要维护连接，那么也就没有所谓的发送方和接收方，甚至都不存在客户端和服务端的概念，只要有一个 `socket` 多台机器就可以任意通信，因此每一个 `UDP` 的 `socket` 都需要 `bind`。
另外，每次通信时，调用 `sendto` 和 `recvfrom`，都要传入目标主机的 `IP` 地址和端口。
### 本地进程间通信
本地 `socket`  被用于在**同一台主机上进程间通信**的场景：
- 本地 `socket` 的编程接口和 `IPv4` 、`IPv6` 套接字编程接口是一致的，可以支持字节流和数据报两种协议。
- 本地 `socket` 的实现效率大大高于 `IPv4` 和 `IPv6` 的字节流、数据报 `socket` 实现。
对于本地字节流 `socket`，其 `socket` 类型是 `AF_LOCAL` 和 `SOCK_STREAM`。
对于本地数据报 `socket`，其 `socket` 类型是 `AF_LOCAL` 和 `SOCK_DGRAM`。
本地字节流 `socket` 和本地数据报 `socket` 在 `bind` 的时候，不像 `TCP` 和 `UDP` 要绑定 `IP` 地址和端口，而是绑定一个本地文件，这也就是它们之间的最大区别。