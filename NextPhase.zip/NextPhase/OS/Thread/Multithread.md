# Multithread
在单核 `CPU` 系统里，为实现多个程序同时运行的假象，操作系统通常以时间片调度的方式，让每个进程执行每次执行一个时间片，时间片用完，就切换下一个进程运行，由于这个时间片的时间很短，于是就造成并发的现象。另外，操作系统也为每个进程创建巨大、私有的虚拟内存的假象，这种地址空间的抽象让每个程序好像拥有自己的内存，而实际上操作系统在背后让多个地址空间复用物理内存或者磁盘。
线程之间可以共享进程的资源，比如代码段、堆空间、数据段、打开的文件等资源，但每个线程都有自己独立的栈空间。多个线程如果竞争共享资源，如果不采取有效的措施，则会造成共享数据的混乱。
## 并发并行
并发指单个 `CPU` 同时执行多个进程，指的是单位时间内的累积工作量，比如每秒并发数是 100，这是指一秒内累积的请求量总和为 100 个请求。传统意义上，这种并发执行只是模拟出来的，是通过正在执行的进程/线程间快速切换来实现的，因此称之为进程/线程级并发。
并行是指多个 `CPU` 同时执行各自的进程，指的是真正同时进行的工作量，比如并行100个请求量是指任意瞬间都有 100 个请求在发生，所以单核 `CPU` 谈并发，多核 `CPU` 谈并行。
一个进程的指令和另一个进程的指令交错执行称为并发运行。
处理器可以同时执行多条指令称为指令级并行。
## 互斥/同步
竞态条件出现在多个执行线程/进程大致同时进入临界区时，都试图更新共享的数据结构，每次运行都可能得到不同的结果，因此输出的结果存在不确定性。
多线程/进程对共享变量的操作代码可能会导致竞争状态，因此将此段代码称为临界区，这段代码应该是互斥的，只要一个进程/线程进入临界区，其他线程/进程应该被阻止进入临界区，直到第一个进程/线程离开临界区。
进程/线程在一些关键点上可能需要互相等待与互通消息，这种相互制约的等待与互通信息称为进程/线程同步。
因此互斥侧重于进程/线程不能在同一时刻进入临界区，而同步侧重于进程/线程需要等待对方的消息。为实现进程/线程间正确的协作，操作系统通过锁实现进程/线程互斥，通过信号量实现进程/线程互斥与同步。
如果一个函数能被多个线程同时调用且不发生竞态条件，则称它是线程安全的，或者说它是可重入函数。`Linux` 库函数只有一小部分是不可重入的，这些库函数之所以不可重入，主要是因为其内部使用静态变量。不过 `Linux` 对很多不可重入的库函数提供对应的可重入版本，这些可重入版本的函数名是在原函数名尾部加上 `_r`。
## 同步原语
### Test-and-Set
自旋锁一直自旋，利用 `CPU` 周期，直到锁可用。在单处理器上，需要抢占式的调度器不断通过时钟中断一个线程，运行其他线程。否则，自旋锁在单 `CPU` 上无法使用，因为一个自旋的线程永远不会放弃 `CPU`。
```c
// 测试和设置不是原子操作
void lock(lock_t *mutex) {
    while (mutex->flag == 1);  // 自旋锁
    // 若在此刻中断执行新线程，新线程将设置 mutex->flag = 1 从而持有锁
    // 此时该线程应该自旋等待锁可用，但却尝试持有锁
    mutex->flag = 1;         // 锁被持有
}

int TestAndSet(int *old_ptr, int new) { 
    int old = *old_ptr; 
    *old_ptr = new; // 设置新值
    return old;  // 返回旧值用于测试
}

typedef struct lock_t { int flag; } lock_t; 

void init(lock_t *lock) { 
    lock->flag = 0;
} 

void lock(lock_t *lock) {
    // 现在测试和设置合并为原子操作，不会发生上述例子的情况
    while (TestAndSet(&lock->flag, 1) == 1); // 自旋锁且锁被持有
} 

void unlock(lock_t *lock) {
    lock->flag = 0;
} 
```
### CompareAndSwap
```c
int CompareAndSwap(int *ptr, int expected, int new) {
    int actual = *ptr;
    if(actual == expected) *ptr = new; // 如果没有被其它线程改变，则更新值
    return actual; // 返回旧值
}

void lock(lock_t *lock) {
    // 若未持有锁 actual == expected == 0，则 new=1 持有锁，若已持有锁，则自旋等待
    while(CompareAndSwap(&lock->flag, 0, 1) == 1)  
} 
```
### 链接加载和条件式存储
```c
int LoadLinked(int *ptr) {
    return *ptr;
}

int StoreConditional(int *ptr, int value) { 
    if (no one has updated *ptr since the LoadLinked to this address) { 
        *ptr = value;            
        return 1; // success!
    } 
    else return 0; // failed to update  
} 

void lock(lock_t *lock) { 
    while (1) { 
        while (LoadLinked(&lock->flag) == 1); // 用于自旋锁
        // 若没有线程线程持有锁则尝试获取锁，条件存储成功（锁没有变化）时锁被持有，否则重新检查（即有变化的话就重新来过）
        // 可以设想一下在此处中断的情况（类似第一个例子），而条件存储就能保证这种情况下的互斥
        if (StoreConditional(&lock->flag, 1) == 1) return; // 用于获取锁
        // 等价写法
        // while (LoadLinked(&lock->flag)||!StoreConditional(&lock->flag, 1)) ;
    }   
} 

void unlock(lock_t *lock) {
    lock->flag = 0;
}                    
```
### FetchAndAdd
由于每次 `lock` 都会增加 `ticket` 值，因此每次 `lock` 进入等待队列的线程，其 `ticket` 是依次增加的，这样随着锁被释放，全局变量 `turn` 增加，等待队列的线程都能获取到锁。
```c
typedef struct lock_t { 
    int ticket;
    int turn;    // 全局共享变量
} lock_t;

// 原子地返回特定地址的旧值，并且让该值自增一
int FetchAndAdd(int *ptr) { 
    int old = *ptr;
    *ptr = old + 1;
    return old;
} 

void lock_init(lock_t *lock) {
    lock->ticket = 0;
    lock->turn  = 0;
}

void lock(lock_t *lock) {
    int myturn = FetchAndAdd(&lock->ticket);
    while (lock->turn != myturn); // 若旧值与全局共享变量一致，则获取锁，否则自旋锁
}

void unlock(lock_t *lock) { 
    FetchAndAdd(&lock->turn); // 释放锁则更新全局共享变量，从而下一个等待线程可以进入临界区。
} 
```
综上
- 核心思想：如果有线程持有锁则自旋，如果没有线程持有锁则锁被持有。
- 标志：0 表示锁未被持有，1 表示锁被持有
- 代码实现：置新返旧
获取并增加与其它三个的区别：其它三个无法保证公平性，因为它们的标志都是相同的，无法区分各个线程，一个线程有可能一直自旋，即使其他线程在获取和释放锁。
链接的加载和条件式存储指令与原子交换、比较并交换的区别：将自旋锁与获取锁的逻辑分开，通过条件存储保证原子操作。
### 休眠代替自旋
前述同步原语或者一直自旋，或者立刻让出 `CPU`，这都会造成浪费，因此必须显式地施加某种控制，决定锁释放时，谁能抢到锁。
为做到这一点，需要一个队列来保存等待锁的线程，提供调用 `park()` 让调用线程休眠，提供调用 `unpark(threadID)` 则唤醒 `threadID` 标识的线程。
```c
typedef struct lock_t {
    int flag;  
    int guard; // 只有当持有 guard 时才可以置位 flag 获取或释放锁
    queue_t *q; 
} lock_t;

void lock_init(lock_t *m) {
    m->flag  = 0;
    m->guard = 0; 
    queue_init(m->q); // 休眠队列
}

void lock(lock_t *m) { 
    while(TestAndSet(&m->guard, 1) == 1); // guard 非 1 才可以获取锁
    // 此时 m->guard == 1，若没有线程线程持有锁则当前线程尝试获取锁
    if (m->flag == 0) { // 锁没有被持有，可以获取锁
        m->flag = 1;    // 锁被持有
        m->guard = 0;
    } else { // 锁被持有，线程休眠等待
        queue_add(m->q, gettid()); // 获取当前线程 id，加入队列中
        m->guard = 0; 
        // 此处可能切换线程导致永远休眠
        park();         // 线程休眠
    
        // 因此需要将 m->guard = 0 滞后
        // queue_add(m->q, gettid());
        // setpark();
        // m->guard = 0; 
    } 
}

void unlock(lock_t *m) {
    while (TestAndSet(&m->guard, 1) == 1);  // guard 非 1 才可以释放锁
    if (queue_empty(m->q)) m->flag = 0;     // 若休眠队列为空，则锁没有被持有
    // 否则从队列中弹出线程，该线程现在持有锁，因此 m->flag 依然为 1
    else unpark(queue_remove(m->q));        // 唤醒线程并传递锁
    m->guard = 0;                           // 重置 guard
}
```
之前的实现中未持有锁只能自选等待，现在未持有锁会休眠等待，临界区改为 `guard` 负责。
若某线程在 `park` 调用之前，切换到那个持有锁的线程，则释放锁后，可能 `park` 还未被调用该锁就再次被持有，这种唤醒/等待竞争可能会导致该线程永远休眠，为避免这种情况，需要通过 `setpark` 表明自己马上要休眠，从而确保 `m->guard=1` 时已经休眠。如果刚好另一个线程被调度，并且调用 `unpark`，那么后续的 `park` 调用就会直接返回，而不是一直休眠。
## semaphore
信号量是操作系统提供的一种协调共享资源访问的方法，主要用于实现进程间的互斥与同步，通常信号量表示资源的数量，对应的变量是一个整型 `sem` 变量。
在 `Linux` 上，信号量 `API` 有两组。一组是 `System V IPC` 信号量，定义在 `sys/sem.h`，另外一组是 `POSIX` 信号量，定义在 `semaphore.h`。
在 `Linux/UNIX` 中，等待和信号都已经具有特殊的含义，所以对信号量的这两种操作更常用的称呼是 `P`、`V` 操作。这两个字母来自于荷兰语单词 `passeren` 传递进入临界区）和 `vrijgeven` 释放退出临界区。
- 信号初始化为 `1`，就代表着是互斥信号量，它可以保证共享内存在任何时刻只有一个进程在访问。
- 信号初始化为 `0`，就代表着是同步信号量，它可以保证进程 `A` 应在进程 `B` 之前执行。
### System V IPC
 `System V IPC` 信号量主要包含3个系统调用，它们都被设计为操作一组信号量，而不是单个信号量。
#### semget
`semget` 系统调用创建一个新的信号量集，或者获取一个已经存在的信号量集，成功时返回一个正整数值，它是信号量集的标识符。其定义如下：
```c
#include<sys/sem.h>
int semget(key_t key, int num_sems, int sem_flags);
```
`key` 参数是一个键值，用来标识一个全局唯一的信号量集，就像文件名全局唯一地标识一个文件一样。要通过信号量通信的进程需要使用相同的键值来创建/获取该信号量。
`num_sems` 参数指定要创建/获取的信号量集中信号量的数目。如果是创建信号量，则该值必须被指定，如果是获取已经存在的信号量，则可以把它设置为 0。
`sem_flags` 参数指定一组标志。它低端的 `9` 个比特是该信号量的权限，其格式和含义都与系统调用 `open` 的 `mode` 参数相同。此外，还可以和 `IPC_CREAT` 标志做按位或运算以创建新的信号量集。此时即使信号量已经存在，`semget` 也不会产生错误。
还可以联合使用 `IPC_CREAT` 和 `IPC_EXCL` 标志来确保创建一组新的、唯一的信号量集。在这种情况下，如果信号量集已经存在，则 `semget` 返回错误并设置 `errno` 为 `EEXIST`。
如果 `semget` 用于创建信号量集，则与之关联的内核数据结构体 `semid_ds` 将被创建并初始化：
```c
#include<sys/sem.h>
/*该结构体用于描述IPC对象（信号量、共享内存和消息队列）的权限*/
struct ipc_perm
{
    key_t key;/*键值*/
    uid_t uid;/*所有者的有效用户ID*/
    gid_t gid;/*所有者的有效组ID*/
    uid_t cuid;/*创建者的有效用户ID*/
    gid_t cgid;/*创建者的有效组ID*/
    mode_t mode;/*访问权限*/
    /*省略其他填充字段*/
}

struct semid_ds
{
    struct ipc_perm sem_perm;/*信号量的操作权限*/
    unsigned long int sem_nsems;/*该信号量集中的信号量数目*/
    time_t sem_otime;/*最后一次调用semop的时间*/
    time_t sem_ctime;/*最后一次调用semctl的时间*/
    /*省略其他填充字段*/
};
```
#### semop
`semop` 系统调用改变信号量的值，即执行 `P`、`V` 操作。每个信号量关联的一些重要的内核变量：
```c
unsigned short semval;/*信号量的值*/
unsigned short semzcnt;/*等待信号量值变为0的进程数量*/
unsigned short semncnt;/*等待信号量值增加的进程数量*/
pid_t sempid;/*最后一次执行semop操作的进程ID*/
```
`semop` 系统调用改变信号量的值，即对这些内核变量执行 `P`、`V` 操作：
```c
#include<sys/sem.h>
int semop(int sem_id, struct sembuf* sem_ops, size_t num_sem_ops);
```
`sem_id` 参数是由 `semget` 调用返回的信号量集标识符，用以指定被操作的目标信号量集。`sem_ops` 参数指向一个 `sembuf` 结构体类型的数组，`sembuf` 结构体的定义如下：
```c
struct sembuf{
    unsigned short int sem_num; // 信号量集中信号量的编号
    short int sem_op;
    short int sem_flg;
}
```
`sem_op` 成员指定操作类型，每种类型的操作的行为受到 `sem_flg` 成员的影响。`sem_flg` 的可选值是：
- `IPC_NOWAIT`：无论信号量操作是否成功，`semop` 调用都将立即返回，这类似于非阻塞 `I/O` 操作。
- `SEM_UNDO`：当进程退出时取消正在进行的 `semop` 操作。
如果 `sem_op > 0`，则 `semop` 将被操作的信号量的 `semval` 增加 `semop` 的值。此时若设置 `SEM_UNDO` 标志，则系统将更新进程的 `semadj` 变量用以跟踪进程对信号量的修改情况。
如果 `sem_op == 0`，则如果此时信号量的值是 0，调用立即成功返回，不是 0 则 `semop` 失败返回或者阻塞进程以等待信号量变为 0。在这种情况下，当 `IPC_NOWAIT` 标志被指定时，`semop` 立即返回一个错误，并设置 `errno` 为 `EAGAIN`。如果未指定 `IPC_NOWAIT` 标志，则信号量的 `semzcnt` 值加 1，进程被投入睡眠直到下列 3 个条件之一发生：
- 信号量的值 `semval` 变为 0，此时系统将该信号量的 `semzcnt` 值减 1。
- 被操作信号量所在的信号量集被进程移除，此时 `semop` 调用失败返回，`errno=EIDRM`。
- 调用被信号中断，此时 `semop` 调用失败返回，`errno=EINTR`，同时系统将该信号量的 `semzcnt` 值减 `1`。
如果 `sem_op < 0`，则将该信号量的 `semval` 值减去 `sem_op` 的绝对值，即 semop 操作成功，调用进程立即获得信号量。此时如果设置 `SEM_UNDO` 标志，则系统将更新进程的 `semadj` 变量。如果信号量的值 `semval` 小于 `sem_op` 的绝对值，则 `semop` 失败返回或者阻塞进程以等待信号量可用。
在这种情况下，当 `IPC_NOWAIT` 标志被指定时，`semop` 立即返回一个错误，并设置 `errno` 为 `EAGAIN`。如果未指定 `IPC_NOWAIT` 标志，则信号量的 `semncnt` 值加 1，进程被投入睡眠直到下列3个条件之一发生：
- 信号量的值 `semval` 变得大于或等于 `sem_op` 的绝对值，此时系统将该信号量的 `semncnt` 值减 1，并将 `semval` 减去 `sem_op` 的绝对值，同时，如果 `SEM_UNDO` 标志被设置，则系统更新 `semadj` 变量。
- 同上
第 3 个参数 `num_sem_ops` 指定要执行的操作个数，即 `sem_ops` 数组中元素的个数。`semop` 对数组 `sem_ops` 中的每个成员按照数组顺序依次执行操作，并且该过程是原子操作，以避免别的进程在同一时刻按照不同的顺序对该信号集中的信号量执行 `semop` 操作导致的竞态条件。
#### semctl
`semctl` 系统调用允许调用者对信号量进行直接控制。其定义如下：
```c
#include<sys/sem.h>
int semctl(int sem_id, int sem_num, int command,...);
```
`sem_id` 参数是由 `semget` 调用返回的信号量集标识符，用以指定被操作的信号量集。`sem_num` 参数指定被操作的信号量在信号量集中的编号。`command` 参数指定要执行的命令。有的命令需要调用者传递第 4 个参数。第 4 个参数的类型由用户自己定义，但推荐格式如下：
```c
union semun
{
    int val;/*用于SETVAL命令*/
    struct semid_ds*buf;/*用于IPC_STAT和IPC_SET命令*/
    unsigned short*array;/*用于GETALL和SETALL命令*/
    struct seminfo*__buf;/*用于IPC_INFO命令*/
};
struct seminfo
{
    int semmap;/*Linux内核没有使用*/
    int semmni;/*系统最多可以拥有的信号量集数目*/
    int semmns;/*系统最多可以拥有的信号量数目*/
    int semmnu;/*Linux内核没有使用*/
    int semmsl;/*一个信号量集最多允许包含的信号量数目*/
    int semopm;/*semop一次最多能执行的sem_op操作数目*/
    int semume;/*Linux内核没有使用*/
    int semusz;/*sem_undo结构体的大小*/
    int semvmx;/*最大允许的信号量值*/
    /*最多允许的UNDO次数（带SEM_UNDO标志的semop操作的次数）*/
    int semaem;
};
```
semctl支持的所有命令如表13-2所示。
![image-20230326144634676](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326144634676.png)
这些操作中，`GETNCNT`、`GETPID`、`GETVAL`、`GETZCNT` 和 `SETVAL` 操作的是单个信号量，它是由标识符 `sem_id` 指定的信号量集中的第 `sem_num` 个信号量，而其他操作针对的是整个信号量集，此时  `semctl` 的参数 `sem_num` 被忽略。
### POSIX
常用的 `POSIX` 信号量函数是下面 5 个：
```c
#include<semaphore.h>
int sem_init(sem_t* sem, int pshared, unsigned int value);
int sem_destroy(sem_t* sem);
int sem_wait(sem_t* sem);
int sem_trywait(sem_t* sem);
int sem_post(sem_t* sem);
```
这些函数的第一个参数 `sem` 指向被操作的信号量。
- `sem_init` 函数用于初始化一个未命名的信号量。`pshared` 参数指定信号量的类型。如果其值为0，就表示这个信号量是当前进程的局部信号量，否则该信号量就可以在多个进程之间共享。`value` 参数指定信号量的初始值。此外，初始化一个已经被初始化的信号量将导致不可预期的结果。
- `sem_destroy` 函数用于销毁信号量，以释放其占用的内核资源。如果销毁一个正被其他线程等待的信号量，则将导致不可预期的结果。
- `sem_trywait` 与 `sem_wait` 函数相似，不过它始终立即返回，而不论被操作的信号量是否具有非 0 值，相当于 `sem_wait` 的非阻塞版本。当信号量的值非 0 时，`sem_trywait` 对信号量执行减 1 操作。当信号量的值为 0 时，它将返回 -1 并设置 `errno` 为 `EAGAIN`。
- `P` 操作：`sem_wait` 函数通过 `semop()` 函数以原子操作的方式对信号量进行递减。如果当前的信号量的值大于零，则该递减操作将立即进行，并且函数会立刻返回。如果当前的信号量值为零，那么该调用操作将被阻塞，直到可以进行递减操作。
- `V` 操作：`sem_post` 函数通过 `semop()` 函数以原子操作的方式对信号量进行递增。如果由此导致的信号量的值大于零，则被阻塞在 `sem_wait` 调用中的另一个进程或线程将被唤醒，并继续进行递增信号量的操作。
上面这些函数成功时返回 0，失败则返回 `-1` 并设置 `errno`。在进程终止时，需要调用`semctl()`函数来释放信号量的资源。
在使用 `sem_wait()` 和 `sem_post()` 函数时，必须使用正确的信号量标识符，并且避免在多个进程之间共享同一个信号量的指针。此外，由于信号量机制不提供互斥保护，因此在使用信号量时，还需要采用其他的同步机制来保证线程安全。
下述实现二值信号锁，应用见[[03Tools#实现锁]]
```c++
typedef struct _Zem_t { 
    int value; 
    pthread_cond_t cond; // 提供休眠措施
    pthread_mutex_t lock; // 提供互斥
} Zem_t; // only one thread can call this 

void Zem_init(Zem_t *s, int value) { 
    s->value = value; 
    Cond_init(&s->cond); 
    Mutex_init(&s->lock); 
} 

void Zem_wait(Zem_t *s) {
    Mutex_lock(&s->lock); 
    while (s->value <= 0) // 先判断后递减（注意sem_t的实现中，当信号量为 0 时不休眠）
        Cond_wait(&s->cond, &s->lock); // 当被唤醒时会再次检查，直到信号量不小于 0
    s->value--; // 被休眠后不会执行该行，因此不会变为负值
    Mutex_unlock(&s->lock);
}

void Zem_post(Zem_t *s) {  
    Mutex_lock(&s->lock); 
    s->value++;
    Cond_signal(&s->cond); 
    Mutex_unlock(&s->lock); 
}  
```
### Dijkstra
使用一个普通变量来模拟二进制信号量是行不通的，因为所有高级语言都没有一个原子操作可以同时完成如下两步操作：检测变量是否为 `true/false`，如果是则再将它设置为 `false/true`。
`Dijkstra` 实现的信号量，当值为负数时，可以反映出等待的线程数，而 `POSIX` 信号量不会变为负值。
- `P` 操作：将 `sem` 减 `1`，相减后，如果 `sem < 0`，则挂起进程/线程，否则继续。
- `V` 操作：将 `sem` 加 `1`，相加后，如果 `sem <= 0`，唤醒一个等待中的进程/线程。
![PV 操作的算法描述](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/17-%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9FPV%E7%AE%97%E6%B3%95%E6%8F%8F%E8%BF%B0.jpg)
#### 二值信号锁
如果要使得两个进程互斥访问共享内存，可以初始化信号量为 `1`。为每类共享资源设置一个信号量 `s`，其初值为 `1`，表示该临界资源未被占用。只要把进入临界区的操作置于 `P(s)` 和 `V(s)` 之间，即可实现进程/线程互斥。
`P` 操作直接将信号量减 1，若信号量小于 0 则阻塞，`V` 操作直接将信号量加 1，若信号量为 0 则唤醒。第一个线程进入临界区执行 `P` 操作，信号量变为 0，表示有线程正在临界区。当第二个线程也想进入临界区，由于直接执行 `P` 操作，信号量变为 -1，被阻塞直到第一个线程执行 `V` 操作，使信号量变为 0，唤醒第二个线程，这里的 0 依然表示有线程正在临界区，之后执行结束执行 `V` 操作，信号量回到初始值 1。
因此，互斥信号量的值仅取 1、0 和 -1 三个值，分别表示：
- 如果互斥信号量为 1，表示没有线程进入临界区；
- 如果互斥信号量为 0，表示有一个线程正在临界区；
- 如果互斥信号量为 -1，表示一个线程正在临界区，而另一个线程等待。
#### 条件变量
同步的方式是设置一个信号量，其初值为 `0`，有以下两种情况：
1. 父线程/消费者创建子线程，但是子线程/生产者并没有运行。这种情况下，父线程调用 `sem_wait()` 会先于子线程调用 `sem_post()`。因此初值未 0，父线程 `sem_wait()`，将信号量减为 −1，然后睡眠等待。子线程运行的时候，调用 `sem_post()`，信号量增加为 0，唤醒父线程，父线程然后从 `sem_wait()` 返回，完成该程序。
2. 子线程在父线程调用 `sem_wait()` 之前就运行结束。在这种情况下，子线程会先调用 `sem_post()`，将信号量从 0 增加到 1。然后当父线程有机会运行时，会调用 `sem_wait()`，发现信号量的值为 1。于是父线程将信号量从 1 减为0，没有等待，直接从 `sem_wait()` 返回。
## Lock
使用加锁操作和解锁操作可以解决并发线程/进程的互斥问题。任何想进入临界区的线程，必须先执行加锁操作。若加锁操作顺利通过，则线程可进入临界区，在完成对临界资源的访问后再执行解锁操作，以释放该临界资源。
### POSIX
`POSIX` 互斥锁的相关函数主要有如下 5 个：
```C
#include<pthread.h>
int pthread_mutex_init(pthread_mutex_t* mutex, const pthread_mutexattr_t* mutexattr);
int pthread_mutex_destroy(pthread_mutex_t* mutex);
int pthread_mutex_lock(pthread_mutex_t* mutex);
int pthread_mutex_trylock(pthread_mutex_t* mutex);
int pthread_mutex_unlock(pthread_mutex_t* mutex);

// 读写锁
int pthread_rwlock_init(pthread_rwlock_t *restrict rwlock, const pthread_rwlockattr_t *restrict attr);
int pthread_rwlock_destroy(pthread_rwlock_t *rwlock);
int pthread_rwlock_rdlock(pthread_rwlock_t *rwlock);
int pthread_rwlock_wrlock(pthread_rwlock_t *rwlock);
int pthread_rwlock_unlock(pthread_rwlock_t *rwlock);

// 自旋锁
int pthread_spin_init(pthread_spinlock_t *lock, int pshared);
int pthread_spin_destroy(pthread_spinlock_t *lock);
int pthread_spin_lock(pthread_spinlock_t *lock);
int pthread_spin_unlock(pthread_spinlock_t *lock);
```
`pthread_mutex_init` 函数用于初始化互斥锁。`mutexattr` 参数指定互斥锁的属性。如果将它设置为 `NULL`，则表示使用默认属性。除这个函数外，还可以使用如下方式来初始化一个互斥锁：
```C
// 把互斥锁的各个字段都初始化为0
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
```
`pthread_mutex_destroy` 函数用于销毁互斥锁，以释放其占用的内核资源，销毁一个已经加锁的互斥锁将导致不可预期的后果。
`pthread_mutex_lock` 函数以原子操作的方式给一个互斥锁加锁。如果目标互斥锁已经被锁上，则 `pthread_mutex_lock` 调用将阻塞，直到该互斥锁的占有者将其解锁。
`pthread_mutex_trylock` 与 `pthread_mutex_lock` 函数类似，不过它始终立即返回，而不论被操作的互斥锁是否已经被加锁，相当于 `pthread_mutex_lock` 的非阻塞版本。当目标互斥锁未被加锁时，对互斥锁执行加锁操作。当互斥锁已经被加锁时，将返回错误码 `EBUSY`。
`pthread_mutex_unlock` 函数以原子操作的方式给一个互斥锁解锁，如果此时有其他线程正在等待这个互斥锁，则这些线程中的某一个将获得它。
`pthread_rwlock_rdlock`: 获取读锁。如果已经有其他线程持有写锁，那么调用线程将被阻塞，直到写锁被释放。如果没有其他线程持有写锁，那么调用线程将获取读锁。
`pthread_rwlock_wrlock` 获取写锁。如果已经有其他线程持有读锁或写锁，那么调用线程将被阻塞，直到所有读锁和写锁都被释放。如果没有其他线程持有读锁或写锁，那么调用线程将获取写锁。
`pthread_rwlock_unlock` 释放读锁或写锁。如果调用线程持有读锁，那么读锁将被释放。如果调用线程持有写锁，那么写锁将被释放。
### Attribute
`pthread_mutexattr_t` 结构体定义一套完整的互斥锁属性。线程库提供一系列函数来操作 `pthread_mutexattr_t` 类型的变量，以方便获取和设置互斥锁属性。
```C
#include<pthread.h>

/*初始化互斥锁属性对象*/
int pthread_mutexattr_init(pthread_mutexattr_t* attr);

/*销毁互斥锁属性对象*/
int pthread_mutexattr_destroy(pthread_mutexattr_t* attr);

/*获取和设置互斥锁的pshared属性*/
int pthread_mutexattr_getpshared(const pthread_mutexattr_t* attr, int* pshared);
int pthread_mutexattr_setpshared(pthread_mutexattr_t* attr,int pshared);

/*获取和设置互斥锁的type属性*/
int pthread_mutexattr_gettype(const pthread_mutexattr_t* attr, int* type);
int pthread_mutexattr_settype(pthread_mutexattr_t* attr,int type);
```
属性 `pshared` 指定是否允许跨进程共享互斥锁，其可选值有两个：
- `PTHREAD_PROCESS_SHARED`，互斥锁可以被跨进程共享。 
- `PTHREAD_PROCESS_PRIVATE`，互斥锁只能被和锁的初始化线程隶属于同一个进程的线程共享。 
属性 `type` 指定互斥锁的类型。`Linux` 支持如下 4 种类型的互斥锁： 
- `PTHREAD_MUTEX_NORMAL`，普通锁。这是互斥锁默认的类型。当一个线程对一个普通锁加锁以后，其余请求该锁的线程将形成一个等待队列，并在该锁解锁后按优先级获得它。这种锁类型保证资源分配的公平性，一个线程如果对一个已经加锁的普通锁再次加锁，将引发死锁，对一个已经被其他线程加锁的普通锁解锁，或者对一个已经解锁的普通锁再次解锁，将导致不可预期的后果。 
- `PTHREAD_MUTEX_ERRORCHECK`，检错锁。一个线程如果对一个已经加锁的检错锁再次加锁，则加锁操作返回 `EDEADLK`。对一个已经被其他线程加锁的检错锁解锁，或者对一个已经解锁的检错锁再次解锁，则解锁操作返回 `EPERM`。 
- `PTHREAD_MUTEX_RECURSIVE`，嵌套(可重入)锁。这种锁允许一个线程在释放锁之前多次对它加锁而不发生死锁。不过其他线程如果获得这个锁，则当前锁的拥有者必须执行相应次数的解锁操作。对一个已经被其他线程加锁的嵌套锁解锁，或者对一个已经解锁的嵌套锁再次解锁，则解锁操作返回 `EPERM`。 
- `PTHREAD_MUTEX_DEFAULT`，默认锁。一个线程如果对一个已经加锁的默认锁再次加锁，或者对一个已经被其他线程加锁的默认锁解锁，或者对一个已经解锁的默认锁再次解锁，将导致不可预期的后果。这种锁在实现的时候可能被映射为上面三种锁之一。
## 条件变量
互斥锁是用于同步线程对共享数据的访问的话，而条件变量则是用于在线程之间同步共享数据的值。条件变量提供一种线程间的通知机制：当某个共享数据达到某个值的时候，唤醒等待这个共享数据的线程。条件变量的相关函数主要有如下 5 个：
```c
#include<pthread.h>
int pthread_cond_init(pthread_cond_t* cond, const pthread_condattr_t* cond_attr);
int pthread_cond_destroy(pthread_cond_t* cond);
int pthread_cond_broadcast(pthread_cond_t* cond);
int pthread_cond_signal(pthread_cond_t* cond);
int pthread_cond_wait(pthread_cond_t* cond, pthread_mutex_t* mutex);
```
`pthread_cond_init` 函数用于初始化条件变量。`cond_attr` 参数指定条件变量的属性。如果将它设置为 `NULL`，则表示使用默认属性。条件变量的属性不多，而且和互斥锁的属性类型相似。除 `pthread_cond_init` 函数外，还可以使用如下方式来初始化一个条件变量：
```c
pthread_cond_t cond=PTHREAD_COND_INITIALIZER;
```
`pthread_cond_destroy` 函数用于销毁条件变量，以释放其占用的内核资源。销毁一个正在被等待的条件变量将失败并返回 `EBUSY`。
`pthread_cond_broadcast` 函数以广播的方式唤醒所有等待目标条件变量的线程。
`pthread_cond_signal` 函数唤醒一个等待目标条件变量的线程。至于哪个线程将被唤醒，则取决于线程的优先级和调度策略。
`pthread_cond_wait` 函数使调用线程等待目标条件变量。`mutex` 参数是用于保护条件变量的互斥锁，以确保 `pthread_cond_wait` 操作的原子性。在调用 `pthread_cond_wait` 前，必须确保互斥锁 `mutex` 已经加锁，否则将导致不可预期的结果。
`pthread_cond_wait` 函数执行时，首先把调用线程放入条件变量的等待队列中，然后将互斥锁 `mutex` 解锁。
从 `pthread_cond_wait` 开始执行到其调用线程被放入条件变量的等待队列之间的这段时间内， `pthread_cond_signal` 和 `pthread_cond_broadcast` 等函数不会修改条件变量。换言之， `pthread_cond_wait` 函数不会错过目标条件变量的任何变化。当 `pthread_cond_wait` 函数成功返回时，互斥锁 `mutex` 将再次被锁上。
有时候可能想唤醒一个指定的线程，但 `pthread` 没有对该需求提供解决方法。可以间接地实现该需求：定义一个能够唯一表示目标线程的全局变量，在唤醒等待条件变量的线程前先设置该变量为目标线程，然后采用广播方式唤醒所有等待条件变量的线程，这些线程被唤醒后都检查该变量以判断被唤醒的是否是自己，如果是就开始执行后续代码，如果不是则返回继续等待。
```c
pthread_cond_wait(pthread_cond_t *c, pthread_mutex_t *m);  
pthread_cond_signal(pthread_cond_t *c); 
int done  = 0;   
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t c  = PTHREAD_COND_INITIALIZER;
void thr_exit() { 
    Pthread_mutex_lock(&m); 
    done = 1;
    Pthread_cond_signal(&c);
    Pthread_mutex_unlock(&m);
}
void *child(void *arg) {
    printf("child\n");
    thr_exit();
    return NULL;
} 
void thr_join() { 
    Pthread_mutex_lock(&m); // 若调用wait之前中断
    // 由于中断使得wait未被调用，锁没有释放，其它线程无法进入临界区，必须等待中断结束
	// 因此不会出现中断后进入另一个线程，唤醒线程时没有线程处于睡眠状态，中断结束后执行wait，父线程无法再次被唤醒的情况

    // 设想此处使用if语句：被唤醒后done=1，现在如果是while循环会再次检查，而if情况不会再次检查
    // 这在只有一个子线程没有抢占的情况中没有问题，但下面那个例子中就会存在问题，就必须要while来再次检查
    while (done == 0) Pthread_cond_wait(&c, &m); // 被唤醒后从wait调用返回到此处，并持有锁，再次检查
    Pthread_mutex_unlock(&m); // 释放锁
} 
int main(int argc, char *argv[]) { 
    printf("parent: begin\n"); 
    pthread_t p; 
    Pthread_create(&p, NULL, child, NULL); 
    thr_join(); 
    printf("parent: end\n"); 
    return 0; 
} 
```
设想不需要 `done` 变量的情况：假设子线程立刻运行，并且调用 `thr_exit()`。在这种情况下，子线程发送信号，但此时却没有在条件变量上睡眠等待的线程。父线程运行时，就会调用 `wait` 并卡在那里，没有其他线程会唤醒它。
多线程程序在检查条件变量时，使用 `while` 循环总是对的。`if` 语句可能会对，这取决于发信号的语义。对条件变量使用 `while` 循环，解决假唤醒的情况。某些线程库中，由于实现的细节，有可能出现一个信号唤醒两个线程的情况，再次检查线程的等待条件。
假设线程在发信号和等待时都不加锁。会发生什么问题：
```c
void thr_exit() { 
    done = 1; 
    Pthread_cond_signal(&c);
}
void thr_join() { 
    while (done == 0) Pthread_cond_wait(&c, &m);
} 
```
如果父进程调用thr_join()，然后检查完done的值为0，然后试图睡眠。但在调用wait进入睡眠之前，父进程被中断。此时由于未加锁，因此子线程可以进入临界区，修改变量done为1，发出信号，同样没有等待线程。父线程再次运行时，就会长眠不醒，这就惨了。
因此发信号时总是持有锁尽管并不是所有情况下都严格需要，但有效且简单的做法，还是在使用条件变量发送信号时持有锁，从而使得在唤醒线程之前有线程处于睡眠状态，不会出现长眠不醒的情况。
## 生产者/消费者方案
生产者-消费者问题描述：
- **生产者**在生成数据后，放在一个缓冲区中；
- **消费者**从缓冲区取出数据处理；
- 任何时刻，**只能有一个**生产者或消费者可以访问缓冲区；
对问题分析可以得出：
- 任何时刻只能有一个线程操作缓冲区，说明操作缓冲区是临界代码，**需要互斥**；
- 缓冲区空时，消费者必须等待生产者生成数据；缓冲区满时，生产者必须等待消费者取出数据。说明生产者和消费者**需要同步**。
### 条件变量
```c
int buffer[MAX]; 
int fill  = 0; 
int use   = 0; 
int count = 0; 
void put(int value) { 
    buffer[fill] = value; 
    fill = (fill + 1) % MAX; 
    count++; 
} 
int get() { 
    int tmp = buffer[use]; 
    use = (use + 1) % MAX; 
    count--; 
    return tmp; 
} 

cond_t empty, fill; // 使用两个条件变量
mutex_t mutex;
void *producer(void *arg) { 
    int i; 
    for (i = 0; i < loops; i++) { 
        Pthread_mutex_lock(&mutex);
        while (count == MAX) // count == MAX 达到缓冲区最大大小，因此休眠直到empty再唤醒它
            Pthread_cond_wait(&empty, &mutex); // 生产者休眠使用empty变量
        put(i); 
        Pthread_cond_signal(&fill);  // 唤醒消费者使用fill变量
        Pthread_mutex_unlock(&mutex);
    } 
} 
void *consumer(void *arg) { 
    int i; 
    for (i = 0; i < loops; i++) { 
        Pthread_mutex_lock(&mutex);
        while (count == 0) // count==0 代表缓冲区没东西了，因此休眠直到fill的时候再唤醒它
            Pthread_cond_wait(&fill, &mutex); // 消费者休眠使用fill变量
        int tmp = get(); 
        Pthread_cond_signal(&empty);  // 唤醒生产者使用empty变量
        Pthread_mutex_unlock(&mutex); 
        printf("%d\n", tmp); 
    } 
} 
```
### 信号量
向缓冲区加入元素和增加缓冲区的索引是临界区。所以，使用二值信号量来增加锁。由于信号量无法在休眠时自动释放锁，因此需要考虑死锁问题。不能让消费者在缓冲区为 0 时先拿到锁，导致生产者无法进入临界区增加缓冲区，从而死锁，把获取和释放互斥量的操作调整为紧挨着临界区，把full、empty的唤醒和等待操作调整到锁外面。
如果消费者线程一开始执行 `P(fullBuffers)`，由于信号量 `fullBuffers` 初始值为 0，则此时 `fullBuffers` 的值从 0 变为 -1，说明缓冲区里没有数据，消费者只能等待。
接着，轮到生产者执行 `P(emptyBuffers)`，表示减少 1 个空槽，如果当前没有其他生产者线程在临界区执行代码，那么该生产者线程就可以把数据放到缓冲区，放完后，执行 `V(fullBuffers)` ，信号量 `fullBuffers` 从 -1 变成 0，表明有「消费者」线程正在阻塞等待数据，于是阻塞等待的消费者线程会被唤醒。
消费者线程被唤醒后，如果此时没有其他消费者线程在读数据，那么就可以直接进入临界区，从缓冲区读取数据。最后，离开临界区后，把空槽的个数 + 1。 
```c++
sem_t empty;  // 生产者询问缓冲区是否有空位，有空位则生成数据，初始化值为 n （缓冲区大小）；
sem_t full;   // 消费者询问缓冲区是否有数据，有数据则读取数据，初始化值为 0（表明缓冲区一开始为空）；
sem_t mutex;  // 互斥信号量 mutex 用于互斥访问缓冲区，初始化值为 1；
void *producer(void *arg) { 
  int i; 
  for (i = 0; i < loops; i++) { 
    sem_wait(&empty); // 进行生产，若empty小于0，即缓冲区满了，则直接休眠，不会持有锁
    sem_wait(&mutex);
    put(i);
    sem_post(&mutex);
    sem_post(&full);
  } 
} 
void *consumer(void *arg) { 
  int i; 
  for (i = 0; i < loops; i++) { 
    sem_wait(&full); // 进行消费，若full小于0，即缓冲区为空，则直接休眠，不会持有锁
    sem_wait(&mutex);
    int tmp = get();   
    sem_post(&mutex);
    sem_post(&empty);
    printf("%d\n", tmp); 
  } 
}    
int main(int argc, char *argv[]) { 
  // ... 
  sem_init(&empty, 0, MAX); 
  sem_init(&full, 0, 0);
  sem_init(&mutex, 0, 1);// mutex=1 because it is a lock (NEW LINE) 
  // ... 
} 
```
## 哲学家就餐问题
### 方案一
用信号量的方式，也就是 PV 操作来尝试解决它，代码如下：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/24-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E4%B8%80%E7%A4%BA%E4%BE%8B.jpg)
上面的程序，好似很自然。拿起叉子用 P 操作，代表有叉子就直接用，没有叉子时就等待其他哲学家放回叉子。
![方案一的问题](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/25-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E4%B8%80%E9%97%AE%E9%A2%98.jpg)
不过，这种解法存在一个极端的问题：**假设五位哲学家同时拿起左边的叉子，桌面上就没有叉子了，这样就没有人能够拿到他们右边的叉子，也就说每一位哲学家都会在 `P(fork[(i + 1) % N ])` 这条语句阻塞了，很明显这发生了死锁的现象**。
### 方案二
既然「方案一」会发生同时竞争左边叉子导致死锁的现象，那么就在拿叉子前，加个互斥信号量，代码如下：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/26-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E4%BA%8C%E7%A4%BA%E4%BE%8B.jpg)
上面程序中的互斥信号量的作用就在于，**只要有一个哲学家进入了「临界区」，也就是准备要拿叉子时，其他哲学家都不能动，只有这位哲学家用完叉子了，才能轮到下一个哲学家进餐。**
![方案二的问题](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/27-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E4%BA%8C%E9%97%AE%E9%A2%98.jpg)
方案二虽然能让哲学家们按顺序吃饭，但是每次进餐只能有一位哲学家，而桌面上是有 5 把叉子，按道理是能可以有两个哲学家同时进餐的，所以从效率角度上，这不是最好的解决方案。
### 方案三
那既然方案二使用互斥信号量，会导致只能允许一个哲学家就餐，那么就不用它。另外，方案一的问题在于，会出现所有哲学家同时拿左边刀叉的可能性，那就避免哲学家可以同时拿左边的刀叉，采用分支结构，根据哲学家的编号的不同，而采取不同的动作。
**即让偶数编号的哲学家「先拿左边的叉子后拿右边的叉子」，奇数编号的哲学家「先拿右边的叉子后拿左边的叉子」。**
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/28-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E4%B8%89%E7%A4%BA%E4%BE%8B.jpg)
上面的程序，在 P 操作时，根据哲学家的编号不同，拿起左右两边叉子的顺序不同。另外，V 操作是不需要分支的，因为 V 操作是不会阻塞的。
![方案三可解决问题](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/29-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E4%B8%89-%E5%9B%BE%E8%A7%A3.jpg)
方案三即不会出现死锁，也可以两人同时进餐。
### 方案四
在这里再提出另外一种可行的解决方案，**用一个数组 state 来记录每一位哲学家的三个状态，分别是在进餐状态、思考状态、饥饿状态（正在试图拿叉子）。**
那么，**一个哲学家只有在两个邻居都没有进餐时，才可以进入进餐状态。**
第 `i` 个哲学家的左邻右舍，则由宏 `LEFT` 和 `RIGHT` 定义：
- *LEFT* : ( i + 5  - 1 ) % 5
- *RIGHT* : ( i + 1 ) % 5
比如 i 为 2，则 `LEFT` 为 1，`RIGHT` 为 3。
具体代码实现如下：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/30-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E5%9B%9B%E7%A4%BA%E4%BE%8B.jpg)
上面的程序使用了一个信号量数组，每个信号量对应一位哲学家，这样在所需的叉子被占用时，想进餐的哲学家就被阻塞。
注意，每个进程/线程将 `smart_person` 函数作为主代码运行，而其他 `take_forks`、`put_forks` 和 `test`只是普通的函数，而非单独的进程/线程。
![方案四也可解决问题](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/31-%E5%93%B2%E5%AD%A6%E5%AE%B6%E8%BF%9B%E9%A4%90-%E6%96%B9%E6%A1%88%E5%9B%9B-%E5%9B%BE%E8%A7%A3.jpg)
方案四同样不会出现死锁，也可以两人同时进餐。
## 读者-写者问题
前面的「哲学家进餐问题」对于互斥访问有限的竞争问题（如 I/O 设备）一类的建模过程十分有用。
另外，还有个著名的问题是「读者-写者」，它为数据库访问建立了一个模型。
读者只会读取数据，不会修改数据，而写者即可以读也可以修改数据。
读者-写者的问题描述：
- 「读-读」允许：同一时刻，允许多个读者同时读
- 「读-写」互斥：没有写者时读者才能读，没有读者时写者才能写
- 「写-写」互斥：没有其他写者时，写者才能写
接下来，提出几个解决方案来分析分析。
### 方案一
使用信号量的方式来尝试解决：
- 信号量 `wMutex`：控制写操作的互斥信号量，初始值为 1 ；
- 读者计数 `rCount`：正在进行读操作的读者个数，初始化为 0；
- 信号量 `rCountMutex`：控制对 rCount 读者计数器的互斥修改，初始值为 1；
接下来看看代码的实现：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/32-%E8%AF%BB%E8%80%85%E5%86%99%E8%80%85-%E6%96%B9%E6%A1%88%E4%B8%80%E7%A4%BA%E4%BE%8B.jpg)
上面的这种实现，是读者优先的策略，因为只要有读者正在读的状态，后来的读者都可以直接进入，如果读者持续不断进入，则写者会处于饥饿状态。
### 方案二
那既然有读者优先策略，自然也有写者优先策略：
- 只要有写者准备要写入，写者应尽快执行写操作，后来的读者就必须阻塞；
- 如果有写者持续不断写入，则读者就处于饥饿；
在方案一的基础上新增如下变量：
- 信号量 `rMutex`：控制读者进入的互斥信号量，初始值为 1；
- 信号量 `wDataMutex`：控制写者写操作的互斥信号量，初始值为 1；
- 写者计数 `wCount`：记录写者数量，初始值为 0；
- 信号量 `wCountMutex`：控制 wCount 互斥修改，初始值为 1；
具体实现如下代码：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/33-%E8%AF%BB%E8%80%85%E5%86%99%E8%80%85-%E6%96%B9%E6%A1%88%E4%BA%8C%E7%A4%BA%E4%BE%8B.jpg)
注意，这里 `rMutex` 的作用，开始有多个读者读数据，它们全部进入读者队列，此时来了一个写者，执行了 `P(rMutex)` 之后，后续的读者由于阻塞在 `rMutex` 上，都不能再进入读者队列，而写者到来，则可以全部进入写者队列，因此保证了写者优先。
同时，第一个写者执行了 `P(rMutex)` 之后，也不能马上开始写，必须等到所有进入读者队列的读者都执行完读操作，通过 `V(wDataMutex)` 唤醒写者的写操作。 
### 方案三
既然读者优先策略和写者优先策略都会造成饥饿的现象，那么就来实现一下公平策略。
公平策略：
- 优先级相同；
- 写者、读者互斥访问；
- 只能一个写者访问临界区；
- 可以有多个读者同时访问临界资源；
具体代码实现：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/%E4%BA%92%E6%96%A5%E4%B8%8E%E5%90%8C%E6%AD%A5/34-%E8%AF%BB%E8%80%85%E5%86%99%E8%80%85-%E6%96%B9%E6%A1%88%E4%B8%89%E7%A4%BA%E4%BE%8B.jpg)
为什么加了一个信号量 `flag`，就实现了公平竞争？
对比方案一的读者优先策略，可以发现，读者优先中只要后续有读者到达，读者就可以进入读者队列， 而写者必须等待，直到没有读者到达。
没有读者到达会导致读者队列为空，即 `rCount==0`，此时写者才可以进入临界区执行写操作。
而这里 `flag` 的作用就是阻止读者的这种特殊权限（特殊权限是只要读者到达，就可以进入读者队列）。 
比如：开始来了一些读者读数据，它们全部进入读者队列，此时来了一个写者，执行 `P(falg)` 操作，使得后续到来的读者都阻塞在 `flag` 上，不能进入读者队列，这会使得读者队列逐渐为空，即 `rCount` 减为 0。
这个写者也不能立马开始写（因为此时读者队列不为空），会阻塞在信号量 `wDataMutex` 上，读者队列中的读者全部读取结束后，最后一个读者进程执行 `V(wDataMutex)`，唤醒刚才的写者，写者则继续开始进行写操作。 
## 基于事件的并发
基于事件的并发（event-based concurrency）：等待某事件发生；当它发生时，检查事件类型，然后做少量的相应工作（可能是I/O请求，或者调度其他事件准备后续处理）。使用单个CPU和基于事件的应用程序，并发程序中发现的问题不再存在。具体来说，因为一次只处理一个事件，所以不需要获取或释放锁。基于事件的服务器不能被另一个线程中断，因为它确实是单线程的。因此，线程化程序中常见的并发性错误并没有出现在基本的基于事件的方法中。
使用基于事件的方法时，没有其他线程可以运行：只是主事件循环。因此，在基于事件的系统中必须遵守一条规则：不允许阻塞调用。
为了克服这个限制，许多现代操作系统已经引入了新的方法来向磁盘系统发出I/O请求，一般称为异步I/O（asynchronous I/O）。这些接口使应用程序能够发出I/O请求，并在I/O完成之前立即将控制权返回给调用者，另外的接口让应用程序能够确定各种I/O是否已完成。
> 基于事件的服务器可以对任务调度进行细粒度的控制。但是，为了保持这种控制，不可以有阻止调用者执行的调用。