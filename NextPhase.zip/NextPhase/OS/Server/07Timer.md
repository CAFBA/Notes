# Timer
## SO_RCVTIMEO/SO_SNDTIMEO
`socket` 选项 `SO_RCVTIMEO` 和 `SO_SNDTIMEO` 分别用来设置 `socket` 接收数据超时时间和发送数据超时时间。因此，这两个选项仅对与数据接收和发送相关的 `socket` 专用系统调用有效：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240227153451.png)
## SIGALRM
由 `alarm` 和 `setitimer` 函数设置的实时闹钟一旦超时，将触发 `SIGALRM` 信号，因此可以利用该信号的信号处理函数来处理定时任务。但是，如果要处理多个定时任务，就需要不断地触发 `SIGALRM` 信号，并在其信号处理函数中执行到期的任务。
一般而言，`SIGALRM` 信号按照固定的频率生成，即由 `alarm` 或 `setitimer` 函数设置的定时周期 `T` 保持不变。如果某个定时任务的超时时间不是 `T` 的整数倍，那么它实际被执行的时间和预期的时间将略有偏差，因此定时周期 `T` 反映定时的精度。 
定时器通常至少要包含两个成员：一个超时时间和一个任务回调函数。有的时候还可能包含回调函数被执行时需要传入的参数，以及是否重启定时器等信息。如果使用链表作为容器来串联所有的定时器，则每个定时器还要包含指向下一个定时器的指针成员。进一步，如果链表是双向的，则每个定时器还需要包含指向前一个定时器的指针成员。下面实现一个简单的升序定时器链表。升序定时器链表将其中的定时器按照超时时间做升序排序。
`sort_timer_lst` 是一个升序链表。其核心函数 `tick` 相当于一个心搏函数，它每隔一段固定的时间就执行一次，以检测并处理到期的任务。判断定时任务到期的依据是定时器的 `expire` 值小于当前的系统时间。从执行效率来看，添加定时器的时间复杂度是O(n)，删除定时器的时间复杂度是O(1)，执行定时任务的时间复杂度是O(1)。
```cpp
#ifndef LST_TIMER
#define LST_TIMER

#include <time.h>

#define BUFFER_SIZE 64
class util_timer; /* 前向声明 */ 

/* 用户数据结构：客户端socket地址、socket文件描述符、读缓存和定时器 */
struct client_data {
    sockaddr_in address;
    int sockfd;
    char buf[BUFFER_SIZE];
    util_timer* timer;
};

class util_timer /* 定时器类 */
{
public:
    util_timer() : prev(NULL), next(NULL){}

public:
   time_t expire;  /* 任务的超时时间，这里使用绝对时间 */
   void (*cb_func)(client_data*); /* 任务回调函数 */
   client_data* user_data; /* 回调函数处理的客户数据，由定时器的执行者传递给回调函数*/
   util_timer* prev; /* 指向前一个定时器 */
   util_timer* next; /* 指向下一个定时器 */
};

class sort_timer_lst /* 定时器链表。它是一个升序、双向链表，且带有头结点和尾节点 */
{
public:
    sort_timer_lst() : head(NULL), tail(NULL) {}
    ~sort_timer_lst() /*链表被销毁时，删除其中所有的定时器*/
    {
        util_timer* tmp = head;
        while(tmp)
        {
            head = tmp->next;
            delete tmp;
            tmp = head;
        }
    }
    void add_timer(util_timer* timer) // 将目标定时器timer添加到链表中 
    {
        if(!timer) return;
        if(!head) {
            head = tail = timer;
            return; 
        }
        // 如果目标定时器的超时时间小于当前链表中所有定时器的超时时间，
        // 则把该定时器插入链表头部，作为链表新的头节点。
        if(timer->expire < head->expire) {
            timer->next = head;
            head->prev = timer;
            head = timer;
            return;
        }
        // 否则就需要调用重载函数 add_timer(util_timer*timer,util_timer*lst_head)
        // 把它插入链表中合适的位置，以保证链表的升序特性
        add_timer(timer, head);
    }
    // 当某个定时任务发生变化时，调整对应的定时器在链表中的位置。
    // 这个函数只考虑被调整的定时器的超时时间延长的情况，即该定时器需要往链表的尾部移动
    void adjust_timer( util_timer* timer )
    {
        if(!timer)return;
        util_timer* tmp = timer->next;
        // 如果被调整的目标定时器处在链表尾部，或者该定时器新的超时值仍然小于其下一个定时器的超时值，则不用调整
        if(!tmp || (timer->expire < tmp->expire)) return;
        // 如果目标定时器是链表的头节点，则将该定时器从链表中取出并重新插入链表
        if( timer == head )
        {
            head = head->next;
            head->prev = NULL;
            timer->next = NULL;
            add_timer(timer, head);
        }
        else // 如果目标定时器不是链表的头节点，则将该定时器从链表中取出，然后插入其原来所在位置之后的部分链表中
        {
            timer->prev->next = timer->next;
            timer->next->prev = timer->prev;
            add_timer( timer, timer->next );
        }
    }
    // 将目标定时器timer从链表中删除
    void del_timer( util_timer* timer )
    {
        if(!timer) return;
        // 若链表中只有目标定时器这一个定时器
        if((timer == head) && (timer == tail))
        {
            delete timer;
            head = NULL;
            tail = NULL;
            return;
        }
        // 如果链表中至少有两个定时器，且目标定时器是链表的头结点
        // 则将链表的头结点重 置为原头节点的下一个节点，然后删除目标定时器
        if(timer == head)
        {
            head = head->next;
            head->prev = NULL;
            delete timer;
            return;
        }
        // 如果链表中至少有两个定时器，且目标定时器是链表的尾结点
        // 则将链表的尾结点重置为原尾节点的前一个节点，然后删除目标定时器
        if(timer == tail)
        {
            tail = tail->prev;
            tail->next = NULL;
            delete timer;
            return;
        }
        // 如果目标定时器位于链表的中间，则把它前后的定时器串联起来，然后删除目标定时器
        timer->prev->next = timer->next;
        timer->next->prev = timer->prev;
        delete timer;
    }
    // SIGALRM信号每次被触发就在其信号处理函数（如果使用统一事件源，则是主函数） 中执行一次tick函数，以处理链表上到期的任务*/
    void tick()
    {
        if(!head) return;
        printf( "timer tick\n" );
        time_t cur = time(NULL); // 获得系统当前的时间
        util_timer* tmp = head;
        // 从头结点开始依次处理每个定时器，直到遇到一个尚未到期的定时器，这就是定时器的核心逻辑
        while(tmp) {
            // 因为每个定时器都使用绝对时间作为超时值，所以可以把定时器的超时值和系统当前时间，比较以判断定时器是否到期
            if(cur < tmp->expire) break;
            // 调用定时器的回调函数，以执行定时任务
            tmp->cb_func( tmp->user_data );
            // 执行完定时器中的定时任务之后，就将它从链表中删除，并重置链表头结点
            head = tmp->next;
            if(head) head->prev = NULL;
            delete tmp;
            tmp = head;
        }
    }

private:
    // 一个重载的辅助函数，它被公有的add_timer函数和adjust_timer函数调用
    // 该函数表示将目标定时器timer添加到节点lst_head之后的部分链表中
    void add_timer( util_timer* timer, util_timer* lst_head )
    {
        util_timer* prev = lst_head;
        util_timer* tmp = prev->next;
        // 遍历lst_head节点之后的部分链表，直到找到一个超时时间大于目标定时器的超时时间的节点，并将目标定时器插入该节点之前
        while(tmp)
        {
            if(timer->expire < tmp->expire)
            {
                prev->next = timer;
                timer->next = tmp;
                tmp->prev = timer;
                timer->prev = prev;
                break;
            }
            prev = tmp;
            tmp = tmp->next;
        }
        // 如果遍历完lst_head节点之后的部分链表，仍未找到超时时间大于目标定时器的超时时间的节点，则将目标定时器插入链表尾部，并把它设置为链表新的尾节点
        if(!tmp)
        {
            prev->next = timer;
            timer->prev = prev;
            timer->next = NULL;
            tail = timer;
        }
        
    }

private:
    util_timer* head;
    util_timer* tail;
};

#endif
```
服务器程序通常要定期处理非活动连接：给客户端发一个重连请求，或者关闭该连接，或者其他。Linux在内核中提供对连接是否处于活动状态的定期检查机制，可以通过 `socket` 选项 `KEEPALIVE` 来激活它。不过使用这种方式将使得应用程序对连接的管理变得复杂。因此，可以考虑在应用层实现类似于 `KEEPALIVE` 的机制，以管理所有长时间处于非活动状态的连接。比如，下述利用 `alarm` 函数周期性地触发 `SIGALRM` 信号，该信号的信号处理函数利用管道通知主循环执行定时器链表上的定时任务——关闭非活动的连接。
```cpp
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/epoll.h>
#include <pthread.h>
#include "lst_timer.h"

#define FD_LIMIT 65535
#define MAX_EVENT_NUMBER 1024
#define TIMESLOT 5

static int pipefd[2];
static sort_timer_lst timer_lst; // 利用升序链表来管理定时器
static int epollfd = 0;

int setnonblocking( int fd )
{
    int old_option = fcntl( fd, F_GETFL );
    int new_option = old_option | O_NONBLOCK;
    fcntl(fd, F_SETFL, new_option);
    return old_option;
}

void addfd( int epollfd, int fd )
{
    epoll_event event;
    event.data.fd = fd;
    event.events = EPOLLIN | EPOLLET;
    epoll_ctl(epollfd, EPOLL_CTL_ADD, fd, &event);
    setnonblocking(fd);
}

void sig_handler( int sig )
{
    int save_errno = errno;
    int msg = sig;
    send(pipefd[1], (char*)&msg, 1, 0 );
    errno = save_errno;
}

void addsig( int sig )
{
    struct sigaction sa;
    memset(&sa, '\0', sizeof(sa));
    sa.sa_handler = sig_handler;
    sa.sa_flags |= SA_RESTART;
    sigfillset(&sa.sa_mask);
    assert(sigaction( sig, &sa, NULL ) != -1);
}

void timer_handler() /*定时处理任务，实际上就是调用tick函数*/
{
    /*因为一次alarm调用只会引起一次SIGALRM信号，所以要重新定时，以不断触发SIGALRM信号*/
    timer_lst.tick();
    alarm(TIMESLOT);
}

/*定时器回调函数，它删除非活动连接socket上的注册事件，并关闭之*/
void cb_func( client_data* user_data )
{
    epoll_ctl( epollfd, EPOLL_CTL_DEL, user_data->sockfd, 0 );
    assert( user_data );
    close( user_data->sockfd );
    printf( "close fd %d\n", user_data->sockfd );
}

int main( int argc, char* argv[] )
{
    if( argc <= 2 )
    {
        printf( "usage: %s ip_address port_number\n", basename( argv[0] ) );
        return 1;
    }
    const char* ip = argv[1];
    int port = atoi( argv[2] );

    int ret = 0;
    struct sockaddr_in address;
    bzero( &address, sizeof( address ) );
    address.sin_family = AF_INET;
    inet_pton( AF_INET, ip, &address.sin_addr );
    address.sin_port = htons( port );

    int listenfd = socket( PF_INET, SOCK_STREAM, 0 );
    assert( listenfd >= 0 );

    ret = bind( listenfd, ( struct sockaddr* )&address, sizeof( address ) );
    assert( ret != -1 );

    ret = listen( listenfd, 5 );
    assert(ret != -1);

    epoll_event events[ MAX_EVENT_NUMBER ];
    int epollfd = epoll_create(5);
    assert(epollfd != -1);
    addfd(epollfd, listenfd);

    ret = socketpair(PF_UNIX, SOCK_STREAM, 0, pipefd);
    assert(ret != -1);
    setnonblocking(pipefd[1]);
    addfd(epollfd, pipefd[0]);

    // 设置信号处理函数
    addsig(SIGALRM);
    addsig(SIGTERM);
    bool stop_server = false;

    client_data* users = new client_data[FD_LIMIT]; 
    bool timeout = false;
    alarm(TIMESLOT);

    while(!stop_server)
    {
        int number = epoll_wait(epollfd, events, MAX_EVENT_NUMBER, -1);
        if ((number < 0) && (errno != EINTR))
        {
            printf( "epoll failure\n" );
            break;
        }
    
        for (int i = 0; i < number; i++)
        {
            int sockfd = events[i].data.fd;
            if(sockfd == listenfd) // 处理新到的客户连接
            {
                struct sockaddr_in client_address;
                socklen_t client_addrlength = sizeof( client_address );
                int connfd = accept( listenfd, ( struct sockaddr* )&client_address, &client_addrlength );
                addfd( epollfd, connfd );
                users[connfd].address = client_address;
                users[connfd].sockfd = connfd;
                // 创建定时器，设置其回调函数与超时时间，然后绑定定时器与用户数据
                // 最后将定时 器添加到链表timer_lst中
                util_timer* timer = new util_timer;
                timer->user_data = &users[connfd];
                timer->cb_func = cb_func;
                time_t cur = time(NULL);
                timer->expire = cur + 3 * TIMESLOT;
                users[connfd].timer = timer;
                timer_lst.add_timer(timer);
            }
            // 处理信号
            else if((sockfd == pipefd[0]) && (events[i].events & EPOLLIN))
            {
                int sig;
                char signals[1024];
                ret = recv( pipefd[0], signals, sizeof( signals ), 0 );
                if(ret == -1)
                {
                    // handle the error
                    continue;
                }
                else if( ret == 0 ) continue;
                else
                {
                    for( int i = 0; i < ret; ++i )
                    {
                        switch( signals[i] )
                        {
                            case SIGALRM:
                            {
                // 用timeout变量标记有定时任务需要处理，但不立即处理定时任务
                // 这是因为定时任务的优先级不是很高，优先处理其他更重要的任务
                                timeout = true;
                                break;
                            }
                            case SIGTERM:
                            {
                                stop_server = true;
                            }
                        }
                    }
                }
            }
            // 处理客户连接上接收到的数据
            else if(  events[i].events & EPOLLIN )
            {
                memset( users[sockfd].buf, '\0', BUFFER_SIZE );
                ret = recv( sockfd, users[sockfd].buf, BUFFER_SIZE-1, 0 );
                printf( "get %d bytes of client data %s from %d\n", ret, users[sockfd].buf, sockfd );
                util_timer* timer = users[sockfd].timer;
                if( ret < 0 )
                {
                // 如果发生读错误，则关闭连接，并移除其对应的定时器
                    if( errno != EAGAIN )
                    {
                        cb_func( &users[sockfd] );
                        if( timer )
                        {
                            timer_lst.del_timer( timer );
                        }
                    }
                }
                // 如果对方已经关闭连接，则我们也关闭连接，并移除对应的定时器
                else if( ret == 0 )
                {
                    cb_func( &users[sockfd] );
                    if( timer )
                    {
                        timer_lst.del_timer( timer );
                    }
                }
                else
                {
                // 如果某个客户连接上有数据可读，则要调整该连接对应的定时器，以延迟该连接 被关闭的时间*/
                    //send( sockfd, users[sockfd].buf, BUFFER_SIZE-1, 0 );
                    if( timer )
                    {
                        time_t cur = time( NULL );
                        timer->expire = cur + 3 * TIMESLOT;
                        printf( "adjust timer once\n" );
                        timer_lst.adjust_timer( timer );
                    }
                }
            }
            else
            {
                // others
            }
        }
        // 最后处理定时事件，因为I/O事件有更高的优先级
        // 当然，这样做将导致定时任务不能精确地按照预期的时间执行
        if( timeout )
        {
            timer_handler();
            timeout = false;
        }
    }

    close( listenfd );
    close( pipefd[1] );
    close( pipefd[0] );
    delete [] users;
    return 0;
}
```
## I/O复用系统调用的超时参数
`Linux` 下的 3 组 `I/O` 复用系统调用都带有超时参数，因此它们不仅能统一处理信号和 I/O 事件，也能统一处理定时事件。但是由于 `I/O` 复用系统调用可能在有 `I/O` 事件发生时，在超时时间到期之前就返回，所以如果要利用它们来定时，就需要不断更新定时参数以反映剩余的时间：
```cpp
#define TIMEOUT 5000

int timeout = TIMEOUT;
time_t start = time( NULL );
time_t end = time( NULL );
while( 1 )
{
    printf( "the timeout is now %d mill-seconds\n", timeout );
    start = time( NULL );
    int number = epoll_wait( epollfd, events, MAX_EVENT_NUMBER, timeout );
    if( ( number < 0 ) && ( errno != EINTR ) )
    {
        printf( "epoll failure\n" );
        break;
    }
    // 如果epoll_wait成功返回0，则说明超时时间到，此时便可处理定时任务，并重置定时时间
    if( number == 0 )
    {
        // timeout
        timeout = TIMEOUT;
        continue;
    }
    end = time( NULL );
    // 如果epoll_wait的返回值大于0，则本次epoll_wait调用持续的时间是(endstart)*1000 ms
    // 需要将定时时间timeout减去这段时间，以获得下次epoll_wait 调用的超时参数
    timeout -= ( end - start ) * 1000;
    // 重新计算之后的timeout值有可能等于0，说明本次epoll_wait调用返回时
    // 不仅有文件描述符就绪，而且其超时时间也刚好到达，此时也要处理定时任务，并重置定时时间
    if( timeout <= 0 )
    {
        // timeout
        timeout = TIMEOUT;
    }

    // handle connections
}
```
## 高性能定时器
### 时间轮
基于排序链表的定时器存在一个问题：添加定时器的效率偏低，时间轮解决了这个问题。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240227160756.png)
时间轮以恒定的速度顺时针转动，每转动一步就指向下一个 `slot`，每次转动称为一个 `tick`。一个`tick` 的时间称为时间轮的槽间隔 `si`(`slot interval`)，它实际上就是心搏时间。该时间轮共有 `N` 个槽，因此它运转一周的时间是 `N*si`。
每个槽指向一条定时器链表，每条链表上的定时器具有相同的特征：它们的定时时间相差 `N*si` 的整数倍。时间轮正是利用这个关系将定时器散列到不同的链表中。假如现在指针指向槽 `cs`，要添加一个定时时间为 `ti` 的定时器，则该定时器将被插入槽 `ts(timer slot)` 对应的链表中：
$$
ts=(cs +(ti/si))\%N
$$
基于排序链表的定时器使用唯一的一条链表来管理所有定时器，所以插入操作的效率随着定时器数目的增多而降低。而时间轮使用哈希表的思想，将定时器散列到不同的链表上。这样每条链表上的定时器数目都将明显少于原来的排序链表上的定时器数目，插入操作的效率基本不受定时器数目的影响。 
很显然，对时间轮而言，要提高定时精度，就要使 `si` 值足够小，而要提高执行效率，则要求 `N` 值足够大。复杂的时间轮可能有多个轮子，不同的轮子拥有不同的粒度。相邻的两个轮子，精度高的转一圈，精度低的仅往前移动一 `slot`。
可见，对时间轮而言，添加一个定时器的时间复杂度是 `O(1)`， 删除一个定时器的时间复杂度也是`O(1)`，执行一个定时器的时间复杂度是 `O(n)`，但实际上执行一个定时器任务的效率要比 `O(n)` 好得多，因为时间轮将所有的定时器散列到不同的链表上。
时间轮的槽越多，等价于散列表的入口越多，从而每条链表上的定时器数量越少。此外，代码仅使用一个时间轮。当使用多个轮子来实现时间轮时，执行一个定时器任务的时间复杂度将接近 `O(1)`。
```cpp
#ifndef TIME_WHEEL_TIMER
#define TIME_WHEEL_TIMER

#include <time.h>
#include <netinet/in.h>
#include <stdio.h>

#define BUFFER_SIZE 64
class tw_timer;

/*绑定socket和定时器*/
struct client_data
{
    sockaddr_in address;
    int sockfd;
    char buf[ BUFFER_SIZE ];
    tw_timer* timer;
};

class tw_timer /*定时器类*/
{
public:
    tw_timer( int rot, int ts ) 
    : next( NULL ), prev( NULL ), rotation( rot ), time_slot( ts ){}

public:
    int rotation; /*记录定时器在时间轮转多少圈后生效*/
    int time_slot; /*记录定时器属于时间轮上哪个槽（对应的链表，下同）*/
    void (*cb_func)( client_data* ); /*定时器回调函数*/
    client_data* user_data; /*客户数据*/
    tw_timer* next; /*指向下一个定时器*/
    tw_timer* prev; /*指向上一个定时器*/
};

class time_wheel
{
public:
    time_wheel() : cur_slot( 0 ) {
        for( int i = 0; i < N; ++i )
            slots[i] = NULL; /*初始化每个槽的头结点*/
    }
    ~time_wheel() { /*遍历每个槽，并销毁其中的定时器*/
        for( int i = 0; i < N; ++i ) {
            tw_timer* tmp = slots[i];
            while( tmp )
            {
                slots[i] = tmp->next;
                delete tmp;
                tmp = slots[i];
            }
        }
    }
    /*根据定时值timeout创建一个定时器，并把它插入合适的槽中*/
    tw_timer* add_timer( int timeout ) 
    {
        if( timeout < 0 )
        {
            return NULL;
        }
        int ticks = 0;
        // 下面根据待插入定时器的超时值计算它将在时间轮转动多少个滴答后被触发并将该滴答数存储于变量ticks中
        
        // 如果待插入定时器的超时值小于时间轮的槽间隔SI，则将ticks向上折合为1
        if( timeout < SI ) ticks = 1;
        // 否则就将ticks向下折合为timeout/SI
        else ticks = timeout / SI;
        
        /*计算待插入的定时器在时间轮转动多少圈后被触发*/
        int rotation = ticks / N;
        
        /*计算待插入的定时器应该被插入哪个槽中*/
        int ts = ( cur_slot + ( ticks % N ) ) % N;
        /*创建新的定时器，它在时间轮转动rotation圈之后被触发，且位于第ts个槽上*/
        tw_timer* timer = new tw_timer( rotation, ts );
        
        /*如果第ts个槽中尚无任何定时器，则把新建的定时器插入其中，并将该定时器设置为该槽的头结点*/
        if( !slots[ts] )
        {
            printf( "add timer, rotation is %d, ts is %d, cur_slot is %d\n", rotation, ts, cur_slot );
            slots[ts] = timer;
        }
        else /*否则，将定时器插入第ts个槽中*/
        {
            timer->next = slots[ts];
            slots[ts]->prev = timer;
            slots[ts] = timer;
        }
        return timer;
    }
    
    void del_timer( tw_timer* timer ) /*删除目标定时器timer*/
    {
        if( !timer ) return;
        int ts = timer->time_slot;
        // slots[ts]是目标定时器所在槽的头结点。
        // 如果目标定时器就是该头结点，则需要重置第ts个槽的头结点
        if( timer == slots[ts] )
        {
            slots[ts] = slots[ts]->next;
            if( slots[ts] )
            {
                slots[ts]->prev = NULL;
            }
            delete timer;
        }
        else
        {
            timer->prev->next = timer->next;
            if( timer->next )
            {
                timer->next->prev = timer->prev;
            }
            delete timer;
        }
    }

    void tick() /*SI时间到后，调用该函数，时间轮向前滚动一个槽的间隔*/
    {
        tw_timer* tmp = slots[cur_slot]; /*取得时间轮上当前槽的头结点*/
        printf( "current slot is %d\n", cur_slot );
        while( tmp )
        {
            printf( "tick the timer once\n" );
            if( tmp->rotation > 0 ) /*如果定时器的rotation值大于0，则它在这一轮不起作用*/
            {
                tmp->rotation--;
                tmp = tmp->next;
            }
            else /*否则，说明定时器已经到期，于是执行定时任务，然后删除该定时器*/
            {
                tmp->cb_func( tmp->user_data );
                if( tmp == slots[cur_slot] )
                {
                    printf( "delete header in cur_slot\n" );
                    slots[cur_slot] = tmp->next;
                    delete tmp;
                    if( slots[cur_slot] )
                    {
                        slots[cur_slot]->prev = NULL;
                    }
                    tmp = slots[cur_slot];
                }
                else
                {
                    tmp->prev->next = tmp->next;
                    if( tmp->next )
                    {
                        tmp->next->prev = tmp->prev;
                    }
                    tw_timer* tmp2 = tmp->next;
                    delete tmp;
                    tmp = tmp2;
                }
            }
        }
        cur_slot = ++cur_slot % N; /*更新时间轮的当前槽，以反映时间轮的转动*/
    }

private:
    static const int N = 60; /*时间轮上槽的数目*/
    static const int SI = 1; /*每1s时间轮转动一次，即槽间隔为1s*/
    tw_timer* slots[N];
    int cur_slot;
};

#endif
```
### 时间堆
前面讨论的定时方案都是以固定的频率调用心搏函数 `tick`，并在其中依次检测到期的定时器，然后执行到期定时器上的回调函数。设计定时器的另外一种思路是：将所有定时器中超时时间最小的一个定时 器的超时值作为心搏间隔。这样，一旦经过心搏间隔后心搏函数 `tick` 被调用，超时时间最小的定时器必然到期，就可以在 `tick` 函数中处理该定时器。然后，再次从剩余的定时器中找出超时时间最小的一个，并将这段最小时间设置为下一次心搏间隔。最小堆很适合处理这种定时方案。
对时间堆而言，添加一个定时器的时间复杂度是 `O(lgn)`，删除一个定时器的时间复杂度是 `O(1)`，执行一个定时器的时间复杂度是 `O(1)`。因此，时间堆的效率是很高的。
```cpp
#ifndef intIME_HEAP
#define intIME_HEAP

#include <iostream>
#include <netinet/in.h>
#include <time.h>
using std::exception;

#define BUFFER_SIZE 64

class heap_timer;

struct client_data /*绑定socket和定时器*/
{
    sockaddr_in address;
    int sockfd;
    char buf[ BUFFER_SIZE ];
    heap_timer* timer;
};

class heap_timer /*定时器类*/
{
public:
    heap_timer( int delay )
    {
        expire = time( NULL ) + delay;
    }

public:
   time_t expire; /*定时器生效的绝对时间*/
   void (*cb_func)( client_data* ); /*定时器的回调函数*/
   client_data* user_data; /*用户数据*/
};

class time_heap /*时间堆类*/
{
public:
    /*构造函数之一，初始化一个大小为cap的空堆*/
    time_heap( int cap ) throw ( std::exception )
        : capacity( cap ), cur_size( 0 )
    {
    	array = new heap_timer* [capacity]; /*创建堆数组*/
    	if ( ! array )
            throw std::exception();
        for( int i = 0; i < capacity; ++i )
            array[i] = NULL;
    }
    /*构造函数之二，用已有数组来初始化堆*/
    time_heap( heap_timer** init_array, int size, int capacity ) throw ( std::exception )
        : cur_size( size ), capacity( capacity )
    {
        if ( capacity < size )
            throw std::exception();
        array = new heap_timer* [capacity]; /*创建堆数组*/
        if ( ! array )
            throw std::exception();
        for( int i = 0; i < capacity; ++i )
            array[i] = NULL; /*初始化堆数组*/
        if ( size != 0 )
        {
            for ( int i =  0; i < size; ++i )
                array[ i ] = init_array[ i ];
            for ( int i = (cur_size-1)/2; i >=0; --i )
                /*对数组中的第[(cur_size-1)/2]～0个元素执行下沉操作*/
                percolate_down( i );
        }
    }
    ~time_heap() /*销毁时间堆*/
    {
        for ( int i =  0; i < cur_size; ++i )
        {
            delete array[i];
        }
        delete [] array; 
    }

public:
    /*添加目标定时器timer*/
    void add_timer( heap_timer* timer ) throw ( std::exception )
    {
        if( !timer ) return;
        /*如果当前堆数组容量不够，则将其扩大1倍*/
        if( cur_size >= capacity ) resize();
        /*新插入了一个元素，当前堆大小加1，hole是新建空穴的位置*/
        int hole = cur_size++;
        int parent = 0;
        /*对从空穴到根节点的路径上的所有节点执行上虑操作*/
        for( ; hole > 0; hole=parent )
        {
            parent = (hole-1)/2;
            if ( array[parent]->expire <= timer->expire ) break;
            array[hole] = array[parent];
        }
        array[hole] = timer;
    }
    
    void del_timer( heap_timer* timer ) /*删除目标定时器timer*/
    {
        if( !timer ) return;
        // 仅仅将目标定时器的回调函数设置为空，即所谓的延迟销毁
        // 这将节省真正删除该定时器造成的开销，但这样做容易使堆数组膨胀
        timer->cb_func = NULL;
    }
    
    heap_timer* top() const /*获得堆顶部的定时器*/
    {
        if (empty()) return NULL;
        return array[0];
    }
    
    void pop_timer() /*删除堆顶部的定时器*/
    {
        if( empty() ) return;
        if( array[0] )
        {
            delete array[0]; /*将原来的堆顶元素替换为堆数组中最后一个元素*/
            array[0] = array[--cur_size];
            percolate_down( 0 ); /*对新的堆顶元素执行下沉操作*/
        }
    }
    void tick() /*心搏函数*/
    {
        heap_timer* tmp = array[0];
        time_t cur = time( NULL );
        while( !empty() ) /*循环处理堆中到期的定时器*/
        {
            if( !tmp ) break;
            if( tmp->expire > cur ) break; /*如果堆顶定时器没到期，则退出循环*/
            if( array[0]->cb_func ) /*否则就执行堆顶定时器中的任务*/
                array[0]->cb_func( array[0]->user_data );
            pop_timer(); /*将堆顶元素删除，同时生成新的堆顶定时器（array[0]）*/
            tmp = array[0];
        }
    }
    bool empty() const { return cur_size == 0; }

private:
    // 最小堆的下沉操作，它确保堆数组中以第hole个节点作为根的子树拥有最小堆性质
    void percolate_down( int hole )
    {
        heap_timer* temp = array[hole];
        int child = 0;
        for ( ; ((hole*2+1) <= (cur_size-1)); hole=child )
        {
            child = hole*2+1;
            if ( (child < (cur_size-1)) && (array[child+1]->expire < array[child]->expire ) )
            {
                ++child;
            }
            if ( array[child]->expire < temp->expire )
            {
                array[hole] = array[child];
            }
            else
            {
                break;
            }
        }
        array[hole] = temp;
    }
    
    void resize() throw ( std::exception ) /*将堆数组容量扩大1倍*/
    {
        heap_timer** temp = new heap_timer* [2*capacity];
        for( int i = 0; i < 2*capacity; ++i )
            temp[i] = NULL;
        if ( !temp )
            throw std::exception();
        capacity = 2*capacity;
        for ( int i = 0; i < cur_size; ++i )
            temp[i] = array[i];
        delete [] array;
        array = temp;
    }

private:
    heap_timer** array; /*堆数组*/
    int capacity; /*堆数组的容量*/
    int cur_size; /*堆数组当前包含元素的个数*/
};

#endif
```


