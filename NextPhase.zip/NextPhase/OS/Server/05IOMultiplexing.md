# I/O复用

## 最基本的 Socket 模型

要想客户端和服务器能在网络中通信，那必须得使用 Socket 编程，它是进程间通信里比较特别的方式，特别之处在于它是可以跨主机间通信。创建 Socket 的时候，可以指定网络层使用的是 IPv4 还是 IPv6，传输层使用的是 TCP 还是 UDP。

服务端首先调用 `socket()` 函数，创建网络协议为 IPv4，以及传输协议为 TCP 的 Socket ，接着调用 `bind()` 函数，给这个 Socket 绑定一个 **IP 地址和端口**：

- 绑定端口的目的：当内核收到 TCP 报文，通过 TCP 头里面的端口号，来找到应用程序，从而传递数据。
- 绑定 IP 地址的目的：一台机器是可以有多个网卡的，每个网卡都有对应的 IP 地址，当绑定一个网卡时，内核在收到该网卡上的包，才会发送数据

绑定完 IP 地址和端口后，就可以**调用 `listen()` 函数进行监听**，此时对应 TCP 状态图中的 `listen`，如果要判定服务器中一个网络程序有没有启动，可以通过 `netstat` 命令查看对应的端口号是否有被监听。

服务端进入了监听状态后，通过调用 `accept()` 函数，来从内核获取客户端的连接，如果没有客户端连接，则会阻塞等待客户端连接的到来。

客户端在创建好 Socket 后，调用 `connect()` 函数发起连接，该函数的参数要指明服务端的 IP 地址和端口号，然后 TCP 三次握手就开始了。

在 TCP 连接的过程中，服务器的内核实际上为每个 Socket 维护了两个队列：

- 一个是还没完全建立连接的队列，称为 **TCP 半连接队列**，这个队列都是没有完成三次握手的连接，此时服务端处于 `syn_rcvd` 的状态；
- 一个是一件建立连接的队列，称为 **TCP 全连接队列**，这个队列都是完成了三次握手的连接，此时服务端处于 `established` 状态；

当 TCP 全连接队列不为空后，服务端的 `accept()` 函数，就会从内核中的 TCP 全连接队列里拿出一个已经完成连接的 Socket 返回应用程序，后续数据传输都用这个 Socket。

注意，监听的 Socket 和真正用来传数据的 Socket 是两个：

- 一个叫作**监听 Socket**；
- 一个叫作**已连接 Socket**；


连接建立后，客户端和服务端就开始相互传输数据了，双方都可以通过 `read()` 和 `write()` 函数来读写数据。

至此，TCP 协议的 Socket 程序的调用过程就结束了，整个过程如下图：


![image-20230221232525491](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230221232525491.png)

>读写 Socket 的方式，好像读写文件一样，因为在内核中 Socket 也是以「文件」的形式存在的，也是有对应的文件描述符。

TCP 连接是由四元组唯一确认的，这个四元组就是：**本机IP, 本机端口, 对端IP, 对端端口**。服务器作为服务方，通常会在本地固定监听一个端口，等待客户端的连接。因此服务器的本地 IP 和端口是固定的，于是对于服务端 TCP 连接的四元组只有对端 IP 和端口是会变化的，所以**最大 TCP 连接数 = 客户端 IP 数 × 客户端端口数**。

对于 IPv4，客户端的 IP 数最多为 2 的 32 次方，客户端的端口数最多为 2 的 16 次方，也就是**服务端单机最大 TCP 连接数约为 2 的 48 次方**。但是服务器肯定承载不了那么大的连接数，主要会受两个方面的限制：

- **文件描述符**，Socket 实际上是一个文件，也就会对应一个文件描述符。在 Linux 下，单个进程打开的文件描述符数是有限制的，没有经过修改的值一般都是 1024，不过我们可以通过 ulimit 增大文件描述符的数目；
- **系统内存**，每个 TCP 连接在内核中都有对应的数据结构，意味着每个连接都是会占用一定内存的；

那如果服务器的内存只有 2 GB，网卡是千兆的，能支持并发 1 万请求吗？

并发 1 万请求，也就是经典的 C10K 问题 ，C 是 Client 单词首字母缩写，C10K 就是单机同时处理 1 万个请求的问题。

从硬件资源角度看，对于 2GB 内存千兆网卡的服务器，如果每个请求处理占用不到 200KB 的内存和 100Kbit 的网络带宽就可以满足并发 1 万个请求。

不过，要想真正实现 C10K 的服务器，要考虑的地方在于服务器的网络 I/O 模型，效率低的模型，会加重系统开销，从而会离 C10K 的目标越来越远。

## 多进程模型

TCP Socket 调用流程是最简单、最基本的，它基本只能一对一通信，因为使用的是同步阻塞的方式，当服务端在还没处理完一个客户端的网络 I/O 时，或者读写操作发生阻塞时，其他客户端是无法与服务端连接的。

可如果服务器只能服务一个客户，那这样就太浪费资源了，要改进这个网络 I/O 模型，以支持更多的客户端。基于最原始的阻塞网络 I/O，如果服务器要支持多个客户端，其中比较传统的方式，就是使用**多进程模型**，也就是为每个客户端分配一个进程来处理请求。

服务器的主进程负责监听客户的连接，一旦与客户端连接完成，`accept()` 函数就会返回一个「已连接 Socket」，这时就通过 `fork()` 函数创建一个子进程，实际上就把父进程所有相关的东西都**复制**一份，包括文件描述符、内存地址空间、程序计数器、执行的代码等。

这两个进程刚复制完的时候，几乎一模一样。不过，会根据**返回值**来区分是父进程还是子进程，如果返回值是 0，则是子进程；如果返回值是其他的整数，就是父进程。

正因为子进程会**复制父进程的文件描述符**，于是就可以直接使用「已连接 Socket」和客户端通信，子进程不需要关心「监听 Socket」，只需要关心「已连接 Socket」；父进程则相反，将客户服务交给子进程来处理，因此父进程不需要关心「已连接 Socket」，只需要关心「监听 Socket」。

下面这张图描述了从连接请求到连接建立，父进程创建生子进程为客户服务。

![image-20230221232842154](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230221232842154.png)

另外，当「子进程」退出时，实际上内核里还会保留该进程的一些信息，也是会占用内存的，如果不做好回收工作，就会变成**僵尸进程**，随着僵尸进程越多，会慢慢耗尽我们的系统资源。

有两种方式可以在子进程退出后回收资源，分别是调用 `wait()` 和 `waitpid()` 函数。这种用多个进程来应付多个客户端的方式，在应对 100 个客户端还是可行的，但是当客户端数量高达一万时，肯定扛不住的，因为每产生一个进程，必会占据一定的系统资源，而且进程间上下文切换不仅包含了虚拟内存、栈、全局变量等用户空间的资源，还包括了内核堆栈、寄存器等内核空间的资源，性能会大打折扣。

## 多线程模型

既然进程间上下文切换的“包袱”很重，那就搞个比较轻量级的模型来应对多用户的请求 —— **多线程模型**。

当服务器与客户端 TCP 完成连接后，通过 `pthread_create()` 函数创建线程，然后将「已连接 Socket」的文件描述符传递给线程函数，接着在线程里和客户端进行通信，从而达到并发处理的目的。

如果每来一个连接就创建一个线程，线程运行完后，还得操作系统还得销毁线程，虽说线程切换的上写文开销不大，但是如果频繁创建和销毁线程，系统开销也是不小的。

那么，可以使用**线程池**的方式来避免线程的频繁创建和销毁，所谓的线程池，就是提前创建若干个线程，这样当由新连接建立时，将这个已连接的 Socket 放入到一个队列里，然后线程池里的线程负责从队列中取出已连接 Socket 进程处理。

![image-20230221233238308](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230221233238308.png)


需要注意的是，这个队列是全局的，每个线程都会操作，为了避免多线程竞争，线程在操作这个队列前要加锁。

上面基于进程或者线程模型的，其实还是有问题的。新到来一个 TCP 连接，就需要分配一个进程或者线程，那么如果要达到 C10K，意味着要一台机器维护 1 万个连接，相当于要维护 1 万个进程/线程，操作系统就算死扛也是扛不住的。

## io_multiplexing

如果要让服务器服务多个客户端，那么最直接的方式就是为每一条连接创建线程。其实创建进程也是可以的，原理是一样的，进程和线程的区别在于线程比较轻量级些，线程的创建和线程间切换的成本要小些，为了描述简述，后面都以线程为例。


处理完业务逻辑后，随着连接关闭后线程也同样要销毁了，但是这样不停地创建和销毁线程，不仅会带来性能开销，也会造成浪费资源，而且如果要连接几万条连接，创建几万个线程去应对也是不现实的。

可以使用「资源复用」的方式，也就是不再为每个连接创建线程，而是创建一个「线程池」，将连接分配给线程，然后一个线程可以处理多个连接的业务。但这样又引来一个新的问题，线程怎样才能高效地处理多个连接的业务？一个线程通常要处理多个连接的业务，线程在处理某个连接的 `read` 操作时，如果遇到没有数据可读，就会发生阻塞，线程就没办法继续处理其他连接的业务。

> 当一个连接对应一个线程时，线程一般采用「read -> 业务处理 -> send」的处理流程，如果当前连接没有数据可读，那么线程会阻塞在 `read` 操作上（**socket 默认情况是阻塞 I/O**），不过这种阻塞方式并不影响其他线程。
>

要解决这一个问题，最简单的方式就是将 socket 改成非阻塞，然后线程不断地轮询调用 `read` 操作来判断是否有数据，这种方式虽然该能够解决阻塞的问题，但是解决的方式比较粗暴，因为轮询是要消耗 CPU 的，而且随着一个线程处理的连接越多，轮询的效率就会越低。

综上所述，为每个请求分配一个进程/线程的方式不合适，而且线程并不知道当前连接是否有数据可读，从而需要每次通过 `read` 去试探。

因此就需要I/O 多路复用，只使用一个进程来维护多个 Socket，并且**只有当连接上有数据的时候，线程才去发起读请求**。select/poll/epoll 是内核提供给用户态的多路复用系统调用，**进程可以通过一个系统调用函数从内核中获取多个事件**。

在获取事件时，先把要关心的连接（文件描述符）传给内核，再由内核检测：

- 如果没有事件发生，线程只需阻塞在这个系统调用，而无需像前面的线程池方案那样轮询调用 read 操作来判断是否有数据。
- 如果有事件发生，内核会返回产生了事件的连接，线程就会从阻塞状态返回，然后在用户态中再处理这些连接对应的业务即可。

------

I/O 复用使得程序能同时监听多个文件描述符，这对提高程序的性能至关重要。通常，网络程序在下列情况下需要使用I/O复用技术： 

- 客户端程序要同时处理多个socket。比如非阻塞connect技术。 
- 客户端程序要同时处理用户输入和网络连接。比如聊天室程序。 
- TCP服务器要同时处理监听socket和连接socket。这是I/O复用使用最多的场合。
- 服务器要同时处理TCP请求和UDP请求。比如回射服务器。 
- 服务器要同时监听多个端口，或者处理多种服务。比如xinetd服务器。 

需要指出的是，**I/O复用虽然能同时监听多个文件描述符，但它本身是阻塞的。并且当多个文件描述符同时就绪时，如果不采取额外的措施，程序就只能按顺序依次处理其中的每一个文件描述符，这使得服务器程序看起来像是串行工作的。**如果要实现并发，只能使用多进程或多线程等编程手段。



event loop 是 non-blocking 网络编程的核心，在现实生活中，non-blocking 几乎总是和 IOmultiplexing 一起使用，原因有两点： 

- 如果用轮询 (busy-pooling) 来检查某个 non-blocking IO 操作是否完成，会十分浪费 CPU 资源。 

- IO-multiplex 一般不能和 blocking IO 用在一起，因为 blocking IO 中 read()/write()/accept()/connect() 都有可能阻塞当前线程，这样线程就没办法处理其他 socket 上的事件了。 

所以，当提到 non-blocking 的时候，实际上指的是 non-blocking + IO-multiplexing，单用其中任何一个都没有办法很好的实现功能。

> epoll + fork 不如 epoll + pthread？
>
> 强大的 nginx 服务器采用了 epoll+fork 模型作为网络模块的架构设计，实现了简单好用的负载算法，使各个 fork 网络进程不会忙的越忙、闲的越闲，并且通过引入一把乐观锁解决了该模型导致的服务器惊群现象，功能十分强大。

### select

select 系统调用的用途是：在一段指定时间内，监听用户感兴趣的文件描述符上的可读、可写和异常等事件。原型如下：

```c
#include<sys/select.h>
int select(int nfds, fd_set* readfds, fd_set* writefds, fd_set* exceptfds, struct timeval* timeout);
```

**nfds参数指定被监听的文件描述符的总数。**它通常被设置为select监听的所有文件描述符中的最大值加1，因为文件描述符是从0开始计数的。

**readfds、writefds和exceptfds参数分别指向可读、可写和异常等事件对应的文件描述符集合。应用程序调用select函数时，通过这3个参数传入自己感兴趣的文件描述符。select调用返回时，内核将修改它们来通知应用程序哪些文件描述符已经就绪。**

这3个参数是fd_set结构指针类型。fd_set结构体的定义如下：

```c
#include<typesizes.h>
#include<sys/select.h>

#define __FD_SETSIZE 1024
#define FD_SETSIZE __FD_SETSIZE

typedef long int __fd_mask;

#undef __NFDBITS
#define __NFDBITS (8 * (int)sizeof(__fd_mask))

typedef struct
{
    #ifdef __USE_XOPEN
    	__fd_mask fds_bits[__FD_SETSIZE / __NFDBITS];
    	#define __FDS_BITS(set) ((set)->fds_bits)]
    #else
    	__fd_mask __fds_bits[__FD_SETSIZE / __NFDBITS];
    	#define __FDS_BITS(set) ((set)->__fds_bits)
    #endif
} fd_set;
```

由以上定义可见，fd_set结构体仅包含一个整型数组，该数组的每个元素的每一位标记一个文件描述符。**fd_set能容纳的文件描述符数量由FD_SETSIZE指定，这就限制了select能同时处理的文件描述符的总量。**

由于位操作过于烦琐，应该使用下面的一系列宏来访问fd_set结构体中的位：

```c
#include<sys/select.h>
FD_ZERO(fd_set* fdset); /*清除fdset的所有位*/
FD_SET(int fd, fd_set* fdset); /*设置fdset的位fd*/
FD_CLR(int fd, fd_set* fdset); /*清除fdset的位fd*/
int FD_ISSET(int fd, fd_set* fdset); /*测试fdset的位fd是否被设置*/
```

**timeout参数用来设置select函数的超时时间。它是一个timeval结构类型的指针，采用指针参数是因为内核将修改它以告诉应用程序select等待了多久。**不过不能完全信任select调用返回后的timeout值，比如调用失败时timeout值是不确定的。timeval结构体的定义如下：

```c
struct timeval
{
    long tv_sec;/*秒数*/
    long tv_usec;/*微秒数*/
};
```

由以上定义可见，select提供了一个微秒级的定时方式。如果给timeout变量的tv_sec成员和tv_usec成员都传递0，则select将立即返回。如果给timeout传递NULL，则select将一直阻塞，直到某个文件描述符就绪。 

**select成功时返回就绪（可读、可写和异常）文件描述符的总数。**如果在超时时间内没有任何文件描述符就绪，select将返回0。select失败时返回-1并设置errno。如果在select等待期间，程序接收到信号，则select立即返回-1，并设置errno为EINTR。

哪些情况下文件描述符可以被认为是可读、可写或者出现异常，对于select的使用非常关键。

在网络编程中，下列情况下socket可读： 

- socket内核接收缓存区中的字节数大于或等于其低水位标记SO_RCVLOWAT。此时可以无阻塞地读该socket，并且读操作返回的字节数大于0。 
- socket通信的对方关闭连接。此时对该socket的读操作将返回0。 
- 监听socket上有新的连接请求。 
- socket上有未处理的错误。此时可以使用getsockopt来读取和清除该错误。

下列情况下socket可写： 

- socket内核发送缓存区中的可用字节数大于或等于其低水位标记SO_SNDLOWAT。此时可以无阻塞地写该socket，并且写操作返回的字节数大于0。 
- socket的写操作被关闭。对写操作被关闭的socket执行写操作将触发一个SIGPIPE信号。
- socket使用非阻塞connect连接成功或者失败（超时）之后。
- socket上有未处理的错误。此时可以使用getsockopt来读取和清除该错误。 

网络程序中，select能处理的异常情况只有一种：socket上接收到带外数据。

### poll

**poll系统调用和select类似，也是在指定时间内轮询一定数量的文件描述符，以测试其中是否有就绪者。**poll的原型如下：

```c
#include<poll.h>
int poll(struct pollfd* fds, nfds_t nfds, int timeout);
```

**fds参数是一个pollfd结构类型的数组，它指定所有感兴趣的文件描述符上发生的可读、可写和异常等事件**。pollfd结构体的定义如下：

```c
struct pollfd
{
    int fd;/*文件描述符*/
    short events;/*注册的事件*/
    short revents;/*实际发生的事件，由内核填充*/
};
```

其中，fd成员指定文件描述符；events成员告诉poll监听fd上的哪些事件，它是一系列事件的按位或；revents成员则由内核修改，以通知应用程序fd上实际发生了哪些事件。poll支持的事件类型如表9-1所示。

![image-20230326001821336](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326001821336.png)

通常，应用程序需要根据recv调用的返回值来区分socket上接收到的是有效数据还是对方关闭连接的请求，并做相应的处理。不过，自Linux内核2.6.17开始，GNU为poll系统调用增加了一个POLLRDHUP事件，它在socket上接收到对方关闭连接的请求之后触发。这为区分上述两种情况提供了一种更简单的方式。但使用POLLRDHUP事件时，需要在代码最开始处定义_GNU_SOURCE。

nfds参数指定被监听事件集合fds的大小。其类型nfds_t的定义如下：

```c
typedef unsigned long int nfds_t;
```

timeout参数指定poll的超时值，单位是毫秒。当timeout为-1时，poll调用将永远阻塞，直到某个事件发生；当timeout为0时，poll调用将立即返回。 

poll系统调用的返回值的含义与select相同。

### epoll
epoll是Linux特有的I/O复用函数。它在实现和使用上与select、poll有很大差异。首先，epoll使用一组函数来完成任务，而不是单个函数。其次，epoll把用户关心的文件描述符上的事件放在内核里的一个事件表中，从而无须像select和poll那样每次调用都要重复传入文件描述符集或事件集。但epoll需要使用一个额外的文件描述符（句柄id），来唯一标识内核中的这个事件表。
epoll底层实现中有两个关键的数据结构，一个是eventpoll另一个是epitem，其中eventpoll中有两个成员变量分别是rbr和rdlist，前者指向一颗红黑树的根，后者指向双向链表的头。
而epitem则是红黑树节点和双向链表节点的综合体，也就是说epitem即可作为树的节点，又可以作为链表的节点，并且epitem中包含着用户注册的事件。
当用户调用epoll_create()时，会创建eventpoll对象（包含一个红黑树和一个双链表）；
而用户调用epoll_ctl(ADD)时，会在红黑树上增加节点（epitem对象）；
接下来，操作系统会默默地在通过epoll_event_callback()来管理eventpoll对象。当有事件被触发时，操作系统则会调用epoll_event_callback函数，将含有该事件的epitem添加到双向链表中。

当用户需要管理连接时，只需通过epoll_wait()从eventpoll对象中的双链表下"摘取"epitem并取出其包含的事件即可。

#### epitem

epitem是中包含了两个主要的成员变量，分别是rbn和rdlink，前者是红黑树的节点，而后者是双链表的节点，也就是说一个epitem对象即可作为红黑树中的一个节点又可作为双链表中的一个节点。并且每个epitem中存放着一个event，对event的查询也就转换成了对epitem的查询。

![image-20230329231232294](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230329231232294.png)

```c
struct epitem {
	RB_ENTRY(epitem) rbn;
	/*  RB_ENTRY(epitem) rbn等价于
	struct {											
		struct type *rbe_left;		//指向左子树
		struct type *rbe_right;		//指向右子树
		struct type *rbe_parent;	//指向父节点
		int rbe_color;			    //该节点的颜色
	} rbn
	*/
 
	LIST_ENTRY(epitem) rdlink;
	/* LIST_ENTRY(epitem) rdlink等价于
	struct {									
		struct type *le_next;	//指向下个元素
		struct type **le_prev;	//前一个元素的地址
	}*/
 
	int rdy; //判断该节点是否同时存在与红黑树和双向链表中
	
	int sockfd; //socket句柄
	struct epoll_event event;  //存放用户填充的事件
};
```

#### epoll_event

event参数指定事件，它是epoll_event结构指针类型。epoll_event的定义如下：

```c
struct epoll_event
{
    __uint32_t events;/*epoll事件*/
    epoll_data_t data;/*用户数据*/
};
```

其中**events成员描述事件类型。**epoll支持的事件类型和poll基本相同。表示epoll事件类型的宏是在poll对应的宏前加上“E”，比如epoll的数据可读事件是EPOLLIN。但**epoll有两个额外的事件类型——EPOLLET和EPOLLONESHOT。**data成员用于存储用户数据，其类型epoll_data_t的定义如下：

```c
typedef union epoll_data
{
    void* ptr; // 文件描述符 fd 携带的数据
    int fd;
    uint32_t u32;
    uint64_t u64;
} epoll_data_t;
```

epoll_data_t是一个联合体，其4个成员中使用最多的是**fd，它指定事件所从属的目标文件描述符。ptr成员可用来指定与fd相关的用户数据。**

但由于epoll_data_t是一个联合体，不能同时使用其ptr成员和fd成员，因此，如果要将文件描述符和用户数据关联起来，以实现快速的数据访问，只能使用其他手段，比如放弃使用epoll_data_t的fd成员，而在ptr指向的用户数据中包含fd。

#### eventpoll

eventpoll中包含了两个主要的成员变量，分别是rbr和rdlist，前者指向红黑树的根节点，后者指向双链表的头结点。即一个eventpoll对象对应二个epitem的容器。对epitem的检索，将发生在这两个容器上（红黑树和双链表）。

![image-20230329231305178](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230329231305178.png)

```c
struct eventpoll {
	/*
	struct ep_rb_tree {
		struct epitem *rbh_root; 			
	}
	*/
	ep_rb_tree rbr;      //rbr指向红黑树的根节点
	
	int rbcnt; //红黑树中节点的数量（也就是添加了多少个TCP连接事件）
	
	LIST_HEAD( ,epitem) rdlist;    //rdlist指向双向链表的头节点；
	/*	这个LIST_HEAD等价于 
		struct {
			struct epitem *lh_first;
		}rdlist;
	*/
	
	int rdnum; //双向链表中节点的数量（也就是有多少个TCP连接来事件了）
 
	// ...略...
};
```

#### epoll_create()

**该函数返回的文件描述符将用作其他所有epoll系统调用的第一个参数，以指定要访问的内核事件表。**

1. 创建eventpoll对象
2. 让eventpoll中的rbr指向空
3. 让eventpoll中的rdlist指向空
4. 在并发环境下进行互斥
5. 保存eventpoll对象
6. 返回eventpoll对象的句柄(id)

```c
#include<sys/epoll.h>
//创建epoll对象，包含一颗空红黑树和一个空双向链表
int epoll_create(int size) {
	//与很多内核版本一样，size参数没有作用，只要保证大于0即可
	if (size <= 0) return -1;
	
	nty_tcp_manager *tcp = nty_get_tcp_manager(); //获取tcp对象
	if (!tcp) return -1;
	
	struct _nty_socket *epsocket = nty_socket_allocate(NTY_TCP_SOCK_EPOLL);
	if (epsocket == NULL) {
		nty_trace_epoll("malloc failed\n");
		return -1;
	}
 
	// 1° 开辟了一块内存用于填充eventpoll对象
	struct eventpoll *ep = (struct eventpoll*)calloc(1, sizeof(struct eventpoll));
	if (!ep) {
		nty_free_socket(epsocket->id, 0);
		return -1;
	}
 
	ep->rbcnt = 0;
 
	// 2° 让红黑树根指向空
	RB_INIT(&ep->rbr);       //等价于ep->rbr.rbh_root = NULL;
 
	// 3° 让双向链表的头指向空
	LIST_INIT(&ep->rdlist);  //等价于ep->rdlist.lh_first = NULL;
 
	// 4° 并发环境下进行互斥
	// ...该部分代码与主线逻辑无关，可自行查看...
 
	//5° 保存epoll对象
	tcp->ep = (void*)ep;
	epsocket->ep = (void*)ep;
 
	return epsocket->id;
}
```

#### epoll_ctl()

epoll_ctl 用来操作epoll的内核事件表，成功时返回0，失败则返回-1并设置errno。

sockid 参数是要操作的文件描述符，op 参数则指定操作类型。操作类型有如下3种：

- EPOLL_CTL_ADD，将 epitem 对象插入红黑树中，往事件表中注册 sockid 上的事件。 
- EPOLL_CTL_MOD，更新红黑树中的 epitem 对象，修改 sockid 上的注册事件。 
- EPOLL_CTL_DEL，移除红黑树中的 epitem 对象，删除 sockid 上的注册事件。

```c
//往红黑树中加每个tcp连接以及相关的事件
int epoll_ctl(int epid, int op, int sockid, struct epoll_event *event) {

    nty_tcp_manager *tcp = nty_get_tcp_manager();
    if (!tcp) return -1;

    nty_trace_epoll(" epoll_ctl --> 1111111:%d, sockid:%d\n", epid, sockid);
    struct _nty_socket *epsocket = tcp->fdtable->sockfds[epid];

    if (epsocket->socktype == NTY_TCP_SOCK_UNUSED) {
        errno = -EBADF;
        return -1;
    }

    if (epsocket->socktype != NTY_TCP_SOCK_EPOLL) {
        errno = -EINVAL;
        return -1;
    }

    nty_trace_epoll(" epoll_ctl --> eventpoll\n");

    struct eventpoll *ep = (struct eventpoll*)epsocket->ep;
    if (!ep || (!event && op != EPOLL_CTL_DEL)) {
        errno = -EINVAL;
        return -1;
    }

    if (op == EPOLL_CTL_ADD) {
        //添加sockfd上关联的事件
        pthread_mutex_lock(&ep->mtx);

        struct epitem tmp;
        tmp.sockfd = sockid;
        struct epitem *epi = RB_FIND(_epoll_rb_socket, &ep->rbr, &tmp); //先在红黑树上找，根据key来找，也就是这个sockid，找的速度会非常快
        if (epi) {
            //原来有这个节点，不能再次插入
            nty_trace_epoll("rbtree is exist\n");
            pthread_mutex_unlock(&ep->mtx);
            return -1;
        }

        //只有红黑树上没有该节点【没有用过EPOLL_CTL_ADD的tcp连接才能走到这里】；

        //(1)生成了一个epitem对象，这个结构对象，其实就是红黑的一个节点；
        epi = (struct epitem*)calloc(1, sizeof(struct epitem));
        if (!epi) {
            pthread_mutex_unlock(&ep->mtx);
            errno = -ENOMEM;
            return -1;
        }

        //(2)把socket(TCP连接)保存到节点中；
        epi->sockfd = sockid;  //作为红黑树节点的key，保存在红黑树中

        //(3)我们要增加的事件也保存到节点中；
        memcpy(&epi->event, event, sizeof(struct epoll_event));

        //(4)把这个节点插入到红黑树中去
        epi = RB_INSERT(_epoll_rb_socket, &ep->rbr, epi); //实际上这个时候epi的rbn成员就会发挥作用，如果这个红黑树中有多个节点，那么RB_INSERT就会epi->rbi相应的值：可以参考图来理解
        assert(epi == NULL);
        ep->rbcnt ++;

        pthread_mutex_unlock(&ep->mtx);

    } else if (op == EPOLL_CTL_DEL) {
        pthread_mutex_lock(&ep->mtx);

        struct epitem tmp;
        tmp.sockfd = sockid;

        struct epitem *epi = RB_FIND(_epoll_rb_socket, &ep->rbr, &tmp);//先在红黑树上找，根据key来找，也就是这个sockid，找的速度会非常快
        if (!epi) {
            nty_trace_epoll("rbtree no exist\n");
            pthread_mutex_unlock(&ep->mtx);
            return -1;
        }

        //只有在红黑树上找到该节点【用过EPOLL_CTL_ADD的tcp连接才能走到这里】；

        //从红黑树上把这个节点移除
        epi = RB_REMOVE(_epoll_rb_socket, &ep->rbr, epi);
        if (!epi) {
            nty_trace_epoll("rbtree is no exist\n");
            pthread_mutex_unlock(&ep->mtx);
            return -1;
        }

        ep->rbcnt --;
        free(epi);

        pthread_mutex_unlock(&ep->mtx);

    } else if (op == EPOLL_CTL_MOD) {
        struct epitem tmp;
        tmp.sockfd = sockid;
        struct epitem *epi = RB_FIND(_epoll_rb_socket, &ep->rbr, &tmp); //先在红黑树上找，根据key来找，也就是这个sockid，找的速度会非常快
        if (epi) {
            //红黑树上有该节点，则修改对应的事件
            epi->event.events = event->events;
            epi->event.events |= EPOLLERR | EPOLLHUP;
        } else {
            errno = -ENOENT;
            return -1;
        }

    } else {
        nty_trace_epoll("op is no exist\n");
        assert(0);
    }

    return 0;
}
```

#### epoll_wait()

epoll系列系统调用的主要接口是epoll_wait函数。它在一段超时时间内等待一组文件描述符上的事件，成功时返回就绪的文件描述符的个数，失败时返回-1并设置errno。

timeout参数的含义与 poll 接口的timeout参数相同。maxevents参数指定最多监听多少个事件，它必须大于0。

先查看 eventpoll 对象的双链表中是否有节点：

- 如果有节点的话则取出节点中的就绪事件**填充到用户传入的第二个参数 events 所指向的内存中**。这个数组只用于输出 epoll_wait 检测到的就绪事件，而不像select和poll的数组参数那样既用于传入用户注册的事件，又用于输出内核检测到的就绪事件。
- 如果没有节点的话，则在 while 循环中等待一定时间，直到有事件被触发后操作系统会将 epitem 插入到双向链表上使得 rdnum>0 时(这个过程是由操作系统调用 epoll_event_callback 函数完成的)，程序才会跳出 while 循环，去双向链表中取数据。

其原型如下：

```c
#include<sys/epoll.h>
//到双向链表中去取相关的事件通知
int epoll_wait(int epid, struct epoll_event *events, int maxevents, int timeout) {
 
	nty_tcp_manager *tcp = nty_get_tcp_manager();
	if (!tcp) return -1;
 
	struct _nty_socket *epsocket = tcp->fdtable->sockfds[epid];
 
	struct eventpoll *ep = (struct eventpoll*)epsocket->ep;
	
    // ...此处主要是一些负责验证性工作的代码...
 
	//(1)当eventpoll对象的双向链表为空时，程序会在这个while中等待一定时间，
	//直到有事件被触发，操作系统将epitem插入到双向链表上使得rdnum>0时，程序才会跳出while循环
	while (ep->rdnum == 0 && timeout != 0) {
		// ...此处主要是一些与等待时间相关的代码...
	}
 
	pthread_spin_lock(&ep->lock);
 
	int cnt = 0;
 
	//(1)取得事件的数量
	//ep->rdnum：代表双向链表里边的节点数量（也就是有多少个TCP连接来事件了）
	//maxevents：此次调用最多可以收集到maxevents个已经就绪【已经准备好】的读写事件
	int num = (ep->rdnum > maxevents ? maxevents : ep->rdnum); //哪个数量少，就取得少的数字作为要取的事件数量
	int i = 0;
	
	while (num != 0 && !LIST_EMPTY(&ep->rdlist)) { //EPOLLET
 
		//(2)每次都从双向链表头取得 一个一个的节点
		struct epitem *epi = LIST_FIRST(&ep->rdlist);
 
		//(3)把这个节点从双向链表中删除【但这并不影响这个节点依旧在红黑树中】
		LIST_REMOVE(epi, rdlink); 
 
		//(4)这是个标记，标记这个节点【这个节点本身是已经在红黑树中】已经不在双向链表中；
		epi->rdy = 0;  //当这个节点被操作系统 加入到 双向链表中时，这个标记会设置为1。
 
		//(5)把事件标记信息拷贝出来；拷贝到提供的events参数中
		memcpy(&events[i++], &epi->event, sizeof(struct epoll_event));
		
		num --;
		cnt ++;       //拷贝 出来的 双向链表 中节点数目累加
		ep->rdnum --; //双向链表里边的节点数量减1
	}
	
	pthread_spin_unlock(&ep->lock);
 
	//(5)返回 实际 发生事件的 tcp连接的数目；
	return cnt; 
}
```

****

这就极大地提高了应用程序索引就绪文件描述符的效率。代码清单9-2体现了这个差别。

```c
/*如何索引poll返回的就绪文件描述符*/
int ret = poll(fds ,MAX_EVENT_NUMBER, -1);

/*必须遍历所有已注册文件描述符并找到其中的就绪者（可以利用ret来稍做优化）*/
for(int i = 0; i < MAX_EVENT_NUMBER; ++i)
{
    if(fds[i].revents & POLLIN) /*判断第i个文件描述符是否就绪*/
    {
        int sockfd = fds[i].fd; /*处理sockfd*/
    }
}

/*如何索引epoll返回的就绪文件描述符*/
int ret = epoll_wait(epollfd, events, MAX_EVENT_NUMBER, -1);

/*仅遍历就绪的ret个文件描述符*/
for(int i = 0; i < ret; i++)
{
    int sockfd = events[i].data.fd; /*sockfd肯定就绪，直接处理*/
}
```

#### epoll_event_callback()

通过跟踪epoll_event_callback在内核中被调用的位置。可知，当服务器在以下5种情况会调用epoll_event_callback：

1. 客户端connect()连入，服务器处于SYN_RCVD状态时
2. 三路握手完成，服务器处于ESTABLISHED状态时
3. 客户端close()断开连接，服务器处于FIN_WAIT_1和FIN_WAIT_2状态时
4. 客户端send/write()数据，服务器可读时
5. 服务器可以发送数据时

```c
//当发生客户端三路握手连入、可读、可写、客户端断开等情况时，操作系统会调用这个函数，用以往双向链表中增加一个节点【该节点同时 也在红黑树中】
int epoll_event_callback(struct eventpoll *ep, int sockid, uint32_t event) {
	struct epitem tmp;
	tmp.sockfd = sockid;
 
	//(1)根据给定的key【这个TCP连接的socket】从红黑树中找到这个节点
	struct epitem *epi = RB_FIND(_epoll_rb_socket, &ep->rbr, &tmp);
	if (!epi) {
		nty_trace_epoll("rbtree not exist\n");
		assert(0);
	}
 
	//(2)从红黑树中找到这个节点后，判断这个节点是否已经被连入到双向链表里【判断的是rdy标志】
	if (epi->rdy) {
		//这个节点已经在双向链表里，那无非是把新发生的事件标志增加到现有的事件标志中
		epi->event.events |= event;
		return 1;
	} 
 
	//走到这里，表示 双向链表中并没有这个节点，那要做的就是把这个节点连入到双向链表中
 
	nty_trace_epoll("epoll_event_callback --> %d\n", epi->sockfd);
	
	pthread_spin_lock(&ep->lock);
 
	//(3)标记这个节点已经被放入双向链表中，我们刚才研究epoll_wait()的时候，从双向链表中把这个节点取走的时候，这个标志被设置回了0
	epi->rdy = 1;  
 
	//(4)把这个节点链入到双向链表的表头位置
	LIST_INSERT_HEAD(&ep->rdlist, epi, rdlink);
 
	//(5)双向链表中的节点数量加1，刚才研究epoll_wait()的时候，从双向链表中把这个节点取走的时候，这个数量减了1
	ep->rdnum ++;
 
	pthread_spin_unlock(&ep->lock);
	pthread_mutex_lock(&ep->cdmtx);
	pthread_cond_signal(&ep->cond);
	pthread_mutex_unlock(&ep->cdmtx);
 
	return 0;
}
```

以上代码的逻辑也十分简单，就是将eventpoll所指向的红黑树的节点插入到双向链表中。

#### LT/ET

epoll对文件描述符的操作有两种模式：LT（Level Trigger，电平触发）模式和ET（Edge Trigger，边沿触发）模式：

- 对于采用 LT 工作模式的文件描述符，当 epoll_wait 检测到其上有事件发生并将此事件通知应用程序后，应用程序可以不立即处理该事件。当应用程序下一次调用 epoll_wait 时，epoll_wait 还会再次向应用程序通告此事件，直到该事件被处理。

	因此在这种情况下，当被监控的 Socket 上有可读事件发生时，**服务器端不断地从 epoll_wait 中苏醒，直到内核缓冲区数据被 read 函数读完才结束**，所以在收到通知后，没必要一次执行尽可能多的读写操作。

- 对于采用 ET 工作模式的文件描述符，当 epoll_wait 检测到其上有事件发生并将此事件通知应用程序后，应用程序必须立即处理该事件，因为后续的epoll_wait 调用将不再向应用程序通知这一事件。

	因此在这种情况下，当被监控的 Socket 描述符上有可读事件发生时，**服务器端只会从 epoll_wait 中苏醒一次**，若进程没有调用 read 函数从内核读取数据，就再没有机会读取了，因此程序要保证一次性将内核缓冲区的数据读取完；

如果使用边缘触发模式，I/O 事件发生时只会通知一次，而且不知道到底能读写多少数据，所以在收到通知后应尽可能地读写数据，以免错失读写的机会。因此，会**循环**从文件描述符读写数据，那么如果文件描述符是阻塞的，没有数据可读写时，进程会阻塞在读写函数那里，程序就没办法继续往下执行。所以，**边缘触发模式一般和非阻塞 I/O 搭配使用**（每个使用 ET 模式的文件描述符都应该是非阻塞的），程序会一直执行 I/O 操作，直到系统调用（如 `read` 和 `write`）返回错误，错误类型为 `EAGAIN` 或 `EWOULDBLOCK`。

一般来说，边缘触发的效率比水平触发的效率要高，因为边缘触发在很大程度上降低了同一个 epoll 事件被重复触发的次数，可以减少 epoll_wait 的系统调用次数，系统调用也是有一定的开销的的，毕竟也存在上下文的切换。

select/poll 只有水平触发模式，epoll 默认的触发模式是水平触发，但是可以根据应用场景设置为边缘触发模式。当往 epoll 内核事件表中注册一个文件描述符上的 EPOLLET 事件时，epoll 将以 ET 模式来操作该文件描述符。



即使使用 ET 模式，一个 socket 上的某个事件还是可能被触发多次。这在并发程序中就会引起一个问题。

> ET模式在很大程度上降低了**同一个epoll事件被重复触发的次数**，注意是同一个事件被重复触发的次数，因此不代表不通知新事件，因此一个socket上的某个事件还是可能被触发多次。

比如一个线程（或进程）在读取完某个socket上的数据后开始处理这些数据，而在数据的处理过程中该socket上又有新数据可读（EPOLLIN再次被触发）， 此时另外一个线程被唤醒来读取这些新的数据。于是就出现了两个线程同时操作一个socket的局面。而期望的是一个socket连接在任一时刻都只被一个线程处理。这一点可以使用epoll的EPOLLONESHOT事件实现。

**对于注册了EPOLLONESHOT事件的文件描述符，操作系统最多触发其上注册的一个可读、可写或者异常事件，且只触发一次，除非使用epoll_ctl函数重置该文件描述符上注册的EPOLLONESHOT事件。这样，当一个线程在处理某个socket时，其他线程是不可能有机会操作该socket的。**

但反过来思考，**注册了EPOLLONESHOT事件的socket一旦被某个线程处理完毕，该线程就应该立即重置这个socket上的EPOLLONESHOT事件，以确保这个socket下一次可读时，其EPOLLIN事件能被触发，进而让其他工作线程有机会继续处理这个socket。**

由此看来，尽管一个socket在不同时间可能被不同的线程处理，但同一时刻肯定只有一个线程在为它服务。这就保证了连接的完整性，从而避免了很多可能的竞态条件。

```c
int s = socket(AF_INET, SOCK_STREAM, 0);
bind(s, ...);
listen(s, ...)

int epfd = epoll_create(...);
epoll_ctl(epfd, ...); // 将所有需要监听的socket添加到epfd中

while(1) {
    int n = epoll_wait(...);
    for(接收到数据的socket) {
        //处理
    }
}
```

## difference

select、poll和epoll三组I/O复用系统调用，这3组系统调用都能同时监听多个文件描述符。它们将等待由timeout参数指定的超时时间，直到一个或者多个文件描述符上有事件发生时返回，返回值是就绪的文件描述符的数量。返回0表示没有事件发生。

而且这 3 组函数都通过某种结构体变量来告诉内核监听哪些文件描述符上的哪些事件，并使用该结构体类型的参数来获取内核处理的结果。 

### 参数类型

select 的参数类型 fd_set 使用固定长度的 BitsMap，表示文件描述符集合，并没有将文件描述符和事件绑定。

因此 select 需要提供 3 个这种类型的参数来分别传入和输出可读、可写及异常等事件。这一方面使得**select不能处理更多类型的事件**，另一方面由于内核对 fd_set 集合的在线修改，应用程序**下次调用 select 前不得不重置这 3 个 fd_set 集合**。



poll 的参数类型把文件描述符和事件都定义其中，任何事件都被统一处理，并且不再用 BitsMap 来存储所关注的文件描述符，取而代之用动态数组，以链表形式来组织。

此外，内核每次修改的是 pollfd 结构体的 revents 成员，而 events 成员保持不变，因此下次调用 poll 时应用程序**无须重置 pollfd 类型的事件集参数**。



epoll 在内核里使用**红黑树来跟踪进程所有待检测的文件描述字**，并提供独立的系统调用 `epoll_ctl()` 来控制往其中添加、删除、修改事件。红黑树增删查一般时间复杂度是 `O(logn)`，通过对这棵黑红树进行操作，这样就不需要像 select/poll 每次操作时都传入整个 socket 集合，只需要传入一个待检测的 socket，减少了内核和用户空间大量的数据拷贝和内存分配。

### 实现原理

select 实现多路复用的方式是，将已连接的 Socket 都放到一个**文件描述符集合**，然后调用 `select()` 函数将文件描述符集合**拷贝**到内核里，让内核来检查是否有网络事件产生，检查的方式很粗暴，就是通过**遍历**文件描述符集合的方式，当检查到有事件产生后，将此 Socket 标记为可读或可写，接着再把整个文件描述符集合**拷贝**回用户态里，然后用户态还需要再通过**遍历**的方法找到可读或可写的 Socket，然后再对其处理。

所以，对于 select 这种方式，需要进行 **2 次「遍历」文件描述符集合**，一次是在内核态里，一个次是在用户态里 ，而且还会发生 **2 次「拷贝」文件描述符集合**，先从用户空间传入内核空间，由内核修改后，再传出到用户空间中。

poll 和 select 都是使用「线性结构」存储进程关注的 Socket 集合，每次 select 和 poll 调用都返回整个用户注册的事件集合（其中包括就绪的和未就绪的），即每次调用都要扫描整个注册文件描述符集合，并将其中就绪的文件描述符返回给用户程序，因此它们检测就绪事件的算法的时间复杂度是 O(n)，而且也需要在用户态与内核态之间拷贝文件描述符集合，这种方式随着并发数上来，性能的损耗会呈指数级增长。

而 epoll 使用事件驱动的机制，内核里**维护了一个链表来记录就绪事件**，内核检测到就绪的文件描述符时，通过回调函数内核会将其加入到这个就绪事件列表中，内核最后在适当的时机将该就绪事件列表中的内容拷贝到用户空间。

`epoll_wait` 返回时，对于就绪的事件，epoll 没有使用共享内存。`epoll_wait` 实现的内核代码中调用了 `__put_user` 函数，这个函数就是将数据从内核拷贝到用户空间。

![image-20230329204643033](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230329204643033.png)

每次 epoll_wait 调用都直接从该内核事件表中取得用户注册的事件，而无须反复从用户空间读入这些事件。epoll_wait 系统调用的 events 参数仅用来返回就绪的事件，不需要像 select/poll 那样轮询扫描整个 socket 集合，因此应用程序索引就绪文件描述符的时间复杂度达到 O(1)。

但是，当活动连接比较多的时候，epoll_wait 的效率未必比 select 和 poll 高，因为此时回调函数被触发得过于频繁。所以 epoll_wait 适用于连接数量多，但活动连接较少的情况。

### 描述符上限

**poll 和 epoll_wait 分别用 nfds 和 maxevents 参数指定最多监听多少个文件描述符和事件。这两个数值都能达到系统允许打开的最大文件描述符数目，即65 535（cat/proc/sys/fs/file-max）。**而 select 允许监听的最大文件描述符数量通常有限制，在 Linux 系统中，由内核中的 FD_SETSIZE 限制，默认最大值为 `1024`，只能监听 0~1023 的文件描述符。

### 工作模式

select 和 poll 都只能工作在相对低效的 LT 模式，而 epoll 则可以工作在ET高效模式。并且 epoll 还支持 EPOLLONESHOT 事件。该事件能进一步减少可读、可写和异常等事件被触发的次数。



![image-20230326002116441](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230326002116441.png)







