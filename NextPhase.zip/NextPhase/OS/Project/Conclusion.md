# Conclusion
## RealMode/ProMode
编写MBR使BIOS识别，从MBR跳转到loader，在loader中进入保护模式。
在loader中，获取物理内存，初始化段描述符，打开A20，安装GDT、置位CR0，进入保护模式，然后从磁盘读取内核。
开启分页机制，然后安装GDT，创建内核映像，解析ELF文件格式，然后跳转到内核执行。
## Interrupt
## Thread
## Process
## Memory
## Syscall
