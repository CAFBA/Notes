# Interrupt
```assembly
[bits 32]
                                                ; -------------- 中断错误码 --------------
                                                ; ----------------------------------------------------------------------
                                                ; 有些中断进入前CPU会自动压入32位错误码，为保持栈中格式统一，这里不做操作
                                                ; 有些中断进入前CPU不会压入错误码，则手工压入一个32位的数，使栈结构相同
%define ERROR_CODE nop		                
%define ZERO push 0		                    

extern put_str			                        ; 调用put_str外部函数

extern idt_table		 					    ; 调用C中中断处理函数数组

                                                ; -------------- 中断处理程序入口 --------------
                                                ; ----------------------------------------------------------------------

section .data                                   ; 此处.data与宏中的.data合并为segment，每次调用宏产生的中断处理程序地址
                                                ; 都会作为数组intr_entry_table的元素紧凑地排在一起
global intr_entry_table 
intr_entry_table:                             
                                                ; 定义中断处理程序的宏
                                                ; 第一个参数是本宏实现的中断处理程序对应的中断向量号，将来要装载到中断描述符表中以该中断向量号为索引的中断门描述符位置
                                                ; 第二个参数是为保证栈中结构统一而对错误码的处理
    %macro VECTOR 2                             
    section .text                               ; 中断处理程序的代码段
    intr%1entry:		                        
        %2                                      ; 手工压入凑数32位数据

        push ds                                 ; 以下是保存上下文环境
        push es
        push fs
        push gs
        pushad

        mov al,0x20                             ; -------------- 中断结束命令EOI --------------
        out 0xa0,al                             ; 向主片发送OCW2，其中EOI位为1，告知结束中断
        out 0x20,al                             ; 向从片发送OCW2，其中EOI位为1，告知结束中断

                                                ; -------------- 执行中断 --------------
        push %1			                        ; 把中断向量号压入栈中作为idt_table数组中某元素所指向的中断处理程序的参数
        call [idt_table + %1*4]                 ; 调用idt_table中的C版本中断处理函数
        jmp intr_exit                           ; call之后回到此处，恢复程序的上下文

    section .data                               ; 该数据段存储此中断处理函数的地址，将来会合并从而保证连续
                                                ; 将这个标号所代表的地址存入intr_entry_table中
        dd    intr%1entry	                    ; 即存储各个中断处理程序的入口地址，形成intr_entry_table数组
    %endmacro

section .text
global intr_exit
intr_exit:
                                            ; 以下是恢复上下文环境，以寄存器入栈的相反顺序依次弹出栈恢复到寄存器
    add esp, 4			                    ; 跳过压入的中断处理程序的参数中断向量号
    popad                       
    pop gs                                  
    pop fs
    pop es
    pop ds
    add esp, 4			                    ; 对于会压入错误码的中断会抛弃错误码（这个错误码是执行中断处理函数之前CPU自动压入的）
                                            ; 对于不会压入错误码的中断，就会抛弃上面push的0 
    
    iretd				                    ; 从中断返回，32位下iret等同指令iretd
                                            
                                            ; 调用宏生成中断处理程序
VECTOR 0x00,ZERO                            
VECTOR 0x01,ZERO
VECTOR 0x02,ZERO
VECTOR 0x03,ZERO 
VECTOR 0x04,ZERO
VECTOR 0x05,ZERO
VECTOR 0x06,ZERO
VECTOR 0x07,ZERO 
VECTOR 0x08,ERROR_CODE
VECTOR 0x09,ZERO
VECTOR 0x0a,ERROR_CODE
VECTOR 0x0b,ERROR_CODE 
VECTOR 0x0c,ZERO
VECTOR 0x0d,ERROR_CODE
VECTOR 0x0e,ERROR_CODE
VECTOR 0x0f,ZERO 
VECTOR 0x10,ZERO
VECTOR 0x11,ERROR_CODE
VECTOR 0x12,ZERO
VECTOR 0x13,ZERO 
VECTOR 0x14,ZERO
VECTOR 0x15,ZERO
VECTOR 0x16,ZERO
VECTOR 0x17,ZERO 
VECTOR 0x18,ERROR_CODE
VECTOR 0x19,ZERO
VECTOR 0x1a,ERROR_CODE
VECTOR 0x1b,ERROR_CODE 
VECTOR 0x1c,ZERO
VECTOR 0x1d,ERROR_CODE
VECTOR 0x1e,ERROR_CODE
VECTOR 0x1f,ZERO 
VECTOR 0x20,ZERO    ; 时钟中断对应的入口
VECTOR 0x21,ZERO	; 键盘中断对应的入口
VECTOR 0x22,ZERO	; 级联用的
VECTOR 0x23,ZERO	; 串口2对应的入口
VECTOR 0x24,ZERO	; 串口1对应的入口
VECTOR 0x25,ZERO	; 并口2对应的入口
VECTOR 0x26,ZERO	; 软盘对应的入口
VECTOR 0x27,ZERO	; 并口1对应的入口
VECTOR 0x28,ZERO	; 实时时钟对应的入口
VECTOR 0x29,ZERO	; 重定向
VECTOR 0x2a,ZERO	; 保留
VECTOR 0x2b,ZERO	; 保留
VECTOR 0x2c,ZERO	; ps/2鼠标
VECTOR 0x2d,ZERO	; fpu浮点单元异常
VECTOR 0x2e,ZERO	; 硬盘
VECTOR 0x2f,ZERO	; 保留


;  -------------- 0x80号中断 --------------
[bits 32]

; 声明外部数据结构syscall_table，数组成员是系统调用中子功能对应的处理函数，这里用子功能号在此数组中索引子功能号对应的处理函数
extern syscall_table                        ; 系统调用函数入口地址表
section .text
global syscall_handler

syscall_handler:
                                            ; 保存上下文环境
   push 0			                        ; 压入中断错误码0, 使栈中格式统一
   push ds						            ; 保存任务的上下文
   push es
   push fs
   push gs
   pushad			                        ; PUSHAD指令压入32位寄存器，其入栈顺序是:EAX,ECX,EDX,EBX,ESP,EBP,ESI,EDI

   push 0x80			                    ; 此位置压入中断号0x80也是为了保持统一的栈格式

                                            ; 为系统调用子功能传入参数，按照C调用约定，最右边的参数先入栈
                                            ; 所以为了格式统一，直接按照最高参数数量压入3个参数
   push edx			                        ; 系统调用中第3个参数
   push ecx			                        ; 系统调用中第2个参数
   push ebx			                        ; 系统调用中第1个参数
	
                                            ; 寄存器eax中是系统调用子功能号，用它在数组syscall_table中索引对应的子功能处理函数。
                                            ; syscall_table中存储的是函数地址，每个成员是4字节大小，因此用eax*4做syscall_table的偏移量
   call [syscall_table + eax*4]	            ; 编译器会在栈中根据C函数声明匹配正确数量的参数
   add esp, 12			                    ; 调用之后，跨过上面的三个参数

   mov [esp + 8*4], eax			            ; 将call调用后的返回值写到了栈（此时是内核栈）中保存eax的那个内存空间。
   jmp intr_exit		                    ; intr_exit返回，恢复上下文
```
## 中断错误码
有的中断会产生错误码，用来指明中断是在哪个段上发生的，错误码会在进入中断后，处理器在栈中压入寄存器EIP之后压入。
在中断发生时，处理器要在目标栈中保存被中断进程的部分寄存器环境，这是处理器自动完成的，不需要手动写码。保存的寄存器名称及顺序是：
1. 如果发生了特权级转移，比如被中断的进程是3特权级，中断处理程序是0特权级，此时要把低特权级的栈段选择子ss及栈指针esp保存到栈中。
2. 压入标志寄存器eflags。
3. 压入返回地址cs和eip，先压入cs，后压入eip。
4. 如果此中断没有相应的错误码，至此，处理器把寄存器压栈的工作完成，栈中情况如图7-23A所示。如果此中断有错误码的话，处理器在压入eip之后会压入错误码，至此，处理器自动压栈工作全部完成，如图7-23B所示。
![image-20230619160104218](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230619160104218.png)
有的中断会压入错误码，而有的中断则不会压入，说明这两种不同的中断发生时，即使栈顶初始值一样，由于个别的中断压入了错误码，最终栈指针也是不一样的，至少差了存储错误码的那4个字节。**用iret指令从中断返回时栈顶必须是EIP的值，也就是栈顶必须如图7-23A中esp指向的位置。所以如果栈中有错误码，在iret指令执行前必须要把栈中的错误码跨过。**
问题的关键是栈顶指针不一致，即包含错误码的中断，其栈顶指针比不包含错误码的中断低了4字节。其实只要保证这两种情况的中断发生后，栈顶指针值是一样的就行了。只要保证在栈中EIP的位置之后还会再压入一个32位的数就成了，错误码是由处理器自动压入的，所以有错误码的中断就不管了。**如果没有错误码，手工压入一个32位的数，这样不管中断是否会压入错误码，栈顶指针都是一样的，即栈结构相同，在iret指令执行前再将栈顶的数据（错误码或手工压入的32位数）跨过就行了。**
而做这件事的前提是，得知道哪些中断会压入错误码才行。在表7-1中已经知道哪些中断会压入错误码，所以针对那些会压入错误码的中断，什么都不做，如果中断未压入错误码，就手工压入个数，这就是把ERROR_CODE和ZERO作为参数的目的。
由于ERROR_CODE的值为nop，所以对于那些参数为ERROR_CODE的宏调用，它们对应的都是包含错误码的中断。对于那些参数为ZERO的宏调用，它们对应的中断都不包括错误码，针对此种情况手工往栈中压个0占个位置，ZERO其值为push 0，这表示手工往栈中压入一个0，这样后面**在调用iret指令从中断返回之前，可以用通用的代码跨过栈顶的数据，即错误码或0，以使栈顶指向EIP，为iret准备好数据。**
由于EIP和错误码都是处理器自动压入栈的，错误码是在EIP压入栈之后压入的，所以手工压入的32位数也应该放在压入EIP之后操作，即它必须是中断处理程序中的第一个指令。所以，宏定义中的第一条指令是%2，它在预处理之后，会根据实际的参数展开为nop或push 0。
## kernel.S中断处理程序入口
在宏intr%1entry中嵌套了两个section，.text用作代码范围的起始定义，.data用作上个.text的结束，同时是此数据范围的起始定义。在.text的section中定义的是中断处理程序，intr%1entry是标号，作为中断处理程序的起始地址。由于中断向量0～19为处理器内部固定的异常类型，20～31是Intel保留的，标号不能重名，所以使用参数1作为中断向量号进行命名。
为引用所有中断处理程序的地址，在kernel.S中定义数组intr_entry_table，并且导出为全局符号。**为使此数组中的元素是每个中断处理程序的地址**，定义数据段section .data。由于32位下的地址是4字节，所以用伪指令dd来定义数组元素的宽度，元素值为intr%1entry，这样**每个宏调用都将在数组中产生新的地址元素**。
虽然数组名intr_entry_table定义在宏外，数组元素即中断程序地址所在的section和数组名并不属于同一个section的定义，但在此处对所有的数据section都使用相同属性.data，编译器会将属性相同的section合并到同一个大的segment中，所以编译之后，所有中断处理程序的地址都会作为数组intr_entry_table的元素紧凑地排在一起，保证数组元素地址是连续的。
由于**将来在设置8259A时设置会手动结束，所以需要在中断处理程序中手动向8259A发送中断结束标记**，否则8259A并不知道中断处理完成，它会一直等下去，从而不再接受新的中断。也就是说，为了让8259A接受新的中断，必须要让8259A知道当前中断处理程序已经执行完成。8259A的操作控制字OCW2，其中第5位是EOI位，此位为1，其余位全为0，因此向主片和从片中写入0x20，即写入EOI。
注意**必须放在call调用之前**，因为多线程调度的时候会触发时钟中断，调用时钟中断处理程序，这样引发线程切换后，无法通知中断处理器8259A结束处理中断，因此要提前通知。
> ICW1和OCW2、OCW3的写入端口是一致的，但各自有标记用以辨识，因此向这个端口写入后0x20后，ICW要保证一定的次序写入，因此排除ICW1，接下来根据各控制字中的第4～3标识位来判断是OCW2还是OCW3，从而正确写入。
## 执行中断
在C中建立目标中断处理程序数组idt_table，数组元素是C版本的中断处理函数32位地址，占用4字节。中断入口程序intrXXentry调用C版本中断处理函数的依据是每个中断的中断向量号。当中断发生时，汇编中的中断入口intrXXentry将以中断向量号作为idt_table的索引，在中断入口程序中，将中断向量号乘以4，再加上idt_table地址的值，便是对应的C语言版本的中断处理函数地址，从而调用相应的中断处理函数。
> 内存地址以 0x 开头的 16 进制数表示，对其加 1 相当于**增加一个与所指向数据类型大小相等的地址偏移量**。
![image-20230626204600785](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230626204600785.png)

伪中断并不是真正的中断，属于某种不希望发生的硬件中断。产生伪中断的原因很多，如中断线路上电气信号异常，或是中断请求设备本身有问题。在实际情况中，它经常由IRQ7和IRQ15产生，IRQ7是并口1，IRQ15是保留的。由于它们无法通过IMR寄存器屏蔽，所以在这里单独处理，直接通过return返回，无视它。
因为在此汇编文件中要调用C程序，一定会使当前寄存器环境破坏，所以要保存当前所使用的寄存器环境，即4个段寄存器ds、es、fs、gs和8个32位通用寄存器。所以在程序中先把ds、es、fs和gs这4个16位段寄存器压栈，虽然是16位，但在32位下段寄存器压栈有点特殊，入栈后要占用4字节（而位于其他寄存器和内存中的值若为16位，则入栈后只占2字节），然后再通过pushad指令压入8个通用寄存器，入栈顺序是EAX->ECX->EDX->EBX->ESP->EBP->ESI-> EDI，最先入栈的是EAX。此时栈中数据分布的情况，如图7-30所示：
![image-20230626204710067](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230626204710067.png)
目前先把向量号作为参数传进来，程序是否用不用参数都没关系，这不影响编译和运行，毕竟参数入栈是由控制的，只要记得将向量号出栈。
通过`call [idt_table + %1*4]`便调用了对应的C语言编写的中断处理程序。其中`[idt_table + %1*4]`是32位下的基址变址寻址，由于idt_table中的每个元素都是32位地址，故占用4字节大小，所以将向量号乘以4，再加上idt_table数组的起始地址，便得到了下标为中断向量号%1的数组元素地址，再对该地址通过中括号[]取值，便得到该数组元素中所指向C语言编写的中断处理程序，也就是在exception_init函数中注册过的general_intr_handler，将来某些外设需要重写中断处理程序（比如时钟、键盘、硬盘），所以这些中断对应的中断处理程序将不会是默认的general_intr_handler。
当恢复上下文后，栈指针指向栈中error_code的位置，当然若中断无错误码，此处是0，如图7-31所示，所以需要将其跳过，这样后面的iretd指令执行时，栈顶指针esp才能指向栈中eip，iretd才能在栈中弹出正确的值到各寄存器。跳过的方法同跳过参数中断号一样，就是通过add指令把esp加4。
![image-20230626204728536](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230626204728536.png)
## 0x80号中断描述符
为实现系统调用，需要在idt_desc_init中循环外单独调用make_idt_desc来安装0x80对应的中断描述符，同时修改最大的中断向量数IDT_DESC_CNT。
中断发生后，将通过中断向量号找到中断描述符，从而得到中断处理程序入口，再作为idt_table的索引找到对应的中断处理程序从而调用。
由于0x80号中断只作为系统调用的入口，子功能号决定着中断处理函数，不再存在intr_entry_table与ide_table的对应关系，因此系统调用相关的中断，有着另一种处理方式：
- 使用系统调用子功能表syscall_table代替idt_table，利用eax寄存器中的子功能号在该表中索引相应的处理函数，而不是中断向量号。
- 不通过register_handler注册，而是在syscall_init初始化时直接注册。
syscall_handler不管具体系统调用中的参数是几个，一律压入3个参数。子功能处理函数都有自己的原型声明，声明中包括参数个数及类型，编译时编译器会根据函数声明在栈中匹配出正确数量的参数，进入函数体后，根据C调用约定，栈顶的4字节（32位系统，下同）是函数的返回地址，往上（高地址的栈底方向）的4字节是第1个参数，再往上的4字节便是第2个参数，依此类推。
在函数体中，编译器生成的取参数指令是从栈顶往上（跨过栈顶的返回地址，向高地址方向）获取参数的，参数个数是通过函数声明事先确定好的，因此并不会获取到错误的参数，从而保证了多余的参数用不上，因此，对于参数少于3个的函数也不会出错。
根据二进制编程接口abi约定，寄存器eax用来存储返回值。经过call函数调用，如果有返回值的话，eax的值已经变成了返回值（如果没有返回值也没关系，编译器会保证函数返回后eax的值不变），此时要把返回值传给用户进程，但是从内核态退出时，要从内核栈中恢复寄存器上下文（之前保存的寄存器上下文中的eax值与当前eax值不同），这会将当前eax的返回值覆盖，因此**把寄存器eax的值回写到内核栈中用于保存eax的内存处，这样从内核返回时，popd指令也只是用该返回值重新覆盖一次eax寄存器，返回到用户态时，用户进程便获取到了系统调用函数的返回值**。
[esp+8\*4]是寄存器相对寻址，esp就是当前栈顶，8\*4就是相对栈顶，往栈中高地址方向的偏移量，其实把8\*4拆分成(1+7)\*4更好，其中的1是指上面的push 0x80所占的4字节，另外的7是指pushad指令会将eax最先压入，故要跨过7个4字节，总共是8个4字节，即[esp+8\*4]是对应栈中eax的地址。

```c
#define PIC_M_CTRL 0x20	       // 主片的控制端口是0x20
#define PIC_M_DATA 0x21	       // 主片的数据端口是0x21
#define PIC_S_CTRL 0xa0	       // 从片的控制端口是0xa0
#define PIC_S_DATA 0xa1	       // 从片的数据端口是0xa1

#define IDT_DESC_CNT 0x81      // 目前总共支持的中断数，最后一个支持的中断号0x80 + 1即0x81个中断，0x80是系统调用对应的中断向量

#define EFLAGS_IF   0x00000200 // 表示开中断时eflags寄存器中的IF的值为1
// pop到EFLAG_VAR所在内存中，该约束自然用表示内存的字母，但是内联汇编中没有专门表示约束内存的字母，所以只能用g
// g 代表可以是任意寄存器，内存或立即数
#define GET_EFLAGS(EFLAG_VAR) asm volatile("pushfl; popl %0" : "=g" (EFLAG_VAR))

// syscall_handler是系统调用对应的中断处理程序，将在kernel.S中定义
extern uint32_t syscall_handler(void); 

// 中断门描述符结构体
// 结构体中位置越偏下的成员，其地址越高
// 描述符都是8字节，即结构体大小
struct gate_desc {
   uint16_t    func_offset_low_word;
   uint16_t    selector;
   uint8_t     dcount;   // 此项为双字计数字段，是门描述符中的第4字节。此项固定值，不用考虑
   uint8_t     attribute;
   uint16_t    func_offset_high_word;
};
static struct gate_desc idt[IDT_DESC_CNT];                // 中断描述符表IDT，即中断门描述符数组

extern intr_handler intr_entry_table[IDT_DESC_CNT];	    // 引用定义在kernel.S中的中断处理函数入口数组

// intr_handler是用来修饰intr_entry_table的，而intr_entry_table中的元素都是普通地址
// 因此intr_handler是个空指针类型，仅仅用来表示地址

// 在kernel.S中定义的intrXXentry是中断处理程序的入口，最终调用的是ide_table中的处理程序
// 定义中断处理程序数组，数组中的元素即目标中断处理函数地址
// 先由函数exception_init初始化，其中的数组元素将由intrXXentry来调用，见kernel/kernel.S的call [idt_table + %1*4] 
intr_handler idt_table[IDT_DESC_CNT];  

char* intr_name[IDT_DESC_CNT];		                      // 存储中断/异常的名字，用于调试

static void make_idt_desc(struct gate_desc* p_gdesc, uint8_t attr, intr_handler function); // 静态函数声明，非必须

// 创建中断门描述符
static void make_idt_desc(struct gate_desc* p_gdesc, uint8_t attr, intr_handler function) { 
   p_gdesc->func_offset_low_word = (uint32_t)function & 0x0000FFFF;
   p_gdesc->selector = SELECTOR_K_CODE;         // 指向内核数据段的选择子，定义在global.h中
   p_gdesc->dcount = 0;
   p_gdesc->attribute = attr;
   p_gdesc->func_offset_high_word = ((uint32_t)function & 0xFFFF0000) >> 16;
}

// 初始化中断描述符表
// 通过调用make_idt_desc函数在中断描述符表中创建IDT_DESC_CNT个中断门描述符
static void idt_desc_init(void) {
   int i, lastindex = IDT_DESC_CNT - 1;
   for (i = 0; i < IDT_DESC_CNT; i++) {
      make_idt_desc(&idt[i], IDT_DESC_ATTR_DPL0, intr_entry_table[i]);  // 传入来自中断描述符表中的中断门描述符地址，即数组idt的某个数组元素指针
   }
   // 单独处理系统调用，系统调用对应的中断门DPL为3，中断处理程序为单独的syscall_handler 
   make_idt_desc(&idt[lastindex], IDT_DESC_ATTR_DPL3, syscall_handler);
   put_str("   idt_desc_init done\n");
}

// 初始化可编程中断控制器8259A
static void pic_init(void) {

   /* 初始化主片 */
   outb (PIC_M_CTRL, 0x11);   // ICW1: 边沿触发,级联8259，需要ICW4
   outb (PIC_M_DATA, 0x20);   // ICW2: 起始中断向量号为0x20，也就是IR[0-7] 为 0x20 ~ 0x27
   outb (PIC_M_DATA, 0x04);   // ICW3: IR2接从片
   outb (PIC_M_DATA, 0x01);   // ICW4: 8086模式，正常EOI

   /* 初始化从片 */
   outb (PIC_S_CTRL, 0x11);    // ICW1: 边沿触发，级联8259，需要ICW4.
   outb (PIC_S_DATA, 0x28);    // ICW2: 起始中断向量号为0x28，也就是IR[8-15] 为 0x28 ~ 0x2F
   outb (PIC_S_DATA, 0x02);    // ICW3: 设置从片连接到主片的IR2引脚
   outb (PIC_S_DATA, 0x01);    // ICW4: 8086模式，正常EOI
   
   /* 打开主片上IR0，也就是目前只接受时钟产生的中断 */
   // outb (PIC_M_DATA, 0xfe);
   // outb (PIC_S_DATA, 0xff);

   /* 测试键盘，只打开键盘中断，其它全部关闭 */
   // outb (PIC_M_DATA, 0xfd);      // 操作主片上的中断屏蔽寄存器，只打开键盘中断，即位1为0，其他位都为1，因此写入的值为0xfd
   // outb (PIC_S_DATA, 0xff);	   // 操作从片上的中断屏蔽寄存器，屏蔽了从片上的所有中断，所以值为0xff。

   // 同时打开时钟中断与键盘中断
   // 写入数值0xfc到主片的中断屏蔽寄存器，0xfc低2位为0，这两位对应的是时钟中断和键盘中断
   // 它们为0，表示不屏蔽中断，即打开这两个中断
   outb (PIC_M_DATA, 0xfc);
   outb (PIC_S_DATA, 0xff);

   put_str("   pic_init done\n");
}

// 通用的中断处理函数，相关中断若没有定义具体的中断处理函数时将调用，一般用在异常出现时的处理 
static void general_intr_handler(uint8_t vec_nr) {
   if (vec_nr == 0x27 || vec_nr == 0x2f) {	   // 0x2f是从片8259A上的最后一个IRQ引脚，保留
      return;		                              // IRQ7和IRQ15会产生伪中断(spurious interrupt)，无须处理
   }
   // 将光标置为0，从屏幕左上角清出一片打印异常信息的区域，方便阅读
   set_cursor(0);
   int cursor_pos = 0;
   while(cursor_pos < 320) {
      put_char(' ');
      cursor_pos++;
   }

   set_cursor(0);	 // 重置光标为屏幕左上角
   put_str("!!!!!!!      excetion message begin  !!!!!!!!\n");
   set_cursor(88);	// 从第2行第8个字符开始打印
   put_str(intr_name[vec_nr]);
   if (vec_nr == 14) {	  // 若为Pagefault,将缺失的地址打印出来并悬停
      int page_fault_vaddr = 0; 
      asm ("movl %%cr2, %0" : "=r" (page_fault_vaddr));	  // cr2是存放造成page_fault的地址
      put_str("\npage fault addr is ");put_int(page_fault_vaddr); 
   }
   put_str("\n!!!!!!!      excetion message end    !!!!!!!!\n");
  // 能进入中断处理程序就表示已经处在关中断情况下
  // 不会出现调度进程的情况。故下面的死循环不会再被中断
   while(1);
}

// 完成一般中断处理函数及异常名称注册
static void exception_init(void) {
   int i;
   // 默认为general_intr_handler，以后会由register_handler来注册具体处理函数。
   for (i = 0; i < IDT_DESC_CNT; i++) {
      idt_table[i] = general_intr_handler;		
      // 由于intr_name是用来记录IDT_DESC_CNT个的名称，但异常只有20个，所以先一律赋值为unknown
      // 保证intr_name[20～32]不指空，接下来在循环体外单独为0～19这20个异常赋予正确的异常名称
      intr_name[i] = "unknown";				    
   }
   // 初始化intr_name数组中的每个元素，此数组用来记录异常的名字
   // 将来在异常出现时，可以根据中断向量号在intr_name数组中检索到相应的异常名
   intr_name[0] = "#DE Divide Error";
   intr_name[1] = "#DB Debug Exception";
   intr_name[2] = "NMI Interrupt";
   intr_name[3] = "#BP Breakpoint Exception";
   intr_name[4] = "#OF Overflow Exception";
   intr_name[5] = "#BR BOUND Range Exceeded Exception";
   intr_name[6] = "#UD Invalid Opcode Exception";
   intr_name[7] = "#NM Device Not Available Exception";
   intr_name[8] = "#DF Double Fault Exception";
   intr_name[9] = "Coprocessor Segment Overrun";
   intr_name[10] = "#TS Invalid TSS Exception";
   intr_name[11] = "#NP Segment Not Present";
   intr_name[12] = "#SS Stack Fault Exception";
   intr_name[13] = "#GP General Protection Exception";
   intr_name[14] = "#PF Page-Fault Exception";
   // intr_name[15] 第15项是intel保留项，未使用
   intr_name[16] = "#MF x87 FPU Floating-Point Error";
   intr_name[17] = "#AC Alignment Check Exception";
   intr_name[18] = "#MC Machine-Check Exception";
   intr_name[19] = "#XF SIMD Floating-Point Exception";
}


// 在中断处理程序数组第vector_no个元素中注册安装中断处理程序function
void register_handler(uint8_t vector_no, intr_handler function) {
   // idt_table数组中的函数是在进入中断后根据中断向量号调用的，即call [idt_table + %1*4]
   idt_table[vector_no] = function; 
}

/* 获取当前中断状态 */
enum intr_status intr_get_status() {
   uint32_t eflags = 0; 
   GET_EFLAGS(eflags);
   return (EFLAGS_IF & eflags) ? INTR_ON : INTR_OFF;
}

/* 开中断并返回开中断前的状态*/
enum intr_status intr_enable() {
   enum intr_status old_status;
   if (INTR_ON == intr_get_status()) {
      old_status = INTR_ON;
      return old_status;
   } else {
      old_status = INTR_OFF;
      asm volatile("sti");	                  // 开中断，sti指令将IF位置1
      return old_status;
   }
}

/* 关中断,并且返回关中断前的状态 */
enum intr_status intr_disable() {     
   enum intr_status old_status;
   if (INTR_ON == intr_get_status()) {
      old_status = INTR_ON;
      asm volatile("cli" : : : "memory");    // 关中断，cli指令将IF位置0
      return old_status;
   } else {
      old_status = INTR_OFF;
      return old_status;
   }
}

/* 将中断状态设置为status */
enum intr_status intr_set_status(enum intr_status status) {
   return status & INTR_ON ? intr_enable() : intr_disable();
}

// 完成有关中断的所有初始化工作
void idt_init() {
   put_str("idt_init start\n");
   idt_desc_init();	         // 初始化中断描述符表
   exception_init();	         // 异常名初始化并注册通常的中断处理函数
   pic_init();		            // 初始化8259A

   /* 加载idt */
   uint64_t idt_operand = ((sizeof(idt) - 1) | ((uint64_t)(uint32_t)idt << 16));
   asm volatile("lidt %0" : : "m" (idt_operand));
   put_str("idt_init done\n");
}
```
## idt_desc_init初始化中断描述符表IDT
make_idt_desc创建中断门描述符，接收以下三个参数
- 中断描述符表IDT的数组成员指针
- 中断描述符内的属性IDT_DESC_ATTR_DPL0，定义在global.h中
- 中断描述符内对应的中断处理函数，在kernel.S中定义的中断描述符地址数组intr_entry_table中的元素值，即中断处理程序的地址
原理是将后两个参数写入第一个参数所指向的中断门描述符中，也就是用后面的两个参数构建第一个参数指向的中断门描述符。
idt_desc_init初始化中断描述符表，通过调用make_idt_desc函数在中断描述符表中创建IDT_DESC_CNT个中断门描述符。
## pic_init设置8259A
8259A的编程就是写入ICW和OCW，其中ICW是初始化控制字，共4个，ICW1～ICW4，用于初始化8259A的各个功能。OCW是操作控制字，用于同初始化后的8259A进行操作命令交互。所以，对8259A的操作是在其初始化之后，对于8259A的初始化必须最先完成。
> PIC就是可编程中断控制器Programmable Interrupt Controller的简称，而8259A也是PIC的一种。

因为硬盘是接在了从片的引脚上，可参见图7-12，将来实现文件系统是离不开硬盘的，所以这里使用的8259A要采用主、从片级联的方式。在x86系统中，对于初始化级联8259A，无论是主片，还是从片，4个ICW都必须按顺序依次写入ICW1、ICW2、ICW3、ICW4：
- ICW1和OCW2、OCW3是用偶地址端口0x20（主片）或0xA0（从片）写入
- ICW2～ICW4和OCW1是用奇地址端口0x21（主片）或0xA1（从片）写入
### 主片
先设置主片，ICW1是往主、从片的偶数地址写入的，即主片端口地址是0x20，从片端口地址是0xA0。
通过outb函数往端口PIC_M_CTRL（也就是主片的控制端口0x20）写入ICW1，其值为0x11。对照图7-14 ICW1格式，第0位是IC4位，表示是否需要指定ICW4，需要在ICW4中设置EOI为手动方式，所以需要ICW4。由于要级联从片，所以将ICW1中的第1位SNGL置为0，表示级联。设置第3位的LTIM为0，表示边沿触发。ICW1中第4位是固定为1。2号位为0，用于是设定8085的调用时间间隔，x86不需要设置。
之后往主片中写入ICW2，ICW2～ICW4是写入主、从片的奇地址端口，即主片的0x21和从片的0xA1。
ICW2专用于设置8259A的起始中断向量号，由于中断向量号0～31已经被占用或保留，从32起才可用，所以往主片PIC_M_DATA端口（主片的数据端口0x21）写入的ICW2值为0x20，即32。这说明主片的起始中断向量号为0x20，即IR0对应的中断向量号为0x20，这是的时钟所接入的引脚。IR1～IR7对应的中断向量号依次往下排。
> 如第一个主片，八个接口就是，IRQ0 = 32 + 0; IRQ1 = 32 + 1… 第一个从片就是IRQ0 = 32 + 8 + 0, IRQ1 = 32 + 8 + 1

往主片中写入ICW3：ICW3专用于设置主从级联时用到的引脚。此处用IR2引脚作为主片级联从片的接口，在ICW3中将其置为1，故ICW3值为0x04，写入主片奇地址端口0x21，即PIC_M_DATA。
往主片中写入ICW4：8259A的很多工作模式都在ICW4中设置，可以参见图7-18 ICW4的格式：
- 0号位为1，表示x86处理器；
- 1号位为0，EOI的工作模式位，表示手动向8259A发送中断（中断处理程序中有通知主从片结束中断的步骤）；
- 2号位为0，因为3号位设定为0（非缓冲模式工作），所以此位无用；在非缓冲模式下，8259A的数据总线直接连接到系统总线上，而不是通过缓冲器。当中断发生时，8259A会直接向CPU发送中断信号，而不经过任何缓冲或处理。这种模式可能会使系统在处理大量的中断请求时表现得不那么稳定，因为它对系统总线的要求更高。然而，非缓冲模式的系统设计会更简单一些，因为不需要缓冲器的附加硬件；
- 4号位为0，表示全嵌套模式，也就是优先处理较低中断请求线编号的中断请求（IRQ0最优先），特殊全嵌套模式是可以允许在中断处理过程中，如果来了一个优先级更高的中断请求，就暂停当前正在执行的中断，转而去执行那个优先级更高的中断请求；
所以ICW4的值为0x01。写入主片奇地址端口0x21，即PIC_M_DATA。
### 从片
向从片发送ICW1，其意义和主片的ICW1一致，只不过是往从片的偶数地址端口0xA0发送，这是从片的控制端口，即PIC_S_CTRL。
向从片发送ICW2，这是设置从片的起始中断向量号。由于主片的中断向量号是0x20～0x27，故从片的中断向量号顺着它延续下来，从0x28开始，即ICW2值为0x28，也就是IR[8-15] 为0x28 ～ 0x2F。ICW2通过outb函数向从片的奇数地址端口0xA1写入，即PIC_S_DATA。
向从片发送ICW3，ICW3专用于设置级联的引脚，这里设置从片连接在主片的哪个IRQ引脚上。刚才在设置主片的时候是设置用IR2引脚来级联从片，所以此处要告诉从片连接到主片的IR2上，即ICW2值为0x02，通过outb函数向从片的奇数地址端口0xA1写入，即PIC_S_DATA。
向从片发送ICW4，同主片的ICW4一样。
至此主、从片都已经初始化完成了。
### 屏蔽某个中断信号
屏蔽某个外部设备中断信号可以通过设置位于8259A中的中断屏蔽寄存器IMR来实现，只要将相应位置1就达到了屏蔽相应中断源信号的目的，但标志寄存器eflags中的IF位对所有外部中断有效，不能通过它来屏蔽某个外设的中断。所以，设置中断屏蔽寄存器IMR，只放行主片上IR0的时钟中断，屏蔽其他外部设备的中断。
这样的命令操作不属于初始化，所以此时再向8259A发送的任何数据都称为操作控制字，即OCW。往IMR寄存器中发送的命令控制字称为OCW1，主片上的OCW1为0xfe，即第0位为0，表示不屏蔽IR0的时钟中断。其他位都是1，表示都屏蔽。从片上的所有外设都屏蔽，所以发送的OCW1值为0xff。OCW1是写入主、从片的奇地址端口，即主片的0x21端口（PIC_M_DATA）和从片的0xA1端口（PIC_S_DATA）。
## 通用中断处理程序general_intr_handler
general_intr_handler函数作为默认的中断处理函数，即某个中断源没有中断处理程序时才用它来代替。
set_cursor接受一个参数，就是光标值（光标值范围是0～1999）。它的功能就是设置光标的值，其函数实现就是文件print.S中函数put_char的.set_cursor部分。
为什么需要这个函数呢？有时候屏幕上的内容太多了，打印的提示信息不利用阅读。甚至有时候的异常是由光标错误值引发的，因此必须在异常中将光标位置纠正，否则在通过put_str输出报错信息的时候，错误的光标值将再次导致异常，可能会造成异常的死循环，因此更谈不上输出异常信息了，所以在异常处理程序中将其置为正确的值。
程序运行时最后输出的有用信息一般都在屏幕最下方，最好不占用下方的屏幕，而是将异常信息输出在屏幕左上角，因此先调用“set_cursor(0)”将光标置为0。
为方便阅读，在输出异常信息之前先通过while循环清空4行内容，也就是填入了4行空格，一行字符数是80个，因此共320个空格输出的循环。接着再次调用“set_cursor(0)”将光标置为0，也就是屏幕左上角，这样异常信息将在刚刚清空的地方输出。
此外还加进了Pagefault的处理。Pagefault就是通常所说的缺页异常，它表示虚拟地址对应的物理地址不存在，也就是虚拟地址尚未在页表中分配物理页，这样会导致Pagefault异常。**导致Pagefault的虚拟地址会被存放到控制寄存器CR2中，加入的内联汇编代码就是让Pagefault发生时，将寄存器cr2中的值转储到整型变量page_fault_vaddr中，并通过put_str函数打印出来**。因此，如果程序运行过程中出现异常Pagefault时，将会打印出导致Pagefault出现的虚拟地址。
以后各设备都会注册自己的中断处理程序，不会再使用general_intr_handler。未被注册的，将会用general_intr_handler作为通用的中断处理程序来假装处理异常，general_intr_handler的功能是打印调试信息并将程序停止，也就是提醒出问题了，该调试了，因此只要执行到general_intr_handler中就表示出了某些异常。
**处理器进入中断后会自动把标志寄存器eflags中的IF位置0，即中断处理程序在关中断的情况下运行**。因此，通过后面的while(1)语句便能够将程序悬停在此，这样便于观察报错信息。
## exception_init注册一般中断处理函数及异常名称
在前20个异常中，除pagefault可以利用外，其他异常的发生基本属于编程出错的情况，此时需要排查。所以，对于大多数异常也不做处理，当处理器抛出异常时，需要知道是哪个异常引起的，这样才能排查问题，然而这必然要用到中断向量号，然后用该向量号作为intr_name数组的索引，这样就能找到相应异常的名字，从而方便调试。
## register_handler注册中断处理程序
由于中断处理逻辑是由kernel.S提供统一的中断入口，通过中断向量号调用中断处理程序数组idt_table中的C版本的处理程序。因此，为设备注册中断处理程序不用去修改中断描述符，直接把中断向量作为数组下标，去修改idt_table[中断向量]数组元素即可。
register_handler接受两个参数，vector_no是中断向量号，function是中断处理程序。功能是在中断处理程序数组第vector_no个元素中注册安装中断处理程序function。
## idt_init加载IDT开启中断
参见图7-6 IDTR结构，IDTR是48位的寄存器，低16位是IDT的界限，即IDT尺寸大小-1，高32位是IDT的线性基地址。**往IDTR中加载IDT的指令是lidt，lidt的操作数也要符合IDTR寄存器的结构，所以lidt的操作数也必须是48位，低16位是界限limit，高32位是基址**，只不过这48位的数据必须位于内存中，所以lidt的用法是：lidt 48位内存数据。
由于C语言中没有48位的数据类型，所以用64位的变量idt_operand来代替，这是没问题的，lidt中会取出48位数据做操作数，所以只要保证64位变量中的前48位数据是正确的就行。为了给lidt凑出48位的操作数：
1. 先用sizeof(idt) – 1得到idt的段界限limit，这用作低16位的段界限。
2. 接下来再将idt的地址挪到高32位即可，这可以通过把idt地址左移16位的形式实现。由于数组名便是地址，即指针，故先将其转换成整数才能参与后面的左移运算。考虑到32位地址经过左移操作后，高位将被丢弃，万一原地址高16位不是0，这样会造成数据错误，故需要将idt地址转换成64位整型后再进行左移操作，这样其高32位都是0，经过左移操作依然能够保证其精度。由于指针只能转换成相同大小的整型，故32位的指针不能直接转换成64位的整型，所以采取迂回的作法，先将其转换成uint32_t，再将其转换成uint64_t，之后再对这个64位的无符号整型数据进行左移16位操作。这样idt地址被移到了16～48位，低16位自动填充为0。
3. 之后再将以上两步的结果通过“按位或”运算符'|'组合到一起后，存储到变量idt_operand中。
虽然经过以上的三步得到的操作数是64位，但由于lidt的操作数是从内存地址处获得的，所以lidt依然只在该地址处取其中的48位数据当作操作数。
通过内联汇编的形式将变量idt_operand通过内存约束m的形式传给lidt作为操作数，该操作数对应的内存约束用序号占位符%0表示，所以lidt %0便将idt载入了IDTR寄存器。
> **内存约束是传递的C变量的指针给汇编指令当作操作数**，因此在“lidt %0”中，%0是idt_operand的地址&idt_operand，并不是idt_operand的值。原因是AT&T语法的汇编语言把内存寻址放在最高级，任何数字都被看成是内存地址（所以立即数需要加前缀$表示），所以lidt %0直接便去%0指向的内存地址处获取48位的操作数。而在Intel汇编语法中，立即数是最高级，也就是说数字就是数字，不代表地址，内存寻址并不是最高级，所以内存寻址需要用显式用中括号[]的方式，如lidt [idt_ptr]。

打开中断是用sti指令，它将标志寄存器eflags中的IF位置1，这样来自中断代理8259A的中断信号便被处理器受理。
外部设备都是接在8259A的引脚上，由于在8259A中已经通过IMR寄存器将除时钟之外的所有外部设备中断都屏蔽了，这样开启中断后，处理器只会收到源源不断地时钟中断。
## 时钟中断
```c
#define IRQ0_FREQUENCY	   100                                    // 要设置的时钟中断的频率
#define INPUT_FREQUENCY	   1193180                                // 计数器0的工作脉冲信号频率
#define COUNTER0_VALUE	   INPUT_FREQUENCY / IRQ0_FREQUENCY       // 计数器0的计数初值
#define CONTRER0_PORT	   0x40                                   // 计数器0的端口号0x40
#define COUNTER0_NO	   0                                         // 用在控制字中选择计数器的号码，其值为0即计数器0，将被赋值给函数的形参counter_no。
#define COUNTER_MODE	   2                                         // 用在控制字中设定工作模式的号码，其值为2，即方式2比率发生器。
#define READ_WRITE_LATCH   3                                      // 用在控制字中设定读/写/锁存操作位，这里表示先读写低8位，再读写高8位
                                                                  // 要写入的初值是16位，按照8253的初始化步骤，必须先写低8位，后写高8位
#define PIT_CONTROL_PORT   0x43                                   // 控制字寄存器的端口

uint32_t ticks;                                                   // ticks是内核自中断开启以来总共的嘀嗒数

// 设置8253，完成初始化工作
static void frequency_set(uint8_t counter_port, \
			  uint8_t counter_no, \
			  uint8_t rwl, \
			  uint8_t counter_mode, \
			  uint16_t counter_value) {
   outb(PIT_CONTROL_PORT, (uint8_t)(counter_no << 6 | rwl << 4 | counter_mode << 1));  // 往控制字寄存器端口0x43中写入控制字
   outb(counter_port, (uint8_t)counter_value);                                         // 先写入counter_value的低8位
   outb(counter_port, (uint8_t)(counter_value >> 8));                                  // 再写入counter_value的高8位
}

/* 时钟的中断处理函数 */
static void intr_timer_handler(void) {
   struct task_struct* cur_thread = running_thread();       // 获取当前正在运行的线程，将其赋值给PCB指针cur_thread

   ASSERT(cur_thread->stack_magic == 0x19870916);           // 判断stack_magic是否等于0x19870916，也就是检查栈是否溢出

   cur_thread->elapsed_ticks++;	  		// 记录此线程占用的cpu时间嘀
   ticks++;	  // 从内核第一次处理时间中断后开始至今的滴哒数,内核态和用户态总共的嘀哒数

   if (cur_thread->ticks == 0) {	  	// 若进程时间片用完就开始调度新的进程上cpu
      schedule(); 
   } else {				  // 将当前进程的时间片-1
      cur_thread->ticks--;
   }
}

/* 初始化PIT8253 */
void timer_init() {
   put_str("timer_init start\n");
   // 设置8253的定时周期，即发中断的周期
   frequency_set(CONTRER0_PORT, COUNTER0_NO, READ_WRITE_LATCH, COUNTER_MODE, COUNTER0_VALUE);
   // timer_init是由init_all调用的，它在内核运行开始处执行的，故时钟中断会被提前注册好
   register_handler(0x20, intr_timer_handler);
   put_str("timer_init done\n");
}
```
### frequency_set初始化8253
8253的目的就是为了给IRQ0引脚上的时钟中断信号提速，使其发出的中断信号频率快一些。它默认的频率是18.206Hz，即一秒内大约发出18次中断信号，本节将对8253编程，使时钟一秒内发100次中断信号，即中断信号频率为100Hz：
1. IRQ0引脚上的时钟中断信号频率是由8253的计数器0设置的，要使用计数器0。
2. 时钟发出的中断信号不能只发一次，必须是周期性发出的，也就是要采取循环计数的工作方式，可选的工作方式为方式2和方式3，这选择方式2，即标准的分频方式。
3. 计数器发出输出信号的频率是由计数初值决定的，所以要为计数器0赋予合适的计数初值。要设置的中断信号的频率为100Hz，则计数器0的初始计数值= 1193180/100 约等于11932。11932就是计数器0的计数初值。
frequency_set函数的功能是把操作的计数器counter_no、读写锁属性rwl、计数器工作模式counter_mode写入模式控制寄存器并赋予计数器的计数初值为counter_value。
1. counter_port是计数器的端口号，用来指定初值counter_value的目的端口号。
2. counter_no用来在控制字中指定所使用的计数器号码，对应于控制字中的SC1和SC2位。
3. rwl用来设置计数器的读/写/锁存方式，对应于控制字中的RW1和RW0位。
4. counter_mode用来设置计数器的工作方式，对应于控制字中的M2～M0位。
5. counter_value用来设置计数器的计数初值，由于此值是16位，所以用uint16_t来定义。
### intr_timer_handler时钟中断处理函数
> 此处的时钟中断处理函数主要用于多线程调度

在timer_init中，加入注册时钟中断处理程序的代码，timer_init是由init_all调用的，它在内核运行开始处执行的，故时钟中断会被提前注册好。
## 键盘中断处理程序
一个中断向量号要有一个中断入口，以宏VECTOR来实现的中断入口展开后，中断入口程序名为intr%1entry，其中%1是中断向量号，在入口程序中用这个中断向量号作为idt_table中的索引，调用最终C语言版本的中断处理程序。
因此，中断处理程序不仅要调用register_handler注册到idt_table中，还需要有相应的中断向量号，而键盘的中断信号接在8259A主片的IR1引脚上，也就是它对应的中断向量为0x21。
此外，还需要写8259A的中断屏蔽寄存器，打开键盘中断。
> 很多中断相关的结构都与IDT_DESC_CNT有关，中断描述符idt、数组intr_name都要用IDT_DESC_CNT作为数组长度，甚至所声明的外部数组intr_entry_table（位于kernel.S中）也用到它，数组intr_entry_table中的元素就是程序入口intr%1entry，因此，一定要保证IDT_DESC_CNT的值正确。

## 开关中断
```c
/* 定义中断的两种状态:
 * INTR_OFF值为0,表示关中断,
 * INTR_ON值为1,表示开中断 */
enum intr_status {		 // 中断状态
    INTR_OFF,			 // 中断关闭
    INTR_ON		         // 中断打开
};

/* 获取当前中断状态 */
enum intr_status intr_get_status() {
   uint32_t eflags = 0; 
   GET_EFLAGS(eflags);
   return (EFLAGS_IF & eflags) ? INTR_ON : INTR_OFF;
}

/* 开中断并返回开中断前的状态*/
enum intr_status intr_enable() {
   enum intr_status old_status;
   if (INTR_ON == intr_get_status()) {
      old_status = INTR_ON;
      return old_status;
   } else {
      old_status = INTR_OFF;
      asm volatile("sti");	                  // 开中断，sti指令将IF位置1
      return old_status;
   }
}

/* 关中断,并且返回关中断前的状态 */
enum intr_status intr_disable() {     
   enum intr_status old_status;
   if (INTR_ON == intr_get_status()) {
      old_status = INTR_ON;
      asm volatile("cli" : : : "memory");    // 关中断，cli指令将IF位置0
      return old_status;
   } else {
      old_status = INTR_OFF;
      return old_status;
   }
}

/* 将中断状态设置为status */
enum intr_status intr_set_status(enum intr_status status) {
   return status & INTR_ON ? intr_enable() : intr_disable();
}
```

**宏GET_EFLAGS用来获取eflags寄存器的值**。它就是段内嵌汇编代码，其中EFLAG_VAR是C代码中用来存储eflags值的变量，它用寄存器约束g来约束EFLAG_VAR可以放在内存中或寄存器中，之后用pushfl将eflags寄存器的值压入栈，然后再用popl指令将其弹出到与EFLAG_VAR关联的约束中，最后C变量EFLAG_VAR获得eflags的值。
为管理中断状态，在头文件中定义enum intr_status枚举结构，INTR_OFF值为0表示关中断，INTR_ON值为1表示开中断。
**intr_get_status函数的作用是获取当前的中断状态**。先利用宏GET_EFLAGS来获取eflags寄存器的值并存到变量eflags中，接下来再利用EFLAGS_IF与变量eflags的值进行按位与运算，判断变量eflags中IF位的值是否为1，从而返回不同的中断状态，即INTR_ON或INTR_OFF。
**intr_enable的功能是把中断打开，再把执行开中断前的中断状态返回**。此函数先调用intr_get_status函数获取当前的中断状态，接下来判断：如果当前已经是开中断的状态，那就直接返回，无需再执行一次汇编指令sti。如果当前是关中断状态，就通过sti指令将中断打开。最后，无论程序走哪个分支，都要将操作前的中断状态old_status返回。
**intr_disable的功能是把中断关闭，就是关中断**。此函数的原理也是先通过intr_get_status获取当前的中断状态，若当前已经是关中断状态，则直接把INTR_OFF返回，否则就通过cli指令将中断关闭，然后返回旧中断状态。
**intr_set_status的作用是把中断设置为参数status的状态**，参数status的值通常是调用intr_disable和intr_enable之后的返回值old_status，故一般情况下intr_set_status用来配合intr_disable和intr_enable，以恢复之前的中断状态。
> 把返回指令return old_status放在分支判断的外层，也就是放在函数结束前，这样两个分支就共同使用这一行代码了。其实也未尝不可，只是每个分支中都有return语句时，能够避免将C编译为汇编代码时因为共用一行代码而额外添加jmp语句，虽然程序因此大了一点，但也因此快了一点，空间换时间。