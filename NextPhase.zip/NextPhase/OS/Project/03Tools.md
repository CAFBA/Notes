# Print
> 下面代码中涉及到的显卡操作只用到了CRT Controller Registers分组中的寄存器
```assembly
TI_GDT equ  0                                               ; 定义显存段段描述符的选择子
RPL0  equ   0                                               ; 即boot.inc的定义
SELECTOR_VIDEO equ (0x0003<<3) + TI_GDT + RPL0

[bits 32]                                                   
section .text                                               ; 代码段
                                                            ; ------------------------   put_char   -----------------------------
                                                            ; -------------------------------------------------------------------   
global put_char                                             ; 将put_char导出为全局符号

put_char:
   pushad	                                                ; 备份32位寄存器环境
   mov ax, SELECTOR_VIDEO	                                 ; 不能直接把立即数送入段寄存器
   mov gs, ax                                               ; 需要保证gs中为正确的视频段选择子，每次打印时都为gs赋值

                                                            ; --------------------- 获取当前光标位置，先获得高8位
   mov dx, 0x03d4                                           ; 从端口地址为0x3D4的Address Register寄存器写入
   mov al, 0x0e	                                          ; 索引为0Eh的Cursor Location High Register寄存器
   out dx, al                                               ; 写入寄存器索引，得到光标坐标值
   mov dx, 0x03d5                                           ; 从端口地址为0x3D5的Data Register寄存器读取
   in al, dx	                                             ; 得到光标位置的高8位，in指令源操作是8位寄存器，目的操作数必须是al
   mov ah, al                                               ; ax中的ah是光标位置的高8位

                                                            ; 再获取低8位
   mov dx, 0x03d4
   mov al, 0x0f
   out dx, al
   mov dx, 0x03d5 
   in al, dx                                                  
   mov bx, ax	                                             ; 现在bx中存的是光标的位置，是下一个可打印字符的位置

                                                            ; --------------------- 判断待打印字符
                                                            ; 获取栈中压入的字符的ASCII码
   mov ecx, [esp + 36]	                                    ; pushad压入32字节，加上主调函数的返回地址4字节，故待打印的字符在栈顶偏移36字节的位置
   cmp cl, 0xd				                                    ; 判断是否是CR(回车)0x0d
   jz .is_carriage_return

   cmp cl, 0xa                                              ; 判断是否是LF(换行)0x0a
   jz .is_line_feed

   cmp cl, 0x8				                                    ; 判断是否是BS(backspace退格)
   jz .is_backspace

   jmp .put_other
                                                            ; -------------- 处理退格
.is_backspace:		         
   dec bx                                                   ; 光标位置-1，即按下退格符，光标回退
   shl bx,1                                                 ; 光标值乘以2后便是对应字符在显存中的相对地址
                                                            ; 字符在显存中占2字节，低字节是ASCII码，高字符是属性
   mov byte [gs:bx], 0x20		                              ; 将待删除的字节补为0或空格, 0x20是空格符的ASCII码
   inc bx                                                   ; bx+1, 指向这个字符的属性位置, 设定背景色, 字符颜色
   mov byte [gs:bx], 0x07                                   ; 0x07, 就是黑底白字
   shr bx,1                                                 ; 除2取整恢复成光标坐标，此时的bx指向新覆盖的空格
   jmp .set_cursor                                          ; 去设置光标位置, 这样光标才会显示在新位置。

 .put_other:                                                ; 对于可见字符，需要判断这个新坐标是否超过屏幕显示的范围
   shl bx, 1				                                    ; 光标位置是用2字节表示，将光标值乘2，表示对应显存中的偏移字节
   mov [gs:bx], cl			                                 ; ecx是待打印字符
   inc bx
   mov byte [gs:bx], 0x07		                              ; 字符属性
   shr bx, 1
   inc bx				                                       ; 下一个光标值
   cmp bx, 2000                                             ; 在80*25模式下屏幕可显示的字符数是2000，用cmp指令把下次打印字符的坐标和2000比较
   jl .set_cursor			                                    ; 若光标值小于2000,表示未写到显存的最后,则去设置新的光标值

                                                            ; -------------- 处理回车换行
                                                            ; 若超出屏幕字符数大小(2000)则换行处理，把\n和\r都处理为linux中\n，也就是下一行的行首
 .is_line_feed:				                                 ; 是换行符LF(\n)
 .is_carriage_return:			                              ; 是回车符CR(\r)
                                                            ; 先处理回车，将光标回撤到当前行的行首
   xor dx, dx				                                    ; 要进行16位除法，高16位会放在dx中，要先清零
   mov ax, bx				                                    ; 将光标坐标值bx对80求模，ax存被除数的低16位
   mov si, 80				                                    ; si寄存器存储除数80
   div si				                                       ; div除法指令，ax中存商，dx中存余数
   sub bx, dx				                                    ; 坐标值bx减去余数就是行首字符的位置

 .is_carriage_return_end:		                              ; 再处理换行
   add bx, 80                                               ; 将当前光标坐标值加上每行的字符数80，便是下一行的坐标
   cmp bx, 2000                                             ; 回车换行符处理流程中自己的滚屏判断
   
 .is_line_feed_end:			                                  
   jl .set_cursor

                                                            ; -------------- 滚屏
                                                            ; 屏幕行范围是0~24，滚屏的原理是将屏幕的1~24行搬运到0~23行，再将第24行用空格填充
.roll_screen:				                                    
   cld                                                      ; 清除方向位
   mov ecx, 960				                                 ; 一共有2000-80=1920个字符要搬运，共1920*2=3840字节，一次搬4字节，共3840/4=960次 
                                                            ; 实现用户进程后，为方便用户进程的管理，此处会用其虚拟地址0xc00b80a0代替
   mov esi, 0xc00b80a0										         ; 复制的起始地址第1行行首 mov esi, 0xb80a0		
   mov edi, 0xc00b8000										         ; 目的地址第0行行首 mov edi, 0xb8000	
   rep movsd				                                    ; rep movs word ptr es:[edi], word ptr ds:[esi] 简写为: rep movsw

                                                            ; 将最后一行填充为空白
   mov ebx, 3840			                                    ; 最后一行首字符的第一个字节偏移为1920 * 2
   mov ecx, 80				                                    ; 一行是80字符(160字节)，每次清空1字符(2字节)，一行需要移动80次

.cls:
   mov word [gs:ebx], 0x0720		                           ; 0x0720是黑底白字的空格键
   add ebx, 2
   loop .cls 
   mov bx,1920				                                    ; 把bx设置为最后一行起始，bx作为光标坐标值，进入.set_cursor完成光标坐标的更新。

.set_cursor:   
					                                             ; -------------- 设置光标
   mov dx, 0x03d4			                                    ; 索引寄存器
   mov al, 0x0e				                                 ; 用于提供光标位置的高8位
   out dx, al
   mov dx, 0x03d5			                                    
   mov al, bh
   out dx, al

   mov dx, 0x03d4
   mov al, 0x0f
   out dx, al
   mov dx, 0x03d5 
   mov al, bl
   out dx, al

.put_char_done: 
   popad
   ret

                                                            ; -------------------------------------------------------------------   
                                                            ; ---------------- put_str ----------------
[bits 32]
section .text

global put_str

put_str:                                                    
                                                            
   push ebx                                                 ; 由于只用到ebx和ecx两个寄存器，所以直接将这两个寄存器入栈备份
   push ecx                                                 ; 不需要用pushad保存所有32位通用寄存器
   xor ecx, ecx		                                       ; 下面要用寄存器ecx来传递字符，所以在此先用异或指令xor清0
   mov ebx, [esp + 12]	                                    ; 从栈中得到待打印的字符串首地址 

.goon:
   mov cl, [ebx]                                            ; ebx是字符串的地址，对地址进行取地址操作，取出一字节的数据，即取出第一个字符
   cmp cl, 0		                                          ; 如果处理到了字符串尾，跳到结束处返回
   jz .str_over
   push ecx		                                             ; 为put_char函数传递参数
   call put_char
   add esp, 4		                                          ; 回收参数所占的栈空间
   inc ebx		                                             ; 使ebx指向下一个字符
   jmp .goon

.str_over:
   pop ecx
   pop ebx
   ret

                                                            ; -------------------------------------------------------------------   
                                                            ; ---------------- put_int ----------------
section .data
put_int_buffer dq 0                                         ; 定义8字节缓冲区用于数字到字符的转换

global put_int

put_int:
                                                            ; ---------------- 准备寄存器
   pushad
   mov ebp, esp
   mov eax, [ebp+4*9]		                                 ; call的返回地址占4字节+pushad的8个4字节，现在eax中就是要显示的32位数值
   mov edx, eax                                             ; eax作为参数的备份，edx作为每次参与数位转换的寄存器
   mov edi, 7                                               ; 表示在缓冲区中的偏移量，偏移为7表示指向缓冲区中最后一个1字节，即存储数字最低4位二进制对应的字符
   mov ecx, 8			                                       ; 表示要处理的数字的个数，32位数字中16进制数字的个数是8
   mov ebx, put_int_buffer                                  ; ebx现在存储的是put_int_buffer的起始地址

                                                            ; ---------------- 处理最低四位
                                                            ; 将32位数字按照16进制的形式从低位到高位逐个处理，共处理8个16进制数字
.16based_4bits:			                                    ; 每4位二进制是16进制数字的1位，遍历每一位16进制数字
   and edx, 0x0000000F		                                 ; 先从32位数字的最低4位开始处理，edx低4位有效
   cmp edx, 9			                                       ; 数字0～9和a~f需要分别处理成对应的字符
   jg .is_A2F                                               ; 大于9则属于A～F范围
   add edx, '0'			                                    ; ASCII码是8位大小，add求和操作后，edx低8位有效
   jmp .store
.is_A2F:
   sub edx, 10			                                       ; A~F 减去10 所得到的差，再加上字符A的ASCII码,便是A~F对应的ASCII码
   add edx, 'A'

                                                            ; ---------------- 存储字符

                                                            ; 将每一位数字转换成对应的字符后，按照类似大端的顺序存储到缓冲区put_int_buffer
                                                            ; 高位字符放在低地址，低位字符要放在高地址，这样和大端字节序类似
.store:
   mov [ebx+edi], dl		                                    ; 此时dl中是数字对应的字符的ASCII码，向put_int_buffer中写入转换好的字符
   dec edi                                                  ; edi是表示在buffer中存储的偏移，逐渐减少，使偏移量由高到低，向前高位移动
   shr eax, 4                                               ; eax中是参数的备份，现在右移4位，处理下一个4位二进制表示的16进制数字
   mov edx, eax                                             ; edx作为每次参与数位转换的寄存器
   loop .16based_4bits


                                                            ; ---------------- 前置0处理

                                                            ; 现在put_int_buffer中已全是字符,打印之前,
                                                            ; 把高位连续的字符去掉,比如把字符00000123变成123
.ready_to_print:
   inc edi			                                          ; 此时edi退减为-1(0xffffffff)，加1使其为0，为指向缓冲区中最低地址做准备

.skip_prefix_0:                                             ; 跳过前缀的连续多个0
   cmp edi,8			                                       ; 若已经比较第9个字符了，表示待打印的字符串为全0 
   je .full0 
                                                            ; 找出连续的0字符, edi做为非0的最高位字符的偏移
.go_on_skip:                                                ; 从最高位字符逐个与字符'0'比对，直到找出不为0的字符
   mov cl, [put_int_buffer+edi]                             ; cl表示当前处理的字符，edi作为偏移量
   inc edi                                                  ; 缓冲区中的偏移从0起便指向最高位字符，之后每次比对都自增1
   cmp cl, '0'                                              ; 继续判断下一位字符是否为字符0，
   je .skip_prefix_0		                                    ; 若是则会跳到.skip_prefix_0，然后继续执行.go_on_skip判断，直到不是连续0，在此处不跳转
   dec edi			                                          ; edi在上面的inc操作中指向下一个字符，若当前字符不为'0'，要恢复edi指向当前字符		       
   jmp .put_each_num                                        ; 此时已经跳过所有前置0，进行打印

.full0:
   mov cl,'0'			                                       ; 输入的数字为全0时，则只打印0

.put_each_num:
   push ecx			                                          ; 为put_char函数传递参数，此时cl为待打印字符
   call put_char                                            
   add esp, 4                                               ; 回收参数所占的栈空间
   inc edi			                                          ; edi指向缓冲区中左起第1个非'0'的字符
   mov cl, [put_int_buffer+edi]	                           ; 获取下一个字符到cl寄存器
   cmp edi,8                                                ; 当edi=8时，虽然不会去打印，但是实际上已经在越界访问缓冲区
   jl .put_each_num

   popad
   ret

global set_cursor
set_cursor:
   pushad
   mov bx, [esp+36]
															         
   mov dx, 0x03d4			  								            
   mov al, 0x0e				  								         
   out dx, al
   mov dx, 0x03d5			  								            
   mov al, bh
   out dx, al

   mov dx, 0x03d4
   mov al, 0x0f
   out dx, al
   mov dx, 0x03d5 
   mov al, bl
   out dx, al

   popad
   ret
```
## 实现单个字符打印
打印函数在print.S文件中完成，该文件是各种打印函数的核心：
1. 备份寄存器现场。
2. 获取光标坐标值，光标坐标值是下一个可打印字符的位置。
3. 获取待打印的字符。
4. 判断字符是否为控制字符，若是回车符、换行符、退格符三种控制字符之一，则进入相应的处理流程。否则，其余字符都被粗暴地认为是可见字符，进入输出流程处理。
5. 判断是否需要滚屏。
6. 更新光标坐标值，使其指向下一个打印字符的位置。
7. 恢复寄存器现场，退出。
put_char的打印原理是直接写显存，在32位保护模式下对内存的操作是[段基址（选择子）：段内偏移量]，所以这就涉及显存段选择子。一直以来都是用段寄存器gs来存储显存段选择子的，以后也是，所以得保证在写显存之前，gs中的值是正确的选择子。
### 获取当前光标位置
打印字符本质上就是把字符写入在显存中的某个地址处。在文本模式`80*25`下的显存可以显示80\*25=2000个字符，每个字符占2字节，低字节是字符的ASCII码，高字节是前景色和背景色属性，所以在4000字节的显存空间中，只要起始地址为偶数的任意2字节都可以写入字符。光标只是个亮点，本身与字符显示的位置没有关系，但光标的作用已经被认同为当前可输入或显示字符的位置。
光标是字符的坐标，只不过该坐标不是二维的，而是一维的线性坐标，是屏幕上所有字符以0为起始的顺序。在默认的80\*25模式下，每行80个字符共25行，屏幕上可以容纳2000个字符，故该坐标值的范围是0～1999。第0行的所有字符坐标是0～24，第1行的所有字符坐标是25～49，以此类推，最后一行的所有字符是1975～1999。**由于一个字符占用2字节，所以光标乘以2后才是字符在显存中的地址**。
光标的坐标位置是存放在光标坐标寄存器中的，当在屏幕上写入一个字符时，光标的坐标并不会自动+1，因为光标跟随字符并不是必要的，比如想删除文本中的某个字符时，可以把光标移动到该字符后面，再按下delete键，这样字符就被删除了，这就是光标与字符分离的应用之一。所以，光标位置并不会自动更新，因为光标坐标寄存器是可写的，如果需要的话，程序员可以自己来维护光标的坐标。
为了在光标处打印字符，需要读取光标坐标寄存器，获取光标坐标值。表6-5CRT Controller Data Registers中**索引为0Eh**的Cursor Location High Register寄存器和**索引为0Fh**的Cursor Location Low Register寄存器都是8位长度，分别用来存储光标坐标的高8位和低8位地址。访问CRT controller寄存器组的寄存器，需要**先往端口地址为0x3D4的Address Register寄存器中写入寄存器索引，再从端口地址为0x3D5的Data Register寄存器读取**。
综上，将索引0x0e写入端口是0x03d4的Address Register寄存器，从而找到操作的寄存器是Cursor Location High Register，再通过端口是0x3d5的Data Register寄存器，将坐标读取到dx寄存器，由于是坐标的高8位，所以要将其存储在ah寄存器。接下来用同样的方法获取到坐标的低8位，至此，寄存器ax中是光标完整的16位坐标值。
接下来**要将光标值从ax寄存器中复制到bx**，因为**在16位实模式下基址寄存器必须是bx或bp**，变址必须是寄存器si或di，在32位保护模式下基址和变址寄存器可以是全部的32位的通用寄存器，即pushad指令压入的8个，此处只是因为习惯用寄存器bx做基址寻址。
> 对于in指令，如果源操作是8位寄存器，目的操作数必须是al，如果源操作数是16位寄存器，目的操作数必须是ax。
### 判断待打印字符
获取栈中压入的字符的ASCII码，也就是待打印的字符，这是1字节的数据。栈中除了调用put_char函数的返回地址占4字节外，还有最开始的pushad指令压入的8个32位的通用寄存器共32字节的数据，所以待打印的字符在栈顶偏移36字节的位置。
之后开始判断参数是什么字符，回车符的ASCII码是0xd，换行符的ASCII码是0xa，这里的处理是不管参数是回车符，还是换行符，一律按CRLF处理（Linux中就把换行符处理成回车+换行），即这两个动作的合成：光标回撤到行首+换到下一行。
> 直接写入回车的ASCII码0xd并不生效，所以得手工控制字符的行为。硬件不负责这些字符编码的行为解释，字符编码的表现形式取决于软件的逻辑，所以，甚至可以将shift键解释为换行，不过还是按照常识来解释这些字符编码的行为，即换行符就是切换到下一行，退格键就是删除前一个字符。
### 处理退格键
backspace的原理就是将光标向回移动1位，将该处的字符用空格覆盖。当为backspace时，本质上只要将光标移向前一个显存位置即可，后面再输入的字符自然会覆盖此处的字符，但有可能在键入backspace后并不再键入新的字符，这时在光标已经向前移动到待删除的字符位置，但字符并没有被覆盖，所以此处添加了空格或空字符0。
bx是下一个可打印字符的光标坐标值，光标值乘以2后便是字符在显存中的相对地址，接下来在该地址处写入字符。寄存器ecx已经是待打印的参数，由于字符的ASCII码只是1字节，所以只用寄存器cl。
由于字符在显存中占2字节，低字节是ASCII码，高字符是属性，所以在bx处，也就是低字节处先把空格的ASCII码0x20写入，再通过inc指令把bx加上1，这样bx便指向了该字符的属性位置，再将属性0x7写入到高字节（直接写入0x0720最简单）。
此时的bx由于之前已经加1指向属性，所以已经变成了奇数，通过右移指令shr将bx右移1位相当于除2取整，这样bx便由显存中的相对地址恢复成光标坐标，此时的bx指向新覆盖的空格。
由于删除了一个字符，bx中的光标坐标已经被更新为前一位，跳到设置光标的流程.set_cursor，经过它的处理，光标才会显示在新位置。
### 滚屏与回车换行
对于可见字符，需要判断这个新坐标是否超过屏幕显示的范围，这个新坐标值就是下次打印字符的位置。在80\*25模式下屏幕可显示的字符数是2000，这里用cmp指令把下次打印字符的坐标和2000比较，若小于2000则表示下次打印时，字符还会在当前屏幕的范围之内，于是直接跳转到.set_cursor更新光标坐标。如果下次打印字符的坐标不小于2000，就需要滚屏。此外其实还有其他情况也需要滚屏：新的光标值超出了屏幕右下角最后一个字符的位置或最后一行中任意位置有回车或换行符。
在80\*25文本模式下屏幕可显示2000个字（字符），4000字节的内容。显存有32KB，按理说显存中可以存放32KB/4000B约等于8屏的字符，这8屏的字符肯定不能一下子都显示在1个屏幕上，所以显卡就提供了两个寄存器，用来设置显存中那些在屏幕上显示的字符的起始位置，它们分别是表6-5中索引为0xc的Start Address High Register和0xd的Start Address Low Register，这两个都是8位寄存器，如名字所示，它们分别设置地址的高8位和低8位。**只要指定起始地址，屏幕自动从该地址起，向后显示2000个字符。注意，如果起始地址过大，显卡会将其在显存中回绕wrap around。因此，一种方案是通过设置显示的起始地址，让屏幕在显存中滑动起来实现窗口滚动。**
还有另外一个方案：默认情况下这两个寄存器的值是0，也就是说默认情况下屏幕上的内容是从显存的首地址（物理地址）0xb8000起，一直到以该地址向上偏移3999字节的地方。假如把屏幕固定在此，这样就不用再设置显示的起始地址了，其永远为0。这两个寄存器Start Address High Register和Start Address Low Register就不用动了。
第一种方案的优势是显存中可缓存16KB个字符，屏幕外的文本也能找回。缺点就是要设置那两个起始地址寄存器，编程复杂一点。第二种方案的优势就是编程简单，缺点是只能缓存2000个字符，屏幕上的字符便是全部缓存了。虽然第一种方案能缓存那么多个字符，但显存容量毕竟是有限的，当输出字节量超过32KB时，照样要丢弃之前旧的字符，不是所有屏幕外的字符都能找回，而且要多个设置寄存器的操作，因此采取第二种方案。
屏幕每行80个字符，共25行，此方案实现滚屏的步骤：
1. 将第1～24行的内容整块搬到第0～23行，也就是把第0行的数据覆盖。
2. 再将第24行，也就是最后一行的字符用空格覆盖，这样它看上去是一个新的空行。
3. 把光标移到第24行也就是最后一行行首。
经过这三步，屏幕就像向上滚动一行。另外，由于第3步只是计算好了新的坐标值并没有在光标寄存器中更新，所以它的顺序不是很重要，也可以放在前面先做。滚屏操作也需要回车换行符的。因为在滚屏操作中，除了将当前屏幕所有内容上移一行外，光标的坐标也要更新为下一行的行首，这实际上相当于在最后一行的行尾键入了回车符，在此用处理回车换行符的代码帮助实现上面第3步的更新光标值。
回车换行本质上是两个操作的合，使得光标出现在下一行行首：
- 回车carriage_return将光标回撤到行首**将光标坐标值bx对80求模，再用坐标值bx减去余数，得到行首字符的位置**。代码中对80求模，经过div除法操作后，dx寄存器中为余数，再用坐标值减余数，经过sub bx, dx后，bx便为当前行首坐标。
- 换行符line_feed将当前光标坐标值加上每行的字符数80，从而将光标切换到下一行。
cmp bx, 2000是回车换行符处理流程中自己的滚屏判断，它和前面所说的滚屏流程无关。倘若没有之前的滚屏，在单独的回车换行处理流程中也要判断在将光标更新为下一行后是否超出了屏幕范围而需要滚屏。这就是前面所说的第2种需要滚屏的情况，即在最后一行中的任意一个位置有回车或换行符都将导致滚屏。
这里需要换行的原因是由于屏幕已经满了，当前光标坐标（不是下一个可打印位置的光标坐标）已经是在最后一行的最后一列，这种情况下滚屏相当于在屏幕右下角后面敲入一个回车键，尽管没有回车符或换行符，但它能使屏幕新起一行，这恰恰是滚屏需要的。所以，这就是借用回车换行符处理流程的原因，它能为滚屏增加个新的空行。
滚屏.roll_screen，先用cld指令清除方向位，就是把eflags寄存器中方向标志位DF（Direction Flag）清0，用于cld，movs[bwd]和rep组合完成大数据的复制。
将ecx赋值为960，它用来控制rep重复执行指令的次数，这里是要把第1～24行的字符整体往上提一行，复制到第0～23行。要复制的字符数是2000-80=1920个，每个字符是2字节，共3840字节，用movsd指令来复制，它一次复制4字节数据，所以需要执行3840/4=960次。
接下来把要复制的起始地址赋给esi寄存器，也就是屏幕第1行的起始地址，物理地址是0xb80a0。将来实现用户进程后，为方便用户进程的管理，此处会用其虚拟地址0xc00b80a0代替。把目的地址赋给edi寄存器，也就是屏幕的第0行的起始地址，物理地址是0xb8000，将来也会用其虚拟地址0xc00b8000代替。
用rep指令配合movsd指令，开始循环复制，直至把第24行的数据复制完毕。
滚屏操作需要将最后一行用空格填充，首先准备复制的起始地址和循环次数，最后一行在显存中的偏移地址是3840，循环次数是每行的字节总数除以每次处理的字节数，每行80个字符共160字节，一次清空1个字符，即2字节，故循环次数是160/2=80次。
准备后使用.cls清空最后一行，0x0720是一个空格的数据，低字节是空格的ASCII码0x20，高字节是前景色和背景色属性0x07。这里通过mov dword [gs:ebx]，0x0720处理1个空格，用loop指令来实现循环执行，它也是用ecx作为循环计数器，每执行一次，ecx自动减1，直到为0时停止执行。
### 设置光标
.set_cursor把光标坐标寄存器设置为寄存器bx中的值。原理是先通过0x3d4端口写入待操作寄存器的索引，与之前获取坐标值的代码一样。只不过操作0x3d5端口不再是读取指令in，而是写入指令out，要把bx中的值更新到光标坐标寄存器的高8位和低8位。
最后.put_char_done完成put_char的处理流程，用popd指令将之前入栈的8个32位寄存器恢复到各个的寄存器中，环境恢复，ret指令返回。
虽然put_char是用汇编语言写的，但它被C语言引用时，在C语言中的形式还是得符合C语言语法，加之cdecl调用约定，所以put_char的C语言形式是void put_char（uint8_t char_asci），这样put_char才能从栈中获取参数char_asci。这里的char_asci是无符号8位整型变量（其实就是unsigned char），这与代码mov ecx, [esp + 36]获取参数到寄存器ecx后，只用寄存器cl是相吻合的。
## 实现字符串打印
put_str的原理是每次处理一个字符，循环调用put_char来完成字符串中全部字符的打印。
C编译器会为字符串常量分配一块内存，在这块内存中存储字符串中各字符的ASCII码，并且会在结尾后自动补个结束字符'\0'，它的ASCII码是0。
编译器将该字符串作为传入的参数时，传递的是字符串所在的内存起始地址，因此压入到栈中的是存储该字符串的内存首地址，需要对该地址进行内存寻址才能找到字符的ASCII码。前面在栈中备份了两个寄存器占8字节，再加上栈中put_str函数的返回地址占4字节，故在栈中偏移栈顶12字节的位置得到字符串首地址，存储到ebx，用ebx作为基址寻址。
## 实现整数打印
### 准备寄存器
函数转换实现的原理是按十六进制来处理32位数字，每4位二进制表示1位十六进制，将各十六进制数字转换成对应的字符，一共8个十六进制数字要处理，转换成对应的字符后，这些数字就得变成对应的ASCII码，ASCII码是1字节大小，所以每个字符需要1字节的空间。因此用section定义一个数据区，里面用伪指令dq申请了8字节的内存put_int_buffer，它作为转换过程中用的缓冲区，实际上它的用途就是用于存储转换后的字符。
直接通过esp获取参数是不太好的习惯，难免有压栈操作会改变esp，而ebp不显式改变它永远不会变。所以，尽管32位支持寄esp寻址，但还是建议通过ebp来获取参数。因此先把栈顶esp赋值给ebp，再通过ebp来获取参数。
在将参数获取到寄存器eax后，将其送到edx中，这两个寄存器在后面要配合在一起使用。**eax作为参数的备份，而edx作为每次参与数位转换的寄存器**，主要是由它做转换源，每当转换完1个十六进制数后，再由eax为其更新下一个待转换的数字。
为edi赋值为7，它表示在缓冲区中的偏移量，偏移为7表示指向缓冲区中最后一个1字节，目的是在该地址处存储数字最低4位二进制（也就是十六进制中的最低1位）对应的字符。
为ecx赋值为8，它表示要处理的数字的个数，32位数字中，每4位二进制表示1个十六进制，十六进制数字的个数是8，按照十六进制来处理，所以共8个。
把ebx作为缓冲区的基址，该地址就是前面已经定义的put_int_buffer，把数字转换后的字符都存储在这里面。
### 处理最低四位
.16based_4bits将32位数字按照十六进制的形式从低位到高位逐个处理。通过and与运算只保留数字的最低十六进制位，先从32位数字的最低4位开始处理。接下来将数字转换成字符的原理是：
- 如果是0～9之间的数字，用该数字加上字符'0'的ASCII码48。
- 如果是A～F之间的数字，用该数字减去10后再加上字符'A'的ASCII码65。
因此开始判断该数字是否大于9，大于9则属于A～F范围，否则属于0～9。这里为了语义清楚，对于字符'0'和字符'A'的ASCII码，直接写字符'0'和字符'A'，由编译器将其转换成各自的ASCII码。
### 存储字符
字符转换完成后就存储到缓冲区put_int_buffer。在由数字变成字符后，它在内存中的顺序不能按照各位数字本身在内存中的顺序（x86架构是小端字符序，数字中的高位在内存的高地址，数字中的低位在内存的低地址），因为它们已经不再是数字了，处理它们的时候，都是以各字符1字节的单位来处理的，一视同仁，不分高低。所以，最好按照正常顺序来存储，高位的字符放在前面低地址，低位的字符放在后面高地址，这才是人习惯的自然顺序。
.store开始存储字符，edi之前已经被赋值为7，这是从后往前写字符，就是大端字符序。向put_int_buffer中写入转换好的字符，dec指令使寄存器edi的值逐渐减少，使偏移量由高到低。
通过shr右移指令把eax寄存器向右移动4位，去掉已转换完成的低4位，随后赋值给edx，再进行下一轮的处理，这就是eax和edx配合。
### 前置0处理
打印前要跳过原来数字中高位的0，而且打印到屏幕上的字符不包括十六进制的0x前缀。
edi作为缓冲区中的偏移量，经过前面的转换之后，edi此时已经为-1了，即0xffffffff，故通过inc指令使其恢复为0，这也是为指向缓冲区中最低地址做准备。
.go_on_skip从最高位字符逐个与字符'0'比对，直到找出不为0的字符。寄存器cl用来存储字符ASCII码，表示当前处理的字符，由于缓冲区中的字符已经是按照大端字符序（最低地址最高字符）存储，所以此时的edi作为偏移量，其值为0，缓冲区中的偏移从0起便指向最高位字符，之后每次比对都自增1。
后面将edi用dec指令减1的原因是，若当前字符为非'0'，说明不需要跳转，edi也无需自增1，因此将edi恢复成指向当前字符。
如果在最高位找到字符'0'，程序流程会到.skip_prefix_0，在这里会判断数字字符是否为全0，这里的逻辑是偏移edi变成8时，表示已经找到了8个0，所以判断为全0。比如数字为0x00000000这种情况，其转换的字符会是'0''0''0''0''0''0''0''0'。随后会跳到.full0处，在那里将其处理为字符'0'。
## GS赋值
和硬件相关的访问都属于内核的工作，打印输出也是，用户进程只能依靠内核的帮助来完成和硬件相关的操作，不过需要有一套机制来防止用户进程直接访问内核资源的这种越权行为。
在loader中，早已经将gs赋予成正确的选择子，程序进入保护模式之后继承0特权级，内核也在0特权级下工作。到现在为止这一切都很正常，可是当有用户进程之后，**用户进程是需要用iretd返回指令上CPU运行的**。CPU在执行iretd指令时会做特权检查，它检查DS、ES、FS、GS段寄存器的内容。在32位保护模式下它们中存储的都是选择子，**要是有任何一个段寄存器所指向的段描述符的DPL权限高于从iretd命令返回后的CPL（这个返回后的CPL也就是新的CPL，CPL就是加载到CS寄存器中选择子的RPL），CPU就会将该段寄存器赋值为0**。
一旦将来用该段寄存器访问内存时，由于选择子为0，这表示选择子中的索引位、TI位和RPL位都为0，所以会在GDT中检索到第0个段描述符，由于第0个段描述符是空的不可用（这是Intel有意为之的，为避免忘记初始化选择子而误选到了GDT中的第0个描述符），这就会导致CPU抛出异常。
用户进程的特权级由CS寄存器中选择子的RPL字段决定，它将成为进程在CPU上运行时的CPL。将来为用户进程初始化寄存器时，CS中的选择子RPL字段必须为3，进而它就是从iretd指令返回后的新的CPL。而用于访问显存的GS寄存器，在新的CPL为3的情况下，无论为其赋为何值，其选择子所指向的段描述符中的DPL值必须等于3，否则CPU会将GS置为0。目前使用的显存段描述符是全局描述符表GDT中的第3个段描述符，但它的DPL为0，不为3。这里给出了两个方案。
1. 为用户进程创建一个显存段描述符，其DPL为3，专门给特权3级的用户进程使用。
2. 在打印函数中将GS的值改为指向目前DPL为0的显存段描述符。
貌似第1个方案更合理，而且工作量也不大，但打印字符这种和硬件相关的功能属于内核的范畴，用户需要打印输出时，它应该请求内核的服务，由内核帮助完成，这才是的理想模式，绝对不能让用户进程直接操作显卡。所以放弃第1种做法，干脆在初始化用户进程寄存器时，直接将GS赋值为0。用户进程将来在打印输出时，是需要通过系统调用陷入内核来完成的，到时用户进程的CPL会由3变成0，执行的是内核的代码，那时再将GS赋值为内核使用的显存段选择子即可。
所以，必须得把为GS赋值的代码放在打印时必须要调用的函数中，它是各种打印的核心。
> 陷入内核后的用户进程，由于其GS已经被置为内核视频段描述符的选择子，其指向的DPL依然为0，故从内核态返回后，GS又会被CPU置为0。
# 字符串函数
## memset
memset函数用于内存区域的数据初始化，原理是逐字节地把value写入起始内存地址为~的size个空间，在本系统中通常用于内存分配时的数据清0。
memcpy函数用于内存数据拷贝，原理是将src起始的size个字节复制到`dst_`，逐字节拷贝。
memcmp函数用于一段内存数据比较，分别以两个地址a和b为起始，如果在size个字节内，a中的某个内存字节的数值（或ASCII码）大于b中同一相对位置的内存数值，此时返回1，如果这两个地址中，同一位置的所有值都相等，则返回0，否则返回−1。
```c
#include "string.h"
#include "global.h"
#include "debug.h"  //定义了ASSERT

//将dst起始的size个字节置为value，这个函数最常用的用法就是来初始化一块内存区域，也就是置为ASCII码为0
void memset(void* dst_, uint8_t value, uint32_t size) {
    ASSERT(dst_ != NULL);            //一般开发都有这个习惯，传入进来个地址，判断不是空
    uint8_t* dst = (uint8_t*)dst_;   //强制类型转换，将对地址的操作单位变成一字节
    while (size-- > 0)               //先判断size是否>0，然后再减，然后执行循环体，size是多少，就会循环多少次
        *dst++ = value;               //*的优先级高于++，所以是先对dst指向的地址进行操作(*dst=value)，然后地址+1
}

//将src地址起始处size字节的数据移入dst，用于拷贝内存数据
//src起始是有数据的，所以用const void*，const修饰void*，意味着地址内的数据是只读
void memcpy(void* dst_, const void* src_, uint32_t size) {
    ASSERT(dst_ != NULL && src_ != NULL);
    uint8_t* dst = dst_;
    const uint8_t* src = src_;
    while (size-- > 0)
        *dst++ = *src++;
}

//比较两个地址起始的size字节的数据是否相等，如果相等，则返回0；如果不相等，比较第一个不相等的数据，>返回1，<返回-1
int memcmp(const void* a_, const void* b_, uint32_t size) {
    const char* a = a_;
    const char* b = b_;
    ASSERT(a != NULL || b != NULL);
    while (size-- > 0) {
        if(*a != *b) {
	        return *a > *b ? 1 : -1; 
        }
    a++;
    b++;
    }
   return 0;
}
```
## strcpy
strcpy函数用于把起始于地址src的字符串复制到地址`dst_`，这和memcpy原理相同，只不过strcpy以src处的字符’0’作为终止条件，memcpy以拷贝的字节数size为终止条件。
strlen函数用于返回字符串的长度，即字符数。
strcmp函数用于比较起始地址分别为a和b的两个字符串是否相等，若a中某个字符的ASCII值大于b中同一相对位置字符的ASCII值，此时返回1，若字符都相同，则返回0，否则返回−1。同memcpy的原理相同，区别就是strcmp以地址a处的字符串的长度，也就是直到字符0为终止条件，memcpy的终止条件是size个比对的字节。
strchr返回的是字符ch在字符串str中，从左到右最先出现的所在地址，并不是下标。
```c
//将字符串从src拷贝到dst,并返回目的字符串的起始地址
char* strcpy(char* dst_, const char* src_) {
    ASSERT(dst_ != NULL && src_ != NULL);
    char* r = dst_;		       // 用来返回目的字符串起始地址
    while((*dst_++ = *src_++));  //1、*dst=*src  2、判断*dst是否为'\0'，然后决定是否执行循环体，本步骤真假值不影响3   3、dst++与scr++，谁先谁后不知道
    return r;                    //上面多出来的一对括号，是为了告诉编译器，我这里的=就是自己写的，而不是将==错误写成了=
}

/* 返回字符串长度 */
uint32_t strlen(const char* str) {
    ASSERT(str != NULL);
    const char* p = str;
    while(*p++);                 //1、先取*p的值来进行2的判断     2、判断*p,决定是否执行循环体     3、p++(这一步的执行并不依赖2的判断为真) 
    return (p - str - 1);        //p最后指向'\0'后面第一个元素
}

//比较两个字符串，若a_中的字符与b_中的字符全部相同，则返回0，如果不同，那么比较第一个不同的字符，如果a_>b_返回1，反之返回-1
int8_t strcmp (const char* a, const char* b) {
    ASSERT(a != NULL && b != NULL);
    while (*a != 0 && *a == *b) {
        a++;
        b++;
    }
/* 如果*a小于*b就返回-1,否则就属于*a大于等于*b的情况。在后面的布尔表达式"*a > *b"中,
 * 若*a大于*b,表达式就等于1,否则就表达式不成立,也就是布尔值为0,恰恰表示*a等于*b */
    return *a < *b ? -1 : *a > *b;
}

/* 从左到右查找字符串str中首次出现字符ch的地址(不是下标,是地址) */
char* strchr(const char* str, const uint8_t ch) {
    ASSERT(str != NULL);
    while (*str != 0) {
        if (*str == ch) {
	        return (char*)str;	    // 需要强制转化成和返回值类型一样,否则编译器会报const属性丢失,下同.
        }
        str++;
    }
    return NULL;
}
```
## strrchr
strrchr函数返回的是从后往前查找字符串str中首次出现字符ch的地址，注意，是字符在字符串中的地址，并不是下标值。此函数虽然是从后往前找，但原理上是通过从前往后（从左到右）的顺序查找的，这样的好处是无需事先知道字符串的结束字符’\0’的地址。
strcat函数的功能是字符串拼接，将src处的字符串接在dst的结尾处，并将dst返回。实现原理是将src处的字符串拷贝到dst_的结束处。
strchrs函数用于返回字符ch在字符串str中出现的次数。
```c
/* 从后往前查找字符串str中首次出现字符ch的地址(不是下标,是地址) */
char* strrchr(const char* str, const uint8_t ch) {
    ASSERT(str != NULL);
    const char* last_char = NULL;
    /* 从头到尾遍历一次,若存在ch字符,last_char总是该字符最后一次出现在串中的地址(不是下标,是地址)*/
    while (*str != 0) {
        if (*str == ch) {
	        last_char = str;
        }
        str++;
    }
    return (char*)last_char;
}

/* 将字符串src_拼接到dst_后,将回拼接的串地址 */
char* strcat(char* dst_, const char* src_) {
    ASSERT(dst_ != NULL && src_ != NULL);
    char* str = dst_;
    while (*str++);
    --str;                       // 别看错了，--str是独立的一句，并不是while的循环体。这一句是为了让str指向dst_的最后一个非0字符
    while((*str++ = *src_++));	//1、*str=*src  2、判断*str     3、str++与src++，这一步不依赖2
    return dst_;
}

/* 在字符串str中查找指定字符ch出现的次数 */
uint32_t strchrs(const char* str, uint8_t ch) {
    ASSERT(str != NULL);
    uint32_t ch_cnt = 0;
    const char* p = str;
    while(*p != 0) {
        if (*p == ch) {
            ch_cnt++;
        }
        p++;
    }
    return ch_cnt;
}
```
# assert
两种断言，一种是为内核系统使用的ASSERT，另一种是为用户进程使用的assert，本节先实现专供内核使用的ASSERT。
一方面，当内核运行中出现问题时，多属于严重的错误，没必要再运行下去。另一方面，断言在输出报错信息时，屏幕输出不应该被其他进程干扰。综上两点原因，ASSERT排查出错误后，最好在关中断的情况下打印报错信息。
在C语言中ASSERT是用宏来定义的，其原理是判断传给ASSERT的表达式是否成立，若表达式成立则什么都不做，否则打印出错信息并停止执行，仿照它来实现自己的版本。
```c
#ifndef __KERNEL_DEBUG_H
#define __KERNEL_DEBUG_H
void panic_spin(char* filename, int line, const char* func, const char* condition);

#define PANIC(...) panic_spin (__FILE__, __LINE__, __func__, __VA_ARGS__)

//如果定义了NDEBUG,那么下面定义的ASSERT就是个空。这样可以便捷的让所有ASSERT宏失效。因为有时候断言太多，程序会运行
//很慢。如果不想要ASSERT起作用，编译时用gcc-DNDEBUG就行了
#ifdef NDEBUG
   #define ASSERT(CONDITION) ((void)0)
#else
#define ASSERT(CONDITION)   \
    if(CONDITION){}         \
    else{PANIC(#CONDITION);}    //加#后，传入的参数变成字符串

#endif  //结束#ifdef NDEBUG

#endif  //结束#define __KERNEL_DEBUG_H
```
判断CONDITION条件为真时，其后的大括号中为空，即如前所述，什么都不做。否则条件为假时，调用另外一个宏PANIC(#CONDITION)，此宏是ASSERT采取行动的部分：
```c
#define PANIC(...) panic_spin (__FILE__, __LINE__, __func__, __VA_ARGS__)
```
上面的预处理命令define是将PANIC(...)定义为panic_spin函数，此函数定义在debug.o中。
(...)是C预处理器所支持的一种用法，它允许宏支持个数不固定的参数，"..."表示所定义的宏其参数可变，即成为参数个数可变的宏。
预处理器为此专门提供了一个标识符＿VA_ARGS＿，它只允许在具有可变参数的宏替换列表中出现，它代表所有与省略号“…”相对应的参数。该参数至少有一个，但可以为空。所以，传给panic spin的其中一个参数是＿VA_ARGS＿。同样作为参数的还有＿FILE＿，＿LINE＿，＿func＿，这三个是预定义的宏，分别表示被编译的文件名、被编译文件中的行号、被编译的函数名。
调用PANIC的形式为PANIC(#CONDITION) ，即形参为#CONDITION，其中字符’#’的作用是让预处理器把CONDITION转换成字符串常量。比如CONDITION若为var != 0，#CONDITION的效果是变成了字符串“var != 0”。于是，传给panic_spin函数的第4个参数＿VA_ARGS＿，实际类型为字符串指针。
ASSERT是在调试过程中使用的，宏毕竟是一段代码，经预处理器展开后，调用宏的地方越多，程序体积越大，所以执行得越慢。所以，当不再调试时，就应该让此宏失效，这样编译出来的程序才比较小，运行会稍快一些。
这里可利用#define宏定义的功能让宏等于空值，这就是`#define ASSERT(CONDITION) ((void)0)`的作用，让此ASSERT成为空0，也就是什么都不是，这样就相当于删除了ASSERT。
宏是预处理器提供的功能，是在预处理阶段处理的，所以让其为空的条件也得在预处理阶段判断才行。用预处理指令#ifdef判断，如果定义了宏NDEBUG，就使ASSERT等于(void)0。此宏NDEBUG可以在gcc编译时指定，只要用gcc的参数-D来定义NDEBUG就行了，如gcc–DNDEBUG，不过通常将“–DNDEBUG”定义在makefile中。
下述是debug.c中的panic_spin：
```c
#include "debug.h"
#include "print.h"
#include "interrupt.h"  //关闭中断函数在里面

/* 打印文件名,行号,函数名,条件并使程序悬停 */
void panic_spin(char* filename, int line, const char* func, const char* condition) 
{
   intr_disable();	//发生错误时打印错误信息，不应该被打扰
   put_str("\n\n\n!!!!! error !!!!!\n");
   put_str("filename:");put_str(filename);put_str("\n");
   put_str("line:0x");put_int(line);put_str("\n");
   put_str("function:");put_str((char*)func);put_str("\n");
   put_str("condition:");put_str((char*)condition);put_str("\n");
   while(1);
}
```
# 端口I/O函数
```c
#ifndef __LIB_IO_H
#define __LIB_IO_H
#include "stdint.h"

 //一次送一字节的数据到指定端口，static指定只在本.h内有效，inline是让处理器将函数编译成内嵌的方式，就是在该函数调用处原封不动地展开
 //此函数有两个参数，一个端口号，一个要送往端口的数据
static inline void outb(uint16_t port, uint8_t data) {
/*********************************************************
 a表示用寄存器al或ax或eax,对端口指定N表示0~255, d表示用dx存储端口号, 
 %b0表示对应al,%w1表示对应dx */ 
   asm volatile ( "outb %b0, %w1" : : "a" (data), "Nd" (port));    
}

//利用outsw（端口输出串，一次一字）指令，将ds:esi指向的addr处起始的word_cnt(存在ecx中)个字写入端口port,ecx与esi会自动变化
static inline void outsw(uint16_t port, const void* addr, uint32_t word_cnt) {
/*********************************************************
   +表示此限制即做输入又做输出.
   outsw是把ds:esi处的16位的内容写入port端口, 我们在设置段描述符时, 
   已经将ds,es,ss段的选择子都设置为相同的值了,此时不用担心数据错乱。*/
   asm volatile ("cld; rep outsw" : "+S" (addr), "+c" (word_cnt) : "d" (port));
}                                       //S表示寄存器esi/si

/* 将从端口port读入的一个字节返回 */
static inline uint8_t inb(uint16_t port) {
   uint8_t data;
   asm volatile ("inb %w1, %b0" : "=a" (data) : "Nd" (port));
   return data;
}

/* 将从端口port读入的word_cnt个字写入addr */
static inline void insw(uint16_t port, void* addr, uint32_t word_cnt) {
/******************************************************
   insw是将从端口port处读入的16位内容写入es:edi指向的内存,
   在设置段描述符时, 已经将ds,es,ss段的选择子都设置为相同的值了,
   此时不用担心数据错乱。*/
   asm volatile ("cld; rep insw" : "+D" (addr), "+c" (word_cnt) : "d" (port) : "memory");
}                                   //D表示寄存器edi/di                       //通知编译器，内存已经被改变了

#endif
```
对8259A或任何硬件的控制都要通过端口，之前在操作硬盘或显卡时，都是用Intel语法风格的汇编语言编写的。现在把常用的端口读写功能封装成C函数。
平时都是把函数体放在.c文件中，头文件只用于存放函数声明，如果函数是全局作用域的话，链接后，外部文件就可以调用该函数了，所以一般情况下头文件都作为功能模块的接口而存在，头文件中对应的函数在程序中也只会存在一份。而的io.h却是函数的实现，并且里面**各函数的作用域都是static，这表明该函数仅在本文件中有效，对外不可见**。这意味着，凡是包含io.h的文件，都会获得一份io.h中所有函数的拷贝，也就是说同样功能的函数在程序中会存在多个副本。
这里的函数并不是普通的函数，它们都是**对底层硬件端口直接操作的，通常由设备的驱动程序来调用，为了快速响应，函数调用上需要更加高效**。而且，操作系统是为了让用户程序编写、执行更加方便才诞生的，归根结底是为了用户程序服务，所以它会让处理器的大多数时间花在3特权级的用户程序上。**为了让处理器更多地为用户程序服务，操作系统（包括硬件驱动程序）必须减少自己占用处理器的时间，所以，对硬件端口的操作，只要求快。**
但一般的函数调用需要涉及到现场保护及恢复现场，即函数调用前要把相关的栈、返回地址（CS和EIP）保存到栈中，函数执行完返回后再将它们从栈中恢复到寄存器。栈毕竟是内存，速度低很多，而且入栈、出栈这么多内存操作，对于想方设法提速的内核程序来说是无法忍受的。
因此，为了提速，在实现中，函数的存储类型都是static，并且加了inline关键字，它建议处理器将函数编译为内嵌的方式，将所调用的函数体的内容，在该函数的调用处，原封不动地展开，这样编译后的代码中**将不包含call指令，也就不属于函数调用了，而是顺次执行**。虽然这会让程序大一些，但**减少了函数调用及返回时的现场保护及恢复工作，提升了效率还是值得的**。
io.h中就定义了4个函数，分别是：
1. 一次写入1个字节的outb函数。
2. 一次写入多个字的outsw函数，是以2字节为单位的。
3. 一次读入1个字节的inb函数。
4. 一次读入多个字的insw函数，同样以2字节为单位。
下面介绍**outb**：
outb函数接受两个参数，参数port是16位无符号整型的端口号，此类型可容纳Intel所支持的65536个端口号，参数data是1字节的整型数据，outb的功能是将data中的1字节数据写入port所指向的端口。
```c
asm volatile ("outb %b0, %w1" : : "a" (data), "Nd" (port));
```
outb指令格式为outb %al，%dx，其中%al是源操作数，指的是8位数据，%dx是目的操作数，指的是数据所写入的端口。要做的是通过gcc提供的各种约束和机器模式操作码将内联汇编形式凑成outb %al，%dx。
从右边的input开始看，形参变量port的约束有2个，分别是N和d。N为立即数约束，它表示0～255的立即数，也就是8位1字节所表示的范围，这样把写入的数据限制在1字节之内。d为寄存器约束，它表示让gcc为port分配的寄存器可以是dl、dx或edx。outb的目的操作数是dx，得想办法将寄存器明确为dx。这可以用操作码w来实现，它表示使用寄存器的HImode名称，即寄存器中2字节的那个可独立使用的部分，也就是[a-d]x。操作码是跟序号占位符配合在一起来使用的，所以操作码w要随着序号占位符在内联汇编的assembly code中使用。port所对应约束的序号占位符是%1，目的是使用dx寄存器，所以用%w1来限制目的操作数为寄存器dx。
data变量对应的约束为a，这表示用寄存器al、ax或eax来存储该变量的值，outb指令的源操作数是寄存器al，也必须将源操作数使用的寄存器明确为al才行。这可以通过机器模式操作码b来实现，操作码b表示寄存器的QImode部分，也就是寄存器中最低8位可独立使用的部分，即[a-d]l。同理，在assembly code中用%b0表示al寄存器。
下面介绍**insw**：
```c
asm volatile ("cld; rep insw" : "+D" (addr), "+c" (word_cnt) : "d" (port) : "memory");
```
insw接受三个参数，无符号16位整型变量port是待读入的端口号，空指针变量addr是数据缓冲区，用于存储读出来的数据，无符号32位整型变量word_cnt是以字（2字节）为单位的数据单位量。insw函数的功能是将从端口port读入的word_cnt个字写入addr。
insw函数的核心是用同名汇编指令**insw来实现的，该指令的功能是从端口port处读入16位数据并写入es:edi指向的内存**，即一次读入2字节。
虽然要指定段寄存器es，但平坦模型下所有内存数据都在同一个4GB的大段中，即段基址为0，段界限为4GB-1。在loader中初始化全局描述符表进入保护模式后，早已经把段寄存器ds、es、ss都指定为相同的数据段选择子（fs未使用，所以未做初始化），见图。所以es和ds指向的是同一个基址为0的段，只要指定偏移地址就行。
平坦模型下的编译器，其所编译出来的程序中的符号地址自然按照平坦模型来编排，即默认段基址为0，符号地址其实就是偏移地址。指针变量用来存储其他符号的地址，也就是说，此处指针变量addr中的值便是偏移地址，只要把addr的值约束到edi寄存器就行了。于是，**在output中，"+D" (addr)表示用寄存器约束D将变量addr的值约束到EDI中**。
![image-20230619160443998](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230619160443998.png)
insw函数实现的是将多个字从指定端口读出，而汇编指令insw执行一次只能从端口读取2字节的数据，所以这必然涉及到循环执行，这里用的是重复指令rep，它把寄存器ecx作为循环计数器，每执行一次，ecx的值就减1，直到ecx为0时停止执行。因此"+c" (word_cnt)便是把word_cnt的值约束到寄存器ecx中作为循环次数。寄存器edi和ecx先被读入，又被写入，同时作为指令的输入和输出，因此必须使用+。
> +表示所修饰的约束既做输入（位于input中），也做输出（位于output中），也就是告诉gcc所约束的寄存器或内存先被读入，再被写入。

数据复制需要使用以下三个指令：
1. 字符串搬运指令族movs[dw]
2. 重复执行指令rep
3. 方向指令cld和std
其实后两个是固定不变的，第1个字符串搬运指令可以替换为其他以DS:[E]SI作为数据源地址，以ES:[E]DI作为目的地址的字符串操作（传输）指令，这里的insw相当于movsw。movsw用到了esi和edi，所以这两个寄存器的值都会自动更新，但insw只用到了edi，所以只会更新edi，不会更新esi
每执行一次insw指令，insw要把ES:EDI作为数据缓冲区，这时EDI作为insw指令的输入。由于在insw执行前已经用cld指令清除了方向位DF，故insw指令执行后，EDI的值自动加2，这时EDI作为输出。
rep用ecx控制执行后面指令insw的次数，所以每次先要读取ecx的值判断是否为0，这时ecx作为输入，执行完后，ecx要减1，这时ecx作为输出。
"d" (port)就是把端口号port的值约束到dx寄存器中。
这里还用到了内存破坏memory，由于insw指令往内存es:edi处写入了数据，所以通知gcc这块内存已经改变。如果在output和input中通过寄存器约束指定了寄存器，gcc必然会知道这些寄存器会被修改，因此edi不需要在clobber/modify中声明。
# 双向链表
```c
#ifndef __LIB_KERNEL_LIST_H
#define __LIB_KERNEL_LIST_H
#include "global.h"

//用于计算一个结构体成员在结构体中的偏移量
#define offset(struct_type,member_name) (int)(&(((struct_type*)0)->member_name))
//用于通过一个结构体成员地址计算出整个结构体的起始地址
#define member_to_entry(struct_type,member_name,member_ptr) (struct_type*)((int)member_ptr-offset(struct_type,member_name))

#define elem2entry(struct_type, struct_member_name, elem_ptr) \
		(struct_type*)((int)elem_ptr - offset(struct_type, struct_member_name))

/**********   定义链表结点成员结构   ***********
*结点中不需要数据成元,只要求前驱和后继结点指针*/
struct list_elem {
   struct list_elem* prev; // 前躯结点
   struct list_elem* next; // 后继结点
};

/* 链表结构,用来管理整个队列 */
struct list {
/* head是队首,是固定不变的，不是第1个元素,第1个元素为head.next */
   struct list_elem head;
/* tail是队尾,同样是固定不变的 */
   struct list_elem tail;
};

//定义个叫function的函数类型，返回值是int，参数是链表结点指针与一个整形值
typedef bool (function)(struct list_elem*, int arg);

void list_init (struct list* list);
void list_insert_before(struct list_elem* before, struct list_elem* elem);
void list_push(struct list* plist, struct list_elem* elem);
void list_iterate(struct list* plist);
void list_append(struct list* plist, struct list_elem* elem);
void list_remove(struct list_elem* pelem);
struct list_elem* list_pop(struct list* plist);
bool list_empty(struct list* plist);
uint32_t list_len(struct list* plist);
struct list_elem* list_traversal(struct list* plist, function func, int arg);
bool elem_find(struct list* plist, struct list_elem* obj_elem);

#endif
```
结构体struct list_elem是链表中结点的结构，这是链表的核心。一般的链表结点中除了前驱或后继结点的指针外，还包括数据成员，即链表结点是数据的存储单元。但本结点只有前驱结点指针prev和后继结点指针next，不包含数据成员，因为不需要。
list是定义双向链表的结构体，head和tail的数据类型都是struct list_elem，head.next是链表中第1个元素结点，tail.prev是链表中最后一个元素结点，以后在链表中插入结点时，都是插入在head和tail之间。head.prev和tail.next的值无意义，在初始化时会被置为空。
> 文件开头定义的两个宏member_to_entry和offset是为了将结点元素转换成实际元素项。

list.c中用到了关中断的函数intr_disable，将来的进程调度机制依靠时钟中断，此处把中断关闭，就避免了在检索位图时被换下CPU的可能。所以，对于此例子中的位图操作，一定要保证是在关中断的情况下进行，而实现原子操作，关中断只是一种方式，将来会用锁来保证。
函数list_init只接受一个参数list，功能是初始化双向链表list。此时钟表是空的，因此函数内部的初始化工作就是把表头head和表尾tail连接起来，即`list->head.next = &list->tail`和`list->tail.prev = &list->head`。head.prev和tail.next的值无意义，因此被置为NULL。
```c
/* 初始化双向链表list */
void list_init (struct list* list) {
   list->head.prev = NULL;
   list->head.next = &list->tail;
   list->tail.prev = &list->head;
   list->tail.next = NULL;
}
```
函数list_insert_before接受两个参数，before和elem，它们皆为链表结点的指针，此函数功能是把链表元素elem插入在元素before之前。由于队列是公共资源，对于它的修改一定要保证为原子操作，所以通过intr_disable将中断关闭，旧中断状态用变量old_status保存，操作结束后通过`intr_set_status(old_status)`将中断恢复。
```c
/* 把链表元素elem插入在元素before之前 */
void list_insert_before(struct list_elem* before, struct list_elem* elem) { 
    enum intr_status old_status = intr_disable();        //未来这个链表结点插入是用于修改task_struck队列的，这是个公共资源，所以需要不被切换走

    /* 将before前驱元素的后继元素更新为elem, 暂时使before脱离链表*/ 
    before->prev->next = elem; 

    /* 更新elem自己的前驱结点为before的前驱,更新elem自己的后继结点为before, 于是before又回到链表 */
    elem->prev = before->prev;
    elem->next = before;

    /* 更新before的前驱结点为elem */
    before->prev = elem;

    intr_set_status(old_status);     //关中断之前是开着，那么现在就重新打开中断，如果关着，那么就继续关着
}
```
函数list_push接受两个参数，plist是链表，elem是链表结点，功能是添加元素elem到列表plist的队首，其实这就是栈的特性，后进先出，因此相当于用链表实现了栈。其内部是调用“list_insert_before(plist->head.next, elem)”实现的，即在队头head.next的前面插入elem。
```c
/* 添加元素到列表队首,类似栈push操作，添加结点到链表队首，类似于push操作, 参数1是链表的管理结点，参数2是一个新结点 */
void list_push(struct list* plist, struct list_elem* elem) {
   list_insert_before(plist->head.next, elem); // 在队头插入elem
}
```
函数list_append接受两个参数，plist是链表，elem是链表结点，功能是添加元素elem到列表plist的队尾。
```c
/* 追加元素到链表队尾,类似队列的先进先出操作，添加结点到队尾，实际上就是添加结点到管理结点之前。参数是管理结点与要添加的结点 */
void list_append(struct list* plist, struct list_elem* elem) {
   list_insert_before(&plist->tail, elem);     // 在队尾的前面插入
}
```
函数list_remove接受一个参数，链表结点pelem，功能是将pelem从链表中去除。此函数也是对链表修改，所以为了保证原子性，同样先将中断关闭，完成操作后再恢复。
```c
/* 使元素pelem脱离链表 */
void list_remove(struct list_elem* pelem) {
   enum intr_status old_status = intr_disable();
   
   pelem->prev->next = pelem->next; // 让pelem前躯的后继结点指向pelem的后继结点
   pelem->next->prev = pelem->prev; // 让pelem后继的前躯结点指向pelem的前躯结点

   intr_set_status(old_status);
}
```
函数list_pop只接受一个参数，链表plist，功能是将链表plist的第一个结点弹出。
```c
/* 将链表第一个元素弹出并返回,类似栈的pop操作，参数是链表的管理结点（入口结点） */
struct list_elem* list_pop(struct list* plist) {
   struct list_elem* elem = plist->head.next;
   list_remove(elem);
   return elem;
} 
```
函数elem_find接受两个参数，链表plist和待查找的结点obj_elem，功能是从链表plist中查找元素obj_elem，成功时返回true，失败时返回false。
```c
/* 从链表中查找元素obj_elem,成功时返回true,失败时返回false */
bool elem_find(struct list* plist, struct list_elem* obj_elem) {
    struct list_elem* elem = plist->head.next;
    while (elem != &plist->tail) { // 把链表的第一个结点作为入口，通过while循环遍历链表中所有结点
        if (elem == obj_elem) {
            return true;
        }
        elem = elem->next;
    }
    return false;
}
```
函数list_traversal接受三个参数，链表plist、回调函数func及回调函数的参数arg，功能是遍历列表内所有元素，逐个判断是否有符合条件的元素结点，找到符合条件的结点返回结点指针，否则返回NULL。
```c
struct list_elem* list_traversal(struct list* plist, function func, int arg) {
    struct list_elem* elem = plist->head.next; // 用变量elem保存每一个结点
    /* 如果队列为空,就必然没有符合条件的结点,故直接返回NULL */
    if (list_empty(plist)) { 
        return NULL;
    }

    while (elem != &plist->tail) { // 对各个结点都调用func(elem, arg)
        if (func(elem, arg)) {	   // func返回ture则认为该元素在回调函数中符合条件,命中,故停止继续遍历
            return elem;
        }					  // 若回调函数func返回true,则继续遍历
        elem = elem->next;	       
    }
    return NULL;
}
```
函数list_len只接受一个参数，链表plist，功能是返回链表长度，即链表中结点的个数。
```c
/* 返回链表长度，不包含管理结点，参数就是链表的管理结点 */
uint32_t list_len(struct list* plist) {
   struct list_elem* elem = plist->head.next;
   uint32_t length = 0;
   while (elem != &plist->tail) {
      length++; 
      elem = elem->next;
   }
   return length;
}
```
函数list_empty只接受一个参数，链表plist，功能是判断链表plist是否为空，空时返回true，否则返回false。
```c
/* 判断链表是否为空,空时返回true,否则返回false */
bool list_empty(struct list* plist) {		
    // 判断链表plist第一个结点是否指向链表plist的尾
    return (plist->head.next == &plist->tail ? true : false);
}
```
# 线程阻塞与唤醒
实现阻塞功能的方法就是不让线程在就绪队列中出现，这样线程便没有机会运行，也就是实现线程的阻塞。
调度器只负责挑选有运行意愿、准备好运行的线程上处理器运行，如果线程没有运行的意愿，调度器也不能强迫它，原因是运行的条件不具备，停止运行实属无奈。调度器的功能只是去挑选哪个线程运行，即使再差的调度算法也会保证每个线程都有运行的机会，哪怕只是运行几个时钟周期。因此，**调度器并不决定线程是否可以运行，只是决定了运行的时机，线程可否运行是由线程自己把控的**。
阻塞是一种意愿，表达的是线程运行中发生了一些事情，这些事情通常是由于缺乏了某些运行条件造成的，以至于线程不得不暂时停下来，必须等到运行的条件再次具备时才能上处理器继续运行。因此，**阻塞发生的时间是在线程自己的运行过程中，是线程自己阻塞自己，并不是被谁阻塞**。而唤醒已阻塞的线程是由别的线程，通常是锁的持有者来做的。
> 值得注意的是线程阻塞是线程执行时的动作，因此线程的时间片还没用完，在唤醒之后，线程会继续在剩余的时间片内运行，不会再用线程的优先级priority为时间片ticks赋值。

```c
// 当前线程将自己阻塞，线程pcb中的状态字段设定为传入的status
void thread_block(enum task_status stat) {
   // stat取值为TASK_BLOCKED,TASK_WAITING,TASK_HANGING,也就是只有这三种状态才不会被调度
   ASSERT(((stat == TASK_BLOCKED) || (stat == TASK_WAITING) || (stat == TASK_HANGING)));
   enum intr_status old_status = intr_disable();      // 先关闭中断，因为涉及要修改阻塞队列，调度
   struct task_struct* cur_thread = running_thread(); // 得到当前正在运行的进程的pcb地址
   cur_thread->status = stat;    // 置其状态为stat 
   schedule();		               // 将当前线程换下处理器
   intr_set_status(old_status);  // 只有在当前线程被唤醒后才会被执行到
}
```
thread_block接受一个参数stat，stat是线程的状态，取值为不可运行态，函数功能是将当前线程的状态置为stat，从而实现线程的阻塞。函数中不包括指向其他线程的指针，因此是当前线程自己调用thread_block阻塞自己，线程并不能被别人强制阻塞，在时间片内，任何线程被换下处理器都是出于主动和自愿。
stat取值范围是TASK_BLOCKED、TASK_WAITING和TASK_HANGING，这三个就是上面所说的不可运行态，后两个将来会用到。在系统中只有status为TASK_RUNNING的线程才可以被添加到就绪队列thread_ready_list，才有机会上处理器运行。
当前运行线程的status必然是TASK_RUNNING，此状态的线程在调度器中会被重新加到就绪队列中。由于要实现的功能是线程阻塞，也就是当前线程暂时不能运行。达到这一目的的原理是：**让调度器schedule无法再调度它，也就是当前线程不能再被加到就绪队列thread_ready_list中**。
在调度器schedule函数中，它会对当前线程的status判断。若当前线程的status为TASK_RUNNING，这说明当前线程只是时间片到了，此次调度并不是由于阻塞而引发的，因此会将其重新加入到就绪队列中并置其状态为TASK_READY。为了不让其再被调度，必须将其status置为非TASK_RUNNING，也就是函数thread_block的参数stat。于是获取当前线程，并置其status为stat，之后便调用schedule重新调度下一任务。
```c
// 将线程pthread解除阻塞
void thread_unblock(struct task_struct* pthread) {
   enum intr_status old_status = intr_disable();               // 涉及队就绪队列的修改，此时绝对不能被切换走
   ASSERT(((pthread->status == TASK_BLOCKED) || (pthread->status == TASK_WAITING) || (pthread->status == TASK_HANGING)));
   if (pthread->status != TASK_READY) {
      ASSERT(!elem_find(&thread_ready_list, &pthread->general_tag));
      if (elem_find(&thread_ready_list, &pthread->general_tag)) {
	      PANIC("thread_unblock: blocked thread in ready_list\n");
      }
      list_push(&thread_ready_list, &pthread->general_tag);    // 放到队列的最前面，使其尽快得到调度
      pthread->status = TASK_READY;
   } 
   intr_set_status(old_status);
}
```
函数thread_unblock将某线程解除阻塞，也就是唤醒某线程。被阻塞的线程已无法运行，无法自己唤醒自己，必须被其他线程唤醒，因此参数pthread指向的是目前已经被阻塞，又希望被唤醒的线程。函数thread_unblock是由当前运行的线程调用的，由它实施唤醒动作。
按常理说就绪队列中不会出现已阻塞的线程，但还是担心有些意外情况会导致阻塞的线程已经在就绪队列中，为防止已经在就绪队列中的线程再次被添加，通过ASSERT判断。这个判断还是需要的，因此由if结合PANIC宏再次判断这种重复添加的情况。
接着通过list_push将阻塞的线程重新添加到就绪队列，这里用list_push是将线程添加到就绪队列的队首，因此保证这个睡了很久的线程能被优先调度。最后再将线程的status置为TASK_READY，至此，线程重新回到了就绪队列，它有再被调度的机会，即唤醒。
# 实现锁
```c
// 信号量结构 
struct semaphore {
   uint8_t  value;              
   struct   list waiters;       // 用一个双链表结点来管理所有阻塞在该信号量上的线程
};

// 锁结构 
struct lock {
   struct   task_struct* holder;	    
   struct   semaphore semaphore;	    
   uint32_t holder_repeat_nr;		    
};
```
struct semaphore为信号量结构，信号量要有初值，因此该结构中包含了成员value，对信号量进行down操作时，若信号量值为0就会阻塞线程，因此该结构中还包括成员waiters，用它来记录在此信号量上等待（阻塞）的所有线程。
struct lock是锁结构。谁成功申请锁，就应该记录锁被谁持有，这是用成员holder记录的，表示锁的持有者。锁是基于信号量来实现的，因此锁结构中必须包含一个信号量成员，这里就是semaphore，它就是信号量结构体struct semaphore实例。将来此信号量的初值会被赋值为1，也就是用二元信号量实现锁。成员**holder_repeat_nr用来累积锁的持有者重复申请锁的次数**，释放锁的时候会参考此变量的值。
> 原因有可能存在持有了某临界区的锁后，在未释放锁之前，再次调用重复申请此锁的函数的情况，这种情况下内外层函数在释放锁时会对同一个锁释放两次，为了避免这种情况的发生，用此变量来累积重复申请的次数，释放锁时会根据变量holder_repeat_nr的值来执行具体动作。

```c
// 用于初始化信号量，传入参数就是指向信号量的指针与初值
void sema_init(struct semaphore* psema, uint8_t value) {
   psema->value = value;               // 为信号量赋初值
   list_init(&psema->waiters);         // 初始化信号量的等待队列
}

// 用于初始化锁，传入参数是指向该锁的指针
void lock_init(struct lock* plock) {
   plock->holder = NULL;
   plock->holder_repeat_nr = 0;
   sema_init(&plock->semaphore, 1);
}

// 信号量的down操作
void sema_down(struct semaphore* psema) {
   enum intr_status old_status = intr_disable();         // 对于信号量的操作，关中断保证原子操作

   // 线程醒来后依然对信号量做判断，确保锁目前未被持有
   while(psema->value == 0) {	// 若value为0，表示锁已经被持有
      ASSERT(!elem_find(&psema->waiters, &running_thread()->general_tag));
      // 当前线程不应该出现在此信号量的等待队列中
      if (elem_find(&psema->waiters, &running_thread()->general_tag)) {
         PANIC("sema_down: thread blocked has been in waiters_list\n");
      }
      // 如果此时信号量为0，那么就将该线程加入阻塞队列
      // 为什么不用判断是否在阻塞队列中？因为线程被阻塞后，会加入阻塞队列，除非被唤醒，否则不会
      // 分配到处理器资源，自然也不会重复判断是否有信号量，也不会重复加入阻塞队列
      list_append(&psema->waiters, &running_thread()->general_tag); 
      thread_block(TASK_BLOCKED);    // 阻塞线程，直到被唤醒
   }
   // 若value为1或被唤醒后，会执行下面的代码，也就是获得了锁
   psema->value--;
   ASSERT(psema->value == 0);

   intr_set_status(old_status);
}

// 信号量的up操作
void sema_up(struct semaphore* psema) {
   enum intr_status old_status = intr_disable();      // 对于信号量的操作，关中断保证原子操作
   ASSERT(psema->value == 0);	    
   if (!list_empty(&psema->waiters)) {                // 判断信号量阻塞队列应为非空，这样才能执行唤醒操作
      struct task_struct* thread_blocked = elem2entry(struct task_struct, general_tag, list_pop(&psema->waiters));
      thread_unblock(thread_blocked);
   }
   psema->value++;
   ASSERT(psema->value == 1);	    
   intr_set_status(old_status);
}

// 获取锁的函数
void lock_acquire(struct lock* plock) {         // 排除掉线程自己已经持有锁，但是还没有释放就重新申请的情况
   if (plock->holder != running_thread()) {     // 如果自己尚未持有此锁
        sema_down(&plock->semaphore);
        plock->holder = running_thread();
        ASSERT(plock->holder_repeat_nr == 0);
        plock->holder_repeat_nr = 1;
   } else {                                     // 如果持有者已经是自己
        plock->holder_repeat_nr++;
   }
}

// 释放锁的函数
void lock_release(struct lock* plock) {
   ASSERT(plock->holder == running_thread());
   if (plock->holder_repeat_nr > 1) {      // 说明自己多次申请了该锁，现在还不能立即释放锁
      plock->holder_repeat_nr--;
      return;
   }
   ASSERT(plock->holder_repeat_nr == 1);    //  只有lock的重复持有数为1才能释放
   plock->holder = NULL;	   
   plock->holder_repeat_nr = 0;
   sema_up(&plock->semaphore);	   
}
```
### sema_init
sema_init接受两个参数，psema是待初始化的信号量，value是信号量的初值，函数功能是将信号量psema初值初始化为value。锁是用信号量来实现的，因此锁的初始化中会调用sema_init。
### lock_init
lock_init接受一个参数，plock是待初始化的锁。函数功能是将锁的持有者holder置为空，将持有者重复申请次数累积变量holder_repeat_nr置为0，并将锁使用的信号量初值赋值为1，即二元信号量。
### sema_down
sema_down接受一个参数，psema是待执行down操作的信号量。函数功能就是在信号量psema上执行down操作。
对于二元信号量来说，当信号量的值为1时，down操作才会成功返回，否则就在该信号上阻塞。这里通过while(psema->value == 0)判断信号量是否为0，如果为0，就进入while的循环体做两件事。
按理说，既然当前线程已处于活动中，也就是状态为TASK_RUNNING，当前线程就不会出现在此信号量的等待队列中，否则重复添加的话会破坏队列。因此，为避免异常情况发生，在做以上两件事之前，还是**用ASSERT和if排除当前线程已在等待队列中的情况**。
如果信号量不为0，也就是为1，或者之前为0，现在线程被唤醒后已经为1，则将信号量减1，即psema->value--。此时value的值应该为0，因此用ASSERT (`psema->value==0`)做判断。这是为防止程序出错时，出现value大于1的情况。
> 此处可以用if代替，只不过用while更通用，因为信号量的up操作是通过thread_unblock唤醒线程的，而thread_unblock会把阻塞的线程放在就绪队列的队首，因此会紧随当前锁的持有者之后调度，也就是当前锁持有者释放锁后，它会第一个获得锁。
### sema_up
sema_up接受一个参数，psema是待执行up操作的信号量。函数功能是将信号量的值加1。
sema_up是使信号量加1，这表示有信号资源可用，也就是其他线程可以申请锁了，因此在信号量的等待队列psema->waiters中通过list_pop弹出队首的第一个线程，并通过宏elem2entry将其转换成PCB，存储到thread_blocked中。然后将此线程唤醒。在将线程唤醒后，接下来将信号量值加1。
> 所谓的唤醒并不是指马上就运行，而是重新加入到就绪队列，将来可以参与调度，运行是将来的事。而且当前是在关中断的情况下，所以调度器并不会被触发。因此不用担心线程已经加到就绪队列中，但value的值还没变成1会导致出错。
### lock_acquire
lock_acquire接受一个参数，plock是所要获得的锁，函数功能是获取锁plock。有时候，线程可能会嵌套申请同一把锁，这种情况下再申请锁，就会形成死锁，即自己在等待自己释放锁。因此，在函数开头先判断自己是否已经是该锁的持有者。
如果持有者已经是自己，就将变量holder_repeat_nr++，除此之外什么都不做，然后函数返回。
如果自己尚未持有此锁的话，通过将锁的信号量减1，在sema_down中有可能会阻塞，不过早晚会成功返回的。成功后将当前线程记为锁的持有者，即plock->holder = running_thread()，然后将holder_repeat_nr置为1，表示第1次申请了该锁。
### lock_release
lock_release只接受一个参数，plock指向待释放的锁，函数功能是释放锁plock。当前线程应该是锁的持有者，所以用ASSERT判断了一下。
如果持有者的变量holder_repeat_nr大于1，这说明自已多次申请该锁，此时还不能真正将锁释放，因此只是将holder_repeat_nr--，随后返回。
如果锁持有者的变量holder_repeat_nr为1，说明现在可以释放锁，通过代码plock->holder = NULL将持有者置空，随后将holder_repeat_nr置为0，最后将信号量加1，自此，锁被真正释放。
要把持有者置空语句plock->holder = NULL放在sema_up操作之前。原因是释放锁的操作并不在关中断下进行，有可能会被调度器换下处理器。**若sema_up操作在前的话，sema_up会先把value置1，若老线程刚执行完sema_up，还未执行plock->holder = NULL便被换下处理器，新调度上来的进程有可能也申请这个锁**，value为1，因此申请成功，锁的持有者plock->holder将变成这个新进程的PCB。假如这个新线程还未释放锁又被换下了处理器，老线程又被调度上来执行，它会继续执行plock->holder = NULL，将持有者置空，这就乱了。