# User Process
## 定义并初始化TSS
```c
// 定义TSS的数据结构，在内存中TSS的分布就是这个结构体
// TSS是程序员提供，由CPU来维护的，定义好后，实例化一个tss，将此实例交给CPU
struct tss {
    uint32_t backlink;
    uint32_t* esp0;
    uint32_t ss0;
    uint32_t* esp1;
    uint32_t ss1;
    uint32_t* esp2;
    uint32_t ss2;
    uint32_t cr3;
    uint32_t (*eip) (void);
    uint32_t eflags;
    uint32_t eax;
    uint32_t ecx;
    uint32_t edx;
    uint32_t ebx;
    uint32_t esp;
    uint32_t ebp;
    uint32_t esi;
    uint32_t edi;
    uint32_t es;
    uint32_t cs;
    uint32_t ss;
    uint32_t ds;
    uint32_t fs;
    uint32_t gs;
    uint32_t ldt;
    uint16_t trace;
    uint16_t io_base;
};
static struct tss tss;

// update_tss_esp用来更新TSS中的esp0，这是学习Linux任务切换的方式，只修改TSS中的特权级0对应的栈
// 此函数将TSS中esp0修改为参数pthread的0级栈地址,也就是线程pthread的PCB所在页的最顶端
// 此栈地址是用户进程由用户态进入内核态时所用的栈，这和之前的内核线程地址是一样的
// 用户进程进入内核态后，除了拥有单独的地址空间外，其他方面和内核线程是一样的
void update_tss_esp(struct task_struct* pthread) {
    tss.esp0 = (uint32_t*)((uint32_t)pthread + PG_SIZE);
}

// GDT是在loader.S中进入保护模式时实现的，那时候用汇编语言直接生成的GDT。
// 进入内核后，已经用C语言编程了，现在还需要GDT中增加新的描述符
// 函数make_gdt_desc，专门生成描述符结构，此函数并不是直接在GDT中安装好描述符，只是返回生成的描述符。
// 此函数的实现是按照段描述符的格式来拼数据，在内部生成一局部描述符结构体变量structgdt_desc desc
// 后面把此结构体变量中的属性填充好后通过return返回其值。
// 用于创建gdt描述符，传入参数1，段基址，传入参数2，段界限；参数3，属性低字节，参数4，属性高字节(要把低四位置0，高4位才是属性)
static struct gdt_desc make_gdt_desc(uint32_t* desc_addr, uint32_t limit, uint8_t attr_low, uint8_t attr_high) {
    uint32_t desc_base = (uint32_t)desc_addr;
    struct gdt_desc desc;
    desc.limit_low_word = limit & 0x0000ffff;
    desc.base_low_word = desc_base & 0x0000ffff;
    desc.base_mid_byte = ((desc_base & 0x00ff0000) >> 16);
    desc.attr_low_byte = (uint8_t)(attr_low);
    desc.limit_high_attr_high = (((limit & 0x000f0000) >> 16) + (uint8_t)(attr_high));
    desc.base_high_byte = desc_base >> 24;
    return desc;
}

// 在gdt中创建tss并重新加载gdt
void tss_init() {
    put_str("tss_init start\n");
    uint32_t tss_size = sizeof(tss);
    memset(&tss, 0, tss_size); 	// 将全局变量tss清0后
    tss.ss0 = SELECTOR_K_STACK;	// 为其ss0字段赋0级栈段的选择子SELECTOR_K_STACK
    tss.io_base = tss_size;		// 将tss的io_base字段置为tss的大小tss_size，这表示此TSS中并没有IO位图
    // 有关IO位图的内容已经在IO特权级中介绍过，当IO位图的偏移地址大于等于TSS大小减1时，就表示没有IO位图
	
    // gdt段基址为0x900,把tss放到第4个位置,也就是0x900+0x20的位置

    //在gdt表中添加tss段描述符，在本系统的，GDT表的起始位置为0x00000900，那么tss的段描述就应该在0x920(0x900+十进制4*8)
    *((struct gdt_desc*)0xc0000920) = make_gdt_desc((uint32_t*)&tss, tss_size - 1, TSS_ATTR_LOW, TSS_ATTR_HIGH);
	
    
    // 在gdt中安装两个DPL为3的段描述符，分别是代码段和数据段，这是为用户进程提前做的准备
    // 它们在GDT中的位置基于TSS描述符顺延，分别是偏移GDT0x28和0x30的位置
    *((struct gdt_desc*)0xc0000928) = make_gdt_desc((uint32_t*)0, 0xfffff, GDT_CODE_ATTR_LOW_DPL3, GDT_ATTR_HIGH);
    *((struct gdt_desc*)0xc0000930) = make_gdt_desc((uint32_t*)0, 0xfffff, GDT_DATA_ATTR_LOW_DPL3, GDT_ATTR_HIGH);

    /* gdt 16位的limit 32位的段基址 */
    uint64_t gdt_operand = ((8 * 7 - 1) | ((uint64_t)(uint32_t)0xc0000900 << 16));   // 7个描述符大小
    asm volatile ("lgdt %0" : : "m" (gdt_operand));		// 将新的GDT重新加载
    asm volatile ("ltr %w0" : : "r" (SELECTOR_TSS));	// 将tss加载到TR
    put_str("tss_init and ltr done\n");	
}
```
函数tss_init除了用来初始化tss并将其安装到GDT中外，还另外在GDT中安装两个供用户进程使用的描述符，一个是DPL为3的数据段，另一个是DPL为3的代码段。
在GDT中安装TSS描述符。在调用make_gdt_desc后，其返回的描述符是安装在0xc0000920的地址，即`*((struct gdt_desc*)0xc0000920)`，其实此处用0x920也是可以的，因为把低端1MB空间的页表映射为同物理地址相同，并且把内核开始使用的第768个页表指向了同低端1MB空间相同的物理页，因此此时的0xc0000920可以用0x920代替。
为什么把TSS描述符放在0xc0000920的地址？32位保护模式下的描述符大小都是8字节，在GDT中第0个段描述符不可用，第1个为代码段，第2个为数据段和栈，第3个为显存段，因此把tss放到第4个位置，也就是0xc0000900+0x20的位置。
定义变量gdt_operand作为lgdt指令的操作数。lgdt的指令格式，其操作数是16位表界限&32位表的起始地址，这里要求表界限要放在前面，也就是操作数中前2字节的低地址处。到目前为止，在原有描述符的基础上又新增了3个描述符，加上第0个不可用的哑描述符，GDT中现在一共是7个描述符，因此表界限值为8 * 7 - 1。操作数中的高32位是GDT起始地址，在这里把GDT线性地址0xc0000900先转换成uint32_t后，再将其转换成uint64_t位（不可一步到位转为uint64_t），最后通过按位或运算符'|'拼合在一起。
目前的目标是在现有线程的基础上实现进程，创建线程是通过thread_start进行的，其内部实现的流程如图11-11所示。
在thread_start(…,function,…)的调用中，function是最终在线程中执行的函数。在thread_start内部，先是通过get_kernel_pages(1)在内核内存池中获取1个物理页做线程的pcb，即thread，接着调用init_thread初始化该线程pcb中的信息，然后再用thread_create创建线程运行的栈，实际上是将栈中的返回地址指向了kernel_thread函数，因此相当于调用了kernel_thread，在kernel_thread中通过调用function的方式使function得到执行。
经过以上的分析，如果要基于线程实现进程，把function替换为创建进程的新函数就可以，先得到控制权，进程相关的具体工作再由新函数完成。
![image-20230831220458491](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831220458491.png)
## 进入特权级3
一直以来都在0特权级下工作，即使是在创建用户进程的过程中也是。可是一般情况下，**CPU不允许从高特权级转向低特权级，除非是从中断和调用门返回的情况下。系统中不打算使用调用门，因此，进入特权级3只能借助从中断返回的方式**，但用户进程还没有运行，何谈被中断？更谈不上从中断返回了……但是可以骗过CPU，**在用户进程运行之前，使其以为在中断处理环境中，这样便假装从中断返回**。
从中断返回肯定要用到iretd指令，iretd指令会用到栈中的数据作为返回地址，还会加载栈中eflags的值到eflags寄存器，如果栈中cs.rpl若为更低的特权级，处理器的特权级检查通过后，会将栈中cs载入到CS寄存器，栈中ss载入SS寄存器，随后处理器进入低特权级。因此必然要在栈中提前准备好数据供iretd指令使用。既然已经涉及到栈操作了，不如进行得更彻底一些，将进程的上下文都存到栈中，通过一系列的pop操作把用户进程的数据装载到寄存器，最后再通过iretd指令退出中断，把退出中断彻底地“假装”一回。
现在完全可以再重复写一套退出中断的代码，退出中断的出口是汇编语言函数intr_exit，这是定义在kernel.S中的，此函数用来恢复中断发生时被中断的任务的上下文状态，并且退出中断。
由此得出关键点1：**从中断返回，必须要经过intr_exit，即使是假装。**
在中断发生时，在中断入口函数intr%1entry中通过一系列的push操作来保存任务的上下文，因此在intr_exit中恢复任务上下文要通过一系列的pop操作，这属于intr%1entry的逆过程。在汇编函数intr_exit里面的一系列的pop操作是为了恢复任务的上下文，从它退出中断是不可避免的，这样才能假装从中断返回。
任务的上下文信息被保存在任务pcb中的struct intr_stack中，struct intr_stack并不要求有固定的位置，它只是一种保存任务上下文的格式结构。以下为叙述方便，将struct intr_stack称为栈。
由此得出关键点2：**必须提前准备好用户进程所用的栈结构，在里面填装好用户进程的上下文信息，借一系列pop出栈的机会，将用户进程的上下文信息载入CPU的寄存器，为用户进程的运行准备好环境。**
当执行完intr_exit中的iretd指令后，CPU便恢复了任务中断前的状态：中断前是哪个特权级就进入哪个特权级。CPU是如何知道从中断退出后要进入哪个特权级呢？这是由栈中保存的CS选择子中的RPL决定的，CS.RPL就是CPU的CPL，当执行iretd时，在栈中保存的CS选择子要被加载到代码段寄存器CS中，因此栈中CS选择子中的RPL便是从中断返回后CPU的新的CPL。
进入（假装返回）到3特权级，由此得出关键点3：**要在栈中存储的CS选择子，其RPL必须为3**。
RPL是选择子中的低2位，用以表示访问者特权级，因此RPL是为了避免低特权级任务作弊使用指向高特权级内存段的选择子而提供的一种检测手段。虽然RPL是CPU提供的、硬件级的方案，但CPU只负责接收选择子，它自己可不知道所提交的选择子是否是造假的。所以，为了避免任务提交一个假的选择子（通常是指向特权级更高的内存段），**操作系统会将选择子的RPL置为用户进程的CPL，只有CPL和RPL在数值上同时小于等于选择子所指向的内存段的DPL时，CPU的安全检测才通过**，从而避免了低特权级任务跨级访问高特权级的内存段。
> RPL只是针对访问内存（数据的），并不会对执行有影响

因为用户进程的特权级为3，操作系统要把用户进程所有段选择子的RPL都置为3，因此，在RPL=CPL=3的情况下，用户进程只能访问DPL为3的内存段，即代码段、数据段、栈段。前面的工作中已经准备好了DPL为3的代码段及数据段，由此得出关键点4，**栈中段寄存器的选择子必须指向DPL为3的内存段**。
对于可屏蔽中断来说，任务之所以能进入中断，是因为标志寄存器eflags中的IF位为1，退出中断后，还得保持IF位为1，继续响应新的中断。由此得出关键点5：**必须使栈中eflags的IF位为1**。
用户进程属于最低的特权级，对于IO操作，不允许用户进程直接访问硬件，只允许操作系统有直接的硬件控制。这是由标志寄存器eflags中IOPL位决定的。由此得出关键点6：**必须使栈中eflags的IOPL位为0**。
## 进程共享内核
为了用户进程可以访问到内核服务，必须确保用户进程必须在自己的地址空间中能够访问到内核，也就是说内核空间必须是用户空间的一部分。
每个用户进程都拥有 4GB 虚拟地址空间，操作系统把这 4GB 空间分为用户空间和内核空间两部分，因此内核空间和用户空间的大小是不固定的。
`Linux` 的作法是在用户进程 `4GB` 虚拟地址空间的高 `3GB` 以上的部分划分给操作系统，`0～3GB` 是用户进程自己的虚拟空间。为实现共享操作系统，让所有用户进程 `3GB～4GB` 的虚拟地址空间都指向同一个操作系统，也就是所有进程的虚拟地址 `3GB～4GB` 本质上都是指向的同一片物理页地址，这片物理页上是操作系统的实体代码。实现起来也比较容易，只要保证所有用户进程虚拟地址空间 `3GB～4GB` 对应的页表项中所记录的物理页地址是相同的就行。
目前的内核位于 `0xc0000000` 以上的地址空间，也就是位于页目录表中第 768～1023 个页目录项所指向的页表中，这一共是 256 个页目录项，即 1GB空间。图 11-20 是任意进程的页目录表，其中，用户进程占据页目录表中第 0～767 个页目录项，内核占据页目录表中第 768～1023 个页目录项。
![image-20230831222038554](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831222038554.png)
即使是同一个用户程序在被加载多次时，操作系统每次为它们分配的物理内存也不会固定，但操作系统启动后，其在物理内存中的位置是固定的，不会再变动。其次，操作系统只有一套页表，它们也是固定的。
页表是记录在页目录项中，页目录项是访问内核所在物理内存的入口。因此，为了访问到内核，只要给每个用户进程创建访问内核的入口即可。
也就是把用户进程页目录表中的第 768～1023 个页目录项用内核页目录表的第 768～1023 个页目录项代替，其实就是将内核所在的页目录项复制到进程页目录表中同等位置，这样就能让用户进程的高 `1GB` 空间指向内核。
每创建一个新的用户进程，就将内核页目录项复制到用户进程的页目录表，这样就为内核物理内存创建多个入口，从而实现所有用户进程共享内核。
## 用户进程创建
进程从创建到运行在总体上分为两步，进程创建的工作是由函数process_execute完成的，进程的执行是由时钟中断调用schedule，schedule从就绪队列中调度进程完成的。图11-12的阅读顺序是从上到下。
process_execute的参数是user_prog，这是待执行的用户进程，在流程图中它出现5次，展示着它是如何被安装的。由于进程的实现基于线程，故进程创建过程中用到了很多创建线程的函数。
在process_execute中，先调用函数get_kernel_pages申请1页内存创建进程的pcb，这里的pcb就是thread，接下来调用函数init_thread对thread进行初始化。随后调用函数create_user_vaddr_bitmap为用户进程创建管理虚拟地址空间的位图。
**接着调用thread_create创建线程，此函数的作用是将函数start_process和用户进程user_prog作为kernel_thread的参数，以使kernel_thread能够调用start_proces(user_prog)**。接下来是调用函数create_page_dir为进程创建页表，随后通过函数list_append将进程pcb，也就是thread加入就绪队列和全部队列，至此用户进程的创建部分完成，现在就等进程运行。
![image-20230831220930872](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831220930872.png)
**进程的运行是由时钟中断调用schedule**，由调用器schedule调度实现的。当schedule从就绪队列中获取的pcb恰好是新创建的进程pcb—thread时，该进程马上就要被执行了。在schedule中，调用了process_activate来激活进程或线程的相关资源（页表等），随后通过switch_to函数调度进程。
根据先前进程创建时函数thread_create的工作，已经将kernel_thread作为函数switch_to的返回地址，即在switch_to中退出后，处理器会执行kernel_thread函数，相当于switch_to调用kernel_thread。
同样在之前的thread_create中，已经将start_process和user_prog作为了kernel_thread的参数，故在kernel_thread中可以以此形式调用start_process(user_prog)。**函数start_process主要用来构建用户进程的上下文，它会将user_prog作为进程从中断返回的地址，这里的从中断返回是假装的，目的是让用户进程顺利进入3特权级**。
由于是从0特权级的中断返回，故返回地址user_prog被iretd指令使用，为了复用中断退出的代码，现在需要跳转到中断出口intr_exit（kernel.S中汇编代码完成的函数）处，利用那里的iretd指令使返回地址user_prog作为EIP寄存器的值以使user_prog得到执行，故相当于start_process调用intr_exit，intr_exit调用user_prog，最终用户进程user_prog在3特权级下执行。
### 用户进程的虚拟地址空间
进程与内核线程最大的区别是进程有单独的4GB虚拟地址空间。每个进程都拥有4GB的虚拟地址空间，虚拟地址连续而物理地址可以不连续，这就是保护模式下分页机制的优势。为演示此特性，需要单独为每个进程维护一个虚拟地址池，用此地址池来记录该进程的虚拟中，哪些已被分配，哪些可以分配。
进程是基于线程实现的，因此它和线程一样使用相同的PCB结构，即struct task_struct，不同的是TCB新增成员userprog_vaddr，用它来跟踪用户空间虚拟地址的分配情况。
页表寄存器cr3中的应该是页目录表的物理地址，但还需要成员pgdir存放其虚拟地址，因为页目录表本身也要占用内存来存储，在为进程创建页目录表时，必然要为其申请内存，但内存管理系统返回的地址肯定都是虚拟地址，在分页机制下，引用的任何地址都被当作虚拟地址。因此在往寄存器cr3中加载页目录地址时，会将pgdir转换成物理地址。
```c
#include "memory.h"

struct task_struct {
    uint32_t* self_kstack;	       	 	// 用于存储线程的栈顶位置，栈顶放着线程要用到的运行信息
    enum task_status status;
    uint8_t priority;		        	// 线程优先级
    char name[16];                   	// 用于存储自己的线程的名字

    uint8_t ticks;	                 	// 线程允许上处理器运行还剩下的滴答值，因为priority不能改变，所以要在其之外另行定义一个值来倒计时
    uint32_t elapsed_ticks;          	// 此任务自上cpu运行后至今占用了多少cpu嘀嗒数, 也就是此任务执行了多久*/
    struct list_elem general_tag;		// general_tag的作用是用于线程在一般的队列(如就绪队列或者等待队列)中的结点
    struct list_elem all_list_tag;   	// all_list_tag的作用是用于线程队列thread_all_list（这个队列用于管理所有线程）中的结点
    
    uint32_t* pgdir;              		// 存放进程页目录表的虚拟地址，这将在为进程创建页表时为其赋值
    struct virtual_addr userprog_vaddr; // 每个用户进程的虚拟地址池
    uint32_t stack_magic;	       		// 如果线程的栈无限生长，总会覆盖地pcb的信息，那么需要定义个边界数来检测是否栈已经到了PCB的边界
};

extern struct list thread_ready_list;
extern struct list thread_all_list;
```
### 3特权级栈
进程与线程的区别是进程拥有独立的地址空间，不同的地址空间就是不同的页表，因此在创建进程的过程中需要为每个进程单独创建一个页表。这里所说的页表是页目录表+页表，页目录表用来存放页目录项PDE，每个PDE又指向不同的页表。
页表虽然用于管理内存，但它本身也要用内存来存储，所以要为每个进程单独申请存储页目录项及页表项的虚拟内存页。除此之外，之前创建的线程属于内核的线程，它们运行在特权级0。和它们相比，用户进程还多了个特权级3，大多数情况下，用户进程在特权级3下工作，因此，还要为用户进程创建在3特权级的栈。栈也是内存区域，所以，还得为进程分配内存作为3级栈空间。
```c
extern void intr_exit(void);	// 声明外部函数intr_exit，这是用户进程进入3特权级的关键

#define USER_VADDR_START 0x8048000	 				// linux下大部分可执行程序的入口地址（虚拟）都是这个附近
#define USER_STACK3_VADDR  (0xc0000000 - 0x1000)    // 定义了一页C语言程序的栈顶虚拟起始地址
#define default_prio 31								// 定义默认的优先级
```
用户进程使用的3级栈必然要建立在用户进程自己的页表中。回顾一下图11-12，有两项工作确保了这件事的正确性，在进程创建部分，有一项工作是create_page_dir，这是提前为用户进入创建了页目录表，在进程执行部分，有一项工作是process_activate，这是使任务（无论任务是否为新创建的进程或线程，或是老进程、老线程）自己的页表生效。
在函数start_process中为用户进程创建了3特权级栈，start_process是在执行任务页表激活之后执行的，也就是在process_activate之后运行，那时已经把页表更新为用户进程的页表，所以3特权级栈是安装在用户进程自己的页表中的。
每个进程都拥有独立的虚拟地址空间，本质上就是各个进程都有单独的页表，页表是存储在页表寄存器CR3中的，CR3寄存器只有1个，因此，不同的进程在执行前，要在CR3寄存器中为其换上与之配套的页表，从而实现了虚拟地址空间的隔离。
![image-20230831221516391](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831221516391.png)
用户程序内存空间的最顶端用来存储命令行参数及环境变量，这些内容是由某操作系统下的C运行库写进去的。紧接着是栈空间和堆空间，栈向下扩展，堆向上扩展，栈与堆在空间上是相接的，这两个空间由操作系统管理分配，由于栈与堆是相向扩展的，操作系统需要检测栈与堆的碰撞。最下面的未初始化数据段bss、初始化数据段data及代码段text由链接器和编译器负责。
在4GB的虚拟地址空间中，(0xc0000000-1)是用户空间的最高地址，0xc0000000～0xffffffff是内核空间。
因此，用户空间的最高处即0xc0000000-1，以下的部分内存空间用于存储用户进程的命令行参数，之下的空间再作为用户的栈和堆。命令行参数也是被压入用户栈的，因此虽然命令行参数位于用户空间的最高处，但它们相当于位于栈的最高地址处，所以用户栈的栈底地址为0xc0000000。由于在申请内存时，内存管理模块返回的地址是内存空间的下边界，所以为栈申请的地址应该是0xc0000000-0x1000，此地址是用户栈空间栈顶，即宏USER_STACK3_VADDR。
### start_process
```c
//用于初始化进入进程所需要的中断栈中的信息，传入参数是实际要运行的函数地址(进程)，这个函数是用线程启动器进入的（kernel_thread）
void start_process(void* filename_) {
    void* function = filename_;
    struct task_struct* cur = running_thread();
    
    cur->self_kstack += sizeof(struct thread_stack); //当进入到这里的时候，cur->self_kstack指向thread_stack的起始地址，跳过这里，才能设置intr_stack
    
    struct intr_stack* proc_stack = (struct intr_stack*)cur->self_kstack;	 
    
    // 对栈中8个通用寄存器初始化，在程序开始运行之初，尚未进行任何计算，因此它们都无实际值，把它们初始化为0即可
    proc_stack->edi = proc_stack->esi = proc_stack->ebp = proc_stack->esp_dummy = 0;
    proc_stack->ebx = proc_stack->edx = proc_stack->ecx = proc_stack->eax = 0;
    
    // 接下来是对栈中显存段寄存器gs初始化，操作系统不允许用户进程访问显存，所以将其初始化为0。
    proc_stack->gs = 0;		 //用户态根本用不上这个，所以置为0（gs一般用于访问显存段，这个让内核态来访问）
    
    // 将栈中段寄存器ds、es和fs的值设置为选择子SELECTOR_U_DATA，此选择子在global.h中定义
    proc_stack->ds = proc_stack->es = proc_stack->fs = SELECTOR_U_DATA;      

    // 先对栈中eip赋值为function，这是start_process的参数filename_的值
    proc_stack->eip = function;	 //设定要执行的函数（进程）的地址
    
    // 将栈中代码段寄存器cs赋值为先前已在GDT中安装好的用户级代码段
    proc_stack->cs = SELECTOR_U_CODE;
    
    // 接下来对栈中eflags赋值，EFLAGS_IOPL_0表示IOPL位为0，EFLAGS_IF_1表示IF位为1，EFLAGS_MBS固定为1
    // 它们在eflags中的位置如图11-16所示。
    proc_stack->eflags = (EFLAGS_IOPL_0 | EFLAGS_MBS | EFLAGS_IF_1);     //设置用户态下的eflages的相关字段
    
    // 之后为用户进程分配3特权级下的栈，也就是栈中proc_stack->esp需要指向从用户内存池中分配的地址
    // 先获取特权级3的栈的下边界地址，将此地址再加上PG_SIZE，所得的和就是栈的上边界，即栈底，将此栈底赋值给proc_stack->esp
    proc_stack->esp = (void*)((uint32_t)get_a_page(PF_USER, USER_STACK3_VADDR) + PG_SIZE) ;
    
	// 栈段可以用普通的数据段，为栈中SS赋值为用户数据段选择子SELECTOR_U_DATA
    proc_stack->ss = SELECTOR_U_DATA; 

    // 将栈esp替换为刚刚填充好的proc_stack，然后通过jmp intr_exit使程序流程跳转到中断出口地址intr_exit
    // 通过那里的一系列pop指令和iretd指令，将proc_stack中的数据载入CPU的寄存器
    // 从而使程序假装退出中断，进入特权级3
    asm volatile ("movl %0, %%esp; jmp intr_exit" : : "g" (proc_stack) : "memory");
}
```
start_process接收一个参数`filename_`表示用户程序的名称，用户程序肯定是从文件系统上加载到内存的，因此进程名是进程的文件名。此函数用来创建用户进程`filename_`的上下文，也就是填充用户进程的struct intr_stack，通过假装从中断返回的方式，间接使`filename_`运行。
用户进程是基于线程来实现的，因此在图11-9中的线程创建流程中，函数start_process相当于最下面的function，也就是说，创建进程的第一步是在线程中运行函数start_process，后面会验证这一点。
程序最终的舞台是在内存中，CPU只能直接执行位于内存中的指令。用户进程在执行前，是由操作系统的程序加载器将用户程序从文件系统读到内存，再根据程序文件的格式解析其内容，将程序中的段展开到相应的内存地址。程序格式中会记录程序的入口地址，CPU把CS:[E]IP指向它，该程序就被执行了。
C语言中虽然不能直接控制这两个寄存器，但函数调用其实就是改变这两个寄存器的指向，故C语言编写的操作系统可以像调用函数那样调用执行用户程序。因此，用户进程被加载到内存中后同函数一样，仅仅是个指令区域。由于目前尚未实现文件系统，前期用普通函数代替用户程序，所以用function代替了`filename_`，待后面文件系统完成时就可以不用这个名称。
用户进程上下文保存在struct intr_stack栈中，虽然此栈的位置不固定，但还得为它安排个合适的位置。在函数init_thread中有这样一句代码：
```c
pthread->self_kstack = (uint32_t*)((uint32_t)pthread + PG_SIZE);
```
目的是初始化线程所用的栈的基址，后面的两个栈struct intr_stack和struct thread_stack的布局及所占的空间以此基地址往下顺延，这个布局操作是在函数thread_create中完成的，相关代码是：
```c
pthread->self_kstack -= sizeof(struct intr_stack);
pthread->self_kstack -= sizeof(struct thread_stack);
```
**struct intr_stack栈用来存储进入中断时任务的上下文，struct thread_stack用来存储在中断处理程序中、任务切换switch_to前后的上下文**。这两个栈的布局情况如图11-13所示。
![image-20230831221417127](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831221417127.png)
self_kstack在init_thread中被赋予指向PCB上顶端，经过上面的两行代码后，self_kstack指向PCB中struct thread_stack栈的最底端，如图11-13中横向箭头的位置所示。**在线程创建过程中，把线程的上下文保存在了struct thread_stack栈中**，实际操作struct thread_stack栈的代码如图11-14所示。
![image-20230831221441931](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831221441931.png)
struct thread_stack栈是由函数kernel_thread使用的，之后kernel_thread调用function，function因此得以执行。目前栈struct intr_stack还是空的，此栈有两个作用，一方面是任务被中断时，用来保存任务的上下文，另一方面**这是为了给进程预留的，用来填充用户进程的上下文，也就是寄存器环境**。
**为了引用struct intr_stack栈**，通过
```c
cur->self_ kstack += sizeof(struct thread_stack);
```
使指针self_kstack跨过struct thread_stack栈，最终指向struct intr_stack栈的最低处，此时PCB中栈的情况如图11-15所示。接下来声明proc_stack，使其指向self_kstack，也就是struct intr_stack栈的最低处，如图11-15中横向箭头指向的位置所示。这么做的原因是**结构体指针proc_stack指向结构体的最低处，对结构体成员的访问是由低向高处做偏移，这样符合结构体成员访问的方式**。
![image-20230831221450406](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831221450406.png)
此处不允许用户进程直接控制显存是操作系统的管理方法。其实CPU是允许低特权级（用户进程）的任务直接访问显存的，因为显存毕竟是块内存区域，访问内存区域就要通过描述符，因此只要在描述符中把它的DPL设置成低特权就好，也就是显存段的DPL数值上大于等于用户特权级即可。
不过即使此处的gs不置为0，CPU也会将其置0，原因是执行iretd从中断返回时，CPU会进行特权级检查，如果发现未来的CPL（也就是内核栈中CS.RPL）权限低于（数值上大于）CPU中段寄存器（如DS、ES、FS、GS）中选择子指向的内存段的DPL，CPU会自动将相应段寄存器的选择子置为0。这样一来，如果低特权级程序用此0值选择子访问GDT，必然会导致访问GDT中第0个不可访问的哑描述符，导致CPU抛异常，从而阻止了越权访问。因此，在特权为3的用户环境下gs选择子用不上，即使赋值成其他值，由于cpl为3，特权检查时CPU就将gs置0，干脆这里直接置为0。
![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230831221502127.png)
### page_dir_activate
page_dir_activate接受一个参数p_thread，用来激活p_thread的页表，p_thread可能是进程，也可能是线程。
> 进程才有独立的地址空间，才有自己的页表，按理说激活页表这类工作应该针对的是进程，为什么线程也需要？
> 这是因为目前的线程并不是为用户进程服务的，它是为内核服务的，因此与内核共享同一地址空间，也就是和内核用的是同一套页表。当进程A切换到进程B时，页表也要随之切换到进程B所用的页表，这样才保证了地址空间的独立性。当进程B又切换到线程C时，由于目前在页表寄存器CR3中的还是进程B的页表，因此，必须要将页表更换为内核所使用的页表。所以，无论是针对进程，还是线程，都要考虑页表切换。

注意，pgdir中的是页目录表的虚拟地址，因为页目录表需要单独的内存空间，创建页目录表（由函数create_page_dir完成）时必然要为页目录表申请内存，内存管理模块返回的地址是虚拟地址，因此页目录表地址也是虚拟地址，所以在把页目录表加载到CR3之前，要将其转换成物理地址。
```c
// 激活页目录表
void page_dir_activate(struct task_struct* p_thread) {
    // 执行此函数时，当前任务可能是线程，之所以对线程也要重新安装页表
    // 原因是上一次被调度的可能是进程, 否则不恢复页表的话，线程就会使用进程的页表

    // 若为内核线程，需要重新填充页目录表为0x100000
    // 将pagedir_phy_addr初始化为0x100000，这是内核所使用的页目录表的物理地址，也是所有内核线程的页目录表
    uint32_t pagedir_phy_addr = 0x100000;  
    
    // pcb->pgdir用来指向页目录表的虚拟地址，线程pcb中是没有页目录表的，所以pgdir等于NULL，如果是进程，其pgdir不为NULL
    if (p_thread->pgdir != NULL)	{    
        // 若为进程，则将进程的页目录表地址加载到CR3寄存器，所以先得到进程页目录表的物理地址
        // 通过函数addr_v2p将虚拟地址p_thread->pgdir转换为物理地址，重新为变量pagedir_phy_addr赋值
        pagedir_phy_addr = addr_v2p((uint32_t)p_thread->pgdir);
    }
    // 将pagedir_phy_addr的值通过mov指令写入到寄存器CR3中，由此实现目录切换
    asm volatile ("movl %0, %%cr3" : : "r" (pagedir_phy_addr) : "memory");   // 更新页目录寄存器cr3，使新页表生效
}
```
### process_activate
process_activate激活线程或进程的页表，并更新tss中的esp0为进程的特权级0的栈。进程与线程都是独立的执行流，它们有各自的栈和页表，只不过线程的页表是和其他线程共用的，而进程的页表是单独的。
进程或线程在被中断信号打断时，处理器会进入0特权级，并会在0特权级栈中保存进程或线程的上下文环境。**如果当前被中断的是3特权级的用户进程，处理器会自动到tss中获取esp0的值作为用户进程在内核态（0特权级）的栈地址，如果被中断的是0特权级的内核线程，由于内核线程已经是0特权级，进入中断后不涉及特权级的改变，所以处理器并不会到tss中获取esp0**，言外之意是即使更新了线程tss中的esp0，处理器也不会使用它。
所以，判断如果是用户进程的话才去更新tss中的esp0。这两个功能的实现，就是调用update_tss_esp和page_dir_activate完成的。只有在任务调度时才会切换页表及更新0级栈，因此process_activate是被schedule调用的。
```c
// 用于加载进程自己的页目录表，同时更新进程自己的0特权级esp0到TSS中
void process_activate(struct task_struct* p_thread) {
    ASSERT(p_thread != NULL);
    // 激活该进程或线程的页表 
    page_dir_activate(p_thread);
    // 内核线程特权级本身就是0，处理器进入中断时并不会从tss中获取0特权级栈地址，故不需要更新esp0
    if (p_thread->pgdir)
        update_tss_esp(p_thread);  // 更新该进程的esp0，用于此进程被中断时保留上下文
}
```
### create_page_dir
```c
// 用于为进程创建页目录表，并初始化（系统映射+页目录表最后一项是自己的物理地址，以此来动态操作页目录表），成功后，返回页目录表虚拟地址，失败返回空地址
uint32_t* create_page_dir(void) {
	// get_kernel_pages(1)在内核内存池中申请一页内存，将返回地址存储到指针变量page_dir_vaddr中
    // page_dir_vaddr中的值是虚拟地址。
    uint32_t* page_dir_vaddr = get_kernel_pages(1);  //用户进程的页表不能让用户直接访问到,所以在内核空间来申请
	
    if (page_dir_vaddr == NULL) {
        console_put_str("create_page_dir: get_kernel_page failed!");
        return NULL;
    }
    // 将内核页目录表的768号项到1022号项复制过来
    memcpy((uint32_t*)((uint32_t)page_dir_vaddr + 768 * 4), (uint32_t*)(0xfffff000 + 768 * 4), 255 * 4);
    // 将进程的页目录表的虚拟地址，转换成物理地址
    uint32_t new_page_dir_phy_addr = addr_v2p((uint32_t)page_dir_vaddr);     
    
    // 将物理地址new_page_dir_phy_addr加上属性PG_US_U和PG_RW_W以及PG_P_1后
    // 写入用户进程页目录表的最后一个页目录项，即page_dir_vaddr[1023]
    page_dir_vaddr[1023] = new_page_dir_phy_addr | PG_US_U | PG_RW_W | PG_P_1;   //页目录表最后一项填自己的地址，为的是动态操作页表
    return page_dir_vaddr;	// 返回页表的虚拟地址
}
```
create_page_dir用来创建页表，确切地说是创建页目录表。
首先要把内核的页目录项复制到用户进程使用的页目录表中
memcpy的第一个形参是复制的目标地址，此处的实参为`(uint32_t*)((uint32_t)page_dir_vaddr + 0x300*4)`，其中page_dir_vaddr是为用户进程申请作为页目录表的基地址，0x300是十进制的768，4是每个页目录项的大小，0x300\*4表示768个页目录项的偏移量，因此，这表示**复制的目标地址为偏移用户进程页目录表基地址768个页目录项的地方**，此处正是内核起始地址0xc0000000被映射的页表所在的页目录项地址。
memcpy的第二个形参是复制的源地址，此处的实参是`(uint32_t*)(0xfffff000+0x300*4)`，用户进程的创建是在内核中完成的，因此目前是在内核的页表中，其中0xfffff000便是用来访问内核页目录表的基地址（也是第0个页目录项），0x300\*4是内核起始页目录项在页目录表中的偏移量，也就是内核起始地址0xc0000000所在的页目录项地址，因此**0xfffff000+0x300\*4是内核页目录表中第768个页目录项的地址**。
memcpy的第三个形参是复制的字节量，这里是1024，即1024/4=256个页目录项的大小。
这样内核占用的页目录项被复制到了用户进程的页目录表中，也就是为用户进程创建了访问内核的入口。
其次需要**把用户页目录表中最后一个页目录项更新为用户进程自己的页目录表的物理地址**。这么做的原因是将来用户进程运行时，执行期间有可能会有页表操作，页表操作是由内核代码完成的，因此内核需要知道该用户进程的页目录表在哪里。
例如，如果用户进程通过系统调用申请内存，它会陷入内核态，那时内核除了为其分配内存外，如果申请的内存大小跨越了物理页框（大于4KB），甚至跨越了页表（大于4MB），还需要在它的页目录表中创建页目录项和在页表中创建页表项，否则会引起pagefault异常。每个用户有自己单独的页表，为了让用户进程能够使用系统为其分配的地址空间，肯定需要内核事先在该用户进程自己的页表中创建该地址对应的页目录项和页表项，无论怎样操作页表，必须要让内核获取页目录表的地址。内核访问页目录表的方法是通过虚拟地址0xfffff000，这会访问到当前页目录表的最后一个页目录项。**为了保证内核操作的是该用户进程自己的页目录表，此时必须把页目录表的物理地址写入用户进程页目录表的最后一个页目录项中。**
这里说的是页目录表的物理地址，通过get_kernel_pages返回的page_dir_vaddr是虚拟地址，因此必须将其转换为物理地址。
用户进程有自己的4GB虚拟地址空间，这空间中除了存放用户进程自己的指令和数据外，还要包括用户进程自己的堆和栈，用户进程可以在自己的堆中申请、释放内存，因此必须有一套方法跟踪内存的分配情况。和内核一样，用户进程也是用位图来管理地址分配的，每个进程有自己单独的位图，存储在进程pcb中的userprog_vaddr中。
在C语言中用户进程用malloc申请的内存是在进程自己的堆空间中，操作系统在用户进程的堆空间找到可用的内存后，返回该内存空间的起始地址。也要实现堆内存管理，为了实现简单，现在并没有为堆单独规划起始地址，而是由用户进程自己的虚拟内存池统一管理，用户进程被加载到内存后，剩余未用的高地址都被作为堆和栈的共享空间。
### create_user_vaddr_bitmap
为用户进程创建虚拟内存池的函数是create_user_vaddr_bitmap，它接受一个参数user_prog，表示用户进程，函数功能是创建用户进程的虚拟地址位图user_prog->userprog_vaddr，也就是按照用户进程的虚拟内存信息初始化位图结构体struct virtual_addr。
```c
// 用于初始化进程pcb中的用于管理自己虚拟地址空间的虚拟内存池结构体
void create_user_vaddr_bitmap(struct task_struct* user_prog) {
    user_prog->userprog_vaddr.vaddr_start = USER_VADDR_START;	// 位图中所管理的内存空间的起始地址，即Linux用户程序入口地址
    // 记录管理进程虚拟地址的位图需要的内存页框数
    uint32_t bitmap_pg_cnt = DIV_ROUND_UP((0xc0000000 - USER_VADDR_START) / PG_SIZE / 8 , PG_SIZE);    
    // 为位图分配内存
    user_prog->userprog_vaddr.vaddr_bitmap.bits = get_kernel_pages(bitmap_pg_cnt);                
    // 计算出位图长度（字节单位）
    user_prog->userprog_vaddr.vaddr_bitmap.btmp_bytes_len = (0xc0000000 - USER_VADDR_START) / PG_SIZE / 8;   
    // 进行位图初始化
    bitmap_init(&user_prog->userprog_vaddr.vaddr_bitmap);        
}
```
### process_execute
process_execute接受两个参数，filename是用户进程地址，name是进程名，它的功能是创建用户进程filename并将其加入到就绪队列等待执行。
```c
// 创建用户进程filename并将其加入到就绪队列等待执行
void process_execute(void* filename, char* name) { 
    struct task_struct* thread = get_kernel_pages(1);	// pcb内核的数据结构，由内核来维护进程信息，因此要在内核内存池中申请
    init_thread(thread, name, default_prio); 			// 初始化TCB
    create_user_vaddr_bitmap(thread);					// 创建虚拟内存池
    thread_create(thread, start_process, filename);		// 初始化进程栈
    thread->pgdir = create_page_dir();					// 创建页目录表
    block_desc_init(thread->u_block_desc);				// 完成用户内存块描述符数组的初始化工作
    
    enum intr_status old_status = intr_disable();
    
    ASSERT(!elem_find(&thread_ready_list, &thread->general_tag));
    list_append(&thread_ready_list, &thread->general_tag);
    ASSERT(!elem_find(&thread_all_list, &thread->all_list_tag));
    list_append(&thread_all_list, &thread->all_list_tag);
    
    intr_set_status(old_status);
}
```
### 用户进程的调度
在这之前，已经将进程创建好，并且添加到就绪队列中，不管任务是线程，还是进程，目前的任务调度器schedule一律按内核线程来处理。内核线程是0特权级，并且它使用内核的页表，这与进程的区别很大，进程的特权级是3，并且有自己单独的页表，因此需要改进调度器，增加对进程的处理。因此在thread.c中的schedule加入process_activate，用来更新任务的页表，根据任务是否为进程，修改TSS中的ESP0。
