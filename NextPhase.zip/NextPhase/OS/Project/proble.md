根据ABI约定，返回值是存放在寄存器eax中的，没有将返回值赋给内存变量，编译器只是没有将返回值从eax寄存器中mov到某块内存而已。



中断的测试：调用在前实现在后

多线程调度的测试：Kernel.S没有关闭中断

添加系统调用sys_call：没有修改中断数量

添加系统调用write：由于之前生成的是没有禁用栈保护的文件，因此总是链接错误，需要删除这些文件再重新生成之后链接

添加系统调用write：修改print.S的地址，使其与用户进程共享空间

添加系统调用malloc：void process_execute(void* filename, char* name) 函数中未加入初始化内存块



修改Makefile为新增加的文件增加编译规则，编译之后，会出现如下错误：

```
ld: build/stdio.o: in function `printf':
stdio.c:(.text+0x1ab): undefined reference to `__stack_chk_fail'
make: *** [makefile:105: build/kernel.bin] Error 1
```

这个错误是因为编译器在使用栈保护特性，但链接器找不到实现这一特性所需的函数`__stack_chk_fail`。栈保护是一种安全特性，可以检测到栈溢出。通常情况下，`__stack_chk_fail`函数是由编译器自动插入到代码中的，用于在检测到栈溢出时中止程序。这个函数通常包含在C库中，由于链接的程序没有链接C库，就会看到这个错误。

解决这个问题的一个办法是禁用栈保护特性。在编译代码时添加`-fno-stack-protector`选项来做到这一点。





在编译的时候存在以下问题：

- 由于链接的时候，各个文件的类型必须相同，因此需要-m32明确指定
- 如果没有指定自己定义的stdint.h，会自动寻找到系统的stdint.h，但由于当前虚拟机是64位，没有32位的stdint.h，因此，若在未指定自己定义的stdint.h的情况下指定-m32指定编译为32位文件，会因为没有32位的stdint.h而失败。

综上，既要指定头文件，又要指定-m32。
