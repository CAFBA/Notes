# Thread
## 在内核空间实现线程
```c
typedef void thread_func(void*);       // 指定在线程中运行的函数类型
typedef uint16_t pid_t;

enum task_status {                     // 定义线程的状态，也是进程的状态
   TASK_RUNNING,                       // 进程与线程的区别是它们是否独自拥有地址空间，也就是是否拥有页表，程序的状态都是通用的
   TASK_READY,
   TASK_BLOCKED,
   TASK_WAITING,
   TASK_HANGING,
   TASK_DIED
};

// 定义中断栈，无论是进程，还是线程，此结构用于中断发生时保护程序的上下文环境
struct intr_stack {                    
    uint32_t vec_no;	                  // kernel.S宏VECTOR中push %1压入的中断号
    uint32_t edi;
    uint32_t esi;
    uint32_t ebp;
    uint32_t esp_dummy;	               // 虽然pushad把esp也压入，但esp是不断变化的，所以会被popad忽略
    uint32_t ebx;
    uint32_t edx;
    uint32_t ecx;
    uint32_t eax;
    uint32_t gs;
    uint32_t fs;
    uint32_t es;
    uint32_t ds;
                                       // 以下由cpu从低特权级进入高特权级时压入
    uint32_t err_code;		            // err_code会被压入在eip之后
    void (*eip) (void);
    uint32_t cs;
    uint32_t eflags;
    void* esp;
    uint32_t ss;
};

// 定义线程栈，无论是进程，还是线程，此结构用于中断发生时保护程序的上下文环境  
struct thread_stack {
   uint32_t ebp;
   uint32_t ebx;
   uint32_t edi;
   uint32_t esi;

   // 将作为栈顶存储首次执行函数的返回地址，之后利用ret指令执行函数
   void (*eip) (thread_func* func, void* func_arg);   // 返回void的函数指针，传入的参数是一个thread_func类型的函数指针与函数的参数地址

                                       // 以下三条是模仿call进入thread_start执行的栈内布局构建的，call进入就会压入参数与返回地址
                                       // 因为是ret进入kernel_thread执行的，当调用eip指向的函数后，需要手动压入参数与返回地址
                                       // ret伴随出栈，因此运行之后，栈顶指向unused_retaddr作为基准找到参数
   void (*unused_retaddr);             // 一个指向未知参数类型的函数指针，省略参数列表，但编译器会自动根据函数调用的上下文来推断函数参数列表
   thread_func* function;              // Kernel_thread运行所需要的函数地址
   void* func_arg;                     // Kernel_thread运行所需要的参数地址
};

// PCB
struct task_struct {
   uint32_t* self_kstack;	        	   	// self_kstack是各线程的内核栈顶指针
   pid_t pid;                          		// 任务pid，用于系统调用
   enum task_status status;            		// 记录线程状态
   uint8_t priority;		        	    // 线程优先级
   char name[16];                   		// 记录任务（线程或进程）的名字

   uint8_t ticks;	                 	   	// 任务每次被调度到处理器上执行的时间嘀嗒数，因为priority不能改变，所以要在其之外另行定义一个值来倒计时
   uint32_t elapsed_ticks;          		// 此任务自上cpu运行后至今占用了多少cpu嘀嗒数, 也就是此任务执行了多久*/
   struct list_elem general_tag;		   	// general_tag的作用是用于线程在一般的队列(如就绪队列或者等待队列)中的结点
   struct list_elem all_list_tag;   		// all_list_tag的作用是用于线程队列thread_all_list（这个队列用于管理所有线程）中的结点
   uint32_t* pgdir;              			// 进程自己页表的虚拟地址
   struct virtual_addr userprog_vaddr; 		// 用户进程的虚拟地址
   struct mem_block_desc u_block_desc[DESC_CNT];   // 用户进程内存块描述符
   uint32_t stack_magic;	       			// 如果线程的栈无限生长，总会覆盖地pcb的信息，那么需要定义个边界数来检测是否栈已经到了PCB的边界
};

extern struct list thread_ready_list;
extern struct list thread_all_list;
```
### intr_stack
intr_stack是中断栈，无论是进程，还是线程，此结构用于中断发生时保护程序的上下文环境。进入中断后，在kernel.S中的中断入口程序intr%1entry所执行的上下文保护的一系列压栈操作都是压入了此结构中。因此，进程或线程被外部中断或软中断打断时，中断入口程序会按照此结构压入上下文寄存器。
所以，kernel.S中intr_exit中的出栈操作便是此结构的逆操作。初始情况下此栈在线程自己的内核栈中位置固定，在PCB所在页的最顶端，每次进入中断时就不一定，如果进入中断时不涉及到特权级变化，它的位置就会在当前的esp之下，否则处理器会从TSS中获得新的esp的值，然后该栈在新的esp之下。
### thread_stack
thread_stack是线程栈。线程是使函数单独上处理器运行的机制，因此线程肯定得知道要运行哪个函数，**首次执行某个函数时，这个栈就用来保存待运行的函数，其中eip便是该函数的地址，将来是用switch_to函数实现任务切换，当任务切换时，此eip用于保存任务切换后的新任务的返回地址。**
线程栈结构中的前4个成员uint32_t ebp、uint32_t ebx、uint32_t edi、uint32_t esi与ABI有关，ABI是Application Binary Interface，即应用程序二进制接口，API是库函数和操作系统的系统调用之间的接口。ABI与此不同，ABI规定的是更加底层的一套规则，属于编译方面的约定，比如参数如何传递，返回值如何存储，系统调用的实现方式，目标文件格式或数据类型等。只要操作系统和应用程序都遵守同一套ABI规则，编译好的应用程序可以无需修改直接在另一套操作系统上运行。
位于Intel386硬件体系上的所有寄存器都具有全局性，因此在函数调用时，这些寄存器对主调函数和被调函数都可见。这5个寄存器ebp、ebx、edi、esi、和esp归主调函数所用，其余的寄存器归被调函数所用。换句话说，不管被调函数中是否使用了这5个寄存器，在被调函数执行完后，这5个寄存器的值不该被改变。因此被调函数必须为主调函数保护好这5个寄存器的值，在被调函数运行完之后，这5个寄存器的值必须和运行前一样，它必须在自己的栈中存储这些寄存器的值。
C编译器就是按照这套ABI规则来编译C程序的，倘若全是用C语言来写程序，就不需要考虑ABI规则，这些都是编译器考虑的事。C语言和汇编语言是用不同的编译器来编译的，C语言代码要先被编译为汇编代码，此汇编代码便是按照ABI规则生成的，因此，**如果要自己手动写汇编函数，并且此函数要供C语言调用的话，也得按照ABI的规则去写汇编才行**。
而此处写的汇编函数就是switch_to，它是由C语言函数schedule来调用的，因此**为了不破坏主调函数schedule的寄存器，需要在汇编代码中保存这5个寄存器，保存的位置就是这个线程栈，在线程自己的内核栈中位置不固定，实际位置取决于实际运行情况。**
esp的值会由调用约定来保证，因此不打算保护esp的值。在实现中，由被调函数保存除esp外的4个寄存器，这就是**线程栈thread_stack前4个成员的作用，将来用switch_to函数切换时，先在线程栈thread_stack中压入这4个寄存器的值**。
根据C调用约定，调用者会先从右到左把参数压到栈中，然后通过call指令发起调用，此指令会在栈中留下返回地址，因此被调用的函数在执行时，会认为调用者已经把返回地址留在栈中，而且是在栈顶的位置，当进入到被调用函数中执行时，栈中的情形如图9-9所示。
![image-20230627231800212](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230627231800212.png)
执行流存在的原因就是程序中包含改变CS或EIP的值的指令，这些指令有call、jmp、ret等。call指令在去之前先在栈中留下返回地址，回则需要在ret指令的配合下才能完成，**ret将栈顶的值当作call留下的返回地址**，在保证栈顶值正确的情况下，ret能把处理器重新带回到主调函数中。此处kernel_thread的调用灵活运用ret指令，即**在没有call指令的前提下，直接在栈顶装入函数的返回地址，再利用ret指令执行该函数**，当然这是在内联汇编下做的。
> 在`ret`指令的执行过程中，它首先会从栈中取出保存的返回地址，然后将这个地址加载到程序计数器中，从而将程序流程返回到主调函数中的相应位置，在这之后，`ret`指令会执行出栈操作，将之前压入栈中的返回地址移除。

因此，kernel_thread函数并不是通过调用call指令的形式执行的，而是用汇编指令ret返回执行的，也就是kernel_thread作为某个函数（此函数暂时为thread_start）的返回地址，**通过ret指令使函数kernel_thread的偏移地址（段基址为0）被载入到处理器的EIP寄存器，从而处理器开始执行函数kernel_thread**，但由于它的执行并不是通过call指令实现的，所以进入到函数kernel_thread中执行时，栈中并没有返回地址。
在C语言中，函数的执行通常被编译为call指令调用的形式，因此在某个函数中执行时，按照规定，栈顶应该是某个主调函数通过call指令调用该函数时留下的返回地址，在栈顶之上（高地址）的栈帧中是被调函数的参数。**为了满足C语言的调用形式，当前栈顶必须得是返回地址，故使用参数unused_ret占位，由它充当栈顶，其值充当返回地址，所以它的值是多少都没关系**，因为将来不需要通过此返回地址返回，真正目的是让kernel_thread去调用func(func_arg)。
> 不需要返回只是函数首次在线程中执行的情况，将来任务切换时在内核调度器中会由调度函数switch_to为其留下返回地址，这时需要返回

因此要保留这个栈帧位置，让函数kernel_thread以为栈顶是它自己的返回地址，这样便有一个正确的基准，并能够从栈顶+4和栈顶+8的位置找到参数func和func_arg。否则，若没有占位成员unused_ret的话，处理器依然把栈顶当作返回地址作为基准，以栈顶向上+4和+8的地方找参数func和func_arg，但由于没有返回地址，此时栈顶就是参数func，栈顶+4就是func_arg，栈顶+8的值目前未知，因此处理器便找错了栈帧位置。
![image-20230913215331382](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230913215331382.png)
根据上图内存布局：在thread_create中定义的线程栈栈顶指针kthread_stack将指向ebp，将来pop恢复寄存器上下文后的栈顶将是在thread_create中为kthread_stack->eip所赋的值—kernel_thread，因此在执行ret后，会弹出当前栈顶，即eip，用于占位的成员将作为新的栈顶，使得处理器去执行kernel_thread函数时候能够找到参数。因此，**该结构体中的成员位置不能改变**。
将来执行ret的地方是schedule调用的switch_to，其中若参与调度的是首次执行的函数，即是作为线程初始运行的函数而不是时间片消耗结束又重新被调度的线程，将会按照上述过程返回到kernel_thread进行执行。
综上，线程栈struct thread_stack有两个作用：
1. 第1个作用是在线程首次运行时，**线程栈用于存储创建线程所需的相关数据**。和线程有关的数据应该都在该线程的PCB中，这样便于线程管理，避免为它们再单独维护数据空间。创建线程之初，要指定在线程中运行的函数及参数，因此，把它们放在位于PCB所在页的高地址处的0级栈中比较合适，该处就是线程栈的所在地址。
2. 第2个作用是用在任务切换函数switch_to中的，这是线程已经处于正常运行后线程栈所体现的作用。switch_to函数是用汇编语言实现的，它是被内核调度器函数调用的，因此这里面**涉及到主调函数寄存器的保护**，就是ebp、ebx、edi和esi这4个寄存器，要在被调用函数switch_to中将它们保护起来，也就是将它们保存在栈中，这必然涉及到压栈指令push，switch_to自然是汇编程序。
switch_to既然是汇编程序，从其返回时，必然要用到ret指令，因此为同时满足这2个作用，**最初先在线程栈中装入适合的返回地址及参数，使作用2中switch_to的ret指令也满足创建线程时的作用1。**
### task_struct
task_struct是定义的PCB，其中**self_kstack是各线程的内核栈顶指针**，当线程被创建时，self_kstack被初始化为自己PCB所在页的顶端，之后在运行时，在被换下处理器前，会把线程的上下文信息（也就是寄存器映像）保存在0特权级栈中，**self_kstack便用来记录0特权级栈在保存线程上下文后的新的栈顶**，在下一次此线程又被调度到处理器上时，可以把self_kstack的值加载到esp寄存器，这样便从0特权级栈中获取了线程上下文，从而可以加载到处理器中运行。
status用于记录线程状态，其类型便是前面定义的枚举结构enum task_status。
priority用于记录线程优先级，进程或线程都要有个优先级，此优先级用来决定进程或线程的时间片，即被调度到处理器上的运行时间。
stack_magic是栈的边界标记，用于检测栈的溢出。0级栈会被初始化为线程PCB的最顶端，栈位于页的顶端并向下发展，因此担心压栈过程中会把PCB中的信息给覆盖，所以**每次在线程或进程调度时要判断是否触及到进程信息的边界**，也就是判断stack_magic的值是否为初始化的内容，stack_magic实际上就是个魔数。
ticks是任务每次被调度到处理器上执行的时间嘀嗒数，也就是所说的任务的时间片，每次时钟中断都会将当前任务的ticks减1，当减到0时就被换下处理器。
**ticks和上面的priority要配合使用**。priority表示任务的优先级，这里优先级体现在任务执行的时间片上，即优先级越高，每次任务被调度上处理器后执行的时间片就越长。当ticks递减为0时，就要被时间中断处理程序和调度器换下处理器，调度器把priority重新赋值给ticks，这样当此线程下一次又被调度时，将再次在处理器上运行ticks个时间片。
elapsed_ticks用于记录任务在处理器上运行的时钟嘀嗒数，从开始执行，到运行结束所经历的总时钟数。
general_tag的类型是struct list_elem，也就是general_tag是双向链表中的结点。它是线程的标签，当线程被加入到就绪队列thread_ready_list或其他等待队列中时，就把该线程PCB中general_tag的地址加入队列。
all_list_tag的类型也是struct list_elem，它专用于线程被加入全部线程队列时使用。一个struct list_elem类型的结点只有一对前躯和后继指针，它只能被加入一个队列，但为管理所有线程，还存在一个全部线程队列thread_all_list，因此线程还需要另外一个标签，即all_list_tag。
这两个标签仅仅是加入队列时用的，将来从队列中把它们取出来时，还需要再通过offset宏与elem2entry宏的反操作，实现从&general_tag到&thread的地址转换，将它们还原成线程的PCB地址后才能使用。
pgdir是任务自己的页表的虚拟地址。线程与进程的最大区别就是进程独享自己的地址空间，即进程有自己的页表，而线程共享所在进程的地址空间，即线程无页表。如果该任务为线程，pgdir则为NULL，否则pgdir会被赋予页表的虚拟地址，注意此处是虚拟地址，页表加载时还是要被转换成物理地址的。
## 线程的基础实现
```c
struct task_struct* main_thread;       	// 主线程PCB
struct list thread_ready_list;	      	// 就绪队列
struct list thread_all_list;	        // 所有任务队列

// pid必须是唯一的，此锁用来在分配pid时实现互斥，避免为不同的任务分配重复的pid
// pid_lock的类型是struct lock，在使用前要初始化，这是在函数thread_init中完成的
struct lock pid_lock;		            // 分配pid锁

static struct list_elem* thread_tag;    // 记录tag，用于转换

extern void switch_to(struct task_struct* cur, struct task_struct* next);

// 获取当前线程pcb指针
struct task_struct* running_thread() {
    uint32_t esp; 
    asm("mov %%esp, %0" : "=g" (esp));
    // 取esp整数部分即pcb起始地址
    return (struct task_struct*)(esp & 0xfffff000);
}

// 由kernel_thread去执行function(func_arg)
static void kernel_thread(thread_func* function, void* func_arg) {
    // 执行function前要开中断，避免后面的时钟中断被屏蔽，而无法调度其它线程 
    intr_enable();
    function(func_arg); 
}

// 分配pid是在线程创建后的初始化期间进行的，因此函数allocate_pid是在init_thread函数中使用
static pid_t allocate_pid(void) {
    // next_pid初始为0，其加1后的结果为新线程的pid，因此第1个任务的pid为1，之后任务的pid会自增
    static pid_t next_pid = 0;
    lock_acquire(&pid_lock);
    next_pid++;
    lock_release(&pid_lock);
    return next_pid;
}

// 初始化线程栈thread_stack，将待执行的函数和参数放到thread_stack中相应的位置
void thread_create(struct task_struct* pthread, thread_func function, void* func_arg) {
    // pthread->self_kstack在init_thread中已经被指向了PCB的最顶端
    pthread->self_kstack -= sizeof(struct intr_stack);    // 预留线程所使用的中断栈intr_stack的空间
    pthread->self_kstack -= sizeof(struct thread_stack);  // 再留出线程栈空间

    // 预留后pthread->self_kstack值为线程栈栈顶指针
    struct thread_stack* kthread_stack = (struct thread_stack*)pthread->self_kstack;

    // 为能够在kernel_thread中调用function(func_arg)做准备
    // eip指向kernel_thread，kernel_thread接受两个参数，function是kernel_thread中调用的函数，func_arg是function的参数
    kthread_stack->eip = kernel_thread;    // 首次执行某个函数时，这个栈就用来保存待运行的函数
    kthread_stack->function = function;    // 其中eip便是该函数的地址
    kthread_stack->func_arg = func_arg;

    // 把ebp，ebx，esi，edi这4个寄存器初始化为0，因为线程中的函数尚未执行，在执行过程中寄存器才会有值，此时置为0即可
    kthread_stack->ebp = kthread_stack->ebx = kthread_stack->esi = kthread_stack->edi = 0;

    // kthread_stack->unused_retaddr是不需要赋值的，就是用来占位的，因此代码中并没有对它处理
}

// 初始化线程基本信息
void init_thread(struct task_struct* pthread, char* name, int prio) {
    memset(pthread, 0, sizeof(*pthread));     // 将pthread所在的PCB清0，即清0一页
    pthread->pid = allocate_pid();            
    strcpy(pthread->name, name);              // 将线程名写入PCB中的name数组中

    if (pthread == main_thread) {             // 为线程的状态pthread->status赋值
        // 由于把main函数也封装成一个线程，并且它一直是运行的，故将其直接设为TASK_RUNNING
        pthread->status = TASK_RUNNING;
    } else {
        pthread->status = TASK_READY;
    }

    // self_kstack是线程自己在内核态下使用的栈顶地址
    // 将线程栈顶定义为pcb地址+4096的地方，即一页给线程的信息（包含管理信息与运行信息）空间
    pthread->self_kstack = (uint32_t*)((uint32_t)pthread + PG_SIZE);  // 线程自己在0特权级下所用的栈，在线程创建之初，它被初始化为线程PCB的最顶端
    pthread->priority = prio;
    pthread->ticks = prio;                                            // 任务（线程和进程的统称）在处理器上执行的时间片长度
    pthread->elapsed_ticks = 0;
    pthread->pgdir = NULL;
    pthread->stack_magic = 0x19870916;	                              // 自定义的魔数
}

// 创建一优先级为prio的线程，线程名为name，线程所执行的函数是function(func_arg)
struct task_struct* thread_start(char* name, int prio, thread_func function, void* func_arg) {
    // 在内核空间中申请一页内存，将其赋值给新创建的PCB指针thread
    // 由于get_kernel_page返回的是页的起始地址，故thread指向的是PCB的最低地址
    // 进程或线程的PCB都是给内核调度器使用的结构，属于内核管理的数据，将来用户进程的PCB也依然要从内核物理内存池中申请
    struct task_struct* thread = get_kernel_pages(1);           

    init_thread(thread, name, prio);                   // 初始化刚刚创建的thread线程
    thread_create(thread, function, func_arg);         // 创建线程

    // 演示线程运行的临时方案
    // asm volatile ("movl %0, %%esp;pop %%ebp; pop %%ebx; pop %%edi; pop %%esi; ret": : "g" (thread->self_kstack) : "memory");
    // 使thread->self_kstack的值作为栈顶，之后使之前初始化的0弹入到相应寄存器中
    // 最后ret会把栈顶的数据作为返回地址送上处理器的EIP寄存器
    // 此时栈顶的数据就是在thread_create中为kthread_stack->eip所赋的值—kernel_thread
    // 因此在执行ret后，由于已经手动压入参数并伪造了返回地址，因此处理器会去执行kernel_thread

    // 确保之前不在队列中
    ASSERT(!elem_find(&thread_ready_list, &thread->general_tag));
    // 加入就绪线程队列
    list_append(&thread_ready_list, &thread->general_tag);

    ASSERT(!elem_find(&thread_all_list, &thread->all_list_tag));
    // 加入全部线程队列
    list_append(&thread_all_list, &thread->all_list_tag);

    return thread;
}

// 将kernel中的main函数完善为主线程
static void make_main_thread(void) {
    // 因为main线程早已运行，在loader.S中进入内核时mov esp, 0xc009f000已为其预留tcb
    // 地址为0xc009e000，因此不需要通过get_kernel_page另分配一页
    main_thread = running_thread();
    init_thread(main_thread, "main", 31);

    // main函数是当前线程，当前线程不在thread_ready_list中,，所以只将其加在thread_all_list中
    ASSERT(!elem_find(&thread_all_list, &main_thread->all_list_tag));
    list_append(&thread_all_list, &main_thread->all_list_tag);
}

// 实现任务调度
void schedule() {

    ASSERT(intr_get_status() == INTR_OFF);

    struct task_struct* cur = running_thread(); 

    if (cur->status == TASK_RUNNING) {                       // 如果当前线程cur的时间片到期
        ASSERT(!elem_find(&thread_ready_list, &cur->general_tag));
        list_append(&thread_ready_list, &cur->general_tag);   // 重新加入到就绪队列thread_ready_list队尾
        cur->ticks = cur->priority;                           // 重新将ticks的值再次赋值为它的优先级prio
        cur->status = TASK_READY;                             // 将cur的状态status置为TASK_READY
    } else {    // 如果当前线程cur并不是因为时间片到期而被换下处理器，肯定是由于某种原因被阻塞
        // 这时候不需要处理就绪队列，因为当前运行线程并不在就绪队列中
    }

    // 由于尚未实现idle线程，因此有可能就绪队列为空，为避免这种无线程可调度的情况，暂时用断言来保障
    ASSERT(!list_empty(&thread_ready_list));

    thread_tag = NULL;	                                    // thread_tag清空
    thread_tag = list_pop(&thread_ready_list);               // 将thread_ready_list队列中的第一个就绪线程弹出，准备将其调度上cpu
    // 通过elem2entry获得新线程的PCB地址，将其赋值给next
    struct task_struct* next = elem2entry(struct task_struct, general_tag, thread_tag);
    next->status = TASK_RUNNING;  // 表示新线程next可以上处理器了，于是准备切换寄存器映像，通过调用switch_to完成

    // 激活任务页表等
    process_activate(next);

    switch_to(cur, next);         // 将线程cur的上下文保护好，再将线程next的上下文装载到处理器，从而完成任务切换。
}

// 当前线程将自己阻塞，线程pcb中的状态字段设定为传入的status
void thread_block(enum task_status stat) {
    // stat取值为TASK_BLOCKED,TASK_WAITING,TASK_HANGING,也就是只有这三种状态才不会被调度
    ASSERT(((stat == TASK_BLOCKED) || (stat == TASK_WAITING) || (stat == TASK_HANGING)));
    enum intr_status old_status = intr_disable();      // 先关闭中断，因为涉及要修改阻塞队列，调度
    struct task_struct* cur_thread = running_thread(); // 得到当前正在运行的进程的pcb地址
    cur_thread->status = stat;    // 置其状态为stat 
    schedule();		               // 将当前线程换下处理器
    intr_set_status(old_status);  // 只有在当前线程被唤醒后才会被执行到
}

// 将线程pthread解除阻塞
void thread_unblock(struct task_struct* pthread) {
    enum intr_status old_status = intr_disable();               // 涉及队就绪队列的修改，此时绝对不能被切换走
    ASSERT(((pthread->status == TASK_BLOCKED) || (pthread->status == TASK_WAITING) || (pthread->status == TASK_HANGING)));
    if (pthread->status != TASK_READY) {
        ASSERT(!elem_find(&thread_ready_list, &pthread->general_tag));
        if (elem_find(&thread_ready_list, &pthread->general_tag)) {
            PANIC("thread_unblock: blocked thread in ready_list\n");
        }
        list_push(&thread_ready_list, &pthread->general_tag);    // 放到队列的最前面，使其尽快得到调度
        pthread->status = TASK_READY;
    } 
    intr_set_status(old_status);
}

// 初始化线程环境
void thread_init(void) {
    put_str("thread_init start\n");
    list_init(&thread_ready_list);
    list_init(&thread_all_list);
    lock_init(&pid_lock);
    make_main_thread();  // 将当前main函数创建为线程
    put_str("thread_init done\n");
}
```
### thread_start
thread_start接受4个参数，创建一优先级为prio的线程，线程名为name，线程所执行的函数是function(func_arg)。
thread_start是创建线程的入口，在执行完init_thread和thread_create后，通过list_append函数把新创建的线程加入就绪队列和全部线程队列。拿就绪队列来说，在加入队列之前，按理说线程不应该出现在就绪队列thread_ready_list中，因此在加入队列之前，先通过ASSERT来保证这一点。
ASSERT中调用的是`elem_find(&thread_ready_list, &thread->general_tag)`，第1个参数是就绪队列的地址&thread_ready_list，第2个参数是新线程的标签general_tag的地址。elem_find的功能是在队列中找结点，如果找到就返回1，否则返回0。由此可见，队列中的结点就是线程PCB中的成员general_tag。
list_append的功能就是在队列thread_ready_list中加入新创建线程的general_tag成员，因此传入的参数是general_tag的地址，即&thread->general_tag。一定要清楚，链表（队列）中的结点并不是PCB，因此这里并不是把PCB加到队列中，链表的结点类型是struct list_elem，只能将struct list_elem类型的结点插入到队列中，而PCB中general_tag的类型就是struct list_elem，这是在设计PCB时有意安排的。
这样做是有好处的，struct list_elem类型中只有两个指针成员：struct list_elem* prev和struct list_elem* next，因此它作为结点的话，结点尺寸就8字节，整个队列显得轻量小巧，如果换成PCB做结点，尺寸太大。线程在内存中的位置是散落的，由不同的链表将它们各自的general_tag和all_list_tag串联起来，从而形成队列。线程在队列中的组织结构如图9-11所示。
![image-20230627232248583](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230627232248583.png)
### init_thread
init_thread初始化线程基本信息。
pthread->self_kstack是线程自己在0特权级下所用的栈，**在线程创建之初被初始化为线程PCB的最顶端**，因此PCB的上端是0特权级栈，将来线程在内核态下的任何栈操作都是用此PCB中的栈，如果出现了某些异常导致入栈操作过多，这会破坏PCB低处的线程信息。为此，需要检测这些线程信息是否被破坏，stack_magic被安排在线程信息的最边缘，作为它与栈的边缘。
从开机到创建第一个线程前，程序都有个执行流，这个执行流带从BIOS到mbr到loader到kernel，即主线程。为此**在loader中把esp置为0xc009f000，这是有意为之的设计，意图是把0xc009e000作为主线程的PCB**。现在要创建新线程，并且打开时钟中断，时钟中断的处理函数会判断当前线程所用的栈是否会破坏了线程信息，也就是判断thread->stack_magic是否等于0x19870916。可是**新创建的线程在首次运行前一直是主线程在跑，但此时主线程还没有PCB，因此main_thread->stack_magic就是错误的值，所以提前在make_main_thread中调用init_thread为主线程赋予PCB**。
> 有关0xc009e000作为主线程的PCB，见memory.md宏MEM_BITMAP_BASE

所以init_thread函数加入对主线程main_thread的判断，如果待初始化的线程是主线程，也就是代码`if(pthread == main_thread)`的判断，那就将线程的状态置为TASK_RUNNING，因为主线程早已经在运行了。否则的话，就表示待初始化的线程不是主线程，它们的状态为准备运行，因此置其状态为TASK_READY。
### thread_create
thread_create初始化线程栈thread_stack，将待执行的函数和参数放到thread_stack中相应的位置。
预留线程所使用的中断栈struct intr_stack的空间有两个目的：
1. 将来线程进入中断后，位于kernel.S中的中断代码会通过此栈来保存上下文。
2. 将来实现用户进程时，会将用户进程的初始信息放在中断栈中。
因此，必须要事先把struct intr_stack的空间留出来。
kernel_thread并不是通过call指令调用的，而是通过ret来执行的，因此无法按照正常的函数调用形式传递kernel_thread所需要的参数，如这样调用是不行的：kernel_thread(function, func_arg)，只能将参数放在kernel_thread所用的栈中，即处理器进入kernel_thread函数体时，栈顶为返回地址，栈顶+4为参数function，栈顶+8为参数func_arg。
### thread_tag
在队列中的结点并不是线程的PCB，而是线程PCB中的tag，即general_tag或all_list_tag，其类型是struct list_elem。对线程的管理都是基于线程PCB的，其类型是struct task_struct，因此必须要将tag转换成PCB。在转换过程中需要记录tag的值，因此在定义全局变量thread_tag来存储。
### running_thread
函数running_thread是返回线程的PCB地址，在thread_start中通过get_kernel_pages获取一页用于PCB的内存，因此PCB位于自然页的起始地址，32位虚拟地址的高20位可用来定位一个物理页，PCB中的self_kstack是线程自己在内核态下使用的栈顶地址，在PCB中的偏移量为0，将来**当前线程的PCB地址会在switch_to中切下调度器时通过esp保存到self_kstack中，又会通过self_kstack将换上调度器下一个线程的PCB地址恢复到esp中**，因此取当前栈指针esp的高20位即整数部分作为当前运行线程的PCB起始地址。
### kernel_thread
kernel_thread在函数体中开中断的函数intr_enable是任务调度的保证。原因是线程的首次运行由时钟中断处理函数调用任务调度器schedule完成，进入中断后处理器会自动关中断，因此在执行function前要打开中断，否则kernel_thread中的function在关中断的情况下运行，也就是时钟中断被屏蔽了，再也不会调度到新的线程，function会独享处理器。
> **任务调度机制基于时钟中断，由时钟中断这种不可抗力来中断所有任务的执行，借此将控制权交到内核手中，由内核的任务调度器schedule考虑将处理器使用权发放到某个任务的手中**，下次中断再发生时，权利将再被回收，周而复始，这样便保证操作系统不会被架空，而且保证所有任务都有运行的机会。

### make_main_thread
make_main_thread在主线程的PCB中写入线程信息。主线程从内核创建之初就在运行，所以不需要再为其申请页安装其PCB，也不需要再通过thread_create构造它的线程栈，只需要通过init_thread填充其名称和优先级。只有两个队列，就绪队列只存储准备运行的线程，全部队列存储所有线程，包括就绪的、阻塞的、正在执行的，因此，只需要将主线程加入到全部队列thread_all_list中。
### allocate_pid
分配pid是在线程创建后的初始化期间进行的，因此函数allocate_pid是在init_thread函数中使用。Linux中pid为0的任务是init，将来实现任务init后也要把它的pid分配为1。
## 任务调度器和任务切换
调度器的工作就是根据任务的状态将其从处理器上换上换下，任务的状态是定义的，因此定义任务状态目的就是为了方便设计任务调度的方法。**调度器主要任务就是读写就绪队列，增删里面的结点，结点是线程PCB中的general_tag，相当于线程的PCB，从队列中将其取出时一定要还原成PCB才行。**
线程每次在处理器上的执行时间是由其ticks决定的，在初始化线程的时候，已经将线程PCB中的ticks赋值为prio，优先级越高，ticks越大。每发生一次时钟中断，时钟中断的处理程序便将当前运行线程的ticks减1。**当ticks为0时，时钟的中断处理程序调用调度器schedule，也就是该把当前线程换下处理器了，让调度器选择另一个线程上处理器。**
调度器是从就绪队列thread_ready_list中取出上处理器运行的线程，所有待执行的线程都在thread_ready_list中，调度机制即轮询调度，按先进先出的顺序始终调度队头的线程。注意，这里说的是取出，也就是从队列中弹出，意思是说队头的线程被选中后，其结点不会再从就绪队列thread_ready_list中保存，因此，按照先入先出的顺序，位于队头的线程永远是下一个上处理器运行的线程。就绪队列thread_ready_list中的线程都属于运行条件已具备，但还在等待被调度运行的线程，因此thread_ready_list中的线程的状态都是TASK_READY。而当前运行线程的状态为TASK_RUNNING，它仅保存在全部队列thread_all_list当中。
调度器schedule并不仅由时钟中断处理程序来调用，还有被其他函数调用的情况，比如thread_block。因此，在schedule中要判断当前线程是出于什么原因才要被换下处理器。是线程的时间片到期了？还是线程时间片未到，但它被阻塞了，以至于不得不换下处理器？其实这就是查看线程的状态，如果线程的状态为TASK_RUNNING，这说明时间片到期了，将其ticks重新赋值为它的优先级prio，将其状态由TASK_RUNNING置为TASK_READY，并将其加入到就绪队列的末尾。如果状态为其他，这不需要任何操作，因为调度器是从就绪队列中取出下一个线程，而当前运行的线程并不在就绪队列中。
调度器按照队列先进先出的顺序，把就绪队列中的第1个结点作为下一个要运行的新线程，将该线程的状态置为TASK_RUNNING，之后通过函数switch_to将新线程的寄存器环境恢复，这样新线程便开始执行。
> 注册时钟中断处理函数见interrupt.md
### schedule
schedule功能是将当前线程换下处理器，并在就绪队列中找出下个可运行的程序，将其换上处理器，由于主要内容就是读写就绪队列，因此它不需要参数。
由于thread_tag是全局变量，先将其置为NULL，接下来通过从就绪队列中弹出一个可用线程并存入thread_tag，但thread_tag并不是线程，它仅仅是线程PCB中的general_tag或all_list_tag，要获得线程的信息，必须将其转换成PCB，因此使用宏elem2entry：
```c
#define offset(struct_type,member_name) (int)(&(((struct_type*)0)->member_name))
#define elem2entry(struct_type, struct_member_name, elem_ptr) \
		(struct_type*)((int)elem_ptr - offset(struct_type, struct_member_name))
```
宏elem2entry接受三个参数:
- 参数elem_ptr是待转换的地址，它属于某个结构体中某个成员的地址
- 参数struct_member_name是elem_ptr所在结构体中对应地址的成员名字，即参数struct_member_name是个字符串
- 参数struct_type是elem_ptr所属的结构体的类型
宏elem2entry的作用是**将指针elem_ptr转换成struct_type类型的指针**，其原理是用elem_ptr的地址减去elem_ptr在结构体struct_type中的偏移量，此地址差便是结构体struct_type的起始地址，最后再将此地址差转换为struct_type指针类型。
一般的转型转换，只是改变数据类型，并不改变地址，**不同的数据类型仅仅是告诉编译器在同一地址处连续获取多少字节的数据**。比如：
```c
int four_bytes = 0x12345678;
char one_bytes = (char)four_bytes;
```
Intel是小端字节序，因此单字节变量one_bytes的值为0x78。
这里要做的转换，不仅包括类型，还涉及到地址的转换。从队列中弹出的结点元素并不能直接用，因为**链表中的结点并不是PCB，而是PCB中的general_tag或all_list_tag，需要将它们转换成所在的PCB的地址**。所以，整个转换过程要分为两步，先完成地址转换，再完成类型转换。general_tag和all_list_tag在PCB中的布局，如图9-12所示。
![image-20230627232615480](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230627232615480.png)
无论PCB的地址是多少，x_tag在PCB中的偏移量是固定的，将它们的地址转换成PCB地址，有两种方法：
1. 类似running_thread的方法，PCB是在自然页的起始地址，即PCB的地址为`0xfffff000 & (&(PCB.general_tag))`。
2. 用x_tag的地址减去它们在PCB中的偏移量。
访问结构体成员的两种方法是“结构体变量.成员”和“结构体指针变量->成员”。它们的访问原理是“结构体变量的地址+成员的偏移量”，这种寻址方式相当于“基址+变址”，其中“结构体变量的地址”相当于基址，“成员的偏移量”相当于变址。
那么，&PCB相当于基址，成员x_tag在PCB中的偏移量 `&(PCB.x_tag)–&PCB = n`，从这个式子可以看出，若令基址&PCB的值等于0，&(PCB.x_tag)就等于偏移量n，因此可以用代码`&((struct_type*)0)->member`得到**结构体成员member在结构体中的偏移量n**，从而`&(PCB.x_tag)–n =&PCB `得到基址&PCB。这就是宏offset的作用，其接受两个参数，struct_type是结构体类型，member是结构体成员的名字。
综上：
1. 用结构体成员的地址减去成员在结构体中的偏移量，先获取到结构体起始地址。
2. 再通过强制类型转换将第1步中的地址转换成结构体类型。
### switch_to
完整的程序=用户代码+内核代码，所以任务在执行过程中会执行用户代码和内核代码，当处理器处于低特权级下执行用户代码时，称之为用户态，当处理器进入高特权级执行到内核代码时，称之为内核态，当处理器从用户代码所在的低特权级过渡到内核代码所在的高特权级时，称为陷入内核。
无论是执行用户代码，还是执行内核代码，都属于当前任务，任务与任务的区别在于执行流一整套的上下文资源，**处理器只有被新的上下文资源重新装载后，当前任务才被替换为新的任务，这才叫任务切换**，当任务陷入内核时，其上下文资源并未完全替换，并不是说当前任务由用户态进入内核态后当前任务就切换成内核任务。
中断发生时，当前运行的任务被打断，随后会去执行中断处理程序，不管当前任务在中断前的特权级是什么，执行中断处理程序时肯定都是0特权级。任务的代码包括用户代码+内核代码，即使是3特权级的用户进程进入中断后，当前的任务依然是进入中断前的那个任务，只是此任务目前陷入内核态，执行的是内核的代码，因此进入中断后所执行的一切内核代码也依然属于当前任务，只是由内核来提供这一部分。
任务调度由时钟中断发起，由中断处理程序调用switch_to函数实现。当任务调度发生时，受时钟中断的影响，处理器会进入中断处理程序，上下文环境为进入中断前的全部寄存器，即第一层执行流的上下文，之后在内核中执行中断处理程序，调用任务切换函数switch_to时，执行流再次改变，因此还需要保护第二层执行流的上下文，即中断处理过程中的任务状态。
因此，系统中的任务调度过程中，需要**保护好任务两层执行流的上下文**，这分两部分来完成。
1. 进入中断时的保护：用户环境上下文，即全部寄存器映像。这些寄存器由kernel.S中定义的中断处理入口程序intr%1entry来保护，里面是一些push寄存器的指令，由汇编下的宏%macro VECTOR 2定义。当把这些寄存器映像恢复到处理器中后，任务便完全退出中断，继续执行自己的代码部分。
2. 任务切换时的保护：内核环境上下文，根据ABI，除esp外，只保护esi、edi、ebx和ebp这4个寄存器，此部分只负责恢复第二层的执行流，即恢复为在内核的中断处理程序中继续执行的状态。
当恢复寄存器后，如果此任务是用户进程，任务就完全恢复为用户程序继续在用户态下执行，如果此任务是内核线程，任务就完全恢复为另一段被中断执行的内核代码，依然是在内核态下运行。
当任务开始执行内核代码后，任务在内核代码中的执行路径由这4个寄存器决定，将来恢复这4个寄存器，只是让处理器继续执行任务中的内核代码，并不是让任务恢复到中断前，依然还是在内核中。**这几个寄存器的值会让处理器把程序执行到内核代码的结束处，在那里可以用第一部分中保护的全部寄存器映像来恢复任务，从而退出中断，使任务彻底恢复为进入中断前的状态**。另外，其实这4个寄存器主要是用来恢复主调函数的环境，只是当前在讨论内核函数。
退出中断的出口是kernel.S中的intr_exit，中断处理完成后，执行流程会通过jmp intr_exit跳转到此，此处的指令用进入中断时，在kernel.S中由intr%1entry保护的寄存器映像来恢复上下文，从而彻底走出中断，恢复任务。现在要完成第二部分，其中的函数switch_to用于任务切换。
switch_to接受两个参数，第1个参数是当前线程的PCB地址cur，第2个参数是下一个上处理器的线程，此函数的功能是**保存cur线程的寄存器映像，将下一个线程next的寄存器映像装载到处理器**。
首先遵循ABI原则，保护esi、edi、ebx、ebp寄存器。栈是自高地址向低地址扩展的，因此这4个push操作步骤与线程栈struct thread_stack的结构是逆序的。线程栈struct thread_stack仅仅是个数据结构，是个存储数据的格式，表述结构中各成员的存储顺序，仅仅按照此格式中数据成员的顺序来压栈，所以它并不一定在某个固定的内存位置。此时栈中的情况如图9-14所示，最下面的4个寄存器是进入switch_to时压入的。
![image-20230627232658232](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230627232658232.png)
在PCB结构struct task_struct中，第一个成员是self_kstack，它用来记录每个线程自己的栈顶指针。任务在内核中的寄存器映像是保存在栈中的，这正是进入switch_to函数时立即把那4个寄存器入栈的原因。任务在下次被调度运行时，还得把寄存器映像从栈中恢复，因此，**为了恢复寄存器映像，先得知道寄存器映像被保存在哪个栈中，也就是得在切换前把当前的栈指针保存在某个地方，下次再被调度上处理器前，再从相同的地方恢复栈指针，将栈中的寄存器映像重新装载到处理器**，这个地方就是self_kstack，self_kstack在PCB中的偏移量为0，等同于PCB的起始地址。
因此switch_to和PCB是配合工作的，在switch_to中self_kstack已被固定引用为偏移PCB 0字节的地方，因此必须要把self_kstack放在PCB的起始处，即task_struct的开头。[esp + 20]获取到栈中cur的值，即当前线程的PCB地址，而**self_kstack在PCB中偏移为0，因此当前线程的PCB地址也是self_kstack的地址**，将其存入eax中后，再将当前栈顶指针esp保存到当前线程PCB中的self_kstack成员中，实现当前线程的上下文环境保存。
> 也就是说[esp + 20]是为了找到self_kstack的地址，用于保存当前栈顶指针esp，即PCB的起始地址。

mov eax, [esp + 24]获取到栈中的next的值，即next线程的PCB地址，之后将它mov到寄存器eax，同样此时eax可以认为是next线程PCB中self_kstack的地址。因此，[eax]中保存的是next线程的栈指针。
mov esp, [eax]将next线程的栈指针恢复到esp中，经过这一步后便找到next线程的栈，从而可以从栈中恢复之前保存过的寄存器映像。按照寄存器保存的逆顺序，依次从栈中弹出。
注意，不要误以为此时恢复的寄存器映像是在上面刚刚保存过的那些寄存器。在同一次switch_to的调用执行中，前面代码保存的寄存器属于当前线程cur，后面代码恢复的寄存器映像属于下一个上处理器运行的线程next，**这些被恢复的寄存器映像是在之前某次执行switch_to时，由现在的这个next线程作为那时候的当前线程cur，被换下处理器前保存的**，也是用前面代码代码保存的，只是它们分属于不同的switch_to调用次序。
ret便将当前栈顶处的值作为返回地址加载到处理器的eip寄存器中，从而使next线程的代码恢复执行。**如果此时的next线程之前尚未执行过**，马上开始的是第一次执行，此时栈顶的值是函数kernel_thread的地址，这是由thread_create函数设置的，执行ret指令后处理器将去执行函数kernel_thread。**如果next之前已经执行过了**，这次是再次将其调度到处理器的话，此时栈顶的值是由调用函数switch_to的主调函数schedule留下的，这会继续执行schedule后面的流程。而switch_to是schedule最后一句代码，因此执行流程马上回到schedule的调用者intr_timer_handler中。schedule同样也是intr_timer_handler中最后一句代码，因此会完成intr_timer_handler，回到kernel.S中的jmp intr_exit，从而恢复任务的全部寄存器映像，之后通过iretd指令退出中断，任务被完全彻底地恢复。
### thread_init
最后加入线程相关信息的初始化。通过list_init函数将就绪队列thread_ready_list和全部队列thread_all_list初始化，初始化的内容就是将队列为空，也就是使队列首尾相接。再通过函数make_main_thread将当前已运行的主函数封装为线程，本质上就是在其PCB中写入了线程信息。
上述set_cursor用于c调用，只和print.S的在mov bx, [esp+36]上存在区别：
```assembly
global set_cursor
set_cursor:
   pushad
   mov bx, [esp+36]
															;;;;;;; 1 先设置高8位 ;;;;;;;;
   mov dx, 0x03d4			  								;索引寄存器
   mov al, 0x0e				  								;用于提供光标位置的高8位
   out dx, al
   mov dx, 0x03d5			  								;通过读写数据端口0x3d5来获得或设置光标位置 
   mov al, bh
   out dx, al

															;;;;;;; 2 再设置低8位 ;;;;;;;;;
   mov dx, 0x03d4
   mov al, 0x0f
   out dx, al
   mov dx, 0x03d5 
   mov al, bl
   out dx, al
   popad
   ret
```
