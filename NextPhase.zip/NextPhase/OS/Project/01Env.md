# Env
> 下述均为环境测试的内容及命令，与实际内容无关。
## Bochs
Bochs（发音:box）是一个以LGPL许可证发放的开放源代码的x86、x86-64IBM PC兼容机模拟器和调试工具。它支持处理器（包括保护模式）、内存、硬盘、显示器、以太网、BIOS、IBM PC兼容机的常见硬件外设的仿真。
许多客户操作系统能通过该仿真器运行，包括DOS、Microsoft Windows的一些版本、AmigaOS 4、BSD、Linux、MorphOS、Xenix和Rhapsody（Mac OS X的前身）。Bochs能在许多主机操作系统运行，例如Windows、Windows Mobile、Linux、Mac OS X、iOS和PlayStation 2。
Bochs主要用于操作系统开发（当一个模拟操作系统崩溃，它不崩溃主机操作系统，所以可以调试仿真操作系统）和在主机操作系统运行其他来宾操作系统。它也可以用来运行不兼容的旧的软件（如电脑游戏）。
### 安装
```
sudo apt install build-essential
sudo apt-get install libghc-x11-dev
sudo apt-get install xorg-dev
```
下载Bochs`https://udomain.dl.sourceforge.net/project/bochs/bochs/2.6.8/bochs-2.6.8.tar.gz`
下载完毕之后将其移动至虚拟机中想要的位置，然后解压
```
tar -zxvf bochs-2.6.8.tar.gz
```
进入解压后的bochs-2.6.8文件夹，配置bochs的config文件（–prefix后面填安装bochs的目录），编译，安装
> 后续出现无法调试的情况，重新安装bochs
```
cd bochs-2.6.8
./configure --prefix=/实际路径/bochs --enable-debugger --enable-disasm --enable-iodebug --enable-x86-debugger --with-x --with-x11 LDFLAGS='-pthread'
make
make install

--prefix=/实际路径/bochs是用来指定bochs的安装目录。
--enable-debugger  打开bochs自己的调试器。如果想用gdb调试，就要将参数--enable-debugger替换为--enable-gdb-stub。
--enable-disasm　　 使bochs支持反汇编。
--enable-iodebug    启用io接口调试器。
--enable-x86-debugger  支持x86调试器。
--with-x  使用x windows。--with-x11使用x11图形用户接口。
```
### 配置
进入安装好bochs的目录 `cd ..` `cd bochs`创建`bochsrc.disk` ，下面是能够支持gdb的bochs配置文件
```
#第一步，首先设置Bochs在运行过程中能够使用的内存，本例为32MB。
#关键字为:megs

megs : 32

#第二步，设置对应真实机器的BIOS和VGA BIOS，对应两个关键字为:romimage 和 vgaromimage
romimage: file=/实际路径/bochs/share/bochs/BIOS-bochs-latest
vgaromimage: file=/实际路径/bochs/share/bochs/VGABIOS-lgpl-latest

#第三步，设置Bochs所使用的磁盘，软盘的关键字为floppy。
#若只有一个软盘，则使用floppya即可，若有多个，则为floppya，floppyb…
#floppya: 1_44=a.img, status=inserted

#第四步，选择启动盘符。
#boot: floppy　　默认从软盘启动，将其注释
#boot: disk　　　改为从硬盘启动。任何代码都将直接写在硬盘上，所以不会再有读写软盘的操作。
boot: disk

#第五步，设置日志文件的输出。
log: bochs.out

#第六步，开启或关闭某些功能。
#下面是关闭鼠标，并打开键盘。
mouse:enabled=0
keyboard:keymap=/实际路径/bochs/share/bochs/keymaps/x11-pc-us.map

#硬盘设置
ata0:enabled=1,ioaddr1=0x1f0,ioaddr2=0x3f0,irq=14
#增加硬盘，与bximage对应
ata0-master:type=disk,path="hd60M.img",mode=flat,cylinders=121,heads=16,spt=63

#下面的是增加的bochs对gdb的支持，这样gdb便可以远程连接到此机器的1234端口调试了
#gdbstub:enabled=1,port=1234,text_base=0,data_base=0,bss_base=0
```
配置后使用 -f 指定配置文件启动 bochs
```
bin/bochs -f bochsrc.disk
```
### 创建启动磁盘
bochs提供了创建虚拟硬盘的工具bin/bximage
```
bin/bximage
```
然后在输入框依次输入以下，输入一个，按一次回车
```
1
hd
flat
60
hd60M.img
```
## mbr测试
```assembly
SECTION MBR vstart=0x7c00
	mov ax,0x0000	;设置栈指应该是程序一开始就应该做的事情,这个值是参照1m内存空间布局图选择的，以后会刻意避开
	mov ss,ax
	mov ax,0x7c00
	mov sp,ax	

	mov ax,0x0600
	mov bx,0x0700	;BH是设置缺省属性，属性是指背景色，前景色，是否闪烁等，例如07H表示黑底白字，70H表示灰底黑字等等。
	mov cx,0x0000
	mov dx,0x184f	
	int 0x10
	
	mov ax,0x0300	
	mov bx,0x0000	
	int 0x10
	
	mov ax,0x0000
	mov es,ax
	mov ax,message
	mov bp,ax
	mov ax,0x1301
	mov bx,0x0007	;设置字体属性，02是黑底绿字，07是黑底白字
	mov cx,0x000c
	int 0x10
	
	jmp $
	message db "Hello World!"
	times 510-($-$$) db 0
	db 0x55,0xaa
```
## makefile
```makefile
BUILD_DIR=./build

ENTRY_POINT=0xc0001500

HD60M_PATH=/home/cafba/OS/bochs/hd60M.img

AS=nasm

CC=gcc-4.4

LD=ld

LIB= -I lib/ -I lib/kernel/ -I lib/user/ -I kernel/ -I device/ -I thread/ -I userprog/ 

ASFLAGS= -f elf

# -c 生成当前文件的二进制.o文件，不要进行链接
# -fno-stack-protector 禁用栈保护特性，应对报错 undefined reference to `__stack_chk_fail'
# -fno-builtin不使用GCC的内建函数
# -W 会显示警告，但是只显示编译器认为会出现错误的警告
# -Wstrict-prototypes 要求函数声明必须有参数类型，否则发出警告
# -Wmissing-prototypes 要求必须要有函数声明，否则发出警告
CFLAGS= -Wall $(LIB) -c -fno-builtin -fno-stack-protector -W -Wstrict-prototypes -Wmissing-prototypes -m32 

# -Ttext 指定编译起始虚拟位置
# -e 指定函数入口
# -m 指定模拟的链接环境
# -Map，生成map文件，就是通过编译器编译之后，生成的程序、数据及IO空间信息的一种映射文件，里面包含函数大小，入口地址等一些重要信息
LDFLAGS= -Ttext $(ENTRY_POINT) -e main -Map $(BUILD_DIR)/kernel.map -m elf_i386 

# 顺序是调用在前，实现在后
OBJS=$(BUILD_DIR)/main.o $(BUILD_DIR)/init.o \
	$(BUILD_DIR)/interrupt.o $(BUILD_DIR)/timer.o $(BUILD_DIR)/kernel.o \
	$(BUILD_DIR)/print.o $(BUILD_DIR)/debug.o $(BUILD_DIR)/string.o $(BUILD_DIR)/bitmap.o \
	$(BUILD_DIR)/memory.o $(BUILD_DIR)/thread.o $(BUILD_DIR)/list.o $(BUILD_DIR)/switch.o \
	$(BUILD_DIR)/sync.o $(BUILD_DIR)/console.o $(BUILD_DIR)/keyboard.o $(BUILD_DIR)/ioqueue.o \
	$(BUILD_DIR)/tss.o $(BUILD_DIR)/process.o $(BUILD_DIR)/syscall.o $(BUILD_DIR)/syscall-init.o \
	$(BUILD_DIR)/stdio.o

.PHONY : 
	mk_dir hd clean build all boot	

######################编译两个启动文件的代码#####################################
$(BUILD_DIR)/mbr.o : boot/mbr.S
	$(AS) -I boot/include/ -o build/mbr.o boot/mbr.S

$(BUILD_DIR)/loader.o : boot/loader.S
	$(AS) -I boot/include/ -o build/loader.o boot/loader.S
	
######################编译C内核代码###################################################
$(BUILD_DIR)/main.o : kernel/main.c
	$(CC) $(CFLAGS) -o $@ $<	
# $@表示规则中目标文件名的集合这里就是$(BUILD_DIR)/main.o  $<表示规则中依赖文件的第一个，这里就是kernle/main.c 

$(BUILD_DIR)/init.o : kernel/init.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/interrupt.o : kernel/interrupt.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/timer.o : device/timer.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/debug.o : kernel/debug.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/string.o : lib/string.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/bitmap.o:lib/kernel/bitmap.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/memory.o : kernel/memory.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/thread.o : thread/thread.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/list.o : lib/kernel/list.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/sync.o : thread/sync.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/console.o : device/console.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/keyboard.o : device/keyboard.c
	$(CC) $(CFLAGS) -o $@ $<
	
$(BUILD_DIR)/ioqueue.o : device/ioqueue.c
	$(CC) $(CFLAGS) -o $@ $<
	
$(BUILD_DIR)/tss.o : userprog/tss.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/process.o : userprog/process.c
	$(CC) $(CFLAGS) -o $@ $<

$(BUILD_DIR)/syscall.o : lib/user/syscall.c
	$(CC) $(CFLAGS) $< -o $@

$(BUILD_DIR)/syscall-init.o : userprog/syscall-init.c
	$(CC) $(CFLAGS) $< -o $@

$(BUILD_DIR)/stdio.o : lib/stdio.c
	$(CC) $(CFLAGS) -o $@ $<
	
###################编译汇编内核代码#####################################################
$(BUILD_DIR)/kernel.o : kernel/kernel.S 
	$(AS) $(ASFLAGS) -o $@ $<

$(BUILD_DIR)/print.o : lib/kernel/print.S
	$(AS) $(ASFLAGS) -o $@ $<

$(BUILD_DIR)/switch.o : thread/switch.S
	$(AS) $(ASFLAGS) -o $@ $<

##################链接所有内核目标文件##################################################
$(BUILD_DIR)/kernel.bin : $(OBJS)
	$(LD) $(LDFLAGS) -o $@ $^


# [ 和 ] 命令之间必须用空格进行分隔，因为 shell 命令需要确定一个参数的开始和结束
# ! 表示逻辑非，用于对条件进行取反。
# -d 是一个用于测试目录是否存在的选项，当指定路径为目录时，返回真；否则返回假。
# 当 if/else 结构包含多个命令时，需要在最后一个命令后面加上 ;，然后再添加 fi 结束
mk_dir:
	if [ ! -d $(BUILD_DIR) ];
		then mkdir $(BUILD_DIR);
	fi 

hd:
	dd if=build/mbr.o of=$(HD60M_PATH) count=1 bs=512 conv=notrunc && \
	dd if=build/loader.o of=$(HD60M_PATH) count=4 bs=512 seek=2 conv=notrunc && \
	dd if=$(BUILD_DIR)/kernel.bin of=$(HD60M_PATH) bs=512 count=200 seek=9 conv=notrunc

clean:
	@cd $(BUILD_DIR) && rm -f ./* && echo "remove ./build all done"

build : $(BUILD_DIR)/kernel.bin

boot : $(BUILD_DIR)/mbr.o $(BUILD_DIR)/loader.o

all : mk_dir boot build hd
```
1. MBR写入硬盘第0扇区，第1扇区是空的，loader写入硬盘第2扇区
2. loader.bin目前的大小是1342字节，占用3个扇区，因此count指定读入的扇区数为4
3. 为了给loader预留空间，载入内核从第9扇区开始，因此seek指定跨过前9个扇区（第0～8扇区），在第9个扇区写入
4. 因为将来的内核大小不会超过100KB，所以直接把count改为200块扇区，并且dd命令会自己判断写入的数据量，如果参数if指定的文件体积小于count\*bs，只按实际文件大小写入。
在上面的链接阶段，目标文件链接顺序是main.o在前，print.o在后。main.c文件中用到了print.o中的put_char函数，在链接顺序上，属于“调用在前，实现在后”的顺序。如果将print.o放在前面，main.o放在后面，也就是实现在前，调用在后，此时生成的可执行文件起始虚拟地址并不准确，会有向后顺延的现象，并且segment的数量也不一样。原因是链接器对符号表的处理细节造成的，链接器主要工作就是整合目标文件中的符号，为其分配地址，让使用该符号的文件可以正确定位到它。
链接器最先处理的目标文件是参数中从左边数第一个（这里是main.o），对于里面找不到的符号（这里是put_char），链接器会将它记录下来，以备在后面的目标文件中查找。如果将其顺序颠倒，势必导致在后面的目标文件中才出现找不到符号的情况，而该符号的实现所在的目标文件早已经过去了，这可能使链接器内部采用另外的处理流程，导致出来的可执行程序不太一样。
所以，**最好保持调用在前，实现在后的顺序来链接**。
