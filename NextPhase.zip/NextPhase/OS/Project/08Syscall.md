# Syscall
系统调用是Linux内核提供的一套子程序，它和Windows的动态链接库dll文件的功能一样，用来实现一系列在用户态不能或不易实现的功能，比如最常见的读写硬盘文件，只有操作系统有权限去访问硬件，用户程序是没有权限的，用户程序只能向操作系统寻求帮助，故系统调用是供用户程序来使用的。
系统调用很像BIOS中断调用，只不过系统调用的入口只有一个，因为中断的实现要用到中断描述符表，表中很多中断项是被预留的，不能强占，所以Linux就选一个可用的中断号即第0x80项中断作为所有系统调用的统一入口，具体的子功能在寄存器eax中单独指定。
系统调用的子功能要用eax寄存器来指定，在Linux系统中，系统调用是定义在/usr/include/asm/unistd.h文件中，该文件只是个统一的入口，指向了32位和64位两种版本。在asm目录下提供了这两个版本，文件名分别是unistd_32.h和unistd_64.h。
调用系统调用有两种方式。
1. 不依赖任何库函数，直接通过汇编指令int与操作系统通信。
2. 将系统调用指令封装为c库函数，通过库函数进行系统调用。
## 汇编
跨过库函数直接与系统内核通信，这样最终的程序不需要与任何库文件链接，这是获得系统功能效率最高的方式。
用汇编代码直接与内核通信，要看看系统调用输入参数的传递方式，当输入的参数小于等于5个时，Linux用寄存器传递参数。当参数个数大于5个时，把参数按照顺序放入连续的内存区域，并将该区域的首地址放到ebx寄存器。
eax寄存器用来存储子功能号（寄存器eip、ebp、esp是不能使用的）。5个参数存放在以下寄存器中，传送参数的顺序为ebx存储第1个参数，ecx存储第2个参数，edx存储第3个参数，esi存储第4个参数，edi存储第5个参数。
![image-20230531160012813](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230531160012813.png)
代码syscall_write.S中，演示了系统调用的两种方式。程序开头定义了两种方式下打印的字符串，其中0xa为LF（LineFeed）ASCII码，这样就会输出一个换行符。
第11～17行是在演示方式1，模拟调用C库函数write的方式。因为write是C库函数，按一般的做法是汇编程序需要与C代码生成的目标文件链接才能调用C的代码。在这个例子中并没有这样做，在这里定义了simu_write来代替C库函数write，用它来简单解释write的原理，它定义在第1～40行。这里是按照C调用约定将参数从右到左依次入栈，随后调用simu_write实现字符串打印功能。
第19～24行是在演示第2种系统调用的方式，这是最简单直接可依赖的方式。第0～24行是在eax中赋予子功能号，参数按照顺序依次写入对应的寄存器。
第31～40行是simu_write的实现，它内部在本质上和第2种方式一样，都是在内部调用int指令直接和系统通信实现系统调用。
编译链接过程如下：nasm -f elf -o syscall_write.o syscall_write.S
其中-f参数用来指定编译输出的文件格式，这里需要指定为elf，目的是将来要和gcc编译的elf格式的目标文件链接，所以格式必须相同。
最后用ld程序将syscall_write.o链接成elf格式的二进制可执行文件：ld -o syscall_write.bin syscall_write.o
## C封装


# 完善内核

## Linux系统调用
Linux系统调用是用中断门来实现的，通过软中断指令int来主动发起中断信号。要支持的系统功能很多，**Linux只占用一个中断向量号，即0x80，处理器执行指令int 0x80时便触发了系统调用。为了让用户程序可以通过这一个中断门调用多种系统功能，在系统调用之前，Linux在寄存器eax中写入子功能号**，例如系统调用open和close都是不同的子功能号，当用户程序通过int 0x80进行系统调用时，对应的中断处理例程会根据eax的值来判断用户进程申请哪种系统调用。
syscall的原型是int syscall(int number, …)，其中的number是int型，这是系统调用号，也就是子功能号。不同的子功能需要的参数也是不同的，所以number后面的“…”表示此函数支持变参，函数syscall支持不同参数个数的系统调用，在新版本Linux中，所有的系统调用功能都可通过这一个函数完成。传入的参数一般是`__NR_`+系统调用名称形式的子功能号宏。

函数syscall并不是由操作系统提供的，它是由C运行库glibc（GNU发布的libc库版本）提供的，因此syscall实际上是库函数，因此syscall属于间接的系统调用。

直接的方式是由操作系统提供的`_syscall[X]`，它是一系列的宏。用`_syscall`进行系统调用不需要通过库函数，这说明它是直接的系统调用方式。不过，此方法已经被Linux废弃了，只是废弃了`_syscall`这个符号，废弃的原因是此方式最多支持6个参数。`_syscall`是系统调用族，所以用`_syscallX`来表示它们，其中的X表示系统调用中的参数个数，其原型是`_syscallX(type,name,type1,arg1,type2,arg2,…)`。

`_syscallX`是用宏来实现的，根据系统调用中参数个数、类型及返回值的不同，共有7个不同的宏，分别是`_syscall[0-6]`，因此，对于参数个数不同的系统调用，需要调用不同的宏来完成。**type是系统调用的返回值类型，name是系统调用名称（字符串），最后通过宏替换会转换成数值型的子功能号**，typeN和argN配对出现，分别表示参数的类型及变量名。下面拿_syscall3举例。

```c
#define _syscall3(type, name, type1, arg1, type2, arg2, type3, arg3) 				\
type name(type1 arg1, type2 arg2, type3 arg3) { 									\
	long __res; 																	\
	__asm__ volatile ("push %%ebx; movl %2,%%ebx; int $0x80; pop %%ebx" 			\
                    	: "=a" (__res) 												\
   				     	: "0" (__NR_##name),"ri" ((long)(arg1)),"c" ((long)(arg2)), \
            			"d" ((long)(arg3)) : "memory");								\
	__syscall_return(type, __res); 													\
 }
```

Linux中的系统调用是用寄存器来传递参数的，这些参数需要按照从左到右的顺序依次存入到不同的通用寄存器（除esp）中。其中，**寄存器eax用来保存子功能号，ebx保存第1个参数，ecx保存第2个参数，edx保存第3个参数，esi保存第4个参数，edi保存第5个参数**。

type是函数的返回值类型，name是函数名，也就是系统调用名，函数名后面括号中是一系列的形参，用的是宏`_syscall3`中的参数，`__res`是返回值。

第5行的"=a" (`__res`)位于输出部output，这表明变量`__res`由寄存器eax赋值。根据ABI约定，eax作为函数调用的返回值，这里是用变量`__res`来存储从中断返回后的返回值。

第6行是参数输入部input，"0" (`__NR_##name`)中的`_NR_##name`是系统调用的字符串名，经过预处理后会先变成`__NR_`系统调用名，然后变成数值型的子功能号，其中“##”表示联结字符串，这是预处理器支持的语法，比如系统调用名为getpid，预处理后就变成`__NR_getpid`，`__NR_getpid`也是宏。

"0" (`__NR_##name`)中的0是通用约束，表示`__NR_##name`使用的寄存器或内存与第0个约束表达式使用的寄存器或内存一致，这里指的是和第5行的"=a" (`__res`)一致，也就是**寄存器eax既做子功能号输入，又做返回值的输出**。后面"ri" ((long)(arg1))是将变量arg1约束到通用寄存器中，"c"((long)(arg2))是将变量约束到ecx寄存器中，第7行的"d" ((long)(arg3))是将变量约束到edx中。

第4行内联汇编代码，其中push %%ebx的作用是在用户空间的栈中提前保护好ebx的值，movl %2,%%ebx将arg1的值写入寄存器ebx，%2是序号占位符，表示第2个约束，即arg1对应的寄存器或内存。int $0x80触发软中断，进行系统调用，完成后通过pop %%ebx恢复ebx的值。

第8行是对返回值`__res`判断后返回，其中__syscall_return也是个宏，实现如下。

```c
#define __syscall_return(type, res)                     		\
    do {														\
        if ((unsigned long)(res) >= (unsigned long)(-125)) { 	\
            errno = -(res);                              		\
            res = -1;                                   		\
        }                                                		\
		return (type) (res);                                	\
	} while (0)
```

**当参数多于5个时，可以用内存来传递，此时在内存中存储的参数仅是第1个参数及第6个以上的所有参数，不包括第2～5个参数，第2～5个参数依然要顺序放在寄存器ecx、edx、esi及edi中，eax始终是子功能号。**

```c
#define _syscall6(type,name, type1,arg1, type2,arg2, 								\
				  type3,arg3,type4,arg4, type5,arg5, type6,arg6) 					\
type name (type1 arg1,type2 arg2,type3 arg3, 										\
		   type4 arg4,type5 arg5,type6 arg6) { 										\
    long __res; 																	\
    struct { long __a1; long __a6; } __s = { (long)arg1, (long)arg6 }; 				\
    __asm__ volatile ("push %%ebp ; push %%ebx ; movl 4(%2),%%ebp ; " 				\
                      "movl 0(%2),%%ebx ; movl %1,%%eax ; int $0x80 ; " 			\
                      "pop %%ebx ;  pop %%ebp" 										\
                      : "=a" (__res) 												\
                      : "i" (__NR_##name),"0" ((long)(&__s)),"c" ((long)(arg2)), 	\
                      "d" ((long)(arg3)),"S" ((long)(arg4)),"D" ((long)(arg5)) 		\
                      : "memory"); 													\
    __syscall_return(type,__res); 													\ 
}
```

在_syscall6的第6行声明了结构及实例，然后在第11行将实例__s的地址作为输入，最后在第7行用movl 4(%2),%%ebp将第6个参数写入寄存器ebp，在第8行用movl 0(%2),%%ebx将第1个参数写入ebx。总之ebx中还是第1个参数。

> 0(%2) 指的是相对于第二个序号寄存器中的地址偏移量为0，即__s中的arg1
>
> 4(%2)，即__s中的arg6

宏`_syscall`和库函数syscall相比，syscall实现更灵活，对用户来说任何参数个数的系统调用都统一用一种形式，用户只要记住syscall就可以，而宏`_syscall`的实现比较死板，针对每种参数个数的系统调用都要有单独的形式，因此支持的参数数量必然有限，而且用户要记住7种形式`_syscall[0-6]`，调用时除了输入实参外，还要输入实参的类型，故必然会被syscall取代。

这里所说Linux废弃宏`_syscall`，是指Linux系统不提供`_syscall`的定义及实现了，因此用户进程无法通过宏`_syscall`进行系统调用，`_syscall`虽然已经很直接了，但真正最直接的方式是汇编代码“mov eax，子功能号;int 0x80”，`_syscall`是这两句汇编指令的封装，**在Linux系统内部，系统调用接口并未改变，依然是在中断向量0x80对应的中断处理例程中把eax的值作为子功能号，然后调用相应的子功能函数，其对外形式依旧是eax为子功能号，然后执行0x80中断**。

虽然库函数syscall更加先进，但为了实现简单，参考这宏_syscall来完成。

> 传递参数还可以用栈（内存），为什么Linux用寄存器来传递参数，而不用栈？
>
> 因为用寄存器用寄存器传参的步骤少一些，用户进程执行int 0x80时还处于用户态，编译器根据c调用约定，系统调用所用的参数会被压到用户栈中，这是3特权级栈。当int 0x80执行后，任务陷入内核态，此时进入了0特权级，因此需要用到0特权级栈，但系统调用的参数还在3特权级的栈中，为了获取用户栈地址，还得在0特权级栈中获取处理器自动压入的用户栈的SS和esp寄存器的值，然后再次从用户栈中获取参数，这涉及到两种栈的读写，故通过寄存器传递参数效率更高。

## 系统调用的实现

一个系统功能调用分为两部分，一部分是暴露给用户进程的接口函数，它属于用户空间，此部分只是用户进程使用系统调用的途径，只负责发需求。另一部分是与之对应的内核具体实现，它属于内核空间，此部分完成的是功能需求，就是系统调用子功能处理函数。为区分这两部分，一般情况下内核空间的函数名要在用户空间函数名前加`sys_`。

以函数getpid为例，getpid的功能是返回任务的pid，这是给用户进程使用的系统调用的接口，接口的另一端是实现该功能的内核函数，该内核函数就是系统调用子功能为getpid对应的函数，即sys_getpid，由它负责找出调用者的pid并返回。

系统调用的实现思路。

1. 用中断门实现系统调用，效仿Linux用0x80号中断作为系统调用的入口。

2. 在IDT中安装0x80号中断对应的描述符，在该描述符中注册系统调用对应的中断处理例程。

3. 建立系统调用子功能表syscall_table，利用eax寄存器中的子功能号在该表中索引相应的处理函数。

4. 用宏实现用户空间系统调用接口`_syscall`，最大支持3个参数的系统调用，故只需要完成`_syscall[0-3]`。寄存器传递参数，eax为子功能号，ebx保存第1个参数，ecx保存第2个参数，edx保存第3个参数。


以上4个步骤的流程如图12-5所示。

![image-20230902002604113](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230902002604113.png)

根据以上流程，为实现系统调用：

- 增加0x80号中断描述符，在idt_desc_init中初始化，见interrupt.md
- kernel.S中增加0x80号中断处理例程syscall_handler，见interrupt.md
- 增加分配pid的函数allocate_pid，见thread.md
- 定义枚举结构enum SYSCALL_NR用来存放系统调用子功能号。
- 实现系统调用接口`_syscall`，用户进程可以通过调用宏_syscall[0-6]进行系统调用，它的核心就是用内联汇编传参并触发中断。
- 实现用户进程使用的接口函数，通过系统调用接口_syscall调用在内核中对应的处理函数sys_xxx。
- 定义子功能处理函数sys_xxx，将其注册到系统调用子功能数组syscall_table，使数组syscall_table中的元素为子功能处理函数指针，这样在0x80号中断向量的中断处理例程中才能调用到相应的子功能处理函数，具体的函数调用是文件kernel.S的代码call [syscall_table + eax*4]。

> 之所以_syscall0(SYS_GETPID)可以调用sys_getpid，是因为在syscall_table中注册了SYS_GETPID子功能号对应的处理函数sys_getpid，通过触发软中断，会去syscall_table中找对应子功能号的函数进行执行，这是在Kernel.S中实现的。

```c

#define syscall_nr 32 
typedef void* syscall;
syscall syscall_table[syscall_nr];

// 返回当前任务的pid
uint32_t sys_getpid(void) {
   return running_thread()->pid;
}

// 打印字符串str(未实现文件系统前的版本)
uint32_t sys_write(char* str) {
   console_put_str(str);
   return strlen(str);
}

// 初始化系统调用
void syscall_init(void) {
	put_str("syscall_init start\n");
	syscall_table[SYS_GETPID] = sys_getpid;
	syscall_table[SYS_WRITE] = sys_write;
	syscall_table[SYS_MALLOC] = sys_malloc;
   	syscall_table[SYS_FREE] = sys_free;
	put_str("syscall_init done\n");
}
```

## 可变参数Printf

### 可变参数

堆内存专门用于程序运行时的内存申请，因此编译器也开始支持程序在运行时动态内存申请，也就是编译器开始支持源码中的变长数据结构。编译时确定是指数据结构在源码编译阶段就能确定下来，编译器必须提前知道数据结构的长度，它为此类数据结构分配的是静态内存，也就是程序被操作系统加载时分配的内存。运行时确定是指数据结构的长度是在程序运行阶段确定下来的，编译器为此类数据结构在堆中分配内存。

函数占用的也是静态内存，因此也得提前告诉编译器自己占用的内存大小。为了在编译时获取函数调用时所需要的内存空间（这通常是在栈中分配内存单元），编译器要求提供函数声明，声明中描述了函数参数的个数及类型，编译器用它们来计算参数所占据的栈空间。因此编译器不关心函数声明中参数的名称，它只关心参数个数及类型，编译器用这两个信息才能确定为函数在栈中分配的内存大小。

函数并不是在堆中分配内存，因此它需要提前确定内存空间，这通常取决于参数的个数及类型大小，但编译器却允许函数的参数个数不固定（可变参数）？其实**可变参数的这种动态本质上还是静态，这一切得益于编译器采用C调用约定来处理函数的传参方式。C调用约定规定：由调用者把参数以从右向左的顺序压入栈中，并且由调用者清理堆栈中的参数。**

拿printf(char* format, arg1, arg2，…)举例，其中的参数format就是包含“%类型字符”的字符串，其调用后栈中布局如图12-7所示。

![image-20230902130728705](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230902130728705.png)

既然参数是由调用者压入的，调用者当然知道栈中压入了几个参数，参数占用了多少空间，因此无论函数的参数个数是否固定，采用C调用约定，调用者都能完好地回收栈空间，不必担心栈溢出等问题。因此，看似动态的可变参数函数，其实也是静态固定的，传入参数的个数是由编译器在编译阶段就确定下来的。

比如printf（”hello %s!”, ”martin”），其中的”hello %s!”便是format。在格式化字符串中的字符'%'便是在栈中寻找可变参数的依据，紧跟'%'后面的是类型字符，类型字符表示数据类型和进制相关的内容。格式化字符串中有多少'%'，就在栈中找多少次参数。

为方便引用函数中的可变参数，编译器gcc的头文件stdarg.h中定义了3个宏，如图12-8所示。

![image-20230902130812748](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230902130812748.png)

这3个宏va_start、va_end和va_arg都以va（Variable Argument）开头，表示可变参数，但这里它们的值都是以`_builtin`为开头的内建符号，就拿va_start(v,l)来说，它的值为`_builtin_va_start(v,l)`，_builtin_va_start内建函数的实现在其源码文件builtins.c中。

![image-20230902130807106](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230902130807106.png)

ap（argument pointer）是个指针变量，表示参数的指针，用来指向可变参数在栈中的地址。由于ap用于指向栈中可变参数的地址，其所指向的参数类型未知，因此其类型为通用类型`char*`，即图中的va_list。

下面是3个宏的说明。

1. va_start(ap,v)，参数ap是用于指向可变参数的指针变量，参数v是支持可变参数的函数的第1个参数（如对于printf来说，参数v就是字符串format）。此宏的功能是使指针ap指向v的地址，它的调用必须先于其他两个宏，相当于初始化ap指针的作用。

2. va_arg(ap,t)，参数ap是用于指向可变参数的指针变量，参数t是可变参数的类型，此宏的功能是使指针ap指向栈中下一个参数的地址并返回其值。

3. va_end(ap)，将指向可变参数的变量ap置为null，也就是清空指针变量ap。


### write

printf函数是格式化输出函数，但真正起到格式化作用的是vsprintf函数，真正起输出作用的是write系统调用

write接受3个参数，其中的fd是文件描述符，buf是被输出数据所在的缓冲区，count是输出的字符数，write的功能是把buf中count个字符写到文件描述符fd指向的文件中。

1. 先在syscall.h中的结构enum SYSCALL_NR里添加新的子功能号SYS_WRITE：

2. 在syscall.c中增加系统调用的用户接口。write简易版只需要一个参数，作用是向屏幕上打印str。这里用一个参数的宏_syscall1来完成系统调用。

3. 在syscall-init.c中定义子功能处理函数sys_write并在syscall_table中注册。

### 宏

printf是C语言标准输出函数，其原型是：int printf(const char *format, ...);

printf是vsprintf和write的封装，在Linux中执行man vsprintf，可以看到其原型是

```c
int vsprintf(char *str, const char *format, va_list ap);
```

此函数的功能是把ap指向的可变参数，以字符串格式format中的符号'%'为替换标记，不修改原格式字符串format，将format中除“%类型字符”以外的内容复制到str，把“%类型字符”替换成具体参数后写入str中对应“%类型字符”的位置，也就是说函数执行后，str的内容相当于格式字符串format中的“%类型字符”被具体参数替换后的format字符串。

```c
#define va_start(ap, v) ap = (va_list)&v        	// 把ap指向第一个固定参数v
#define va_arg(ap, t) *((t*)(ap += 4))	         	// ap指向下一个参数并返回其值
#define va_end(ap) ap = NULL		               	// 清除ap
```

va_start(ap, v)的作用是初始化指针ap，即把ap指向栈中可变参数中的第一个参数v，其实现是ap = (va_list)&v。ap和v的类型都是char\*，但不同的是ap用来存储v的地址&v，&v的类型实际是二级指针，因此用(va_list)强制转换为一级指针后再赋值给ap。

va_arg(ap, t)的作用是使指针ap指向栈中下一个参数，并根据下一个参数的类型t返回下一个参数的值，其实现是`*((t*)(ap += 4))`。va_arg(ap, t)必须在va_start(ap, v)之后调用，否则指针ap未初始化将导致错误。经va_start初始化后，ap已经指向了栈中可变参数中的第1个参数，由于32位栈的存储单元是4字节，故(ap+=4)将指向下一个参数在栈中的地址，而后将其强制转换成t型指针`(t*)`，最后再用*号取值，即`*((t*)(ap += 4))`是下一个参数的值。

va_end(ap)的作用就是回收指针ap，清空，其实现为ap = NULL。

### iota

```c

// 将整型转换成字符(integer to ascii)
static void itoa(uint32_t value, char** buf_ptr_addr, uint8_t base) {
    uint32_t m = value % base;	                  	// 对基数base求模，逐步求出每一级的最低位   
    uint32_t i = value / base;	                  	// 对基数base取整数倍，此整数倍用于递归调用
    if (i) {			                            // 如果倍数不为0则递归调用
        itoa(i, buf_ptr_addr, base);
    }
    // 将转换后的数值转换成字符
    if (m < 10) {     								// 如果余数是0~9
        *((*buf_ptr_addr)++) = m + '0';	  			// 将数字0~9转换为字符'0'~'9'
    } 
    else {	      									// 否则余数是A~F
        // 用0xA～0xF减去10（0xA）所得到的差，加上字符A的ASCII码，便是字符'A'～'F'的ASCII码
        *((*buf_ptr_addr)++) = m - 10 + 'A'; 		// 将数字A~F转换为字符'A'~'F'
    }
}
```

iota的任务有两个：一个是数制转换，原理是把数值对基数求模，先掉下来的是最低位（个位），然后递归调用，依次求出次低位……次高位、最高位，直到数值无法整除基数，也就是没有数位可取，倍数为0时结束，另一个就是将转换后的整型再转换为字符串。

itoa接受3个参数，第1个参数value是待转换的整数，第2个参数buf_ptr_addr是保存转换结果的缓冲区指针的地址，即二级指针，因此类型是`char**`。第3个参数base是转换的基数，也就是进制。

> 这里用二级指针的原因是：在函数实现中要将转换后的字符写到缓冲区指针指向的缓冲区中的1个或多个位置，这取决于进制转换后的数值的位数，比如十六进制0xd转换成十进制后变成数值13，13要被转换成字符'1'和'3'，所以数值13变成字符后将占用缓冲区中两个字符位置，字符写到哪里是由缓冲区指针决定的。
>
> 因此**每写一个字符到缓冲区后，要更新缓冲区指针的值以使其指向缓冲区中下一个可写入的位置，这种原地修改指针的操作，最方便的是用其下一级指针类型来保存此指针的地址**，故将一级指针的地址作为参数传给二级指针buf_ptr_addr，这样便于原地修改一级指针。
>
> itoa用的是二级指针作为形参，便于原地修改一级指针（此处为缓冲区指针）。试想一下，如果用一级指针作为形参，缓冲区指针作为实参，由于参数是值传递，为更新缓冲区指针的值，要么用个全局变量来记录，要么itoa将最新指针返回，不如二级指针原地修改方便。

### vsprint

vsprint将参数ap按照格式format输出到字符串str并返回替换后str的长度。

sprintf与printf类似，区别是sprintf并不把字符串输出到标准输出，而是写到字符串buf中，原理也和printf一样。

开启页表机制，任何地址都将视作虚拟地址。之前编写print.S时，由于是给内核用的，所以用于与显存段打交道的地址有些是借助于内核页目录表0号项进行寻址的，**现在将print共享给了用户进程，而用户进程无法去访问内核页目录表0号项。但是由于进程页目录表768号项与内核页目录表0号项指向同一张内核的页表（因为进程页目录表768号项就是拷贝的内核页目录表768号项）**。所以能通过进程页目录表768号项访问原来通过内核页目录表0号项访问的地址。所以，需要修改print.S中的一些地址访问，将其升高3G，这样能让原本通过内核页目录表0号项访问的地址，现在能通过进程页目录表768号项访问。

```c

char* arg_str;

// 将参数ap按照格式format输出到字符串str，并返回替换后str长度
uint32_t vsprintf(char* str, const char* format, va_list ap) {
    char* buf_ptr = str;	
    const char* index_ptr = format;
    // index_char指向格式字符串format中的每个字符，用它来找字符'%'
    char index_char = *index_ptr;

    int32_t arg_int;
    char* arg_str;		// arg_str是指针变量，专门处理%s
    while(index_char) {	// 用while(index_char)循环判断format中的每个字符index_char，直到index_char为结束字符'\0'
        if (index_char != '%') {	// 复制format中除'%'以外的字符到buf_ptr，也就是复制到str中
            *(buf_ptr++) = index_char;
            index_char = *(++index_ptr);
            continue;
        }
        // 当index_char为字符'%'时，也就是找到了待替换的 %类型字符
        // 先++index_ptr跳过字符'%'，然后取值，将获取到的类型字符更新index_char
        index_char = *(++index_ptr);	 			// 得到%后面的字符
        switch(index_char) {
            case 's':		// 当操作数对象为字符串时，编译器只会把字符串的地址作为操作数，并不会把整个字符串中的全部字符复制一份作为参数
                arg_str = va_arg(ap, char*);			// 获取了待打印字符串的地址，返回给变量arg_str
                strcpy(buf_ptr, arg_str);				// 将待打印字符串arg_str拷贝到buf_ptr中，完成拼接
                buf_ptr += strlen(arg_str);				// 更新buf_ptr的指针，跨过待打印字符串的长度
                index_char = *(++index_ptr);			// 更新index_char的值为类型字符's'后面的字符
                break;
            case 'c':
                *(buf_ptr++) = va_arg(ap, char);		// 直接获得单个字符后写入buf_ptr
                index_char = *(++index_ptr);			// 使指针index_ptr跨过字符'c'，并更新index_char
                break;
            case 'd':
                arg_int = va_arg(ap, int);
                if (arg_int < 0) {
                    arg_int = 0 - arg_int;				// 若是负数, 将其转为正数后
                    *buf_ptr++ = '-';					// 在其前添加个负号
                }
                itoa(arg_int, &buf_ptr, 10); 
                index_char = *(++index_ptr);
                break;
            case 'x':									// 只支持十六进制的输出，也就是类型符号为x
                arg_int = va_arg(ap, int);				// 通过宏va_arg(ap, int)获取下一个整型参数，将结果存储到变量arg_int中
                itoa(arg_int, &buf_ptr, 16); 			// 调用itoa将arg_int转换为十六进制，并存储到buf_ptr中
                // 此时index_ptr指向类型字符'x'，故跨过类型字符'x'
                // 更新index_char为字符'x'后面的下一个字符，继续下一轮循环在format中找字符'%'
                index_char = *(++index_ptr); 			// 跳过格式字符并更新index_char
                break;
        }
    }
    return strlen(str);
}

// 格式化输出字符串format
uint32_t printf(const char* format, ...) {
   va_list args;									// 即ap，用它来指向参数
   va_start(args, format);	       					// 使args指向format
   char buf[1024] = {0};	       					// 存储由vsprintf处理的结果，也就是str
   vsprintf(buf, format, args);
   va_end(args);									// 使args清空
   return write(buf); 								// 将处理后的字符串输出。
}

uint32_t sprintf(char* buf, const char* format, ...) {
   va_list args;
   va_start(args, format);	       					
   retval = vsprintf(buf, format, args);
   va_end(args);
   return retval; 
}
```

