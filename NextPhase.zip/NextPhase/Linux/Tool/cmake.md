## 指令
PROJECT(projectname [CXX] [C] [Java])：定义工程名称，并可指定工程支持的语言，支持的语言列表是可以忽略的，默认情况表示支持所有语言。
> 这个指令隐式的定义了两个 cmake 变量: <projectname>\_BINARY_DIR 以及 <projectname>_SOURCE_DIR，等价于系统预定义的 PROJECT_BINARY_DIR 和 PROJECT_SOURCE_DIR 变量，分别表示编译发生的当前目录和工程代码所在目录，如果采用内部编译，二者相同。

MESSAGE([SEND_ERROR | STATUS | FATAL_ERROR] "message to display" ...)：向终端输出用户定义的信息，包含了三种类型。
- SEND_ERROR，产生错误，生成过程被跳过。
- SATUS，输出前缀为—的信息。
- FATAL_ERROR，立即终止所有 cmake 过程。
ADD_SUBDIRECTORY(source_dir [binary_dir] [EXCLUDE_FROM_ALL])：向当前工程添加存放源文件的子目录，并可以指定中间二进制和目标二进制存放的位置。EXCLUDE_FROM_ALL 参数的含义是**将这个目录从编译过程中排除**，比如，工程的 example，可能就需要工程构建完成后，再进入 example 目录单独进行构建。
SUBDIRS(dir1 dir2...)：一次添加多个子目录，并且，即使外部编译，子目录体系仍然会被保存。
通过 SET 指令重新定义 EXECUTABLE_OUTPUT_PATH 和 LIBRARY_OUTPUT_PATH 变量，可以指定最终的目标二进制的位置(指最终生成的 hello 或者最终的共享库，不包含编译生成的中间文件)。
上面的例子定义了将 t2 的子目录 src 子目录加入工程，并指定编译输出(包含编译中间结果)路径为 bin 目录。如果不进行 bin 目录的指定，那么编译结果(包括中间结果)都将存放在 build/src 目录(这个目录跟原有的 src 目录必须对应)，指定 bin 目录后，相当于在编译时将 src 重命名为 bin，所有的中间结果和目标二进制都将存放在 bin 目录。
```
# 建立目录 t2，与 t2 的子目录 src，在子目录中编写 main.c
# 进入子目录 src，编写 CMakeLists.txt 如下：
ADD_EXECUTABLE(hello main.c)
# 将 t2 的 CMakeLists.txt 编写为：
ADD_SUBDIRECTORY(src bin)
# 建立 build 目录，进入 build 目录进行外部编译
cmake ..
make
# t2 的 CMakeLists.txt 添加：
SET(EXECUTABLE_OUTPUT_PATH ${PROJECT_BINARY_DIR}/bsd)
```
上面的例子中，hello 文件将出现在 bsd 目录中，如果不添加，将仍然是在 bin 目录中。

## 安装

### 工程文件的安装

INSTALL(TARGETS targets... [[ARCHIVE | LIBRARY | RUNTIME] 

[ DESTINATION [PERMISSIONS permissions...] [CONFIGURATIONS [Debug|Release|...]] [COMPONENT ] [OPTIONAL] ] [...])

参数中的 TARGETS 后面跟的就是通过 ADD_EXECUTABLE 或者 ADD_LIBRARY 定义的目标文件，可能是可执行二进制、动态库、静态库。

目标类型也就相对应的有三种，ARCHIVE 特指静态库，LIBRARY 特指动态库，RUNTIME 特指可执行目标二进制。

DESTINATION 定义了安装的路径，如果路径以 / 开头，那么指的是绝对路径，这时候 CMAKE_INSTALL_PREFIX 其实就无效了。如果希望使用CMAKE_INSTALL_PREFIX 来定义安装路径，就要写成相对路径，即不要以/开头，那么安装后的路径就是 ${CMAKE_INSTALL_PREFIX}/<DESTINATION>。

```cmake
cmake -D CMAKE_INSTALL_PREFIX=/usr
INSTALL(TARGETS myrun mylib mystaticlib 
		RUNTIME DESTINATION bin 
		LIBRARY DESTINATION lib
		ARCHIVE DESTINATION libstatic)
```

上面的例子会将：

- 可执行二进制 myrun 安装到 ${CMAKE_INSTALL_PREFIX}/bin 
- 目录动态库 libmylib 安装到 ${CMAKE_INSTALL_PREFIX}/lib 目录
- 静态库 libmystaticlib 安装到 ${CMAKE_INSTALL_PREFIX}/libstatic 目录

### 普通文件的安装

INSTALL(FILES files... DESTINATION <dir> [PERMISSIONS permissions...] [CONFIGURATIONS [Debug|Release|...]] [COMPONENT <component>] [RENAME ] [OPTIONAL])

可用于安装一般文件，并可以指定访问权限，文件名是此指令所在路径下的相对路径。如果默认不定义权限PERMISSIONS，安装后的权限为：

OWNER_WRITE, OWNER_READ, GROUP_READ,和WORLD_READ，即 644 权限。

### 非目标文件的可执行程序安装(比如脚本之类)

INSTALL(PROGRAMS files... DESTINATION <dir> [PERMISSIONS permissions...] [CONFIGURATIONS [Debug|Release|...]] [COMPONENT <component>] [RENAME <name>] [OPTIONAL])

跟上面的 FILES 指令使用方法一样，唯一的不同是安装后权限为：OWNER_EXECUTE, GROUP_EXECUTE, 和 WORLD_EXECUTE，即755 权限目录的安装。

### 目录的安装

INSTALL(DIRECTORY dirs... DESTINATION <dir> [FILE_PERMISSIONS permissions...] [DIRECTORY_PERMISSIONS permissions...] [USE_SOURCE_PERMISSIONS] [CONFIGURATIONS [Debug|Release|...]] [COMPONENT <component>]

[[PATTERN <pattern> | REGEX <regex>] [EXCLUDE] [PERMISSIONS permissions...]] [...])

DIRECTORY 后面连接的是所在 Source 目录的相对路径，但 /abc 和 /abc/ 有很大的区别。/abc 代表 abc 这个目录将被安装为目标路径下的 abc，/abc/ 代表将 abc 这个目录中的内容安装到目标路径，但不包括这个目录本身。

PATTERN 用于使用正则表达式进行过滤，PERMISSIONS 用于指定 PATTERN 过滤后的文件权限。

```cmake
INSTALL(DIRECTORY icons scripts/ 
		DESTINATION share/myproj
		PATTERN "CVS" EXCLUDE 
		PATTERN "scripts/*"
		PERMISSIONS OWNER_EXECUTE OWNER_WRITE OWNER_READ GROUP_EXECUTE GROUP_READ)
```

这条指令的执行结果是：

将 icons 目录安装到 <prefix>/share/myproj，将 scripts/ 中的内容安装到 <prefix>/share/myproj

不包含目录名为 CVS 的目录，对于 scripts/* 文件指定权限为 OWNER_EXECUTE OWNER_WRITE OWNER_READ GROUP_EXECUTE GROUP_READ。

### 案例

```cmake
# 目的是安装到 ./tmp/t2/usr 下的各个目录中
# CMAKE_INSTALL_PREFIX 的默认定义是/usr/local
cmake -DCMAKE_INSTALL_PREFIX=/tmp/t2/usr ..

# 安装普通文件 COPYRIGHT README 到 ./tmp/t2/usr/share/doc/cmake/t2
INSTALL(FILES COPYRIGHT README DESTINATION share/doc/cmake/t2)
# 安装脚本到 ./tmp/t2/usr/bin
INSTALL(PROGRAMS runhello.sh DESTINATION bin)
# 安装目录 doc/ 下的内容到 ./tmp/t2/usr/share/doc/cmake/t2 不包括 doc 目录本身
INSTALL(DIRECTORY doc/ DESTINATION share/doc/cmake/t2)
```

## 静态库与动态库

ADD_LIBRARY(libname [SHARED|STATIC|MODULE] [EXCLUDE_FROM_ALL] source1 source2 ... sourceN)

不需要写全 libhello.so，只需要填写 hello 即可，cmake 系统会自动生成 libhello.X

类型有三种:

- SHARED，动态库
- STATIC，静态库
- MODULE，在使用 dyld 的系统有效，如果不支持dyld，则被当作SHARED 对待。

EXCLUDE_FROM_ALL 参数的意思是这个库不会被默认构建，除非有其他的组件依赖或者手工构建。

SET_TARGET_PROPERTIES(target1 target2 ... PROPERTIES prop1 value1 prop2 value2 ...)

SET_TARGET_PROPERTIES(hello PROPERTIES VERSION 1.2 SOVERSION 1) VERSION 指代动态库版本，SOVERSION 指代 API 版本。

**首先建立动态库与静态库：**

```cmake
SET(LIBHELLO_SRC hello.c)
ADD_LIBRARY(hello SHARED ${LIBHELLO_SRC})
ADD_LIBRARY(hello_static STATIC ${LIBHELLO_SRC})
SET_TARGET_PROPERTIES(hello_static PROPERTIES OUTPUT_NAME "hello")
# 如果 cmake 在构建一个新的target 时，会尝试清理掉其他使用这个名字的库，则使用以下回避
SET_TARGET_PROPERTIES(hello PROPERTIES CLEAN_DIRECT_OUTPUT 1)
SET_TARGET_PROPERTIES(hello_static PROPERTIES CLEAN_DIRECT_OUTPUT 1)

# 将 hello 的共享库安装到 <prefix>/lib 目录，将 hello.h 安装到 <prefix>/include/hello 目录
# cmake -DCMAKE_INSTALL_PREFIX=/usr ..
INSTALL(TARGETS hello hello_static LIBRARY DESTINATION lib ARCHIVE DESTINATION lib)
INSTALL(FILES hello.h DESTINATION include/hello)
```

**之后使用库的时候引入头文件搜索路径：**

INCLUDE_DIRECTORIES([AFTER|BEFORE] [SYSTEM] dir1 dir2 ...)

这条指令可以用来向工程添加多个特定的头文件搜索路径，路径之间用空格分割，如果路径中包含了空格，可以使用双引号将它括起来，默认的行为是追加到当前的头文件搜索路径的后面，可以通过两种方式来进行控制搜索路径添加的方式：

- CMAKE_INCLUDE_DIRECTORIES_BEFORE，通过 SET 这个 cmake 变量为 on，可以将添加的头文件搜索路径放在已有路径的前面。
- 通过 AFTER 或者 BEFORE 参数，也可以控制是追加还是置前。

**最后为 target 添加共享库：**

LINK_DIRECTORIES(directory1 directory2 ...)：添加非标准的共享库搜索路径，比如，在工程内部同时存在共享库和可执行二进制，在编译时就需要指定一下这些共享库的路径。

TARGET_LINK_LIBRARIES(target library1<debug | optimized> library2...)：为 target 添加需要链接的共享库，本例中是一个可执行文件，但是同样可以用于为自己编写的共享库添加共享库链接。

```cmake
# 优先连接动态库
TARGET_LINK_LIBRARIES(main hello)
# 使其连接静态库
TARGET_LINK_LIBRARIES(main libhello.a)
```

**若链接不到库：**

```shell
vim /etc/ld.so.conf      
/usr/lib				# 添加环境变量
ldconfig                # 更新 /etc/ld.so.cache 文件
```

如果共享库文件安装到了 /lib 或 /usr/lib 目录下, 那么需执行一下 ldconfig 命令

ldconfig 命令的用途, 主要是在默认搜寻目录(/lib和/usr/lib)以及动态库配置文件 **/etc/ld.so.conf** 内所列的目录下,
搜索出可共享的动态链接库(格式如lib\*.so*), 进而创建出动态装入程序(ld.so)所需的连接和缓存文件。缓存文件默认为/etc/ld.so.cache, 此文件保存已排好序的动态链接库名字列表。
