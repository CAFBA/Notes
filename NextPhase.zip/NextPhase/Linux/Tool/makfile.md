# makefile
编译全部文件过于耗时，为了自动针对有过改动的文件编译，需要知道目标文件依赖哪些文件，依赖的文件是否更新。
Linux提供了make命令，可以自动找出变更的文件，并根据依赖关系，找出受变更文件影响的其他相关文件，然后对这些文件按照规则进行单独处理，此处的规则一般都是指编译，如调用gcc，但也可以是删除文件等其他行为。而第二个问题可以根据文件修改时间来解决，只要其修改时间比目标文件要新，就认为该文件有过更新。
依赖关系是定义在文件makefile中，make程序通过解析makefile文件，自动找出变更的文件以及依赖此变更文件的相关文件，然后对所有受影响的相关文件执行事先定义好的命令规则。
make命令和makefile文件的关系类似脚本解析器和脚本语言文件，makefile相当于脚本语言文件，由make程序解析makefile中的内容，从而产生出不同的行为。make和makefile并不是用来编译程序的，它只负责找出哪些文件有变化，并且根据依赖关系找出受影响的文件，然后执行事先在makefile中定义好的命令规则。因为make就是在shell下执行的，所以在makefile中，位于命令规则里的那些命令，都是shell命令。
## 语法
一个规则是由**目标（targets）**、**先决条件（prerequisites）**以及**命令（commands）**所组成的。目标和先决条件之间表达的就是依赖关系，这种依赖关系指明**在构建目标之前，必须保证先决条件先满足**。而先决条件可以是其它的目标，当先决条件是目标时，其必须先被构建出来。
```makefile
targets : prerequisites
	command
```
- 目标文件是指此规则中想要生成的文件，可以是.o结尾的目标文件，也可以是可执行文件，也可以是个伪目标。
- 依赖文件是指要生成此规则中的目标文件，需要哪些文件。通常依赖文件不是1个，所以此处是个依赖文件的列表。
- 命令是指此规则中要执行的动作，一个命令要单独占用一行，在行首必须以Tab开头。
以上规则的意义是：**要想生成目标文件，需要提前准备好依赖文件，如果依赖文件列表中任意一个文件比目标文件新，就去执行规则中的命令**。
在Linux中，文件分为属性和数据两部分，每个文件有三种时间，分别用于记录与文件属性和文件数据相关的时间，这三个时间分别是atime、mtime、ctime。
- atime，即access time，表示文件数据部分被访问时间，每次读取文件数据部分时就会更新atime，强调下，是读取文件数据（内容）时改变atime，比如cat或less命令查看文件就可以更新atime，而ls命令则不会。
- ctime，即change time，表示文件属性或数据的改变时间，每当文件的属性或数据被修改时，就会更新ctime，也就是说ctime同时跟踪文件属性和文件数据变化的时间。
- mtime，即modify time，表示文件数据部分被修改时间，每次文件的数据被修改时就会更新mtime。ctime也跟踪数据变化时间，所以，当文件数据被修改时，mtime和ctime一同更新。
makefile中有很多目标时，可以用目标名称作为make的参数，采用`make目标名称`的方式，单独执行目标名称处的规则。这种方式只会执行目标名称处的规则，之后就退出了，后面即使存在其他的目标也不会执行。
当make后面没有目标名称做参数时，make会在makefile中第一个出现的目标处开始执行，一般情况下，命令能否执行是要看所依赖文件的mtime是否比目标文件要新。如果依赖文件的mtime比目标文件旧的话，说明目标文件已经是最新的，根本不需要更新，所以此种情况下规则中的命令是不会执行的。
## 递归式推导目标
在makefile中的目标，是以递归的方式逐层向上查找目标的，由果寻因，逐个向上推导。这一点尤其体现在多个目标相互依赖的情况下。
```makefile
test2.o:test2.c
	gcc -c -o test2.o test2.c
test1.o:test1.c
	gcc -c -o test1.o test1.c
test.bin:test1.o test2.o
	gcc -o test.bin test1.o test2.o
all:test.bin
	@echo "compile done"
```
第1～4行都是在准备.o目标文件，第5～6行是将.o文件生成二进制文件test.bin。第7行的目标all是为了编译test.bin，要执行的命令是make all，借此分析下make的执行流程。
1. make未找到文件GNUmakefile，便继续找文件makefile，找到后根据命令的参数all，从文件中找到all所在的规则。
2. make发现all的依赖文件test.bin不存在，于是就去找以test.bin为目标文件的规则。
3. 在第5行找到test.bin的规则，但test.bin的依赖文件test1.o和test2.o都不存在，于是先去找以test1.o为目标文件的规则。
4. 在第3行找到生成test1.o的规则，而且test1.o的依赖文件test1.c已经存在，因此执行规则生成test1.o。（test1.o本身不存在，所以不用再查看test1.c的mtime）
5. 生成test1.o后，执行流程返回到test.bin所在的规则，即第5行，此时发现test2.o也不存在，于是继续递归查找目标test2.o。
6. 在第1行发现test2.o所在的规则，同理，执行规则生成test2.o.
7. 生成test2.o后，此时执行流程又回到了第5行，make发现两个依赖文件test1.o和test2.o都准备齐了，于是执行本规则的命令，将这两个目标文件生成可执行文件test.bin。
test.bin终于生成了，此时回到了第2步目标all所在的规则，于是执行所在规则中的命令。虽然all被当作了真实目标文件来处理，但给出的命令并不是为了生成它，所以它同伪目标的作用类似。
## 隐含规则
对于一些使用频率非常高的规则，make把它们当成是默认的，不需要显式地写出来，当用户未在makefile中显式定义规则时，将默认使用隐含规则进行推导。隐含规则对于不同的程序语言是不同的，是根据一般的依赖关系来自动推导，属于重建目标文件的通用方法。
隐含规则只限于那些编译过程中基本固定的依赖关系，比如C语言代码文件扩展名为.c，编译生成的目标文件扩展名是.o，这一般是一对一的。而一个可执行程序可能是由多个.o文件共同链接生成的，所以，从可执行程序到.o文件的关系有可能是一对多，这种不确定性无法使之成为隐含的规则。所以，对于C语言的依赖关系是：文件名.o依赖于文件名.c，仅限于源文件生成.o目标文件，不存在.o文件生成可执行程序的隐含规则。
总的说来，针对不同的编程语言依赖关系，make程序通过除扩展名之外的文件名部分，再根据隐含规则，可以推导出最终的可执行文件。也就是说，若想通过隐含规则自动推导生成目标，存在于文件系统上的文件，除扩展名之外的文件名部分必须相同。比如x.o的C源文件必须名为x.c，这样通过隐含规则才能成功生成x.o。
隐含规则是用系统变量来实现的，下面列出了常见的部分语言程序的隐含规则。
C程序：x.o的生成依赖于x.c，生成x.o的命令为：`$(CC) -c $(CPPFLAGS) $(CFLAGS)`
C++程序：x.o的生成依赖于“x.cc或者x.C，生成x.o的命令为：`$(CXX) -c $(CPPFLAGS) $(CFLAGS)`
## 变量
变量定义的格式:变量名=值，多个值之间用空格分开。make程序在处理时会用空格将值打散，然后遍历每一个值。另外，值仅支持字符串类型，即使是数字也被当作字符串来处理。
变量引用的格式：\$(变量名)，**虽然变量的值会被当作字符串类型处理，但不能将其用双引号或单引号括起来**，否则双引号或单引号也会被当作变量值的一部分。比如var ='file.c'，var的值并不是file1.c，而是'file.c'。当引用变量$(var)做依赖文件时，make会去找名为'file.c'的目标，而不是file.c。
在这个 Makefile 中，引入了 CC 和 RM 两个变量，一个用于保存编译器名，而另一个用于指示删除文件的命令是什么。还有就是引入了 EXE 和 OBJS 两个变量，一个用于存放可执行文件名，可另一个则用于放置所有的目标文件名。
```makefile
.PHONY: clean
CC = gcc
RM = rm
EXE = simple
OBJS = main.o foo.o
$(EXE): $(OBJS)
	$(CC) -o $(EXE) $(OBJS)
main.o: main.c
	$(CC) -o main.o -c main.c
foo.o: foo.c
	$(CC) -o foo.o -c foo.c
clean:
	$(RM) $(EXE) $(OBJS)
```

![image-20230627223522944](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230627223522944.png)

![image-20230627224034264](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230627224034264.png)
### 自动变量
如果改变了目标或是依赖的名，那得在命令中全部跟着改。为了简化，需要用到 Makefile 中的自动变量，它们包括：
- `$@`用于表示一个规则中的目标。当一个规则中有多个目标时，$@所指的是其中任何造成命令被运行的目标。
- `$^`表示的是规则中的所有先决条件，如果集合中有重复的文件，`$^`会自动去重。
- `$<`表示的是规则中的第一个先决条件。
- `$?`表示规则中，所有比目标文件mtime更新的依赖文件集合。
```makefile
.PHONY: all
all: first second third
	@echo "\$$@ = $@"
	@echo "$$^ = $^"
	@echo "$$< = $<"
```
> 在 Makefile 中 `$` 具有特殊的意思，因此，如果想采用 echo 输出 `$`，则必需用两个连着的 `$`。
> `$@` 对于 Shell 也有特殊的意思，需要在 `$$@` 之前再加\。

```makefile
.PHONY: clean
CC = gcc
RM = rm
EXE = simple
OBJS = main.o foo.o
$(EXE): $(OBJS)
	$(CC) -o $@ $^
main.o: main.c
	$(CC) -o $@ -c $^
foo.o: foo.c
	$(CC) -o $@ -c $^
clean:
	$(RM) $(EXE) $(OBJS)
```
### 特殊变量
MAKE 变量：表示 make 命令名。
MAKECMDGOALS：表示当前用户所输入的 make 目标（缺省目标不会出现）。
### 操作符
递归扩展，但会无限递归：
```makefile
.PHONY: all
foo = $(bar)
bar = $(ugh)
ugh = Huh?
all:
	@echo $(foo)

$make
Huh?

CFLAGS = $(CFLAGS) -O
```
简单扩展变量（simply expanded variables），是用“:=”操作符来定义的。对于这种变量，make 只对其进行一次扫描和替换
```makefile
.PHONY: all
x = foo
y = $(x) b # x 被替换两次
x = later 
xx := foo
yy := $(xx) b # xx 已经被替换一次，因此下面这次不替换
xx := later 
all:
	@echo "x = $(y), xx = $(yy)"

$make
x = later b, xx = foo b
```
?= 用于条件赋值，当变量以前没有定义时，就定义它并且将左边的值赋值给它，如果已经定义了那么就不再改变其值。条件赋值类似于提供了给变量赋缺省值的功能。
```makefile
.PHONY: all
foo = x
foo ?= y
bar ?= y
all:
@echo "foo = $(foo), bar = $(bar)"

$make
foo = x, bar = y
```
+=：
```makefile
.PHONY: all
objects = main.o foo.o bar.o utils.o
objects += another.o
all:
	@echo $(objects)
```
### 变量及其值的来源
- 自动变量，其值是在每一个规则中根据规则的上下文自动获得变量值的。
- 可以在运行 make 时，在 make 命令行上定义一个或多个变量，也可以通过在 make 命令行中定义变量的方式从而覆盖 Makefile 中所定义的变量的值，图 1.51 示例了对图 1.46 中的 Makefile 中的变量值进行覆盖操作的结果。
- 变量还可以来自于 Shell 环境。
### 高级变量引用功能
```makefile
# 在赋值的同时完成后缀替换操作
foo = a.o b.o c.o
bar := $(foo:.o=.c)
all:
	@echo "bar = $(bar)"

$make
bar = a.c b.c c.c
```
### override 指令
```makefile
override foo = x
all:
@echo "foo = $(foo)"

$make foo=haha
foo = x
```
## 模式规则
模式，即pattern，其实就是指字符串模子，正则表达式中用此概念表示字符或字符串匹配，把符合此模子的字符串找出来。
%用来匹配任意多个非空字符。比如%.o代表所有以.o为结尾的文件，g%s.o是以字符g开头的所有以.o为结尾的文件，make会拿这个字符串模式去文件系统上查找文件，默认为当前路径下。
%通常用在规则中的目标文件中，以用来匹配所有目标文件，%也可以用在规则中的依赖文件中，因为目标文件才是要生成的文件，所以当%用在依赖文件中时，其所匹配的文件名要以目标文件为准。拿%.o:%.c为例，假如用%.o匹配到了目标文件a.o和b.o，那么依赖文件中的%.c将分别匹配到a.c和b.c。
```makefile
.PHONY: clean
CC = gcc
RM = rm
EXE = simple
OBJS = main.o foo.o
$(EXE): $(OBJS)
	$(CC) -o $@ $^
%.o: %.c
	$(CC) -o $@ -c $^
clean:
	$(RM) $(EXE) $(OBJS)
	
%.o:%.c
	gcc -c -o $@ $^3 
objfiles = test1.o test2.o
test.bin:$(objfiles)       
	gcc -o $@ $^
all:test.bin       
	@echo "compile done"
```
在规则的目标文件中用%.o匹配所有的.o文件，目前当前目录下也就是test1.o和test2.o。在依赖文件中用%.c匹配所有合适的.c文件，这个合适是指：要以目标文件中%所匹配到的test1和test2为主，也就是会匹配到test1.c和test2.c，即使当前目标下还有其他.c文件也不会受影响匹配结果。
## 函数
### addprefix 
addprefix 函数是用来在给字符串中的每个子串前加上一个前缀，其形式是：$(addprefix prefix, names...)
```makefile
without_dir = foo.c bar.c main.o
with_dir := $(addprefix objs/, $(without_dir))
all:
	@echo $(with_dir)

$make
objs/foo.c objs/bar.c objs/main.o
```
### filter 
filter 函数用于从一个字符串中，根据模式得到满足模式的字符串，其形式是：$(filter pattern..., text)
```makefile
sources = foo.c bar.c baz.s ugh.h
sources := $(filter %.c %.s, $(sources))
all:
	@echo $(sources)

$make
foo.c bar.c baz.s
```
### filter-out
filter-out 函数用于从一个字符串中根据模式滤除一部分字符串，其形式是：$(filter-out pattern..., text)
```makefile
objects = main1.o foo.o main2.o bar.o
result = $(filter-out main%.o, $(objects))
all:
	@echo $(result)

$make
foo.o bar.o
```
### patsubst 
patsubst 函数是用来进行字符串替换的，其形式是：$(patsubst pattern, replacement, text)，由于patsubst 函数可以使用模式，所以其也可以用于替换前缀等等。
```makefile
mixed = foo.c bar.c main.o
objects := $(patsubst %.c, %.o, $(mixed))
all:
	@echo $(objects)

$make
foo.o bar.o main.o
```
### strip 
strip 函数用于去除变量中的多余的空格，其形式是：$(strip string)
```makefile
original = foo.c   bar.c
stripped := $(strip $(original))
all:
	@echo "original = $(original)"
	@echo "stripped = $(stripped)"

$make
original = foo.c   bar.c
stripped = foo.c bar.c
```
### wildcard 
wildcard 是通配符函数，通过它可以得到所需的文件。其形式是：$(wildcard pattern)
```makefile
SRCS = $(wildcard *.c)
all:
	@echo $(SRCS)

$make
bar.c foo.c main.c
```
## 安装
```makefile
DESTDIR =
install:
	mkdir -p $(DESTDIR)/usr/bin install -m 755 hello $(DESTDIR)/usr/bin
```
可以通过 make install 将 hello 直接安装到 /usr/bin 目录，也可以通过 make install DESTDIR=/tmp/test 安装在/tmp/test/usr/bin 目录。
稍微复杂一点的是还需要定义 PREFIX，比如上面的Makefile 就可以改写成:
```makefile
DESTDIR =
PREFIX = /usr
install:
	mkdir -p $(DESTDIR)/$(PREFIX)/bin install -m 755 hello $(DESTDIR)/$(PREFIX)/bin
```
