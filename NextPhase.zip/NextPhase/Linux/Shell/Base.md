# Base
## 创建shell脚本文件
在创建shell脚本文件时，必须**在文件的第一行指定要使用的shell**，格式如下：
```
#!/bin/bash
```
在普通的shell脚本中，#用作注释行。shell并不会处理shell脚本中的注释行。然而，shell脚本文件的第一行是个例外，#后面的惊叹号会告诉shell用哪个shell来运行脚本。
为了要让shell找到脚本，可以采用下列两种方法之一：
- 将放置shell脚本文件的目录添加到PATH环境变量中
- 在命令行中使用绝对路径或相对路径来引用shell脚本文件
下一步是通过chmod命令赋予文件属主执行文件的权限：
```
$ chmod u+x test1 
```

> 如果想把字符串和命令输出显示在同一行中，可以使用echo命令的-n选项。命令输出会在紧接着字符串结束的地方出现。
## 变量
在脚本中，可以在环境变量名之前加上$来引用这些环境变量。
只要脚本在双引号中看到$，就会以为在引用变量。反斜线允许shell脚本按照字面意义解释\$，而不是引用变量。
> 引用变量值时要加\$，对变量赋值时则不用加$
### 用户自定义变量
使用等号为变量赋值。在变量、等号和值之间不能出现空格，因为变量名区分大小写，所以变量Var1和变量var1是不同的。
shell脚本会以字符串形式存储所有的变量值，脚本中的各个命令可以自行决定变量值的数据类型。shell脚本中定义的变量在脚本的整个生命周期里会一直保持着它们的值，在脚本结束时会被删除。
### 命令替换
shell脚本中最有用的特性之一是可以从命令输出中提取信息并将其赋给变量。把输出赋给变量之后，就可以随意在脚本中使用了。有两种方法可以**将命令输出赋给变量：反引号、$()格式**。
shell会执行命令替换符内的命令，将其输出赋给变量testing。注意，赋值号和命令替换符之间没有空格。
下面这个例子很常见，它在脚本中通过命令替换获得当前日期并用其来生成唯一文件名：
```
#!/bin/bash
today=$(date +%y%m%d)
ls /usr/bin -al > log.$today
```
today变量保存着格式化后的date命令的输出。这是提取日期信息，用于生成日志文件名的一种常用技术。+%y%m%d格式会告诉date命令将日期显示为两位数的年、月、日的组合。
该脚本会将日期值赋给变量，然后再将其作为文件名的一部分。文件本身包含重定向的目录列表输出。
运行后目录中出现的日志文件采用$today变量的值作为文件名的一部分。日志文件的内容是/usr/bin目录内容的列表输出。如果脚本在次日运行，那么日志文件名会是log.200602，因此每天都会创建一个新文件。
命令替换会创建出子shell来运行指定命令，这是由运行脚本的shell所生成的一个独立的shell。因此，在子shell中运行的命令无法使用脚本中的变量。
> 如果在命令行中使用./路径执行命令，就会创建子shell，但如果不加路径，则不会创建子shell。不过，内建的shell命令也不会创建子shell。在命令行中运行脚本时要当心。
### 重定向
#Linux重定向
bash shell提供了几个运算符，它们可以将命令的输出重定向到其他位置（比如文件）。重定向既可用于输入，也可用于输出，例如将文件重定向，作为命令输入。
#### 输出重定向
最基本的重定向会将命令的输出发送至文件。之前出现在显示器上的命令输出会被保存到指定的输出文件中，如果输出文件已存在，则重定向运算符会用新数据覆盖已有的文件。
```
command > outputfile
```
有时，可能并不想覆盖文件原有内容，而是想将命令输出追加到已有文件中，此时可以用双大于号>>来追加数据。
#### 输入重定向
输入重定向会将文件的内容重定向至命令，而不是将命令输出重定向至文件。
```
command < inputfile
```
下面是一个和wc命令一起使用输入重定向的例子。
```
$ wc < test6 
2 11 60 
```
wc命令可以统计数据中的文本。在默认情况下，它会输出3个值，文本的行数、文本的单词数、文本的字节数。
通过将文本文件重定向到wc命令，立刻就可以得到文件中的行、单词和字节的数量。这个例子说明test6文件包含2行、11个单词以及60字节。
#### 内联输入重定向
还有另外一种输入重定向的方法，称为内联输入重定向（inline input redirection）。这种方法无须使用文件进行重定向，只需在命令行中指定用于输入重定向的数据即可。
内联输入重定向运算符是双小于号（<<）。除了这个符号，必须指定一个文本标记来划分输入数据的起止。任何字符串都可以作为文本标记，但在数据开始和结尾的文本标记必须一致：
```
command << 
marker 
data 
marker
```
在命令行中使用内联输入重定向时，shell会用PS2环境变量中定义的次提示符来提示输入数据，其用法如下所示：
```
$ wc << EOF
> test string 1
> test string 2
> test string 3
> EOF
      3       9      42
```
次提示符会持续显示，以获取更多的输入数据，直到输入了作为文本标记的那个字符串。wc命令会统计内联输入重定向提供的数据包含的行数、单词数和字节数。
### 
管道连接（piping）可以将一个命令的输出直接传给另一个命令的输入，无须将命令输出重定向至文件。
管道被置于命令之间，将一个命令的输出传入另一个命令中：
```
command1 | command2
```
实际上，**Linux系统会同时运行这两个命令，在系统内部将二者连接起来。当第一个命令产生输出时，它会被立即传给第二个命令。数据传输不会用到任何中间文件或缓冲区**。
可以利用管道轻松地将rpm命令的输出传入sort命令来获取结果：
```
$ rpm -qa | sort 
```
> rpm命令通过Red Hat软件包管理系统（RPM）管理系统（比如上例中的CentOS系统）中已安装的软件包。配合-qa选项使用时，会生成已安装包的列表，但这个列表并不遵循某种特定的顺序。

管道可以串联的命令数量没有限制。可以持续地将命令输出通过管道传给其他命令来细化操作。
在这个例子中，由于sort命令的输出一闪而过，因此可以用文本分页命令（比如less或more）强行将输出按屏显示：
```
$ rpm -qa | sort | more
```
也可以结合重定向和管道来将输出保存到文件中：
```
$ rpm -qa | sort > rpm.list 
```
## 执行数学运算 
最初，Bourne shell提供了一个专门用于处理数学表达式的命令：expr，该命令可在命令行中执行数学运算，但是特别笨拙。要将一个数学算式的结果赋给变量，需要使用命令替换来获取expr命令的输出。
### 方括号
为了兼容Bourne shell，bash shell保留了expr命令，但同时也提供了另一种更简单的方法来执行数学运算。在bash中，要将数学运算结果赋给变量，可以使用$和方括号。
bash shell的数学运算符只支持整数运算。
```
$ cat test8
#!/bin/bash
var1=100
var2=45
var3=$[$var1 / $var2]
echo The final result is $var3
```
> bash shell的数学运算符只支持整数运算。如果打算尝试现实世界中的数学运算，那么这是一个巨大的限制。
### 浮点数
有几种解决方案能够克服bash只支持整数运算的限制。最常见的做法是使用内建的bash计算器bc。
bash计算器实际上是一种编程语言，允许在命令行中输入浮点数表达式，然后解释并计算该表达式，最后返回结果。bash计算器能够识别以下内容：数字（整数和浮点数）、变量（简单变量和数组）、注释（以#或C语言中的/* \*/开始的行）、表达式、编程语句（比如if-then语句）、函数。
可以在shell提示符下通过bc命令访问bash计算器进行运算。浮点数运算是由内建变量scale控制的，必须将该变量的值设置为希望在计算结果中保留的小数位数，否则将无法得到期望的结果。scale变量的默认值是0。在scale值被设置前，bash计算器的计算结果不包含小数位。除了普通数字，bash计算器还支持变量之间的运算。
可以用命令替换来运行bc命令，将输出赋给变量。基本格式如下：
```
variable=$(echo "options; expression" | bc)
```
第一部分的options允许设置变量。如果需要多个变量，可以用分号来分隔它们。expression定义了要通过bc执行的数学表达式。
表达式中不仅可以使用数字，还可以用shell脚本中定义好的变量：
```
$ cat test10
#!/bin/bash
var1=100
var2=45
var3=$(echo "scale=4; $var1 / $var2" | bc)
echo The answer for this is $var3
```
该脚本定义了两个变量，这两个变量都可以用在expression部分中，发送给bc命令。
bc命令能接受输入重定向，允许将一个文件重定向到bc命令来处理。但这同样会让人头疼，因为还需要将表达式存放到文件中。最好的办法是使用内联输入重定向，它允许直接在命令行中重定向数据。在shell脚本中，可以将输出赋给一个变量：
```
variable=$(bc << EOF
options
statements
expressions
EOF
)
```
现在，可以将bash计算器涉及的各个部分放入脚本文件的不同行中：
```
$ cat test12
#!/bin/bash

var1=10.46
var2=43.67
var3=33.2
var4=71

var5=$(bc << EOF
scale = 4
a1 = ( $var1 * $var2)
b1 = ($var3 * $var4)
a1 + b1
EOF
)

echo The final answer for this mess is $var5
```
将选项和表达式放在脚本的不同行中可以让处理过程变得更清晰并提高易读性。EOF字符串标识了重定向给bc命令的数据的起止。当然，必须用命令替换符标识出用来给变量赋值的命令。
> 可以在bash计算器中为变量赋值，但在bash计算器中创建的变量仅在计算器中有效，不能在shell脚本中使用。
## 退出脚本
shell中运行的每个命令都使用退出状态码来告诉shell自己已经运行完毕。退出状态码是一个0～255的整数值，在命令结束运行时由其传给shell。可以获取这个值并在脚本中使用。
Linux提供了专门的变量\$?来保存最后一个已执行命令的退出状态码。对于需要进行检查的命令，必须在其运行完毕后立刻查看或使用$?变量。这是因为**该变量的值会随时变成由shell所执行的最后一个命令的退出状态码**。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230920152654.png)
在默认情况下，shell脚本会以脚本中的最后一个命令的退出状态码退出。你可以改变这种默认行为，返回自己的退出状态码。exit命令允许在脚本结束时指定一个退出状态码，也可以使用变量作为exit命令的参数。
```
exit 5
exit $var
```
使用这个功能时要小心，因为退出状态码最大只能是255，因此退出状态码会被缩减到0～255的区间。shell通过模运算得到这个结果。一个值的模就是被除后的余数。最终的结果是指定的数值除以256后得到的余数。
## 案例
编写一个shell脚本来计算两个日期之间相隔的天数，允许用户以date命令能识别的任何格式来指定日期。
date命令允许使用-d选项指定特定日期（以任意格式），然后以我们定义的其他格式输出该日期。为了执行日期运算，要利用纪元时间（epoch time）这个Linux特性。纪元时间将时间指定为1970年1月1日午夜后的整数秒（这是一个古老的Unix标准）。因此，要获得2020年1月1日的纪元时间，可以这么做：
```
$date -d "Jan 1, 2020" +%s 
1577854800
```
使用这种方法获得两个日期的纪元时间，然后相减，得到两个日期之间相隔的秒数。在此，将该值除以一天中的秒数（每分钟60秒、每小时60分钟、每天24小时），以获得两个日期之间的天数差异。
使用命令替换将date命令的输出保存在变量中：
```
$time1=$(date -d "$date1" +%s)
```
完整的脚本：
```$ cat mydate.sh
#!/bin/bash
# calculate the number of days between two dates
date1="Jan 1, 2020"
date2="May 1, 2020"

time1=$(date -d "$date1" +%s)
time2=$(date -d "$date2" +%s)

diff=$(expr $time2 - $time1)
secondsinday=$(expr 24 \* 60 \* 60)
days=$(expr $diff / $secondsinday)

echo "The difference between $date2 and $date1 is $days days"
```
之后设置合适的权限并运行脚本。
# 函数
## 创建函数
在bash shell脚本中创建函数的语法有两种。第一种语法是使用关键字function，随后跟上分配给该代码块的函数名，第二种在bash shell脚本中创建函数的语法更接近其他编程语言中定义函数的方式：
```
function name {
    commands
}

name() {
	commands
}
```
name定义了该函数的唯一名称。脚本中的函数名不能重复。如果定义了同名函数，那么新定义就会覆盖函数原先的定义，而这一切不会有任何错误消息。
函数定义不一定非要放在shell脚本的最开始部分，但是如果试图在函数被定义之前调用它，则会收到一条错误消息。
## 函数返回值
bash shell把函数视为一个小型脚本，运行结束时会返回一个退出状态码）。有3种方法能为函数生成退出状态码。
### 默认的退出状态码
在默认情况下，函数的退出状态码是函数中最后一个命令返回的退出状态码。函数执行结束后，可以使用标准变量$?来确定函数的退出状态码，但你无法知道该函数中的其他命令是否执行成功。
### return
return命令允许指定一个整数值作为函数的退出状态码。当用这种方法从函数中返回值时：
- 函数执行一结束就立刻读取返回值：如果在用`$?`变量提取函数返回值之前执行了其他命令，那么函数的返回值会丢失。因为`$?`变量保存的是最后执行的那个命令的退出状态码。
- 退出状态码必须介于0~255：由于退出状态码必须小于256，因此函数结果也必须为一个小于256的整数值。大于255的任何数值都会产生错误的值。
### 使用函数输出
正如可以将命令的输出保存到shell变量中一样，也可以将函数的输出保存到shell变量中。新函数会用echo语句的输出作为函数返回值，这种方法还可以返回浮点值和字符串：
```
$ cat test5b
#!/bin/bash
# using the echo to return a value
function dbl {
   read -p "Enter a value: " value
   echo $[ $value * 2 ]
}
result=$(dbl)
echo "The new value is $result"
$ ./test5b
Enter a value: 200
The new value is 400
$ ./test5b
Enter a value: 1000
The new value is 2000
```
dbl函数实际上输出了两条消息。read命令输出了一条简短的消息来向用户询问输入值。bash shell脚本并不将其作为STDOUT输出的一部分，而是直接将其忽略。
如果用echo语句生成这条read消息来询问用户，那么它会与输出值一起被读入shell变量。
## 在函数中使用变量
### 传递参数
函数可以使用标准的位置变量来表示在命令行中传给函数的任何参数。在脚本中调用函数时，必须将参数和函数名放在同一行，然后函数可以用位置变量来获取参数值。
由于函数使用位置变量访问函数参数，因此无法直接获取脚本的命令行参数。
脚本主体中的$1和$2变量指的是脚本的命令行参数，而函数使用的$1和$2位置变量用于访问函数参数。
要在函数中使用脚本的命令行参数，必须在调用函数时手动将其传入：
```
$ cat test7
#!/bin/bash
# trying to access script parameters inside a function
function func7 {
   echo $[ $1 * $2 ]
}

if [ $# -eq 2 ]
then
   value=$(func7 $1 $2)
   echo "The result is $value"
else
   echo "Usage: badtest1 a b"
fi
$ ./test7
Usage: badtest1 a b
$ ./test7 10 15
The result is 150
```
### 全局/局部变量
在默认情况下，在脚本中定义的任何变量都是全局变量。在函数外定义的变量可在函数内正常访问。如果变量在函数内被赋予了新值，那么在脚本中引用该变量时，新值仍可用。
任何在函数内部使用的变量都可以被声明为局部变量，为此，只需在变量声明之前加上local关键字即可。local关键字保证了变量仅在该函数中有效。如果函数之外有同名变量，那么shell会保持这两个变量的值互不干扰。
## 数组变量和函数
将数组变量当作单个参数传递的话，它不会起作用：
```shell
$ cat badtest3
#!/bin/bash
# trying to pass an array variable

function testit {
   echo "The parameters are: $@"
   thisarray=$1
   echo "The received array is ${thisarray[*]}"
}

myarray=(1 2 3 4 5)
echo "The original array is: ${myarray[*]}"
testit $myarray
$ ./badtest3
The original array is: 1 2 3 4 5
The parameters are: 1
The received array is 1
```
如果试图将数组变量作为函数参数进行传递，则函数只会提取数组变量的第一个元素。要解决这个问题，必须先将数组变量拆解成多个数组元素，然后将这些数组元素作为函数参数传递。最后在函数内部，将所有的参数重新组合成一个新的数组变量。
```shell
$ cat test10
#!/bin/bash
# array variable to function test

function testit {
   local newarray
   # 将所有的参数重新组合成一个新的数组变量
   newarray=(`echo "$@"`)
   echo "The new array value is: ${newarray[*]}"
}

myarray=(1 2 3 4 5)
echo "The original array is ${myarray[*]}"
# 先将数组变量拆解成多个数组元素，作为函数参数传递
testit ${myarray[*]}
$ ./test10
The original array is 1 2 3 4 5
The new array value is: 1 2 3 4 5
```
函数向shell脚本返回数组变量也采用类似的方法。函数先用echo语句按正确顺序输出数组的各个元素，然后脚本再将数组元素重组成一个新的数组变量：
```shell
$ cat test12
#!/bin/bash
# returning an array value

function arraydblr {
   local origarray
   local newarray
   local elements
   local i
   origarray=($(echo "$@"))
   newarray=($(echo "$@"))
   elements=$[ $# - 1 ]
   for (( i = 0; i <= $elements; i++ ))
   {
      newarray[$i]=$[ ${origarray[$i]} * 2 ]
   }
   echo ${newarray[*]}
}

myarray=(1 2 3 4 5)
echo "The original array is: ${myarray[*]}"
arg1=$(echo ${myarray[*]})
result=($(arraydblr $arg1))
echo "The new array is: ${result[*]}"
$
$ ./test12
The original array is: 1 2 3 4 5
The new array is: 2 4 6 8 10
```
该脚本通过$arg1变量将数组元素作为参数传给arraydblr函数。arraydblr函数将传入的参数重组成新的数组变量，生成该数组变量的副本。然后对数据元素进行遍历，将每个元素的值翻倍，并将结果存入函数中的数组变量副本。
arraydblr函数使用echo语句输出每个数组元素的值。脚本用arraydblr函数的输出重组了一个新的数组变量。
## 递归
x的阶乘等于x乘以x-1的阶乘。这可以用简单的递归脚本表达为以下形式：
```shell
function factorial {
   if [ $1 -eq 1 ]
   then
      echo 1
   else
      local temp=$[ $1 - 1 ]
      local result=`factorial $temp`
      echo $[ $result * $1 ]
   fi
}
```
## 创建库
bash shell允许创建函数库文件，然后在多个脚本中引用此库文件。这个过程的第一步是创建一个包含脚本中所需函数的公用库文件。第二步是在需要用到这些函数的脚本文件中包含库文件。
和环境变量一样，shell函数仅在定义它的shell会话内有效。**如果在shell命令行界面运行脚本，那么shell会创建一个新的shell并在其中运行这个脚本。在这种情况下，以上3个函数会定义在新shell中，当你运行另一个要用到这些函数的脚本时，它们是无法使用的**。
这同样适用于脚本。如果尝试像普通脚本文件那样运行库文件，那么这3个函数也不会出现在脚本中：
```shell
$ cat badtest4
#!/bin/bash
# using a library file the wrong way
./myfuncs

result=$(addem 10 15)
echo "The result is $result"
$
$ ./badtest4
./badtest4: addem: command not found
The result is
```
使用函数库的关键在于source命令。source命令会在当前shell的上下文中执行命令，而不是创建新的shell并在其中执行命令。可以用source命令在脚本中运行库文件。这样脚本就可以使用库中的函数了。source命令有个别名，称作点号操作符。
```shell
$ cat test14
#!/bin/bash
# using functions defined in a library file
. ./myfuncs

value1=10
value2=5
result1=$(addem $value1 $value2)
result2=$(multem $value1 $value2)
result3=$(divem $value1 $value2)
echo "The result of adding them is: $result1"
echo "The result of multiplying them is: $result2"
echo "The result of dividing them is: $result3"
$ ./test14
The result of adding them is: 15
The result of multiplying them is: 50
The result of dividing them is: 2
```
## 在命令行中使用函数
就像在shell脚本中将脚本函数当作命令使用一样，在命令行界面中也可以这样做。一旦在shell中定义了函数，就可以在整个系统的任意目录中使用它，而无须担心该函数是否位于PATH环境变量中。
### 在命令行中创建函数
一种方法是采用单行方式来定义函数，当在命令行中定义函数时，必须在每个命令后面加个分号，这样shell就能知道哪里是命令的起止了：
```
$ function doubleit { read -p "Enter value: " value; echo $[
 $value * 2 ]; }
$ doubleit
Enter value: 20
40
```
另一种方法是采用多行方式来定义函数。在定义时，bash shell会使用次提示符来提示输入更多命令。使用这种方法，无须在每条命令的末尾放置分号，只需按下回车键即可：
```
$ function multem {
> echo $[ $1 * $2 ]
> }
$ multem 2 5
10
```
> 在命令行创建函数时要特别小心。如果给函数起了一个跟内建命令或另一个命令相同的名字，那么函数就会覆盖原来的命令。
### 在.bashrc文件中定义函数
在命令行中直接定义shell函数的一个明显缺点是，在退出shell时，函数也会消失。有一种非常简单的方法可以解决这个问题：将函数定义在每次新shell启动时都会重新读取该函数的地方。
.bashrc文件就是最佳位置。**不管是交互式shell还是从现有shell启动的新shell，bash shell在每次启动时都会在用户主目录中查找这个文件**。
可以直接在用户主目录的.bashrc文件中定义函数，只需将函数放在文件末尾即可。
只要是在shell脚本中，就可以用source命令（点号操作符）将库文件中的函数添加到.bashrc脚本中：
```
$ cat .bashrc
# .bashrc

# Source global definitions
if [ -r /etc/bashrc ]; then
        . /etc/bashrc
fi

. /home/rich/libraries/myfuncs
```
要确保库文件的路径名正确，以便bash shell找到该文件。下次启动shell时，库中的所有函数都可以在命令行界面使用了。
shell还会将定义好的函数传给子shell进程，这样一来，这些函数就能够自动用于该shell会话中的任何shell脚本了。
















ls命令的另一些使用选项。
- -d：只显示目录，但不显示目录内容。
- -sh：以人类易读的格式显示文件大小。
- -g：在文件长列表中不显示文件属主
- -o：在文件长列表中不显示文件属组。
























































