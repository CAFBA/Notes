## apt-get无法使用
安装vnc远程连接后，显示系统错误，缺少依赖包
于是安装相应依赖包
sudo apt-get install libpulse0
但报错显示 Depends: libpulse0 (= 1:11.1-1ubuntu7.8) but 1:11.1-1ubuntu7.11 is to be installed
```
dpkg: libpulse0:arm64: dependency problems, but removing anyway as you requested:
 libfluidsynth1:arm64 depends on libpulse0 (>= 0.99.1).
 speech-dispatcher-audio-plugins:arm64 depends on libpulse0 (>= 0.99.1).
 libsdl2-2.0-0:arm64 depends on libpulse0 (>= 0.99.1).
 libfreerdp-client2-2:arm64 depends on libpulse0 (>= 0.99.1).
 libpcaudio0 depends on libpulse0 (>= 0.99.1).
 gnome-control-center depends on libpulse0 (>= 0.99.1); however:
  Package libpulse0:arm64 is to be removed.
 gnome-shell depends on libpulse0 (>= 0.99.1); however:
  Package libpulse0:arm64 is to be removed.
 libasound2-plugins:arm64 depends on libpulse0 (>= 0.99.1).
 pulseaudio-utils depends on libpulse0 (= 1:11.1-1ubuntu7.8).
 xfce4-pulseaudio-plugin:arm64 depends on libpulse0 (>= 0.99.1); however:
  Package libpulse0:arm64 is to be removed.
 gstreamer1.0-pulseaudio:arm64 depends on libpulse0 (>= 2.0).
 libpulsedsp:arm64 depends on libpulse0 (= 1:11.1-1ubuntu7.11).
 unity-settings-daemon depends on libpulse0 (>= 0.99.1); however:
  Package libpulse0:arm64 is to be removed.
 libpulse-mainloop-glib0:arm64 depends on libpulse0 (= 1:11.1-1ubuntu7.11).
 pavucontrol depends on libpulse0 (>= 4.0); however:
  Package libpulse0:arm64 is to be removed.
 gnome-settings-daemon depends on libpulse0 (>= 0.99.1); however:
  Package libpulse0:arm64 is to be removed.
 libavdevice57:arm64 depends on libpulse0 (>= 0.99.1).
```
也就是这个依赖存在，但版本过高，根据提示 apt --fix-broken install
但没有任何作用，使用 dpkg -l libpulse0 查看这个包，版本为 1:11.1-1ubuntu7.11
```
/sbin/ldconfig.real: /usr/lib/libtinyalsa.so.1 is not a symbolic link

/sbin/ldconfig.real: /usr/lib/libpulse-mainloop-glib.so.0 is not a symbolic link

/sbin/ldconfig.real: /usr/lib/libpulse.so.0 is not a symbolic link

/sbin/ldconfig.real: /usr/lib/libUNIAI.so is not a symbolic link

/sbin/ldconfig.real: /usr/lib/libUNIAI_wrapper1.so is not a symbolic link

/sbin/ldconfig.real: /usr/lib/libpulse-simple.so.0 is not a symbolic link
```
于是考虑删除，重新下载 sudo dpkg --force-all -P libpulse0
删除过程中出现以下
```
dpkg: warning: parsing file '/var/lib/dpkg/status' near line 5207 package 'gnss-ota':
 missing description
dpkg: warning: parsing file '/var/lib/dpkg/status' near line 5207 package 'gnss-ota':
 missing maintainer
dpkg: warning: parsing file '/var/lib/dpkg/status' near line 56253 package 'unisoc-gpsd':
 missing description
dpkg: warning: parsing file '/var/lib/dpkg/status' near line 56253 package 'unisoc-gpsd':
 missing maintainer
```
使用下述命令删除备份
```
sudo rm /var/lib/dpkg/status
sudo cp /var/backups/dpkg.status.0 /var/lib/dpkg/status
sudo apt-get update
```
于是开始重新安装，但报错
```
libpulse-mainloop-glib0 : Depends: libpulse0 (= 1:11.1-1ubuntu7.11) but 1:8.0-0ubuntu3.15 is to be installed
libpulsedsp : Depends: libpulse0 (= 1:11.1-1ubuntu7.11) but 1:8.0-0ubuntu3.15 is to be installed
pulseaudio-utils : Depends: libpulse0 (= 1:11.1-1ubuntu7.8) but 1:8.0-0ubuntu3.15 is to be installed
```
也就是说被删除的这个也依赖一系列包
综上，安装vnc后，其安装了一系列依赖包，这些包版本无法匹配，但包确实存在，进而导致apt安装任何包都无法进行，此外尝试更换用户，都无法解决，网上的教程均是基于apt安装进行的，但这个问题就出在无法使用apt，而且系统自带的修复也没有作用，在stackoverflow上查找类似libpulse0的问题，发现有人一模一样的问题，但确只有一个回答，没有解决问题，再查找类似的问题，均是使用sudo apt install或dpkg进行，均无法解决，最后只能考虑刷系统。
但上述问题就出在版本问题，最开始的镜像源我并没有替换过，之后是别人替换的，他因此可能使用的是x64而非arm64的镜像，因此我再次替换，使用相应版本，但还是上述问题，最后我改成低一个版本的镜像，开始再次尝试，发现 apt --fix-broken install 可以运行，并且使用了刚才配置的镜像，修复过程中删除了一系列包，接下来，我安装之前的libpulse0包，显示最新版本正确，不再是之前的版本。
因此apt可以使用，便删除vnc的一系列包，之后使用apt安装其他包进行测验，奇怪的是，报错依旧是，但此时再次运行apt --fix-broken install，由于vnc一系列依赖删除，导致现在可以正常修复，修复过程中删除了vnc一系列依赖，此时我直接删除libpulse0，并再次安装libpulse0，解决了问题。
综上，一开始的镜像源配错，导致包依赖出错，导致apt无法使用，进入死循环。
考虑到版本问题，因此采用降低版本的方式，此外，系统修复会依据镜像源进行，因此才能正确解决问题。

