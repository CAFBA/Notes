## 远程连接
### root用户连接
```shell
sudo apt-get update
sudo apt-get install openssh-server

# 默认不允许root用户连接
vim /etc/ssh/sshd_config
PermitRootLogin yes # 修改

service sshd restart #或
/etc/init.d/ssh restart
```
### 免密登录
```shell
ssh-keygen -t rsa # 根目录下生成以下文件
authorized_keys: 存放远程免密登录的公钥,主要通过这个文件记录多台机器的公钥。
id_rsa: 生成的私钥文件
id_rsa.pub: 生成的公钥文件
known_hosts: 已知的主机公钥清单

# 1 指定免密钥登录的服务器 ip 地址
ssh-copy-id -i ~/.ssh/id_rsa.pub 192.168.1.100

# 2 将本地 id_rsa.pub 文件的内容拷贝至远程服务器的 ~/.ssh/authorized_keys 文件中

# 远程连接
ssh 192.168.1.100
```
## 配置镜像
```shell
sudo cp /etc/apt/sources.list /etc/apt/sources.list_backup
vim /etc/apt/sources.list

deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-updates main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-updates main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-backports main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-backports main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-security main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-security main restricted universe multiverse
```
## 分配空间
设置 ISO 光盘，启动时连接，进入 BIOS，在 BOOT 中将 CD-ROM 放到最上面，之后保存退出，进入 try，打开 GP 软件，设置未分配空间
## 找回root密码
启动系统，进入开机界面，在界面中按**e**进入编辑界面。
找到以Linux16开头内容所在的行数，在行的最后面输入：**init=/bin/sh**。
按快捷键：Ctrl+x 进入**单用户模式**
输入：**mount -o remount,rw /**，完成后按键盘的回车键。
在新的一行最后面输入：**passwd**， 完成后按键盘的回车键。输入密码，然后再次确认密码即可，密码修改成功后，会显示passwd加密样式，说明密码修改成功
输入：**touch /.autorelabel**，完成后按键盘的回车键
输入：**exec /sbin/init**，完成后按键盘的回车键
## Vscode配置 C++
### tasks.json
```json
// tasks.json
{
    // https://code.visualstudio.com/docs/editor/tasks
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Build",  // 任务的名字叫Build，注意是大小写区分的，等会在launch中调用这个名字
            "type": "shell",  // 任务执行的是shell命令
            "command": "g++", // 命令是g++
            "args": [
                "'-Wall'",
                "'-std=c++17'",  //使用c++17标准编译
                "'${file}'", //当前文件名
                "-o", //对象名，不进行编译优化
                "'${fileBasenameNoExtension}.exe'",  //当前文件名（去掉扩展名）
            ],
          // 所以以上部分，就是在shell中执行（假设文件名为filename.cpp）
          // g++ filename.cpp -o filename.exe
            "group": { 
                "kind": "build",
                "isDefault": true   
                // 任务分组，因为是tasks而不是task，意味着可以连着执行很多任务
                // 在build组的任务们，可以通过在Command Palette(F1) 输入run build task来运行
                // 当然，如果任务分组是test，你就可以用run test task来运行 
            },
            "problemMatcher": [
                "$gcc" // 使用gcc捕获错误
            ],
        }
    ]
}
```
### launch.json
```json
// launch.json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "(gdb) Launch", //这个应该是F1中出现的名字
            "preLaunchTask": "Build",  //在launch之前运行的任务名，这个名字一定要跟tasks.json中的任务名字大小写一致
            "type": "cppdbg",
            "request": "launch",
            "program": "${fileDirname}/${fileBasenameNoExtension}.exe", //需要运行的是当前打开文件的目录中，名字和当前文件相同，但扩展名为exe的程序
            "args": [],
            "stopAtEntry": false, // 选为true则会在打开控制台后停滞，暂时不执行程序
            "cwd": "${workspaceFolder}", // 当前工作路径：当前文件所在的工作空间
            "environment": [],
            "externalConsole": true,  // 是否使用外部控制台，选false的话，我的vscode会出现错误
            "MIMode": "gdb",
            "miDebuggerPath": "c:/MinGW/bin/gdb.exe",
            "setupCommands": [
                {
                    "description": "Enable pretty-printing for gdb",
                    "text": "-enable-pretty-printing",
                    "ignoreFailures": true
                }
            ]
        }]
}
```
支持下面的预定义变量:
- **${workspaceFolder}** - 当前工作目录(根目录)
- **${workspaceFolderBasename}** - 当前文件的父目录
- **${file}** - 当前打开的文件名(完整路径)
- **${relativeFile}** - 当前根目录到当前打开文件的相对路径(包括文件名)
- **${relativeFileDirname}** - 当前根目录到当前打开文件的相对路径(不包括文件名)
- **${fileBasename}** - 当前打开的文件名(包括扩展名)
- **${fileBasenameNoExtension}** - 当前打开的文件名(不包括扩展名)
- **${fileDirname}** - 当前打开文件的目录
- **${fileExtname}** - 当前打开文件的扩展名
- **${cwd}** - 启动时task工作的目录
- **${lineNumber}** - 当前激活文件所选行
- **${selectedText}** - 当前激活文件中所选择的文本
- **${execPath}** - vscode执行文件所在的目录
- **${defaultBuildTask}** - 默认编译任务(build task)的名字
假设你满足以下的条件
1. 一个文件 `/home/your-username/your-project/folder/file.ext` 在你的编辑器中打开;
2. 一个目录 `/home/your-username/your-project` 作为你的根目录.
下面的预定义变量则代表:
- **${workspaceFolder}** - `/home/your-username/your-project`
- **${workspaceFolderBasename}** - `your-project`
- **${file}** - `/home/your-username/your-project/folder/file.ext`
- **${relativeFile}** - `folder/file.ext`
- **${relativeFileDirname}** - `folder`
- **${fileBasename}** - `file.ext`
- **${fileBasenameNoExtension}** - `file`
- **${fileDirname}** - `/home/your-username/your-project/folder`
- **${fileExtname}** - `.ext`
- **${lineNumber}** - 光标所在行
- **${selectedText}** - 编辑器中所选择的文本
- **${execPath}** - Code.exe的位置