## 命令
logout 在提示符下注销用户（在图形运行级别无效，在运行级别3以下有效）
网络的联机状态，可以下达『 netstat -a 』 这个指令
\# 代表以 root 的身份登入系统，而 $ 则代表一般身份使用者
ifconfig 获取虚拟机地址
ping + 地址 检查是否与母机冲突
数据同步写入磁盘： sync
关机指令： shutdown
重启：reboot
```shell
/sbin/shutdown [-krhc] [时间] [警告讯息]
选项与参数：
-k ： 不要真的关机，只是发送警告讯息出去！
-r ： 在将系统的服务停掉之后就重新启动(常用)
-h ： 将系统的服务停掉后，立即关机。 (常用)
-c ： 取消已经在进行的 shutdown 指令内容。
时间 ： 指定系统关机的时间！时间的范例底下会说明。若没有这个项目，则默认 1 分钟后自动进行。

[root@study ~]# shutdown -h now
立刻关机，其中 now 相当于时间为 0 的状态
[root@study ~]# shutdown -h 20:25
系统在今天的 20:25 分会关机，若在 21:25 才下达此指令，则隔天才关机
[root@study ~]# shutdown -h +10
系统再过十分钟后自动关机
[root@study ~]# shutdown -r now
系统立刻重新启动
[root@study ~]# shutdown -r +30 'The system will reboot' 
再过三十分钟系统会重新启动，并显示后面的讯息给所有在在线的使用者
[root@study ~]# shutdown -k now 'This system will reboot' 
```
## 运行级别
运行级别说明：
0：关机
1：单用户【找回丢失密码】
2：多用户状态没有网络服务
3：多用户状态有网络服务
4：系统未使用保留给用户
5：图形界面
6：系统重启
常用运行级别是3和5，也可以指定默认运行级别
**init 数字** 切换运行级别
**systemctl get-default** 查询当前运行级别
**systemctl set-default TARGET.target**  指定默认运行级别
TARGET有以下选择
multi-user.target: analogous to runlevel 3 
graphical.target: analogous to runlevel 5 
## dd
```
dd if=/home/cafba/OS/bochs/test of=/home/cafba/OS/bochs/hd60M.img bs=512 count=1 conv=notrunc

if=FILE 指定要读取的文件。
of=FILE 指定把数据输出到哪个文件。
bs=BYTES 指定块的大小，dd以块为单位来进行IO操作。
ibs=BYTES 输入块大小，ibs和输出块大小obs可以单独配置。
count=BLOCKS 指定拷贝的块数。
seek=BLOCKS 指定当把块输出到文件时想要跳过多少个块，块从0开始算。
conv=CONVS 指定如何转换文件。
append append mode (makes sense only for output; conv=notrunc suggested) 在追加数据时，conv最好用notrunc方式，不打断文件。
```
## 网络
TCP 的连接状态查看，在 Linux 可以通过 `netstat -napt` 命令查看。
![TCP 连接状态查看](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9jZG4uanNkZWxpdnIubmV0L2doL3hpYW9saW5jb2Rlci9JbWFnZUhvc3QyLyVFOCVBRSVBMSVFNyVBRSU5NyVFNiU5QyVCQSVFNyVCRCU5MSVFNyVCQiU5Qy9UQ1AtJUU0JUI4JTg5JUU2JUFDJUExJUU2JThGJUExJUU2JTg5JThCJUU1JTkyJThDJUU1JTlCJTlCJUU2JUFDJUExJUU2JThDJUE1JUU2JTg5JThCLzE4LmpwZw?x-oss-process=image/format,png)
查看系统的 cwnd 初始化值
Linux 针对每一个 TCP 连接的 cwnd 初始化值是 10，也就是 10 个 MSS，我们可以用 ss -nli 命令查看每一个 TCP 连接的 cwnd 初始化值，如下图
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost2/%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BD%91%E7%BB%9C/TCP-%E5%8F%AF%E9%9D%A0%E7%89%B9%E6%80%A7/cwnd.png)
在服务端可以使用 `ss` 命令，来查看 TCP 全连接队列的情况
![img](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BD%91%E7%BB%9C/TCP-%E5%8D%8A%E8%BF%9E%E6%8E%A5%E5%92%8C%E5%85%A8%E8%BF%9E%E6%8E%A5/5.jpg)
![img](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BD%91%E7%BB%9C/TCP-%E5%8D%8A%E8%BF%9E%E6%8E%A5%E5%92%8C%E5%85%A8%E8%BF%9E%E6%8E%A5/6.jpg)
查看 TCP 半连接队列长度
![img](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BD%91%E7%BB%9C/TCP-%E5%8D%8A%E8%BF%9E%E6%8E%A5%E5%92%8C%E5%85%A8%E8%BF%9E%E6%8E%A5/21.jpg)
丢掉的 TCP 连接的个数会被统计起来，我们可以使用 `netstat -s` 命令来查看
![img](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BD%91%E7%BB%9C/TCP-%E5%8D%8A%E8%BF%9E%E6%8E%A5%E5%92%8C%E5%85%A8%E8%BF%9E%E6%8E%A5/10.jpg)
![img](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost/%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BD%91%E7%BB%9C/TCP-%E5%8D%8A%E8%BF%9E%E6%8E%A5%E5%92%8C%E5%85%A8%E8%BF%9E%E6%8E%A5/25.jpg)
上面输出的数值是**累计值**，表示共有多少个 TCP 连接因为半连接队列溢出而被丢弃。**隔几秒执行几次，如果有上升的趋势，说明当前存在半连接队列溢出的现象**。