# Linux内核
内核主要负责以下4种功能。
## 系统内存管理
内核不仅管理服务器上的可用物理内存，还可以创建并管理虚拟内存。内核通过硬盘上称为交换空间（swap space）的存储区域来实现虚拟内存。内核在交换空间和实际的物理内存之间反复交换虚拟内存中的内容。这使得系统以为自己拥有比物理内存更多的可用内存。
## 软件程序管理
**内核创建第一个进程（称为init进程）来启动系统中所有其他进程。当内核启动时，它会将init进程载入虚拟内存。内核在启动其他进程时，会在虚拟内存中给新进程分配一块专有区域来存储该进程用到的数据和代码。**
在Linux中，有多种init进程实现，目前最流行的是以下两种。SysVinit：Linux最初使用的是SysVinit（SysV）初始化方法，该方法基于Unix System V初始化方法。
systemd：systemd初始化方法诞生于2010年，现在已经成为Linux发行版中最流行的初始化和进程管理系统。SysVinit初始化方法使用运行级（runlevel）的概念来决定启动哪个进程。运行级定义了Linux系统的运行状态以及每种状态下应该运行的进程。表1-1显示了SysVinit初始化方法中定义的各种运行级。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919103236.png)
/etc/inittab文件定义了系统的默认运行级。特定运行级下启动的进程是在/etc/rc.d目录下的各个子目录中定义的。可以使用runlevel命令随时查看当前运行级。
systemd初始化方法得以流行起来的原因在于能够根据不同的事件启动进程：系统启动时、连接到特定的硬件设备时、服务启动时、建立好网络连接时、计时器到期时。
**systemd方法通过将事件与单元文件（unit file）链接来决定运行哪些进程**。每个单元文件定义了特定事件发生时要启动的程序。systemctl程序允许启动、停止和列出系统中当前运行的单元文件。
systemd方法将单元文件划归为目标（target）。目标定义了Linux系统的特定运行状态，这和SysVinit运行级的概念类似。在系统启动时，default.target单元定义了要启动的所有单元文件。可以使用systemctl命令查看当前默认目标：
```
$ systemctl get-default 
graphical.target
```
## 硬件设备管理
任何Linux系统需要与之通信的设备都必须在内核代码中加入其驱动程序。驱动程序相当于应用程序和硬件设备的“中间人”，允许内核同设备之间交换数据。向Linux内核中插入设备驱动的方法有两种：
- 将驱动程序编译入内核
- 将设备驱动模块加入内核
以前，插入设备驱动程序的唯一途径就是重新编译内核。因此，开发人员提出了内核模块的概念，允许在无须重新编译内核的情况下将驱动程序插入运行中的内核。另外，当设备不再使用时也可将内核模块从内核中移走。这种方式极大地简化和扩展了硬件设备在Linux中的使用。Linux系统将硬件设备视为一种特殊文件，称为设备文件。设备文件分为3种：
- 字符设备文件对应于每次只能处理一个字符的设备。大多数类型的调制解调器和终端是作为字符设备文件创建的。
- 块设备文件对应于每次以块形式处理数据的设备，比如硬盘驱动器。
- 网络设备文件对应于采用数据包发送和接收数据的设备，这包括网卡和一个特殊的环回设备，后者允许Linux系统使用常见的网络编程协议同自身通信。
Linux会为系统的每个设备都创建一种称为“节点”的特殊文件。与设备的所有通信都是通过设备节点完成的。每个节点都有一个唯一的数值对，以供Linux内核标识。数值对包括一个主设备号和一个次设备号。类似的设备会被划分到相同的主设备号下。次设备号用于标识主设备组下的某个特定设备。
## 文件系统管理
不同于其他一些操作系统，Linux内核支持通过不同类型的文件系统读写硬盘数据，内核必须在编译时就加入对所有要用到的文件系统的支持。Linux服务器所访问的所有硬盘驱动器都必须采用表1-2所列文件系统类型中的一种进行格式化。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919103623.png)
Linux内核采用虚拟文件系统（virtual file system，VFS）作为和各种文件系统交互的接口。这为Linux内核与其他类型文件系统之间的通信提供了一个标准接口。当文件系统被挂载和使用时，VFS会在内存中缓存相关信息。
# Shell
GNU/Linux shell是一种特殊的交互式工具，为用户提供了启动程序、管理文件系统中的文件以及运行在Linux系统中的进程的途径。
shell的核心是命令行提示符，负责shell的交互部分，允许用户输入文本命令，然后解释命令并在内核中执行。shell包含一组内部命令，可用于完成复制文件、移动文件、重命名文件、显示和终止系统中正在运行的程序这类操作。除此之外，shell也允许在命令行提示符中输入程序的名称，它会**将程序名称传递给内核以启动程序**。
也可以将多个shell命令放入文件中作为程序执行。这些文件称作shell脚本。凡是能在命令行中执行的命令都可放入shell脚本中作为一组命令执行。
在Linux系统中，有相当多的shell可供使用。不同的shell有不同的特性，有些适用于创建脚本，有些则适用于管理进程。所有Linux发行版默认的shell都是bash shell。
在图形化桌面出现之前，和Unix系统交互的唯一方式就是通过shell提供的**文本命令行界面**（command line interface，CLI）。CLI只允许输入文本，而且只能显示文本和基本图形输出。
## Linux控制台
进入CLI的一种途径是访问Linux系统的文本模式。该模式只在显示器上提供一个简单的shell CLI，就跟图形化桌面出现之前那样。这称作Linux控制台，因为它模拟的是期的硬接线控制台终端（hard-wired console terminal），而且是跟Linux系统交互的直接接口。
在大多数Linux发行版中，可以使用简单的按键组合来访问某个Linux虚拟控制台。通常必须按下Ctrl+Alt组合键，然后再按一个功能键（F1～F7）来进入你要使用的虚拟控制台。功能键F2键会生成虚拟控制台2，F3键会生成虚拟控制台3，F4键会生成虚拟控制台4，以此类推。
> Linux发行版通常使用Ctrl+Alt组合键配合F1键、F7键或F8键进入虚拟控制台。Ubuntu和CentOS均使用F1键。
> 不是所有的Linux发行版都会在登录画面显示虚拟控制台的tty编号。登入虚拟控制台后，可以入命令tty，然后按Enter键查看当前使用的是哪个虚拟控制台
## bash shell基础命令
当你使用man命令查看命令手册页的时候，其中的信息是由分页程序（pager）来显示的。分页程序是一种实用工具，能够逐页（或逐行）显示文本。你可以单击空格键进行翻页，或是使用Enter键逐行查看。也可以使用箭头键向前和向后滚动手册页的内容（假设你使用的终端仿真软件包支持箭头键功能）。
手册页将与命令相关的信息分成了多段。每一段的惯用名标准如表3-1所示。
很多命令采用的基本模式如下。
```
COMMAND-NAME [OPTION]... [ARGUMENT]...
```
下面是对以上命令的模式结构的解释。
- COMMAND-NAME是要运行的命令名。
- OPTION是用于修改命令行为的选项。可添加的OPTION通常不止一个。中括号表示OPTION并不是必需的，3个点号（...）表示可以一次指定多个OPTION。
- ARGUMENT是传递给命令的参数，以指明命令的操作对象。从中括号可以看出，ARGUMENT也不是必需的，也可以一次指定多个ARGUMENT。
## 浏览文件系统
Linux会将文件存储在名为虚拟目录（virtual directory）的单个目录结构中。Linux虚拟目录结构只包含一个称为根（root）目录的基础目录。虚拟目录会将计算机中所有存储设备的文件路径都纳入单个目录结构。
Linux虚拟目录中比较复杂的部分是它如何来协调管理各个存储设备。
称在Linux系统中安装的第一块硬盘为根驱动器。根驱动器包含了虚拟目录的核心，其他目录都是从那里开始构建的。
Linux会使用根驱动器上一些特别的目录作为挂载点。**挂载点是虚拟目录中分配给额外存储设备的目录。Linux会让文件和目录出现在这些挂载点目录中，即便它们位于其他物理驱动器中**。系统文件通常存储在根驱动器中，而用户文件则存储在其他驱动器中，如图3-3所示。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919105709.png)
图3-3展示了计算机中的两块硬盘。一块硬盘（Disk 1）与虚拟目录的根目录关联，其他硬盘可以挂载到虚拟目录结构中的任何地方。在这个例子中，另一块硬盘（Disk 2）被挂载到了/home，这是用户主目录所在的位置。
Linux文件系统结构演进自Unix文件系统。在Linux文件系统中，采用通用的目录名表示一些常见的功能。表3-3列出了一些常见的Linux顶层虚拟目录名及其内容。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919105728.png)
### 遍历文件
ls：
- -F选项会在目录名之后添加/，以方便用户在输出中分辨。类似地，它还会在可执行文件（比如上面的my_script文件）之后添加`*`，以帮助用户找出可在系统中运行的文件。
- -a选项会显示隐藏文件
- -R可以列出当前目录所包含的子目录中的文件。
- -l选项会产生长列表格式的输出，提供目录中各个文件的详细信息。此后的每一行都包含了关于文件（或目录）的下列信息：文件类型、文件的权限、文件的硬链接数、文件属主、文件属组、文件大小（以字节为单位）、文件的上次修改时间、文件名或目录名。
如果想查看单个文件的长列表，那么只需在ls -l命令之后跟上该文件名即可。但如果想查看目录的相关信息，而非目录所包含的内容，则除了-l选项之外，还得添加-d选项
ls命令也能识别标准通配符（wildcard），并在过滤器中用其来进行模式匹配：
- ?代表任意单个字符
- `*`代表零个或多个字符
- 方括号代表单个字符位置并给出了该位置上的多个可能的选择。可以将可能的字符逐一列出，也可以指定字符范围，比如字母范围`[a–i]`
- !将不需要的内容排除在外
### 处理文件
touch命令会创建好指定的文件并将你的用户名作为该文件的属主。touch命令还可用来改变文件的修改时间。该操作不会改变文件内容。
cp命令最基本的用法需要两个参数，即源对象和目标对象：cp source destination。**当参数source和destination都是文件名时，cp命令会将源文件复制成一个新的目标文件，并以destination命名**。也可以将文件复制到现有目录中，在cp命令中使用通配符。
> 如果目标文件已经存在，则cp命令可能并不会提醒你这一点。最好加上-i选项，强制shell询问是否需要覆盖已有文件。
> -R选项可以在单个命令中递归地复制整个目录的内容
### 链接文件
如果需要在系统中维护同一文件的两个或多个副本，可以使用单个物理副本加多个虚拟副本（链接）的方法代替创建多个物理副本。链接是目录中指向文件真实位置的占位符。在Linux中有两种类型的文件链接。
符号链接（也称为软链接）是一个文件，该文件指向存放在虚拟目录结构中某个地方的另一个文件。这**两个以符号方式链接在一起的文件彼此的内容并不相同**。
要为一个文件创建符号链接，原始文件必须事先存在，然后**使用ln命令以及-s选项来创建符号链接**。
```shell
$ ln -s test_file slink_test_file
$ ls -l *test_file
lrwxrwxrwx. 1 christine christine  9 Mar  4 09:46 slink_test_file -> test_file
-rw-rw-r--. 1 christine christine 74 Feb 29 15:50 test_file
```
在上面的例子中，注意符号链接文件名slink_test_file位于ln命令的第二个参数的位置。长列表（ls -l）中显示的符号文件名后的->符号表明该文件是链接到文件test_file的一个符号链接。
另外，还要注意符号链接文件与数据文件的文件大小。符号链接文件slink_test_file只有9个字节，而test_file有74个字节。这是因为slink_test_file仅仅只是指向test_file而已。它们的内容并不相同，是两个完全不同的文件。
另一种证明链接文件是一个独立文件的方法是查看inode编号。文件或目录的inode编号是内核分配给文件系统中的每一个对象的唯一标识。要查看**文件或目录的inode编号，可以使用ls命令的-i选项**。
**硬链接创建的是一个独立的虚拟文件，其中包含了原始文件的信息以及位置。但是两者就根本而言是同一个文件**。要想创建硬链接，原始文件也必须事先存在，只不过这次使用ln命令时不需要再加入额外的选项。
```shell
$ ln test_one hlink_test_one
$ ls -li *test_one
1415016 -rw-rw-r--. 2 christine christine 0 Feb 29 17:26 hlink_test_one
1415016 -rw-rw-r--. 2 christine christine 0 Feb 29 17:26 test_one
```
以硬链接相连的文件共享同一个inode编号。这是因为两者其实就是同一个文件。另外，彼此的文件大小也一模一样。
> 只能对处于同一存储设备的文件创建硬链接。要想在位于不同存储设备的文件之间创建链接，只能使用符号链接
### 文件重命名
在Linux中，重命名文件称为移动（moving）。mv命令可以将文件和目录移动到另一个位置或是重新命名。文件的时间戳和inode编号不会改变，改变的只有位置或名称。
```shell
# 重命名只涉及文件名
$ mv fall fzll
# 移动会涉及位置
$ mv /home/christine/fzll /home/christine/NewDocuments/
# 可以使用mv命令在移动文件的同时进行重命名
$ mv /home/christine/NewDocuments/fzll /home/christine/fall
# 也可以使用mv命令移动整个目录及其内容
$ mv NewDocuments OldDocuments
```
> 和cp命令类似，也可以在mv命令中使用-i选项。这样在mv试图覆盖已有的文件时会发出询问。
### 管理目录
mkdir的-p选项可以根据需要创建缺失的父目录。
rmdir是删除目录的基本命令，在默认情况下只删除空目录。
rm可以在整个非空目录中使用。-r选项使得rm命令可以向下进入目录，删除其中的文件，然后再删除目录本身。
### 查看文件内容
file命令能够探测文件的内部并判断文件类型。file命令能够确定该程序编译时所面向的平台以及需要何种类型的库。如果有从未知来源处获得的二进制文件，那么这会是一个非常有用的特性。
cat命令是显示文本文件中所有数据，-n选项会给所有的行加上行号，如果只想给有文本的行加上行号，可以用-b选项。
more命令会显示文本文件的内容，但会在显示每页数据之后暂停下来。可以使用空格键向前翻页，或是使用Enter键逐行向前查看。结束之后，按q键退出。
less命令可以在完成整个文件的读取之前显示文件的内容。cat命令和more命令则无法做到这一点。还能够识别上下箭头键以及上下翻页键。
tail命令会显示文件最后几行的内容（文件的“尾部”）。在默认情况下，它会显示文件的末尾10行。可以向tail命令中加入-n选项来修改所显示的行数。tail命令的-f选项允许在其他进程使用此文件时查看文件的内容。tail命令会保持活动状态并持续地显示添加到文件中的内容。这是实时监测系统日志的绝佳方式。
head命令会显示文件开头若干行。在默认情况下，它会显示文件前10行的文本，与tail命令类似，head命令也支持-n选项，以便指定想要显示的内容。这两个命令也允许简单地在连字符后面直接输入想要显示的行数，例如-3。
## 监测程序
### ps
ps命令默认只显示运行在当前终端中属于当前用户的那些进程，显示**程序的进程ID（process ID，PID）、进程运行在哪个终端（TTY）及其占用的CPU时间。**
Linux系统中使用的GNU ps命令支持以下3种类型的命令行选项：
- Unix 风格选项，选项前加单连字符
- BSD 风格选项，选项前不加连字符
- GNU 长选项，选项前加双连字符。
#### Unix
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919145235.png)
如果需要查看系统中运行的所有进程，可以使用-ef选项组合，-e选项指定显示系统中运行的所有进程；-f选项则扩充输出内容以显示一些有用的信息列。
```shell
$ ps -ef
UID          PID    PPID  C STIME TTY          TIME CMD
root           1       0  0 12:14 ?        00:00:02 /sbin/init splash
root           2       0  0 12:14 ?        00:00:00 [kthreadd]
```
- UID：启动该进程的用户。
- PID：进程ID。
- PPID：父进程的PID（如果该进程是由另一个进程启动的）。
- C：进程生命期中的CPU利用率。·
- STIME：进程启动时的系统时间。
- TTY：进程是从哪个终端设备启动的。
- TIME：运行进程的累计CPU时间。
- CMD：启动的程序名称。
如果还想获得更多的信息，可以使用-l选项，产生长格式输出。
```shell
$ ps -l
F S  UID PID  PPID  C PRI  NI ADDR SZ WCHAN   TTY         TIME   CMD
0 S  500 3081  3080  0  80   0 -  1173 do_wai pts/0   00:00:00   bash
0 R  500 4463  3081  1  80   0 -  1116 -      pts/0   00:00:00   ps
```
- F：内核分配给进程的系统标志。
- S：进程的状态（O代表正在运行；S代表在休眠；R代表可运行，正等待运行；Z代表僵化，已终止但找不到其父进程；T代表停止）。
- PRI：进程的优先级（数字越大，优先级越低）。
- NI：谦让度（nice），用于决定优先级。
- ADDR：进程的内存地址。
- SZ：进程被换出时所需交换空间的大致大小。
- WCHAN：进程休眠的内核函数地址。
#### BSD
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919145557.png)
在使用BSD风格的选项时，ps命令会自动改变输出以模仿BSD格式。下面是使用l选项的输出。
```shell
$ ps l
F   UID     PID    PPID PRI  NI    VSZ   RSS WCHAN  STAT TTY TIME COMMAND
4  1000    1491    1415  20   0 163992  6580 poll_s Ssl+ tty2 0:00 /usr/li
```
尽管上述很多输出列跟使用Unix风格选项时是一样的，但还是有一些不同之处。
VSZ：进程占用的虚拟内存大小（以KB为单位）。
RSS：进程在未被交换出时占用的物理内存大小。
STAT：代表当前进程状态的多字符状态码。很多系统管理员喜欢BSD风格的l选项，因为能输出更详细的进程状态码（STAT列）。多字符状态码能比Unix风格输出的单字符状态码更清楚地表明进程的当前状态。
第一个字符采用了与Unix风格的S输出列相同的值，表明进程是在休眠、运行还是等待。
第二个字符进一步说明了进程的状态。
- <：该进程以高优先级运行。
- N：该进程以低优先级运行。
- L：该进程有锁定在内存中的页面。
- s：该进程是控制进程。
- l：该进程拥有多线程。
- +：该进程在前台运行。
从先前展示的简单例子中可以看出，bash命令处于休眠状态，但同时它也是一个控制进程（会话中的主进程），而ps命令则运行在系统前台。
#### GNU
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919150027.png)
可以混用GNU长选项和Unix或BSD风格的选项来定制输出。作为一个GNU长选项，--forest选项能够使用ASCII字符来绘制图表以显示进程的层级信息。
### top
ps命令虽然在收集系统中运行进程的信息时非常有用，但只能显示某个特定时间点的信息。而top命令采用实时方式显示进程信息。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919150200.png)
第一行显示了当前时间、系统的运行时长、登录的用户数以及系统的平均负载。平均负载有3个值，分别是最近1分钟、最近5分钟和最近15分钟的平均负载。值越大说明系统的负载越高。由于进程短期的突发性活动，出现最近1分钟的高负载值也很常见。但如果近15分钟内的平均负载都很高，就说明系统可能有问题了。
第二行显示了进程（top称其为task）概况：多少进程处于运行、休眠、停止以及僵化状态（僵化状态指进程已结束，但其父进程没有响应）。
下一行显示了CPU概况。top会根据进程的属主（用户或是系统）和进程的状态（运行、空闲或等待）将CPU利用率分成几类输出。
紧跟其后的两行详细说明了系统内存的状态。前一行显示了系统的物理内存状态：总共有多少内存、当前用了多少，以及还有多少空闲。后一行显示了系统交换空间（如果分配了的话）的状态。
最后一部分显示了当前处于运行状态的进程的详细列表，有些列跟ps命令的输出类似。
- PID：进程的PID。
- USER：进程属主的用户名。
- PR：进程的优先级。
- NI：进程的谦让度。
- VIRT：进程占用的虚拟内存总量。
- RES：进程占用的物理内存总量。
- SHR：进程和其他进程共享的内存总量。
- S：进程的状态（D代表可中断的休眠，R代表运行，S代表休眠，T代表被跟踪或停止，Z代表僵化）。
- %CPU：进程使用的CPU时间比例。
- %MEM：进程使用的可用物理内存比例。
- TIME+：自进程启动到目前为止所占用的CPU时间总量。
- COMMAND：进程所对应的命令行名称，也就是启动的程序
在默认情况下，top命令在启动时会按照%CPU值来对进程进行排序，你可以在top命令运行时使用多种交互式命令来重新排序。每个交互式命令都是单字符，在top命令运行时键入可改变top的行为。键入f允许你选择用于对输出进行排序的字段，键入d允许你修改轮询间隔（polling interval），键入q可以退出top。
用户对top命令输出有很大的控制权。利用该工具，你经常能找出占用系统大量资源的罪魁祸首。当然，找到之后，下一步就是结束这些进程。
### kill
在Linux中，进程之间通过信号来通信。进程的信号是预定义好的一个消息，进程能识别该消息并决定忽略还是做出反应。进程如何处理信号是由开发人员通过编程来决定的。大多数编写完善的应用程序能接收和处理标准Unix进程信号。这些信号如表4-4所示。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919150343.png)
在Linux中有两个命令可以向运行中的进程发出进程信号：kill和pkill。
kill命令可以通过PID向进程发送信号。**在默认情况下，kill命令会向命令行中列出的所有PID发送TERM信号**，但只能使用进程的PID而不能使用其对应的程序名。TERM信号会告诉进程终止运行。但不服管教的进程通常会忽略这个请求。如果要强制终止，则-s选项支持指定其他信号（用信号名或信号值）。
要检查kill命令是否生效，可以再次执行ps命令或top命令，看看那些进程是否已经停止运行。
pkill命令可以使用程序名代替PID来终止进程，pkill命令也允许使用通配符。
## 监测磁盘空间
Linux文件系统会将所有的磁盘都并入单个虚拟目录。在使用新的存储设备之前，需要将其放在虚拟目录中。这项工作称为挂载（mounting）。
### mount
用于挂载存储设备的命令叫作mount。**在默认情况下，mount命令会输出当前系统已挂载的设备列表**。mount命令提供了4部分信息：
- 设备文件名
- 设备在虚拟目录中的挂载点
- 文件系统类型
- 已挂载设备的访问状态
要手动在虚拟目录中挂载设备，需要以root用户身份登录，或是以root用户身份运行sudo命令。
下面是**手动挂载设备的基本命令**：
```
mount -t type device directory
```
其中，type参数指定了磁盘格式化所使用的文件系统类型。Linux可以识别多种文件系统类型。如果与Windows PC共用移动存储设备，那么通常需要使用下列文件系统类型。
vfat：Windows FAT32文件系统，支持长文件名。
ntfs：Windows NT及后续操作系统中广泛使用的高级文件系统。
exfat：专门为可移动存储设备优化的Windows文件系统。
iso9660：标准CD-ROM和DVD文件系统。大多数U盘会使用vfat文件系统格式化。如果需要挂载数据CD或DVD，则必须使用iso9660文件系统类型。
后面两个参数指定了该存储设备的设备文件位置以及挂载点在虚拟目录中的位置。例如，手动将U盘/dev/sdb1挂载到/media/disk，可以使用下列命令：
```
mount -t vfat /dev/sdb1 /media/disk
```
一旦存储设备被挂载到虚拟目录，root用户就拥有了对该设备的所有访问权限，而其他用户的访问则会被限制。可以通过目录权限指定用户对设备的访问权限。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919150920.png)
- o：允许在挂载文件系统时添加一系列以逗号分隔的额外选项。
- ro：以只读形式挂载。
- rw：以读写形式挂载。
- user：允许普通用户挂载该文件系统。
- check=none：挂载文件系统时不执行完整性校验。
- loop：挂载文件。
### umount
移除可移动设备时，不能直接将设备拔下，应该先卸载。**umount命令支持通过设备文件或者挂载点来指定要卸载的设备**。如果有任何程序正在使用设备上的文件，则系统将不允许卸载该设备。
```
umount [directory | device ]
```
在本例中，因为命令行提示符仍然位于已挂载设备的文件系统中，所以umount命令无法卸载该镜像文件。一旦命令提示符移出其镜像文件系统，umount命令就能成功卸载镜像文件了。
```shell
# umount /home/rich/mnt 
umount: /home/rich/mnt: device is busy 
# cd /home/rich 
# umount /home/rich/mnt 
# ls -l mnt
total 0 
#
```
### df
df命令可以方便地查看所有已挂载磁盘的使用情况：
```shell
$ df -t ext4 -t vfat
Filesystem     1K-blocks       Used Available Use% Mounted on
/dev/sda5       19475088    7326256  11136508  40% /
/dev/sda2         524272          4    524268   1% /boot/efi
/dev/sdb1         983552     247264    736288  26% /media/
rich/54A1-7D7D
```
df命令会逐个显示已挂载的文件系统。与mount命令类似，df命令会输出内核挂载的所有虚拟文件系统，因此可以使用-t选项来指定文件系统类型，进而过滤输出结果。该命令的输出如下：
- 设备文件位置
- 包含多少以1024字节为单位的块
- 使用了多少以1024字节为单位的块
- 还有多少以1024字节为单位的块可用
- 已用空间所占的百分比·设备挂载点
df命令常用选项之一是-h，该选项会以人类易读的形式显示磁盘空间，通常用M来替代兆字节，用G来替代吉字节。
> Linux系统后台一直有进程在处理文件。df命令的出值反映的是Linux系统认为的当前值。正在运行的进程有可能创建或删除了某个文件，但尚未释放该文件。这个值是不会被计算进闲置空间的。
### du
du命令可以显示某个特定目录（默认情况下是当前目录）的磁盘使用情况。在默认情况下，du命令会显示当前目录下所有的文件、目录和子目录的磁盘使用情况，并以磁盘块为单位来表明每个文件或目录占用了多大存储空间。
每行最左侧的数字是每个文件或目录所占用的磁盘块数。
下面这些选项能让du命令的输出更加清晰易读。
- -c：显示所有已列出文件的总大小。
- -h：按人类易读格式输出大小，分别用K表示千字节、M表示兆字节、G表示吉字节。
- -s：输出每个参数的汇总信息。
## 处理数据文件
### 数据排序
在默认情况下，sort命令会依据会话所指定的默认语言的排序规则来**对文本文件中的数据行进行排序**。
在默认情况下，sort命令会将数字视为字符并执行标准的字符排序，这种结果可能不是你想要的。可以**使用-n选项告诉sort命令将数字按值排序**。
另一个常用的选项是-M，该选择可以将数字按月排序。Linux的日志文件经常在每行的起始位置有一个时间戳，以表明事件是什么时候发生的，如果加入-M选项，那么sort命令就能识别三字符的月份名并正确排序。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919151554.png)

在对按字段分隔的数据（比如/etc/passwd文件）进行排序时，-k选项和-t选项非常方便。先使用-t选项指定字段分隔符，然后使用-k选项指定排序字段。例如，要根据用户ID对/etc/passwd按数值排序，可以这么做：
```shell
$ sort -t ':' -k 3 -n /etc/passwd
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
adm:x:3:4:adm:/var/adm:/sbin/nologin
lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin
sync:x:5:0:sync:/sbin:/bin/sync
```
现在数据已经按第三个字段（用户ID的数值）排序妥当了。
-n选项适合于排序数值型输出，-r选项对数值按照降序排列，比如du命令的输出：
```shell
$ du -sh * | sort -nr
1008k   mrtg-2.9.29.tar.gz
972k    bldg1
888k    fbs2.pdf
760k    Printtest
680k    rsync-2.6.6.tar.gz
660k    code
516k    fig1001.tiff
496k    test
496k    php-common-4.0.4pl1-6mdk.i586.rpm
448k    MesaGLUT-6.5.1.tar.gz
400k    plp
```
> 本例中的管道命令（|）用于将du命令的出传入sort命令，
### 数据搜索
grep命令的格式如下：
```
grep [options] pattern [file]
```
grep命令会在输入或指定文件中逐行搜索匹配指定模式的文本。该命令的输出是包含匹配模式的所有行。
- 如果要进行反向搜索（输出不匹配指定模式的行），可以使用-v选项。
- 如果要显示匹配指定模式的那些行的行号，可以使用-n选项。
- 如果只想知道有多少行含有匹配的模式，可以使用-c选项。
- 如果要指定多个匹配模式，可以使用-e选项来逐个指定。
在默认情况下，grep命令使用基本的Unix风格正则表达式来匹配模式。
正则表达式中的方括号表明grep应该搜索包含t字符或者f字符的匹配。如果不用正则表达式，则grep搜索的是匹配字符串tf的文本。
```
$ grep [tf] file1 
two three four five 
```
egrep命令是grep的一个衍生，支持POSIX扩展正则表达式，其中包含更多可用于指定匹配模式的字符。
fgrep则是另外一个版本，支持将匹配模式指定为以换行符分隔的一系列固定长度的字符串。这样就可以将这些字符串放入一个文件中，然后在fgrep命令中使用其搜索大文件中的字符串。
### 数据压缩
gzip命令会压缩命令行中指定的文件，也可以指定多个文件名或是用通配符来一次性压缩多个文件。
zip命令能够很好地将数据压缩并归档为单个文件，但它并不是Unix和Linux中的标准归档工具。目前，Unix和Linux中最流行的归档工具是tar命令。
tar命令最开始是用于将文件写入磁带设备以作归档，但它也可以将输出写入文件，这种用法成了在Linux中归档数据的普遍做法。tar命令的格式如下。
```
tar function [options] object1 object2 ...
```
function定义了tar命令要执行的操作，如表4-8所示。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919152015.png)
每种操作都使用option（选项）来定义针对tar归档文件的具体行为。表4-9列出了常用的选项。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919152049.png)
这些选项经常合并使用。可以用下列命令创建归档文件：
```
tar -cvf test.tar test/ test2/
```
该命令创建了一个名为test.tar的归档文件，包含目录test和test2的内容。
```
tar -tf test.tar
```
该命令列出了（但不提取）tar文件test.tar的内容。
```
tar -xvf test.tar
```
该命令从tar文件test.tar中提取内容。如果创建的时候tar文件含有目录结构，则在当前目录中重建该目录的整个结构。
> 在下载开源软件时经常会看到文件名以.tgz结尾，这是经gzip压缩过的tar文件，可以用命令tar -zxvf filename.tgz来提取其中的内容。
## shell的类型
当你登录系统时，系统启动什么样的shell程序取决于你的个人用户配置。**在/etc/passwd文件中，用户记录的第7个字段中列出了该用户的默认shell程序**。默认的交互式shell（default interactive shell）也称登录shell，**只要用户登录某个虚拟控制台终端或是在GUI中启动终端仿真器，该shell就会启动**。
在下面的例子中，用户christine使用GNU bash shell作为自己的默认shell程序：
```
$ cat /etc/passwd 
[...] 
christine:x:1001:1001::/home/christine:/bin/bash $
```
在现代Linux系统中，**bash shell程序（bash）通常位于/usr/bin目录**。不过，在你的Linux系统中，也有可能位于/bin目录。
which bash命令可以找出bash shell的位置：
```
$ which bash 
/usr/bin/bash
```
长列表中文件名尾部的`*`表明bash文件（bash shell）是一个可执行程序。
```
$ ls -lF /usr/bin/bash 
-rwxr-xr-x. 1 root root 1219248 Nov 8 11:30 /usr/bin/bash* $
```
在大多数Linux系统中，/etc/shells文件中列出了各种已安装的shell，这些shell可以作为用户的默认shell。
> 在现代Linux系统中，/bin是指向/usr/bin的符号链接，因此shell文件似乎存在于两个位置。这就是为什么用户christine的默认shell程序是/bin/bash，但bash shell程序实际位于/usr/bin/目录。

作为默认的系统shell，sh（/bin/sh）用于那些需要在启动时使用的系统shell脚本。
你经常会看到某些发行版使用软链接将默认的系统shell指向bash shell，比如CentOS发行版：
```
$ which sh
/usr/bin/sh
$ ls -l /usr/bin/sh
lrwxrwxrwx. 1 root root 4 Nov  8 11:30 /usr/bin/sh -> bash
```
但要注意，在有些发行版中，默认的系统shell并不指向bash shell，比如Ubuntu发行版：
```
$ which sh
/usr/bin/sh
$ ls -l /usr/bin/sh
lrwxrwxrwx 1 root root 4 Mar 10 18:43 /usr/bin/sh -> dash
```
在这里，默认的系统shell（/usr/bin/sh）指向的是Dash shell。
> 对bash shell脚本来说，这两种shell（默认的交互shell和默认的系统shell）可能会导致问题。这与bash shell脚本首行的语法要求有关。

可以启动任意一种已安装的shell，只需输入其名称即可。但屏幕上不会有任何提示或消息表明你当前使用的是哪种shell。命令echo$0会显示当前shell的名称，提供必要的参考。
> 使用echo $0显示当前所用shell的做法仅限在shell命令行中使用。echo $0命令的输出中bash之前有一个连字符（-）。这表明该shell是用户的登录shell。
> 如果在shell脚本中使用，则显示的是该脚本的名称。

#父子shell
## shell的父子关系
用户登录某个虚拟控制台终端或在GUI中运行终端仿真器时所启动的默认的交互式shel（登录shell）是一个父shell。到目前为止，都是由父shell提供CLI提示符并等待命令输入。
当你在CLI提示符处输入bash命令（或是其他shell程序名）时，会创建新的shell程序。这是一个子shell。子shell也拥有CLI提示符，同样会等待命令输入。
在输入bash并生成子shell时，屏幕上不会显示任何相关信息，需要用到ps命令，在生成子shell的前后配合 -f选项来使用：
```
$ ps -f
UID        PID  PPID  C STIME TTY              TIME CMD
christi+  6160  6156  0 11:01 pts/1        00:00:00 -bash
christi+  7141  6160  0 12:51 pts/1        00:00:00 ps -f
$ bash
$ ps -f
UID        PID  PPID  C STIME TTY              TIME CMD
christi+  6160  6156  0 11:01 pts/1        00:00:00 -bash
christi+  7142  6160  0 12:52 pts/1        00:00:00 bash
christi+  7164  7142  0 12:52 pts/1        00:00:00 ps -f
```
输入命令bash之后，就创建了一个子shell。第二个ps -f是在子shell中执行的。你可以从显示结果中看到有两个 bash shell程序在运行。一个是父shell进程，其PID为6160。另一个是子shell进程，其PID为7142。注意，子shell的父进程ID（PPID）是6160，表明这个进程就是该子shell的父进程。
> 在生成子shell进程时，只有部分父进程的环境被复制到了子shell环境中。这会对包括变量在内的一些东西造成影响。

子shell既可以从父shell中创建，也可以从另一个子shell中创建，ps --forest命令展示了这些子shell间的嵌套结构。ps -f命令也能够表现子shell间的嵌套关系，因为它会通过PPID列显示出谁是谁的父进程。
bash shell程序可以使用命令行选项来修改shell的启动方式。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20230919153520.png)
可以使用exit命令有条不紊地退出子shell。
> 如果想查看bash shell的版本号，在命令行中出bash --version即可。该命令不会创建子shell，只会显示系统中GNU bash shell程序的当前版本。
### 进程列表
可以在单行中指定要依次运行的一系列命令。这可以通过命令列表来实现，只需将命令之间以分号分隔即可。不过这并不是进程列表。要想成为进程列表，命令列表必须将命令放入圆括号内：
```
$ (pwd ; ls test* ; cd /etc ; pwd ; cd ; pwd ; ls my*)
```
**圆括号的加入使命令列表变成进程列表，生成一个子shell来执行这些命令**。
> 进程列表是命令分组的一种。另一种命令分组是将命令放入花括号内，并在命令列表尾部以分号作结。语法为：{ command; }。**使用花括号进行命令分组并不会像进程列表那样创建子shell**。

要想知道是否生成了子shell，需要使用命令输出一个环境变量的值。这个命令就是echo $BASH_SUBSHELL。如果该命令返回0，那么表明没有子shell。如果该命令返回1或者其他更大的数字，则表明存在子shell。
因此，进程列表就是使用圆括号包围起来的一组命令，它能够创建子shell来执行这些命令。甚至可以在进程列表中嵌套圆括号来创建子shell的子shell：
```
$ (pwd ; echo $BASH_SUBSHELL)
/home/Christine
1
$ (pwd ; (echo $BASH_SUBSHELL))
/home/Christine
2
```
子shell在shell脚本中经常用于多进程处理。但是，创建子shell的成本不菲（意思是要消耗更多的资源，比如内存和处理能力），会明显拖慢任务进度。在交互式CLI shell会话中，子shell同样存在问题，它并非真正的多进程处理，原因在于终端与子shell的I/O绑定在了一起。
### 子shell用法
### 后台模式
**在后台模式中运行命令可以在处理命令的同时让出CLI，以供他用**。要想将命令置入后台模式，可以在命令末尾加上字符 &。
```
$ sleep 3000&
[1] 2542
$ ps -f
UID        PID  PPID  C STIME TTY          TIME CMD
christi+  2356  2352  0 13:27 pts/0    00:00:00 -bash
christi+  2542  2356  0 13:44 pts/0    00:00:00 sleep 3000
christi+  2543  2356  0 13:44 pts/0    00:00:00 ps -f
```
sleep命令会在后台睡眠3000秒（50分钟）。当其被置入后台时，在shell CLI提示符返回之前，屏幕上会出现两条信息。
第一条信息是方括号中的后台作业号1。
第二条信息是后台作业的进程ID2542。
ps命令的输出中第二列显示的PID和sleep命令进入后台时所显示的PID是一样的，都是2542。
除ps命令，也可以使用jobs命令来显示后台作业信息。jobs命令能够显示当前运行在后台模式中属于你的所有进程：
```
$ jobs 
[1]+ Running sleep 3000 &
```
jobs命令会在方括号中显示作业号（1）。除此之外，还有作业的当前状态（Running）以及对应的命令（sleep 3000&）。
利用jobs命令的-l选项还会显示命令的PID：
```
$ jobs -l 
[1]+ 2542 Running sleep 3000 &
```
> 如果运行多个后台进程，则还有一些额外信息可以显示哪个后台作业是最近启动的。在jobs命令的显示中，最近启动的作业在其作业号之后会有一个加号（+），在它之前启动的进程（the second newest process）则以减号（-）表示。
### 将进程列表置入后台
通过将进程列表置入后台，可以在子shell中进行大量的多进程处理。由此带来的一个好处是**终端不再和子shell的I/O绑定在一起**。
进程列表是子shell中运行的一系列命令：
```
$ (sleep 2 ; echo $BASH_SUBSHELL ; sleep 2) 
1
```
同样的进程列表置入后台会产生些许不同的命令输出：
```
$ (sleep 2 ; echo $BASH_SUBSHELL ; sleep 2)&
[2] 2553
$ 1
[2]+  Done ( sleep 2; echo $BASH_SUBSHELL; sleep 2 )
```
使用tar创建备份文件是有效利用后台进程列表的一个更实用的例子：
```
$ (tar -cf Doc.tar Documents ; tar -cf Music.tar Music)&
[1] 2567
$ ls *.tar
Doc.tar Music.tar
[1]+ Done ( tar -cf Doc.tar Documents; tar -cf Music.tar Music )
$
```
### 协程
**协程会在后台生成一个子shell，在该子shell中执行命令**。
要进行协程处理，可以结合使用coproc命令以及要在子shell中执行的命令：
```
$ coproc sleep 10 
[1] 2689
```
当输入coproc命令及其参数之后，会发现后台启用了一个作业。屏幕上会显示该后台作业号（1）以及进程ID（2689）。
jobs命令可以显示协程的状态：
```
$ jobs 
[1]+ Running coproc COPROC sleep 10 &
```
从上面的例子中可以看到，在子shell中执行的后台命令是coproc COPROC sleep 10。COPROC是coproc命令给进程起的名字。可以使用命令的扩展语法来自己设置这个名字：
```
$ coproc My_Job { sleep 10; }
[1] 2706
$ jobs
[1]+ Running coproc My_Job { sleep 10; } &
```
使用扩展语法，协程名被设置成了My_Job。这里要注意，必须确保在左花括号和内部命令名之间有一个空格。还必须保证内部命令以分号结尾。另外，分号和右花括号之间也得有一个空格。
> 只有在拥有多个协程时才需要对协程进行命名，因为你要和它们进行通信。否则的话，让coproc命令将其设置成默认名称COPROC即可。

可以将协程与进程列表结合起来创建嵌套子shell。只需将命令coproc放在进程列表之前即可：
```
$ coproc ( sleep 10; sleep 2 )
[1] 2750
$ jobs
[1]+  Running                  coproc COPROC ( sleep 10; sleep 2 ) &
$ ps --forest
  PID TTY          TIME CMD
 2367 pts/0    00:00:00 bash
 2750 pts/0    00:00:00  \_ bash
 2751 pts/0    00:00:00  |   \_ sleep
 2752 pts/0    00:00:00  \_ ps
```
## 外部命令
外部命令（有时也称为文件系统命令）是存在于bash shell之外的程序。也就是说，它并不属于shell程序的一部分。外部命令程序通常位于 /bin、/usr/bin、/sbin或 /usr/sbin目录中。
ps命令就是一个外部命令。可以使用which命令和type命令找到其对应的文件名：
```
$ which ps 
/usr/bin/ps 
$ type ps 
ps is /usr/bin/ps
```
**每当执行外部命令时，就会创建一个子进程**。这种操作称为衍生。例如外部命令ps会显示其父进程以及自己所对应的衍生子进程。
## 内建命令
与外部命令不同，内建命令无须使用子进程来执行。内建命令已经和shell编译成一体，作为shell的组成部分存在，无须借助外部程序文件来执行，所以执行速度更快，效率也更高。
cd命令和exit命令都内建于bash shell。可以使用type命令来判断某个命令是否为内建。
有些命令有多种实现。例如，echo和pwd既有内建命令也有外部命令。两种实现略有差异。要查看命令的不同实现，可以使用type命令的 -a选项：
```
$ type -a echo
echo is a shell builtin
echo is /usr/bin/echo
$ which echo
/usr/bin/echo
$ type -a pwd
pwd is a shell builtin
pwd is /usr/bin/pwd
$ which pwd
/usr/bin/pwd
```
对于有多种实现的命令，如果想使用其外部命令实现，直接指明对应的文件即可。例如，要使用外部命令pwd，可以通输入/usr/bin/pwd。

### history命令
要查看最近用过的命令列表，可以使用不带任何选项的history命令。
命令历史记录被保存在位于用户主目录的隐藏文件.bash_history之中。在CLI会话期间，bash命令的历史记录被保存在内存中。当shell退出时才被写入历史文件。可以在不退出shell的情况下强制将命令历史记录写入.bash_history文件。为此，需要使用history命令的 -a选项：
如果打开了多个终端会话，则仍然可以使用history -a命令在每个打开的会话中向 .bash_history文件添加记录。但是历史记录并不会在其他打开的终端会话中自动更新。这是因为.bash_history文件只在首次启动终端会话的时候才会被读取。要想强制重新读取.bash_history文件，更新内存中的终端会话历史记录，可以使用history -n命令。
> 可以设置保存在bash历史记录中的命令数量。为此，需要修改名为HISTSIZE的环境变量。

可以唤回历史记录中的任意命令。只需输入惊叹号和命令在历史记录中的编号即可。
如果需要清除命令历史，输入history -c即可。接下来再输入history -a，清除 .bash_history文件。
### alias
alias命令是另一个实用的shell内建命令。命令别名允许为常用命令及其参数创建另一个名称，从而将输入量减少到最低。
alias -p可以查看当前可用的别名
可以使用alias命令创建自己的别名：
```shell
$ alias li='ls -i'
$ bash
$ li
bash: li: command not found...
$ exit
exit
$ li
34665652 Desktop           1415018 NetworkManager.conf
 1414976 Doc.tar          50350618 OldDocuments
[...]
1415524 my_scrapt         1415017 test_two
 1415519 my_script        16789592 Videos
 1415015 my_scrypt
```
定义好别名之后，就可以随时在shell或者shell脚本中使用。要注意，因为命令别名属于内建命令，所以别名仅在其被定义的shell进程中才有效。通过export导出为全局变量可以在不同的子shell中生效。
> 如果需要，可以在命令行中入unalias alias-name删除指定的别名。记住，如果被删除的别名不是你设置的，那么等下次重新登录系统的时候，该别名就会再次出现。可以通过修改环境文件永久地删除某个别名。
























































