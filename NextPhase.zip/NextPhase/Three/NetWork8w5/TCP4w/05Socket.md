# Linux网络编程基础API
数据链路层、网络层、传输层协议是在内核中实现的，因此操作系统需要实现一组系统调用，使得应用程序能够访问这些协议提供的服务。实现这组系统调用的 API 是 socket。
由 socket 定义的这一组API提供如下两点功能：
- 将应用程序数 据从用户缓冲区中复制到TCP/UDP内核发送缓冲区，以交付内核来发送数据，或者是从内核TCP/UDP接收缓冲区中复制数据到用户缓冲区，以读取数据；
- 应用程序可以通过它们来修改内核中各层协议的某些头部信息或其他数据结构，从而精细地控制底层通信的行为。
## socket 地址 API
socket地址API。socket最开始的含义是一个IP地址和端口对（ip，port）。它唯一地表示了使用TCP通信的一端。

socket基础API。socket的主要API都定义在sys/socket.h头文件 中，包括创建socket、命名socket、监听socket、接受连接、发起连接、读写数据、获取地址信息、检测带外标记，以及读取和设置socket选项。

网络信息API。Linux提供了一套网络信息API，以实现主机名和 IP地址之间的转换，以及服务名称和端口号之间的转换。这些API都定义在netdb.h头文件中。

### 主机字节序和网络字节序

现代CPU的累加器一次都能装载（至少）4字节（这里考虑32位 机，下同），即一个整数。那么这4字节在内存中排列的顺序将影响它被累加器装载成的整数的值。这就是字节序问题。字节序分为大端字节序（big endian）和小端字节序（little endian）。

大端字节序是指一个整数的高位字节（23～31 bit）存储在内存的低地址处，低位字节（0 ～7 bit）存储在内存的高地址处。小端字节序则是指整数的高位字节存储在内存的高地址处，而低位字节则存储在内存的低地址处。

现代PC大多采用小端字节序，因此小端字节序又被称为主机字节序。 当格式化的数据（比如32 bit整型数和16 bit短整型数）在两台使用不同字节序的主机之间直接传递时，接收端必然错误地解释之。解决问题的方法是：发**送端总是把要发送的数据转化成大端字节序数据后再发送，而接收端知道对方传送过来的数据总是采用大端字节序，所以接收端可以根据自身采用的字节序决定是否对接收到的数据进行转换**（小端机转换，大端机不转换）。

因此**大端字节序也称为网络字节序，它给所有接收数据的主机提供了一个正确解释收到的格式化数据的保证。**

需要指出的是，即使是同一台机器上的两个进程（比如一个由C语言编写，另一个由JAVA编写）通信，也要考虑字节序的问题（JAVA虚拟机采用大端字节序）。

Linux提供了如下4个函数来完成主机字节序和网络字节序之间的转换：

```c
#include<netinet/in.h>
unsigned long int htonl(unsigned long int hostlong);
unsigned short int htons(unsigned short int hostshort);
unsigned long int ntohl(unsigned long int netlong);
unsigned short int ntohs(unsigned short int netshort);
```

它们的含义很明确，比如htonl表示“host to network long”，即将长整型（32 bit）的主机字节序数据转化为网络字节序数据。这4个函数中，长整型函数通常用来转换IP地址，短整型函数用来转换端口号 （当然不限于此。任何格式化的数据通过网络传输时，都应该使用这些函数来转换字节序）。

### 通用socket地址

socket网络编程接口中表示socket地址的是结构体sockaddr，其定义如下：

```c
#include<bits/socket.h>
struct sockaddr {
    sa_family_t sa_family;
    char sa_data[14];
}
```

sa_family成员是地址族类型（sa_family_t）的变量。地址族类型通常与协议族类型对应。常见的协议族（protocol family，也称domain）和对应的地址族如表5-1所示。

![image-20230325123619074](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325123619074.png)

sa_data成员用于存放socket地址值。但是，不同的协议族的地址值具有不同的含义和长度，如表5-2所示。

![image-20230325123705700](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325123705700.png)

由表5-2可见，14字节的sa_data根本无法完全容纳多数协议族的地 址值。因此，Linux定义了下面这个新的通用socket地址结构体：

```c
#include<bits/socket.h>
struct sockaddr_storage {
    sa_family_t sa_family;
    unsigned long int__ss_align; // 内存对齐
    char__ss_padding[128-sizeof(__ss_align)];
}
```

### 专用socket地址

两个通用socket地址结构体显然很不好用，比如设置与获取IP地址和端口号就需要执行烦琐的位操作。所以Linux为各个协议族提供了专门的socket地址结构体。

所有专用socket地址（以及sockaddr_storage）类型的变量在实际使用时都需要转化为通用socket地址类型sockaddr（强制转换即可），因为所有socket编程接口使用的地址参数的类型都是sockaddr。

UNIX本地域协议族使用如下专用socket地址结构体：

```c
#include<sys/un.h>
struct sockaddr_un {
    sa_family_t sin_family;/*地址族：AF_UNIX*/
    char sun_path[108];/*文件路径名*/
};
```

TCP/IP协议族有sockaddr_in和sockaddr_in6两个专用socket地址结构体，它们分别用于IPv4和IPv6：

```c
struct sockaddr_in {
    sa_family_t sin_family;/*地址族：AF_INET*/
    u_int16_t sin_port;/*端口号，要用网络字节序表示*/
    struct in_addr sin_addr;/*IPv4地址结构体，见下面*/
};

struct in_addr {
    u_int32_t s_addr;/*IPv4地址，要用网络字节序表示*/
};

struct sockaddr_in6 {
    sa_family_t sin6_family;/*地址族：AF_INET6*/
    u_int16_t sin6_port;/*端口号，要用网络字节序表示*/
    u_int32_t sin6_flowinfo;/*流信息，应设置为0*/
    struct in6_addr sin6_addr;/*IPv6地址结构体，见下面*/
    u_int32_t sin6_scope_id;/*scope ID，尚处于实验阶段*/
};

struct in6_addr {
    unsigned char sa_addr[16];/*IPv6地址，要用网络字节序表示*/
};
```

### IP地址转换函数

可用于用点分十进制字符串表示的IPv4地址和用网络字节序整数表示的IPv4地址之间的转换：

```c
#include<arpa/inet.h>

// inet_addr函数将点分十进制字符串的IPv4地址转化为用网络字节序整数表示的IPv4地址。它失败时返回INADDR_NONE。
in_addr_t inet_addr(const char*strptr);

// inet_aton函数完成和inet_addr同样的功能，但是将转化结果存储于参数inp指向的地址结构中。它成功时返回1，失败则返回0。
int inet_aton(const char*cp,struct in_addr*inp);

// inet_ntoa函数将用网络字节序整数表示的IPv4地址转化为点分十进制字符串的IPv4地址。
// 但需要注意的是，该函数内部用一个静态变量存储转化结果，函数的返回值指向该静态内存，因此inet_ntoa是不可重入的。
char*inet_ntoa(struct in_addr in);

// inet_pton函数将用字符串表示的IP地址src（点分十进制字符串的IPv4地址或十六进制字符串的IPv6地址）转换成用网络字节序整数表示的IP地址
// 并把转换结果存储于dst指向的内存中。成功时返回1，失败则返回0并设置errno[1]。 
// 其中，af 参数指定地址族，可以是AF_INET或者AF_INET6。
int inet_pton(int af,const char*src,void*dst);

// inet_ntop函数进行相反的转换，前三个参数的含义与inet_pton的参数相同，最后一个参数cnt指定目标存储单元的大小。
// 成功时返回目标存储单元的地址，失败则返回NULL并设置errno。
const char* inet_ntop(int af,const void*src,char*dst,socklen_t cnt);

// 下面的两个宏能指定这个大小（分别用于IPv4和IPv6）：
#include<netinet/in.h>
#define INET_ADDRSTRLEN 16
#define INET6_ADDRSTRLEN 46
```

## socket

socket是可读、可写、可控制、可关闭的文件描述符。下面的socket系统调用可创建一个socket：

```c
#include<sys/types.h>
#include<sys/socket.h>
int socket(int domain,int type,int protocol);
```

domain参数告诉系统使用哪个底层协议族。对TCP/IP协议族而言，该参数应该设置为PF_INET（Protocol Family of Internet，用于 IPv4）或PF_INET6（用于IPv6）；对于UNIX本地域协议族而言，该参数应该设置为PF_UNIX。

type参数指定服务类型。服务类型主要有SOCK_STREAM服务（流服务）和SOCK_UGRAM（数据报）服务。对TCP/IP协议族而言，其值取SOCK_STREAM表示传输层使用TCP协议，取SOCK_DGRAM表示传输层使用UDP协议。type参数可以接受上述服务类型与下面两个重要的标志相与的值：

- SOCK_NONBLOCK：将新创建的socket设为非阻塞的；
- SOCK_CLOEXEC：用fork调用创建子进程时在子进程中关闭该socket；

protocol参数是在前两个参数构成的协议集合下，再选择一个具体的协议。不过这个值通常都是唯一的（前两个参数已经完全决定了它的值）。几乎在所有情况下，都应该把它设置为0，表示使用默认协议。 

socket系统调用成功时返回一个socket文件描述符，失败则返回-1 并设置errno。

## bind

创建socket时，指定了地址族，但是并未指定使用该地址族中的哪个具体socket地址。将一个socket与socket地址绑定称为给socket命名。在服务器程序中，通常要命名socket，因为只有命名后客户端才能知道该如何连接它。客户端则通常不需要命名socket，而是采用匿名方式，即使用操作系统自动分配的socket地址。

命名socket的系统调用是bind，其定义如下：

```c
#include<sys/types.h>
#include<sys/socket.h>
int bind(int sockfd,const struct sockaddr*my_addr,socklen_t addrlen);
```

bind将my_addr所指的socket地址分配给未命名的sockfd文件描述符，addrlen参数指出该socket地址的长度。 

bind成功时返回0，失败则返回-1并设置errno。其中两种常见的errno是EACCES和EADDRINUSE，它们的含义分别是： 

- EACCES，被绑定的地址是受保护的地址，仅超级用户能够访问。比如普通用户将socket绑定到知名服务端口（端口号为0～1023）上时，bind将返回EACCES错误。
- EADDRINUSE，被绑定的地址正在使用中。比如将socket绑定到一个处于TIME_WAIT状态的socket地址。

## listen

socket被命名之后，服务器还不能马上接受客户连接，需要使用系统调用来创建一个监听队列以存放待处理的客户连接：

```c
#include<sys/socket.h>
int listen(int sockfd,int backlog); // backlog参数的典型值是5。完整连接（ESTABLISHED）最多有（backlog+1）个
```

sockfd参数指定被监听的socket。

backlog参数提示内核监听队列的最大长度。监听队列的长度如果超过backlog，服务器将不受理新的客户连接，客户端也将收到ECONNREFUSED错误信息。

listen成功时返回0，失败则返回-1并设置errno。 

> 在内核版本2.2 之前的Linux中，backlog参数是指所有处于半连接状态（SYN_RCVD）和完全连接状态（ESTABLISHED）的socket的上限。 
>
> 但内核版本2.2之后，只表示处于完全连接状态的socket的上限，处于半连接状态的socket的上限则由/proc/sys/net/ipv4/tcp_max_syn_backlog内核参数定义。

## accept

下面的系统调用服务器从listen监听队列中接受一个连接：

```c
#include<sys/types.h>
#include<sys/socket.h>
int accept(int sockfd, struct sockaddr* addr, socklen_t* addrlen);
```

sockfd参数是执行过listen系统调用的监听socket文件描述符。

> 把执行过listen调用、处于LISTEN状态的socket称为监听socket，而所有处于ESTABLISHED状态的socket则称为连接socket。

addr参数用来获取被接受连接的远端socket地址，该socket地址的长度由addrlen参数指出。accept成功时返回一个新的连接socket，该socket唯一地标识了被接受的这个连接，服务器可通过读写该socket来与被接受连接对应的客户端通信。accept失败时返回-1并设置errno。 

如果监听队列中处于ESTABLISHED状态的连接对应的客户端出现网络异常（比如掉线），或者提前退出，那么服务器对这个连接执行的accept调用是否成功？

accept只是从监听队列中取出连接，而不论连接处于何种状态（ESTABLISHED状态和CLOSE_WAIT状态），更不关心任何网络状况的变化。

> 发送连接后断开网络，服务端调用正常返回，客户端查询服务器accept返回的连接socket处于ESTABLISHED状态，说明不关心任何网络状况的变化
>
> 发送连接后断开客户端，服务端调用正常返回，客户端查询服务器accept返回的连接socket处于CLOSE_WAIT状态，说明不关心连接处于何种状态

## connect

服务器通过listen调用来被动接受连接，客户端需要通过如下系统调用来主动与服务器建立连接：

```c
#include<sys/types.h>
#include<sys/socket.h>
int connect(int sockfd, const struct sockaddr* serv_addr, socklen_t addrlen);
```

sockfd参数是socket系统调用返回的一个socket。serv_addr参数是服务器监听的socket地址，addrlen参数则指定这个地址的长度。 

connect成功时返回0。一旦成功建立连接，sockfd就唯一地标识了这个连接，客户端就可以通过读写sockfd来与服务器通信。connect失败则返回-1并设置errno。其中两种常见的errno是ECONNREFUSED和ETIMEDOUT：

- ECONNREFUSED，目标端口不存在，连接被拒绝；
- ETIMEDOUT，连接超时；

## close/shutdown

关闭一个连接实际上就是关闭该连接对应的socket，这可以通过如下关闭普通文件描述符的系统调用来完成：

```c
#include<unistd.h>
int close(int fd);
```

fd参数是待关闭的socket。不过，close系统调用并非总是立即关闭一个连接，而是将fd的引用计数减1。只有当fd的引用计数为0时，才真正关闭连接。

多进程程序中，一次fork系统调用默认将使父进程中打开的socket的引用计数加1，因此必须在父进程和子进程中都对该socket执行close调用才能将连接关闭。

如果无论如何都要立即终止连接（而不是将socket的引用计数减 1），可以使用如下的shutdown系统调用（相对于close来说，它是专门为网络编程设计的）：

```c
#include<sys/socket.h>
int shutdown(int sockfd, int howto);
```

sockfd参数是待关闭的socket。howto参数决定了shutdown的行为，它可取表5-3中的某个值。

由此可见，shutdown能够分别关闭socket上的读或写，或者都关闭。而close在关闭连接时只能将socket上的读和写同时关闭。shutdown成功时返回0，失败则返回-1并设置errno。

![image-20230325131246388](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325131246388.png)

## 数据读写

对文件的读写操作read和write同样适用于socket。但是socket编程接口提供了几个专门用于socket数据读写的系统调用，它们增加了对数据读写的控制。

### write/send

在网络编程中，`write`和`send`都是用于**将数据从内存中的缓冲区写入到文件描述符**所关联的套接字中的函数。

在Unix/Linux环境下，`write`是一个系统调用，由内核来完成实际的数据传输工作。

> 由内核来完成实际的数据传输工作指的是同步 IO 的数据就绪环节，将数据从内核拷贝到用户态依然是用户程序完成

它的原型定义如下：

```c
ssize_t write(int fd, const void *buf, size_t count);
```

write 函数将缓冲区 buf 中的数据写入到文件描述符 fd，count 为需要写入的字节数。返回值是实际写入的字节数，如果发送失败则返回-1，并设置errno为相应的错误码。

而`send`函数则是Socket API定义的函数，它的原型定义如下：

```c
ssize_t send(int sockfd, const void *buf, size_t len, int flags);
```

参数含义类似，多了 flags 参数作为传输控制标志，通常为0，常用的选项有MSG_DONTWAIT和MSG_NOSIGNAL，返回值也是实际写入的字节数，如果发送失败则返回-1，并设置errno为相应的错误码。

它们的语义略有区别，`write`是POSIX标准定义的函数，而`send`是Socket API定义的函数，`write`函数用于普通的文件写操作，其语义是将数据写入到文件中，而`send`函数则是用于套接字编程中的数据发送，其语义是将数据通过网络发送给另一台主机。不过，在实际使用中，两者的作用是相同的，可以互相替代。

### read/recv

```c++
ssize_t read(int fd, void *buf, size_t count);
```

read 函数从文件描述符 fd 读取数据到缓冲区 buf，count 为需要读取的字节数。若 count 为 0, 则 read() 不会有作用并返回 0。返回值为实际读取到的字节数，如果返回 0，表示已到达文件尾或是无可读取的数据，此外文件读写位置会随读取到的字节移动。

```c
ssize_t recv(int sockfd, void* buf, size_t len, int flags); // 同步 IO 接口
```

recv读取sockfd上的数据，buf和len参数分别指定读缓冲区的位置和大小，flags参数通常设置为0即可。

recv成功时返回实际读取到的数据的长度，它可能小于期望的长度len。因此可能要多次调用recv，才能读取到完整的数据。recv 返回值有以下情况：

- size == -1：发生内部错误
- size == -1 && errno == EAGAIN：非阻塞返回，没有接收
- size == 0：网络对端关闭连接
- size > 0：recv 接收到的网络字节数

flags参数为数据收发提供了额外的控制，它可以取表5-4所示选项中的一个或几个的逻辑或。

> 由于socket连接是全双工的，这里的“读端”是针对通信对方而言的。

![image-20230325131710431](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325131710431.png)

### recvfrom/sendto

socket编程接口中用于UDP数据报读写的系统调用是：

```c
#include<sys/types.h>
#include<sys/socket.h>
ssize_t recvfrom(int sockfd, void* buf, size_t len, int flags,
                 struct sockaddr* src_addr, socklen_t* addrlen);
ssize_t sendto(int sockfd, const void* buf, size_t len, int flags,
               const struct sockaddr* dest_addr, socklen_t addrlen);
```

recvfrom读取sockfd上的数据，buf和len参数分别指定读缓冲区的位置和大小。因为UDP通信没有连接的概念，所以每次读取数据都需要获取发送端的socket地址，即参数src_addr所指的内容，addrlen参数则指定该地址的长度。

sendto往sockfd上写入数据，buf和len参数分别指定写缓冲区的位置和大小。dest_addr参数指定接收端的socket地址，addrlen参数则指定该地址的长度。

这两个系统调用的flags参数以及返回值的含义均与send/recv系统调用的flags参数及返回值相同。

> recvfrom/sendto系统调用也可以用于面向连接（STREAM）的socket的数据读写，只需要把最后两个参数都设置为NULL以忽略发送端/接收端的socket地址（因为已经和对方建立了连接，所以已经知道其socket地址了）。

### recvmsg/sendmsg

socket编程接口还提供了一对通用的数据读写系统调用。它们不仅能用于TCP流数据，也能用于UDP数据报：

```c
#include<sys/socket.h>
ssize_t recvmsg(int sockfd, struct msghdr* msg, int flags);
ssize_t sendmsg(int sockfd, struct msghdr* msg, int flags);
```

sockfd参数指定被操作的目标socket。msg参数是msghdr结构体类型的指针，msghdr结构体的定义如下：

```c
struct msghdr {
    void* msg_name;/*socket地址*/
    socklen_t msg_namelen;/*socket地址的长度*/
    
    struct iovec* msg_iov;/*分散的内存块*/
    int msg_iovlen;/*分散内存块的数量*/
    
    void* msg_control;/*指向辅助数据的起始位置*/
    socklen_t msg_controllen;/*辅助数据的大小*/
    
    int msg_flags;/*复制函数中的flags参数，并在调用过程中更新*/
};
```

msg_name成员指向一个socket地址结构变量。它指定通信对方的 socket地址。对于面向连接的TCP协议，该成员没有意义，必须被设置为NULL。这是因为对数据流socket而言，对方的地址已经知道。

msg_namelen成员则指定了msg_name所指socket地址的长度。

msg_iov成员是iovec结构体类型的指针，iovec结构体的定义如下：

```c
struct iovec {
    void*iov_base;/*内存起始地址*/
    size_t iov_len;/*这块内存的长度*/
};
```

由上可见，iovec结构体封装了一块内存的起始位置和长度。msg_iovlen指定这样的iovec结构对象有多少个。

- 对于recvmsg而言，数据将被读取并存放在msg_iovlen块分散的内存中，这些内存的位置和长度则由msg_iov指向的数组指定，这称为分散读（scatter read）；
- 对于sendmsg而言，msg_iovlen块分散内存中的数据将被一并发送，这称为集中写（gather write）；

msg_control和msg_controllen成员用于辅助数据的传送，用于来实现在进程间传递文件描述符。 

msg_flags成员无须设定，它会复制recvmsg/sendmsg的flags参数的内容以影响数据读写过程。recvmsg还会在调用结束前，将某些更新后的标志设置到msg_flags中。recvmsg/sendmsg的flags参数以及返回值的含义均与send/recv的flags参数及返回值相同。

## sockatmark

在实际应用中，通常无法预期带外数据何时到来。好在Linux内核检测到TCP紧急标志时，将通知应用程序有带外数据需要接收。内核通知应用程序带外数据到达的两种常见方式是：I/O复用产生的异常事件和SIGURG信号。

但是，即使应用程序得到了有带外数据需要接收的通知，还需要知道带外数据在数据流中的具体位置，才能准确接收带外数据。这一点可通过如下系统调用实现：

```c
#include<sys/socket.h>
int sockatmark(int sockfd);
```

sockatmark判断sockfd是否处于带外标记，即下一个被读取到的数据是否是带外数据。如果是，sockatmark返回1，此时就可以利用带MSG_OOB标志的recv调用来接收带外数据。如果不是，则sockatmark返回0。

## getsockname/getpeername

在某些情况下，想知道一个连接socket的本端socket地址，以及远端的socket地址。下面这两个地址信息函数正是用于解决这个问题：

```c
#include<sys/socket.h>
int getsockname(int sockfd, struct sockaddr* address, socklen_t* address_len);
int getpeername(int sockfd, struct sockaddr* address, socklen_t* address_len);
```

getsockname获取sockfd对应的本端socket地址，并将其存储于address参数指定的内存中，该socket地址的长度则存储于address_len参数指向的变量中。如果实际socket地址的长度大于address所指内存区的大小，那么该socket地址将被截断。成功时返回0，失败返回-1并设置errno。

getpeername获取sockfd对应的远端socket地址，其参数及返回值的含义与getsockname的参数及返回值相同。

## socket选项

如果说fcntl系统调用是控制文件描述符属性的通用POSIX方法，那么下面两个系统调用则是专门用来**读取和设置socket文件描述符属性的方法**：

```c
#include<sys/socket.h>
int getsockopt(int sockfd, int level, int option_name, void* option_value, socklen_t* restrict option_len);
int setsockopt(int sockfd, int level, int option_name, const void* option_value, socklen_t option_len);
```

sockfd参数指定被操作的目标socket。

level参数指定要操作哪个协议的选项（即属性），比如IPv4、IPv6、TCP等。

option_name参数则指定选项的名字。

option_value和option_len参数分别是被操作选项的值和长度。不同的选项具有不同类型的值，如表5-5中“数据类型”一列所示。

getsockopt和setsockopt这两个函数成功时返回0，失败时返回-1并设置errno。



对服务器而言，有部分socket选项只能在调用listen系统调用前针对监听socket设置才有效。这是因为连接socket只能由accept调用返回，而accept从listen监听队列中接受的连接至少已经完成了TCP三次握手的前两个步骤（因为listen监听队列中的连接至少已进入SYN_RCVD状态，这说明服务器已经往被接受连接上发送出了TCP同步报文段。但有的socket选项却应该在TCP同步报文段中设置，比如TCP最大报文段选项（该选项只能由同步报文段来发送）。

> 确切地说，socket在执行listen调用前是不能称为监听socket的，此处 是指将执行listen调用的socket。

对这种情况，Linux给开发人员提供的解决方案是：**对监听socket设置这些socket选项，那么accept返回的连接socket将自动继承这些选项。**

这些socket选项包括：SO_DEBUG、SO_DONTROUTE、SO_KEEPALIVE、SO_LINGER、SO_OOBINLINE、SO_RCVBUF、SO_RCVLOWAT、SO_SNDBUF、 SO_SNDLOWAT、TCP_MAXSEG和TCP_NODELAY。

而对客户端而言，这些socket选项则应该在调用connect函数之前设置，因为connect调用成功返回之后，TCP三次握手已完成。

![image-20230325132613729](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325132613729.png)

### SO_REUSEADDR

有时候希望避免TIME_WAIT状态，因为当程序退出后，希望能够立即重启它。但由于处在TIME_WAIT状态的连接还占用着端口，程序将无法启动（直到2MSL超时时间结束）。不过，可以通过socket选项SO_REUSEADDR来强制进程立即使用处于TIME_WAIT状态的连接占用的端口（socket地址）：

```c
int sock=socket(PF_INET, SOCK_STREAM, 0);
assert(sock>=0);
int reuse=1;
setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, ＆reuse, sizeof(reuse));

struct sockaddr_in address;
// bzero() 能够将内存块（字符串）的前n个字节清零，在"string.h"头文件中
bzero(&address, sizeof(address));

address.sin_family=AF_INET;
inet_pton(AF_INET, ip, &address.sin_addr);
address.sin_port=htons(port);
int ret=bind(sock, (struct sockaddr*)&address, sizeof(address));
```

经过setsockopt的设置之后，即使sock处于TIME_WAIT状态，与之绑定的socket地址也可以立即被重用。

此外，也可以通过修改内核参数/proc/sys/net/ipv4/tcp_tw_recycle来快速回收被关闭的socket，从而使得TCP连接根本就不进入TIME_WAIT状态，进而允许应用程序立即重用本地的socket地址。

### SO_RCVBUF和SO_SNDBUF

SO_RCVBUF和SO_SNDBUF选项分别表示TCP接收缓冲区和发送缓冲区的大小。不过，当用setsockopt来设置TCP的接收缓冲区和发送缓冲区的大小时，系统都会将其值加倍，并且不得小于某个最小值。

TCP接收缓冲区的最小值是256字节，而发送缓冲区的最小值是 2048字节（不同的系统可能有不同的默认最小值）。系统这样做的目的，主要是确保一个TCP连接拥有足够的空闲缓冲区来处理拥塞。此外，可以直接修改内核参数/proc/sys/net/ipv4/tcp_rmem和/proc/sys/net/ipv4/tcp_wmem来强制TCP接收缓冲区和发送缓冲区的大小没有最小值限制。

### SO_RCVLOWAT和SO_SNDLOWAT

SO_RCVLOWAT和SO_SNDLOWAT选项分别表示TCP接收缓冲区和发送缓冲区的低水位标记。它们一般被I/O复用系统调用用来判断socket是否可读或可写。

- 当TCP接收缓冲区中可读数据的总数大于其低水位标记时，I/O复用系统调用将通知应用程序可以从对应的socket上读取数据；
- 当TCP发送缓冲区中的空闲空间（可以写入数据的空间）大于其低水位标记时，I/O复用系统调用将通知应用程序可以往对应的socke上写入数据。

默认情况下，TCP接收缓冲区的低水位标记和TCP发送缓冲区的低水位标记均为1字节。

### SO_LINGER选项

SO_LINGER选项用于控制close系统调用在关闭TCP连接时的行为。默认情况下，当使用close系统调用来关闭一个socket时，close将立即返回，TCP模块负责把该socket对应的TCP发送缓冲区中残留的数据发送给对方。

如表5-5所示，设置（获取）SO_LINGER选项的值时，需要给 setsockopt（getsockopt）系统调用传递一个linger类型的结构体，其定义如下：

```c
#include<sys/socket.h>
struct linger {
    int l_onoff;/*开启（非0）还是关闭（0）该选项*/
    int l_linger;/*滞留时间*/
};
```

根据linger结构体中两个成员变量的不同值，close系统调用可能产生如下3种行为之一： 

l_onoff等于0。此时SO_LINGER选项不起作用，close用默认行为来关闭socket。

l_onoff不为0，l_linger等于0。此时close系统调用立即返回，TCP 模块将丢弃被关闭的socket对应的TCP发送缓冲区中残留的数据，同时给对方发送一个复位报文段。因此，这种情况给服务器提供了异常终止一个连接的方法。 

l_onoff不为0，l_linger大于0。此时close的行为取决于两个条件：一是被关闭的socket对应的TCP发送缓冲区中是否还有残留的数据；二是该socket是阻塞的，还是非阻塞的。

- 对于阻塞的socket，close 将等待一段长为l_linger的时间，直到TCP模块发送完所有残留数据并得到对方的确认。如果这段时间内TCP模块没有发送完残留数据并得到对方的确认，那么close系统调用将返回-1并设置errno为EWOULDBLOCK。
- 如果socket是非阻塞的，close将立即返回，此时需要根据其返回值和errno来判断残留数据是否已经发送完毕。

## 网络信息API

socket地址的两个要素，即IP地址和端口号，都是用数值表示的。这不便于记忆，也不便于扩展（比如从IPv4转移到IPv6）。因此需要网络信息API来进行处理:

```shell
telnet 127.0.0.1 80 
telnet localhost www
```

上面的例子中，telnet客户端程序是通过调用某些网络信息API来实现主机名到IP地址的转换，以及服务名称到端口号的转换的。

### gethostbyname和gethostbyaddr

gethostbyname函数根据主机名称获取主机的完整信息，gethostbyaddr函数根据IP地址获取主机的完整信息。gethostbyname函数通常先在本地的/etc/hosts配置文件中查找主机，如果没有找到，再去访问DNS服务器。这两个函数的定义如下：

```c
#include<netdb.h>
struct hostent* gethostbyname(const char* name);
struct hostent* gethostbyaddr(const void* addr, size_t len, int type);
```

name参数指定目标主机的主机名，addr参数指定目标主机的IP地址，len参数指定addr所指IP地址的长度，type参数指定addr所指IP地址的类型，其合法取值包括AF_INET（用于IPv4地址）和AF_INET6（用于IPv6地址）。

这两个函数返回的都是hostent结构体类型的指针，hostent结构体的定义如下：

```c
#include<netdb.h>
struct hostent {
    char* h_name;/*主机名*/
    char** h_aliases;/*主机别名列表，可能有多个*/
    int h_addrtype;/*地址类型（地址族）*/
    int h_length;/*地址长度*/
    char** h_addr_list/*按网络字节序列出的主机IP地址列表*/
};
```

### getservbyname和getservbyport

getservbyname函数根据名称获取某个服务的完整信息，getservbyport函数根据端口号获取某个服务的完整信息。它们实际上都是通过读取/etc/services文件来获取服务的信息的。这两个函数的定义如下：

```c
#include<netdb.h>
struct servent* getservbyname(const char* name, const char* proto);
struct servent* getservbyport(int port, const char* proto);
```

name参数指定目标服务的名字，port参数指定目标服务对应的端口号。proto参数指定服务类型，给它传递“tcp”表示获取流服务，给它传递“udp”表示获取数据报服务，给它传递NULL则表示获取所有类型的服务。

这两个函数返回的都是servent结构体类型的指针，结构体servent的定义如下：

```c
#include<netdb.h>
struct servent {
    char*s_name;/*服务名称*/
    char**s_aliases;/*服务的别名列表，可能有多个*/
    int s_port;/*端口号*/
    char*s_proto;/*服务类型,通常是tcp或者udp*/
};
```

> 上面讨论的4个函数都是不可重入的，即非线程安全的。不过netdb.h头文件给出了它们的可重入版本。正如Linux下所有其他函数的可重入版本的命名规则那样，这些函数的函数名是在原函数名尾部加上_r（re-entrant）。

### getaddrinfo

getaddrinfo函数既能通过主机名获得IP地址（内部使用的是gethostbyname函数），也能通过服务名获得端口号（内部使用的是getservbyname函数）。它是否可重入取决于其内部调用的gethostbyname和getservbyname函数是否是它们的可重入版本。该函数的定义如下：

```c
#include<netdb.h>
int getaddrinfo(const char* hostname, const char* service, const struct addrinfo* hints, struct addrinfo** result);
```

hostname参数可以接收主机名，也可以接收字符串表示的IP地址。同样，service参数可以接收服务名，也可以接收字符串表示的十进制端口号。hints参数是应用程序给getaddrinfo的一个提示，以对getaddrinfo的输出进行更精确的控制。hints参数可以被设置为NULL，表示允许getaddrinfo反馈任何可用的结果。result参数指向一个链表，该链表用于存储getaddrinfo反馈的结果。

getaddrinfo反馈的每一条结果都是addrinfo结构体类型的对象，结构体addrinfo的定义如下：

```c
struct addrinfo {
    int ai_flags;/*见后文*/
    int ai_family;/*地址族*/
    int ai_socktype;/*服务类型，SOCK_STREAM或SOCK_DGRAM*/
    int ai_protocol;/*见后文*/
    socklen_t ai_addrlen;/*socket地址ai_addr的长度*/
    char* ai_canonname;/*主机的别名*/
    struct sockaddr* ai_addr;/*指向socket地址*/
    struct addrinfo* ai_next;/*指向下一个sockinfo结构的对象*/
};
```

该结构体中，ai_protocol成员是指具体的网络协议，其含义和socket系统调用的第三个参数相同，它通常被设置为0。ai_flags成员可以取表5-6中的标志的按位或。

![image-20230325154537582](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325154537582.png)

当使用hints参数的时候，可以设置其ai_flags，ai_family， ai_socktype和ai_protocol四个字段，其他字段则必须被设置为NULL。

例如，代码清单5-13利用了hints参数获取主机ernest-laptop上 的“daytime”流服务信息。

```c
struct addrinfo hints
struct addrinfo* res;
bzero(&hints,sizeof(hints));
hints.ai_socktype=SOCK_STREAM;
getaddrinfo("ernest-laptop", "daytime", &hints, &res);
```

getaddrinfo将隐式地分配堆内存 （可以通过valgrind等工具查看），因为res指针原本是没有指向一块合法内存的，所以，getaddrinfo调用结束后，必须使用如下配对函数来释放这块内存：

```c
#include<netdb.h>
void freeaddrinfo(struct addrinfo*res);
```

### getnameinfo

getnameinfo函数能通过socket地址同时获得以字符串表示的主机名（内部使用的是gethostbyaddr函数）和服务名（内部使用的是 getservbyport函数）。它是否可重入取决于其内部调用的gethostbyaddr 和getservbyport函数是否是它们的可重入版本。该函数的定义如下：

```c
#include<netdb.h>
int getnameinfo(const struct sockaddr* sockaddr, socklen_t addrlen, char* host,socklen_t hostlen,
                char* serv, socklen_t servlen, int flags);
```

getnameinfo将返回的主机名存储在host参数指向的缓存中，将服务名存储在serv参数指向的缓存中，hostlen和servlen参数分别指定这两块缓存的长度。flags参数控制getnameinfo的行为，它可以接收表5-7中的选项。

![image-20230325154635935](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325154635935.png)

getaddrinfo和getnameinfo函数成功时返回0，失败则返回错误码，可能的错误码如表5-8所示。

![image-20230325154642965](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230325154642965.png)

Linux下strerror函数能将数值错误码errno转换成易读的字符串形式。同样，下面的函数可将表5-8中的错误码转换成其字符串形式：

```c
#include<netdb.h>
const char*gai_strerror(int error);
```



# Socket 编程
## TCP/UDP
`TCP` 网络编程如下：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240312101627.png)
- 服务端和客户端初始化 `socket`，得到文件描述符；
- 服务端调用 `bind`，将 socket 绑定在指定的 IP 地址和端口;
- 服务端调用 `listen`，进行监听；
- 服务端调用 `accept`，等待客户端连接；
- 客户端调用 `connect`，向服务器端的地址和端口发起连接请求；
- 服务端 `accept` 返回用于传输的 `socket` 的文件描述符；
- 客户端调用 `write` 写入数据；服务端调用 `read` 读取数据；
- 客户端断开连接时，会调用 `close`，那么服务端 `read` 读取数据的时候，就会读取到了 `EOF`，待处理完数据后，服务端调用 `close`，表示连接关闭。
这里需要注意的是，服务端调用 `accept` 时，连接成功了会返回一个已完成连接的 socket，后续用来传输数据。
所以，监听的 socket 和真正用来传送数据的 socket，是「两个」 socket，一个叫作**监听 socket**，一个叫作**已完成连接 socket**。
成功连接建立之后，双方开始通过 read 和 write 函数来读写数据，就像往一个文件流里面写东西一样。
`UDP` 网络编程如下：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240312110209.png)
监听这个动作是在 `TCP` 服务端网络编程中才具有的，而 `UDP` 服务端网络编程中没有监听这个动作，只有执行 `bind()` 系统调用来绑定端口的动作。`TCP` 和 `UDP` 服务端网络相似的一个地方，就是会调用 `bind` 绑定端口。
## listen 时候参数 backlog 的意义？
`Linux` 内核中会维护两个队列：
- 半连接队列（SYN 队列）：接收到一个 SYN 建立连接请求，处于 SYN_RCVD 状态；
- 全连接队列（Accpet 队列）：已完成 TCP 三次握手过程，处于 ESTABLISHED 状态；
![ SYN 队列 与 Accpet 队列 ](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9jZG4uanNkZWxpdnIubmV0L2doL3hpYW9saW5jb2Rlci9JbWFnZUhvc3QyLyVFOCVBRSVBMSVFNyVBRSU5NyVFNiU5QyVCQSVFNyVCRCU5MSVFNyVCQiU5Qy9UQ1AtJUU0JUI4JTg5JUU2JUFDJUExJUU2JThGJUExJUU2JTg5JThCJUU1JTkyJThDJUU1JTlCJTlCJUU2JUFDJUExJUU2JThDJUE1JUU2JTg5JThCLzM1LmpwZw?x-oss-process=image/format,png)
```c
int listen (int socketfd, int backlog)
```
- 参数一 socketfd 为 socketfd 文件描述符
- 参数二 backlog，这参数在历史版本有一定的变化
在早期 Linux 内核 backlog 是 SYN 队列大小，也就是未完成的队列大小。
在 Linux 内核 2.2 之后，backlog 变成 accept 队列，也就是已完成连接建立的队列长度，**所以现在通常认为 backlog 是 accept 队列。**
**但是上限值是内核参数 somaxconn 的大小，也就说 accpet 队列长度 = min(backlog, somaxconn)。**
## accept 发生在三次握手的哪一步？
我们先看看客户端连接服务端时，发送了什么？
![socket 三次握手](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost4/网络/socket三次握手.drawio.png)
- 客户端的协议栈向服务器端发送了 SYN 包，并告诉服务器端当前发送序列号 client_isn，客户端进入 SYN_SENT 状态；
- 服务器端的协议栈收到这个包之后，和客户端进行 ACK 应答，应答的值为 client_isn+1，表示对 SYN 包 client_isn 的确认，同时服务器也发送一个 SYN 包，告诉客户端当前我的发送序列号为 server_isn，服务器端进入 SYN_RCVD 状态；
- 客户端协议栈收到 ACK 之后，使得应用程序从 `connect` 调用返回，表示客户端到服务器端的单向连接建立成功，客户端的状态为 ESTABLISHED，同时客户端协议栈也会对服务器端的 SYN 包进行应答，应答数据为 server_isn+1；
- ACK 应答包到达服务器端后，服务器端的 TCP 连接进入 ESTABLISHED 状态，同时服务器端协议栈使得 `accept` 阻塞调用返回，这个时候服务器端到客户端的单向连接也建立成功。至此，客户端与服务端两个方向的连接都建立成功。
从上面的描述过程，我们可以得知**客户端 connect 成功返回是在第二次握手，服务端 accept 成功返回是在三次握手成功之后。**
## 客户端调用 close，连接是断开的流程是什么？
我们看看客户端主动调用了 `close`，会发生什么？
![客户端调用 close 过程](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9jZG4uanNkZWxpdnIubmV0L2doL3hpYW9saW5jb2Rlci9JbWFnZUhvc3QyLyVFOCVBRSVBMSVFNyVBRSU5NyVFNiU5QyVCQSVFNyVCRCU5MSVFNyVCQiU5Qy9UQ1AtJUU0JUI4JTg5JUU2JUFDJUExJUU2JThGJUExJUU2JTg5JThCJUU1JTkyJThDJUU1JTlCJTlCJUU2JUFDJUExJUU2JThDJUE1JUU2JTg5JThCLzM3LmpwZw?x-oss-process=image/format,png)
- 客户端调用 `close`，表明客户端没有数据需要发送了，则此时会向服务端发送 FIN 报文，进入 FIN_WAIT_1 状态；
- 服务端接收到了 FIN 报文，TCP 协议栈会为 FIN 包插入一个文件结束符 `EOF` 到接收缓冲区中，应用程序可以通过 `read` 调用来感知这个 FIN 包。这个 `EOF` 会被**放在已排队等候的其他已接收的数据之后**，这就意味着服务端需要处理这种异常情况，因为 EOF 表示在该连接上再无额外数据到达。此时，服务端进入 CLOSE_WAIT 状态；
- 接着，当处理完数据后，自然就会读到 `EOF`，于是也调用 `close` 关闭它的套接字，这会使得服务端发出一个 FIN 包，之后处于 LAST_ACK 状态；
- 客户端接收到服务端的 FIN 包，并发送 ACK 确认包给服务端，此时客户端将进入 TIME_WAIT 状态；
- 服务端收到 ACK 确认包后，就进入了最后的 CLOSE 状态；
- 客户端经过 `2MSL` 时间之后，也进入 CLOSE 状态；
## 4.19 服务端没有 listen，客户端发起连接建立，会发生什么？

![图片](https://img-blog.csdnimg.cn/img_convert/5f5b9c96c86580e3f14978d5c10c7721.jpeg)

这位读者的角度是以为服务端没有调用 listen，客户端会 ping 不通服务器，很明显，搞错了。

ping 使用的协议是 ICMP，属于网络层的事情，而面试官问的是传输层的问题。

针对这个问题，服务端如果只 bind 了 IP 地址和端口，而没有调用 listen 的话，然后客户端对服务端发起了 TCP 连接建立，此时那么会发生什么呢？

这个问题，自己做个实验就知道了。

我用下面这个程序作为例子，绑定了 IP 地址 + 端口，而没有调用 listen。

```c
/*******服务器程序  TCPServer.c ************/
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>

int main(int argc, char *argv[])
{
    int sockfd, ret;
    struct sockaddr_in server_addr;

    /* 服务器端创建 tcp socket 描述符 */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0)
    {
        fprintf(stderr, "Socket error:%s\n\a", strerror(errno));
        exit(1);
    }

    /* 服务器端填充 sockaddr 结构 */
    bzero(&server_addr, sizeof(struct sockaddr_in));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(8888);
  
  /* 绑定 ip + 端口 */
    ret = bind(sockfd, (struct sockaddr *)(&server_addr), sizeof(struct sockaddr));
    if(ret < 0)
    {
        fprintf(stderr, "Bind error:%s\n\a", strerror(errno));
        exit(1);
    }
  
  //没有调用 listen
    
    sleep(1000);
    close(sockfd);
    return 0;
}
```

然后，我用浏览器访问这个地址：http://121.43.173.240:8888/

![图片](https://img-blog.csdnimg.cn/img_convert/5bdb5443db5b97ff724ab94e014af6a5.png)

报错连接服务器失败。

同时，我也用抓包工具，抓了这个过程。

![图片](https://img-blog.csdnimg.cn/img_convert/a77921ffafbbff86d07983ca0db3e6e0.png)

可以看到，客户端对服务端发起 SYN 报文后，服务端回了 RST 报文。

所以，这个问题就有了答案，**服务端如果只 bind 了 IP 地址和端口，而没有调用 listen 的话，然后客户端对服务端发起了连接建立，服务端会回 RST 报文。**


接下来，带大家源码分析一下。

Linux 内核处理收到 TCP 报文的入口函数是  tcp_v4_rcv，在收到 TCP 报文后，会调用 __inet_lookup_skb 函数找到 TCP 报文所属 socket 。

```
int tcp_v4_rcv(struct sk_buff *skb)
{
 ...
  
 sk = __inet_lookup_skb(&tcp_hashinfo, skb, th->source, th->dest);
 if (!sk)
  goto no_tcp_socket;
 ...
}
```

__inet_lookup_skb 函数首先查找连接建立状态的socket（__inet_lookup_established），在没有命中的情况下，才会查找监听套接口（__inet_lookup_listener）。

![图片](https://img-blog.csdnimg.cn/img_convert/88416aa95d255495e07fb3a002b2167b.png)

查找监听套接口（__inet_lookup_listener）这个函数的实现是，根据目的地址和目的端口算出一个哈希值，然后在哈希表找到对应监听该端口的 socket。

本次的案例中，服务端是没有调用 listen 函数的，所以自然也是找不到监听该端口的 socket。

所以，__inet_lookup_skb 函数最终找不到对应的 socket，于是跳转到no_tcp_socket。

![图片](https://img-blog.csdnimg.cn/img_convert/54ee363e149ee3dfba30efb1a542ef5c.png)

在这个错误处理中，只要收到的报文（skb）的「校验和」没问题的话，内核就会调用 tcp_v4_send_reset 发送 RST 中止这个连接。

至此，整个源码流程就解析完。

其实很多网络的问题，大家都可以自己做实验来找到答案的。

### 没有 listen，能建立 TCP 连接吗？

标题的问题在前面已经解答，**现在我们看另外一个相似的问题**。

之前看群消息，看到有读者面试腾讯的时候，被问到这么一个问题。

> 不使用 listen ，可以建立 TCP 连接吗？

答案，**是可以的，客户端是可以自己连自己的形成连接（TCP自连接），也可以两个客户端同时向对方发出请求建立连接（TCP同时打开），这两个情况都有个共同点，就是没有服务端参与，也就是没有listen，就能建立连接**。

> 那没有listen，为什么还能建立连接？

我们知道执行 listen 方法时，会创建半连接队列和全连接队列。

三次握手的过程中会在这两个队列中暂存连接信息。

所以形成连接，前提是你得有个地方存放着，方便握手的时候能根据 IP + 端口等信息找到对应的 socket。

> 那么客户端会有半连接队列吗？

显然没有，因为客户端没有执行listen，因为半连接队列和全连接队列都是在执行 listen 方法时，内核自动创建的。

但内核还有个全局 hash 表，可以用于存放 sock 连接的信息。

这个全局 hash 表其实还细分为 ehash，bhash和listen_hash等，但因为过于细节，大家理解成有一个全局 hash 就够了，

**在 TCP 自连接的情况中，客户端在 connect 方法时，最后会将自己的连接信息放入到这个全局 hash 表中，然后将信息发出，消息在经过回环地址重新回到 TCP 传输层的时候，就会根据 IP + 端口信息，再一次从这个全局 hash 中取出信息。于是握手包一来一回，最后成功建立连接**。

TCP 同时打开的情况也类似，只不过从一个客户端变成了两个客户端而已。

> 做个实验

客户端自连接的代码，TCP socket 可以 connect 它本身 bind 的地址和端口：


```c
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#define LOCAL_IP_ADDR		(0x7F000001) // IP 127.0.0.1
#define LOCAL_TCP_PORT		(34567) // 端口

int main(void)
{
	struct sockaddr_in local, peer;
	int ret;
	char buf[128];
	int sock = socket(AF_INET, SOCK_STREAM, 0);

	memset(&local, 0, sizeof(local));
	memset(&peer, 0, sizeof(peer));

	local.sin_family = AF_INET;
	local.sin_port = htons(LOCAL_TCP_PORT);
	local.sin_addr.s_addr = htonl(LOCAL_IP_ADDR);

	peer = local;	

    int flag = 1;
    ret = setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag));
    if (ret == -1) {
        printf("Fail to setsocket SO_REUSEADDR: %s\n", strerror(errno));
        exit(1);
    }

	ret = bind(sock, (const struct sockaddr *)&local, sizeof(local));
	if (ret) {
		printf("Fail to bind: %s\n", strerror(errno));
		exit(1);
	}
	
	ret = connect(sock, (const struct sockaddr *)&peer, sizeof(peer));
	if (ret) {
		printf("Fail to connect myself: %s\n", strerror(errno));
		exit(1);
	}
	
	printf("Connect to myself successfully\n");

    //发送数据
	strcpy(buf, "Hello, myself~");
	send(sock, buf, strlen(buf), 0);

	memset(buf, 0, sizeof(buf));
	
	//接收数据
	recv(sock, buf, sizeof(buf), 0);
	printf("Recv the msg: %s\n", buf);

    sleep(1000);
	close(sock);
	return 0;
}
```

编译运行：

![](https://img-blog.csdnimg.cn/9db974179b9e4a279f7edb0649752c27.png)


通过 netstat 命令命令客户端自连接的 TCP 连接：

![在这里插入图片描述](https://img-blog.csdnimg.cn/e2b116e843c14e468eadf9d30e1b877c.png)

从截图中，可以看到 TCP socket 成功的“连接”了自己，并发送和接收了数据包，netstat 的输出更证明了 TCP 的两端地址和端口是完全相同的。


## 4.20 没有 accept，能建立 TCP 连接吗？
![握手建立连接流程](https://img-blog.csdnimg.cn/img_convert/e0d405a55626eb8e4a52553a54680618.gif)

对应的是下面一段简化过的服务端伪代码。

```c
int main()
{
    /*Step 1: 创建服务器端监听socket描述符listen_fd*/    
    listen_fd = socket(AF_INET, SOCK_STREAM, 0);

    /*Step 2: bind绑定服务器端的IP和端口，所有客户端都向这个IP和端口发送和请求数据*/    
    bind(listen_fd, xxx);

    /*Step 3: 服务端开启监听*/    
    listen(listen_fd, 128);

    /*Step 4: 服务器等待客户端的链接，返回值cfd为客户端的socket描述符*/    
    cfd = accept(listen_fd, xxx);

      /*Step 5: 读取客户端发来的数据*/
      n = read(cfd, buf, sizeof(buf));
}
```

估计大家也是老熟悉这段伪代码了。

需要注意的是，在执行`listen()`方法之后还会执行一个`accept()`方法。

**一般情况**下，如果启动服务器，会发现最后程序会**阻塞在**`accept()`里。

此时服务端就算ok了，就等客户端了。

那么，再看下简化过的客户端伪代码。

```c
int main()
{
    /*Step 1: 创建客户端端socket描述符cfd*/    
    cfd = socket(AF_INET, SOCK_STREAM, 0);

    /*Step 2: connect方法,对服务器端的IP和端口号发起连接*/    
    ret = connect(cfd, xxxx);

    /*Step 4: 向服务器端写数据*/
    write(cfd, buf, strlen(buf));
}
```

客户端比较简单，创建好`socket`之后，直接就发起`connect`方法。

此时回到服务端，会发现**之前一直阻塞的accept方法，返回结果了**。

这就算两端成功建立好了一条连接。之后就可以愉快的进行读写操作了。

那么，我们今天的问题是，**如果没有这个accept方法，TCP连接还能建立起来吗？**

其实只要在执行`accept()` 之前执行一个 `sleep(20)`，然后立刻执行客户端相关的方法，同时抓个包，就能得出结论。

![不执行accept时抓包结果](https://img-blog.csdnimg.cn/img_convert/2cfc1d028f3e37f10c2f81375ddb998a.png)

从抓包结果看来，**就算不执行accept()方法，三次握手照常进行，并顺利建立连接。**

更骚气的是，**在服务端执行accept()前，如果客户端发送消息给服务端，服务端是能够正常回复ack确认包的。**

并且，`sleep(20)`结束后，服务端正常执行`accept()`，客户端前面发送的消息，还是能正常收到的。

通过这个现象，我们可以多想想为什么。顺便好好了解下三次握手的细节。

### 三次握手的细节分析

我们先看面试八股文的老股，三次握手。

![TCP三次握手](https://img-blog.csdnimg.cn/img_convert/8d55a06f2efa946921ff61a008c76b00.png)

服务端代码，对socket执行bind方法可以绑定监听端口，然后执行`listen方法`后，就会进入监听（`LISTEN`）状态。内核会为每一个处于`LISTEN`状态的`socket` 分配两个队列，分别叫**半连接队列和全连接队列**。

![每个listen Socket都有一个全连接和半连接队列](https://img-blog.csdnimg.cn/img_convert/d7e2d60b28b0f9b460aafbf1bd6e7892.png)

#### 半连接队列、全连接队列是什么

![半连接队列和全连接队列](https://img-blog.csdnimg.cn/img_convert/36242c85809865fcd2da48594de15ebb.png)

- **半连接队列（SYN队列）**，服务端收到**第一次握手**后，会将`sock`加入到这个队列中，队列内的`sock`都处于`SYN_RECV` 状态。
- **全连接队列（ACCEPT队列）**，在服务端收到**第三次握手**后，会将半连接队列的`sock`取出，放到全连接队列中。队列里的`sock`都处于 `ESTABLISHED`状态。这里面的连接，就**等着服务端执行accept()后被取出了。**

看到这里，文章开头的问题就有了答案，建立连接的过程中根本不需要`accept()`参与， **执行accept()只是为了从全连接队列里取出一条连接。**

我们把话题再重新回到这两个队列上。

虽然都叫**队列**，但其实**全连接队列（icsk_accept_queue）是个链表**，而**半连接队列（syn_table）是个哈希表**。

![半连接全连接队列的内部结构](https://img-blog.csdnimg.cn/img_convert/6f964fb09d6971dab1762a45dfa30b3b.png)

#### 为什么半连接队列要设计成哈希表

先对比下**全连接里队列**，他本质是个链表，因为也是线性结构，说它是个队列也没毛病。它里面放的都是已经建立完成的连接，这些连接正等待被取走。而服务端取走连接的过程中，并不关心具体是哪个连接，只要是个连接就行，所以直接从队列头取就行了。这个过程算法复杂度为`O(1)`。

而**半连接队列**却不太一样，因为队列里的都是不完整的连接，嗷嗷等待着第三次握手的到来。那么现在有一个第三次握手来了，则需要从队列里把相应IP端口的连接取出，**如果半连接队列还是个链表，那我们就需要依次遍历，才能拿到我们想要的那个连接，算法复杂度就是O(n)。**

而如果将半连接队列设计成哈希表，那么查找半连接的算法复杂度就回到`O(1)`了。

因此出于效率考虑，全连接队列被设计成链表，而半连接队列被设计为哈希表。

### 怎么观察两个队列的大小

#### 查看全连接队列

```shell
# ss -lnt
State      Recv-Q Send-Q     Local Address:Port           Peer Address:Port
LISTEN     0      128        127.0.0.1:46269              *:*              
```

通过`ss -lnt`命令，可以看到全连接队列的大小，其中`Send-Q`是指全连接队列的最大值，可以看到我这上面的最大值是`128`；`Recv-Q`是指当前的全连接队列的使用值，我这边用了`0`个，也就是全连接队列里为空，连接都被取出来了。

当上面`Send-Q`和`Recv-Q`数值很接近的时候，那么全连接队列可能已经满了。可以通过下面的命令查看是否发生过队列**溢出**。

```shell
# netstat -s | grep overflowed
    4343 times the listen queue of a socket overflowed
```

上面说明发生过`4343次`全连接队列溢出的情况。这个查看到的是**历史发生过的次数**。

如果配合使用`watch -d` 命令，可以自动每`2s`间隔执行相同命令，还能高亮显示变化的数字部分，如果溢出的数字不断变多，说明**正在发生**溢出的行为。

```shell
# watch -d 'netstat -s | grep overflowed'
Every 2.0s: netstat -s | grep overflowed                                
Fri Sep 17 09:00:45 2021

    4343 times the listen queue of a socket overflowed
```

#### 查看半连接队列

半连接队列没有命令可以直接查看到，但因为半连接队列里，放的都是`SYN_RECV`状态的连接，那可以通过统计处于这个状态的连接的数量，间接获得半连接队列的长度。

```shell
# netstat -nt | grep -i '127.0.0.1:8080' | grep -i 'SYN_RECV' | wc -l
0
```

注意半连接队列和全连接队列都是挂在某个`Listen socket`上的，我这里用的是`127.0.0.1:8080`，大家可以替换成自己想要查看的**IP端口**。

可以看到我的机器上的半连接队列长度为`0`，这个很正常，**正经连接谁会没事老待在半连接队列里。**

当队列里的半连接不断增多，最终也是会发生溢出，可以通过下面的命令查看。

```shell
# netstat -s | grep -i "SYNs to LISTEN sockets dropped" 
    26395 SYNs to LISTEN sockets dropped
```

可以看到，我的机器上一共发生了`26395`次半连接队列溢出。同样建议配合`watch -d` 命令使用。

```shell
# watch -d 'netstat -s | grep -i "SYNs to LISTEN sockets dropped"'
Every 2.0s: netstat -s | grep -i "SYNs to LISTEN sockets dropped"       
Fri Sep 17 08:36:38 2021

    26395 SYNs to LISTEN sockets dropped
```

### 全连接队列满了会怎么样？

如果队列满了，服务端还收到客户端的第三次握手ACK，默认当然会丢弃这个ACK。

但除了丢弃之外，还有一些附带行为，这会受 `tcp_abort_on_overflow` 参数的影响。

```shell
# cat /proc/sys/net/ipv4/tcp_abort_on_overflow
0
```

- `tcp_abort_on_overflow`设置为 0，全连接队列满了之后，会丢弃这个第三次握手ACK包，并且开启定时器，重传第二次握手的SYN+ACK，如果重传超过一定限制次数，还会把对应的**半连接队列里的连接**给删掉。

![tcp_abort_on_overflow为0](https://img-blog.csdnimg.cn/img_convert/874f2fb7108020fd4dcfa021f377ec66.png)

- `tcp_abort_on_overflow`设置为 1，全连接队列满了之后，就直接发RST给客户端，效果上看就是连接断了。

这个现象是不是很熟悉，服务端**端口未监听**时，客户端尝试去连接，服务端也会回一个RST。这两个情况长一样，所以客户端这时候收到RST之后，其实无法区分到底是**端口未监听**，还是**全连接队列满了**。

![tcp_abort_on_overflow为1](https://img-blog.csdnimg.cn/img_convert/6a01c5df74748870a69921da89825d9c.png)

### 半连接队列要是满了会怎么样

**一般是丢弃**，但这个行为可以通过 `tcp_syncookies` 参数去控制。但比起这个，更重要的是先了解下半连接队列为什么会被打满。

首先我们需要明白，一般情况下，半连接的"生存"时间其实很短，只有在第一次和第三次握手间，如果半连接都满了，说明服务端疯狂收到第一次握手请求，如果是线上游戏应用，能有这么多请求进来，那说明你可能要富了。但现实往往比较骨感，你可能遇到了**SYN Flood攻击**。

所谓**SYN Flood攻击**，可以简单理解为，攻击方模拟客户端疯狂发第一次握手请求过来，在服务端憨憨地回复第二次握手过去之后，客户端死活不发第三次握手过来，这样做，可以把服务端半连接队列打满，从而导致正常连接不能正常进来。

![syn攻击](https://img-blog.csdnimg.cn/img_convert/d894de5374a12bd5d75d86d4a718d186.png)

那这种情况怎么处理？有没有一种方法可以**绕过半连接队列**？

有，上面提到的`tcp_syncookies`派上用场了。

```shell
# cat /proc/sys/net/ipv4/tcp_syncookies
1
```

当它被设置为1的时候，客户端发来**第一次握手**SYN时，服务端**不会将其放入半连接队列中**，而是直接生成一个`cookies`，这个`cookies`会跟着**第二次握手**，发回客户端。客户端在发**第三次握手**的时候带上这个`cookies`，服务端验证到它就是当初发出去的那个，就会建立连接并放入到全连接队列中。可以看出整个过程不再需要半连接队列的参与。

![tcp_syncookies=1](https://img-blog.csdnimg.cn/img_convert/d696b8b345526533bde8fa990e205c32.png)

#### 会有一个cookies队列吗

生成是`cookies`，保存在哪呢？**是不是会有一个队列保存这些cookies？**

我们可以反过来想一下，如果有`cookies`队列，那它会跟半连接队列一样，到头来，还是会被**SYN Flood 攻击**打满。

实际上`cookies`并不会有一个专门的队列保存，它是通过**通信双方的IP地址端口、时间戳、MSS**等信息进行**实时计算**的，保存在**TCP报头**的`seq`里。

![tcp报头_seq的位置](https://img-blog.csdnimg.cn/img_convert/6d280b0946a73ea6185653cbcfcc489f.png)

当服务端收到客户端发来的第三次握手包时，会通过seq还原出**通信双方的IP地址端口、时间戳、MSS**，验证通过则建立连接。

#### cookies方案为什么不直接取代半连接队列？

目前看下来`syn cookies`方案省下了半连接队列所需要的队列内存，还能解决 **SYN Flood攻击**，那为什么不直接取代半连接队列？

凡事皆有利弊，`cookies`方案虽然能防 **SYN Flood攻击**，但是也有一些问题。因为服务端并不会保存连接信息，所以如果传输过程中数据包丢了，也不会重发第二次握手的信息。

另外，编码解码`cookies`，都是比较**耗CPU**的，利用这一点，如果此时攻击者构造大量的**第三次握手包（ACK包）**，同时带上各种瞎编的`cookies`信息，服务端收到`ACK包`后**以为是正经cookies**，憨憨地跑去解码（**耗CPU**），最后发现不是正经数据包后才丢弃。

这种通过构造大量`ACK包`去消耗服务端资源的攻击，叫**ACK攻击**，受到攻击的服务器可能会因为**CPU资源耗尽**导致没能响应正经请求。

![ack攻击](https://img-blog.csdnimg.cn/img_convert/15a0a5f7fe15ee2bc5e07492eda5a8ea.gif)

### 没有listen，为什么还能建立连接

那既然没有`accept`方法能建立连接，那是不是没有`listen`方法，也能建立连接？是的，之前写的一篇文章提到过客户端是可以自己连自己的形成连接（**TCP自连接**），也可以两个客户端同时向对方发出请求建立连接（**TCP同时打开**），这两个情况都有个共同点，就是**没有服务端参与，也就是没有listen，就能建立连接。**

当时文章最后也留了个疑问，**没有listen，为什么还能建立连接？**

我们知道执行`listen`方法时，会创建半连接队列和全连接队列。

三次握手的过程中会在这两个队列中暂存连接信息。

所以形成连接，前提是你得**有个地方存放着**，方便握手的时候能根据IP端口等信息找到socket信息。

**那么客户端会有半连接队列吗？**

**显然没有**，因为客户端没有执行`listen`，因为半连接队列和全连接队列都是在执行`listen`方法时，内核自动创建的。

但内核还有个**全局hash表**，可以用于存放`sock`连接的信息。这个全局`hash`表其实还细分为`ehash，bhash和listen_hash`等，但因为过于细节，大家理解成有一个**全局hash**就够了，

在TCP自连接的情况中，客户端在`connect`方法时，最后会将自己的连接信息放入到这个**全局hash表**中，然后将信息发出，消息在经过回环地址重新回到TCP传输层的时候，就会根据IP端口信息，再一次从这个**全局hash**中取出信息。于是握手包一来一回，最后成功建立连接。

TCP 同时打开的情况也类似，只不过从一个客户端变成了两个客户端而已。

## 总结

- **每一个**`socket`执行`listen`时，内核都会自动创建一个半连接队列和全连接队列。
- 第三次握手前，TCP连接会放在半连接队列中，直到第三次握手到来，才会被放到全连接队列中。
- `accept方法`只是为了从全连接队列中拿出一条连接，本身跟三次握手几乎**毫无关系**。
- 出于效率考虑，虽然都叫队列，但半连接队列其实被设计成了**哈希表**，而全连接队列本质是链表。
- 全连接队列满了，再来第三次握手也会丢弃，此时如果`tcp_abort_on_overflow=1`，还会直接发`RST`给客户端。
- 半连接队列满了，可能是因为受到了`SYN Flood`攻击，可以设置`tcp_syncookies`，绕开半连接队列。
- 客户端没有半连接队列和全连接队列，但有一个**全局hash**，可以通过它实现自连接或TCP同时打开。


