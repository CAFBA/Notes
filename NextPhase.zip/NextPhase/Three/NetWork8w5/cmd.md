> `TCP` 的连接状态查看，在 `Linux` 可以通过 `netstat -napt` 命令查看。
![TCP 连接状态查看](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/10.jpg)
> 在 `Linux` 操作系统，可以使用 `route -n` 命令查看当前系统的路由表。
![image-20230308132857242](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230308132857242.png)
> 在 `Linux` 系统中，可以使用 `arp -a` 命令来查看 `ARP` 缓存的内容。