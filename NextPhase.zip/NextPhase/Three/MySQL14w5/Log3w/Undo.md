## 为什么需要 undo log
一个事务在执行过程中，在还没有提交事务之前 `MySQL` 可能会发生崩溃，但是事务执行过程中可能已经修改很多东西，为保证事务的原子性，每次在事务提交之前，先记录下回滚时需要的信息到一个日志里，那么在事务执行中途发生 `MySQL` 崩溃后，可以通过这个日志回滚到事务之前的数据，实现这一机制就是 `undo` 日志。
每当 `InnoDB` 引擎对一条记录进行操作时，要把回滚时需要的信息都记录到 `undo log` 里，在发生回滚时，就读取 `undo log` 里的数据，然后做原先相反操作。
一条记录的每一次更新操作产生的 `undo log` 格式都有一个 `roll_pointer` 指针和一个 `trx_id` 事务 `id`：
- 通过 `trx_id` 可以知道该记录是被哪个事务修改的。
- 通过 `roll_pointer` 指针可以将这些 `undo log` 串成一个链表，这个链表就被称为版本链。
`undo log` 两大作用：
- 实现事务回滚，保障事务的原子性。事务处理过程中，如果出现错误或者用户执行 `ROLLBACK` 语句，`MySQL` 可以利用 `undo log` 中的历史数据将数据恢复到事务开始之前的状态。
- 实现 `MVCC` 关键因素之一。`MVCC` 是通过 `ReadView + undo log` 实现的。`undo log` 为每条记录保存多份历史数据，`MySQL` 在执行快照读的时候，会根据事务的 `Read View` 里的信息，顺着 `undo log` 的版本链找到满足其可见性的记录。
## Undo日志
### 事务 `id` 
一个事务可以是一个只读事务，或者是一个读写事务：
- 可以通过 `START TRANSACTION READ ONLY` 语句开启一个只读事务。在只读事务中不可以对其他事务也能访问到的表进行增、删、改操作，但可以对临时表做增、删、改操作。
- 可以通过 `START TRANSACTION READ WRITE` 语句开启一个读写事务。在读写事务中可以对表执行增删改查操作。使用 `BEGIN`、`START TRANSACTION` 语句开启的事务默认也算是读写事务。
#### 事务 id 分配的时机
如果某个事务执行过程中对某个表执行增、删、改操作，那么 `InnoDB` 存储引擎就会给它分配一个独一无二的事务 `id`，分配方式如下：
- 对于只读事务来说，只有在它第一次对某个用户创建的临时表执行增、删、改操作时才会为这个事务分配一个事务 `id` ，否则的话不分配事务 `id`。
- 对于读写事务来说，只有在它第一次对某个表(包括用户创建的临时表)执行增、删、改操作时才会为这个事务分配一个事务 `id`，否则也不分配事务 `id`。
  有的时候虽然开启了一个读写事务，但是在这个事务中全是查询语句，并没有执行增、删、改的语句，那也就意味着这个事务并不会被分配一个事务 `id`。
有时候在 `Extra` 列会看到 `Using temporary` 的提示，这个表明在执行该查询语句时会用到内部临时表。内部临时表和手动用 `CREATE TEMPORARY TABLE` 创建的用户临时表并不一样，在事务回滚时并不需要把执行 `SELECT` 语句过程中用到的内部临时表也回滚，在执行 `SELECT` 语句用到内部临时表时并不会为它分配事务 `id`。
#### 事务 id 的生成
这个事务 `id` 本质上就是一个数字，它的分配策略和隐藏列 `row_id` 的分配策略大抵相同：
- 服务器会在内存中维护一个全局变量，每当需要为某个事务分配一个事务 `id` 时，就会把该变量的值当作事务 `id` 分配给该事务，并且把该变量自增 1。
- 每当这个变量的值为 256 的倍数时，就会将该变量的值刷新到系统表空间的页号为 5 的页面中一个称之为 `Max Trx ID` 的属性处，这个属性占用 8 个字节的存储空间。
- 当系统下一次重新启动时，会将上边提到的 `Max Trx ID` 属性加载到内存中，将该值加上 256 之后赋值给前边提到的全局变量，因为在上次关机时该全局变量的值可能大于 `Max Trx ID` 属性值。
这样就可以保证整个系统中分配的事务 `id` 值是一个递增的数字。先被分配 `id` 的事务得到的是较小的事务 `id`，后被分配 `id` 的事务得到的是较大的事务 `id`。
#### trx_id 隐藏列
聚簇索引的记录除会保存完整的用户数据以外，而且还会自动添加名为 `trx_id`、`roll_pointer` 的隐藏列，如果用户没有在表中定义主键以及 `UNIQUE` 键，还会自动添加一个名为 `row_id` 的隐藏列。
其中的 `trx_id` 列就是某个对这个聚簇索引记录做改动的语句所在的事务对应的事务 `id`，此处的改动可以是 `INSERT` 、`DELETE`、 `UPDATE` 操作。
###  undo 日志的格式
为实现事务的原子性，`InnoDB` 存储引擎在实际进行增、删、改一条记录时，都需要先把对应的 `undo` 日志记下来。一个事务在执行过程中可能新增、删除、更新若干条记录，也就是说需要记录很多条对应的 `undo` 日志，这些 `undo` 日志会被从 0 开始编号，这个编号被称之为 `undo no` 。
这些 `undo` 日志被记录到类型为 `FIL_PAGE_UNDO_LOG` 的页面中，这些页面可以从系统表空间中分配，也可以从一种专门存放 `undo` 日志的表空间 `undo tablespace` 中分配。
先创建一个名为 `undo_demo` 的表：
```mysql
CREATE TABLE undo_demo  (
    id  INT NOT NULL,
    key1 VARCHAR(100),
    col VARCHAR(100),
    PRIMARY KEY (id),
    KEY idx_key1 (key1)
)Engine= InnoDB  CHARSET=utf8;
```
可以通过系统数据库 `information_schema` 中的 `innodb_sys_tables` 表来查看某个表对应的 `table id` 是什么：
```mysql
mysql> SELECT * FROM information_schema.innodb_sys_tables WHERE name = 'xiaohaizi/ `undo_demo` ';
```
从查询结果可以看出，`undo_demo` 表对应的 `table id` 为 138。
####  `INSERT` 对应 `undo` 日志
当向表中插入一条记录时会将这条记录放到一个数据页中。如果希望回滚这个插入操作，那么把这条记录删除就好，也就是说在写对应的 `undo` 日志时，主要是把这条记录的主键信息记上。所以 `InnoDB` 设计一个类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志：
![image-20230125213322304](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213322304.png)
- `undo no` 在一个事务中是从 0 开始递增的，只要事务没提交，每生成一条 `undo` 日志，那么该条日志的 `undo no` 就增 1。
- 如果记录中的主键只包含一个列，那么在类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志中只需要把该列占用的存储空间大小和真实值记录下来，如果记录中的主键包含多个列，那么每个列占用的存储空间大小和对应的真实值都需要记录下来，图中的 `len` 就代表列占用的存储空间大小，`value` 就代表列的真实值。
当向某个表中插入一条记录时，实际上需要向聚簇索引和所有的二级索引都插入一条记录。不过记录 `undo` 日志时，只需要考虑向聚簇索引插入记录时的情况可以，因为聚簇索引记录和二级索引记录是一一对应的。
在回滚插入操作时，只需要知道这条记录的主键信息，然后根据主键信息做对应的删除操作，做删除操作时就会顺带着把所有二级索引中相应的记录也删除掉。`DELETE` 操作和 `UPDATE` 操作对应的 `undo` 日志也都是针对聚簇索引记录而言的。
向 `undo_demo` 中插入两条记录：
```mysql
BEGIN;  # 显式开启一个事务，假设该事务的 id 为 100

# 插入两条记录
INSERT INTO undo_demo(id, key1, col) VALUES (1, 'AWM', '狙击枪'), (2, 'M416', '步枪');
```
因为记录的主键只包含一个 `id` 列，所以在对应的 `undo` 日志中只需要将待插入记录的 `id` 列占用的存储空间长度和真实值记录下来。
本例中插入两条记录，所以会产生两条类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志:
- 第一条 `undo` 日志的 `undo no` 为 0，记录主键占用的存储空间长度为 4，真实值为 1：
![image-20230125213327991](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213327991.png)
- 第二条 `undo` 日志的 `undo no` 为 1，记录主键占用的存储空间长度为 4，真实值为 2：
![image-20230125213333429](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213333429.png)
####  `DELETE` 对应 `undo` 日志
插入到页面中的记录会根据记录头信息中的 `next_record` 属性组成一个单向链表，把这个链表称之为正常记录链表，被删除的记录其实也会根据记录头信息中的 `next_record` 属性组成一个链表，这个链表中的记录占用的存储空间可以被重新利用，所以称这个链表为垃圾链表。`Page Header` 部分有一个称之为 `PAGE_FREE` 的属性，它指向由被删除记录组成的垃圾链表中的头节点。
假设此刻某个页面中的记录分布情况是这样的：
![image-20230125213346626](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213346626.png)
页面的 `Page Header` 部分的 `PAGE_FREE` 属性的值代表指向垃圾链表头节点的指针。假设现在准备使用 `DELETE` 语句把正常记录链表中的最后一条记录给删除掉，这个删除的过程需要经历两个阶段：
- 阶段一：仅仅将记录的 `delete_mask` 标识位设置为 1，其他的不做修改（其实会修改记录的 `trx_id` 、`roll_pointer` 这些隐藏列的值）。`InnoDB` 把这个阶段称之为 `delete mark`，在删除语句所在的事务提交之前，被删除的记录一直都处于这种所谓的中间状态，这主要是为实现 `MVCC` 的功能。
![image-20230125213353368](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213353368.png)
- 阶段二：当该删除语句所在的事务提交之后，会有专门的线程后来真正的把记录删除掉。所谓真正的删除就是把该记录从正常记录链表中移除，并且加入到垃圾链表中，然后还要调整一些页面的其他信息，比如垃圾链表头节点的指针 `PAGE_FREE` 的值。`InnoDB` 把这个阶段称之为 `purge`。
把阶段二执行完，这条记录就算是真正的被删除掉。这条已删除记录占用的存储空间也可以被重新利用。画下来就是这样：
![image-20230125213359708](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213359708.png)
因此在删除语句所在的事务提交之前，只会经历 `delete mark` 阶段，提交之后就不用回滚，所以只需考虑对删除操作的阶段一做的影响进行回滚。`InnoDB` 为此设计一种称之为 `TRX_UNDO_DEL_MARK_REC` 类型的 `undo` 日志，完整结构如下图所示：
![image-20230125213413422](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213413422.png)
与类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志不同，类型为 `TRX_UNDO_DEL_MARK_REC` 的 `undo` 日志还多一个索引列各列信息的内容，也就是说如果某个列被包含在某个索引中，那么它的相关信息就应该被记录到这个索引列各列信息部分，相关信息包括该列在记录中的位置 `pos`，该列占用的存储空间大小 `len`，该列实际值 `value`。
所以索引列各列信息存储的内容实质上就是 `<pos, len, value>` 的一个列表。这部分信息主要是用在事务提交后，对该中间状态记录做真正删除的阶段二，也就是 `purge` 阶段中使用的。
现在在上边那个事务 `id` 为 100 的事务中删除一条记录，比如把 `id` 为 1 的那条记录删除掉：
```mysql
BEGIN;  # 显式开启一个事务，假设该事务的 `id` 为100

# 插入两条记录
INSERT INTO undo_demo (id, key1, col) VALUES (1, 'AWM', '狙击枪'), (2, 'M416', '步枪');

# 删除一条记录    
DELETE FROM undo_demo WHERE id = 1; 
```
这个 `delete mark` 操作对应的 `undo` 日志的结构就是这样：
![image-20230125213434982](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213434982.png)
对照着这个图，得注意下边几点：
- 因为这条 `undo` 日志是 `id` 为 100 的事务中产生的第 3 条 `undo` 日志，所以它对应的 `undo no` 就是 2。
- 在对记录做 `delete mark` 操作时，记录的 `trx_id` 隐藏列的值是 100，所以把 100 填入  `old trx_id` 属性中。然后把记录的 `roll_pointer` 隐藏列的值取出来，填入 `old roll_pointer` 属性中，这样就可以通过`old roll_pointer` 属性值找到最近一次对该记录做改动时产生的 `undo` 日志。
- 由于 `undo_demo` 表中有 2 个索引：一个是聚簇索引，一个是二级索引 `idx_key1`。只要是包含在索引中的列，那么`<pos, len, value>`就需要存储到 `undo` 日志中。
对于主键来说，只包含一个 `id` 列，存储到 `undo` 日志中的相关信息分别是：
- `pos`： `id` 列是主键，也就是在记录的第一个列，它对应的 `pos` 值为 0。`pos` 占用 1 个字节来存储。
- `len`： `id` 列的类型为 `INT`，占用 4 个字节，所以 `len` 的值为 4。`len` 占用 1 个字节来存储。
- `value`：在被删除的记录中 `id` 列的值为 1，也就是 `value` 的值为 1。`value` 占用 4 个字节来存储。
![image-20230125213439301](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213439301.png)
所以对于 `id` 列来说，最终存储的结果就是 `<0, 4, 1>`，存储这些信息占用的存储空间大小为1 + 1 + 4 = 6 个字节。
对于 `idx_key1` 来说，只包含一个 `key1` 列，存储到 `undo` 日志中的相关信息分别是：
- `pos`：`key1` 列是排在 `id` 列、 `trx_id` 列、 `roll_pointer` 列之后的，它对应的 `pos` 值为 3。
- `len`：`key1` 列的类型为 `VARCHAR(100)`，使用 `utf8` 字符集，被删除的记录实际存储的内容是 `AWM`，所以一共占用 3 个字节，所以 `len` 的值为 3。
- `value`：在被删除的记录中 `key1` 列的值为 `AWM`，也就是 `value` 的值为 `AWM`。`value` 占用 3 个字节来存储。
![image-20230125213443227](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213443227.png)
所以对于 `key1` 列来说，最终存储的结果就是 `<3, 3, 'AWM'>`，存储这些信息占用的存储空间大小为 1 + 1 + 3 = 5 个字节。
从上边的叙述中可以看到，`<0, 4, 1>` 和 `<3, 3, 'AWM'>` 共占用11个字节。然后 `index_col_info len` 本身占用 2 个字节，所以加起来一共占用 13 个字节，把数字 13 就填到 `index_col_info len` 的属性中。

页面的 `Page Header` 部分有一个 `PAGE_GARBAGE` 属性，记录着当前页面中可重用存储空间占用的总字节数。每当有已删除记录被加入到垃圾链表后，都会把这个 `PAGE_GARBAGE` 属性的值加上该已删除记录占用的存储空间大小。
`PAGE_FREE` 指向垃圾链表的头节点，之后每当新插入记录时，首先判断 `PAGE_FREE` 指向的头节点代表的已删除记录占用的存储空间是否足够容纳这条新插入的记录，如果不可以容纳，就直接向页面中申请新的空间来存储这条记录。如果可以容纳，那么直接重用这条已删除记录的存储空间，并且把 `PAGE_FREE` 指向垃圾链表中的下一条已删除记录。
但是如果新插入的那条记录占用的存储空间大小小于垃圾链表的头节点占用的存储空间大小，那就意味头节点对应的记录占用的存储空间里有一部分空间用不到。这些碎片空间占用的存储空间大小会被统计到 `PAGE_GARBAGE` 属性中，这些碎片空间在整个页面快使用完前并不会被重新利用，不过当页面快满时，如果再插入一条记录，此时页面中并不能分配一条完整记录的空间，这时候会首先看一看 `PAGE_GARBAGE` 的空间和剩余可利用的空间加起来是不是可以容纳下这条记录，如果可以的话， `InnoDB` 会尝试重新组织页内的记录，重新组织的过程就是先开辟一个临时页面，把页面内的记录依次插入一遍，因为依次插入时并不会产生碎片，之后再把临时页面的内容复制到本页面，这样就可以把那些碎片空间都解放出来。
####  `UPDATE` 对应 `undo` 日志
在执行 `UPDATE` 语句时，`InnoDB` 对更新主键和不更新主键这两种情况有截然不同的处理方案。
##### 不更新主键
在不更新主键的情况下，又可以细分为被更新的列占用的存储空间不发生变化和发生变化的情况。
- 就地更新：如果每个列在更新前后占用的存储空间一样大，那么就可以进行就地更新，也就是直接在原记录的基础上修改对应列的值。
- 先删除掉旧记录，再插入新记录：如果有任何一个被更新的列更新前后占用的存储空间大小不一致，那么就需要先把这条旧的记录从聚簇索引页面中删除掉，然后再根据更新后列的值创建一条新的记录插入到页面中。
这里所说的删除并不是 `delete mark` 操作，而是真正的删除掉，也就是把这条记录从正常记录链表中移除并加入到垃圾链表中，并且修改页面中相应的统计信息。不过这里做真正删除操作的线程并不是在做 `purge` 操作时使用的另外专门的线程，而是由用户线程同步执行真正的删除操作，真正删除之后紧接着就要根据各个列更新后的值创建的新记录插入。
这里如果新创建的记录占用的存储空间大小不超过旧记录占用的空间，那么可以直接重用被加入到垃圾链表中的旧记录所占用的存储空间，否则的话需要在页面中新申请一段空间以供新记录使用，如果本页面内已经没有可用的空间的话，那就需要进行页面分裂操作，然后再插入新记录。
针对 `UPDATE` 不更新主键的情况，`InnoDB` 设计一种类型为 `TRX_UNDO_UPD_EXIST_REC` 的 `undo` 日志，它的完整结构如下：
![image-20230125213448063](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213448063.png)
大部分属性和 `TRX_UNDO_DEL_MARK_REC` 类型的 `undo` 日志是类似的，不过：
- `n_updated` 属性表示本条 `UPDATE` 语句执行后将有几个列被更新，后边跟着的 `<pos, old_len, old_value>` 分别表示被更新列在记录中的位置、更新前该列占用的存储空间大小、更新前该列的真实值。
- 如果在 `UPDATE` 语句中更新的列包含索引列，那么也会添加索引列各列信息这个部分，否则的话是不会添加这个部分的。
现在继续在上边那个事务 `id` 为 100 的事务中更新一条记录，比如把 `id` 为 2 的那条记录更新：
```mysql
BEGIN;  # 显式开启一个事务，假设该事务的 `id` 为100

# 插入两条记录
INSERT INTO undo_demo(id, key1, col) 
    VALUES (1, 'AWM', '狙击枪'), (2, 'M416', '步枪');
    
# 删除一条记录    
DELETE FROM undo_demo  WHERE id = 1; 

# 更新一条记录
UPDATE  undo_demo` 
    SET key1 = 'M249', col = '机枪'
    WHERE id  = 2;
```
这个 `UPDATE` 语句更新的列大小都没有改动，所以可以采用就地更新的方式来执行，在真正改动页面记录时，会先记录一条类型为 `TRX_UNDO_UPD_EXIST_REC` 的 `undo` 日志：
![image-20230125213458557](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213458557.png)
- 因为这条 `undo` 日志是 `id` 为 100 的事务中产生的第 4 条 `undo` 日志，所以它对应的 `undo no` 就是 3。
- 这条日志的 `roll_pointer` 指向 `undo no` 为 1 的那条日志，也就是插入主键值为 2 的记录时产生的那条 `undo` 日志，也就是最近一次对该记录做改动时产生的 `undo` 日志。
- 由于本条 `UPDATE` 语句中更新索引列 `key1` 的值，所以需要记录一下索引列各列信息部分，也就是把主键和 `key1` 列更新前的信息填入。
##### 更新主键
在聚簇索引中，记录是按照主键值的大小连成一个单向链表的，如果更新某条记录的主键值，意味着这条记录在聚簇索引中的位置将会发生改变。针对 `UPDATE` 语句中更新记录主键值的这种情况， `InnoDB` 在聚簇索引中分两步处理：
- 将旧记录进行 `delete mark` 操作，也就是说在 `UPDATE` 语句所在的事务提交前，对旧记录只做一个 `delete mark` 操作，在事务提交后才由专门的线程做 `purge` 操作，把它加入到垃圾链表中。之所以只对旧记录做 `delete mark` 操作，是因为别的事务同时也可能访问这条记录，如果把它真正的删除加入到垃圾链表后，别的事务就访问不到，这个功能就是 `MVCC`。
- 根据更新后各列的值创建一条新记录，由于更新后的记录主键值发生改变，所以需要重新从聚簇索引中定位这条记录所在的位置，然后把它插进去。
针对 `UPDATE` 语句更新记录主键值的这种情况，在对该记录进行 `delete mark` 操作前，会记录一条类型为 `TRX_UNDO_DEL_MARK_REC` 的 `undo` 日志，之后插入新记录时，会记录一条类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志，也就是说每对一条记录的主键值做改动时，会记录 2 条 `undo` 日志。
## 通用链表结构
在写入 `undo` 日志的过程中会使用到多个链表，很多链表都有同样的节点结构，如图所示：
![image-20230125213505148](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213505148.png)
在某个表空间内，可以通过一个页的页号和在页内的偏移量来唯一定位一个节点的位置，这两个信息也就相当于指向这个节点的一个指针。所以：
- `Pre Node Page Number` 和 `Pre Node Offset` 的组合就是指向前一个节点的指针
- `Next Node Page Number` 和 `Next Node Offset` 的组合就是指向后一个节点的指针。
整个 `List Node` 占用12个字节的存储空间。
为了更好的管理链表， `InnoDB` 还提出了一个基节点的结构，里边存储了这个链表的头节点、尾节点以及链表长度信息，基节点的结构示意图如下：
![image-20230125213510065](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213510065.png)
其中：
- `List Length` 表明该链表一共有多少节点。
- `First Node Page Number` 和 `First Node Offset` 的组合就是指向链表头节点的指针。
- `Last Node Page Number` 和 `Last Node Offset` 的组合就是指向链表尾节点的指针。
整个 `List Base Node` 占用 16 个字节的存储空间。
所以使用 `List Base Node` 和 `List Node` 这两个结构组成的链表的示意图就是这样：
![image-20230125213514904](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213514904.png)
## FIL_PAGE_UNDO_LOG 页面
表空间中 `FIL_PAGE_UNDO_LOG` 类型的页面是专门用来存储 `undo` 日志的，这种类型的页面的通用结构如下图所示：
![image-20230125213520384](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213520384.png)
`Undo Page Header` 是 `Undo` 页面所特有的：
![image-20230125213528603](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213528603.png)
其中各个属性的意思如下：
- `TRX_UNDO_PAGE_TYPE`：本页面准备存储的 `undo` 日志种类。
  - `TRX_UNDO_INSERT`十进制 1 表示：类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志属于此大类，一般由 `INSERT` 语句产生，或者在 `UPDATE` 语句中有更新主键的情况也会产生此类型的 `undo` 日志。
  - `TRX_UNDO_UPDATE` 十进制 2 表示：除类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志，其他类型的 `undo` 日志都属于这个大类，比如 `TRX_UNDO_DEL_MARK_REC`、`TRX_UNDO_UPD_EXIST_REC`，一般由 `DELETE`、`UPDATE` 语句产生的 `undo` 日志属于这个大类。
之所以把 `undo` 日志分成两个大类，是因为类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志在事务提交后可以直接删除掉，而其他类型的 `undo` 日志还需要为 `MVCC` 服务，不能直接删除掉，对它们的处理需要区别对待。
不同大类的 `undo` 日志不能混着存储，比如一个 `Undo` 页面的 `TRX_UNDO_PAGE_TYPE` 属性值为 `TRX_UNDO_INSERT`，那么这个页面就只能存储类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志，其他类型的 `undo` 日志就不能放到这个页面中。
- `TRX_UNDO_PAGE_START`：表示第一条 `undo` 日志在本页面中的起始偏移量。
- `TRX_UNDO_PAGE_FREE`：表示当前页面中存储的最后一条 `undo` 日志结束时的偏移量。
假设现在向页面中写入 3 条 `undo` 日志：
![image-20230125213534036](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213534036.png)
- `TRX_UNDO_PAGE_NODE`：代表一个 `List Node` 结构
## Undo 页面链表
### 单个事务中
在一个事务执行过程中可能产生很多 `undo` 日志，这些日志可能一个页面放不下，需要放到多个页面中，这些页面就通过 `TRX_UNDO_PAGE_NODE` 属性连成链表：
![image-20230125213538115](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213538115.png)
第一个 `Undo` 页面称为 `first undo page`，其余的 `Undo` 页面称之为 `normal undo page`，这是因为在 `first undo page` 中除记录 `Undo Page Header` 之外，还会记录其他的一些管理信息。
在一个事务执行过程中，可能混着执行 `INSERT` 、 `DELETE` 、 `UPDATE` 语句，也就意味着会产生不同类型的 `undo` 日志。但是同一个 `Undo` 页面要么只存储 `TRX_UNDO_INSERT` 大类的 `undo` 日志，要么只存储 `TRX_UNDO_UPDATE` 大类的 `undo` 日志，所以在一个事务执行过程中就可能需要 2 个 `Undo` 页面的链表，一个称之为 `insert undo` 链表，另一个称之为  `update undo` 链表：
![image-20230125213541907](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213541907.png)
另外，`InnoDB` 规定对普通表和临时表的记录改动时产生的 `undo` 日志要分别记录，所以在一个事务中最多有 4 个以 `Undo` 页面为节点组成的链表：
![image-20230125213546415](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213546415.png)
并不是在事务一开始就会为这个事务分配这 4 个链表，具体分配策略如下：
- 刚刚开启事务时，一个 `Undo` 页面链表也不分配。
- 当事务执行过程中向普通/临时表中插入记录或者执行更新记录主键的操作之后，就会为其分配一个普通/临时表的 `insert undo` 链表。
- 当事务执行过程中删除或者更新普通/临时表中的记录之后，就会为其分配一个普通/临时表的`update undo` 链表。
### 多个事务中
为尽可能提高 `undo` 日志的写入效率，不同事务执行过程中产生的 `undo` 日志需要被写入到不同的 `Undo` 页面链表中。比如现在有事务 `id` 分别为 1、2 的两个事务，分别称之为 `trx 1` 和  `trx 2` ，假设在这两个事务执行过程中：
-  `trx 1` 对普通表做 `DELETE` 操作，对临时表做 `INSERT` 和 `UPDATE` 操作。`InnoDB` 会为 `trx 1` 分配 3 个链表：针对普通表的 `update undo` 链表，针对临时表的  `update undo` 链表和 `insert undo` 链表。
-  `trx 2` 对普通表做 `INSERT` 、 `UPDATE` 和 `DELETE` 操作，没有对临时表做改动。`InnoDB` 会为 `trx 2` 分配 2 个链表：针对普通表的 `insert undo` 链表和 `update undo` 链表。
综上所述，在 `trx 1` 和 `trx 2` 执行过程中，`InnoDB` 共需为这两个事务分配 5 个 `Undo` 页面链表：
![image-20230125213554095](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213554095.png)
##  undo 日志写入过程
### Undo Log Segment Header
`InnoDB` 规定，每一个 `Undo` 页面链表都对应着一个段，称之为 `Undo Log Segment`，链表中的页面都是从这个段里边申请的，所以在 `Undo` 页面链表的第一个页面，即 `first undo page` 中有 `Undo Log Segment Header` 的部分，包含该链表对应的段的 `segment header` 信息以及其他的一些关于这个段的信息，所以 `Undo` 页面链表的第一个页面：
![image-20230125220119739](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220119739.png)
可以看到这个 `Undo` 链表的第一个页面比普通页面多 `Undo Log Segment Header`，它的结构：
![image-20230125220124521](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220124521.png)
其中各个属性的意思如下：
- `TRX_UNDO_STATE`：本 `Undo` 页面链表的状态。一个 `Undo Log Segment` 可能处在的状态包括：
  - `TRX_UNDO_ACTIVE`：活跃状态，也就是一个活跃的事务正在往这个段里边写入 `undo` 日志。
  - `TRX_UNDO_CACHED`：被缓存的状态，处在该状态的 `Undo` 页面链表等待着之后被其他事务重用。
  - `TRX_UNDO_TO_FREE`：对于 `insert undo` 链表来说，如果在它对应的事务提交之后，该链表不能被重用，那么就会处于这种状态。
  - `TRX_UNDO_TO_PURGE`：对于 `update undo` 链表来说，如果在它对应的事务提交之后，该链表不能被重用，那么就会处于这种状态。
  - `TRX_UNDO_PREPARED`：包含处于 `PREPARE` 阶段的事务产生的 `undo` 日志。
- `TRX_UNDO_LAST_LOG`：本 Undo 页面链表中最后一个 `Undo Log Header` 的位置。
- `TRX_UNDO_FSEG_HEADER`：本Undo页面链表对应的段的Segment Header信息（就是上一节介绍的那个10字节结构，通过这个信息可以找到该段对应的INODE Entry）。
- `TRX_UNDO_PAGE_LIST`：`Undo` 页面链表的基节点。
每一个 `Undo` 页面都包含 `Undo Page Header` 结构，其中 12 字节大小的 `TRX_UNDO_PAGE_NODE` 属性代表一个 `List Node` 结构，这些页面就可以通过这个属性连成一个链表。这个 `TRX_UNDO_PAGE_LIST` 属性代表着这个链表的基节点，这个基节点只存在于 `Undo` 页面链表的第一个页面。
### Undo Log Header
一个事务在向 `Undo` 页面中写入 `undo` 日志时的方式是写完一条紧接着写另一条，写完一个Undo页面后，再从段里申请一个新页面，然后把这个页面插入到 `Undo` 页面链表中，继续往这个新申请的页面中写。
`InnoDB` 认为同一个事务向一个 `Undo` 页面链表中写入的 `undo` 日志算一个组，比如上述的 `trx 1` 由于会分配 3 个 `Undo` 页面链表，也就会写入 3 个组的 `undo` 日志，`trx 2` 由于会分配 2 个 `Undo` 页面链表，也就会写入 2 个组的 `undo` 日志。
在每写入一组 `undo` 日志时，都会在这组 `undo` 日志前先记录一下关于这个组的一些属性，`InnoDB` 把存储这些属性的地方称之为 `Undo Log Header`。所以 `Undo` 页面链表的第一个页面在真正写入 `undo` 日志前，其实都会被填充 `Undo Page Header`、`Undo Log Segment Header`、`Undo Log Header` 这 3 个部分，如图所示：
![image-20230125220135821](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220135821.png)
这个 `Undo Log Header` 具体的结构如下：
![image-20230125220144312](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220144312.png)
- `TRX_UNDO_TRX_ID`：生成本组 `undo` 日志的事务 `id` 。
- `TRX_UNDO_TRX_NO`：事务提交后生成的一个需要序号，使用此序号来标记事务的提交顺序。
- `TRX_UNDO_DEL_MARKS`：标记本组 `undo` 日志中是否包含由于 `delete mark` 操作产生的 `undo` 日志。
- `TRX_UNDO_LOG_START`：表示本组 `undo` 日志中第一条 `undo` 日志的在页面中的偏移量。
- `TRX_UNDO_XID_EXISTS`：本组 `undo` 日志是否包含 `XID` 信息。
- `TRX_UNDO_DICT_TRANS`：标记本组 `undo` 日志是不是由 `DDL` 语句产生的。
- `TRX_UNDO_TABLE_ID`：如果 `TRX_UNDO_DICT_TRANS` 为真，那么本属性表示 `DDL` 语句操作的表的 `table id` 。
- `TRX_UNDO_NEXT_LOG`：下一组的 `undo` 日志在页面中开始的偏移量。
- `TRX_UNDO_PREV_LOG`：上一组的 `undo` 日志在页面中开始的偏移量。
一般来说一个 `Undo` 页面链表只存储一个事务执行过程中产生的一组 `undo` 日志，但是在某些情况下，可能会在一个事务提交之后，之后开启的事务重复利用这个 `Undo` 页面链表，这样就会导致一个 `Undo` 页面中可能存放多组 `Undo` 日志，`TRX_UNDO_NEXT_LOG` 和 `TRX_UNDO_PREV_LOG` 就是用来标记下一组和上一组 `undo` 日志在页面中的偏移量的。
- `TRX_UNDO_HISTORY_NODE`：一个 12 字节的 `List Node` 结构，代表一个称之为 `History` 链表的节点。
### 小结
对于没有被重用的 `Undo` 页面链表来说，链表的第一个页面，在真正写入 `undo` 日志前，会填充 `Undo Page Header`、`Undo Log Segment Header`、`Undo Log Header` 这 3 个部分，之后才开始正式写入 `undo` 日志。对于其他的页面来说，也就是 `normal undo page`  在真正写入 `undo` 日志前，只会填充 `Undo Page Header`。
链表的 `List Base Node` 存放到  `first undo page`  的 `Undo Log Segment Header` 部分，`List Node` 信息存放到每一个 `Undo` 页面的 `undo Page Header` 部分，所以一个 `Undo` 页面链表的示意图就是这样：
![image-20230125220149919](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220149919.png)
## 重用 Undo 页面
为能提高并发执行的多个事务写入 `undo` 日志的性能，`InnoDB` 决定为每个事务单独分配相应的 `Undo` 页面链表。但是这样也造成一些问题，比如其实大部分事务执行过程中可能只修改一条或几条记录，针对某个 `Undo` 页面链表只产生非常少的 `undo` 日志，这些 `undo` 日志可能只占用一点存储空间，每开启一个事务就新创建一个 `Undo` 页面链表来存储 `undo` 日志太浪费了，于是 `InnoDB` 决定在事务提交后在某些情况下重用该事务的 `Undo` 页面链表。一个 `Undo` 页面链表是否可以被重用的条件为：
- 该链表中只包含一个 `Undo` 页面。
- 该 `Undo` 页面已经使用的空间小于整个页面空间的 3/4。
`Undo` 页面链表按照存储的 `undo` 日志所属的大类可以被分为  `insert undo` 链表和  `update undo` 链表两种，这两种链表在被重用时的策略也是不同的：
`insert undo` 链表中只存储类型为 `TRX_UNDO_INSERT_REC` 的 `undo` 日志，这种类型的 `undo` 日志在事务提交之后就可以被清除掉。所以在某个事务提交后，如果这个事务的 `insert undo`链表只有一个页面，可以直接把之前事务写入的一组 `undo` 日志覆盖掉，从头开始写入新事务的一组 `undo` 日志，如下图所示：
![image-20230125220203660](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220203660.png)
在重用 `Undo` 页面链表写入新的一组 `undo` 日志时，不仅会写入新的 `Undo Log Header`，还会适当调整 `Undo Page Header`、`Undo Log Segment Header`、`Undo Log Header` 中的一些属性。
在一个事务提交后，它的 `update undo` 链表中的 `undo` 日志不能立即删除掉，这些日志用于 `MVCC`。所以如果之后的事务想重用 `update undo` 链表时，就不能覆盖之前事务写入的 `undo` 日志。这样就相当于在同一个 `Undo` 页面中写入多组的 `undo` 日志：
![image-20230125220208825](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220208825.png)
## 回滚段
一个事务在执行过程中最多可以分配 4 个 `Undo` 页面链表，在同一时刻不同事务拥有的 `Undo` 页面链表是不一样的，所以在同一时刻系统里其实可以有许许多多个 `Undo` 页面链表存在。为更好的管理这些链表，`InnoDB` 设计 `Rollback Segment Header` 页面，在这个页面中存放各个`Undo` 页面链表的 `frist undo page` 的页号，把这些页号称之为 `undo slot` 。
`InnoDB` 规定，每一个  `Rollback Segment Header` 页面都对应着一个段，这个段就称为  `Rollback Segment` 。与之前介绍的各种段不同的是，这个  `Rollback Segment`  里只有一个页面。
![image-20230125220214363](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220214363.png)
- `TRX_RSEG_MAX_SIZE`：本 `Rollback Segment` 中管理的所有 `Undo` 页面链表中的 `Undo` 页面数量之和的最大值 `0xFFFFFFFE`。
- `TRX_RSEG_HISTORY_SIZE`：`History` 链表占用的页面数量。
- `TRX_RSEG_HISTORY`：`History` 链表的基节点。
- `TRX_RSEG_FSEG_HEADER`：本 `Rollback Segment` 对应的 10 字节大小的 `Segment Header` 结构，通过它可以找到本段对应的 `INODE Entry`。
- `TRX_RSEG_UNDO_SLOTS`：各个 `Undo` 页面链表的 `frist undo page` 的页号集合，也就是 `undo slot` 集合。
一个页号占用 4 个字节，对于 `16KB` 大小的页面来说，这个 TRX_RSEG_UNDO_SLOTS 部分共存储 1024 个 `undo slot`  ，所以共需 1024 × 4 = 4096 个字节。
### 从回滚段中申请 Undo 页面链表
初始情况下，由于未向任何事务分配任何 `Undo` 页面链表，所以对于一个 `Rollback Segment Header` 页面来说，它的各个 `undo slot`  都被设置成一个特殊的值 `FIL_NULL`，对应的十六进制就是 `0xFFFFFFFF`，表示该 `undo slot` 不指向任何页面。
开始有事务需要分配 `Undo` 页面链表时，就从回滚段的第一个 `undo slot` 开始，看看该 `undo slot` 的值是不是 `FIL_NULL`：
- 如果是 `FIL_NULL`，那么在表空间中新创建 `Undo Log Segment`，然后从段里申请一个页面作为 `Undo` 页面链表的 `first undo page`，然后把该 `undo slot` 的值设置为刚刚申请的这个页面的页号，这样也就意味着这个 `undo slot` 被分配给这个事务。
- 如果不是 `FIL_NULL`，说明该 `undo slot` 已经指向一个 `undo` 链表，也就是说这个 `undo slot` 已经被别的事务占用，那就跳到下一个 `undo slot` 继续判断，重复上边的步骤。
一个 `Rollback Segment Header` 页面中包含 1024 个 `undo slot`，如果这 1024 个 `undo slot` 的值都不为 `FIL_NULL`，这就意味着这 1024 个 `undo slot` 都已经被分配给某个事务，此时由于新事务无法再获得新的 `Undo` 页面链表，就会回滚这个事务并且给用户报错。
当一个事务提交时，它所占用的 `undo slot` 有两种可能：
- 如果该 `undo slot` 指向的 `Undo` 页面链表符合被重用的条件，则该 `undo slot` 就处于被缓存的状态，`InnoDB` 规定这时该 `Undo` 页面链表的 `TRX_UNDO_STATE` 属性会被设置为 `TRX_UNDO_CACHED`。被缓存的 `undo slot` 都会被加入到一个链表，根据对应的 `Undo` 页面链表的类型不同，也会被加入到不同的链表：
  - 如果对应的 `Undo` 页面链表是 `insert undo` 链表，则该 `undo slot` 会被加入 `insert undo cached` 链表。
  - 如果对应的 `Undo` 页面链表是 `update undo` 链表，则该 `undo slot` 会被加入 `update undo cached` 链表。
一个回滚段就对应着上述两个 `cached` 链表，如果有新事务要分配 `undo slot` 时，先从对应的 `cached` 链表中找。如果没有被缓存的 `undo slot`，才会到回滚段的 `Rollback Segment Header` 页面中再去找。
- 如果该 `undo slot` 指向的 `Undo` 页面链表不符合被重用的条件，那么针对该  `undo slot`  对应的 `Undo` 页面链表类型不同，也会有不同的处理：
  - `insert undo`，则该 `Undo` 页面链表的 `TRX_UNDO_STATE` 属性会被设置为 `TRX_UNDO_TO_FREE`，之后该 `Undo` 页面链表对应的段会被释放掉，然后把该 `undo slot` 的值设置为 `FIL_NULL`。
  - `update undo`，则该 `Undo` 页面链表的 `TRX_UNDO_STATE` 属性会被设置为  `TRX_UNDO_TO_PRUGE`，则会将该 `undo slot` 的值设置为 `FIL_NULL`，然后将本次事务写入的一组 `undo` 日志放到 `History` 链表中，这里并不会将 `Undo` 页面链表对应的段给释放掉，因为这些 `undo` 日志还有用。
### 多个回滚段
`InnoDB` 定义 128 个回滚段，一个回滚段里有 `1024` 个 `undo slot`。假设一个读写事务执行过程中只分配 1 个 `Undo` 页面链表，那么就可以同时支持 131072 个这样的读写事务并发执行，而只读事务并不需要分配 `Undo` 页面链表。
每个回滚段都对应着一个 `Rollback Segment Header` 页面，则有 128 个 `Rollback Segment Header` 页面，`InnoDB` 在系统表空间的第 5 号页面的某个区域包含 128 个 8 字节大小的格子记录这些页面的位置：
![image-20230125220220155](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220220155.png)
每个 8 字节的格子的构造就像这样：
![image-20230125220225556](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220225556.png)
如果所示，每个 8 字节的格子其实由两部分组成：
- 4 字节大小的 `Space ID`，代表一个表空间的 `ID`。
- 4 字节大小的 `Page number`，代表一个页号。
也就是说每个 8 字节大小的格子相当于一个指针，指向某个表空间中的某个页面，这些页面就是 `Rollback Segment Header`，要定位一个 `Rollback Segment Header` 还需要知道对应的表空间 `ID`，这也就意味着不同的回滚段可能分布在不同的表空间中。
因此在系统表空间的第 5 号页面中存储 128 个 `Rollback Segment Header` 页面地址，每个 `Rollback Segment Header` 就相当于一个回滚段。在 `Rollback Segment Header` 页面中，又包含1024个 `undo slot`，每个 `undo slot` 都对应一个 `Undo` 页面链表：
![image-20230125220231344](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125220231344.png)
### 回滚段的分类
把这 128 个回滚段编一下号，这 128 个回滚段可以被分成两大类：
- 第 0 号、第 33～127 号回滚段属于一类。其中第 0 号回滚段必须在系统表空间中，第33～127号回滚段既可以在系统表空间中，也可以在自己配置的 `undo` 表空间中。如果一个事务在执行过程中由于对普通表的记录做改动需要分配 `Undo` 页面链表时，必须从这一类的段中分配相应的 `undo slot`。
- 第 1～32 号回滚段属于一类，这些回滚段必须在临时表空间，对应着数据目录中的 `ibtmp1` 文件中。如果一个事务在执行过程中由于对临时表的记录做改动需要分配 `Undo` 页面链表时，必须从这一类的段中分配相应的 `undo slot`。
也就是说如果一个事务在执行过程中既对普通表的记录做改动，又对临时表的记录做改动，那么需要为这个记录分配 2 个回滚段，再分别到这两个回滚段中分配对应的 `undo slot`。
针对普通表和临时表划分不同种类的回滚段的原因是，在修改针对普通表的回滚段中的 `Undo` 页面时，需要记录对应的 `redo` 日志，但是对于临时表来说，因为修改临时表而产生的 `undo` 日志只需要在系统运行过程中有效，如果系统奔溃，那么在重启时也不需要恢复这些 `undo` 日志所在的页面，所以修改针对临时表的回滚段中的 `Undo` 页面时，不需要记录对应的 `redo` 日志。
### 为事务分配 Undo 页面链表详细过程
事务执行过程中分配 `Undo` 页面链表时的完整过程，
- 事务在执行过程中对普通表的记录首次做改动之前，首先会到系统表空间的第 5 号页面中分配一个回滚段，即获取一个 `Rollback Segment Header` 页面的地址。一旦某个回滚段被分配给这个事务，那么之后该事务中再对普通表的记录做改动时，就不会重复分配。
- 在分配到回滚段后，首先看一下这个回滚段的两个 `cached` 链表有没有已经缓存的 `undo slot`，比如如果事务做的是 `INSERT` 操作，就去回滚段对应的 `insert undo cached` 链表中看看有没有缓存的 `undo slot`。如果有缓存的 `undo slot`，那么就把这个缓存的 `undo slot`分配给该事务。如果没有缓存的 `undo slot` 可供分配，那么就要到 `Rollback Segment Header`  页面中找一个可用的 `undo slot` 分配给当前事务。
- 找到可用的 `undo slot` 后，如果该 `undo slot` 是从 `cached` 链表中获取的，那么它对应的 `Undo Log Segment` 已经分配，否则的话需要重新分配一个 `Undo Log Segment`，然后从该 `Undo Log Segment` 中申请一个页面作为 `Undo` 页面链表的 `first undo page`。
- 然后事务就可以把 `undo` 日志写入到上边申请的 `Undo` 页面链表！
对临时表的记录做改动的步骤和上述的一样，如果一个事务在执行过程中既对普通表的记录做改动，又对临时表的记录做改动，那么需要为这个记录分配 2 个回滚段。
并发执行的不同事务其实可以被分配相同的回滚段，只要分配不同的 `undo slot` 就可以。
## 回滚段相关配置
### 配置回滚段数量
前边说系统中一共有128个回滚段，其实这只是默认值，可以通过启动参数innodb_rollback_segments来配置回滚段的数量，可配置的范围是1~128。但是这个参数并不会影响针对临时表的回滚段数量，针对临时表的回滚段数量一直是32，也就是说：
- 如果把innodb_rollback_segments的值设置为1，那么只会有1个针对普通表的可用回滚段，但是仍然有32个针对临时表的可用回滚段。
- 如果把innodb_rollback_segments的值设置为2～33之间的数，效果和将其设置为1是一样的。
- 如果把innodb_rollback_segments设置为大于33的数，那么针对普通表的可用回滚段数量就是该值减去32。
### 配置 `undo` 表空间
默认情况下，针对普通表设立的回滚段（第0号以及第33~127号回滚段）都是被分配到系统表空间的。其中的第第0号回滚段是一直在系统表空间的，但是第33~127号回滚段可以通过配置放到自定义的 `undo` 表空间中。但是这种配置只能在系统初始化（创建数据目录时）的时候使用，一旦初始化完成，之后就不能再次更改了。看一下相关启动参数：
- 通过innodb_undo_directory指定 `undo` 表空间所在的目录，如果没有指定该参数，则默认 `undo` 表空间所在的目录就是数据目录。
- 通过innodb_undo_tablespaces定义 `undo` 表空间的数量。该参数的默认值为0，表明不创建任何 `undo` 表空间。
第33~127号回滚段可以平均分布到不同的 `undo` 表空间中。
如果在系统初始化的时候指定了创建了 `undo` 表空间，那么系统表空间中的第0号回滚段将处于不可用状态。
比如在系统初始化时指定的innodb_rollback_segments为35，innodb_undo_tablespaces为2，这样就会将第33、34号回滚段分别分布到一个 `undo` 表空间中。
设立 `undo` 表空间的一个好处就是在 `undo` 表空间中的文件大到一定程度时，可以自动的将该 `undo` 表空间截断（truncate）成一个小文件。而系统表空间的大小只能不断的增大，却不能截断。