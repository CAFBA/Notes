## redo 日志
在真正访问页面之前，需要把在磁盘上的页缓存到内存中的 `Buffer Pool` 之后才可以访问，但如果在事务提交后突然发生某个故障，导致内存中的数据都失效，那么已经提交的事务对数据库中所做的更改也就跟着丢失。
为防止断电导致数据丢失的问题，当有一条记录需要更新的时候，`InnoDB` 引擎会将本次对这个页的修改以 `redo log` 的形式记录下来。在事务提交时，把 `redo` 日志记录的内容刷新到磁盘中，即使之后系统崩溃，重启之后只要按照所记录的步骤重新更新一下数据页，那么该事务对数据库中所做的修改又可以被恢复出来，也就意味着满足持久性的要求。
这就是  `Write-Ahead Logging`。`WAL` 指的是，`MySQL` 的写操作并不是立刻写到磁盘上，而是先写日志，然后在合适的时间再写到磁盘上。
为什么需要 `redo log`：
- 实现事务的持久性，能够保证 `MySQL` 在任何时间段突然崩溃，重启后之前已提交的记录都不会丢失。
- `redo` 日志占用的空间非常小：存储表空间 `ID`、页号、偏移量以及需要更新的值所需的存储空间是很小的。
- `redo` 日志是顺序写入磁盘的：写入 `redo log` 的方式使用追加操作，这些日志是按照产生的顺序写入磁盘的，也就是使用顺序 `IO`，而写入数据需要先找到写入位置，然后才写到磁盘，所以磁盘操作是随机 `IO`。
### redo 日志格式
`redo` 日志本质上只是记录事务对数据库的修改。绝大部分类型的 `redo` 日志都有下边这种通用的结构：
![image-20230125201548228](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125201548228.png)
#### 简单的 redo 日志类型
如果没有为某个表显式的定义主键，并且表中也没有定义 `Unique` 键，那么 `InnoDB` 会自动的为表添加一个称之为 `row_id` 的隐藏列作为主键。为这个 `row_id` 隐藏列赋值的方式如下：
- 服务器会在内存中维护一个全局变量，每当向某个包含隐藏的 `row_id` 列的表中插入一条记录时，就会把该变量的值当作新记录的 `row_id` 列的值，并且把该变量自增 1。
- 每当这个变量的值为 `256` 的倍数时，就会将该变量的值刷新到系统表空间的页号为 7 的页面中一个称之为 `Max Row ID` 的属性处，这个属性占用的存储空间是 8 个字节。
- 当系统启动时，会将上边提到的 `Max Row ID` 属性加载到内存中，将该值加上 `256` 之后赋值给前边提到的全局变量，因为在上次关机时该全局变量的值可能大于 `Max Row ID` 属性值。
而这个写入实际上是在 `Buffer Pool` 中完成的，因此需要为这个页面的修改记录一条 `redo` 日志，以便在系统崩溃后能将已经提交的该事务对该页面所做的修改恢复出来。这种情况下对页面的修改是极其简单的，`redo` 日志中只需要记录一下在某个页面的某个偏移量处修改几个字节的值，具体被修改的内容，`InnoDB` 把这种极其简单的 `redo` 日志称之为物理日志，并且根据在页面中写入数据的多少划分几种不同的 `redo` 日志类型：
- `MLOG_1BYTE`：`type` 字段对应的十进制数字为 1，表示在页面的某个偏移量处写入 1 个字节的 `redo` 日志类型。
- `MLOG_2BYTE`：`type` 字段对应的十进制数字为 2，表示在页面的某个偏移量处写入 2 个字节的`redo`日志类型。
- `MLOG_4BYTE`：`type` 字段对应的十进制数字为 4，表示在页面的某个偏移量处写入 4 个字节的`redo`日志类型。
- `MLOG_8BYTE`：`type` 字段对应的十进制数字为 8，表示在页面的某个偏移量处写入 8 个字节的`redo`日志类型。
- `MLOG_WRITE_STRING`：`type` 字段对应的十进制数字为 30，表示在页面的某个偏移量处写入一串数据。
`Max Row ID` 属性实际占用 8 个字节的存储空间，所以在修改页面中的该属性时，会记录一条类型为 `MLOG_8BYTE` 的 `redo` 日志，`MLOG_8BYTE` 的 `redo` 日志结构如下所示：
![image-20230125201555586](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125201555586.png)
其余的和 `MLOG_8BYTE` 类似，只不过具体数据中包含对应个字节的数据。
`MLOG_WRITE_STRING` 类型的 `redo` 日志表示写入一串数据，但是因为不能确定写入的具体数据占用多少字节，所以需要在日志结构中添加一个 len 字段：
![image-20230125201624326](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125201624326.png)
只要将 `MLOG_WRITE_STRING` 类型的 `redo` 日志的 `len` 字段填充上 1、2、4、8 这些数字，就可以分别替代这些类型的 `redo` 日志，是因为省空间，能不写 `len` 字段就不写 `len` 字段。
#### 复杂一些的 `redo` 日志类型
有时候执行一条语句会修改非常多的页面，以一条 `INSERT` 语句为例，不但要向 `B+` 树的页面中插入数据，也可能更新系统数据 `Max Row ID` 的值：
- 表中包含多少个索引，一条 `INSERT` 语句就可能更新多少棵 `B+` 树。
- 针对某一棵 `B+` 树来说，既可能更新叶子节点页面，也可能更新内节点页面，也可能创建新的页面,在该记录插入的叶子节点的剩余空间比较少，不足以存放该记录时，会进行页面的分裂，在内节点页面中添加目录项记录。
在语句执行过程中，`INSERT` 语句对所有页面的修改都得保存到 `redo` 日志中去，而且一个数据页中除存储实际的记录，还有 `File Header`、`Page Header`、`Page Directory` 等等部分，所以每往叶子节点代表的数据页里插入一条记录时，还有其他很多地方会跟着更新，比如说：
- 可能更新 `Page Directory` 中的槽信息。
- `Page Header` 中的各种页面统计信息，比如 `PAGE_N_DIR_SLOTS` 表示的槽数量可能会更改， `PAGE_HEAP_TOP` 代表的还未使用的空间最小地址可能会更改，`PAGE_N_HEAP` 代表的本页面中的记录数量可能会更改，各种信息都可能会被修改。
- 在数据页里的记录是按照索引列从小到大的顺序组成一个单向链表的，每插入一条记录，还需要更新上一条记录的记录头信息中的 `next_record` 属性来维护这个单向链表。 
正因为上述两种使用物理 `redo` 日志的方式来记录某个页面中做哪些修改比较浪费，InnoDB 提出新的 `redo` 日志类型，比如：
- `MLOG_REC_INSERT`：`type` 字段对应的十进制数字为 9，表示插入一条使用非紧凑行格式的记录时的 `redo` 日志类型。
- `MLOG_COMP_REC_INSERT`：`type` 字段对应的十进制数字为 38，表示插入一条使用紧凑行格式的记录时的 `redo` 日志类型。`Redundant` 是一种比较原始的行格式，它就是非紧凑的。而 `Compact/Dynamic/Compressed` 行格式是较新的行格式，它们是紧凑的。
- `MLOG_COMP_PAGE_CREATE`：`type` 字段对应的十进制数字为 58，表示创建一个存储紧凑行格式记录的页面的 `redo` 日志类型。
- `MLOG_COMP_REC_DELETE`：`type` 字段对应的十进制数字为 42，表示删除一条使用紧凑行格式记录的 `redo` 日志类型。
- `MLOG_COMP_LIST_START_DELETE`：`type` 字段对应的十进制数字为 44，表示从某条给定记录开始删除页面中的一系列使用紧凑行格式记录的 `redo` 日志类型。
- `MLOG_COMP_LIST_END_DELETE`：`type` 字段对应的十进制数字为 43，与上一类型的 `redo` 日志呼应，表示删除一系列记录直到 `MLOG_COMP_LIST_END_DELETE` 类型的 `redo` 日志对应的记录为止。
数据页中的记录是按照索引列大小的顺序组成单向链表的。有时候会有删除索引列的值在某个区间范围内的所有记录的需求，这时候如果每删除一条记录就写一条 `redo` 日志的话，效率可能有点低，所以提出上述两种类型的 `redo` 日志，可以很大程度上减少 `redo` 日志的条数。
- `MLOG_ZIP_PAGE_COMPRESS`：`type` 字段对应的十进制数字为 51，表示压缩一个数据页的 `redo` 日志类型。
这些类型的 `redo` 日志既包含物理层面的意思，也包含逻辑层面的意思，具体指：
- 物理层面看，这些日志都指明对哪个表空间的哪个页进行修改。
- 逻辑层面看，在系统崩溃重启时，并不能直接根据这些日志里的记载，将页面内的某个偏移量处恢复成某个数据，而是需要调用一些事先准备好的函数，执行完这些函数后才可以将页面恢复成系统崩溃前的样子。
以类型为 `MLOG_COMP_REC_INSERT` 这个代表插入一条使用紧凑行格式的记录时的 `redo` 日志为例：
![image-20230125203949265](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125203949265.png)
- 在一个数据页里，不论是叶子节点还是非叶子节点，记录都是按照索引列从小到大的顺序排序的。对于二级索引来说，当索引列的值相同时，记录还需要按照主键值进行排序。图中 `n_uniques` 的值的含义是在一条记录中，需要几个字段的值才能确保记录的唯一性，这样当插入一条记录时就可以按照记录的前 `n_uniques` 个字段进行排序。对于聚簇索引来说，`n_uniques` 的值为主键的列数，对于其他二级索引来说，该值为索引列数+主键列数。这里需要注意的是，唯一二级索引的值可能为 `NULL`，所以该值仍然为索引列数+主键列数。
- `field1_len~fieldn_len` 代表着该记录若干个字段占用存储空间的大小，这里不管该字段的类型是固定长度大小的，还是可变长度大小的，该字段占用的大小始终要写入 `redo` 日志中。
- `offset` 代表的是该记录的前一条记录在页面中的地址。为啥要记录前一条记录的地址呢？这是因为每向数据页插入一条记录，都需要修改该页面中维护的记录链表，每条记录的记录头信息中都包含一个称为 `next_record` 的属性，所以在插入新记录时，需要修改前一条记录的 `next_record` 属性。
- 一条记录其实由额外信息和真实数据这两部分组成，这两个部分的总大小就是一条记录占用存储空间的总大小。通过 `end_seg_len` 的值可以间接的计算出一条记录占用存储空间的总大小。
- 写 `redo` 日志是一个非常频繁的操作，`InnoDB` 想减小`redo` 日志本身占用的存储空间大小，所以 `end_seg_len` 这个字段就是为节省 `redo` 日志存储空间而提出来的。`mismatch_index` 的值也是为节省 `redo` 日志的大小而设立的。
这个类型 `MLOG_COMP_REC_INSERT` 的 `redo` 日志并没有记录值修改为什么，而只是把在本页面中插入一条记录所有必备的要素记下来，之后系统崩溃重启时，服务器会调用相关向某个页面插入一条记录的那个函数，而 `redo` 日志中的那些数据就可以被当成是调用这个函数所需的参数，在调用完该函数后，页面中的 `PAGE_N_DIR_SLOTS`、`PAGE_HEAP_TOP`、`PAGE_N_HEAP` 等等的值也就都被恢复到系统崩溃前的样子，这就是所谓的逻辑日志的意思。
综上，`redo` 日志会把事务在执行过程中对数据库所做的所有修改都记录下来，在之后系统崩溃重启后可以把事务所做的任何修改都恢复出来。
### 以组的形式写入redo日志
语句在执行过程中可能修改若干个页面。由于对这些页面的更改都发生在 `Buffer Pool` 中，所以在修改完页面之后，需要记录一下相应的 `redo` 日志。
以向某个索引对应的 `B+` 树插入一条记录为例，在向 `B+` 树中插入这条记录之前，需要先定位到这条记录应该被插入到哪个叶子节点代表的数据页中，定位到具体的数据页之后，有两种可能的情况：
- 情况一：该数据页的剩余的空闲空间充足，足够容纳这一条待插入记录，那么直接把记录插入到这个数据页中，记录一条类型为 `MLOG_COMP_REC_INSERT` 的 `redo` 日志，把这种情况称之为乐观插入。
- 情况二：该数据页剩余的空闲空间不足，那么遇到这种情况要进行所谓的页分裂操作，也就是新建一个叶子节点，然后把原先数据页中的一部分记录复制到这个新的数据页中，然后再把记录插入进去，把这个叶子节点插入到叶子节点链表中，最后还要在内节点中添加一条目录项记录指向这个新创建的页面。由于需要新申请数据页，还需要改动一些系统页面，比方说要修改各种段、区的统计信息信息，各种链表的统计信息，这个过程要对多个页面进行修改，也就意味着会产生多条 `redo` 日志，把这种情况称之为悲观插入。
`InnoDB` 认为向某个索引对应的 `B+` 树中插入一条记录的这个过程必须是原子的。`redo` 日志是为在系统崩溃重启时恢复崩溃前的状态，如果在悲观插入的过程中只记录一部分 `redo` 日志，那么在系统崩溃重启时会将索引对应的 `B+` 树恢复成一种不正确的状态。
所以规定在执行这些需要保证原子性的操作时必须以组的形式来记录 `redo` 日志，在进行系统崩溃重启恢复时，针对某个组中的 `redo` 日志，要么把全部的日志都恢复掉，要么一条也不恢复。这得分情况讨论：
- 有的需要保证原子性的操作会生成多条 `redo` 日志，比如向某个索引对应的 `B+` 树中进行一次悲观插入就需要生成许多条 `redo` 日志。
`InnoDB` 会在该组中的最后一条 `redo` 日志后边加上一条特殊类型的 `redo` 日志，该类型名称为 `MLOG_MULTI_REC_END`，`type` 字段对应的十进制数字为 31，该类型的 `redo` 日志只有一个 `type` 字段。所以某个需要保证原子性的操作产生的一系列 `redo` 日志必须要以一个类型为 `MLOG_MULTI_REC_END` 结尾：
![image-20230124151347185](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230124151347185.png)
这样在系统崩溃重启进行恢复时，只有当解析到类型为 `MLOG_MULTI_REC_END` 的 `redo` 日志，才认为解析到一组完整的 `redo` 日志，才会进行恢复，否则的话直接放弃之前解析到的 `redo` 日志。
- 有的需要保证原子性的操作只生成一条 `redo` 日志，比如更新 `Max Row ID` 属性的操作就只会生成一条 `redo` 日志，但更新 `Max Row ID` 属性时产生的 `redo` 日志是不可分割的。
用 7 个比特位就足以包括所有的 `redo` 日志类型，而 type 字段占用 1 个字节，也就是说可以省出来一个比特位用来表示该需要保证原子性的操作只产生单一的一条 `redo` 日志：
![image-20230124151339297](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230124151339297.png)
如果 `type` 字段的第一个比特位为 1，代表该需要保证原子性的操作只产生单一的一条 `redo` 日志，否则表示该需要保证原子性的操作产生一系列的 `redo` 日志。
### Mini-Transaction
对底层页面中的一次原子访问的过程称之为一个 `Mini-Transaction`，简称 `mtr`，比如修改一次 `Max Row ID` 的值是一个 `mtr`，向某个索引对应的 `B+` 树中插入一条记录的过程也是一个 `mtr`。一个 `mtr` 包含一组 `redo` 日志，在进行崩溃恢复时这一组 `redo` 日志作为一个不可分割的整体。
一个事务包含若干条语句，每一条语句其实是由若干个 `mtr` 组成，每一个 `mtr` 又包含若干条 `redo` 日志：
![image-20230124151333138](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230124151333138.png)
###  redo 日志的写入过程
####  redo log block
`InnoDB` 为更好的进行系统崩溃恢复，把通过 `mtr` 生成的 `redo` 日志都放在大小为 512 字节的页中。为和表空间中的页做区别，这里把用来存储 `redo` 日志的页称为 `block`。
![image-20230125205734716](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205734716.png)
真正的 `redo` 日志都是存储到占用 496 字节大小的 `log block body` 中，图中的 `log block header` 和 `log block trailer` 存储的是一些管理信息：
![image-20230125205742223](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205742223.png)
- `LOG_BLOCK_HDR_NO`：每一个 `block` 都有一个大于 0 的唯一标号，本属性就表示该标号值。
- `LOG_BLOCK_HDR_DATA_LEN`：表示 `block` 中已经使用多少字节，因为 `log block body` 从第 12 个字节处开始，初始值为 12。随着往 `block` 中写入的 `redo` 日志越来也多，本属性值也跟着增长。如果 `log block body` 已经被全部写满，那么本属性的值被设置为 512。
- `LOG_BLOCK_FIRST_REC_GROUP`：一条 `redo` 日志也可以称之为一条 `redo` 日志记录，一个 `mtr` 会生产多条 `redo` 日志记录，这些 `redo` 日志记录被称之为一个 `redo` 日志记录组。`LOG_BLOCK_FIRST_REC_GROUP` 就代表该 `block` 中第一个 `mtr` 生成的 `redo` 日志记录组的偏移量，即这个 `block` 里第一个 `mtr` 生成的第一条 `redo` 日志的偏移量。
- `LOG_BLOCK_CHECKPOINT_NO`：表示 `checkpoint` 的序号
- `LOG_BLOCK_CHECKSUM`：表示 `block` 的校验值，用于正确性校验
#### redo log buffer
`InnoDB` 为解决磁盘速度过慢的问题而引入 `Buffer Pool`。同理，写入 `redo` 日志时也不能直接直接写到磁盘上，在服务器启动时会向操作系统申请一大片称之为 `redo log buffer` 的连续内存空间，这片内存空间被划分成若干个连续的 `redo log block`：
![image-20230125230140979](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230140979.png)
向 `log buffer` 中写入 `redo` 日志的过程是顺序的，先往前边的 `block` 中写，当该 `block` 的空闲空间用完之后再往下一个 `block` 中写，`InnoDB` 提供 `buf_free` 全局变量指明后续写入的 `redo` 日志应该写入到 `log buffer` 中的哪个位置，如图所示：
![image-20230125205750823](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205750823.png)
一个 `mtr` 执行过程中可能产生若干条 `redo` 日志，这些 `redo` 日志是一个不可分割的组，每个 `mtr` 运行过程中产生的日志会先暂时存到一个地方，当该 `mtr` 结束的时候，将过程中产生的一组 `redo` 日志再全部复制到 `log buffer` 中。
假设有两个名为 `T1`、`T2` 的事务，每个事务都包含 2 个 `mtr`，每个 `mtr` 都会产生一组`redo`日志，用示意图来描述一下这些mtr产生的日志情况：
![image-20230125205759011](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205759011.png)
不同的事务可能是并发执行的，所以 `T1`、`T2` 之间的 `mtr` 可能是交替执行的。每当一个 `mtr` 执行完成时，伴随该 `mtr` 生成的一组 `redo` 日志就需要被复制到 `log buffer` 中，也就是说不同事务的 `mtr` 可能是交替写入 `log buffer`：
![image-20230125205806115](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205806115.png)
从示意图中可以看出来，不同的 `mtr` 产生的一组 `redo` 日志占用的存储空间可能不一样。
###  redo 日志刷盘时机
`mtr` 运行过程中产生的一组 `redo` 日志在 `mtr` 结束时会被复制到 `log buffer` 中，在一些情况下它们会被刷新到磁盘里，比如：
- `log buffer` 空间不足时：`log buffer` 的大小是有限的，如果当前写入 `log buffer` 的 `redo` 日志量已经占满 `log buffer` 总容量的大约一半左右，就需要把这些日志刷新到磁盘上。
- 事务提交时：之所以使用 `redo` 日志主要是因为它占用的空间少，还是顺序写，在事务提交时可以不把修改过的 `Buffer Pool` 页面刷新到磁盘，但是为保证持久性，必须要把修改这些页面对应的 `redo` 日志刷新到磁盘。
- 将某个脏页刷新到磁盘前，会保证先将该脏页对应的 `redo` 日志刷新到磁盘中，`redo` 日志是顺序刷新的，所以在将某个脏页对应的 `redo` 日志从 `redo log buffer`  刷新到磁盘时，也会保证将在其之前产生的 `redo` 日志也刷新到磁盘。
- 后台有一个线程，大约每秒都会刷新一次 `log buffer` 中的 `redo` 日志到磁盘；正常关闭服务器时；做 `checkpoint` 时；
为保证事务的持久性，用户线程在事务提交时需要将该事务执行过程中产生的所有 `redo` 日志都刷新到磁盘上。这会很明显的降低数据库性能。如果对事务的持久性要求不是那么强烈的话，可以选择修改一个称为 `innodb_flush_log_at_trx_commit` 的系统变量的值：
- 0：表示每次事务提交时 ，还是将 `redo log` 留在 `redo log buffer` 中 ，该模式下在事务提交时不会主动触发写入磁盘的操作。
- 1：表示在事务提交时需要将 `redo` 日志同步到磁盘，可以保证事务的持久性，1 也是默认值。
- 2：表示每次事务提交时，将 `redo log buffer` 里的 `redo log` 写到 `redo log` 文件，即写到操作系统的文件缓存 `Page Cache`。
`InnoDB` 的后台线程每隔 1 秒：
- 针对参数 0：会把缓存在 `redo log buffer` 中的 `redo log`，通过调用 `write()` 写到操作系统的 `Page Cache`，然后调用 `fsync()` 持久化到磁盘。所以参数为 0 的策略，MySQL 进程的崩溃会导致上一秒钟所有事务数据的丢失。
- 针对参数 2：调用 `fsync`，将缓存在操作系统中 `Page Cache` 里的 `redo log` 持久化到磁盘。所以参数为 2 的策略，较取值为 0 情况下更安全，因为 `MySQL` 进程的崩溃并不会丢失数据，只有在操作系统崩溃或者系统断电的情况下，上一秒钟所有事务数据才可能丢失。
这三个参数的数据安全性和写入性能的比较如下：
- 数据安全性：参数 1 > 参数 2 > 参数 0
- 写入性能：参数 0 > 参数 2 > 参数 1
所以，要不追求数据安全性，牺牲性能；要不追求性能，牺牲数据安全性。
- 在一些对数据安全性要求比较高的场景中，显然 `innodb_flush_log_at_trx_commit` 参数需要设置为 1。
- 在一些可以容忍数据库崩溃时丢失 1s 数据的场景中，可以将该值设置为 0，这样可以明显地减少日志同步到磁盘的 `I/O` 操作。
- 安全性和性能折中的方案就是参数 2，虽然参数 2 没有参数 0 的性能高，但是数据安全性方面比参数 0 强，因为参数 2 只要操作系统不宕机，即使数据库崩溃了，也不会丢失数据，同时性能方便比参数 1 高。
### redo 日志文件
#### redo 日志文件组
磁盘上的 `redo` 日志文件不只一个，而是以一个日志文件组的形式出现的。这些文件以 `ib_logfile[数字]` 的形式进行命名。
默认情况下，`InnoDB` 存储引擎有 1 个重做日志文件组，即 `MySQL` 的数据目录下默认两个名为 `ib_logfile0` 和 `ib_logfile1` 的文件，`log buffer` 中的日志默认情况下就是刷新到这两个磁盘文件中，可以通过下边几个启动参数来调节：
- `innodb_log_group_home_dir`：指定 `redo` 日志文件所在的目录，默认值就是当前的数据目录。
- `innodb_log_file_size`：指定每个 `redo` 日志文件的大小。
- `innodb_log_files_in_group`：指定 `redo` 日志文件的个数，默认值为 2，最大值为100。
总共的 `redo` 日志文件大小是：`innodb_log_file_size × innodb_log_files_in_group`。
重做日志文件组是以循环写的方式工作的，所以在将 `redo` 日志写入日志文件组时，从 `ib_logfile0` 开始写，如果 `ib_logfile0` 写满，就接着 `ib_logfile1` 写，依此类推，如果写到最后一个文件那就重新转到 `ib_logfile0` 继续写。
#### redo 日志文件格式
`log buffer` 本质上是一片连续的内存空间，被划分成若干个 512 字节大小的 `block`。将 `log buffer` 中的 `redo` 日志刷新到磁盘的本质就是把 `block` 的镜像写入日志文件中，所以 `redo` 日志文件也是由若干个 512 字节大小的 `block` 组成。
`redo` 日志文件组中的每个文件大小都一样，格式也一样，都是由两部分组成：
- 前 2048 个字节，也就是前 4 个 `block` 用来存储一些管理信息。
- 从第 2048 字节往后用来存储 `log buffer` 中的 `block` 镜像。
所以循环使用 `redo` 日志文件，其实是从每个日志文件的第 2048 个字节开始算：
![image-20230125205827797](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205827797.png)
普通 `block` 的格式就是 `log block header`、`log block body`、`log block trialer` 这三个部分。
每个 `redo` 日志文件前 2048 个字节，也就是前 4 个特殊 block 的格式为：
![image-20230125205832434](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205832434.png)
`log file header`：描述该 `redo` 日志文件的一些整体属性，它的结构：
![image-20230125205836656](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205836656.png)
各个属性的具体释义如下：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240308150559.png)
`checkpoint1`：记录关于 `checkpoint` 的一些属性，它的结构：
![image-20230125205842546](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205842546.png)
各个属性的具体释义如下：![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240308150618.png)第三个 `block` 未使用，忽略
`checkpoint2`：结构和 `checkpoint1` 一样。
### Log Sequence Number
自系统开始运行，就不断的在修改页面，也就意味着会不断的生成 `redo` 日志。为记录已经写入的 `redo` 日志量，设计 `Log Sequence Number` 全局变量，即日志序列号 `lsn`。规定初始的 `lsn` 值为 8704。
向 `log buffer` 中写入 `redo` 日志时是以一个 `mtr` 生成的一组 `redo` 日志为单位进行写入，把日志内容写在 `log block body` 处。但是在统计 `lsn` 的增长量时，是按照实际写入的日志量加上占用的 `log block header` 和 `log block trailer` 来计算的。
系统第一次启动后初始化 `log buffer` 时，`buf_free` (标记下一条 `redo` 日志应该写入到 `log buffer` 的位置的变量)就会指向第一个 `block` 的偏移量为 12 字节(`log block header` 的大小)的地方，那么 `lsn` 值也会跟着增加 12：
![image-20230125205851223](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205851223.png)
如果某个 `mtr` 产生的一组 `redo` 日志占用的存储空间比较小，也就是待插入的 `block` 剩余空闲空间能容纳这个 `mtr` 提交的日志时，`lsn` 增长的量就是该 `mtr` 生成的 `redo` 日志占用的字节数：
![image-20230125205856864](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205856864.png)
假设上图中 `mtr_1` 产生的 `redo` 日志量为 200 字节，那么 `lsn` 就要在 8716 的基础上增加 200，变为 8916。
如果某个 `mtr` 产生的一组 `redo` 日志占用的存储空间比较大，也就是待插入的 `block` 剩余空闲空间不足以容纳这个 `mtr` 提交的日志时，`lsn` 增长的量就是该 `mtr` 生成的 `redo` 日志占用的字节数加上额外占用的 `log block header` 和 `log block trailer` 的字节数：
![image-20230125205902067](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205902067.png)
假设上图中 `mtr_2` 产生的 `redo` 日志量为 1000 字节，为将 `mtr_2` 产生的`redo`日志写入 `log buffer`，不得不额外多分配两个 `block`，所以 `lsn` 的值需要在 8916 的基础上增加 1000 + 12×2 + 4 × 2 = 1032。
因此每一组由 `mtr` 生成的 `redo` 日志都有一个唯一的 `LSN` 值与其对应，`LSN` 值越小，说明 `redo` 日志产生的越早。
#### flushed_to_disk_lsn
`redo` 日志是首先写到 `log buffer` 中，之后才会被刷新到磁盘上的 `redo` 日志文件。所以有标记当前 `log buffer` 中已经有哪些日志被刷新到磁盘中的全局变量，称之为 `buf_next_to_write`。
![image-20230125205909410](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205909410.png)
`lsn` 是表示当前系统中写入的`redo`日志量，这包括写到 `log buffer` 而没有刷新到磁盘的日志，因此有表示刷新到磁盘中的 `redo` 日志量的全局变量，称之为 `flushed_to_disk_lsn`。系统第一次启动时，该变量的值和初始的 lsn 值是相同的，都是 8704。
当有新的 `redo` 日志写入到 `log buffer` 时，首先 `lsn` 的值会增长，但 `flushed_to_disk_lsn` 不变，随后随着不断有 `log buffer` 中的日志被刷新到磁盘上，`flushed_to_disk_lsn` 的值也跟着增长。如果两者的值相同时，说明 `log buffer` 中的所有 `redo` 日志都已经刷新到磁盘中。
应用程序向磁盘写入文件时其实是先写到操作系统的缓冲区中去，如果某个写入操作要等到操作系统确认已经写到磁盘时才返回，那需要调用一下操作系统提供的 `fsync` 函数，因此只有当系统执行 `fsync` 函数后，`flushed_to_disk_lsn` 的值才会跟着增长，当仅仅把 `log buffer` 中的日志写入到操作系统缓冲区却没有显式的刷新到磁盘时，另外的一个称之为 `write_lsn` 的值跟着增长。
#### lsn 值和 redo 日志文件偏移量
因为 `lsn` 的值是代表系统写入的 `redo` 日志量的一个总和，一个 `mtr` 中产生多少日志，`lsn` 的值就增加多少，这样 `mtr` 产生的日志写到磁盘中时，很容易计算某一个 `lsn` 值在 `redo` 日志文件组中的偏移量，如图：
![image-20230125205916593](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125205916593.png)
初始时的 `LSN` 值是 `8704`，对应文件偏移量 `2048`，之后每个 `mtr` 向磁盘中写入多少字节日志，`lsn` 的值就增长多少。
#### flush 链表中的 LSN
一个 `mtr` 代表一次对底层页面的原子访问，在访问过程中可能会产生一组不可分割的 `redo` 日志，在 `mtr` 结束时，会把这一组 `redo` 日志写入到 `log buffer` 中。除此之外，在 `mtr` 结束时还会把在 `mtr` 执行过程中可能修改过的页面加入到 `Buffer Pool` 的 `flush` 链表：
![image-20230125212026476](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125212026476.png)
当第一次修改某个缓存在 `Buffer Pool` 中的页面时，就会把这个页面对应的控制块插入到 `flush` 链表的头部，之后再修改该页面时由于它已经在 `flush` 链表中，不会再次插入。在这个过程中会在缓存页对应的控制块中记录两个关于页面何时修改的属性：
- `oldest_modification`：如果某个页面被加载到 `Buffer Pool` 后进行第一次修改，那么就将修改该页面的 `mtr` 开始时对应的 `lsn` 值写入这个属性。
- `newest_modification`：每修改一次页面，都会将修改该页面的 `mtr` 结束时对应的 `lsn` 值写入这个属性，也就是说该属性表示页面最近一次修改后对应的系统 `lsn` 值。
因此，`flush` 链表中的脏页按照页面的第一次修改时间进行排序，也就是按照 `oldest_modification` 代表的 `LSN` 值进行排序，被多次更新的页面不会重复插入到 `flush` 链表中，但是会更新 `newest_modification` 属性的值。
### 查看系统中的各种LSN值
可以使用SHOW ENGINE INNODB STATUS命令查看当前InnoDB存储引擎中的各种LSN值的情况，比如：
```
mysql> SHOW ENGINE INNODB STATUS\G

(...省略前边的许多状态)
LOG
---
Log sequence number 124476971
Log flushed up to   124099769
Pages flushed up to 124052503
Last checkpoint at  124052494
0 pending log flushes, 0 pending chkp writes
24 log i/o's done, 2.00 log i/o's/second
----------------------
(...省略后边的许多状态)
```
其中：
- Log sequence number：代表系统中的lsn值，也就是当前系统已经写入的`redo`日志量，包括写入log buffer中的日志。
- Log flushed up to：代表flushed_to_disk_lsn的值，也就是当前系统已经写入磁盘的`redo`日志量。
- Pages flushed up to：代表flush链表中被最早修改的那个页面对应的oldest_modification属性值。
- Last checkpoint at：当前系统的checkpoint_lsn值。
### LOG_BLOCK_HDR_NO是如何计算的
对于实际存储`redo`日志的普通的log block来说，在log block header处有一个称之为LOG_BLOCK_HDR_NO的属性，说这个属性代表一个唯一的标号。这个属性是初次使用该block时分配的，跟当时的系统lsn值有关。使用下边的公式计算该block的LOG_BLOCK_HDR_NO值：
```
((lsn / 512) & 0x3FFFFFFFUL) + 1
```
它的二进制表示：
![image-20230125212038716](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125212038716.png)
从图中可以看出，0x3FFFFFFFUL对应的二进制数的前2位为0，后30位的值都为1。一个二进制位与0做与运算的结果肯定是0，一个二进制位与1做与运算的结果就是原值。让一个数和0x3FFFFFFFUL做与运算的意思就是要将该值的前2个比特位的值置为0，这样该值就肯定小于或等于0x3FFFFFFFUL了。这也就说明了，不论lsn多大，((lsn / 512) & 0x3FFFFFFFUL)的值肯定在0~0x3FFFFFFFUL之间，再加1的话肯定在1~0x40000000UL之间。而0x40000000UL这个值就代表着1GB。也就是说系统最多能产生不重复的LOG_BLOCK_HDR_NO值只有1GB个。
规定`redo`日志文件组中包含的所有文件大小总和不得超过512GB，一个block大小是512字节，也就是说`redo`日志文件组中包含的block块最多为1GB个，所以有1GB个不重复的编号值也就够用了。
另外，LOG_BLOCK_HDR_NO值的第一个比特位比较特殊，称之为flush bit，如果该值为1，代表着本block是在某次将log buffer中的block刷新到磁盘的操作中的第一个被刷入的block。
## checkpoint
`redo` 日志文件组容量是有限的，不得不选择循环使用 `redo` 日志文件组中的文件，但是这会造成最后写的 `redo` 日志与最开始写的 `redo` 日志追尾，不过 `redo` 日志只是为系统崩溃后恢复脏页用的，如果对应的脏页已经刷新到磁盘，也就是说即使现在系统崩溃，那么在重启后也用不着使用 `redo` 日志恢复该页面。
所以该 `redo` 日志占用的磁盘空间就可以被后续的 `redo` 日志所重用，为此定义全局变量 `checkpoint_lsn` 表示当前系统中可以被覆盖的 `redo` 日志总量是多少，这个变量初始值也是 8704。
比如现在页 `a` 被刷新到磁盘，`mtr_1` 生成的 `redo` 日志就可以被覆盖，所以可以进行一个增加 `checkpoint_lsn` 的操作，把这个过程称之为做一次 `checkpoint`，因此当 `redo` 日志文件组容量不够时，可以进行 `checkpoint` 计算 `checkpoint_lsn`，重用之前占用的磁盘空间。
做一次 `checkpoint` 其实可以分为两个步骤：
- 步骤一：计算一下当前系统中可以被覆盖的 `redo` 日志对应的 `lsn` 值最大是多少。
`redo` 日志可以被覆盖，意味着它对应的脏页被刷到磁盘，只要计算出当前系统中被最早修改的脏页对应的 `oldest_modification` 值，凡是在系统 `lsn` 值小于该节点的 `oldest_modification` 值时产生的 `redo` 日志都是可以被覆盖掉的，就把该脏页的 `oldest_modification` 赋值给 `checkpoint_lsn`。
比如当前系统中页 `a` 已经被刷新到磁盘，那么 `flush` 链表的尾节点就是页 `c`，该节点就是当前系统中最早修改的脏页，它的 `oldest_modification` 值为 8916，就把 8916 赋值给 `checkpoint_lsn`，也就是说在 `redo` 日志对应的 `lsn` 值小于 8916 时就可以被覆盖掉。
- 步骤二：将 `checkpoint_lsn` 和对应的 `redo` 日志文件组偏移量以及此次 `checkpoint` 的编号写到日志文件的管理信息 `checkpoint1` 或 `checkpoint2` 中。
`InnoDB` 维护一个目前系统做多少次 `checkpoint` 的变量 `checkpoint_no`，每做一次 `checkpoint`，该变量的值就加 1。计算一个 `lsn` 值对应的 `redo` 日志文件组偏移量是很容易的，所以可以计算得到该 `checkpoint_lsn` 在 `redo` 日志文件组中对应的偏移量 `checkpoint_offset`，然后把这三个值都写到 `redo` 日志文件组的管理信息中。
每一个 `redo` 日志文件都有 2048 个字节的管理信息，但是上述关于 `checkpoint` 的信息只会被写到日志文件组的第一个日志文件的管理信息中。规定当 `checkpoint_no` 的值是偶数时，就写到 `checkpoint1` 中，是奇数时，就写到 `checkpoint2` 中。
记录完 `checkpoint` 的信息之后，`redo` 日志文件组中各个 `lsn` 值的关系就像这样：
![image-20230125212031530](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125212031530.png)
一般情况下都是后台的线程在对 `LRU` 链表和 `flush` 链表进行刷脏操作，这主要因为刷脏操作比较慢，不想影响用户线程处理请求。但是如果当前系统修改页面的操作十分频繁，这样就导致写日志操作十分频繁，系统 `lsn` 值增长过快。
如果后台的刷脏操作不能将脏页刷出，那么系统无法及时做 `checkpoint`，可能就需要用户线程同步的从 `flush` 链表中把那些最早修改的脏页，即 `oldest_modification` 最小的脏页刷新到磁盘，这样这些脏页对应的 `redo` 日志就没用，然后就可以去做 `checkpoint`。
## 崩溃恢复
### 确定恢复的起点
`checkpoint_lsn` 之前的 `redo` 日志都可以被覆盖，也就是说这些 `redo` 日志对应的脏页都已经被刷新到磁盘中。对于 `checkpoint_lsn` 之后的 `redo` 日志，它们对应的脏页可能没被刷盘，也可能被刷盘，所以需要从 `checkpoint_lsn` 开始读取 `redo` 日志来恢复页面。
`redo` 日志文件组的第一个文件的管理信息中有两个 `block` 都存储 `checkpoint_lsn` 的信息，要选取最近发生的那次 `checkpoint` 的信息，只要把 `checkpoint1` 和 `checkpoint2` 这两个 `block` 中的 `checkpoint_no` 值读出来比一下大小，哪个的 `checkpoint_no` 值更大，说明哪个 `block` 存储的就是最近的一次 `checkpoint` 信息。
这样就能拿到最近发生的 `checkpoint` 对应的 `checkpoint_lsn` 值以及它在 `redo` 日志文件组中的偏移量 `checkpoint_offset`。
### 确定恢复的终点
在写 `redo` 日志的时候都是顺序写的，写满一个 `block` 之后会再往下一个 `block` 中写：
![image-20230125212042865](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125212042865.png)
普通 `block` 的 `log block header` 部分有一个称之为 `LOG_BLOCK_HDR_DATA_LEN` 的属性，记录当前 `block` 里使用多少字节的空间。对于被填满的 `block` 来说，该值永远为 512。如果该属性的值不为 512，那么就是它，它就是此次崩溃恢复中需要扫描的最后一个 `block`。
### 怎么恢复
确定需要扫描哪些 `redo` 日志进行崩溃恢复之后，接下来就是怎么进行恢复。
假设现在的 `redo` 日志文件中有 5 条 `redo` 日志，如图：
![image-20230125212047536](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125212047536.png)
由于 `redo 0` 在 `checkpoint_lsn` 后边，恢复时可以不管它。现在可以按照 `redo` 日志的顺序依次扫描 `checkpoint_lsn` 之后的各条 `redo` 日志，按照日志中记载的内容将对应的页面恢复出来。
一些办法可以加快这个恢复的过程：
- 使用哈希表
根据 `redo` 日志的 `space ID` 和 `page number`属性计算出散列值，把 `space ID` 和 `page number` 相同的 `redo` 日志放到哈希表的同一个槽里，如果有多个 `space ID` 和 `page number` 都相同的 `redo` 日志，那么它们之间使用链表连接起来，按照生成的先后顺序链接起来的，如图所示：
![image-20230125212053500](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125212053500.png)
之后就可以遍历哈希表，因为对同一个页面进行修改的 `redo` 日志都放在了一个槽里，所以可以一次性将一个页面修复好，避免很多读取页面的随机 `IO`，这样可以加快恢复速度。
另外同一个页面的 `redo` 日志是按照生成时间顺序进行排序的，所以恢复的时候也是按照这个顺序进行恢复，如果不按照生成时间顺序进行排序的话，那么可能出现错误。
比如原先的修改操作是先插入一条记录，再删除该条记录，如果恢复时不按照这个顺序来，就可能变成先删除一条记录，再插入一条记录，这显然是错误的。
- 跳过已经刷新到磁盘的页面
`checkpoint_lsn` 之前的 `redo` 日志对应的脏页确定都已经刷到磁盘，但是 `checkpoint_lsn` 之后的 `redo` 日志不能确定是否已经刷到磁盘，主要是因为在最近做的一次 `checkpoint` 后，可能后台线程又不断的从 `LRU` 链表和 `flush` 链表中将一些脏页刷出 `Buffer Pool`。这些在 `checkpoint_lsn` 之后的 `redo` 日志，如果它们对应的脏页在崩溃发生时已经刷新到磁盘，那在恢复时也就没有必要根据 `redo` 日志的内容修改该页面。
在 `File Header` 里有一个称之为 `FIL_PAGE_LSN` 的属性，该属性记载最近一次修改页面时对应的 `lsn` 值，即页面控制块中的 `newest_modification` 值。如果在做某次 `checkpoint` 之后有脏页被刷新到磁盘中，那么该页对应的 `FIL_PAGE_LSN` 代表的 `lsn` 值肯定大于 `checkpoint_lsn` 的值，凡是符合这种情况的页面就不需要重复执行 `lsn` 值小于 `FIL_PAGE_LSN` 的 `redo` 日志，所以更进一步提升崩溃恢复的速度。