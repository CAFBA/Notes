## Linux 远程连接

```mysql
# 查看网卡 ip 地址，远程连接输入 ip 地址
ifconfig # window下为 ipconfig

# window 下检查 ping
ping ip 地址 

# 远程连接指定主机名，还需要权限允许
mysql -h 主机名 -P 端口号 -u 用户名 -p密码
```

## Linux Mysql安装

```shell
rz # 上传 rpm 包
su root
rpm -ivh rpm 包 # 安装 rpm 包
yum install mysql-server --nogpgcheck # 安装 mysql 
service mysqld start # 超户模式下启动mysqld服务
netstat -tanp # 检查启动的服务
grep "password" /var/log/mysqld.log # 安装mysql默认生成的密码在log日志文件中
# 通过上面的密码可首次登录mysql server
set global validate_password_policy=0;
set global validate_password_length=1;
ALTER USER 'root'@'localhost' IDENTIFIED BY '123456';
quit # 退出登录
```

## 支持远程ip连接

mysql默认只能通过localhost访问，不能通过ip远程访问，主要考虑安全的问题。如果在集群分布式环 境中单独部署mysql，就需要设置通过ip远程访问了

```shell
select Host,User,authentication_string from user;
grant all privileges on *.* to 'root'@'%' identified by '123456' with grant option;
flush privileges;
mysql -h 172.20.10.3 -u root -p123456
```

## 字符集相关操作

在MySQL 8.0版本之前，默认字符集为 latin1 ，utf8字符集指向的是 utf8mb3 。从MySQL 8.0开始，数据库的默认编码将改为 utf8mb4 。

```mysql
# 查看默认使用的字符集
show variables like 'character%';

# 修改字符集，但是原库、原表的设定不会发生变化，参数修改只对新建的数据库生效。
vim /etc/my.cnf
character_set_server=utf8

# 已有库&表字符集的变更
# 原有的数据如果是用非'utf8'编码的话，数据本身编码不会发生改变。已有数据需要导出或删除，然后重新插入。
alter database dbtest1 character set 'utf8';
alter table t_emp convert to character set 'utf8';


# character_set_server ：服务器级别的字符集。
# 在配置文件中修改
[server]
character_set_server=gbk # 默认字符集
collation_server=gbk_chinese_ci #对应的默认的比较规则

# character_set_database ：当前数据库的字符集
# 在创建和修改数据库的时候指定该数据库的字符集和比较规则
CREATE DATABASE 数据库名 [[DEFAULT] CHARACTER SET 字符集名称] [[DEFAULT] COLLATE 比较规则名称];
ALTER DATABASE 数据库名 [[DEFAULT] CHARACTER SET 字符集名称] [[DEFAULT] COLLATE 比较规则名称];
CREATE TABLE 表名(
    列名 字符串类型 [CHARACTER SET 字符集名称] [COLLATE 比较规则名称],
	其他列...
);
ALTER TABLE 表名 MODIFY 列名 字符串类型 [CHARACTER SET 字符集名称] [COLLATE 比较规则名称];
```

> 如果创建或修改列时没有显式的指定字符集和比较规则，则该列默认用表的字符集和比较规则 
>
> 如果创建表时没有显式的指定字符集和比较规则，则该表默认用数据库的字符集和比较规则 
>
> 如果创建数据库时没有显式的指定字符集和比较规则，则该数据库默认用服务器的字符集和比较规则

### 请求到响应过程中字符集的变化

character_set_client：服务器解码请求时使用的字符集 

character_set_connection：服务器处理请求时会把请求字符串从character_set_client转为character_set_connection 

character_set_results：服务器向客户端返回数据时使用的字符集

![image-20230110152340976](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230110152340976.png)

## SQL大小写

MySQL在Linux下数据库名、表名、列名、别名大小写规则是这样的： 

1、数据库名、表名、表的别名、变量名是严格区分大小写的； 

2、关键字、函数名称在 SQL 中不区分大小写；列名（或字段名）与列的别名（或字段别名）在所有的情况下均是忽略大小写的； 

MySQL在Windows的环境下全部不区分大小写

lower_case_table_names参数值的设置：默认为0，大小写敏感。 

设置1，大小写不敏感。创建的表，数据库都是以小写形式存放在磁盘上，对于sql语句都是转换为小写对表和数据库进行查找。 

设置2，创建的表和数据库依据语句上格式存放，凡是查找都是转换为小写进行。

```mysql
SHOW VARIABLES LIKE '%lower_case_table_names%'

# 在重启数据库实例之前就需要将原来的数据库和表转换为小写，否则将找不到数据库名
[mysqld] 
lower_case_table_names=1 # 此参数适用于MySQL5.7。
```

此参数适用于MySQL5.7。在MySQL 8下禁止在重新启动 MySQL 服务时将 lower_case_table_names 设置成不同于初始化 MySQL 服务时设置的 lower_case_table_names 值。如果非要将MySQL8设置为大小写不敏感，具体步骤为：

- 停止MySQL服务
- 删除数据目录，即删除 /var/lib/mysql 目录 
- 在MySQL配置文件（ /etc/my.cnf ）中添加 lower_case_table_names=1 
- 启动MySQL服务

## sql_mode

宽松模式：如果设置的是宽松模式，那么我们在插入数据的时候，即便是给了一个错误的数据，也可能会被接受，并且不报错。

严格模式：出现上面宽松模式的错误，应该报错才对，所以MySQL5.7版本就将sql_mode默认值改为了严格模式。所以在 生产等环境 中，必须采用的是严格模式，进而 开发、测试环境的数据库也必须要设置，这样在开发测试阶段就可以发现问题。

```mysql
# 查看当前的sql_mode
select @@session.sql_mode
select @@global.sql_mode
show variables like 'sql_mode';
# 临时设置方式
SET GLOBAL sql_mode = 'modes...'; #全局
SET SESSION sql_mode = 'modes...'; #当前会话
# 永久设置
[mysqld]
sql_mode=ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION
```

## 其它命令

### 终端

```mysql
# xshell 显示英文
export LC_ALL=en_US.utf8

# 重启mysql
service mysqld restart

# 启动 MySQL 服务命令：
net start MySQL服务名
# 停止 MySQL 服务命令：
net stop MySQL服务名


```

### 引擎

```mysql
show engines;
show engines \G;

# 查看默认的存储引擎
show variables like '%storage_engine%';
SELECT @@default_storage_engine;

# 修改默认的存储引擎
SET DEFAULT_STORAGE_ENGINE=MyISAM;

# 或者修改 my.cnf 文件：
default-storage-engine=MyISAM

systemctl restart mysqld.service

# 创建表时指定存储引擎
CREATE TABLE 表名(
	建表语句;
) ENGINE = 存储引擎名称;

# 修改表的存储引擎
ALTER TABLE 表名 ENGINE = 存储引擎名称;
```

### 行格式

```mysql
CREATE TABLE 表名 (列的信息) ROW_FORMAT=行格式名称
ALTER TABLE 表名 ROW_FORMAT=行格式名称
```

### 索引

如果显式创建表时创建索引的话，基本语法格式如下：

```mysql
CREATE TABLE table_name [col_name data_type]
[UNIQUE | FULLTEXT | SPATIAL] [INDEX | KEY] [index_name] (col_name [length]) [ASC |
DESC]
```

* UNIQUE 、 FULLTEXT 和 SPATIAL 为可选参数，分别表示唯一索引、全文索引和空间索引； 
* INDEX 与 KEY 为同义词，两者的作用相同，用来指定创建索引； 
* index_name 指定索引的名称，为可选参数，如果不指定，那么MySQL默认col_name为索引名； 
* col_name 为需要创建索引的字段列，该列必须从数据表中定义的多个列中选择； 
* length 为可选参数，表示索引的长度，只有字符串类型的字段才能指定索引长度； 
* ASC 或 DESC 指定升序或者降序的索引值存储。

```mysql
# 普通索引
CREATE TABLE book(
    book_id INT ,
    book_name VARCHAR(100),
    year_publication YEAR,
    INDEX(year_publication)
);

# 唯一索引
CREATE TABLE test1(
id INT NOT NULL,
name varchar(30) NOT NULL,
UNIQUE INDEX uk_idx_id(id)
);

# 主键索引，修改主键索引：必须先删除掉(drop)原索引，再新建(add)索引
CREATE TABLE student (
    id INT(10) UNSIGNED AUTO_INCREMENT ,
    student_no VARCHAR(200),
    student_name VARCHAR(200),
    PRIMARY KEY(id)
);
ALTER TABLE student drop PRIMARY KEY;

# 创建单列索引
CREATE TABLE test2(
    id INT NOT NULL,
    name CHAR(50) NULL,
    INDEX single_idx_name(name(20))
);

# 创建组合索引
CREATE TABLE test3(
    id INT(11) NOT NULL,
    name CHAR(30) NOT NULL,
    age INT(11) NOT NULL,
    info VARCHAR(255),
    INDEX multi_idx(id,name,age)
);

# 创建全文索引
CREATE TABLE articles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR (200),
    body TEXT,
    FULLTEXT index (title, body)
) ENGINE = INNODB;

# 创建空间索引：空间索引创建中，要求空间类型的字段必须为 非空 
CREATE TABLE test5(
    geo GEOMETRY NOT NULL,
    SPATIAL INDEX spa_idx_geo(geo)
) ENGINE=MyISAM;


# 在表上创建索引
ALTER TABLE table_name ADD [UNIQUE | FULLTEXT | SPATIAL] [INDEX | KEY]
[index_name] (col_name[length],...) [ASC | DESC]

CREATE [UNIQUE | FULLTEXT | SPATIAL] INDEX index_name
ON table_name (col_name[length],...) [ASC | DESC]

# 删除：删除表中的列时，如果要删除的列为索引的组成部分，则该列也会从索引中删除。如果组成索引的所有列都被删除，则整个索引将被删除。
ALTER TABLE table_name DROP INDEX index_name;

DROP INDEX index_name ON table_name;
```

> 主键不能被设置为隐藏索引。当表中没有显式主键时，表中第一个唯一非空索引会成为隐式主键，也不能设置为隐藏索引。
>
> 当索引被隐藏时，它的内容仍然是和正常索引一样实时更新的。如果一个索引需要长期被隐藏，那么可以将其删除，因为索引的存在会影响插入、更新和删除的性能。

```mysql
# 创建隐式索引
CREATE TABLE tablename(
    propname1 type1[CONSTRAINT1],
    propname2 type2[CONSTRAINT2],
    INDEX [indexname](propname1 [(length)]) INVISIBLE
);

CREATE INDEX indexname ON tablename(propname[(length)]) INVISIBLE;

ALTER TABLE tablename ADD INDEX indexname (propname [(length)]) INVISIBLE;

# 已存在的索引可通过如下语句切换可见状态：
ALTER TABLE tablename ALTER INDEX index_name INVISIBLE; #切换成隐藏索引
ALTER TABLE tablename ALTER INDEX index_name VISIBLE; #切换成非隐藏索引

# 如果use_invisible_indexes设置为off(默认)，优化器会忽略隐藏索引。
# 如果设置为on，即使隐藏索引不可见，优化器在生成执行计划时仍会考虑使用隐藏索引。
mysql> select @@optimizer_switch \G

# 在输出的结果信息中找到如下属性配置。
use_invisible_indexes=off
mysql> set session optimizer_switch="use_invisible_indexes=on";

# 如果需要使隐藏索引对查询优化器不可见，则只需要执行如下命令即可。
mysql> set session optimizer_switch="use_invisible_indexes=off";

# 使用EXPLAIN查看以字段invisible_column作为查询条件时的索引使用情况。查询优化器会使用隐藏索引来查询数据。
explain select * from classes where cname = '高一2班';
```

### Buffer Pool

```mysql
# MySQL MyISAM 存储引擎，它只缓存索引，不缓存数据，对应的键缓存参数为 key_buffer_size
show variables like 'key_buffer_size';

# InnoDB 存储引擎，可以通过查看 innodb_buffer_pool_size 变量来查看缓冲池的大小
show variables like 'innodb_buffer_pool_size';
set global innodb_buffer_pool_size = 268435456;

[server]
innodb_buffer_pool_size = 268435456

[server] # 在服务器启动的时候通过设置innodb_buffer_pool_instances的值来修改Buffer Pool实例的个数
innodb_buffer_pool_instances = 2

# 查看缓冲池的个数，使用命令：
show variables like 'innodb_buffer_pool_instances';

# 每个 Buffer Pool 实例实际占多少内存空间：
innodb_buffer_pool_size/innodb_buffer_pool_instances

# 对于InnoDB存储引擎来说，可以通过查看系统变量innodb_old_blocks_pct的值来确定old区域在LRU链表中所占的比例，比方说这样：
mysql> SHOW VARIABLES LIKE 'innodb_old_blocks_pct';
+-----------------------+-------+
| Variable_name         | Value |
+-----------------------+-------+
| innodb_old_blocks_pct | 37    |
+-----------------------+-------+

# 从结果可以看出来，默认情况下，old区域在LRU链表中所占的比例是37%，也就是说old区域大约占LRU链表的3/8。
# 这个比例是可以设置的，可以在启动时修改innodb_old_blocks_pct参数来控制old区域在LRU链表中所占的比例，比方说这样修改配置文件：
[server]
innodb_old_blocks_pct = 40

# 这样在启动服务器后，old区域占LRU链表的比例就是40%。
# 如果在服务器运行期间，也可以修改这个系统变量的值，不过这个系统变量属于全局变量，一经修改，会对所有客户端生效，所以只能这样修改：
SET GLOBAL innodb_old_blocks_pct = 40;
```

> 不是说 Buffer Pool 实例创建的越多越好，分别管理各个 Buffer Pool 需要性能开销，InnDB规定：**当innodb_buffer_pool_size的值小于1G的时候设置多个实例是无效的，InnoDB会默认把innodb_buffer_pool_instances的值修改为1。而我们鼓励在 Buffer Pool 大于等于 1G 的时候设置多个 Buffer Pool 实例。**

### 报错

创建函数，假如报错：

```mysql
This function has none of DETERMINISTIC......
```

由于开启过慢查询日志bin-log, 必须为function指定一个参数。主从复制，主机会将写操作记录在bin-log日志中。从机读取bin-log日志，执行语句来同步数据。如果使 用函数来操作数据，会导致从机和主键操作时间不一致。所以，默认情况下，mysql不开启创建函数设置。

```mysql
# 查看mysql是否允许创建函数：
show variables like 'log_bin_trust_function_creators';

# 命令开启：允许创建函数设置：
set global log_bin_trust_function_creators=1; # 不加global只是当前窗口有效。

# windows下：my.ini[mysqld]加上：
log_bin_trust_function_creators=1

# linux下：/etc/my.cnf下my.cnf[mysqld]加上：
log_bin_trust_function_creators=1
```

