## SQL30

```mysql
# 统计每个性别的用户分别有多少参赛者
SELECT (
    CASE 
        WHEN profile LIKE '%,male' THEN 'male'
        WHEN profile LIKE '%,female' THEN 'female'
    END
) AS gender, COUNT(*) AS number
FROM user_submit
GROUP BY gender;
```

## SQL26

```mysql
# 将用户划分为25岁以下和25岁及以上两个年龄段，分别查看这两个年龄段用户数量，age为null也记为25岁以下
SELECT (
    CASE 
        WHEN age >= 25 THEN '25岁及以上'
        WHEN age < 25 || age IS NULL THEN '25岁以下'
        END 
) AS age_cut, count(*) as number
FROM user_profile
GROUP BY age_cut; # 聚合函数作用于一组数据，此处需要分组统计数据
```

## SQL25

```mysql
# 查看学校为山东大学或者性别为男性的用户的device_id、gender、age和gpa数据，请取出相应结果，结果不去重。
SELECT device_id, gender, age, gpa
FROM user_profile
WHERE university = "山东大学"
UNION ALL
SELECT device_id, gender, age, gpa
FROM user_profile
WHERE gender = 'male';
```

## SQL24

```mysql
# 查看参加了答题的山东大学的用户在不同难度下的平均答题题目数，请取出相应数据
SELECT university, difficult_level,
COUNT(qd.question_id) / COUNT(DISTINCT us.device_id) AS avg_answer_cnt

FROM question_practice_detail AS qpd

JOIN question_detail AS qd
ON qd.question_id = qpd.question_id
JOIN user_profile AS us 

ON us.device_id = qpd.device_id
GROUP BY university, difficult_level

HAVING university = "山东大学";
```

## SQL29

```mysql
# 查看用户在某天刷题后第二天还会再来刷题的平均概率
SELECT AVG(IF(DATEDIFF(date2, date1) = 1, 1, 0)) AS avg_ret 
FROM (
  	# 按用户ID分组并按日期升序，取到日期的后一行，即第二天
    SELECT device_id, date AS date1, LEAD(date) OVER (PARTITION BY device_id ORDER BY date) AS date2
    FROM ( # 用户一天内可能去多次，在去重的基础上再使用 LEAD 
        SELECT DISTINCT device_id, date
        FROM question_practice_detail
    ) AS uniq_id_date
) AS id_last_next_date
```

## SQL28、39

```mysql
SELECT DAY(date) AS day, COUNT(*) AS question_cnt
FROM question_practice_detail
WHERE MONTH(date) = 8 AND YEAR(date) = 2021
GROUP BY day;

SELECT COUNT(DISTINCT device_id), COUNT(*)
FROM question_practice_detail
WHERE MONTH(date) = 8 && YEAR(date) = 2021;
```

## SQL32

```mysql
SELECT
    SUBSTRING_INDEX(SUBSTRING_INDEX(profile, ',', -2), ',', 1) AS age,
    COUNT(device_id) AS number
FROM user_submit
GROUP BY age
```

## SQL33

```mysql
# 学校与学生是一对多的关系，如果仅用 min 求出 gpa 最低的学生，查询结果中的 id 与学生不一定是对应的关系，因此此方法错误
SELECT device_id, university, MIN(gpa)
FROM user_profile
GROUP BY university;

# 先在表中找到每个学校的最低 gpa，之后在表中匹配最低 gpa 的学生 I
SELECT us1.device_id, us1.university, us1.gpa

FROM user_profile AS us1 
RIGHT OUTER JOIN  # 同一张表，选内外连接没区别
(
    SELECT university, MIN(gpa) AS min_gpa
    FROM user_profile
    GROUP BY university 
) AS us2
ON us1.university = us2.university AND us1.gpa = us2.min_gpa

ORDER BY university;
# 窗口函数
SELECT device_id, university, gpa
FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY university ORDER BY gpa) AS gpa_rank
    FROM user_profile
) AS us1
WHERE gpa_rank = 1
ORDER BY university;
```

## 其它

```mysql
# 查询“M01F011”号课程的考试情况，列出学号、课程号和成绩，同时将百分制成绩显示为等级。
SELECT 学号, 课程号,
CASE
  WHEN 成绩 >= 90 THEN '优'
  WHEN 成绩 BETWEEN 80 AND 89 THEN '良'
  WHEN 成绩 BETWEEN 70 AND 79 THEN '中'
  WHEN 成绩 BETWEEN 60 AND 69 THEN '及格'
  WHEN 成绩 <60 THEN '不及格'
END 成绩
FROM 成绩表
WHERE 课程号 = 'M01F011'
```

