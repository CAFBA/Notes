## 连接数量

如果你想知道当前  MySQL 服务被多少个客户端连接了，你可以执行 `show processlist` 命令进行查看。

![](https://cdn.xiaolincoding.com/gh/xiaolincoder/mysql/sql执行过程/查看连接.png)

比如上图的显示结果，共有两个用户名为 root 的用户连接了 MySQL 服务，其中 id 为 6 的用户的 Command 列的状态为 `Sleep` ，这意味着该用户连接完 MySQL 服务就没有再执行过任何命令，也就是说这是一个空闲的连接，并且空闲的时长是 736 秒（Time 列）。

MySQL 定义了空闲连接的最大空闲时长，由 `wait_timeout` 参数控制的，默认值是 8 小时（28880秒），如果空闲连接超过了这个时间，连接器就会自动将它断开。

```sql
mysql> show variables like 'wait_timeout';
```

也可以手动断开空闲的连接，使用的是 kill connection + id 的命令。

```sql
mysql> kill connection +6;
```

一个处于空闲状态的连接被服务端主动断开后，这个客户端并不会马上知道，等到客户端在发起下一个请求的时候，才会收到这样的报错“ERROR 2013 (HY000): Lost connection to MySQL server during query”。

MySQL 服务支持的最大连接数由 max_connections 参数控制，超过这个值，系统就会拒绝接下来的连接请求，并报错提示“Too many connections”。

```sql
mysql> show variables like 'max_connections';
```

## 查询缓存

一般建议在静态表里使用查询缓存，即极少更新的表。比如，一个系统配置表、字典表，这张表上的查询才适合使用查询缓存。可以将 my.cnf 参数 query_cache_type 设置成 DEMAND，代表当 sql 语句中有 SQL_CACHE 关键字时才缓存。比如：

```mysql
# query_cache_type 有3个值。 0代表关闭查询缓存OFF，1代表开启ON，2代表(DEMAND)
query_cache_type=2

# 这样对于默认的SQL语句都不使用查询缓存。而对于确定要使用查询缓存的语句，可以供SQL_CACHE显示指定
SELECT SQl_CACHE * FROM test WHERE ID=5;
SELECT SQl_NO_CACHE * FROM test WHERE ID=5;

# MySQL5.7中查看当前 mysql 实例是否开启缓存机制：
show global variables like "%query_cache_type%";

# 监控查询缓存的命中率：
show status like '%Qcache%';
```

- Qcache_free_blocks: 表示查**询缓存中还有多少剩余的blocks**，如果该值显示较大，则说明查询缓存中的内部碎片过多了，可能在一定的时间进行整理。
- Qcache_free_memory: **查询缓存的内存大小**，通过这个参数可以很清晰的知道当前系统的查询内存是否够用，DBA可以根据实际情况做出调整。
- Qcache_hits: 表示**有多少次命中缓存**。我们主要可以通过该值来验证我们的查询缓存的效果。数字越大，缓存效果越理想。
- Qcache_inserts: 表示**多少次未命中然后插入**，意思是新来的SQL请求在缓存中未找到，不得不执行查询处理，执行查询处理后把结果insert到查询缓存中。这样的情况的次数越多，表示查询缓存应用到的比较少，效果也就不理想。当然系统刚启动后，查询缓存是空的，这也正常。
- Qcache_lowmem_prunes: 该参数记录**有多少条查询因为内存不足而被移除出查询缓存**。通过这个值，用户可以适当的调整缓存大小。
- Qcache_not_cached: 表示因为query_cache_type的设置而**没有被缓存的查询数量**。
- Qcache_queries_in_cache: **当前缓存中缓存的查询数量**。
- Qcache_total_blocks: **当前缓存的block数量**。

## SQL 执行资源情况

### MySQL8中SQL执行资源情况

```mysql
# 开启可以让MySQL收集在SQL执行时所使用的资源情况
mysql> select @@profiling;
mysql> show variables like 'profiling';

# profiling=0 代表关闭，我们需要把 profiling 打开，即设置为 1：
mysql> set profiling=1;

# 然后执行一个 SQL 查询（你可以执行任何一个 SQL 查询）
mysql> select * from employees;

# 查看当前会话所产生的所有 profiles：
mysql> show profiles; # 显示最近的几次查询

# 显示执行计划，查看程序的执行步骤：
mysql> show profile;
mysql> show profile for query 7;
mysql> show profile cpu,block io for query 6;
```

除了查看cpu、io阻塞等参数情况，还可以查询下列参数的利用情况。发现两次查询当前情况都一致，说明没有缓存。

```mysql
Syntax:
SHOW PROFILE [type [, type] ... ]
	[FOR QUERY n]
	[LIMIT row_count [OFFSET offset]]

type: {
	| ALL -- 显示所有参数的开销信息
	| BLOCK IO -- 显示IO的相关开销
	| CONTEXT SWITCHES -- 上下文切换相关开销
	| CPU -- 显示CPU相关开销信息
	| IPC -- 显示发送和接收相关开销信息
	| MEMORY -- 显示内存相关开销信息
	| PAGE FAULTS -- 显示页面错误相关开销信息
	| SOURCE -- 显示和Source_function,Source_file,Source_line 相关的开销信息
	| SWAPS -- 显示交换次数相关的开销信息
}
```

`在 8.0 版本之后，MySQL 不再支持缓存的查询`。一旦数据表有更新，缓存都将清空，因此只有数据表是静态的时候，或者数据表很少发生变化时，使用缓存查询才有价值，否则如果数据表经常更新，反而增加了 SQL 的查询时间。

### MySQL5.7中SQL执行资源情况

上述操作在MySQL5.7中测试，发现前后两次相同的sql语句，执行的查询过程仍然是相同的。需要显式开启查询缓存模式 。在MySQL5.7中如下设置：

```mysql
# 配置文件中开启查询缓存
query_cache_type=1

# 重启mysql服务
systemctl restart mysqld

# 由于重启过服务，需要重新执行如下指令，开启profiling。
mysql> set profiling=1;

mysql> select * from locations;
mysql> show profiles; # 显示最近的几次查询
mysql> show profile for query 1;
mysql> show profile for query 2;
```
