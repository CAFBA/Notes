# 事务
事务有 4 种特性：原子性、一致性、隔离性和持久性：
- 持久性通过 `redo log` 来保证
- 原子性通过 `undo log` 来保证
- 隔离性通过 `MVCC` 或锁机制来保证
- 一致性则是通过持久性 + 原子性 + 隔离性来保证
`redo log` 和 `undo log` 属于 `InnoDB` 存储引擎的日志：
- `redo log` 记录此次事务「完成后」的数据状态，记录的是更新之后的值，即物理级别上的页修改操作，事务提交之后发生崩溃进行恢复，用来保证事务的持久性。
- `undo log` 记录此次事务「开始前」的数据状态，记录的是更新之前的值，即逻辑操作，主要用于事务提交之前发生崩溃进行回滚( `undo log`  记录的是每个修改操作的逆操作)和一致性非锁定读(`undo log` 回滚行记录到某种特定的版本——`MVCC`，即多版本并发控制)，用来保证事务的原子性。
## ACID
事务是一组逻辑操作单元，使数据从一种状态变换到另一种状态。
事务处理的原则：保证所有事务都作为一个工作单元来执行，即使出现故障，都不能改变这种执行方式。当在一个事务中执行多个操作时，要么所有的事务都被提交，那么这些修改就永久地保存下来，要么数据库管理系统将放弃所作的所有修改，整个事务回滚到最初状态。
### 事物的 ACID 特性
原子性：原子性是指事务是一个不可分割的工作单位，要么全部提交，要么全部失败回滚。
隔离性：事务的隔离性是指一个事务的执行不能被其他事务干扰，即一个事务内部的操作及使用的数据对并发的其他事务是隔离的，并发执行的各个事务之间不能相互干扰。
一致性：如果数据库中的数据全部符合现实世界中的约束，这些数据就是符合一致性的。
持久性：持久性是指一个事务一旦被提交，它对数据库中数据的改变就是永久性的，接下来的其他操作和数据库故障不应该对其有任何影响。
## 事务的概念
事务是一个抽象的概念，把需要保证原子性、隔离性、一致性和持久性的一个或多个数据库操作称之为一个事务，状态大致上划分成：
- 活动的：事务对应的数据库操作正在执行过程中时，则事务处在活动的状态。
- 部分提交的：当事务中的最后一个操作执行完成，但由于操作都在内存中执行，所造成的影响并没有刷新到磁盘时，则事务处在部分提交的状态。
- 失败的：当事务处在活动的或者部分提交的状态时，可能遇到某些错误而无法继续执行，或者人为的停止当前事务的执行，则事务处在失败的状态。
- 中止的：如果事务执行半截而变为失败的状态，从而当前事务处在失败的状态，那么就需要撤销失败事务对当前数据库造成的影响。当回滚操作执行完毕时，也就是数据库恢复到执行事务之前的状态，则事务处在中止的状态。
- 提交的：当一个处在部分提交的状态的事务将修改过的数据都同步到磁盘上之后，则该事务处在提交的状态。
随着事务对应的数据库操作执行到不同阶段，事务的状态也在不断变化，一个基本的状态转换图如下所示：
![image-20230125163805722](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125163805722.png)
只有当事务处于提交的或者中止的状态时，一个事务的生命周期才算是结束。对于已经提交的事务来说，该事务对数据库所做的修改将永久生效，对于处于中止状态的事务，该事务对数据库所做的所有修改都会被回滚到没执行该事务之前的状态。
## 并行事务
`MySQL` 服务端是允许多个客户端连接的，这意味着 `MySQL` 会出现同时处理多个事务的情况，此时可能出现脏读、不可重复读、幻读的问题。
- 脏写：修改其他事务未提交的数据；
- 脏读：读到其他事务未提交的数据；
- 不可重复读：前后读取的数据不一致； 
- 幻读：前后读取的记录数量不一致。
> 严重性来排序：脏写 > 脏读 > 不可重复读 > 幻读
### 脏写
如果一个事务修改另一个未提交事务修改过的数据，就意味着发生脏写。
![image-20230125163811798](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125163811798.png)
如上图，`SessionA` 和 `SessionB` 各开启一个事务，`SessionB` 中的事务先将 `number` 列为 1 的记录的 `name` 列更新为'关羽'，然后 `SessionA` 中的事务接着又把这条 `number` 列为 1 的记录的 `name` 列更新为张飞。如果之后 `SessionB` 中的事务进行回滚，那么 `SessionA` 中的更新也将不复存在，这种现象就称之为脏写。
### 脏读
如果一个事务「读到」另一个「未提交事务修改过的数据」，就意味着发生「脏读」。
假设有 `A` 和 `B` 这两个事务同时在处理，事务 `A` 先开始从数据库中读取小林的余额数据，然后再执行更新操作，如果此时事务 `A` 还没有提交事务，而此时正好事务 `B` 也从数据库中读取小林的余额数据，那么事务 `B` 读取到的余额数据是刚才事务 `A` 更新后的数据，即使没有提交事务。
![图片](https://img-blog.csdnimg.cn/img_convert/10b513008ea35ee880c592a88adcb12f.png)
因为事务 `A` 是还没提交事务的，也就是它随时可能发生回滚操作，如果在上面这种情况事务 A 发生回滚，那么事务 `B` 刚才得到的数据就是过期的数据，这种现象就被称为脏读。
### 不可重复读
在一个事务内多次读取同一个数据，如果出现前后两次读到的数据不一样的情况，就意味着发生「不可重复读」。即当前事务先读取一条记录，另外一个事务对该记录做改动并提交之后，当前事务再次读取时会获得不同的值。
幻读特指同一个查询执行多次，不可重复读特指对同一个记录查询多次。
假设有 `A` 和 `B` 这两个事务同时在处理，事务 `A` 先开始从数据库中读取小林的余额数据，然后继续执行代码逻辑处理，在这过程中如果事务 `B` 更新这条数据，并提交事务，那么当事务 `A` 再次读取该数据时，就会发现前后两次读到的数据是不一致的，这种现象就被称为不可重复读。
![图片](https://img-blog.csdnimg.cn/img_convert/f5b4f8f0c0adcf044b34c1f300a95abf.png)
### 幻读
当同一个查询在不同的时间产生不同的结果集时，意味着发生「幻读」。例如，如果 `SELECT` 执行两次，但第二次返回第一次没有返回的行，则该行是幻像行。
幻读特指同一个查询执行多次，不可重复读特指对同一个记录查询多次。
假设有 `A` 和 `B` 这两个事务同时在处理，事务 `A` 先开始从数据库查询账户余额大于 100 万的记录，发现共有 5 条，然后事务 `B` 也按相同的搜索条件也是查询出 5 条记录。
![图片](https://img-blog.csdnimg.cn/img_convert/d19a1019dc35dfe8cfe7fbff8cd97e31.png)
接下来，事务 `A` 插入一条余额超过 100 万的账号，并提交事务，此时数据库超过 100 万余额的账号个数就变为 6。然后事务 `B` 再次查询账户余额大于 100 万的记录，此时查询到的记录数量有 6 条，发现和前一次读到的记录数量不一样，这种现象就被称为幻读。
## 事务隔离级别
### SQL标准中的四种隔离级别
`SQL` 标准提出四种隔离级别来规避这些现象，隔离级别越高，性能效率就越低，这四个隔离级别如下：
- 读未提交 `read uncommitted`，指一个事务还没提交时，它做的变更就能被其他事务看到；
- 读提交 `read committed`，指一个事务提交之后，它做的变更才能被其他事务看到；
- 可重复读 `repeatable read`，指一个事务执行过程中看到的数据，一直跟这个事务启动时看到的数据是一致的，`MySQL InnoDB` 引擎的默认隔离级别；
- 串行化 `serializable`；会对记录加上读写锁，在多个事务对这条记录进行读写操作时，如果发生读写冲突的时候，后访问的事务必须等前一个事务执行完成，才能继续执行；
按隔离水平高低排序：串行化 > 可重复读 > 读提交 > 读未提交
SQL标准中规定，针对不同的隔离级别，并发事务可以发生不同严重程度的问题，具体情况如下：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240310161630.png)
所以，要解决脏读现象，就要升级到「读提交」以上的隔离级别；要解决不可重复读现象，就要升级到「可重复读」的隔离级别，要解决幻读现象不建议将隔离级别升级到「串行化」。
执行「开始事务」命令，并不意味着启动事务。在 `MySQL` 有两种开启事务的命令，事务的启动时机是不同的：
1. 执行 `begin/start transaction` 命令后，并不代表事务启动，只有在执行这个命令后，执行增删查改操作的 `SQL` 语句，才是事务真正启动的时机。
2. 执行 `start transaction with consistent snapshot`  命令，就会马上启动事务。
### MySQL中支持的四种隔离级别
不同的数据库厂商对 `SQL` 标准中规定的四种隔离级别支持不一样，`Oracle` 就只支持 `READ COMMITTED` 和 `SERIALIZABLE` 隔离级别。`MySQL` 虽然支持 4 种隔离级别，但与 `SQL` 标准中所规定的各级隔离级别允许发生的问题却有些出入，`MySQL` 在「可重复读」隔离级别下，可以很大程度上避免幻读现象的发生，所以 `MySQL` 并不会使用「串行化」隔离级别来避免幻读现象的发生，因为使用「串行化」隔离级别会影响性能。
这四种隔离级别具体是如何实现的呢？
- 对于「读未提交」隔离级别的事务来说，因为可以读到未提交事务修改的数据，所以直接读取最新的数据就行；
- 对于「串行化」隔离级别的事务来说，通过加读写锁的方式来避免并行访问；
- 对于「读提交」和「可重复读」隔离级别的事务来说，它们是通过 `Read View` 来实现的，它们的区别在于创建 `Read View` 的时机不同。`READ COMMITTED` 在「每个语句执行前」都会重新生成一个独立的 `Read View`，而 `REPEATABLE READ` 在「启动事务时/第一个语句执行前」生成一个 `Read View`，然后整个事务期间都在用这个 `Read View`。
### 隔离级别操作
`MySQL` 的默认隔离级别为 `REPEATABLE READ`，可以手动修改一下事务的隔离级别：
```mysql
SET [GLOBAL|SESSION] TRANSACTION ISOLATION LEVEL level;

level: {
     REPEATABLE READ
   | READ COMMITTED
   | READ UNCOMMITTED
   | SERIALIZABLE
}
```
使用 `GLOBAL` 关键字在全局范围影响：
```mysql
SET GLOBAL TRANSACTION ISOLATION LEVEL SERIALIZABLE;
```
只对执行完该语句之后产生的会话起作用，对当前已经存在的会话无效。
使用 `SESSION` 关键字在会话范围影响：
```mysql
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;
```
该语句可以在已经开启的事务中间执行，但不会影响当前正在执行的事务，对当前会话的所有后续的事务有效，如果在事务之间执行，则对后续的事务有效。
上述两个关键字都不用：
```mysql
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
```
只对当前会话中下一个即将开启的事务有效，下一个事务执行完后，后续事务将恢复到之前的隔离级别，该语句不能在已经开启的事务中间执行，会报错。
如果在服务器启动时想改变事务的默认隔离级别，可以修改启动参数 `transaction-isolation` 的值，想要查看当前会话默认的隔离级别可以通过查看系统变量 `transaction_isolation` 的值来确定：
```mysql
mysql> SHOW VARIABLES LIKE 'transaction_isolation';
+-----------------------+-----------------+
| Variable_name         | Value           |
+-----------------------+-----------------+
| transaction_isolation | REPEATABLE-READ |
+-----------------------+-----------------+
1 row in set (0.02 sec)
```
或者使用更简便的写法：
```mysql
mysql> SELECT @@transaction_isolation;
+-------------------------+
| @@transaction_isolation |
+-------------------------+
| REPEATABLE-READ         |
+-------------------------+
1 row in set (0.00 sec)
```
## 快照读与当前读
`MVCC` 在 `MySQL InnoDB` 中的实现主要是为提高数据库并发性能，用更好的方式去处理读-写冲突，做到即使有读写冲突时，也能做到不加锁，非阻塞并发读，而这个读指的就是快照读，而非当前读。当前读实际上是一种加锁的操作，是悲观锁的实现，而 `MVCC` 本质是采用乐观锁思想的一种方式。
### 快照读
快照读又叫一致性读，读取的是快照数据。不加锁的简单的 `SELECT` 都属于快照读，即不加锁的非阻塞读，比如这样：
```mysql
SELECT * FROM player WHERE ...
```
之所以出现快照读的情况，是基于提高并发性能的考虑，快照读的实现是基于 `MVCC`，它在很多情况下，避免加锁操作，降低开销。既然是基于多版本，那么快照读可能读到的并不一定是数据的最新版本，而有可能是之前的历史版本。
快照读的前提是隔离级别不是串行级别，串行级别下的快照读会退化成当前读。
### 当前读
`MySQL` 里除普通查询是快照读，其他都是当前读，当前读读取的是记录的最新版本，读取时还要保证其他并发事务不能修改当前记录，因此会对读取的记录进行加锁。加锁的 `SELECT` 或者对数据进行增删改都会进行当前读。比如：
```mysql
SELECT * FROM student LOCK IN SHARE MODE; # 共享锁
SELECT * FROM student FOR UPDATE; # 独占锁
INSERT INTO student values ... # 独占锁
DELETE FROM student WHERE ... # 独占锁
UPDATE student SET ... # 独占锁
```
## MVCC
### 版本链
对于使用 `InnoDB` 存储引擎的表来说，它的记录中都包含两个必要的隐藏列：
- `trx_id`：当一个事务对某条记录进行改动时，就会把该事务的事务 `id` 记录在 `trx_id` 隐藏列里。
- `roll_pointer`：每次对某条记录进行改动时，都会把旧版本的记录写入到 `undo` 日志中，`roll_pointer` 是个指针，指向记录对应的 `undo` 日志，即每一个旧版本记录，于是就可以通过它找到修改前的记录。
对于初始记录刘备，假设之后两个事务 `id` 分别为 100、200 的事务对这条记录进行 `UPDATE` 操作，操作流程如下：
![image-20230125171423164](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125171423164.png)
每次对记录进行改动，都会记录一条 `undo` 日志，记录被存储到类型为 `FIL_PAGE_INDEX` 的页面中，`undo` 日志被存放到类型为 `FIL_PAGE_UNDO_LOG` 的页面中。
每条 `undo` 日志也都有一个 `roll_pointer` 属性(`INSERT` 操作对应的 `undo` 日志没有该属性，因为该记录并没有更早的版本)，在对一条记录进行 `delete mark` 操作前，需要把该记录的旧的 `trx_id` 和 `roll_pointer` 隐藏列的值都记到对应的 `undo` 日志中，因此可以通过 `undo` 日志的 `old roll_pointer` 找到记录在修改之前对应的 `undo` 日志。比如在一个事务中，先插入一条记录，然后又执行对该记录的删除操作，这个过程的示意图就是这样：
![image-20230125213429194](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125213429194.png)
随着更新次数的增多，所有的版本都会被 `roll_pointer` 属性连接成一个链表，把这个链表称之为版本链，版本链的头节点就是当前记录最新的值：
![image-20230125171430928](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125171430928.png)
另外，每个版本中还包含生成该版本时对应的事务 `id`。
### ReadView
在 `MVCC` 机制中，多个事务对同一个行记录进行更新会产生多个历史快照，这些历史快照保存在 `Undo Log` 里。如果一个事务想要查询这个行记录，需要通过 `ReadView` 读取正确版本的行记录。
`ReadView` 就是事务在使用 `MVCC` 机制进行快照读操作时产生的读视图。当事务启动时，会生成数据库系统当前的一个快照，`InnoDB` 为每个事务构造一个数组，用来记录并维护系统当前活跃事务的 `ID`，即启动但未提交的事务。
`ReadView` 有四个重要的字段：
- `m_ids` ：指的是在创建 `ReadView` 时，当前数据库中「活跃事务」的事务 `id` 列表。
- `min_trx_id` ：指的是在创建 `ReadView` 时，当前数据库中「活跃事务」中事务 `id` 最小的事务，也就是 `m_ids` 的最小值。
- `max_trx_id` ：这个并不是 `m_ids` 的最大值，而是创建 `ReadView` 时当前数据库中应该给下一个事务的 `id` 值，也就是全局事务中最大的事务 `id` 值 + 1；
- `creator_trx_id` ：指的是创建该 `ReadView` 的事务的事务 `id`。
比如现在有 `id` 为 1，2，3 这三个事务，之后 `id` 为 3 的事务提交。那么一个新的读事务在生成 `ReadView` 时，`m_ids` 就包括 1 和 2，`min_trx_id` 的值就是 1，`max_trx_id` 的值就是 4。
在创建 `ReadView` 后，可以将记录中的 `trx_id` 划分这三种情况：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost4@main/mysql/事务隔离/ReadView.drawio.png)
当一个事务去访问某条记录的时候，判断该条记录的某个版本是否可见：
- 如果被访问记录版本的 `trx_id` 值等于 `ReadView` 中的 `creator_trx_id` 值，表示这个版本的记录是在访问它自己修改过的记录，所以该版本对当前事务可见。
- 如果被访问记录版本的 `trx_id` 值小于 `ReadView` 中的 `min_trx_id` 值，表示这个版本的记录是在创建 `ReadView` **前**已经提交的事务生成的，所以该版本的记录对当前事务**可见**。
- 如果被访问记录版本的 `trx_id` 值大于等于 `ReadView` 中的 `max_trx_id` 值，表示这个版本的记录是在创建 `ReadView` **后**才启动的事务生成的，所以该版本的记录对当前事务**不可见**。
- 如果被访问记录版本的 `trx_id` 值在 `ReadView` 的 `min_trx_id` 和 `max_trx_id` 之间，需要判断 `trx_id` 是否在 `m_ids` 列表中：
  - 如果记录的 `trx_id` **在** `m_ids` 列表中，表示生成该版本记录的活跃事务依然活跃着（还没提交事务），所以该版本的记录对当前事务**不可见**。
  - 如果记录的 `trx_id` **不在** `m_ids `列表中，表示生成该版本记录的活跃事务已经被提交，所以该版本的记录对当前事务**可见**。
综上：
- `trx_id == creator_trx_id`：正在访问自己已经修改过的记录，该版本可以被当前事务访问。
- `trx_id < min_trx_id`：生成该版本的事务在当前事务生成 `ReadView` 前已经提交，该版本可以被当前事务访问。
- `trx_id >= max_trx_id`：生成该版本的事务在当前事务生成 `ReadView` 后才开启，该版本不可以被当前事务访问。
- `min_trx_id <= trx_id <= max_trx_id`：在 `m_ids` 列表中，说明创建 `ReadView` 时生成该版本的事务还是活跃的，该版本不可以被访问，不在说明创建 `ReadView` 时生成该版本的事务已经被提交，该版本可以被访问。
如果某个版本的数据对当前事务不可见的话，那就顺着版本链找到下一个版本的数据，继续按照上边的步骤判断可见性，依此类推，直到版本链中的最后一个版本。如果最后一个版本也不可见的话，那么就意味着该条记录对该事务完全不可见，查询结果就不包含该记录。
在 `MySQL` 中，`READ COMMITTED` 和 `REPEATABLE READ` 隔离级别的的区别就是它们生成 `ReadView` 的时机不同：
- `READ COMMITTED` 在「每个查询语句执行前」都会重新生成一个独立的 `Read View`，因此在事务期间多次读取同一条数据，前后两次读的数据可能会出现不一致，因为可能这期间另外一个事务已经修改并提交事务。
- `REPEATABLE READ` 在「启动事务时/第一个查询语句执行前」生成一个 `Read View`，然后整个事务期间都在用这个 `Read View`，在 `undo log` 版本链找到的是事务启动前的记录，因此每次查询的数据都是一样的，即使中途有其他事务插入新纪录，也查询不到这条数据。
### MVCC
`MVCC`，`Multi-Version Concurrency Control` 指的就是 `READ COMMITTD`、`REPEATABLE READ` 这两种隔离级别的事务在执行普通的 `SELECT` 操作时访问记录的版本链的过程，这样可以使不同事务的读-写、写-读操作并发执行，从而提升系统性能。
`MVCC` 的执行过程就是上述通过「版本链」来控制并发事务访问同一个记录时的过程。
执行 `DELETE` 语句或者更新主键的 `UPDATE` 语句并不会立即把对应的记录完全从页面中删除，而是执行一个 `delete mark` 操作，这主要就是为 `MVCC` 服务的。`insert undo` 在事务提交之后就可以被释放掉，而 `update undo` 由于还需要支持 `MVCC`，不能立即删除掉，因此需要 `delete mark` 操作在记录上打一个删除标记，并没有真正将它删除掉。
随着系统的运行，在确定系统中包含最早产生的那个 `ReadView` 的事务不会再访问某些 `update undo` 日志以及被打删除标记的记录，有一个后台运行的 `purge` 线程会把它们真正的删除掉。
另外，`MVCC` 只是在进行普通的 `SEELCT` 查询时才生效。
## Phantom
当同一个查询在不同的时间产生不同的结果集时，事务中就会出现所幻读。
### 快照读
针对快照读，即普通 `select` 语句，通过 `MVCC` 方式解决，因为可重复读隔离级别下，事务执行过程中看到的数据，一直跟这个事务启动时看到的数据是一致的，即使中途有其他事务插入一条数据，是查询不出来这条数据的，所以能避免幻读问题。
实现的方式是在「启动事务时/第一个查询语句执行前」会生成一个 `Read View`，然后整个事务期间都在用这个 `Read View`，在 `undo log` 版本链找到的是事务启动前的记录，因此每次查询的数据都是一样的，即使中途有其他事务插入新纪录，也查询不到这条数据。
### 当前读
针对当前读，即 `select ... for update` 等语句，通过 `next-key lock` 方式解决，因为当执行 `select ... for update` 语句的时候，会加上 `next-key lock`，如果有其他事务在 `next-key lock` 锁范围内插入一条记录，那么这个插入语句就会被阻塞，无法成功插入，所以就能避免幻读问题。
事务 `A` 执行这条锁定读语句后，就在对表中的记录加上 `id` 范围为 `(2, +∞]` 的 `next-key lock`。然后，事务 `B` 在执行插入语句的时候，判断到插入的位置被事务 A 加 `next-key lock`，于是事物 `B` 会生成一个插入意向锁，同时进入等待状态，直到事务 `A` 提交事务。这就避免由于事务 `B` 插入新记录而导致事务 `A` 发生幻读的现象。
![](https://img-blog.csdnimg.cn/3af285a8e70f4d4198318057eb955520.png?)
### 发生幻读的场景
可重复读隔离级别下虽然很大程度上避免幻读，但是还是没有能完全解决幻读。
场景 1：
![](https://img-blog.csdnimg.cn/7f9df142b3594daeaaca495abb7133f5.png)
事务 A 执行查询 id = 5 的记录，此时表中是没有该记录的，所以查询不出来。
```sql
# 事务 A
mysql> begin;
mysql> select * from t_stu where id = 5;
```
然后事务 B 插入一条 id = 5 的记录，并且提交事务。
```sql
# 事务 B
mysql> begin;
mysql> insert into t_stu values(5, '小美', 18);
mysql> commit;
```
此时，事务 A 更新 id = 5 这条记录，事务 A 看不到 id = 5 这条记录，但是他去更新了这条记录，然后再次查询 id = 5 的记录，事务 A 就能看到事务 B 插入的纪录了，幻读就是发生在这种违和的场景。
```sql
# 事务 A
mysql> update t_stu set name = '小林coding' where id = 5;

mysql> select * from t_stu where id = 5;
+----+--------------+------+
| id | name         | age  |
+----+--------------+------+
|  5 | 小林coding   |   18 |
+----+--------------+------+
```
整个发生幻读的时序图如下：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/mysql/锁/幻读发生.drawio.png)
在可重复读隔离级别下，事务 A 第一次执行普通的 select 语句时生成了一个 ReadView，之后事务 B 向表中新插入了一条 id = 5 的记录并提交。接着，事务 A 对 id = 5 这条记录进行了更新操作，在这个时刻，这条新记录的 trx_id 隐藏列的值就变成了事务 A 的事务 id，之后事务 A  再使用普通 select 语句去查询这条记录时就可以看到这条记录了，于是就发生了幻读。
因为这种特殊现象的存在，所以认为 MySQL Innodb 中的 MVCC 并不能完全避免幻读现象。
场景 2：
先快照读后当前读的场景：
- T1 时刻：事务 A 先执行「快照读语句」：select * from t_test where id > 100 得到了 3 条记录。
- T2 时刻：事务 B 往插入一个 id=200 的记录并提交；
- T3 时刻：事务 A 再执行「当前读语句」 select * from t_test where id > 100 for update 就会得到 4 条记录，此时也发生了幻读现象。
要避免这类特殊场景下发生幻读的现象的话，就是尽量在开启事务之后，马上执行 select ... for update 这类当前读的语句，因为它会对记录加 next-key lock，从而避免其他事务插入一条新记录。
上述快照读解决幻读的例子是两次快照读不会发生幻读，但这里是先快照读再当前读，由于当前读必须获取最新的数据，因此发生幻读。

第一个例子：对于快照读， MVCC 并不能完全避免幻读现象。因为当事务 A 更新一条事务 B 插入的记录，那么事务 A 前后两次查询的记录条目就不一样了，所以就发生幻读。
第二个例子：对于当前读，如果事务开启后，并没有执行当前读，而是先快照读，然后这期间如果其他事务插入了一条记录，那么事务后续使用当前读进行查询的时候，就会发现两次查询的记录条目就不一样了，所以就发生幻读。
所以，MySQL 可重复读隔离级别并没有彻底解决幻读，只是很大程度上避免了幻读现象的发生。
要避免这类特殊场景下发生幻读的现象的话，就是尽量在开启事务之后，马上执行 select ... for update 这类当前读的语句，因为它会对记录加 next-key lock，从而避免其他事务插入一条新记录。
## ReadView 分析
### 可重复读例子1
假设现在表 `hero` 中只有一条由事务 `id` 为 80 的事务插入的一条记录：
```mysql
mysql> SELECT * FROM hero;
+--------+--------+---------+
| number | name   | country |
+--------+--------+---------+
|      1 | 刘备   | 蜀      |
+--------+--------+---------+
```
只有在对表中的记录做改动时，即执行 `INSERT`、`DELETE`、`UPDATE` 这些语句时才会为事务分配事务 `id`，否则在一个只读事务中的事务 `id` 值都默认为 0。
比方说现在系统里有两个事务id分别为100、200的事务在执行：
```mysql
# Transaction 100
BEGIN;

UPDATE hero SET name = '关羽' WHERE number = 1;

UPDATE hero SET name = '张飞' WHERE number = 1;
# Transaction 200
BEGIN;
# 更新一些别的表的记录，使其分配事务 id
```
此刻，表 `hero` 中 `number` 为 1 的记录得到的版本链表如下所示：
![image-20230125171435370](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125171435370.png)
假设现在有一个使用 `READ COMMITTED` 隔离级别的事务开始执行：
```mysql
# 使用READ COMMITTED隔离级别的事务
BEGIN;

# SELECT1：Transaction 100、200未提交
SELECT * FROM hero WHERE number = 1; # 得到的列name的值为'刘备'
```
这个 `SELECT1` 的执行过程如下：
- 在执行 `SELECT` 语句时会先生成一个 `ReadView`，`ReadView` 的 `m_ids` 列表的内容就是 `[100, 200]`，`min_trx_id` 为 100，`max_trx_id` 为 201，`creator_trx_id` 为 0。
- 然后从版本链中挑选可见的记录，从图中可以看出，最新版本的列name的内容是'张飞'，该版本的trx_id值为100，在m_ids列表内，所以不符合可见性要求，根据roll_pointer跳到下一个版本。
- 下一个版本的列name的内容是'关羽'，该版本的trx_id值也为100，也在m_ids列表内，所以也不符合要求，继续跳到下一个版本。
- 下一个版本的列name的内容是'刘备'，该版本的trx_id值为80，小于ReadView中的min_trx_id值100，所以这个版本是符合要求的，最后返回给用户的版本就是这条列name为'刘备'的记录。
之后，把事务id为100的事务提交一下，就像这样：
```mysql
# Transaction 100
BEGIN;

UPDATE hero SET name = '关羽' WHERE number = 1;

UPDATE hero SET name = '张飞' WHERE number = 1;

COMMIT;
```
然后再到事务id为200的事务中更新一下表hero中number为1的记录：
```mysql
# Transaction 200
BEGIN;

# 更新了一些别的表的记录
...

UPDATE hero SET name = '赵云' WHERE number = 1;

UPDATE hero SET name = '诸葛亮' WHERE number = 1;
```
此刻，表hero中number为1的记录的版本链就长这样：
![image-20230125171444170](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125171444170.png)
然后再到刚才使用READ COMMITTED隔离级别的事务中继续查找这个number为1的记录，如下：
```mysql
# 使用READ COMMITTED隔离级别的事务
BEGIN;

# SELECT1：Transaction 100、200均未提交
SELECT * FROM hero WHERE number = 1; # 得到的列name的值为'刘备'

# SELECT2：Transaction 100提交，Transaction 200未提交
SELECT * FROM hero WHERE number = 1; # 得到的列name的值为'张飞'
```
这个SELECT2的执行过程如下：
- 在执行SELECT语句时会又会单独生成一个ReadView，该ReadView的m_ids列表的内容就是[200]（事务id为100的那个事务已经提交了，所以再次生成快照时就没有它了），min_trx_id为200，max_trx_id为201，creator_trx_id为0。
- 然后从版本链中挑选可见的记录，从图中可以看出，最新版本的列name的内容是'诸葛亮'，该版本的trx_id值为200，在m_ids列表内，所以不符合可见性要求，根据roll_pointer跳到下一个版本。
- 下一个版本的列name的内容是'赵云'，该版本的trx_id值为200，也在m_ids列表内，所以也不符合要求，继续跳到下一个版本。
- 下一个版本的列name的内容是'张飞'，该版本的trx_id值为100，小于ReadView中的min_trx_id值200，所以这个版本是符合要求的，最后返回给用户的版本就是这条列name为'张飞'的记录。
以此类推，如果之后事务id为200的记录也提交了，再次在使用READ COMMITTED隔离级别的事务中查询表hero中number值为1的记录时，得到的结果就是'诸葛亮'。
### 读提交例子1
比方说现在系统里有两个事务id分别为100、200的事务在执行：
```mysql
# Transaction 100
BEGIN;

UPDATE hero SET name = '关羽' WHERE number = 1;

UPDATE hero SET name = '张飞' WHERE number = 1;
# Transaction 200
BEGIN;
# 更新了一些别的表的记录
```

此刻，表hero中number为1的记录得到的版本链表如下所示：

![image-20230125171449259](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125171449259.png)

假设现在有一个使用REPEATABLE READ隔离级别的事务开始执行：

```mysql
# 使用REPEATABLE READ隔离级别的事务
BEGIN;

# SELECT1：Transaction 100、200未提交
SELECT * FROM hero WHERE number = 1; # 得到的列name的值为'刘备'
```

这个SELECT1的执行过程如下：

- 在执行SELECT语句时会先生成一个ReadView，ReadView的m_ids列表的内容就是[100, 200]，min_trx_id为100，max_trx_id为201，creator_trx_id为0。
- 然后从版本链中挑选可见的记录，从图中可以看出，最新版本的列name的内容是'张飞'，该版本的trx_id值为100，在m_ids列表内，所以不符合可见性要求，根据roll_pointer跳到下一个版本。
- 下一个版本的列name的内容是'关羽'，该版本的trx_id值也为100，也在m_ids列表内，所以也不符合要求，继续跳到下一个版本。
- 下一个版本的列name的内容是'刘备'，该版本的trx_id值为80，小于ReadView中的min_trx_id值100，所以这个版本是符合要求的，最后返回给用户的版本就是这条列name为'刘备'的记录。

之后，把事务id为100的事务提交一下，就像这样：

```mysql
# Transaction 100
BEGIN;

UPDATE hero SET name = '关羽' WHERE number = 1;

UPDATE hero SET name = '张飞' WHERE number = 1;

COMMIT;
```

然后再到事务id为200的事务中更新一下表hero中number为1的记录：

```mysql
# Transaction 200
BEGIN;

# 更新了一些别的表的记录
...

UPDATE hero SET name = '赵云' WHERE number = 1;

UPDATE hero SET name = '诸葛亮' WHERE number = 1;
```

此刻，表hero中number为1的记录的版本链就长这样：

![image-20230125171623034](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125171623034.png)

然后再到刚才使用REPEATABLE READ隔离级别的事务中继续查找这个number为1的记录，如下：

```mysql
# 使用REPEATABLE READ隔离级别的事务
BEGIN;

# SELECT1：Transaction 100、200均未提交
SELECT * FROM hero WHERE number = 1; # 得到的列name的值为'刘备'

# SELECT2：Transaction 100提交，Transaction 200未提交
SELECT * FROM hero WHERE number = 1; # 得到的列name的值仍为'刘备'
```

这个SELECT2的执行过程如下：

- 因为当前事务的隔离级别为REPEATABLE READ，而之前在执行SELECT1时已经生成过ReadView了，所以此时直接复用之前的ReadView，之前的ReadView的m_ids列表的内容就是[100, 200]，min_trx_id为100，max_trx_id为201，creator_trx_id为0。
- 然后从版本链中挑选可见的记录，从图中可以看出，最新版本的列name的内容是'诸葛亮'，该版本的trx_id值为200，在m_ids列表内，所以不符合可见性要求，根据roll_pointer跳到下一个版本。
- 下一个版本的列name的内容是'赵云'，该版本的trx_id值为200，也在m_ids列表内，所以也不符合要求，继续跳到下一个版本。
- 下一个版本的列name的内容是'张飞'，该版本的trx_id值为100，而m_ids列表中是包含值为100的事务id的，所以该版本也不符合要求，同理下一个列name的内容是'关羽'的版本也不符合要求。继续跳到下一个版本。
- 下一个版本的列name的内容是'刘备'，该版本的trx_id值为80，小于ReadView中的min_trx_id值100，所以这个版本是符合要求的，最后返回给用户的版本就是这条列c为'刘备'的记录。

也就是说两次SELECT查询得到的结果是重复的，记录的列c值都是'刘备'，这就是可重复读的含义。如果之后再把事务id为200的记录提交了，然后再到刚才使用REPEATABLE READ隔离级别的事务中继续查找这个number为1的记录，得到的结果还是'刘备'。
### 可重复读例子2
**可重复读隔离级别是启动事务时生成一个 Read View，然后整个事务期间都在用这个 Read View**。
假设事务 A （事务 id 为51）启动后，紧接着事务 B （事务 id 为52）也启动了，那这两个事务创建的 Read View 如下：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost4@main/mysql/事务隔离/事务ab的视图-new.png)
事务 A 和 事务 B 的 Read View 具体内容如下：
- 在事务 A 的 Read View 中，它的事务 id 是 51，由于它是第一个启动的事务，所以此时活跃事务的事务 id 列表就只有 51，活跃事务的事务 id 列表中最小的事务 id 是事务 A 本身，下一个事务 id 则是 52。
- 在事务 B 的 Read View 中，它的事务 id 是 52，由于事务 A 是活跃的，所以此时活跃事务的事务 id 列表是 51 和 52，**活跃的事务 id 中最小的事务 id 是事务 A**，下一个事务 id 应该是 53。
接着，在可重复读隔离级别下，事务 A 和事务 B 按顺序执行了以下操作：

- 事务 B 读取小林的账户余额记录，读到余额是 100 万；
- 事务 A 将小林的账户余额记录修改成 200 万，并没有提交事务；
- 事务 B 读取小林的账户余额记录，读到余额还是 100 万；
- 事务 A 提交事务；
- 事务 B 读取小林的账户余额记录，读到余额依然还是 100 万；

接下来，跟大家具体分析下。

事务 B 第一次读小林的账户余额记录，在找到记录后，它会先看这条记录的 trx_id，此时**发现 trx_id 为 50，比事务 B 的 Read View 中的 min_trx_id 值（51）还小，这意味着修改这条记录的事务早就在事务 B 启动前提交过了，所以该版本的记录对事务 B 可见的**，也就是事务 B 可以获取到这条记录。

接着，事务 A 通过 update 语句将这条记录修改了（还未提交事务），将小林的余额改成 200 万，这时 MySQL 会记录相应的  `undo log` ，并以链表的方式串联起来，形成**版本链**，如下图：

![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost4@main/mysql/事务隔离/事务ab的视图2.png)

你可以在上图的「记录的字段」看到，由于事务 A 修改了该记录，以前的记录就变成旧版本记录了，于是最新记录和旧版本记录通过链表的方式串起来，而且最新记录的 trx_id 是事务 A 的事务 id（trx_id = 51）。

然后事务 B 第二次去读取该记录，**发现这条记录的 trx_id 值为 51，在事务 B 的 Read View 的 min_trx_id 和 max_trx_id 之间，则需要判断 trx_id 值是否在  m_ids 范围内，判断的结果是在的，那么说明这条记录是被还未提交的事务修改的，这时事务 B 并不会读取这个版本的记录。而是沿着  `undo log`  链条往下找旧版本的记录，直到找到 trx_id 「小于」事务 B 的 Read View 中的 min_trx_id 值的第一条记录**，所以事务 B 能读取到的是 trx_id 为 50 的记录，也就是小林余额是 100 万的这条记录。
最后，当事物 A 提交事务后，由于隔离级别时「可重复读」，所以事务 B 再次读取记录时，还是基于启动事务时创建的 Read View 来判断当前版本的记录是否可见。所以，即使事物 A 将小林余额修改为 200 万并提交了事务， 事务 B 第三次读取记录时，读到的记录都是小林余额是 100 万的这条记录。
就是通过这样的方式实现了，「可重复读」隔离级别下在事务期间读到的记录都是事务启动前的记录。
### 读提交例子2
读提交隔离级别是在每次读取数据时，都会生成一个新的 Read View。
也意味着，事务期间的多次读取同一条数据，前后两次读的数据可能会出现不一致，因为可能这期间另外一个事务修改了该记录，并提交了事务。
那读提交隔离级别是怎么工作呢？我们还是以前面的例子来聊聊。
假设事务 A （事务 id 为51）启动后，紧接着事务 B （事务 id 为52）也启动了，接着按顺序执行了以下操作：
- 事务 B 读取数据（创建 Read View），小林的账户余额为 100 万；
- 事务 A 修改数据（还没提交事务），将小林的账户余额从 100 万修改成了 200 万；
- 事务 B 读取数据（创建 Read View），小林的账户余额为 100 万；
- 事务 A 提交事务；
- 事务 B 读取数据（创建 Read View），小林的账户余额为 200 万；
那具体怎么做到的呢？我们重点看事务 B 每次读取数据时创建的  Read View。前两次 事务 B 读取数据时创建的  Read View 如下图：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost4@main/mysql/事务隔离/读提交事务.png)
我们来分析下为什么事务 B 第二次读数据时，读不到事务 A （还未提交事务）修改的数据？
事务 B 在找到小林这条记录时，会看这条记录的 trx_id 是 51，在事务 B 的 Read View 的 min_trx_id 和 max_trx_id 之间，接下来需要判断 trx_id 值是否在  m_ids 范围内，判断的结果是在的，那么说明**这条记录是被还未提交的事务修改的，这时事务 B 并不会读取这个版本的记录**。而是，沿着  `undo log`  链条往下找旧版本的记录，直到找到 trx_id 「小于」事务 B 的 Read View 中的 min_trx_id 值的第一条记录，所以事务 B 能读取到的是 trx_id 为 50 的记录，也就是小林余额是 100 万的这条记录。
我们来分析下为什么事务 A 提交后，事务 B 就可以读到事务 A 修改的数据？
在事务 A 提交后，**由于隔离级别是「读提交」，所以事务 B 在每次读数据的时候，会重新创建  Read View**，此时事务 B 第三次读取数据时创建的  Read View 如下：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/ImageHost4@main/mysql/事务隔离/读提交事务2.drawio.png)
事务 B 在找到小林这条记录时，**会发现这条记录的 trx_id 是 51，比事务 B 的 Read View 中的 min_trx_id 值（52）还小，这意味着修改这条记录的事务早就在创建  Read View 前提交过了，所以该版本的记录对事务 B 是可见的**。
正是因为在读提交隔离级别下，事务每次读数据时都重新创建 Read View，那么在事务期间的多次读取同一条数据，前后两次读的数据可能会出现不一致，因为可能这期间另外一个事务修改了该记录，并提交了事务。