# InnoDB 数据页结构
``InnoDB`` 将数据划分为若干个页，以页作为磁盘和内存之间交互的基本单位，`InnoDB` 中页的大小一般为 `16KB`。数据页代表的这块 `16KB` 大小的存储空间可以被划分为多个部分，不同部分有不同的功能，各个部分如图所示：
![image-20230120140315614](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120140315614.png)
从图中可以看出，一个 `InnoDB` 数据页的存储空间大致被划分成 7 个部分，有的部分占用的字节数是确定的，有的部分占用的字节数是不确定的：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306225059.png)
## 记录在页中的存储
在页的 7 个组成部分中，存储的记录会按照指定的行格式存储到 `User Records` 部分。但是在一开始生成页的时候，其实并没有 `User Records` 这个部分，每当插入一条记录，都会从 `Free Space` 部分，也就是尚未使用的存储空间中申请一个记录大小的空间划分到 `User Records` 部分，当 `Free Space` 部分的空间全部被 `User Records` 部分替代掉之后，也就意味着这个页使用完，如果还有新的记录插入的话，就需要去申请新的页，这个过程的图示如下：
![image-20230125230529541](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230529541.png)
### 记录头信息
```mysql
mysql> CREATE TABLE page_demo(
    ->     c1 INT,
    ->     c2 INT,
    ->     c3 VARCHAR(10000),
    ->     PRIMARY KEY (c1)
    -> ) CHARSET=ascii ROW_FORMAT=Compact;
```
把 `c1` 列指定为主键，所以在具体的行格式中 `InnoDB` 就没有创建 `row_id` 隐藏列，而且为这个表指定 `ascii` 字符集以及 `Compact` 的行格式。所以这个表中记录的行格式示意图就是这样的：
![image-20230120143953276](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120143953276.png)
记录头信息中各个属性：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306225400.png)
![image-20230120180033194](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120180033194.png)
下边向 `page_demo` 表中插入几条记录：
```mysql
mysql> INSERT INTO page_demo VALUES(1, 100, 'aaaa'), (2, 200, 'bbbb'), (3, 300, 'cccc'), (4, 400, 'dddd');
```
示意图就是：
![image-20230120180042831](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120180042831.png)
### delete_mask
这个属性标记着当前记录是否被删除，占用 1 个二进制位，值为 `0` 代表记录并没有被删除，为 `1`代表被删除，实际上它还在真实的磁盘上。
这些被删除的记录之所以不立即从磁盘上移除，是因为移除它们之后把其他的记录在磁盘上重新排列需要性能消耗，所以只是打一个删除标记，所有被删除掉的记录都会组成一个所谓的垃圾链表，在这个链表中的记录占用的空间称之为可重用空间，之后如果有新记录插入到表中的话，可能把这些被删除的记录占用的存储空间覆盖掉。
### min_rec_mask
`B+` 树的每层非叶子节点中的最小记录都会添加该标记，自己插入的四条记录的 `min_rec_mask` 值都是 0，意味着它们都不是 `B+` 树的非叶子节点中的最小记录。
### n_owned
详见页目录
### heap_no
这个属性表示当前记录在本页中的位置，从图中可以看出来，插入的 4 条记录在本页中的位置分别是：2、3、4、5。`InnoDB` 自动给每个页里加入两个记录，由于这两个记录并不是自己插入的，所以有时候也称为伪记录或者虚拟记录。这两个伪记录一个代表最小记录，一个代表最大记录。
对于一条完整的记录来说，比较记录的大小就是比较主键的大小。比如插入的 4 行记录的主键值分别是：1、2、3、4，这也就意味着这 4 条记录的大小从小到大依次递增。
但是不管向页中插入多少自己的记录，`InnoDB` 都规定定义的两条伪记录分别为最小记录与最大记录。这两条记录都是由 5 字节大小的记录头信息和 8 字节大小的一个固定的部分组成的，如图所示：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306230057.png)
由于这两条记录不是自己定义的记录，所以它们并不存放在页的 `User Records` 部分，被单独放在一个称为 `Infimum + Supremum` 的部分，如图所示：
![image-20230120181334774](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120181334774.png)
从图中可以看出来，最小记录和最大记录的 `heap_no` 值分别是 0 和 1，也就是说它们的位置最靠前。
### record_type
这个属性表示当前记录的类型，一共有 4 种类型的记录，0 表示普通记录，1 表示 `B+` 树非叶节点记录，2 表示最小记录，3 表示最大记录。从图中也可以看出来，自己插入的记录就是普通记录，它们的 `record_type` 值都是0，而最小记录和最大记录的 `record_type` 值分别为 2 和 3。
### next_record
表示从当前记录的真实数据到下一条记录的真实数据的地址偏移量。
比方说第一条记录的 `next_record` 值为 32，意味着从第一条记录的真实数据的地址处向后找 32 个字节便是下一条记录的真实数据。这其实是个链表，可以通过一条记录找到它的下一条记录。但是下一条记录指得并不是按照插入顺序的下一条记录，而是按照主键值由小到大的顺序的下一条记录。
而且规定 `Infimum` 记录的下一条记录就是本页中主键值最小的用户记录，而本页中主键值最大的用户记录的下一条记录就是 `Supremum` 记录，用箭头替代一下 `next_record` 中的地址偏移量：
![image-20230120181406341](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120181406341.png)
从图中可以看出来，记录按照主键从小到大的顺序形成一个单链表。最大记录的 `next_record` 的值为0，这也就是说最大记录是没有下一条记录，它是这个单链表中的最后一个节点。如果从中删除掉一条记录，这个链表也是会跟着变化的，比如把第 2 条记录删掉：
```mysql
mysql> DELETE FROM page_demo WHERE c1 = 2;
```
删掉第 2 条记录后的示意图就是：
![image-20230120181419894](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120181419894.png)
从图中可以看出来，删除第 2 条记录前后主要发生这些变化：
- 第 2 条记录并没有从存储空间中移除，而是把该条记录的 `delete_mask` 值设置为 1。
- 第 2 条记录的 `next_record` 值变为 0，意味着该记录没有下一条记录。
- 第 1 条记录的 `next_record` 指向第 3 条记录。
- 最大记录的 `n_owned` 值从 5 变成 4。
所以，不论怎么对页中的记录做增删改操作，`InnoDB` 始终会维护一条记录的单链表，链表中的各个节点是按照主键值由小到大的顺序连接起来的。
`next_record` 这个指针指向记录头信息和真实数据之间的位置，因为这个位置向左读取就是记录头信息，向右读取就是真实数据。变长字段长度列表、`NULL` 值列表中的信息都是逆序存放，这样可以使记录中位置靠前的字段和它们对应的字段长度信息在内存中的距离更近，可能会提高高速缓存的命中率。

因为主键值为 `2` 的记录被删掉，但是存储空间却没有回收，如果再次把这条记录插入到表中：
![image-20230120181430458](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120181430458.png)
从图中可以看到，`InnoDB` 并没有因为新记录的插入而为它申请新的存储空间，而是直接复用原来被删除记录的存储空间。
## Page Directory
记录在页中按照主键值由小到大顺序串联成一个单链表，`InnoDB` 为便于查找主键值，制作页目录，制作过程是这样的：
1. 将所有正常的记录，包括最大和最小记录，划分为几个组。
2. 每个组的最后一条记录的头信息中的 `n_owned` 属性表示该组内共有几条记录。
3. 将每个组的最后一条记录的地址偏移量单独提取出来按顺序存储到靠近页的尾部的地方，这个地方就是 `Page Directory`，也就是页目录。页面目录中的这些地址偏移量被称为槽，所以这个页面目录就是由槽组成的。
`page_demo` 表中正常的记录共有 6 条，`InnoDB` 会把它们分成两组，第一组中只有一个最小记录，第二组中是剩余的 5 条记录，看下边的示意图：
![image-20230120181439594](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230120181439594.png)
- 现在页目录部分中有两个槽，意味着记录被分成两个组，槽 1 中的值是 112，代表最大记录的地址偏移量，槽 0 中的值是 99，代表最小记录的地址偏移量。
- 最小记录的 `n_owned` 值为1，这就代表着以最小记录结尾的这个分组中只有 1 条记录，也就是最小记录本身。最大记录的 `n_owned` 值为 5，这就代表着以最大记录结尾的这个分组中只有 5 条记录，包括最大记录本身还有自己插入的 4 条记录。
从逻辑上看一下这些记录和页目录的关系：
![image-20230121112555346](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230121112555346.png)
`InnoDB` 的对每个分组中的记录条数是有规定的：对于最小记录所在的分组只能有 1 条记录，最大记录所在的分组拥有的记录条数只能在 1~8 条之间，剩下的分组中记录的条数范围只能在是 4~8 条之间。所以分组是按照下边的步骤进行的：
- 初始情况下一个数据页里只有最小记录和最大记录两条记录，它们分属于两个分组。
- 之后每插入一条记录，都会从页目录中找到主键值比本记录的主键值大并且差值最小的槽，然后把该槽对应的记录的 `n_owned` 值加1，直到该组中的记录数等于8个。
- 在一个组中的记录数等于 8 个后再插入一条记录时，会将组中的记录拆分成两个组，一个组中 4 条记录，另一个 5 条记录。这个过程会在页目录中新增一个槽来记录这个新增分组中最大的那条记录的偏移量。
由于现在 `page_demo` 表中的记录太少，无法演示添加页目录之后加快查找速度的过程，所以再往`page_demo` 表中添加一些记录：
```mysql
mysql> INSERT INTO page_demo VALUES(5, 500, 'eeee'), (6, 600, 'ffff'), (7, 700, 'gggg'), (8, 800, 'hhhh'), (9, 900, 'iiii'), (10, 1000, 'jjjj'), (11, 1100, 'kkkk'), (12, 1200, 'llll'), (13, 1300, 'mmmm'), (14, 1400, 'nnnn'), (15, 1500, 'oooo'), (16, 1600, 'pppp');
Query OK, 12 rows affected (0.00 sec)
Records: 12  Duplicates: 0  Warnings: 0
```
现在页里边就一共18 条记录，包括最小和最大记录，这些记录被分成 5 个组，如图所示：
![image-20230121112604039](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230121112604039.png)
在一个数据页中查找指定主键值的记录的过程分为两步：
1. 通过二分法确定该记录所在的槽，并找到该槽所在分组中主键值最小的那条记录。
2. 通过记录的 `next_record` 属性遍历该槽所在的组中的各个记录。
## Page Header
`InnoDB` 为能得到一个数据页中存储的记录的状态信息，比如本页中已经存储多少条记录，第一条记录的地址是什么，页目录中存储了多少个槽等等，在页中定义一个叫 `Page Header` 的部分，这个部分占用固定的 56 个字节，专门存储各种状态信息，具体各个字节：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240307105319.png)
- `PAGE_DIRECTION`：假如新插入的一条记录的主键值比上一条记录的主键值大，这条记录的插入方向是右边，反之则是左边。用来表示最后一条记录插入方向的状态就是 `PAGE_DIRECTION`。
- `PAGE_N_DIRECTION`：假设连续几次插入新记录的方向都是一致的，`InnoDB` 会把沿着同一个方向插入记录的条数记下来，这个条数就用 `PAGE_N_DIRECTION` 这个状态表示，如果最后一条记录的插入方向改变了的话，这个状态的值会被清零重新统计。
> “You can't connect the dots looking forward; you can only connect them looking backwards. So you have to trust that the dots will somehow connect in your future.You have to trust in something - your gut, destiny, life, karma, whatever. This approach has never let me down, and it has made all the difference in my life.”
## File Header
`Page Header` 是专门针对数据页记录的各种状态信息，`File Header` 针对各种类型的页都通用，也就是说不同类型的页都会以 `File Header` 作为第一个组成部分，它描述一些针对各种页都通用的一些信息，这个部分占用固定的 38 个字节，是由下边这些内容组成的：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240307105447.png)
`FIL_PAGE_OFFSET`：每一个页都有一个单独的页号，`InnoDB` 通过页号来可以唯一定位一个页。
`FIL_PAGE_TYPE`：代表当前页的类型，`InnoDB` 为不同的目的而把页分为不同的类型，存放记录的数据页的类型其实是 `FIL_PAGE_INDEX`，也就是所谓的索引页，具体如下表`：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240307105457.png)
`FIL_PAGE_PREV` 和 `FIL_PAGE_NEXT`：`InnoDB`都是以页为单位存放数据的，有时候存放某种类型的数据占用的空间非常大，`InnoDB` 可能不可以一次性为这么多数据分配一个非常大的存储空间，如果分散到多个不连续的页中存储的话需要把这些页关联起来，FIL_PAGE_PREV 和 FIL_PAGE_NEXT 就分别代表本页的上一个和下一个页的页号。这样通过建立一个双向链表把许许多多的页就都串联起来，而无需这些页在物理上真正连着。
并不是所有类型的页都有上一个和下一个页的属性，只是数据页是有这两个属性的，所以所有的数据页其实是一个双链表，就像这样：
![image-20230121112624542](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230121112624542.png)
## File Trailer
为了检测一个页是否完整（也就是在同步的时候有没有发生只同步一半的情况，`InnoDB` 在每个页的尾部都加 `File Trailer` 部分，这个部分由 8 个字节组成，可以分成 2 个小部分：
- 前 4 个字节代表页的校验和：这个部分是和 `File Header` 中的校验和相对应的。每当一个页面在内存中修改，在同步之前就要把它的校验和算出来，因为 `File Header` 在页面的前边，所以校验和会被首先同步到磁盘，当完全写完时，校验和也会被写到页的尾部，如果完全同步成功，则页的首部和尾部的校验和应该是一致的。如果写了一半儿断电了，那么在 `File Header` 中的校验和就代表着已经修改过的页，而在 `File Trailer` 中的校验和代表着原先的页，二者不同则意味着同步中间出了错。
- 后 4 个字节代表页面被最后修改时对应的日志序列位置 `LSN`
