# 表空间
表空间是一个抽象的概念，对于系统表空间来说，对应着文件系统中一个或多个实际文件，对于每个独立表空间来说，对应着文件系统中一个名为表名 `.ibd` 的实际文件。
## 页面通用部分
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306224646.png)

从上图中可以看出，任何类型的页都会包含这两个部分：
- `File Header`：记录页面的一些通用信息
- `File Trailer`：校验页是否完整，保证从内存到磁盘刷新时内容的一致性。
`File Header`的各个组成部分：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306224701.png)
- 表空间中的每一个页都对应着一个页号，也就是 `FIL_PAGE_OFFSET`，这个页号由 4 个字节组成，所以一个表空间最多可以拥有 2³² 个页，如果按照页的默认大小 `16KB` 来算，一个表空间最多支持 `64TB` 的数据。表空间的第一个页的页号为 0，之后的页号分别是1，2，3...依此类推
- 某些类型的页可以组成链表，链表中的页可以不按照物理顺序存储，而是根据 `FIL_PAGE_PREV` 和 `FIL_PAGE_NEXT` 来存储上一个页和下一个页的页号，这两个字段主要是为 `INDEX` 类型的页，也就是数据页建立 `B+` 树后，为每层节点建立双向链表用的，一般类型的页是不使用这两个字段的。
- 每个页的类型由 `FIL_PAGE_TYPE` 表示，比如像数据页的该字段的值就是 `0x45BF`，不同类型的页在该字段上的值是不同的。
## 独立表空间
### 区
对于 `16KB` 的页来说，连续的 64 个页就是一个区，也就是说一个区默认占用 `1MB` 空间大小。不论是系统表空间还是独立表空间，都可以看成是由若干个区组成的，每 256 个区被划分成一组：
![image-20230121142033346](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230121142033346.png)
其中 `extent 0 ~ extent 255` 是第一个组，依此类推可以划分更多的组。这些组的头几个页面的类型都是类似的，就像这样：
![image-20230121142039942](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230121142039942.png)
从上图中能得到如下信息：
- 第一个组最开始的3个页面的类型是固定的，也就是说 extent 0 这个区最开始的 3 个页面的类型是固定的，分别是：
  - `FSP_HDR` 类型：这个类型的页面是用来登记整个表空间的一些整体属性以及本组所有的区，也就是 `extent 0 ~ extent 255` 这 256 个区的属性，整个表空间只有一个 `FSP_HDR` 类型的页面。
  - `IBUF_BITMAP` 类型：这个类型的页面是存储本组所有的区的所有页面关于 `INSERT BUFFER` 的信息。
  - `INODE` 类型：这个类型的页面存储许多 `INODE` 数据结构
- 其余各组最开始的 2 个页面的类型是固定的，也就是说 `extent 256`、`extent 512` 这些区最开始的 2 个页面的类型是固定的，分别是：
  - `XDES` 类型：全称是 `extent descriptor`，用来登记本组 256 个区的属性。`FSP_HDR` 类型的页面其实和 `XDES` 类型的页面的作用类似，只不过 `FSP_HDR` 类型的页面还会额外存储一些表空间的属性。
  - `IBUF_BITMAP` 类型。
因此表空间被划分为许多连续的区，每个区默认由 64 个页组成，每 256 个区划分为一组，每个组的最开始的几个页面类型是固定的。
### 段
从理论上说，不引入区的概念只使用页的概念对存储引擎的运行并没啥影响，但是来考虑一下下边这个场景：
- 每向表中插入一条记录，本质上就是向该表的聚簇索引以及所有二级索引代表的 `B+` 树的节点中插入数据。而 `B+` 树的每一层中的页都会形成一个双向链表，如果是以页为单位来分配存储空间的话，双向链表相邻的两个页之间的物理位置可能离得非常远。
- `B+` 树索引范围查询只需要定位到最左边的记录和最右边的记录，然后沿着双向链表一直扫描就可以，而如果链表中相邻的两个页物理位置离得非常远，就是所谓的随机 I/O。磁盘的速度和内存的速度差好几个数量级，随机 `I/O` 是非常慢的，所以应该尽量让链表中相邻的页的物理位置也相邻，这样进行范围查询的时候才可以使用所谓的顺序 `I/O`。
所以才引入区的概念，一个区就是在物理位置上连续的 64 个页。在表中数据量大的时候，为某个索引分配空间的时候就不再按照页为单位分配，而是按照区为单位分配，甚至在表中的数据十分非常特别多的时候，可以一次性分配多个连续的区。虽然可能造成空间的浪费，但是从性能角度看，可以消除很多的随机 `I/O`。
范围查询，就是对 `B+` 树叶子节点中的记录进行顺序扫描，而如果不区分叶子节点和非叶子节点，把所有节点代表的页面放到申请到的区中的话，进行范围扫描的效果就大打折扣。所以 `InnoDB` 通过段对叶子节点和非叶子节点进行区分，一个索引会生成 2 个段，一个叶子节点段，一个非叶子节点段。
由于以完整的区为单位分配给某个段，对于数据量较小的表会太浪费存储空间，因此存在碎片区，在一个碎片区中，并不是所有的页都是为存储同一个段的数据而存在的，碎片区中的页可以用于不同的目的，比如有些页用于段 `A`，有些页用于段 `B`，有些页哪个段都不属于。碎片区直属于表空间，并不属于任何一个段。所以此后为某个段分配存储空间的策略是这样的：
- 在刚开始向表中插入数据的时候，段是从某个碎片区以单个页面为单位来分配存储空间的。
- 当某个段已经占用 32 个碎片区页面之后，就会以完整的区为单位来分配存储空间。
所以段是某些零散的页面以及一些完整的区的集合，除索引的叶子节点段和非叶子节点段之外，还有为存储一些特殊的数据而定义的段，比如回滚段。
### 区的分类
表空间是由若干个区组成的，这些区大体上可以分为4种类型：
- 空闲的区 `FREE`：现在还没有用到这个区中的任何页面。
- 有剩余空间的碎片区 `FREE_FRAG`：表示碎片区中还有可用的页面。
- 没有剩余空间的碎片区 `FULL_FRAG`：表示碎片区中的所有页面都被使用，没有空闲页面。
- 附属于某个段的区 `FSEG`。每一个索引都可以分为叶子节点段和非叶子节点段，除此之外 `InnoDB` 还会另外定义一些特殊作用的段，在这些段中的数据量很大时将使用区来作为基本的分配单位。
这 4 种类型的区也可以被称为区的 4 种状态，处于 `FREE`、`FREE_FRAG` 以及 `FULL_FRAG` 这三种状态的区都是独立的，算是直属于表空间，而处于 `FSEG` 状态的区是附属于某个段的。
为方便管理这些区，每一个区都对应着一个 `XDES Entry` 结构，这个结构记录对应的区的一些属性：
![image-20230121142045703](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230121142045703.png)
`XDES Entry` 是一个 40 个字节的结构，大致分为 4 个部分，各个部分的释义如下：
8 字节 `Segment ID`：每一个段都有一个唯一的编号，用 `ID` 表示，此处的 `Segment ID` 字段表示就是该区所在的段。当然前提是该区已经被分配给某个段，不然的话该字段的值没意义。
12 字节 `List Node`：这个部分可以将若干个 `XDES Entry` 结构串联成一个链表，如果想定位表空间内的某一个位置的话，只需指定页号以及该位置在指定页号中的页内偏移量即可。
![image-20230121142051706](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230121142051706.png)
4 字节 `State`：这个字段表明区的状态。
16 字节 `Page State Bitmap`：一个区默认有 64 个页，这 128 个比特位被划分为 64 个部分，每个部分 2 个比特位，对应区中的一个页。比如 `Page State Bitmap` 部分的第 1 和第 2 个比特位对应着区中的第 1 个页面，`Page State Bitmap` 部分的第 127 和 128 个比特位对应着区中的第64个页面，依此类推。这两个比特位的第一个位表示对应的页是否是空闲的，第二个比特位还没有用。
#### XDES Entry 链表
为得到表空间里的区状态，把状态为 `FREE/FREE_FRAG/FULL_FRAG` 的区对应的 `XDES Entry` 结构通过 `List Node` 来连接成一个链表，这个链表就称之为 `FREE/FREE_FRAG/FULL_FRAG` 链表。
向某个段中插入数据的过程：
- 当段中数据较少的时候，首先会查看表空间中是否有状态为 `FREE_FRAG` 的区，也就是找还有空闲空间的碎片区，如果找到，那么从该区中取一些零散的页把数据插进去，否则到表空间下申请一个状态为 `FREE` 的区，也就是空闲的区，把该区的状态变为 `FREE_FRAG`，然后从该新申请的区中取一些零散的页把数据插进去。之后不同的段使用零散页的时候都会从该区中取，直到该区中没有空闲空间，然后该区的状态就变成 `FULL_FRAG`。
  每当想找一个 `FREE_FRAG` 状态的区时，把 `FREE_FRAG` 链表的头节点拿出来，从这个节点中取一些零散的页来插入数据，当这个节点对应的区用完时，就修改一下这个节点的 `State` 字段的值，然后从 `FREE_FRAG` 链表中移到 `FULL_FRAG` 链表中。同理，如果 `FREE_FRAG` 链表中一个节点都没有，那么就直接从 `FREE` 链表中取一个节点移动到 `FREE_FRAG` 链表的状态，并修改该节点的 `STATE` 字段值为 `FREE_FRAG`，然后从这个节点对应的区中获取零散的页。
- 当段中数据已经占满 32 个零散的页后，就直接申请完整的区来插入数据。
为知道哪些区属于哪个段的，根据段号 `Segment ID` 来建立链表，`InnoDB` 为每个段中的区对应的 `XDES Entry` 结构建立三个链表：
- `FREE` 链表：同一个段中，所有页面都是空闲的区对应的 `XDES Entry` 结构会被加入到这个链表。注意和直属于表空间的 `FREE` 链表区别开，此处的 `FREE` 链表是附属于某个段的。
- `NOT_FULL` 链表：同一个段中，仍有空闲空间的区对应的 `XDES Entry` 结构会被加入到这个链表。
- `FULL` 链表：同一个段中，已经没有空闲空间的区对应的 `XDES Entry` 结构会被加入到这个链表。
每一个索引都对应两个段，每个段都会维护上述的 3 个链表，比如下边这个表：
  ```mysql
  CREATE TABLE t (
      c1 INT NOT NULL AUTO_INCREMENT,
      c2 VARCHAR(100),
      c3 VARCHAR(100),
      PRIMARY KEY (c1),
      KEY idx_c2 (c2)
  )ENGINE=InnoDB;
  ```
这个表t共有两个索引，一个聚簇索引，一个二级索引idx_c2，所以这个表共有4个段，每个段都会维护上述3个链表，总共是12个链表，加上我们上边说过的直属于表空间的3个链表，整个独立表空间共需要维护15个链表。所以段在数据量比较大时插入数据的话，会先获取NOT_FULL链表的头节点，直接把数据插入这个头节点对应的区中即可，如果该区的空间已经被用完，就把该节点移到FULL链表中。
#### 链表基节点
`InnoDB` 通过 `List Base Node` 找到这些链表。这个结构中包含链表的头节点和尾节点的指针以及这个链表中包含了多少节点的信息：
![image-20230125230545151](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230545151.png)
- `List Length` 表明该链表一共有多少节点，
- `First Node Page Number` 和 `First Node Offset` 表明该链表的头节点在表空间中的位置。
- `Last Node Page Number` 和 `Last Node Offset` 表明该链表的尾节点在表空间中的位置。
一般把某个链表对应的 `List Base Node` 结构放置在表空间中固定的位置。
综上所述，表空间是由若干个区组成的，每个区都对应一个 `XDES Entry` 的结构，直属于表空间的区对应的 `XDES Entry` 结构可以分成 `FREE`、`FREE_FRAG` 和 `FULL_FRAG` 这 3 个链表。每个段可以附属若干个区，每个段中的区对应的 `XDES Entry` 结构可以分成 `FREE`、`NOT_FULL` 和 `FULL` 这3个链表。每个链表都对应一个 `List Base Node` 的结构，这个结构里记录链表的头、尾节点的位置以及该链表中包含的节点数，通过这些链表管理这些区。
### 段的结构
段其实不对应表空间中某一个连续的物理区域，而是一个逻辑上的概念，由若干个零散的页面以及一些完整的区组成。像每个区都有对应的 XDES Entry 来记录这个区中的属性一样，InnoDB 为每个段都定义一个 `INODE Entry` 结构来记录一下段中的属性：
![image-20230125230617144](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230617144.png)
`Segment ID`：就是指这个 `INODE Entry` 结构对应的段的编号。
`NOT_FULL_N_USED`：这个字段指的是在NOT_FULL链表中已经使用了多少个页面。
3 个 `List Base Node` 分别为段的 `FREE` 链表、`NOT_FULL` 链表、`FULL` 链表定义 `List Base Node`，这样想查找某个段的某个链表的头节点和尾节点的时候，就可以直接到这个部分找到对应链表的`List Base Node`。
`Magic Number`：这个值是用来标记这个 `INODE Entry` 是否已经被初始化。如果这个数字是值的 97937874，表明该 `INODE Entry` 已经初始化，否则没有被初始化。
`Fragment Array Entry`：段是一些零散页面和一些完整的区的集合，每个 `Fragment Array Entry` 结构都对应着一个零散的页面，这个结构一共 4 个字节，表示一个零散页面的页号。
### 各类型页面详细情况
#### FSP_HDR类型
表空间的第一个页面，页号为 0，类型是 `FSP_HDR`，存储表空间的一些整体属性以及第一个组内 256 个区的对应的 `XDES Entry` 结构：
![image-20230125230627881](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230627881.png)
##### File Space Header
![image-20230125230634172](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230634172.png)
这个部分是用来存储表空间的一些整体属性的：
- `List Base Node for FREE List`、`List Base Node for FREE_FRAG List`、`List Base Node for FULL_FRAG List`：分别是直属于表空间的 `FREE` 链表的基节点、`FREE_FRAG` 链表的基节点、`FULL_FRAG` 链表的基节点，这三个链表的基节点在表空间的位置是固定的，就是在表空间的第一个页面 `FSP_HDR` 的 `File Space Header` 部分。
- `FRAG_N_USED`：这个字段表明在 `FREE_FRAG` 链表中已经使用的页面数量。
- `FREE Limit`：表空间都对应着具体的磁盘文件，一开始创建表空间的时候对应的磁盘文件中都没有数据，所以需要对表空间完成一个初始化操作，包括为表空间中的区建立 `XDES Entry` 结构，为各个段建立 `INODE Entry` 结构，建立各种链表的各种操作。啥时候用到啥时候初始化，`InnoDB` 为表空间定义 `FREE Limit` 这个字段，在该字段表示的页号之前的区都被初始化，之后的区尚未被初始化。
- `Next Unused Segment ID`：表中每个索引都对应 2 个段，每个段都有一个唯一的 `ID`，那当为某个表新创建一个索引的时候，就意味着要创建两个新的段。`InnoDB` 使用 `Next Unused Segment ID` 字段表明当前表空间中最大的段 `ID` 的下一个 `ID`，这样在创建新段的时候赋予新段一个唯一的 `ID` 值直接使用这个字段的值。
- `Space Flags`：表空间对于一些布尔类型或比特位的属都放在 4 个字节的 `Space Flags` 中存储，详细情况如下表。
- `List Base Node for SEG_INODES_FULL List` 和 `List Base Node for SEG_INODES_FREE List`：每个段对应的 `INODE Entry` 结构会集中存放到一个类型为 `INODE` 的页中，如果表空间中的段特别多，则会有多个 `INODE Entry` 结构，可能一个页放不下，这些 `INODE` 类型的页会组成两种列表：
`SEG_INODES_FULL` 链表：该链表中的 `INODE` 类型的页面都已经被 `INODE Entry` 结构填充满，没空闲空间存放额外的 `INODE Entry`。
`SEG_INODES_FREE` 链表：该链表中的 `INODE` 类型的页面仍有空闲空间来存放 `INODE Entry` 结构。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306220212.png)
##### XDES Entry
每一个 `XDES Entry` 结构对应表空间的一个区，一个 `XDES Entry` 结构的大小是 40 字节，但是一个页面的大小有限，只能存放有限个 `XDES Entry` 结构，所以才把 256 个区划分成一组，在每组的第一个页面中存放 256 个 `XDES Entry` 结构。`XDES Entry 0` 就对应着 `extent 0`，`XDES Entry 1` 就对应着 `extent 1`... 依此类推，`XDES Entry255` 就对应着 `extent 255`，因此每个区对应的 `XDES Entry` 结构的地址是固定的。
#### XDES类型
由于第一个组的第一个页面有些特殊，因为它也是整个表空间的第一个页面，所以除记录本组中的所有区对应的 `XDES Entry` 结构以外，还记录着表空间的一些整体属性，整个表空间里只有一个这个类型的页面。除去第一个分组以外，之后的每个分组的第一个页面只需要记录本组内所有的区对应的 `XDES Entry` 结构即可，不需要再记录表空间的属性，即 `XDES` 类型：
![image-20230125230641186](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230641186.png)
#### IBUF_BITMAP类型
对比前边介绍表空间的图，每个分组的第二个页面的类型都是 `IBUF_BITMAP`，这种类型的页里边记录一些有关 `Change Buffer` 的东西。
#### INODE类型
`InnoD` 为每个索引定义了两个段，而且为某些特殊功能定义些特殊的段。为方便管理，又为每个段设计一个 `INODE Entry` 结构，这个结构中记录关于这个段的相关属性：
![image-20230125230646359](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230646359.png)
从图中可以看出，一个 `INODE` 类型的页面是由这几部分构成的：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221004.png)
`INODE Entry` 部分，主要包括对应的段内零散页面的地址以及附属于该段的 `FREE`、`NOT_FULL` 和 `FULL` 链表的基节点。每个 `INODE Entry` 结构占用 192 字节，一个页面里可以存储 85 个这样的结构。
为方便管理这些 `INODE` 类型的页面，`InnoDB` 将这些 `INODE` 类型的页面串联成`SEG_INODES_FULL` 和 `SEG_INODES_FREE` 链表。
这两个链表的基节点就存储在 `File Space Header` 里边，以后每当新创建一个段（创建索引时就会创建段）时，都会创建一个 INODE Entry 结构与之对应，存储 `INODE Entry` 的大致过程就是这样的：
- 若 `SEG_INODES_FREE` 链表不为空，直接从该链表中获取一个节点，也就相当于获取到一个仍有空闲空间的 `INODE` 类型的页面，然后把该 `INODE Entry` 结构放到该页面中。当该页面中无剩余空间时，就把该页放到 `SEG_INODES_FULL` 链表中。
- 若 `SEG_INODES_FREE` 链表为空，则需要从表空间的 `FREE_FRAG` 链表中申请一个页面，修改该页面的类型为 `INODE`，把该页面放到 `SEG_INODES_FREE` 链表中，与此同时把该 `INODE Entry` 结构放入该页面。
### Segment Header 结构
一个索引会产生两个段，分别是叶子节点段和非叶子节点段，而每个段都会对应一个 `INODE Entry` 结构，`INDEX` 类型的页有一个 `Page Header` 部分，据此得到某个段对应的 `INODE Entry` 结构。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221539.png)
其中的 `PAGE_BTR_SEG_LEAF` 和 `PAGE_BTR_SEG_TOP` 都占用 10 个字节，对应 `Segment Header` 结构：
![image-20230125230651271](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230651271.png)
各个部分的具体释义如下：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221610.png)
`PAGE_BTR_SEG_LEAF` 记录着叶子节点段对应的 `INODE Entry` 结构的地址是哪个表空间的哪个页面的哪个偏移量，`PAGE_BTR_SEG_TOP` 记录着非叶子节点段对应的 `INODE Entry` 结构的地址是哪个表空间的哪个页面的哪个偏移量。因为一个索引只对应两个段，所以只需要在索引的根页面中记录这两个结构即可。
## 系统表空间
系统表空间的结构和独立表空间基本类似，只不过由于整个 `MySQL` 进程只有一个系统表空间，在系统表空间中会额外记录一些有关整个系统信息的页面，所以会比独立表空间多出一些记录这些信息的页面。因为这个系统表空间是表空间之首，所以它的表空间 `Space ID` 是 0。
### 系统表空间的整体结构
系统表空间与独立表空间的一个非常明显的不同之处就是在表空间开头有许多记录整个系统属性的页面，如图：
![image-20230125230704635](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230704635.png)
可以看到，系统表空间和独立表空间的前三个页面（页号分别为0、1、2，类型分别是 `FSP_HDR`、`IBUF_BITMAP`、`INODE`）的类型是一致的，只是页号为 3～7 的页面是系统表空间特有的：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221643.png)
除这几个记录系统属性的页面之外，系统表空间的 `extent 1` 和 `extent 2` 这两个区，也就是页号从 64~191 这 `128` 个页面被称为 `Doublewrite buffer`，也就是双写缓冲区。
### InnoDB数据字典
INSERT语句向表中插入的那些记录称之为用户数据，MySQL只是作为一个软件来保管这些数据，提供方便的增删改查接口而已。但是每当向一个表中插入一条记录的时候，MySQL先要校验一下插入语句对应的表存不存在，插入的列和表中的列是否符合，如果语法没有问题的话，还需要知道该表的聚簇索引和所有二级索引对应的根页面是哪个表空间的哪个页面，然后把记录插入对应索引的B+树中。所以说，MySQL除了保存着我们插入的用户数据之外，还需要保存许多额外的信息，比方说：
- 某个表属于哪个表空间，表里边有多少列
- 表对应的每一个列的类型是什么
- 该表有多少索引，每个索引对应哪几个字段，该索引对应的根页面在哪个表空间的哪个页面
- 该表有哪些外键，外键对应哪个表的哪些列
- 某个表空间对应文件系统上文件路径是什么
上述这些数据并不是我们使用INSERT语句插入的用户数据，实际上是为了更好的管理我们这些用户数据而不得已引入的一些额外数据，这些数据也称为元数据。InnoDB存储引擎特意定义了一些列的内部系统表（internal system table）来记录这些这些元数据：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221656.png)
这些系统表也被称为数据字典，它们都是以`B+`树的形式保存在系统表空间的某些页面中，其中`SYS_TABLES`、`SYS_COLUMNS`、`SYS_INDEXES`、`SYS_FIELDS`这四个表尤其重要，称之为基本系统表（basic system tables），我们先看看这4个表的结构：
#### SYS_TABLES 表
`SYS_TABLES` 表的列：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221704.png)
这个`SYS_TABLES`表有两个索引：
- 以`NAME`列为主键的聚簇索引
- 以`ID`列建立的二级索引
#### SYS_COLUMNS表
SYS_COLUMNS 表的列：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221807.png)
这个`SYS_COLUMNS`表只有一个聚集索引：
- 以`(TABLE_ID, POS)`列为主键的聚簇索引
#### SYS_INDEXES表
`SYS_INDEXES` 表的列： 
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221824.png)
这个`SYS_INDEXES`表只有一个聚集索引：以`(TABLE_ID, ID)`列为主键的聚簇索引
#### SYS_FIELDS表
`SYS_FIELDS` 表的列：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221848.png)
这个`SYS_FIELDS`表只有一个聚集索引：以`(INDEX_ID, POS)`列为主键的聚簇索引
### Data Dictionary Header页面
只要有了上述4个基本系统表，也就意味着可以获取其他系统表以及用户定义的表的所有元数据。比方说我们想看看`SYS_TABLESPACES`这个系统表里存储了哪些表空间以及表空间对应的属性，那就可以：
- 到`SYS_TABLES`表中根据表名定位到具体的记录，就可以获取到`SYS_TABLESPACES`表的`TABLE_ID`
- 使用这个`TABLE_ID`到`SYS_COLUMNS`表中就可以获取到属于该表的所有列的信息。
- 使用这个`TABLE_ID`还可以到`SYS_INDEXES`表中获取所有的索引的信息，索引的信息中包括对应的`INDEX_ID`，还记录着该索引对应的`B+`数根页面是哪个表空间的哪个页面。
- 使用`INDEX_ID`就可以到`SYS_FIELDS`表中获取所有索引列的信息。
也就是说这4个表是表中之表，那这4个表的元数据去哪里获取呢？没法搞了，只能把这4个表的元数据，就是它们有哪些列、哪些索引等信息硬编码到代码中，然后设计`InnoDB`的大叔又拿出一个固定的页面来记录这4个表的聚簇索引和二级索引对应的`B+树`位置，这个页面就是页号为`7`的页面，类型为`SYS`，记录了`Data Dictionary Header`，也就是数据字典的头部信息。除了这4个表的5个索引的根页面信息外，这个页号为`7`的页面还记录了整个InnoDB存储引擎的一些全局属性，说话太啰嗦，直接看这个页面的示意图：
![image-20230125230714006](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230125230714006.png)
可以看到这个页面由下边几个部分组成：
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240306221901.png)
可以看到这个页面里竟然有`Segment Header`部分，意味着设计InnoDB的大叔把这些有关数据字典的信息当成一个段来分配存储空间，我们就姑且称之为`数据字典段`吧。由于目前我们需要记录的数据字典信息非常少（可以看到`Data Dictionary Header`部分仅占用了56字节），所以该段只有一个碎片页，也就是页号为`7`的这个页。
接下来我们需要细细唠叨一下`Data Dictionary Header`部分的各个字段：
- `Max Row ID`：我们说过如果我们不显式的为表定义主键，而且表中也没有`UNIQUE`索引，那么`InnoDB`存储引擎会默认为我们生成一个名为`row_id`的列作为主键。因为它是主键，所以每条记录的`row_id`列的值不能重复。原则上只要一个表中的`row_id`列不重复就可以了，也就是说表a和表b拥有一样的`row_id`列也没啥关系，不过设计InnoDB的大叔只提供了这个`Max Row ID`字段，不论哪个拥有`row_id`列的表插入一条记录时，该记录的`row_id`列的值就是`Max Row ID`对应的值，然后再把`Max Row ID`对应的值加1，也就是说这个`Max Row ID`是全局共享的。
- `Max Table ID`：InnoDB存储引擎中的所有的表都对应一个唯一的ID，每次新建一个表时，就会把本字段的值作为该表的ID，然后自增本字段的值。
- `Max Index ID`：InnoDB存储引擎中的所有的索引都对应一个唯一的ID，每次新建一个索引时，就会把本字段的值作为该索引的ID，然后自增本字段的值。
- `Max Space ID`：InnoDB存储引擎中的所有的表空间都对应一个唯一的ID，每次新建一个表空间时，就会把本字段的值作为该表空间的ID，然后自增本字段的值。
- `Mix ID Low(Unused)`：这个字段没啥用，跳过。
- `Root of SYS_TABLES clust index`：本字段代表`SYS_TABLES`表聚簇索引的根页面的页号。
- `Root of SYS_TABLE_IDS sec index`：本字段代表`SYS_TABLES`表为`ID`列建立的二级索引的根页面的页号。
- `Root of SYS_COLUMNS clust index`：本字段代表`SYS_COLUMNS`表聚簇索引的根页面的页号。
- `Root of SYS_INDEXES clust index`本字段代表`SYS_INDEXES`表聚簇索引的根页面的页号。
- `Root of SYS_FIELDS clust index`：本字段代表`SYS_FIELDS`表聚簇索引的根页面的页号。
- `Unused`：这4个字节没用，跳过。
以上就是页号为`7`的页面的全部内容，初次看可能会懵逼（因为有点儿绕），大家多瞅几次。
### information_schema系统数据库
需要注意一点的是，用户是不能直接访问`InnoDB`的这些内部系统表的，除非你直接去解析系统表空间对应文件系统上的文件。不过设计InnoDB的大叔考虑到查看这些表的内容可能有助于大家分析问题，所以在系统数据库`information_schema`中提供了一些以`innodb_sys`开头的表：
```
mysql> USE information_schema;
Database changed

mysql> SHOW TABLES LIKE 'innodb_sys%';
+--------------------------------------------+
| Tables_in_information_schema (innodb_sys%) |
+--------------------------------------------+
| INNODB_SYS_DATAFILES                       |
| INNODB_SYS_VIRTUAL                         |
| INNODB_SYS_INDEXES                         |
| INNODB_SYS_TABLES                          |
| INNODB_SYS_FIELDS                          |
| INNODB_SYS_TABLESPACES                     |
| INNODB_SYS_FOREIGN_COLS                    |
| INNODB_SYS_COLUMNS                         |
| INNODB_SYS_FOREIGN                         |
| INNODB_SYS_TABLESTATS                      |
+--------------------------------------------+
10 rows in set (0.00 sec)
```
在`information_schema`数据库中的这些以`INNODB_SYS`开头的表并不是真正的内部系统表（内部系统表就是我们上边唠叨的以`SYS`开头的那些表），而是在存储引擎启动时读取这些以`SYS`开头的系统表，然后填充到这些以`INNODB_SYS`开头的表中。以`INNODB_SYS`开头的表和以`SYS`开头的表中的字段并不完全一样。
