# MySQL 执行流程
`MySQL` 执行一条 `SQL` 查询语句的流程：
![查询语句执行流程](https://cdn.xiaolincoding.com/gh/xiaolincoder/mysql/sql执行过程/mysql查询流程.png)
`MySQL` 的架构共分为两层：`Server` 层和存储引擎层，
- `Server` 层负责建立连接、分析和执行 `SQL`。`MySQL` 大多数的核心功能模块都在这实现，主要包括连接器，查询缓存、解析器、预处理器、优化器、执行器等。另外，所有的内置函数和所有跨存储引擎的功能，如存储过程、触发器、视图等都在 `Server` 层实现。
- 存储引擎层负责数据的存储和提取。支持 `InnoDB`、`MyISAM`、`Memory` 等多个存储引擎，不同的存储引擎共用一个 `Server` 层。从 `MySQL 5.5` 版本开始， `InnoDB` 是 `MySQL` 的默认存储引擎，索引数据结构就是由存储引擎层实现的，不同的存储引擎支持的索引类型也不相同，比如 `InnoDB` 支持并默认使用 `B+` 树。
## 第一步：连接器
使用下面这条命令进行连接：
```shell
# -h 指定 MySQL 服务得 IP 地址，如果是连接本地的 MySQL服务，可以不用这个参数；
# -u 指定用户名，管理员角色名为 root；
# -p 指定密码，如果命令行中不填写密码（为了密码安全，建议不要在命令行写密码），就需要在交互对话里面输入密码
mysql -h$ip -u$user -p
```
连接的过程需要先经过 `TCP` 三次握手，因为 `MySQL` 是基于 `TCP` 协议进行传输的，如果 `MySQL` 服务并没有启动，则会收到报错。如果 `MySQL` 服务正常运行，完成 `TCP` 连接的建立后，开始验证用户名和密码。
如果用户密码都没有问题，连接器就会获取该用户的权限，然后保存起来，后续该用户在此连接里的任何操作，都会基于连接开始时读到的权限进行权限逻辑的判断。所以，如果一个用户已经建立连接，即使管理员中途修改该用户的权限，也不会影响已经存在连接的权限。修改完成后，只有再新建的连接才会使用新的权限设置。
至此，连接器的工作完成：
- 与客户端进行 `TCP` 三次握手建立连接。
- 校验客户端的用户名和密码，如果用户名或密码不对，则会报错。
- 如果用户名和密码都对，会读取该用户的权限，然后后面的权限逻辑判断都基于此时读取到的权限。
### 空闲连接
如果想知道当前  `MySQL` 服务被多少个客户端连接，可以执行 `show processlist` 命令进行查看。
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/mysql/sql执行过程/查看连接.png)
比如上图的显示结果，共有两个用户名为 `root` 的用户连接了 `MySQL` 服务，其中 id 为 6 的用户的 `Command` 列的状态为 `Sleep` ，这意味着该用户连接完 `MySQL` 服务就没有再执行过任何命令，也就是说这是一个空闲的连接，并且空闲的时长是 736 秒（`Time` 列）。
`MySQL` 定义空闲连接的最大空闲时长，由 `wait_timeout` 参数控制，默认值是 8 小时（28880秒），如果空闲连接超过这个时间，连接器就会自动将它断开。
```sql
mysql> show variables like 'wait_timeout';
+---------------+-------+
| Variable_name | Value |
+---------------+-------+
| wait_timeout  | 28800 |
+---------------+-------+
1 row in set (0.00 sec)
```
自己也可以手动断开空闲的连接，使用的是 kill connection + id 的命令。
```sql
mysql> kill connection +6;
Query OK, 0 rows affected (0.00 sec)
```
一个处于空闲状态的连接被服务端主动断开后，这个客户端并不会马上知道，等到客户端在发起下一个请求的时候，才会收到报错。
### 最大连接数
`MySQL` 服务支持的最大连接数由 `max_connections` 参数控制，超过这个值，系统就会拒绝接下来的连接请求，并报错提示。
```sql
mysql> show variables like 'max_connections';
+-----------------+-------+
| Variable_name   | Value |
+-----------------+-------+
| max_connections | 151   |
+-----------------+-------+
1 row in set (0.00 sec)
```
### 长/短连接
`MySQL` 的连接也跟 `HTTP` 一样，有短连接和长连接的概念，使用长连接的好处就是可以减少建立连接和断开连接的过程，短连接每次执行 `SQL` 语句都需要建立连接，所以一般是推荐使用长连接。
但是，使用长连接后可能会占用内存增多，因为 `MySQL` 在执行查询过程中临时使用内存管理连接对象，这些连接对象资源只有在连接断开时才会释放。如果长连接累计很多，将导致 `MySQL` 服务占用内存太大，有可能会被系统强制杀掉，这样会发生 `MySQL` 服务异常重启的现象。
有两种解决方式。
第一种，定期断开长连接。
第二种，客户端主动重置连接。MySQL 5.7 版本实现 `mysql_reset_connection()` 函数的接口，客户端可以调用 `mysql_reset_connection` 函数来重置连接，达到释放内存的效果。这个过程不需要重连和重新做权限验证，但是会将连接恢复到刚刚创建完时的状态。
## 第二步：查询缓存
连接器后客户端向 `MySQL` 服务发送 `SQL` 语句，`MySQL` 服务收到 `SQL` 语句后，就会解析出 `SQL` 语句的第一个字段是什么类型的语句。
如果 `SQL` 是查询语句，`MySQL` 就会先去查询缓存里查找缓存数据，看这个查询缓存是以 `key-value` 形式保存在内存中的。如果查询的语句命中查询缓存，那么就会直接返回 `value` 给客户端。如果查询的语句没有命中查询缓存中，那么就要往下继续执行，等执行完后，查询的结果就会被存入查询缓存中。
在 `MySQL` 中的查询缓存，`key` 为 `SQL` 查询语句，只有相同的查询操作才会命中查询缓存。两个查询请求在任何字符上的不同，例如空格、注释、 大小写，都会导致缓存不会命中。因此 `MySQL` 的查询缓存命中率不高。 
同时，如果查询请求中包含某些系统函数时间函数、用户自定义变量和函数、一些系统表，那这个请求就不会被缓存。此外，`MySQL` 的缓存系统会监测涉及到的每张表，只要该表的结构或者数据被修改，那使用该表的所有高速缓存查询都将变为无效并从高速缓存中删除，对于更新压力大的数据库来说，查询缓存的命中率会非常低。
所以，`MySQL 8.0` 版本直接将查询缓存删掉，也就是说 MySQL 8.0 开始，执行一条 SQL 查询语句，不会再走到查询缓存这个阶段。
一般建议在静态表里使用查询缓存，即极少更新的表。比如，一个系统配置表、字典表，这张表上的查询才适合使用查询缓存。可以将 `my.cnf` 参数 `query_cache_type` 设置成 `DEMAND`，代表当 `SQL` 语句中有 `SQL_CACHE` 关键字时才缓存。比如：
```mysql
# query_cache_type 有3个值。 0代表关闭查询缓存OFF，1代表开启ON，2代表(DEMAND)
query_cache_type=2

# 这样对于默认的SQL语句都不使用查询缓存。而对于确定要使用查询缓存的语句，可以供SQL_CACHE显示指定
SELECT SQl_CACHE * FROM test WHERE ID=5;
SELECT SQl_NO_CACHE * FROM test WHERE ID=5;

# MySQL5.7中查看当前 mysql 实例是否开启缓存机制：
show global variables like "%query_cache_type%";

# 监控查询缓存的命中率：
show status like '%Qcache%';
```
- `Qcache_free_blocks`: 表示查**询缓存中还有多少剩余的blocks**，如果该值显示较大，则说明查询缓存中的内部碎片过多，可能在一定的时间进行整理。
- `Qcache_free_memory`: 查询缓存的内存大小，通过这个参数可以很清晰的知道当前系统的查询内存是否够用，`DBA` 可以根据实际情况做出调整。
- `Qcache_hits`: 表示有多少次命中缓存。主要可以通过该值来验证我们的查询缓存的效果。数字越大，缓存效果越理想。
- `Qcache_inserts`: 表示多少次未命中然后插入，意思是新来的 `SQL` 请求在缓存中未找到，不得不执行查询处理，执行查询处理后把结果 `insert` 到查询缓存中。这样的情况的次数越多，表示查询缓存应用到的比较少，效果也就不理想。当然系统刚启动后，查询缓存是空的，这也正常。
- `Qcache_lowmem_prunes`: 该参数记录有多少条查询因为内存不足而被移除出查询缓存。通过这个值，用户可以适当的调整缓存大小。
- `Qcache_not_cached`: 表示因为 `query_cache_type` 的设置而没有被缓存的查询数量。
- `Qcache_queries_in_cache`: 当前缓存中缓存的查询数量。
- `Qcache_total_blocks`: 当前缓存的 `block` 数量。
## 第三步：解析 SQL
在正式执行 `SQL` 查询语句之前， `MySQL` 会先对 `SQL` 语句做解析，解析器会做如下两件事情：
- 词法分析。`MySQL` 会根据输入的字符串识别出关键字出来，构建出 `SQL` 语法树，这样方便后面模块获取 `SQL` 类型、表名、字段名、`where` 条件等等。
- 语法分析。根据词法分析的结果，语法解析器会根据语法规则，判断输入的这个 `SQL` 语句是否满足 `MySQL` 语法。
但是表不存在或者字段不存在，并不是在解析器里判断的，解析器只负责构建语法树和检查语法，但是不会去查表或者字段存不存在。
## 第四步：执行 SQL
经过解析器后，进入执行 SQL 查询语句的流程，每条 `SELECT` 查询语句流程主要可以分为下面这三个阶段：
- `prepare` 阶段，也就是预处理阶段；
- `optimize` 阶段，也就是优化阶段；
- `execute` 阶段，也就是执行阶段；
### 预处理器
预处理阶段：
- 检查 `SQL` 查询语句中的表或者字段是否存在；
- 将 `select *` 中的 `*` 符号，扩展为表上的所有列；
### 优化器
经过预处理阶段后，优化器会为 `SQL` 查询语句先制定一个执行计划，优化器主要负责将 `SQL` 查询语句的执行方案确定下来，比如在表里面有多个索引的时候，优化器会基于查询成本的考虑，来决定选择使用哪个索引。
### 执行器
经历完优化器确定执行方案后，由执行器开始执行，此时执行器会和存储引擎交互，交互是以记录为单位的。接下来，根据不同情况执行：
- 主键索引查询
- 全表扫描
- 索引下推
#### 主键索引查询
```sql
select * from product where id = 1;
```
这条查询语句的查询条件用到主键索引，而且是等值查询，同时主键 `id` 是唯一，不会有 `id` 相同的记录，所以优化器决定选用访问类型为 `const` 进行查询，也就是使用主键索引查询一条记录，那么执行器与存储引擎的执行流程是这样的：
- 执行器第一次查询，会调用 `read_first_record` 函数指针指向的函数，因为优化器选择的访问类型为 `const`，这个函数指针被指向为 `InnoDB` 引擎索引查询的接口，把条件 `id = 1` 交给存储引擎，让存储引擎定位符合条件的第一条记录。
- 存储引擎通过主键索引的 `B+` 树结构定位到 `id = 1` 的第一条记录，如果记录是不存在的，就会向执行器上报记录找不到的错误，然后查询结束。如果记录是存在的，就会将记录返回给执行器。
- 执行器从存储引擎读到记录后，接着判断记录是否符合查询条件，如果符合则发送给客户端，如果不符合则跳过该记录。
- 执行器查询的过程是一个 `while` 循环，所以还会再查一次，但是这次因为不是第一次查询，所以会调用 `read_record` 函数指针指向的函数，因为优化器选择的访问类型为 `const`，这个函数指针被指向为一个永远返回 - 1 的函数，所以当调用该函数的时候，执行器就退出循环，结束查询。
#### 全表扫描
```sql
select * from product where name = 'iphone';
```
这条查询语句的查询条件没有用到索引，所以优化器决定选用访问类型为 `ALL` 进行查询，也就是全表扫描的方式查询：
- 执行器第一次查询，会调用 `read_first_record` 函数指针指向的函数，因为优化器选择的访问类型为 `all`，这个函数指针被指向为 `InnoDB` 引擎全扫描的接口，让存储引擎读取表中的第一条记录。
- 执行器会判断读到的这条记录的 `name` 是不是 `iphone`，如果不是则跳过，如果是则将记录返回给执行器。`Server` 层每从存储引擎读到一条记录就会发送给客户端，之所以客户端显示的时候是直接显示所有记录的，是因为客户端是等查询语句查询完成后，才会显示出所有的记录。
- 执行器查询的过程是一个 `while` 循环，所以还会再查一次，会调用 `read_record` 函数指针指向的函数，因为优化器选择的访问类型为 `all`，`read_record` 函数指针指向的还是 `InnoDB` 引擎全扫描的接口，所以接着向存储引擎层要求继续读刚才那条记录的下一条记录，存储引擎把下一条记录取出后就将其返回给执行器，执行器继续判断条件，不符合查询条件即跳过该记录，否则发送到客户端。
- 一直重复上述过程，直到存储引擎把表中的所有记录读完，然后向执行器返回读取完毕的信息。
- 执行器收到存储引擎报告的查询完毕的信息，退出循环，停止查询。
#### 索引下推
`Index Condition Pushdown` 是 `MySQL 5.6` 中新特性，是一种在存储引擎层使用索引过滤数据的一种优化方式。索引下推能够减少二级索引在查询时的回表操作，提高查询的效率，因为它将 `Server` 层部分负责的事情，交给存储引擎层去处理。
这里一张用户表如下，对 `age` 和 `reward` 字段建立联合索引：
![](https://cdn.xiaolincoding.com/gh/xiaolincoder/mysql/sql执行过程/路飞表.png)
```sql
select * from t_user where age > 20 and reward = 100000;
```
联合索引当遇到范围查询就会停止匹配，也就是 `age` 字段能用到联合索引，但是 `reward` 字段则无法利用到。
不使用索引下推时，执行器与存储引擎的执行流程是这样的：
- `Server` 层首先调用存储引擎的接口定位到满足查询条件的第一条二级索引记录，也就是定位到 `age > 20` 的第一条记录；
- 存储引擎根据二级索引的 `B+` 树快速定位到这条记录后，获取主键值，然后进行回表操作，将完整的记录返回给 `Server` 层；
- `Server` 层在判断该记录的 `reward` 是否等于 100000，如果成立则将其发送给客户端；否则跳过该记录；
- 接着，继续向存储引擎索要下一条记录，存储引擎在二级索引定位到记录后，获取主键值，然后回表操作，将完整的记录返回给 `Server` 层；
- 如此往复，直到存储引擎把表中的所有记录读完。
可以看到，没有索引下推的时候，每查询到一条二级索引记录，都要进行回表操作，然后将记录返回给 `Server`，接着 `Server` 再判断该记录的 `reward` 是否等于 100000。
而使用索引下推后，判断记录的 `reward` 是否等于 `100000` 的工作会交给存储引擎层，过程如下 ：
- `Server` 层首先调用存储引擎的接口定位到满足查询条件的第一条二级索引记录，也就是定位到 `age > 20` 的第一条记录；
- 存储引擎定位到二级索引后，先不执行回表操作，而是先判断一下该索引中包含的列的条件，即`reward = 100000` 是否成立。如果条件不成立，则直接跳过该二级索引。如果成立，则执行回表操作，将完成记录返回给 `Server` 层。
- `Server` 层在判断其他的查询条件（本次查询没有其他条件）是否成立，如果成立则将其发送给客户端；否则跳过该记录，然后向存储引擎索要下一条记录。
- 如此往复，直到存储引擎把表中的所有记录读完。
可以看到，使用索引下推后，虽然 `reward` 列无法使用到联合索引，但是因为它包含在联合索引里，所以直接在存储引擎过滤出满足 `reward = 100000` 的记录后，才去执行回表操作获取整个记录。相比于没有使用索引下推，节省很多回表操作。
综上所述，执行查询时 `storage` 层会首先调用存储引擎的接口定位到满足查询条件的第一条二级索引记录，如果不使用 `ICP`，会获得定位到的记录主键值，然后进行回表操作，将完整的记录返回给 `Server` 层，`Server` 层再判断其他的查询条件是否成立；如果其他的查询条件的字段在索引列中，可以使用 `ICP`，则在获得定位到的记录后对索引中包含的字段先做判断，如果条件不成立，则直接过滤掉不满足条件的记录，减少回表次数。如果成立，则执行回表操作，将完成记录返回给 `Server` 层。
因此 `ICP` 省去多余的返回到 `Server` 层和回表的成本。
默认情况下启动索引条件下推。可以通过设置系统变量 `optimizer_switch` 控制：
```mysql
# 打开索引下推
# EXPLAIN语句输出结果中Extra列内容显示为Using index condition
SET optimizer_switch = 'index_condition_pushdown=on';

# 关闭索引下推
SET optimizer_switch = 'index_condition_pushdown=off';
```
`ICP` 的使用条件：
1. 只能用于二级索引：对于 `InnnoDB` 表，`ICP` 仅用于二级索引。因为对于聚集索引，完整的记录已被读入到 `innodb` 缓冲区，在这种情况下，`ICP` 不会减少 `IO`。
2. `EXPLAIN` 显示的执行计划中 `type` 值为 `range/ref/eq_ref/ref_or_null`。
3. 并非全部 `WHERE` 条件都可以用 `ICP` 筛选，如果 `WHERE` 条件的字段不在索引列中，还是要读取整表的记录到 `Server` 端做 `WHERE` 过滤。
4. 当 `SQL` 使用索引覆盖或相关子查询时，不支持 `ICP` 优化方法。
5. `ICP` 可以用于 `MyISAM` 和 `InnnoDB` 存储引擎。
## 顺序
```mysql
#SQL92：
SELECT ...,....,...
FROM ...,...,....
WHERE 多表的连接条件 AND 不包含组函数的过滤条件
GROUP BY ...,...
HAVING 包含组函数的过滤条件
ORDER BY ... ASC/DESC
LIMIT ...,...

#SQL99：
SELECT ....,....,....(存在聚合函数)
FROM ... (LEFT / RIGHT)JOIN ....ON 多表的连接条件 
(LEFT / RIGHT)JOIN ... ON ....
WHERE 不包含聚合函数的过滤条件
GROUP BY ...,....
HAVING 包含聚合函数的过滤条件
ORDER BY ....,...(ASC / DESC )
LIMIT ...,....
```
关键字的顺序不能颠倒
```mysql
SELECT ... FROM ... WHERE ... GROUP BY ... HAVING ... ORDER BY ... LIMIT...
```
`SELECT` 语句的执行顺序
```mysql
FROM ...,...-> ON -> (LEFT/RIGNT JOIN) -> 
WHERE -> GROUP BY -> HAVING 
-> SELECT -> DISTINCT -> 
ORDER BY -> LIMIT

SELECT DISTINCT player_id, player_name, count(*) as num # 顺序 5
FROM player JOIN team ON player.team_id = team.team_id # 顺序 1
WHERE height > 1.80 # 顺序 2
GROUP BY player.team_id # 顺序 3
HAVING num > 2 # 顺序 4
ORDER BY num DESC # 顺序 6
LIMIT 2 # 顺序 7
```
## 总结
执行一条 `SQL` 查询语句，期间发生了什么？
- 连接器：建立连接，管理连接、校验用户身份；
- 查询缓存：查询语句如果命中查询缓存则直接返回，否则继续往下执行。MySQL 8.0 已删除该模块；
- 解析 `SQL`，通过解析器对 `SQL` 查询语句进行词法分析、语法分析，然后构建语法树，方便后续模块读取表名、字段、语句类型；
- 执行 `SQL`：执行 `SQL` 共有三个阶段：
  - 预处理阶段：检查表或字段是否存在；将 `select *` 中的 `*` 符号扩展为表上的所有列。
  - 优化阶段：基于查询成本的考虑， 选择查询成本最小的执行计划；
  - 执行阶段：根据执行计划执行 `SQL` 查询语句，从存储引擎读取记录，返回给客户端；
## 其它
### MySQL8中SQL执行资源情况
```mysql
# 开启可以让MySQL收集在SQL执行时所使用的资源情况
mysql> select @@profiling;
mysql> show variables like 'profiling';

# profiling=0 代表关闭，我们需要把 profiling 打开，即设置为 1：
mysql> set profiling=1;

# 然后执行一个 SQL 查询（你可以执行任何一个 SQL 查询）
mysql> select * from employees;

# 查看当前会话所产生的所有 profiles：
mysql> show profiles; # 显示最近的几次查询

# 显示执行计划，查看程序的执行步骤：
mysql> show profile;
mysql> show profile for query 7;
mysql> show profile cpu,block io for query 6;
```
除了查看cpu、io阻塞等参数情况，还可以查询下列参数的利用情况。发现两次查询当前情况都一致，说明没有缓存。
```mysql
Syntax:
SHOW PROFILE [type [, type] ... ]
	[FOR QUERY n]
	[LIMIT row_count [OFFSET offset]]

type: {
	| ALL -- 显示所有参数的开销信息
	| BLOCK IO -- 显示IO的相关开销
	| CONTEXT SWITCHES -- 上下文切换相关开销
	| CPU -- 显示CPU相关开销信息
	| IPC -- 显示发送和接收相关开销信息
	| MEMORY -- 显示内存相关开销信息
	| PAGE FAULTS -- 显示页面错误相关开销信息
	| SOURCE -- 显示和Source_function,Source_file,Source_line 相关的开销信息
	| SWAPS -- 显示交换次数相关的开销信息
}
```
在 8.0 版本之后，`MySQL` 不再支持缓存的查询。一旦数据表有更新，缓存都将清空，因此只有数据表是静态的时候，或者数据表很少发生变化时，使用缓存查询才有价值，否则如果数据表经常更新，反而增加了 SQL 的查询时间。
### MySQL5.7中SQL执行资源情况
上述操作在MySQL5.7中测试，发现前后两次相同的sql语句，执行的查询过程仍然是相同的。需要显式开启查询缓存模式 。在MySQL5.7中如下设置：
```mysql
# 配置文件中开启查询缓存
query_cache_type=1

# 重启mysql服务
systemctl restart mysqld

# 由于重启过服务，需要重新执行如下指令，开启profiling。
mysql> set profiling=1;

mysql> select * from locations;
mysql> show profiles; # 显示最近的几次查询
mysql> show profile for query 1;
mysql> show profile for query 2;
```
### Oracle中的SQL执行流程
![image-20230111112917187](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230111112917187.png)
1. 语法检查：检查 SQL 拼写是否正确，如果不正确，Oracle 会报语法错误。 
2. 语义检查：检查 SQL 中的访问对象是否存在。比如我们在写 SELECT 语句的时候，列名写错了，系统 就会提示错误。语法检查和语义检查的作用是保证 SQL 语句没有错误。 
3. 权限检查：看用户是否具备访问该数据的权限。
4. 共享池检查：共享池（Shared Pool）是一块内存池，最主要的作用是缓存 SQL 语句和该语句的执行计 划。Oracle 通过检查共享池是否存在 SQL 语句的执行计划，来判断进行软解析，还是硬解析。那软解析 和硬解析又该怎么理解呢？ 在共享池中，Oracle 首先对 SQL 语句进行 Hash 运算，然后根据 Hash 值在库缓存（Library Cache）中 查找，如果存在 SQL 语句的执行计划，就直接拿来执行，直接进入“执行器”的环节，这就是软解析。如果没有找到 SQL 语句和执行计划，Oracle 就需要创建解析树进行解析，生成执行计划，进入“优化器” 这个步骤，这就是硬解析。
5. 优化器：优化器中就是要进行硬解析，也就是决定怎么做，比如创建解析树，生成执行计划。 
6. 执行器：当有了解析树和执行计划之后，就知道了 SQL 该怎么被执行，这样就可以在执行器中执行语句了。
Oracle 和 MySQL 在进行 SQL 的查询上面有软件实现层面的差异。Oracle 提出了共享池的概念，通过共享池来判断是进行软解析，还是硬解析。共享池是 Oracle 中的术语，包括了库缓存，数据字典缓冲区等。库缓存区，主要缓存 SQL 语句和执行计划。而数据字典缓冲区存储的是 Oracle 中的对象定义，比如表、视图、索引等对象。
当对 SQL 语句进行解析的时候，如果需要相关的数据，会从数据字典缓冲区中提取。库缓存这一个步骤，决定了 SQL 语句是否需要进行硬解析。为了提升 SQL 的执行效率，我们应该尽量 避免硬解析，因为在 SQL 的执行过程中，创建解析树，生成执行计划是很消耗资源的。
在 Oracle 中， 绑定变量是它的一大特色。**绑定变量就是在 SQL 语句中使用变量，通过不同的变量取值来改变 SQL 的执行结果。这样做的好处是能提升软解 析的可能性，不足之处在于可能会导致生成的执行计划不够优化，因此是否需要绑定变量还需要视情况 而定。**
# CRUD
## 排序分组分页
`WHERE` 用来筛选 `FROM` 中指定的数据源所产生的行数据。
`GROUP BY` 子句用来对经 `WHERE` 筛选后的结果数据进行分组。
`HAVING` 用来对分组后的结果数据再进行筛选。
### ORDER BY
使用 `ORDER BY` 子句排序：默认 `ASC` 升序、`DESC`：
```mysql
SELECT last_name, job_id, department_id, hire_date FROM employees ORDER BY hire_date DESC;
```
可以使用不在 `SELECT` 列表中的列排序。当使用 `ROLLUP` 时，不能同时使用 `ORDER` BY 进行结果排序。
在对多列进行排序的时候，首先排序的第一列必须有相同的列值，才会对第二列进行排序，如果第一列数据中所有值都是唯一的，将不再对第二列进行排序。
### GROUP BY
可以使用 `GROUP BY` 将表中的数据分成若干组，但 `WHERE` 排除的记录不再包括在分组中：
```mysql
SELECT column, group_function(column)
FROM table
[WHERE condition]
[GROUP BY group_by_expression] # ORDER BY前面、LIMIT前面。
[ORDER BY column];

SELECT department_id, AVG(salary)
FROM employees
WHERE department_id > 80
GROUP BY department_id WITH ROLLUP;
```
若使用 `GROUP BY`，则目标列中非聚合函数的字段必须声明在 `GROUP BY` 中，聚合函数的字段可以不声明在 `GROUP BY` 中。
若目标列中包含聚合函数但没有使用 `GROUP BY`，则目标列中只能写聚合函数，相当于分组只有一组。
### HAVING
1. 使用聚合函数，必须使用 `HAVING` 来替换 `WHERE`，因为聚合函数是在分组后计算的，当过滤条件中没有聚合函数时，则次过滤条件声明在 `WHERE` 中或 `HAVING` 中都可以，但是声明在 `WHERE` 中的执行效率高。
3. `HAVING` 不能单独使用，必须要跟 `GROUP BY` 一起使用，满足 `HAVING` 中条件的分组将被显示。`HAVING` 必须声明在 `GROUP BY` 的后面。
```mysql
SELECT department_id, MAX(salary)
FROM employees
GROUP BY department_id
HAVING MAX(salary)>10000;
```
在 `MySQL` 中，可以在 `WHERE` 中使用聚合函数，但只有在子查询或派生表中才能这样做。这是因为 `MySQL` 在处理 `WHERE` 子句时，会先计算聚合函数，然后再应用这个结果到 `WHERE` 子句中。
```mysql
-- 找出工资大于平均工资的员工
SELECT employee_id, salary
FROM employees
WHERE salary > (
    SELECT AVG(salary)
    FROM employees
);
```
### WHERE/HAVING
```mysql
-- 使用WHERE子句进行行过滤
SELECT department_id, COUNT(*) AS employee_count
FROM employees
WHERE hire_date > '1990-01-01' -- 行过滤
GROUP BY department_id;

-- 使用HAVING子句进行分组后过滤
SELECT department_id, COUNT(*) AS employee_count
FROM employees
GROUP BY department_id
HAVING COUNT(*) > 10; -- 分组后过滤
```
在查询语法结构中，`WHERE` 在 `GROUP BY` 之前，所以无法使用聚合函数对分组结果进行筛选，而 `HAVING` 必须与 `GROUP BY` 配合使用，在其之后，因此可以使用分组字段和聚合函数对分组的结果集进行筛选。
如果需要通过连接从关联表中获取需要的数据，`WHERE` 是先筛选后连接，而 `HAVING` 是先连接后筛选。因此在关联查询中，`WHERE` 比 `HAVING` 更高效。
因为 `WHERE` 可以先筛选，用一个筛选后的较小数据集和关联表进行连接，这样占用的资源比较少，执行效率也比较高。`HAVING` 则需要先把结果集准备好，也就是用未被筛选的数据集进行关联，然后对这个大的数据集进行筛选，这样占用的资源就比较多，执行效率也较低。
### LIMIT
```mysql
LIMIT [位置偏移量,] 行数 -- LIMIT 子句必须放在整个SELECT语句的最后
 
--前10条记录：
SELECT * FROM 表名 LIMIT 0,10;
或者
SELECT * FROM 表名 LIMIT 10;
--第11至20条记录：
SELECT * FROM 表名 LIMIT 10,10;
--第21至30条记录：
SELECT * FROM 表名 LIMIT 20,10;
```
`MySQL 8.0` 中可以使用 `LIMIT 3 OFFSET 4`，意思是获取从第 5 条记录开始后面的 3 条记录，和 `LIMIT 4,3` 返回的结果相同。
分页显式：
```mysql
SELECT * FROM table
LIMIT(PageNo - 1) * PageSize, PageSize; -- PageNo 当前页数 PageSize 每页条数
```
约束返回结果的数量可以减少数据表的网络传输量 ，也可以提升查询效率 。如果知道返回结果只有 1 条，就可以使用 `LIMIT 1`，告诉 `SELECT` 语句只需要返回一条记录即可。这样的好处就是 `SELECT` 不需要扫描完整的表，只需要检索到一条符合条件的记录即可返回。
## 多表查询
多表连接非常消耗资源，会让 `SQL` 查询性能下降得很严重，因此不要连接不必要的表。
表连接的约束条件可以有三种方式：
* `WHERE`：适用于所有关联查询 
* `ON`：只能和 `JOIN` 一起使用，只能写关联条件。
* `USING`：只能和 `JOIN` 一起使用，而且要求两个关联字段在关联表中名称一致，而且只能表示关联字段值相等。
### 内外连接
#### 表的别名
如果给表起别名，则在 `SELECT` 或 `WHERE` 中必须使用表的别名，而不能再使用表的原名。查询语句先执行 `FROM`，再执行 `WHERE`，因此可以在 `WHERE` 中使用表的别名，但不能在 `WHERE` 中使用列的别名。
```mysql
SELECT emp.employee_id, dept.department_name, emp.department_id
FROM employees emp, departments dept
WHERE emp.`department_id` = dept.department_id;
```
#### 自连接
```mysql
-- 多表查询需要有连接条件
-- 查询员工id和姓名及其管理者的id和姓名

-- 如果查询语句中出现多个表中都存在的字段，则必须指明此字段所在的表
-- 从sql优化的角度，多表查询时，每个字段前都指明其所在的表
SELECT emp.employee_id, emp.last_name, mgr.employee_id, mgr.last_name
FROM employees emp ,employees mgr
-- 两个表的连接条件
WHERE emp.`manager_id` = mgr.`employee_id`;
```
#### 内连接与外连接
内连接: 合并具有同一列的表的行, 结果集中不包含一个表与另一个表不匹配的行。
```mysql
# SQL92语法
SELECT emp.employee_id, dep.department_name
FROM employee emp, department dep
WHERE emp.`department_id` = dep.`department_id`;

# SQL99语法
# JOIN 默认未内连接，因此省略 INNER
SELECT emp.employee_id, dep.department_name
FROM employee emp JOIN department dep
ON emp.`department_id` = dep.`department_id`;
```
外连接则包含一个表与另一个表不匹配的行：
- 左外连接，包括左表不满足条件的行，右表中不满足条件的列值为空
- 右外连接，包括右表不满足条件的行，左表中不满足条件的列值为空。
```mysql
SELECT last_name, department_name
FROM employees emp LEFT OUTER JOIN department dep
ON emp.`department_id` = dep.`department_id`;

SELECT last_name, department_name
FROM employees emp RIGHT OUTER JOIN department dep
ON emp.`department_id` = dep.`department_id`;
```
### UNION
`UNION` 可以将多条 `SELECT` 语句的结果组合成单个结果集。合并时，两个表对应的列数和数据类型必须相同，并且相互对应。
```mysql
SELECT column,... FROM table1
UNION [ALL]
SELECT column,... FROM table2
```
`UNION` 操作符返回两个查询的结果集的并集，去除重复记录。
`UNION ALL` 操作符返回两个查询的结果集的并集，对于重复部分不去重。因此执行 `UNION ALL` 语句时所需要的资源比 `UNION` 语句少。如果明确知道合并数据后的结果数据不存在重复数据，或者不需要去除重复的数据，则尽量使用 `UNION ALL` 语句。
### SQL JOINS
![image-20220603133759153](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220531224324213.png)
```mysql
# 中图：内连接
SELECT employee_id,department_name 
FROM employees e JOIN departments d
ON e.`department_id` = d.`department_id;
# 左上图：左外连接
SELECT employee_id,department_name  
FROM employees e LEFT JOIN departments d
ON e.`department_id` = d.`department_id`;
# 右上图：右外连接
SELECT employee_id,department_name 
FROM employees e RIGHT JOIN departments d
ON e.`department_id` = d.`department_id`;
# 左中图：
SELECT employee_id,department_name 
FROM employees e LEFT JOIN departments d
ON e.`department_id` = d.`department_id`
WHERE d.`department_id` IS NULL;
# 右中图：
SELECT employee_id,department_name 
FROM employees e RIGHT JOIN departments d
ON e.`department_id` = d.`department_id`
WHERE e.`department_id` IS NULL;

# 左下图：满外连接
# 方式1：左上图 UNION ALL 右中图
SELECT employee_id,department_name 
FROM employees e LEFT JOIN departments d 
ON e.`department_id` = d.`department_id` 
UNION ALL
SELECT employee_id,department_name
FROM employees e RIGHT JOIN departments d
ON e.`department_id` = d.`department_id`
WHERE e.`department_id` IS NULL;

# 方式2：左中图 UNION ALL 右上图
SELECT employee_id,department_name 
FROM employees e LEFT JOIN departments d
ON e.`department_id` = d.`department_id`
WHERE d.`department_id` IS NULL
UNION ALL
SELECT employee_id,department_name
FROM employees e RIGHT JOIN departments d
ON e.`department_id` = d.`department_id`;

# 右下图：左中图 UNION ALL 右中图
SELECT employee_id,department_name 
FROM employees e LEFT JOIN departments d
ON e.`department_id` = d.`department_id`
WHERE d.`department_id` IS NULL
UNION ALL
SELECT employee_id,department_name
FROM employees e RIGHT JOIN departments d
ON e.`department_id` = d.`department_id`
WHERE e.`department_id` IS NULL;
```
### NATURAL
`SQL99` 在 `SQL92` 的基础上提供 `NATURAL JOIN` 自然连接，它会自动查询两张连接表中所有相同的字段，然后进行等值连接。
```mysql
# SQL92
SELECT employee_id, last_name, department_name
FROM employees e JOIN departments d
ON e.`department_id` = d.`department_id`
AND e.`manager_id` = d.`manager_id`;

# SQL99
SELECT employee_id, last_name, department_name
FROM employees e NATURAL JOIN departments d;
```
### USING
`SQL99` 支持使用 `USING` 指定数据表里的同名字段进行等值连接，但是只能配合 JOIN 一起使用。比如：
```mysql
# SQL92
SELECT employee_id, last_name, department_name
FROM employees e, departments d
WHERE e.department_id = d.department_id;

# SQL99
SELECT employee_id, last_name, department_name
FROM employees e JOIN departments d
USING (department_id);
```
当两个表外连接之后，组成主表和从表，主表的连接字段不为空，从表的连接字段可能为空，因此从表的关键字段用来判断是否为空：
```mysql
# 查询哪些部门没有员工
# 方式一
SELECT d.department_id
FROM departments d LEFT JOIN employees e
ON d.`department_id` = e.`department_id`
WHERE e.`department_id` IS NULL;

# 方式二
SELECT department_id
FROM departments d
WHERE NOT EXISTS (
		SELECT *
    	FROM employees e
    	WHERE e.`department_id` = d.`department_id`
);
```
## 子查询
子查询在主查询之前一次执行完成，子查询的结果被主查询使用。
  + 将子查询放在比较条件的右侧，并包含在括号内
  + 多行操作符对应多行子查询
按内查询是否被执行多次，将子查询划分为相关(或关联)子查询和不相关(或非关联)子查询：
- 不相关子查询：子查询的数据结果只执行一次，然后这个数据结果作为主查询的条件进行执行
- 相关子查询：子查询中使用主查询中的列，需要执行多次，先从外部查询开始，每次都传入子查询进行查询，然后再将结果反馈给外部
### 单行子查询
单行操作符 `=/<>/>/</>=/<=` 对应单行子查询：
```mysql
# 返回job_id与141号员工相同，salary比143号员工多的员工姓名，job_id和工资
SELECT last_name, job_id, salary
FROM eployees
WHERE job_id = (
	SELECT job_id
	FROM eployees
  WHERE employee_id = 141
)
AND salary > (
	SELECT salary
	FROM eployees
    WHERE employee_id = 143
);

# 查询与141号或174号员工的manager_id和department_id相同的其他员工的employee_id，manager_id，department_id
# 实现方式一：不成对比较
SELECT employee_id, manager_id, department_id
FROM employees
WHERE manager_id IN
        (SELECT manager_id
        FROM employees
        WHERE employee_id IN (174,141))
AND department_id IN
        (SELECT department_id
        FROM employees
        WHERE employee_id IN (174,141))
AND employee_id NOT IN(174,141);

# 实现方式二：成对比较
SELECT employee_id, manager_id, department_id
FROM employees
WHERE (manager_id, department_id) IN
        (SELECT manager_id, department_id
        FROM employees
        WHERE employee_id IN (141,174))
AND employee_id NOT IN (141,174);

# 查询最低工资大于50号部门最低工资的部门id和其最低工资
SELECT department_id, MIN(salary)
FROM employees
GROUP BY department_id
HAVING MIN(salary) >
            (SELECT MIN(salary)
            FROM employees
            WHERE department_id = 50);
            
# 多行子查询使用单行比较符
SELECT employee_id, last_name
FROM employees
WHERE salary = # 这是单行比较符
(SELECT MIN(salary) # GROUP BY 这是多行子查询
FROM employees
GROUP BY department_id);

# 查询员工的employee_id,last_name和location。
# 其中，若员工department_id与location_id为1800 的department_id相同，则location为’Canada’，其余则为’USA’。
SELECT employee_id, last_name,
    (CASE department_id
    WHEN
        (SELECT department_id FROM departments
        WHERE location_id = 1800)
    THEN 'Canada' ELSE 'USA' END) location
FROM employees;
```
### 多行子查询
多行操作符 `IN/ANY/ALL/SOME` 对应单行子查询：
- `ALL` 需要和单行比较操作符一起使用，和子查询返回的所有值比较
- `ANY/SOME` 需要和单行比较操作符一起使用，和子查询返回的某一个值比较
```mysql
# 返回比job_id = 'IT_PROG'部门任一工资低的
SELECT employee_id, last_name, job_id, salary
FROM employees
WHERE job_id <> 'IT_PROG' 
AND salary < ANY(
	SELECT salary
    FROM emplyees
    WHERE job_id = 'IT_PROG'
);

# 查询平均工资最低的部门id
# 方式1：
SELECT department_id
FROM employees
GROUP BY department_id
HAVING AVG(salary) = (
        SELECT MIN(avg_sal)
        FROM (
            SELECT AVG(salary) avg_sal
            FROM employees
            GROUP BY department_id
            ) dept_avg_sal
);
#方式2：
SELECT department_id
FROM employees
GROUP BY department_id
HAVING AVG(salary) <= ALL (
        SELECT AVG(salary) avg_sal
        FROM employees
        GROUP BY department_id
);
```
### 相关子查询
如果子查询的执行依赖于外部查询，通常情况下都是因为子查询中的表用到外部的表，并进行条件关联，因此每执行一次外部查询，子查询都要重新计算一次，这样的子查询就称之为关联子查询。 
相关子查询按照一行接一行的顺序执行，主查询的每一行都执行一次子查询。
```mysql
# 查询工资大于本部门平均工资的员工
# 方式一：使用相关子查询
SELECT last_name, salary, department
FROM employees e1
WHERE salary > (
    SELECT AVG(salary)
    FROM employees e2
    WHERE department_id = e1.`department_id`
);

# 方式二：在FROM中声明子查询
SELECT e.last_name, e.salary, e.department_id
FROM employees e, (
    			SELECT department_id, AVG(salary) avg_sal
    			FROM employees
    			GROUP BY department_id) t_dept_avg_salary
WHERE e.department_id = t_dept_avg_salary.department_id
AND e.salary > t_dept_avg_salary.avg_sal;
```
#### EXISTS 与 NOT EXISTS 
关联子查询通常会和 `EXISTS` 操作符一起来使用，用来检查在子查询中是否存在满足条件的行。
* 如果在子查询中不存在满足条件的行：条件返回 `FALSE`，继续在子查询中查找。
* 如果在子查询中存在满足条件的行：不在子查询中继续查找，条件返回 `TRUE`。
```mysql
# 查询公司管理者的employee_id，last_name，job_id，department_id信息
# 方式一：EXISTS
SELECT employee_id, last_name, job_id, department_id
FROM employees e1
WHERE EXISTS (SELECT *
        FROM employees e2
        WHERE e2.manager_id = e1.employee_id
);

# 方式二：自连接
SELECT DISTINCT e1.employee_id, e1.last_name, e1.job_id, e1.department_id
FROM employees e1 JOIN employees e2
ON e1.employee_id = e2.manager_id;

# 方式三：子查询
# 子查询是通过未知表进行查询后的条件判断，而自连接是通过已知的自身数据表进行条件判断
# 因此在大部分 DBMS 中都会对自连接处理进行优化
SELECT employee_id, last_name, job_id, department_id
FROM employees
WHERE employee_id IN (
        SELECT DISTINCT manager_id
        FROM employees
);

# 查询departments表中，不存在于employees表中的部门
# 方式一：
SELECT d.department_id, d.department_name
FROM departments e RIGHT JOIN departments d
ON e.`department_id` = d.`department_id`
WHERE e.`department_id` IS NULL;

# 方式二：
SELECT department_id, department_name
FROM departments d
WHERE NOT EXISTS (
    SELECT *
    FROM employees e
    WHERE d.`department_id` = e.`department_id`
);
```
#### 相关更新
使用相关子查询依据一个表中的数据更新另一个表的数据。
```mysql
UPDATE table1 alias1
SET column = (SELECT expression
                FROM table2 alias2
                WHERE alias1.column = alias2.column);

# 在employees中增加一个department_name字段，数据为员工对应的部门名称
ALTER TABLE employees
ADD(department_name VARCHAR2(14));

UPDATE employees e
SET department_name = (SELECT department_name
                        FROM departments d
                        WHERE e.department_id = d.department_id);
```
#### 相关删除
使用相关子查询依据一个表中的数据删除另一个表的数据。
```mysql
DELETE FROM table1 alias1
WHERE column operator (SELECT expression
FROM table2 alias2
WHERE alias1.column = alias2.column);

# 删除表employees中，其与emp_history表皆有的数据
DELETE FROM employees e
WHERE employee_id in(
    SELECT employee_id
    FROM emp_history
    WHERE employee_id = e.employee_id
);
```
## 索引
`InnoDB` 和 `MyISAM` 会自动为主键或者声明为 `UNIQUE` 的列去建立 `B+` 树索引，但是如果想为其他的列建立索引就需要显式的去指明。
可以在创建表的时候指定需要建立索引的单个列或者建立联合索引的多个列：
```mysql
CREATE TALBE 表名 (
    各种列的信息 ··· , 
    [KEY|INDEX] 索引名 (需要被索引的单个列或多个列)
)
```
也可以在修改表结构的时候添加索引：
```sql
ALTER TABLE 表名 ADD [INDEX|KEY] 索引名 (需要被索引的单个列或多个列);
```
也可以在修改表结构的时候删除索引：
```sql
ALTER TABLE 表名 DROP [INDEX|KEY] 索引名;
```
如果想在创建 `index_demo` 表的时候就为 `c2` 和 `c3` 列添加一个联合索引，可以这么写建表语句：
```sql
CREATE TABLE index_demo(
    c1 INT,
    c2 INT,
    c3 CHAR(1),
    PRIMARY KEY(c1),
    INDEX idx_c2_c3 (c2, c3)
);
```
如果想删除这个索引：
```sql
ALTER TABLE index_demo DROP INDEX idx_c2_c3;
```

# 创建和管理表

## 1. 基础知识
### 1) 标识符命名规则
* 数据库名、表名不得超过 30 个字符，变量名限制为 29 个 
* 必须只能包含 `A–Z, a–z, 0–9, _` 共 63 个字符 
* 数据库名、表名、字段名等对象名中间不要包含空格 
* 同一个MySQL软件中，数据库不能同名；同一个库中，表不能重名；同一个表中，字段不能重名 
* 必须保证你的字段没有和保留字、数据库系统或常用方法冲突。如果坚持使用，请在SQL语句中使 用着重号引起来
* 保持字段名和类型的一致性：在命名字段并为其指定数据类型的时候一定要保证一致性，假如数据 类型在一个表里是整数，那在另一个表里可就别变成字符型了
### 2) MySQL中的数据类型

| 类型             | 数据变量                                                     |
| ---------------- | ------------------------------------------------------------ |
| 整数类型         | TINYINT、SMALLINT、MEDIUMINT、INT(或INTEGER)、BIGINT         |
| 浮点类型         | FLOAT、DOUBLE                                                |
| 定点数类型       | DECIMAL                                                      |
| 位类型           | BIT                                                          |
| 日期时间类型     | YEAR、TIME、DATE、DATETIME、TIMESTAMP                        |
| 文本字符串类型   | CHAR、VARCHAR、TINYTEXT、TEXT、MEDIUMTEXT、LONGTEXT          |
| 枚举类型         | ENUM                                                         |
| 集合类型         | SET                                                          |
| 二进制字符串类型 | BINARY、VARBINARY、TINYBLOB、BLOB、MEDIUMBLOB、LONGBLOB      |
| JSON类型         | JSON对象、JSON数组                                           |
| 空间数据类型     | 单值：GEOMETRY、POINT、LINESTRING、POLYGON； 集合：MULTIPOINT、MULTILINESTRING、MULTIPOLYGON、 GEOMETRYCOLLECTION |

其中，常用的几类类型介绍如下：

| 数据类型      | 描述                                                    |
| ------------- | ------------------------------------------------------- |
| INT           | 从-2^31到2^31-1的整型数据。存储大小为 4个字节           |
| CHAR(size)    | FLOAT、DOUBLE                                           |
| VARCHAR(size) | DECIMAL                                                 |
| FLOAT(M,D)    | BIT                                                     |
| DOUBLE(M,D)   | YEAR、TIME、DATE、DATETIME、TIMESTAMP                   |
| DECIMAL(M,D)  | CHAR、VARCHAR、TINYTEXT、TEXT、MEDIUMTEXT、LONGTEXT     |
| DATE          | ENUM                                                    |
| BLOB          | SET                                                     |
| TEXT          | BINARY、VARBINARY、TINYBLOB、BLOB、MEDIUMBLOB、LONGBLOB |

## 2. 创建和管理数据库

### 1) 创建数据库

* 方式1：创建数据库

  ```mysql
  CREATE DATABASE 数据库名;
  ```

* 方式2：创建数据库并指定字符集

  ```mysql
  CREATE DATABASE 数据库名 CHARACTER SET 字符集;
  ```

* 方式3：判断数据库是否已经存在，不存在则创建数据库（ 推荐 ）

  ```mysql
  CREATE DATABASE IF NOT EXISTS 数据库名;
  ```

如果MySQL中已经存在相关的数据库，则忽略创建语句，不再创建数据库。

> 注意：DATABASE 不能改名。一些可视化工具可以改名，它是建新库，把所有表复制到新库，再删 旧库完成的。

### 2) 使用数据库

* 查看当前所有的数据库

  ```mysql
  SHOW DATABASES; #有一个S，代表多个数据库
  ```

* 查看当前正在使用的数据库

  ```mysql
  SELECT DATABASE(); #使用的一个 mysql 中的全局函数
  ```

* 查看指定库下所有的表

  ```mysql
  SHOW TABLES FROM 数据库名
  ```

* 查看数据库的创建信息

  ```mysql
  SHOW CREATE DATABASE 数据库名;
  或者：
  SHOW CREATE DATABASE 数据库名\G
  ```

* 使用/切换数据库

  ```mysql
  USE 数据库名;
  ```

> 注意：要操作表格和数据之前必须先说明是对哪个数据库进行操作，否则就要对所有对象加上“数 据库名.”。

### 3) 修改数据库

* 更改数据库字符集

  ```mysql
  ALTER DATABASE 数据库名 CHARACTER SET 字符集; #比如：gbk、utf8等
  ```

* 方式1：删除指定的数据库

  ```mysql
  DROP DATABASE 数据库名;
  ```

* 方式2：删除指定的数据库（ 推荐 ）

  ```mysql
  DROP DATABASE IF EXISTS 数据库名;
  ```

## 3. 创建表

### 1) 创建方式1

* 语法格式：

```mysql
CREATE TABLE [IF NOT EXISTS] 表名(
字段1, 数据类型 [约束条件] [默认值],
字段2, 数据类型 [约束条件] [默认值],
字段3, 数据类型 [约束条件] [默认值],
……
[表约束条件]
);
```

> 加上了IF NOT EXISTS关键字，则表示：如果当前数据库中不存在要创建的数据表，则创建数据表； 如果当前数据库中已经存在要创建的数据表，则忽略建表语句，不再创建数据表。

### 2) 创建方式2

* 使用 AS subquery 选项，将创建表和插入数据结合起来

```mysql
CREATE TABLE 表名
	[(column, column, ...)]
AS subquery;
```

* 指定的列和子查询中的列要一一对应
* 通过列名和默认值定义列

```mysql
CREATE TABLE dept80
AS
SELECT employee_id, last_name, salary*12 ANNSAL, hire_date
FROM employees
WHERE department_id = 80;
```

### 3) 查看数据表结构

在MySQL中创建好数据表之后，可以查看数据表的结构。MySQL支持使用 DESCRIBE/DESC 语句查看数据 表结构，也支持使用 SHOW CREATE TABLE 语句查看数据表结构。

语法格式如下：

```mysql
SHOW CREATE TABLE 表名\G
```

使用SHOW CREATE TABLE语句不仅可以查看表创建时的详细语句，还可以查看存储引擎和字符编码。

## 4. 修改表

修改表指的是修改数据库中已经存在的数据表的结构。

使用 ALTER TABLE 语句可以实现：

+ 向已有的表中添加列
+ 修改现有表中的列
+ 删除现有表中的列
+ 重命名现有表中的列

### 1) 追加一个列

语法格式如下：

```mysql
ALTER TABLE 表名 ADD 【COLUMN】 字段名 字段类型 【FIRST|AFTER 字段名】;
```

举例：

```mysql
ALTER TABLE dept80
ADD job_id varchar(15);
```

### 2) 修改一个列

* 可以修改列的数据类型，长度、默认值和位置 
* 修改字段数据类型、长度、默认值、位置的语法格式如下：

```mysql
ALTER TABLE 表名 MODIFY 【COLUMN】 字段名1 字段类型 【DEFAULT 默认值】【FIRST|AFTER 字段名2】;
```

* 举例：

```mysql
ALTER TABLE dept80
MODIFY salary double(9,2) default 1000;
```

* 对默认值的修改只影响今后对表的修改
* 此外，还可以通过此种方式修改列的约束。

### 3) 重命名一个列

使用 CHANGE old_column new_column dataType子句重命名列。语法格式如下：

```mysql
ALTER TABLE 表名 CHANGE 【column】 列名 新列名 新数据类型;
```

举例：

```mysql
ALTER TABLE dept80
CHANGE department_name dept_name varchar(15);
```

### 4) 删除一个列

删除表中某个字段的语法格式如下：

```mysql
ALTER TABLE 表名 DROP 【COLUMN】字段名
```

### 5) 更改表名

* 方式一：使用RENAME

```mysql
RENAME TABLE emp
TO myemp;
```

* 方式二：

```mysql
ALTER table dept
RENAME [TO] detail_dept; -- [TO]可以省略
```

* 必须是对象的拥有者

## 5. 删除表

* 在MySQL中，当一张数据表 没有与其他任何数据表形成关联关系 时，可以将当前数据表直接删除。 
* 数据和结构都被删除 
* 所有正在运行的相关事务被提交 
* 所有相关索引被删除 
* 语法格式：

```mysql
DROP TABLE [IF EXISTS] 数据表1 [, 数据表2, …, 数据表n];
```

IF EXISTS 的含义为：如果当前数据库中存在相应的数据表，则删除数据表；如果当前数据库中不存 在相应的数据表，则忽略删除语句，不再执行删除数据表的操作。

举例：

```mysql
DROP TABLE dept80;
```

* DROP TABLE 语句不能回滚

## 6. 清空表

* TRUNCATE TABLE语句：
  * 删除表中所有的数据
  * 释放表的存储空间
* 举例：

```mysql
TRUNCATE TABLE detail_dept;
```

* TRUNCATE语句不能回滚，而使用 DELETE 语句删除数据，可以回滚

> 阿里开发规范： 【参考】TRUNCATE TABLE 比 DELETE 速度快，且使用的系统和事务日志资源少，但 TRUNCATE 无 事务且不触发 TRIGGER，有可能造成事故，故不建议在开发代码中使用此语句。 说明：TRUNCATE TABLE 在功能上与不带 WHERE 子句的 DELETE 语句相同。

## 7. 内容扩展

### 拓展1：阿里巴巴《Java开发手册》之MySQL字段命名

* 【 强制 】表名、字段名必须使用小写字母或数字，禁止出现数字开头，禁止两个下划线中间只出 现数字。数据库字段名的修改代价很大，因为无法进行预发布，所以字段名称需要慎重考虑。
  * 正例：aliyun_admin，rdc_config，level3_name
  * 反例：AliyunAdmin，rdcConfig，level_3_name

* 【 强制 】禁用保留字，如 desc、range、match、delayed 等，请参考 MySQL 官方保留字。
* 【 强制 】表必备三字段：id, gmt_create, gmt_modified。
  * 说明：其中 id 必为主键，类型为BIGINT UNSIGNED、单表时自增、步长为 1。gmt_create, gmt_modified 的类型均为 DATETIME 类型，前者现在时表示主动式创建，后者过去分词表示被 动式更新
* 【 推荐 】表的命名最好是遵循 “业务名称_表的作用”。
  + 正例：alipay_task 、 force_project、 trade_config
* 【 推荐 】库名与应用名称尽量一致。
* 【参考】合适的字符存储长度，不但节约数据库表空间、节约索引存储，更重要的是提升检索速度。
  + 正例：无符号值可以避免误存负数，且扩大了表示范围。

### 扩展2：操作注意要求

* 表删除 操作将把表的定义和表中的数据一起删除，并且MySQL在执行删除操作时，不会有任何的确认信 息提示，因此执行删除操时应当慎重。在删除表前，最好对表中的数据进行 备份 ，这样当操作失误时可 以对数据进行恢复，以免造成无法挽回的后果。
* 同样的，在使用 ALTER TABLE 进行表的基本修改操作时，在执行操作过程之前，也应该确保对数据进 行完整的 备份 ，因为数据库的改变是 无法撤销 的，如果添加了一个不需要的字段，可以将其删除；相 同的，如果删除了一个需要的列，该列下面的所有数据都将会丢失。

### 扩展3：MySQL8新特性—DDL的原子化

在MySQL 8.0版本中，InnoDB表的DDL支持事务完整性，即 DDL操作要么成功要么回滚 。DDL操作回滚日志 写入到data dictionary数据字典表mysql.innodb_ddl_log（该表是隐藏的表，通过show tables无法看到） 中，用于回滚操作。通过设置参数，可将DDL操作日志打印输出到MySQL错误日志中。

# 数据处理之增删改

## 1. 插入数据

### 1) 方式1：VALUES的方式添加

使用这种语法一次只能向表中插入一条数据。

**情况1：为表的所有字段按默认顺序插入数据**

```mysql
INSERT INTO 表名
VALUES (value1,value2,....);
```

值列表中需要为表的每一个字段指定值，并且值的顺序必须和数据表中字段定义时的顺序相同。

举例：

```mysql
INSERT INTO departments
VALUES (70, 'Pub', 100, 1700);
```

**情况2: 指定字段名插入数据**

为表的指定字段插入数据，就是在INSERT语句中只向部分字段中插入值，而其他字段的值为表定义时的 默认值。 在 INSERT 子句中随意列出列名，但是一旦列出，VALUES中要插入的value1,....valuen需要与 column1,...columnn列一一对应。如果类型不同，将无法插入，并且MySQL会产生错误。 

举例：

```mysql
INSERT INTO departments(department_id, department_name)
VALUES (80, 'IT');
```

**情况3：同时插入多条记录**

INSERT语句可以同时向数据表中插入多条记录，插入时指定多个值列表，每个值列表之间用逗号分隔 开，基本语法格式如下：

```mysql
INSERT INTO table_name
VALUES
(value1 [,value2, …, valuen]),
(value1 [,value2, …, valuen]),
……
(value1 [,value2, …, valuen]);
```

或者

```mysql
INSERT INTO table_name(column1 [, column2, …, columnn])
VALUES
(value1 [,value2, …, valuen]),
(value1 [,value2, …, valuen]),
……
(value1 [,value2, …, valuen]);
```

使用INSERT同时插入多条记录时，MySQL会返回一些在执行单行插入时没有的额外信息，这些信息的含 义如下：

* Records：表明插入的记录条数。 
* Duplicates：表明插入时被忽略的记录，原因可能是这 些记录包含了重复的主键值。 
* Warnings：表明有问题的数据值，例如发生数据类型转换。

> 一个同时插入多行记录的INSERT语句等同于多个单行插入的INSERT语句，但是多行的INSERT语句 在处理过程中 效率更高 。因为MySQL执行单条INSERT语句插入多行数据比使用多条INSERT语句 快，所以在插入多条记录时最好选择使用单条INSERT语句的方式插入。

### 2) 方式2：将查询结果插入到表中

INSERT还可以将SELECT语句查询的结果插入到表中，此时不需要把每一条记录的值一个一个输入，只需要使用一条INSERT语句和一条SELECT语句组成的组合语句即可快速地从一个或多个表中向一个表中插入多行

```mysql
INSET INTO 目标表名
(tar_column1 [, tar_column2, ..., tar_columnn])
SELECT
(src_column1 [, src_column2, …, src_columnn])
FROM 源表名
[WHERE condition]
```

* 在 INSERT 语句中加入子查询。 
* 不必书写 VALUES 子句。 
* 子查询中的值列表应与 INSERT 子句中的列名对应。

```mysql
INSERT INTO emp2
SELECT *
FROM employees
WHERE department_id = 90;
```

```mysql
INSERT INTO sales_reps(id, name, salary, commission_pct)
SELECT employee_id, last_name, salary, commission_pct
FROM employees
WHERE job_id LIKE '%REP%';
```

## 2. 更新数据

* 使用 UPDATE 语句更新数据。语法如下：

```mysql
UPDATE table_name
SET column1=value1, column2=value2, ..., column=valuen
[WHERE condition]
```

* 可以一次更新多条数据。
* 如果需要回滚数据，需要保证在DML前，进行设置：SET AUTOCOMMIT = FALSE;

* 使用 WHERE 子句指定需要更新的数据。

```mysql
UPDATE employees
SET department_id = 70
WHERE employee_id = 113;
```

* 如果省略 WHERE 子句，则表中的所有数据都将被更新。

## 3. 删除数据

```mysql
DELETE FROM table_name [WHERE <condition>];
```

table_name指定要执行删除操作的表；“[WHERE ]”为可选参数，指定删除条件，如果没有WHERE子句， DELETE语句将删除表中的所有记录。

## 4. MySQL8新特性：计算列

什么叫计算列呢？简单来说就是某一列的值是通过别的列计算得来的。例如，a列值为1、b列值为2，c列 不需要手动插入，定义a+b的结果为c的值，那么c就是计算列，是通过别的列计算得来的。

在MySQL 8.0中，CREATE TABLE 和 ALTER TABLE 中都支持增加计算列。下面以CREATE TABLE为例进行讲解。

举例：定义数据表tb1，然后定义字段id、字段a、字段b和字段c，其中字段c为计算列，用于计算a+b的 值。 首先创建测试表tb1，语句如下：

```mysql
CREATE TABLE tb1(
id INT,
a INT,
b INT,
c INT GENERATED ALWAYS AS (a + b) VIRTUAL
);
```
