# Lambda Extensions
`Lambda` 提供了一些函数无法提供的便利：
- 可以在函数内部定义。
- 可以捕获运行时的值，来指定在运行时的功能行为。
- 可以将它们作为参数传递，而无需指定参数类型。
在 `C++20` `Lambda` 也可以是协程，但这种情况下，`Lambda` 不该捕获任何内容，因为协程可能比本地创建的 `Lambda` 对象存在的时间更长。
## Generic Lambdas with Template Parameters
`C++20` 允许对泛型 `Lambda` 使用模板形参，可以在捕获子句和调用参数之间指定这些模板参数，模板形参优点在于可以在声明泛型参数时为类型或类型的一部分提供名称。
```cpp
auto foo = []<typename T>(const T& param) { // OK since C++20
    T tmp{}; // declare object with type of the template parameter
    ...
};

[]<typename T>(T* ptr) { // OK since C++20
    ... // can use T as type of the value that ptr points to
};
// Or:
[]<typename T, int N>(T (&arr)[N]) {
    ... // can use T as element type and N as size of the passed array
};
```
这也可用于为类型的一部分提供名称：
```cpp
[]<typename T>(const std::vector<T>& vec) { // can only pass vectors
    ...
};
```
这个 `Lambda` 只接受 `vector` 作为参数。而使用 `auto` 时，将实参限制为 `vector` 并不容易，因为 `C++` 不支持 `std::vector` 类型，不过也可以使用类型约束来约束参数的类型。 
对于泛型 `Lambda`，函数调用操作符是一个模板。例如，若定义下面的 `Lambda`，除非使用间接调用，否则无法避免指定函数操作符的模板形参。
```cpp
auto primeNumbers = [] <int Num> () {
    std::array<int, Num> primes{};
    ... // compute and assign first Num prime numbers
    return primes;
};

// 编译器定义相应的闭包类型
class NameChosenByCompiler {
public:
    ...
    template<int Num>
    auto operator() () const {
        std::array<int, Num> primes{};
        ... // compute and assign first Num prime numbers
        return primes;
    }
};

// 并创建该类的一个对象(若没有捕获值则使用默认构造函数):
auto primeNumbers = NameChosenByCompiler{};

// 当将 Lambda 用作函数时，必须指定模板参数
// initialize array with the first 20 prime numbers:
auto primes20 = primeNumbers.operator()<20>();
```
模板参数有助于避免对 `decltype` 的需要。例如，要在 `Lambda` 中完美地转发泛型参数包：
```cpp
[]<typename... Types>(Types&&... args) {
    foo(std::forward<Types>(args)...);
};

// instead of:
[] (auto&&... args) {
    foo(std::forward<decltype(args)>(args)...);
};
```
类似的例子是在访问 `std::variant<>` 时，会具有特定类型的行为：
```cpp
std::variant<int, std::string> var;
...
// 必须使用 decltype() 来获取参数的类型，并将该类型作为 const& 进行比较
// call generic lambda with type-specific behavior:
std::visit([](const auto& val) {
    if constexpr(std::is_same_v<decltype(val), const std::string&>) {
        ... // string-specific processing
    }
    std::cout << val << '\n';
    }, var);
    
// C++20 起可以这样：
std::visit([]<typename T>(const T& val) { // since C++20
    if constexpr(std::is_same_v<T, std::string>) {
        ... // string-specific processing
    }
    std::cout << "value: " << val << '\n';
    }, var);
```
## Lambdas as Non-Type Template Parameters
`C++20` 起，`Lambda` 可以用作非类型模板形参：
```cpp
template<std::invocable auto GetVat>
int addTax(int value) {
    return static_cast<int>(std::round(value * (1 + GetVat())));
}

auto defaultTax = [] { // OK
    return 0.19;
};
std::cout << addTax<defaultTax>(100) << '\n';
```
## Calling the Default Constructor of Lambdas
`Lambda` 提供一种简单的方法来定义函数对象，生成的闭包类型会定义函数操作符，可以将 `Lambda` 对象作为函数使用，但 `C++20` 之前，生成的闭包类型没有可调用的默认构造函数和赋值操作符。生成类的对象最初只能由编译器创建，只可复制：
```cpp
auto cmp1 = [] (const auto& x, const auto& y) {
    return x > y;
};
auto cmp2 = cmp1; // OK, copy constructor supported since C++11
decltype(cmp1) cmp3; // ERROR until C++20: no default constructor provided
cmp1 = cmp2; // ERROR until C++20: no assignment operator provided
```
因为容器需要辅助函数的类型，所以将 `Lambda` 作为排序标准或哈希函数传递给容器需要作为参数传递。考虑一个具有以下接口的 `Customer` 类:
```cpp
class Customer {
    public:
    ...
    std::string getName() const;
};
```
要使用 `getName()` 返回的名称作为哈希函数的排序标准或值，必须将类型和 `Lambda` 作为模板和调用参数传递：
```cpp
// create balanced binary tree with user-defined ordering criterion:
auto lessName = [] (const Customer& c1, const Customer& c2) {
    return c1.getName() < c2.getName();
};
std::set<Customer, decltype(lessName)> coll1{lessName};

// create hash table with user-defined hash function:
auto hashName = [] (const Customer& c) {
    return std::hash<std::string>{}(c.getName());
};
// 对于无序容器，必须先传递最小桶大小
std::unordered_set<Customer, decltype(hashName)> coll2{0, hashName};
```
自 `C++20` 起，生成的闭包类型有一个默认构造函数和一个赋值操作符：
```cpp
auto cmp1 = [] (const auto& x, const auto& y) {
    return x > y;
};
auto cmp2 = cmp1; // OK, copy constructor supported
decltype(cmp1) cmp3; // OK since C++20
cmp1 = cmp2; // OK since C++20
```
出于这个原因，可以只为排序条件或哈希函数传递 `Lambda` 的类型，因为排序条件或散列函数的参数有一个默认值，该值是排序条件或哈希列函数类型的默认构造对象:
```cpp
// create balanced binary tree with user-defined ordering criterion:
auto lessName = [] (const Customer& c1, const Customer& c2) {
    return c1.getName() < c2.getName();
};
std::set<Customer, decltype(lessName)> coll1; // OK since C++20

// create hash table with user-defined hash function:
auto hashName = [] (const Customer& c) {
    return std::hash<std::string>{}(c.getName());
};
std::unordered_set<Customer, decltype(hashName)> coll2; // OK since C++20
```
甚至可以在容器的声明中定义 `Lambda`，并使用 `decltype` 传递其类型。例如，可以声明一个关联容器，并在声明中定义排序：
```cpp
// create balanced binary tree with user-defined ordering criterion:
std::set<Customer,
decltype([] (const Customer& c1, const Customer& c2) {
    return c1.getName() < c2.getName();
})> coll3; // OK since C++20


// create hash table with user-defined hash function:
std::unordered_set<Customer,
decltype([] (const Customer& c) {
    return std::hash<std::string>{}(c.getName());
})> coll; // OK since C++20
```
## consteval Lambdas
通过对 `Lambda` 使用 `consteval` 关键字，可以要求 `Lambda` 成为立即函数，以便函数调用必须在编译时求值，必须在 `consteval` 之前提供参数列表(指定 `constexpr` 时也适用)。例如：
```cpp
auto hashed = [] (const char* str) consteval {
    ...
};
auto hashWine = hashed("wine"); // hash() called at compile time
```
由于在 `Lambda` 的定义中使用 `consteval`，调用都必须在编译时使用编译时已知的值进行。传递运行时值是错误的：
```cpp
const char* s = "beer";
auto hashBeer = hashed(s); // ERROR
constexpr const char* cs = "water";
auto hashWater = hashed(cs); // OK
```
还可以将新的模板语法用于具有 `consteval` 的泛型 `Lambda`，这使开发者能够在另一个函数中定义编译时函数的初始化。例如：
```cpp
// local compile-time computation of Num prime numbers:
auto primeNumbers = [] <int Num> () consteval {
    std::array<int, Num> primes;
    int idx = 0;
    for (int val = 1; idx < Num; ++val) {
        if (isPrime(val)) 
            primes[idx++] = val;
    }
    return primes;
};

auto primes = primeNumbers.operator()<100>();
```
## Changes for Capturing
### Capturing This
若在成员函数中定义 `Lambda`，问题是如何访问调用该成员函数对象的数据。`C++20` 前有以下规则：
```cpp
class MyType {
    std::string name;
    ...
    void foo() {
        int val = 0;
        ...
        auto l0 = [val] { bar(val, name); }; // ERROR: member name not captured
        auto l1 = [val, name=name] { bar(val, name); }; // OK, capture val and name by value
        auto l2 = [&] { bar(val, name); }; // OK (val and name by reference)
        auto l3 = [&, this] { bar(val, name); }; // OK (val and name by reference)
        auto l4 = [&, *this] { bar(val, name); }; // OK (val by reference, name by value)
        auto l5 = [=] { bar(val, name); }; // OK (val by value, name by reference)
        auto l6 = [=, this] { bar(val, name); }; // ERROR before C++20
        auto l7 = [=, *this] { bar(val, name); }; // OK (val and name by value)
        ...
    }
};

```
自 `C++20` 起：
- 不能隐式捕获 `*this`
- 允许 `[=, this]` 捕获
```cpp
class MyType {
    std::string name;
    ...
    void foo() {
        int val = 0;
        ...
        auto l0 = [val] { bar(val, name); }; // ERROR: member name not captured
        auto l1 = [val, name=name] { bar(val, name); }; // OK, capture val and name by value
        auto l2 = [&] { bar(val, name); }; // deprecated (val and name by ref.)
        auto l3 = [&, this] { bar(val, name); }; // OK (val and name by reference)
        auto l4 = [&, *this] { bar(val, name); }; // OK (val by reference, name by value)
        auto l5 = [=] { bar(val, name); }; // deprecated (val by value, name by ref.)
        auto l6 = [=, this] { bar(val, name); }; // OK (val by value, name by reference)
        auto l7 = [=, *this] { bar(val, name); }; // OK (val and name by value)
        ...
    }
};
```
### Capturing Structured Bindings
`C++20` 起，允许捕获结构化绑定：
```cpp
std::map<int, std::string> mymap;
...
for (const auto& [key,val] : mymap) {
    auto l = [key, val] { // OK since C++20
        ...
    };
    ...
}
```
### Capturing Parameter Packs of Variadic Templates
若有一个可变模板，可以像下面这样捕获参数包：
```cpp
template<typename... Args>
void foo(Args... args) {
    auto l1 = [&] {
        bar(args...); // OK
    };
    auto l2 = [args...] { // or [=]
        bar(args...); // OK
    };
    ...
}
```
但如果向返回创建的 `Lambda`，就会出现问题：
- 由于使用 `[&]`，该 `Lambda` 会引用已销毁的参数包
- 由于使用 `[args…]` 或 `[=]`，会复制传递的参数包
捕获对象时，可以使用 `init-capturing` 来使用移动语义：
```cpp
template<typename T>
void foo(T arg) {
    auto l3 = [arg = std::move(arg)] { // OK since C++14
        bar(arg); // OK
    };
    ...
}

template<typename... Args>
void foo(Args... args)
{
    auto l4 = [...args = std::move(args)] { // OK since C++20
        bar(args...); // OK
    };
...
}
```
还可以通过引用来 `init-capturing` 参数包：
```cpp
template<typename... Args>
void foo(Args... args)
{
    auto l4 = [&...fooArgs = args] { // OK since C++20
        bar(fooArgs...); // OK
    };
    ...
}
```
创建并返回一个按值捕获可变数量参数的 `Lambda` 泛型函数:
```cpp
template<typename Callable, typename... Args>
auto createToCall(Callable op, Args... args)
{
    return [op, ...args = std::move(args)] () -> decltype(auto) {
        return op(args...);
    };
}

auto createToCall(auto op, auto... args)
{
    return [op, ...args = std::move(args)] () -> decltype(auto) {
        return op(args...);
    };
}
```