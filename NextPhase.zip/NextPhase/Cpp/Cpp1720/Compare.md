# Compare
对于 `Cpp20`, 为检查是否相等只需要定义单个的 `operator==` 重载，编译器会自动添加对 `!=` 的支持，表达式 `a!=b` 会重写为 `!(a==b)`，并且还会尝试改变操作数的顺序，即` !(b==a)`
```cpp
a != b // tries: a!=b, !(a==b), and !(b==a)
```
但同时拥有独立函数和成员函数会出现歧义错误，因此：
```cpp
bool operator==(const TypeA&, const TypeB&);
// or
class TypeA {
public:
    ...
    bool operator==(const TypeB&) const;
};

MyType a;
MyType b;
...
a == b; // OK: fits perfectly
b == a; // OK, rewritten as: a == b
a != b; // OK, rewritten as: !(a == b)
b != a; // OK, rewritten as: !(a == b)
```
而对于所有的比较操作符，`Cpp20` 引入三路比较操作符 `<=>` 以替代这种利用奇异递归模板模式来复用比较操作符的方法，一旦类有运算符 `==` 和 `<=>` 的重载，`Cpp20` 就会自动为所有六个比较运算符提供支持。`Cpp20` 编译器不会根据 `<=>` 重写 `==` 或 `!=`，这样做是为避免性能问题，因为 `==` 通常比使用 `<=>` 更高效。
`<=>` 操作符用于只用于重载，在 `<=>` 操作符的重载之外，不应该直接调用 `<=>`。虽然这样做没问题，但永远不要用 `a<=>b < 0` 来代替 `a < b`。
## Comparison Category Types
`<=>` 是一个二元关系运算符，返回类型根据三种比较类型之一：`partial_ordering`、`weak_ordering` 和 `strong_ordering`，定义于标准库头文件 `<compare> `中，默认为 `strong_ordering` 类型，这些类型支持与 0 进行比较。
因此 `<=>` 的结果也能通过正负判断关系：当结果大于 `0` 表示大于关系，等于 `0` 表示等价、等于关系，小于 `0` 表示小于关系。
![image-20231011203006737](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20231011203006737.png)
- 偏序 `partial_ordering` 是比较关系中的偏序关系，即给定类的任意两个对象不一定可比较。例如给定一棵对象树，假设父节点比子节点大，`<=>` 得到的结果将为 `greater`，但不是任意两个节点都可比较，此时它们的关系为 `unordered`。例如浮点类型可能需要处理特殊值 `NaN`，任何值与 `NaN` 的比较结果都为 `false`。因此，比较可能导致两个值是无序的，并且比较操作符可能返回四个 值中的一个。对于偏序关系的排序，使用拓扑排序算法将获得正确的结果。
- 弱序 `weak_ordering` 是比较关系中的全序关系，即给定类型的值小于或等于或大于该类型的其他值，并将既不大于也不小于的关系定义为等价关系。例如，长宽分别为 2 和 6 的矩形与长宽分别为 3 和 4 的比较，面积都为12，那么它们是等价的，但不相等是因为可以通过长宽区分出来它们不一样。例如 `hello`  与 `HELLO` 这两个字符串不相等但等价。标准库中的 `std::sort` 要求关系至少为弱序的才能正确工作。
- 强序 `strong_ordering` 与弱序一样，但对等价的情况视为相等关系。考虑正方形类按照面积比较就是强序关系，因为面积一样的正方形无法像长方形那样通过外表能区分出来，即它们是相等的，一些查找算法要求关系为强序才能正确工作。
在标准库比较类别中，如果操作数是整数类型，则结果是强排序，并且可以是以下之一:
- `strong ordering::less`: 第一个操作数小于第二个 
- `strong_ordering::greater`：第一个操作数大于第二个
- `strong_ordering::equal`：第一个操作数等于第二个 
如果操作数是浮点类型，结果是一个偏序：
- `partial_ordering::less`：第一个操作数小于第二个 
- `partial_ordering::greater`: 第一个操作数大于第二个 
- `partial_ordering::equivalent`：第一个操作数等价第二个 
- `partial_ordering::unordered`：如果有一个操作数是非数字或者两个操作数都是非数字
弱排序是可以选择的另一种排序类型，以针对自己的类型实现三向比较：
- `weak_ordering::less`: 第一个操作数小于第二个
- `weak_ordering::greater`：第一个操作数大于第二个 
- `weak_ordering::equivalent`：第一个操作数等价第二个 
`<compare>` 提供命名的比较函数来解释排序结果：
```cpp
int i { 11 };
strong_ordering result { i <=> 0 };
if (is_lt(result)) { cout << "less" << endl; }
if (is_gt(result)) { cout << "greater" << endl; }
if (is_eq(result)) { cout << "equal" << endl; }
```
较强比较类型具有向较弱比较类型的隐式类型转换，可以将 `strong_ordering` 与 `weak_ordering` 或 `partial_ordering` 进行比较(相等则为 `equivalent`)。但反过来不行，若比较产生 `weak_ordering` 或 `partial_ordering` 类型的值，则不能将其与 `strong_ordering` 类型的值进行比较。
```cpp
if (x <=> y == std::strong_ordering::equal) // might not compile
```
## Implementation of the operator<=>
在定义时，通过映射操作符到基础类型的结果来定义操作符通常更容易。因此，重载 `operator<=>` 时最好只是产生其成员值的值和类别，这不仅返回正确的值，还确保返回值根据成员值的类型具有正确的比较类别类型。
```cpp
class MyType { // better
    ...
    auto operator<=> (const MyType& rhs) const {
        return value <=> rhs.value;
    }
};

class MyType {
    ...
    std::strong_ordering operator<=> (const MyType& rhs) const {
        return value == rhs.value ? std::strong_ordering::equal :
        value < rhs.value ? std::strong_ordering::less :
        std::strong_ordering::greater;
    }
};
```
如果希望避免隐式转换对性能的轻微影响，可以为 `double` 提供特定的重载。对于 `Cpp20`，依然只需要提供 `operator==` 和 `operator<=>`。
可以使用 `auto` 作为 `operator<=>` 的返回类型，在这种情况下，编译器将根据数据成员的 `<=>` 运算符的返回类型推断返回类型。如果类的数据成员不支持 `operator<=>`，则返回类型推断将不起作用，需要显式指定返回类型。
但如果添加 `operator==` 和 `<=>` 的 `double` 版本，编译器将不再自动生成默认的 `operator==`，因此必须将其显式默认：
```cpp
class SpreadsheetCell
{
public:
    [[nodiscard]] auto operator<=>(const SpreadsheetCell&) const = default;
    [[nodiscard]] bool operator==(const SpreadsheetCell&) const = default;
    [[nodiscard]] bool operator==(double rhs) const;
    [[nodiscard]] std::partial_ordering operator<=>(double rhs) const;
};
```
如果可以显式地将 `operator<=>` 设置为默认，建议这样做，而不是自己实现它。通过让编译器编写，它将与新添加或修改的数据成员保持同步。如果自己实现运算符，则无论何时添加数据成员或更改现有数据成员，都需要记住更新 `operator<=>` 的实现。如果编译器没有自动生成 `operator==`（显示声明另外类型的情况），则以上内容对其也适用。
## Multiple Ordering Criteria
要基于多个属性计算运算符 `<=`> 的结果，通常可以实现一连串的子比较，直到结果不相等或得到最终的比较类型，但若属性具有不同的比较类别，则返回类型不会编译。例如，若成员名是 `string` 类型，而成员值是 `double` 类型，则返回类型会冲突：
```cpp
class Person {
    std::string name;
    double value;
    ...
    auto operator<=> (const Person& rhs) const { // ERROR: different return types deduced
        auto cmp1 = name <=> rhs.name;
        if (cmp1 != 0) return cmp1; // return strong_ordering for std::string
        return value <=> rhs.value; // return partial_ordering for double
    }
};
```
在这种情况下可以使用到最弱比较类型的转换。若已知最弱的比较类型，可以声明为返回类型：
```cpp
class Person {
    std::string name;
    double value;
    ...
    std::partial_ordering operator<=> (const Person& rhs) const { // OK
        auto cmp1 = name <=> rhs.name;
        if (cmp1 != 0) return cmp1; // strong_ordering converted to return type
        return value <=> rhs.value; // partial_ordering used as the return type
    }
};
```
但如果类型是模板形参等不知道比较类型的情况，可以使用新的类型特征`std::common_comparison_category<>` 来计算最强的比较类型：
```cpp
class Person {
    std::string name;
    double value;
    ...
    auto operator<=> (const Person& rhs) const // OK
    -> std::common_comparison_category_t<decltype(name <=> rhs.name),
        decltype(value <=> rhs.value)> {
        auto cmp1 = name <=> rhs.name;
        if (cmp1 != 0) return cmp1; // used as or converted to common comparison type
        return value <=> rhs.value; // used as or converted to common comparison type
    }
};
```
若希望提供比内部使用的类别更强的类别，则必须将内部比较的所有可能值映射到返回类型的值。若不能映射某些值，则需要包括一些错误处理。例如:
```cpp
class Person {
    std::string name;
    double value;
    ...
    std::strong_ordering operator<=> (const Person& rhs) const {
        auto cmp1 = name <=> rhs.name;
        if (cmp1 != 0) return cmp1; // return strong_ordering for std::string
        auto cmp2 = value <=> rhs.value; // might be partial_ordering for double
        // map partial_ordering to strong_ordering:
        assert(cmp2 != std::partial_ordering::unordered); // RUNTIME ERROR if unordered
        return cmp2 == 0 ? std::strong_ordering::equal
                : cmp2 > 0 ? std::strong_ordering::greater
                : std::strong_ordering::less;
    }
};
```
`C++` 标准库为此提供了一些辅助函数对象。例如，映射浮点值，可以使用 `std::strong_order()` 来比较两个值：
```cpp
class Person {
    std::string name;
    double value;
    ...
    std::strong_ordering operator<=> (const Person& rhs) const {
        auto cmp1 = name <=> rhs.name;
        if (cmp1 != 0) return cmp1; // return strong_ordering for std::string
        // map floating-point comparison result to strong ordering:
        return std::strong_order(value, rhs.value);
    }
};
```
`std::strong_order()` 会根据传入的参数产生一个 `std::strong_ordering` 值，如下所示：
- 若 `strong_order` 为传递的类型已定义，则使用 `strong_order(val1, val2)`
- 否则，若传递的值是浮点类型，则使用 ISO/IEC/IEEE 60559 中指定的 `totalOrder()` 的值
- 若 `std::compare_three_way` 为传递的类型已定义，则使用 `std::compare_three_way{}(val1, val2)`，它是用于调用 `<=>` 操作符的新函数对象类型，就像 `std::less` 是用于小于操作符的函数对象类型一样。 
而对于其它具有较弱排序和 `==/<`  操作符定义的类型，可以使用函数对象 `std::compare_strong_order_fallback()`：
```cpp
class Person {
    std::string name;
    SomeType value;
    ...
    std::strong_ordering operator<=> (const Person& rhs) const {
        auto cmp1 = name <=> rhs.name;
        if (cmp1 != 0) return cmp1; // return strong_ordering for std::string
        // map weak/partial comparison result to strong ordering:
        return std::compare_strong_order_fallback(value, rhs.value);
    }
};
```
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240225172753.png)
## Default
在类或数据结构中(作为成员或友元函数)，可以使用 `=default` 将所有比较操作符声明为默认值， 但这通常只对 `==` 和 `<=>` 操作符有意义。若通过 `=default` 声明操作符 `<=>`，则会生成默认成员操作符 `<=>`，并隐式生成对应的默认成员 `==` 操作符，两个操作符都会使用默认实现，逐个成员对象进行比较。因此只需要 `=default` 的 `<=>` 就可以得到所有六个比较操作符。
默认操作符需要成员和可能的基类的支持：
- 默认操作符 `==` 要求在成员和基类中支持
- 默认操作符 `<=>` 要求在成员和基类中支持 `==` 和已实现的小于操作符或默认操作符 `<=>`。 
对于生成的默认操作符：
- 若比较成员保证不抛出异常，则操作符为 `noexcept`。
- 若可以在编译时比较成员，则操作符为 `constexpr`。 
- 对于空类，默认操作符为 `==/<=/>=` 生成 `true`，`!=/</>` 生成 `false`，而 `<=>` 生成 `std::strong_ordering::equal`。
```cpp
template<typename T>
class Type {
...
public:
    // 成员函数必须是 const，形参必须声明为 const &
    [[nodiscard]] virtual std::strong_ordering
    operator<=> (const Type&) const requires(!std::same_as<T,bool>) = default;
    [[nodiscard]] virtual bool // implicitly generated
    operator== (const Type&) const requires(!std::same_as<T,bool>) = default;
};
```
若 `<=>` 操作符是默认的，并且有成员或基类，那么当调用关系操作符之一时，若为成员或基类定义了操作符 `<=>`，则调用该操作符。否则，使用 `==` 和 `<` 操作符来决定，这种情况下，这些操作符的默认 `<=>` 操作符的返回类型不能为 `auto`。
```cpp
struct B {
    bool operator==(const B&) const;
    bool operator<(const B&) const;
};
struct D : public B {
    std::strong_ordering operator<=> (const D&) const = default;
};

D d1, d2;
d1 > d2; // calls B::operator== and possibly B::operator<
```
## Using Operator <=> in Generic Code
### compare_three_way
`std::compare_three_way` 是用于调用 `<=>` 的函数对象类型，可以用于比较泛型类型的值，或必须指定函数对象的类型时作为默认类型：
```cpp
template<typename T>
struct Value {
    T val{};
    ...
    auto operator<=> (const Value& v) const noexcept(noexcept(val<=>val)) {
        return std::compare_three_way{}(val<=>v.val);
    }
};

// C++20 引入类型特性 std::compare_three_way_result 和
// 别名模板 std::compare_three_way_result_t:
template<typename T>
struct Value {
    T val{};
    ...
    std::compare_three_way_result_t<T, T>
    operator<=> (const Value& v) const noexcept(noexcept(val<=>val));
};
```
`std::compare_three_way` 是定义原始指针的总序，所以当使用是原始指针类型的泛型类型时可以使用。 
### lexicographical_compare_three_way()
`C++20` 引入 `lexicographical_compare_three_way()` 算法比较两个范围并产生比较类型的值。
```cpp
std::ostream& operator<< (std::ostream& strm, std::strong_ordering val)
{
    if (val < 0) return strm << "less";
    if (val > 0) return strm << "greater";
    return strm << "equal";
}

std::vector v1{0, 8, 15, 47, 11};
std::vector v2{0, 15, 8};
auto r1 = std::lexicographical_compare(v1.begin(), v1.end(), v2.begin(), v2.end());
auto r2 = std::lexicographical_compare_three_way(v1.begin(), v1.end(), v2.begin(), v2.end());
std::cout << "r1: " << r1 << '\n';
std::cout << "r2: " << r2 << '\n';
```
## Compatibility Issues with the Comparison Operators
### Delegating Free-Standing Comparison Operators
下述有一个简单的类，存储整型值，并有一个转换构造函数：
```cpp
class MyType {
private:
    int value;
public:
    MyType(int i): value{i} {} // implicit constructor from int:
    bool operator==(const MyType& rhs) const {
        return value == rhs.value;
    }
};

bool operator==(int i, const MyType& t) {
    return t == i; // OK with C++17
}

MyType x = 42;
if (0 == x) 
    std::cout << "'0 == MyType{42}' works\n";
```
但 `C++20` 之前，只允许对第二个操作数进行隐式类型转换，所以引入一个全局操作符来交换参数的顺序。但这段代码在 `C++20` 中不再可用，会导致无尽的递归。在全局函数内部，对于表达式 `t == i`，编译器会试图将调用重写为 `i == t`，所以将会调用本身。
若只使用 `C++20`，则可以简单地删除独立函数。否则使用显式转换：
```cpp
bool operator==(int i, const MyType& t) {
    return t == MyType{i}; // OK until C++17 and with C++20
}
```
### Inheritance with Protected Members
默认的比较操作符需要在基类中支持比较，若此时提供 `protected` 的默认操作符 `==`，那么派生类的默认比较将不起作用，开发者必须自己实现派生操作符。
```cpp
struct Base {};
struct Child : Base {
    int i;
    bool operator==(const Child& other) const = default;
};
Child c1, c2;
...
c1 == c2; // ERROR

struct Base {
protected:
    bool operator==(const Base& other) const = default;
};
struct Child : Base {
    int i;
    bool operator==(const Child& other) const = default; // 不起作用
};
```