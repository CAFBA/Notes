# Auto For Parameters
## Abbreviated Function Template Syntax
`C++14` 起，`Lambda` 可以使用 `auto` 来声明/定义其参数，`C++20` 起，可以对所有函数(包括成员函数和操作符)使用 `auto`，这样的函数相当于函数模板，即简化的函数模板，每个指定为 `auto` 的参数都会成为不同的模板类型参数。
```cpp
void printColl(const auto& coll) { // generic function
    for (const auto& elem : coll) 
        std::cout << elem << '\n';
}
// 上述的等价形式
template<typename T>
void printColl(const T& coll) {
    for (const auto& elem : coll) 
        std::cout << elem << '\n';
}

class MyType {
    ...
    void assign(const auto& newVal);
};

// 该声明等价于(不同之处在于没有定义类型 T):
class MyType {
    ...
    template<typename T>
    void assign(const T& newVal);
};

void foo() {
    struct Data {
        void mem(auto); // ERROR can’t declare templates insides functions
    };
}
``` 
假设有一个这样的函数模板：
```cpp
template <typename T>
decltype(auto) add(const T& t1, const T& t2) { return t1 + t2; }
```
这个版本只有一个模板类型参数，函数的 2 个参数 `t1` 和 `t2` 都是 `const T&` 类型。对于这样的函数模板，不能使用简化的语法，因为这将转换为具有 2 个不同模板类型参数的函数模板。
此外，不能在函数模板的实现中显式地使用导出的类型，因为这些自动导出的类型没有名称。如果需要这样做，那么可以继续使用普通的函数模板语法，或者使用 `decltype` 确定其类型。
因为带有 `auto` 的函数是函数模板，所以适用于函数模板的所有规则，例如函数模板总是内联，所以不需要声明为内联。当 `auto` 用于成员函数的参数时：
## Deferred Type Checks with auto
使用 `auto` 参数，实现具有循环依赖关系的代码会容易得多。考虑两个相互使用对方对象的类，要使用另一个类的对象，需要定义它们的类型，前置声明是不够的(除非只声明引用或指针):
```cpp
class C2;

class C1 {
public:
    void foo(const C2& c2) const {
        c2.print();
    }
     void print() const;
};
class C2 {
public:
    void foo(const C1& c1) const {
        c1.print();
    }
    void print() const;
};
```
虽然可以在类定义中实现 `C2::foo()`，但不能实现 `C1::foo()`，因为要检查 `C2.print()` 的调用是否 有效，编译器需要知道类 `C2` 的定义。必须在声明两个类结构之后实现 `C2::foo()`：
```cpp
class C2;

class C1 {
public:
    void foo(const C2& c2) const;
    void print() const;
};

class C2 {
public:
    void foo(const C1& c1) const {
        c1.print(); // OK
    }
    void print() const;
};

// forward declaration
inline void C1::foo(const C2& c2) const { //implementation (inline if in header)
    c2.print(); // OK
}
```
泛型函数在调用时才会检查泛型形参的成员，所以可以使用 `auto` 实现:
```cpp
class C1 {
public:
    void foo(const auto& c2) const {
        c2.print(); // OK
    }
    void print() const;
};
class C2 {
public:
    void foo(const auto& c1) const {
        c1.print(); // OK
    }
    void print() const;
};

// 将 C1::foo() 声明为成员函数模板时也会有同样的效果，但使用 auto 会更容易
```
`auto` 允许调用者传递任何类型的参数，只要该类型提供成员函数 `print()`。若不想这样，可以使用标准概念 `std::same_as` 来约束这个成员函数只对 `C2` 类型的形参使用，对于概念来说，不完整的类型可以工作得很好：
```cpp
class C2;
class C1 {
public:
    void foo(const std::same_as<C2> auto& c2) const {
        c2.print(); // OK
    }
    void print() const;
};
```
## auto Functions versus Lambdas
带有 `auto` 参数的函数不同于 `Lambda` 表达式，不能在不指定泛型参数的情况下，传递带有 `auto` 作为参数的函数：
```cpp
bool lessByNameFunc(const auto& c1, const auto& c2) { // sorting criterion
    return c1.getName() < c2.getName(); // compare by name
}
// ERROR: can’t deduce type of parameters in sorting criterion
std::sort(persons.begin(), persons.end(), lessByNameFunc); // 相当于间接调用函数模板

// lessByName() 相当于
template<typename T1, typename T2>
bool lessByNameFunc(const T1& c1, const T2& c2) {
    return c1.getName() < c2.getName();
}
```
因为没有直接调用函数模板，编译器不能推断模板参数来编译调用。所以在传递函数模板作为形参时，必须显式指定模板的形参：
```cpp
std::sort(persons.begin(), persons.end(), lessByName<Customer, Customer>); // OK

// 使用 Lambda 表达式，可以按原样传递表达式:
auto lessByNameLambda = [] (const auto& c1, const auto& c2) { // sorting criterion
    return c1.getName() < c2.getName(); // compare by name
};
std::sort(persons.begin(), persons.end(), lessByNameLambda); // OK
```
`Lambda` 是一个没有泛型类型的对象，只有将其作为一个函数使用时才是泛型的，因此不需要显式指定。
此外，`auto` 显式指定函数模板参数更容易，`auto` 只需在函数名后传递指定的类型，而对于泛型 `Lambda` 表达式，由于运算符 `operator()` 为模板，所以必须将请求的类型作为参数传递给 `operator()`，以显式指定模板形参。
```cpp
void printFunc(const auto& arg) {...};
printFunc("hello"); // call function template compiled for std::string

auto printFunc = [] (const auto& arg) {...};
printFunc.operator()("hello"); // call lambda compiled for std::string
```
## Basic Constraints for auto Parameters
使用 `auto` 声明函数形参遵循与声明 `Lambda` 表达式形参相同的规则
- 对于用 `auto` 声明的每个形参，函数都有隐式模板形参。
- 参数可以是参数包:
```cpp
void foo(auto... args);
// 等价于
template<typename... Types>
void foo(Types... args);
```
- 不允许使用 `decltype(auto)`。
## Combining Template and auto Parameters
简化的函数模板仍然可以显式指定模板参数，模板参数的顺序与调用参数相同，为 `auto` 类型生成的模板参数可添加到指定参数 `T` 之后：
```cpp
void foo(auto x, auto y) {...}
foo("hello", 42); // x has type const char*, y has type int
foo<std::string>("hello", 42); // x has type std::string, y has type int
foo<std::string, long>("hello", 42); // x has type std::string, y has type long

template<typename T>
void foo(auto x, T y, auto z){...}
foo("hello", 42, '?'); // x has type const char*, T and y are int, z is char
foo<long>("hello", 42, '?'); // x has type const char*, T and y are long, z is char
```
因此，以下声明是等价的(除了没有为使用 `auto` 的类型命名):
```cpp
template<typename T> // 显式声明的次序在前
void foo(auto x, T y, auto z);

template<typename T, typename T2, typename T3>
void foo(T2 x, T y, T3 z);
```
通过使用概念作为类型约束，可以约束占位符参数和模板参数，可再使用模板参数来进行这样的限定。例如，下面的声明确保第二个形参 `y` 是整型，而第三个形参 `z` 的类型可以转换为 `y` 的类型:
```cpp
template<std::integral T>
void foo(auto x, T y, std::convertible_to<T> auto z) {...}
foo(64, 65, 'c'); // OK, x is int, T and y are int, z is char
foo(64, 65, "c"); // ERROR: "c" cannot be converted to type int (type of 65)
foo<long,char>(64, 65, 'c'); // NOTE: x is char, T and y are long, z is char 以错误的顺序指定参数类型
```
