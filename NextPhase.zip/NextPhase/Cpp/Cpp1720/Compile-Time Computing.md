# Compile-Time Computing
## Compile-time Polymorphism
用户使用同一个名字，需要根据上下文来决策应具体使用哪一个函数，即编译时多态。若决策失败，将导致名字冲突等编译错误。函数重载机制涉及三个阶段：名称查找、模板函数处理、重载决议。前两个阶段得到函数的候选集，最后一个阶段从候选集中选出最合适的版本。考虑如下代码，采用哪个重载版本的 `feed`：
```c++
namespace animal {
    struct Cat { }; 
    void feed(Cat* foo, int); 
};

struct CatLike { 
    CatLike (animal::Cat* ); 
}; 

void feed(CatLike);

template<typename T> 
void feed(T* obj, double);

template<> 
void feed(animal::Cat* obj, double d); //全特化版本 

animal::Cat cat;
feed(&cat, 1); // 使用哪个重载版本的 feed？
```
### Name Lookup
决策的第一阶段是名称查找，编译器需要在 `feed(&cat, 1)` 这个点找出所有与 `feed` 同名的函数声明与函数模板，通常来说名称查找过程分为三类：
- 成员函数名查找，当使用 `.` 或者 `->` 进行成员函数调用时，名称查找位于该成员类中的同名函数。
- 限定名称查找，当显式使用限定符 `::` 进行函数调用时，名称查找位于该名称空间中的同名函数。
- 未限定名称查找，除上述两种函数调用，编译器会根据参数依赖查找规则 `ADL` 进行查找。
在上面这个例子中，`feed(&cat, 1)` 属于未限定名称查找，由于实参类型 `Cat` 属于 `animal` 名称空间，其名称空间中的同名函数也会纳入考虑范围，因此这时编译器会找到如下三个候选函数：
```c++
void animal::feed(Cat* foo, int);
void feed(CatLike);
template<typename T> 
void feed(T* obj, double);
```
`ADL` 规则仅在非限定名称查找这种情况下生效，若程序员在这种情况下不想采用 `ADL` 规则，可以通过圆括号将函数名括起来，即 `(feed)(&cat, 1)` 调用将会删除第一个候选函数，候选集仅剩后两个。
需要注意的是模板特化函数并没有出现在候选集中，对于模板函数而言，其支持模板参数全特化，而对于模板类而言，不仅支持模板参数全特化，还支持偏特化。对于默认模板版本，称之为主模板版本，在名称查找过程中仅仅考虑普通函数和主模板函数为候选函数的情况，而不会考虑其所有的特化版本。只有在第三阶段选出的最合适版本为模板函数时，才会考虑其特化版本
### Template Function Processing
在前一阶段的候选集中可能会存在模板函数，对于模板函数而言无法直接调用，需要实例化，因此在这一阶段编译器将会对模板函数进行处理，从而实例化使得函数可调用。模板参数推导成功后，将会替换成推导后的类型，考虑如下候选的模板函数：
```c++
template<typename T> 
void feed(T* obj, double);
```
这个模板函数仅一个模板参数 `T`，而 `feed` 的调用没有显式指明实际的模板参数，因此编译器会根据实参 `&cat` 进行推导，得到模板参数 `T` 为 `animal::Cat`，接下来进行模板参数替换，得到可调用的模板实例化函数：
```c++
template<typename T> 
void feed(T* obj, typename T::value_type v);
```
如果模板参数推导与参数替换的过程失败，则编译器会将该模板函数从候选集中删除。什么情况下模板参数替换会失败呢？考虑如下模板函数：
该模板函数第二个形参类型为 `typename T::value_type`，因为编译器不知道 `T::value_type` 是一个静态成员变量还是一个类型别名，因此需要前置 `typename` 关键字修饰用来解除类型与值的歧义，明确告诉编译器这是一个类型。如果直接写成 `T::value_type` 则指明这是一个成员变量，无须任何修饰。
首先，编译器会根据实际调用情况将模板参数 `T` 推导为 `animal::Cat`，接下来将发生模板参数替换过程，从而得到函数签名：
```c++
void feed<animal::Cat>(animal::Cat* obj, typename animal::Cat::value_type v) ;
```
该签名的第二个形参类型为 `typename animal::Cat::value_type`，根据 `Cat` 的定义，其并不存在成员类型别名 `Cat::value_type`，语句非良构，因此这个替换失败，但并不会导致编译错误，编译器只是将其从候选集中删除而已，即 `SFINAE`。
### Overloaded esolution
最后一个阶段——重载决议，这个阶段得到的是一系列模板函数与非模板函数的候选集，这个阶段分为两步：规约可行函数集与挑选最佳可行函数。可行函数就是形参数目对应得上且形参类型能够直接或间接转换后仍可与实参类型匹配得上，同时要符合约束。根据这些规则可以判断当前哪些候选函数可行。
```c++
void animal::feed(Cat* foo, int);
void feed(CatLike);
template<typename T> 
void feed(T* obj, double);
```
对于第一个候选函数来说，形参和实参数量都为两个，第一个形参类型为 `Cat*`，而实参为 `&cat`，第二个形参类型为 `int`，实参为1，类型为 `int`，两个类型都完全匹配，那么该候选函数可行。
再来看看第二个候选函数，形参类型为 `CatLike`，由于 `CatLike(Cat*)` 类型转换构造函数能够将类型 `Cat*` 隐式转换成类型 `CatLike`，因此类型匹配。然而该候选函数只有一个形参，数量不匹配，所以该候选函数不可行。
第三个模板实例化后的候选函数基本和第一个候选函数类似，不同之处在于第二个形参类型为 `double`，由于实参类型 `int` 到 `double` 为标准转换，故该函数可行。
最后，可行函数集只有第一和第三。接下来进入第二步，从可行函数集中挑选出最佳可行函数。
编译器依据每条规则逐条进行两两比较，从而决策出最佳可行函数，否则进入下一条规则继续进行比较，若经过所有规则都没有选出最佳可行函数，那么将引发编译错误。用来判断的规则数量比较多，如下列几条比较重要的规则。
1. 形参与实参类型最匹配、转换最少的为最佳可行函数。
2. 非模板函数优于模板函数。
3. 若多于两个模板实例，那么最具体的模板实例最佳。`C++` 标准定义一系列比较规则来说明哪种模板更具体。`C++20` 起，若函数拥有约束，则选择约束更强的那一个。
根据第一条规则，可以判断可行函数 `void animal::feed(Cat*foo, int)` 的形参与实参类型完全匹配，而可行函数 `void feed<animal::Cat>(animal::Cat*，double)` 的第二个参数发生类型转换，因此决策出最佳可行函数为前者，而无需进行后续规则的决策。
假设第一个可行函数的签名为 `void animal::feed(Cat* foo, double)`，第二个参数同样需要发生类型转换，那么第一条规则无法简单决策出最佳可行函数，而根据第二条规则非模板函数优于模板函数同样可以决策出该可行函数最佳。更进一步，若第二个可行模板函数实例签名为 `void feed<animal::Cat>(animal::Cat*，int)` ，也就是类型完全匹配，而第一个函数由于第二个参数发生类型转换，那么根据第一条规则，就能决策出最佳可行函数为该模板函数实例，而无须后续的规则判断。
假设进入到第三条规则若多于两个模板实例，那么最具体的模板实例最佳，考虑如下模板函数：
```c++
template<typename T> void feed(T* obj, double d);// #1
template<typename T> void feed(T obj, double d); // #2
```
由于函数模板不支持偏特化，这两个为完全独立的模板函数（即函数重载）在模板处理阶段会各自产生两个实例化版本：
```c++
void feed<animal::Cat>(animal::Cat*, double);   // #1,T = animal::Cat 
void feed<animal::Cat*>(animal::Cat* , double); // #2,T = animal::Cat*
```
两者的唯一区别是第一个模板函数只接受指针类型，而第二个模板函数可以接受任意类型（包含指针类型），那么第一个模板函数比第二个更加具体，因为第一个模板函数能够接受的类型同样也能被第二个模板函数所接受。对于函数调用 `(feed)(&cat, 1)` 而言将决策出第一个为最佳可行函数。注意这个调用使用圆括号禁止了 `ADL`。
## Constraining Templates
### SFINAE
`SFINAE` 指的是替换失败不是错误，若泛型代码的模板参数替换失败就忽略它，而非引发编译时错误，利用这点可以编写禁用模板的代码。
如果要在 `push_back()` 和 `insert()` 之间切换，可以在 `C++20` 之前的代码中声明如下的函数模板，`push_back()` 或 `insert()` 作为模板声明的一部分，如果类型不支持导致参数替换失败，会忽略此模板而调用另一个模板。
```cpp
template<typename Coll, typename T>
auto add(Coll& coll, const T& val) -> decltype(coll.push_back(val))
{
    return coll.push_back(val);
}

template<typename Coll, typename T>
auto add(Coll& coll, const T& val) -> decltype(coll.insert(val))
{
    return coll.insert(val);
}
```
### Declval
`std::declval` 是 `C++11` 标准库里面提供的一个模板函数，用于在编译时非求值上下文中对类型进行实例化得到对象，从而可以通过对象获取到其相关信息。
考虑一个典型场景，获取给定任意一个函数与其参数进行调用得到的返回类型：
```c++
// 给定任意一个函数F与其参数Args
template<typename F, typename...Args>
using InvokeResultOfFunc = // 如何获取调用得到的返回类型
```
最简单的场景是一个普通函数类型，那么当入参类型匹配时，其返回类型也就确定，而一般场景考虑函数对象时，可能是一个 `lambda` 或用户自定义的函数对象，当入参类型不同时，其重载决议的 `operator()` 操作符也不一样，因此得到的返回类型也是不一样的：
```c++
struct AFunctionObj {
    double operator() (char, int); // #1
    float operator() (int); // #2
} f;
```
在这个场景中，若使用 `f('a'，0)` 将决议第一个版本，函数返回一个 `double` 类型的值，进一步需要使用 `decltype` 从值得到其类型，因此 `decltype(f('a'，0))` 得到函数对象调用后的返回值的类型 `double`，同理通过 `decltype(f(0))` 得到返回类型 `float`。
这里只需要声明这两个函数而不需要实现，正是因为其处于非求值上下文 `decltype` 中，因此不会导致链接错误。由此可以初步实现如下：
```c++
template<typename F, typename...Args>
using InvokeResultOfFunc = decltype(F{}(Args{}...))
```
因为无法直接对类型进行调用，因此需要对 F 进行实例化得到函数对象 `F{}`，从而能够进行函数调用动作，而且函数调用的入参也必须是对象值而不是类型，因此需要将每个入参类型通过 `Args{}...` 进行实例化，这样得到的是一个合法的函数调用语句，最终通过 `decltype` 操作符获得返回值的类型。需要注意的是实例化并不是真正在内存上构造出对象，它在编译期非求值上下文中，仅仅是用于构造合法的语句。
然而当类模板参数不可构造时，其没有默认构造函数，或者构造函数是私有的，那么上述实现将不可用，因为语句 `F{}/Args{}...` 无效。这时候可以使用 `std::declval`，它能不受以上条件的约束而构造出对象，只要在非求值上下文中将 `F{}` 对象写成 `std::declval<F>()` 即可，将待构造的类型显式传递给 `declval` 模板函数，最终的实现如下：
```c++
template<typename F, typename...Args>
using InvokeResultOfFunc = decltype(std::declval<F>()(std::declval<Args>()...))

using T1 = InvokeResultOfFunc<AFunctionObj, char, int>; // double 
using T2 = InvokeResultOfFunc<AFunctionObj, int>; // float
```
`C++` 标准中对 `std::declval` 的定义是返回一个转发引用的对象，并只能用于诸如 `decltype` 和 `sizeof` 等非求值上下文中。返回的引用类型可以是只需声明无需定义的非完备类型，其上下文不需要求值，因此放松对类型的要求，另外，转发引用可以保留左值或右值引用的属性。
第二个问题是如何确保程序员仅在非求值上下文中使用：
```c++
template<typename T> 
struct declval_protector { 
    static constexpr bool value = false; 
};

template<typename T> 
T&& declval () {
    static_assert(declval_protector<T>::value, 
        "declval 应该只在decltype/sizeof等非求值上下文中使用！");
}
```
这个实现通过静态断言 `static_assert` 将错误信息从链接错误转化成更友好的编译错误信息。静态断言的条件没有直接硬编码成 `false` 的原因是延迟实例化 `declval_protector` 模板类的时机防止无条件编译错误。
当程序员错误地在非求值上下文以外的场景中使用时，便会对函数体中的语句进行检查，从而使实例化的结果为假，导致静态断言失败，提示更加友好的信息，当程序员在非求值上下文中使用时，不会对函数体内的语句进行检查，即不会执行静态断言，据此约束了使用场景，此时获得的就是该函数返回的一个引用类型的对象，这正符合我们的要求。
事实上这个实现对于 `void` 类型来说是有问题的，因为 `void` 没有引用类型，即 `void&&` 是非法语句，因而会导致编译错误，根据 `C++` 标准，对于不可引用的类型应该返回其本身，可以通过 `SFINAE` 机制来补充这个场景。此外，标准库的实现针对 `void` 这类没有引用版本的类型提供了一个特殊的实现，即返回它们本身，这可以通过 `add_rvalue_reference_t` 来做到。
考虑提供两个 `declval` 模板函数的重载：若类型可引用，则返回类型为该类型的右值引用形式，否则为原类型，即编译时分支选择（编译时多态）。初步得到如下实现：
```c++
template<typename T> T declval ();
template<typename T, typename U = T&&> U declval ();
```
根据如上两个版本，可以构造出对应的两个用例：`decltype(declval<void>())` 的结果为 `void`，`decltype(declval<Point>())` 的结果为 `Point&&`。
首先对于 `declval<void>()` 而言，在名称查找阶段，上述两个模板函数的重载都可以成为候选函数，接下来是模板函数处理阶段，将模板参数 `T` 替换成 `void`，分别得到如下两个模板函数实例：
```c++
void declval<void>(); // #1
void&& declval<void, void&&>() // #2
```
第二个模板实例的参数替换后存在非法语句 `void&&`，因此这个替换失败，从候选集中删除，最终只剩下第一个模板函数实例，从而决策出第一个版本，最终符合预期。函数的重载过程中只看函数的声明，在模板参数替换失败后不会导致编译错误，即SFINAE。但如果它被决策为最佳可行函数，在模板函数体内发生模板参数替换失败，那么就会在实例化的过程中产生编译错误，而不是 `SFINAE`。
而对于 `declval<Point>()`，在名称查找阶段这两个重载版本都被称为候选函数，在模板函数处理阶段，产生如下两个模板实例：
```c++
void declval<Point>(); // #1
void&& declval<Point, Point&&>() // #2
```
这两个实例都合法，因此这个阶段候选集没变化，而到重载决议过程将产生歧义，因为这两个函数只有返回类型上的差异从而无法决策出最佳版本。为了能够在重载决议阶段决策出第二个版本，需要为这两个函数添加形参以进行区分，进一步得到如下实现：
```c++
template<typename T> T declval (long);
template<typename T, typename U = T&&> U declval (int);
```
这就要求程序员使用的时候传递一个实参来进行调用，通过传递 `int` 类型的 0 来调用：`declval<T>(0)`。对于 `declval<void>(0)` 用例来说没什么影响，真正发生变化的是 `declval<Point>(0)`，在重载决议阶段，由于 0 为 `int` 类型，第一个版本将发生 `int` 到 `long` 的隐式类型转换，而第二个版本类型完全匹配，因此第二个版本最优，最终决策出第二个版本是符合预期的版本。
可以将这两个重载版本封装一下，提供默认参数 0 而无须每次使用时再进行传递，最终实现如下：
```c++
template<typename T, typename U = T&&> U declval_(int); 
template<typename T> T declval_(long);

template<typename T> auto declval () -> decltype (declval_<T>(0)) { 
    static assert(/*...*/);
    return declval_<T>(0); /* 避免编译警告：需要提供返回值 */
}
```
需要注意的是 `declval` 的函数原型必须完整，尤其是返回类型不能只写 `decltype(auto)`，虽然那样编译器也能够推导出类型为 `decltype(declval_<T>(0))`，但也意味着编译器需要看到函数体，而函数体中的静态断言将阻止这个过程，这完全是一种防呆措施，而返回值的作用仅仅是避免编译告警，真正关键的在于函数的原型声明。
### Enable_if
`enable_if` 元函数常出现于 `SFINAE` 场景中，通过对模板函数、模板类中的模板类型进行谓词判断，使得程序能够选择合适的模板函数的重载版本或模板类的特化版本。
`enable_if` 接受两个模板参数，第一个参数为 `bool` 类型的值，当条件为真时，输出的类型成员 `type` 的结果为第二个模板参数，否则没有类型成员 `type`，只提供一个模板参数时，当条件为真，返回第二个模板参数 `void`：
```c++
template<bool, typename=void> // 主模板，第二个默认模板参数为void 
struct enable_if { };

template<typename T>          // 偏特化版本，待确定一个模板参数T 
struct enable_if<true, T> { using type = T; };
```
考虑对数值进行判等操作的场景。如果是整数类型，则直接使用 `==` 操作符进行判断；如果是浮点数类型，则需要考虑精度问题，据此实现模板函数 `numEq`：
```c++
template<typename T, enable_if_t<is_integral_v<T>>* = nullptr> 
bool numEq(T lhs, T rhs) { return lhs == rhs; };//#1

template<typename T, enable_if_t<is_floating_point_v<T>>* = nullptr> 
bool numEq(T lhs, T rhs) { 
    return fabs(lhs - rhs) < numeric_limits<T>::epsilon(); 
};//#2
```
考虑函数调用 `numEq(1, 2)` 应使用哪个重载版本？根据实参的类型可以推导出第一个类型模板参数为 `int`，替换推导后的类型得到如下两个实例：
```c++
bool numEq<int, enable_if_t<is_integral_v<int>>* = nullptr>(int, int); 
bool numEq<int, enable_if_t<is_floating_point_v<int>>* = nullptr>(int,int);
```
`is_integral_v<int>` 的结果为真，因此 `enable_if_t<true>` 的类型将为 `void`，而`is_floating_point_v<int>` 的结果为假，`enable_if<false>` 没有定义成员类型 `type`，导致替换失败，将其从候选集中删除，最终选择第一个重载版本。
## If constexpr
`if constexpr` 是 `C++17` 引入的特性，与普通的 `if` 语句相比，它会在编译时对布尔常量表达式进行评估，并生成对应分支的代码。下述使用 `if constexpr` 特性实现 `numEq` 模板函数对数值类型进行判等操作：
```c++
template<typename T>
auto numEq(T lhs, T rhs) -> enable_if_t<is_arithmetic_v<T>, bool> { 
    if constexpr (is_integral_v<T>) return lhs == rhs; 
    else return fabs(lhs - rhs) < numeric_limits<T>::epsilon(); 
};
```
实现中通过 `is_integral_v` 元函数判断输入类型是否为整数类型，并则直接使用 `==` 进行判等；否则将认为输入类型为浮点类型，判等时需要考虑精度。虽然代码表现出来的是分支结构，但实际上会根据模板参数替换后的类型仅生成对应分支的代码
## Constinit
`constinit` 可用于强制确保在编译时初始化可变静态或全局变量，相当于：
```cpp
constinit = constexpr - const
```
因此 `constinit` 变量不是 `const`，仍然可以修改声明的值。无论何时声明静态或全局变量，都可以使用 `constinit`：
```cpp
constinit auto i = 42;

int getNextClassId() {
    static constinit int maxId = 0;
    return ++maxId;
}

class MyType {
    static constinit long max = sizeof(int) * 1000;
    ...
};
constexpr std::array<int, 5> getColl() {
    return {1, 2, 3, 4, 5};
}
constinit auto globalColl = getColl();
```
使用 `constinit` 的效果是，只有当初始值是编译时已知的常数值时，才会成功编译：
```cpp
auto x = f(); // f() might be a runtime function
constinit auto x = f(); // f() must be a compile-time function

// 若用 constinit 初始化一个对象，必须能够在编译时使用构造函数:
constinit std::pair p{42, "ok"}; // OK
constinit std::list l; // ERROR: default constructor not constexpr
```
使用 `constinit` 的原因：
- 可以确保在编译时初始化可变全局/静态对象，从而避免在运行时进行初始化，并确保全局/静态对象在使用时总是初始化，当使用 `thread_local` 变量时，这可以提高性能。 
- 可以用来修复静态初始化顺序的错误，当一个静态/全局对象的初始值依赖于另一个静态/全局对象时，就会出现这种错误。 
- 使用 `constinit` 永远不会改变程序的功能行为，只能导致代码不可编译。
### Using constinit in Practice
不能用另一个 `constinit` 值初始化一个 `constinit` 值：
```cpp
constinit auto x = f(); // f() must be a compile-time function
constinit auto y = x; // ERROR: x is not a constant initializer

constexpr auto x = f(); // f() must be a compile-time function
constinit auto y = x; // OK
```
原因是初始值必须是编译时已知的常量值，但 `constinit` 不是常量。
初始化对象时，需要编译时构造函数，但编译时析构函数不是必需的。出于这个原因，可以对智能指针使用 `constinit`：
```cpp
constinit std::unique_ptr<int> up; // OK
constinit std::shared_ptr<int> sp; // OK
```
`constinit` 并不意味着内联，这与 `constexpr` 不同。
```cpp
class Type {
    constinit static int val1 = 42; // ERROR
    inline static constinit int val2 = 42; // OK
    ...
};
```
可以和 `extern` 一起使用 `constinit`：
```cpp
// header:
extern constinit int max;
// translation unit:
constinit int max = 42;
```
也可以将 `constinit` 与 `static` 和 `thread_local` 一起使用:
```cpp
static thread_local constinit int numCalls = 0;
```
`constinit`、`static` 和 `thread_local` 的顺序无所谓。对于 `thread_local` 变量，使用 `constinit` 可能会提高性能，因为其可以避免生成的代码需要内部保护来指示变量是否初始化:
```cpp
extern thread_local int x1 = 0;
extern thread_local constinit int x2 = 0; // better (might avoid an internal guard)
```
### Solves the Static Initialization Order Fiasco
静态初始化顺序的问题在于没有定义不同翻译单元中静态和全局初始化的顺序。出于这个原因，下面的代码可能有问题：
```cpp
// 假设有一个带构造函数的类型来初始化对象，并引入该类型的外部全局对象:
#ifndef TRUTH_HPP
#define TRUTH_HPP
struct Truth {
    int value;
    Truth() : value{42} {} // ensure all objects are initialized with 42
};
extern Truth theTruth; // declare global object
#endif // TRUTH_HPP
```
在对象自己的转换单元中初始化该对象：
```cpp
#include "truth.hpp"
Truth theTruth; // define global object (should have value 42)
```
然后在另一个转换单元中，用 `theTruth` 初始化另一个全局/静态对象：
```cpp
#include "truth.hpp"
#include <iostream>
int val = theTruth.value; // may be initialized before theTruth is initialized
int main() {
    std::cout << val << '\n'; // OOPS: may be 0 or 42
    ++val;
    std::cout << val << '\n'; // OOPS: may be 1 or 43
}
```
但很可能 `val` 初始化在 `theTruth` 初始化之前，而当使用 `constinit` 声明 `val` 时，就不会出现这个问题。`constinit` 确保对象总是在使用之前进行初始化，因为初始化是在编译时进行的。若不能给出保证，代码将无法编译。
若 `val` 用 `constexpr` 声明，初始化也会得到保证，但这种情况下，将无法再修改该值。例子中，仅仅使用 `constinit` 首先会导致一个编译时错误，表示在编译时无法保证初始化：
```cpp
// truth.hpp:
struct Truth {
    int value;
    Truth() : value{42} {}
};
extern Truth theTruth;
// main translation unit:
constinit int val = theTruth.value ; // ERROR: no constant initializer
```
该错误消息表明，在编译时不能初始化 `val`。为使初始化有效，必须修改类 `Truth` 和 `theTruth` 的声明，以便 `theTruth` 可以在编译时使用：
```cpp
#ifndef TRUTH_HPP
#define TRUTH_HPP
struct Truth {
    int value;
    constexpr Truth() : value{42} {} // enable compile-time initialization
};
constexpr Truth theTruth; // force compile-time initialization
#endif // TRUTH_HPP
```
现在，编译程序，`val` 可保证用 `theTruth` 的初始值进行初始化：
```cpp
#include "truthc.hpp"
#include <iostream>
constinit int val = theTruth.value ; // initialized after theTruth is initialized
int main() {
    std::cout << val << '\n'; // guaranteed to be 42
    ++val;
    std::cout << val << '\n'; // guaranteed to be 43
}
```
还有其他方法可以解决静态初始化顺序的问题(使用静态函数获取值或使用内联)。然而，若初始化不需要运行时值/特性，则可能需要仔细考虑遵循总是使用 `constinit` 声明全局变量和静态变量的编程风格。在这样的函数中使用，至少没有坏处。
## Consteval
`C++20` 引入 `consteval` 要求进行编译时计算，用 `consteval` 标记的函数不能在运行时调用而是要求在编译时调用。
下述使用 `consteval` 定义函数 `primeNumbers()`，在编译时返回一个包含前 `N` 个素数的数组：
```cpp
constexpr
bool isPrime(int value) {
    for (int i = 2; i <= value/2; ++i) 
        if (value % i == 0) return false;
    return value > 1; // 0 and 1 are not prime numbers
}

template<int Num>
consteval
std::array<int, Num> primeNumbers() {
    std::array<int, Num> primes;
    int idx = 0;
    for (int val = 1; idx < Num; ++val) 
        if (isPrime(val)) primes[idx++] = val;
    return primes;
}
```
为计算素数，`primeNumbers()` 使用一个辅助函数 `isPrime()`，该函数是用 `constexpr` 声明的，在运行时和编译时都可用。然后使用 `primeNumbers<>()` 初始化一个包含 `100` 个素数的数组，因为 `primeNumbers<>()` 是 `consteval`，所以这个初始化必须在编译时进行。
也可以将 `Lambda` 声明为 `consteval`，此时 `Lambda` 只能在具有编译时值的编译时上下文中进行。因此对于下述代码来说，调用只有在接受字符串字面值或 `constexpr const char*` 类型的形参时才有效。 
```cpp
// compile-time function to compute hash value for string literals:
auto hashed = [] (const char* str) consteval {
    std::size_t hash = 5381;
    while (*str != '\0') {
        hash = hash * 33 ^ *str++;
    }
    return hash;
};

// OK (requires hashed() in compile-time context):
enum class drinkHashes : long { beer = hashed("beer"), wine = hashed("wine"),
    water = hashed("water"), ... };
    
// OK (hashed() guaranteed to be called at compile time):
std::array arr{hashed("beer"), hashed("wine"), hashed("water")};
if (argc > 1) {
    switch (hashed(argv[1])) { // ERROR: argv is not known at compile time
    ...
    }
}
```
若使用 `constexpr` 声明 `Lambda`(从 `C++17` 开始，所有的 `Lambda` 都是隐式的 `constexpr`)，则 `switch` 语句也能生效。然而，这样就不能保证在编译时对 `arr` 的初始值进行计算。
### constexpr versus consteval
既不是 `constexpr` 也不是 `consteval`：这些函数只能在运行时上下文中使用，但编译器仍然可以在编译时进行优化。
`constexpr`：这些函数可以在编译时和运行时上下文中使用。若函数的所有方面在编译时已知，可以在编译时上下文中使用其结果，即使在运行时上下文中，编译器仍然可以在编译时对函数求值。 
`consteval`：这些函数只能在编译时使用，但结果可以在运行时上下文中使用。
```cpp
// square() for runtime only:
inline int squareR(int x) {
    return x * x;
}
// square() for compile time and runtime:
constexpr int squareCR(int x) {
    return x * x;
}
// square() for compile time only:
consteval int squareC(int x) {
    return x * x;
}

int i = 42;
// using the square functions at runtime with runtime value:
std::cout << squareR(i) << '\n'; // OK
std::cout << squareCR(i) << '\n'; // OK
// std::cout << squareC(i) << ’’; // ERROR

// using the square functions at runtime with compile-time value:
// consteval 函数必须在编译时执行计算:
std::cout << squareR(42) << '\n'; // OK
std::cout << squareCR(42) << '\n'; // may be computed at compile time or runtime
std::cout << squareC(42) << '\n'; // OK: square computed at compile time

// using the square functions at compile time:
// std::array<int, squareR(42)> arr1; // ERROR
std::array<int, squareCR(42)> arr2; // OK: square computed at compile time
std::array<int, squareC(42)> arr3; // OK: square computed at compile time
// 不允许 consteval 函数处理编译时未知的参数:
// std::array<int, squareC(i)> arr4; // ERROR
```
当想要强制执行编译时计算或禁用运行时使用的的函数时，使用 `consteval` 是有意义的，在编译时上下文中 `constexpr` 还是 `consteval` 并没有区别，但在运行时上下文中，`consteval` 可以强制编译时计算从而不需要运行时求值。
## Using consteval in Practice
`consteval` 函数与 `constexpr` 函数几乎相同，实际使用时有一些限制，`C++20` 放宽为以下限制：
- 参数和返回类型(若不是 `void`)必须是字面量类型类型。
- 函数体只能包含既不是静态，也不是 `thread_local` 的字面量类型的变量。
- 不允许使用 `goto` 和标签。
- 只有当类没有虚基类时，构造函数和析构函数才可以是编译时函数。
- `consteval` 函数隐式内联，不能用作协程。
带有 `consteval` 标记的函数可以调用其他带有 `constexpr` 或 `consteval` 标记的函数：
```cpp
constexpr int funcConstExpr(int i) {
    return i;
}
consteval int funcConstEval(int i) {
    return i;
}
consteval int foo(int i) {
    return funcConstExpr(i) + funcConstEval(i); // OK
}

// 然而，constexpr 函数不能调用 consteval 函数:
consteval int funcConstEval(int i) {
    return i;
}
// i 不是编译时值
// foo() 只能用编译时变量调用 funcConstEval()
constexpr int foo(int i) {
    return funcConstEval(i); // ERROR
    return funcConstEval(42); // OK
}
```
带有 `consteval` 标记的函数也不允许调用纯运行时函数(既不带有 `constexpr`，也不带有 `consteval` 标记的函数)，但只有在真正执行调用时才会检查这一点。对于 `consteval` 函数，只要没有执行到运行时函数，包含调用运行时函数的语句就不是错误(这条规则已经适用于编译时调用的 `constexpr` 函数)。考虑下面的例子：
```cpp
void compileTimeError() {}
consteval int nextTwoDigitValue(int val) {
    if (val < 0 || val >= 99) 
        compileTimeError(); // call something not valid to call at compile time
    return ++val;
}
constexpr int i1 = nextTwoDigitValue(0); // OK (initializes i1 with 1)
constexpr int i2 = nextTwoDigitValue(98); // OK (initializes i2 with 99)
constexpr int i3 = nextTwoDigitValue(99); // compile-time ERROR
constexpr int i4 = nextTwoDigitValue(-1); // compile-time ERROR
```
这个编译时函数只能用于一些值在 0 到 98 之间的参数，通过使用这个技巧将编译时函数约束为某些值，可以在编译时对解析的字符串发出无效格式的信号。
## Is_constant_evaluated()
`C++20` 提供 `std::is_constant_evaluate()`，允许开发者为编译时和运行时计算实现不同的代 码。
```cpp
#include <type_traits>
#include <cstring>
constexpr int len(const char* s)
{
    if (std::is_constant_evaluated()) {
        int idx = 0;
        while (s[idx] != '\0') ++idx; // compile-time friendly code
        return idx;
    }
    else return std::strlen(s); // function called at runtime
}

constexpr int l1 = len("hello"); // uses then branch
int l2 = len("hello"); // uses else branch (no required compile-time context)
```
`len()` 的第一次调用发生在编译时上下文中，`is_constant_evaluate()` 产生 `true`，因此可使用不同的实现。`len()` 的第二次调用发生在运行时上下文中，因此产生 `false` 并调用 `strlen()`。
根据 `C++20` 标准，`std::is_constant_evaluate()` 在以下情况调用时产生 `true`：
- 在常量表达式中
- 在 `if constexpr`、`consteval` 函数或常量初始化等常量上下文中
- 可在编译时使用的变量的初始化器中
```cpp
constexpr bool isConstEval() {
    return std::is_constant_evaluated();
}

bool g1 = isConstEval(); // true
const bool g2 = isConstEval(); // true
static bool g3 = isConstEval(); // true
static int g4 = g1 + isConstEval(); // false

int main()
{
    bool l1 = isConstEval(); // false
    const bool l2 = isConstEval(); // true
    static bool l3 = isConstEval(); // true
    int l4 = g1 + isConstEval(); // false
    const int l5 = g1 + isConstEval(); // false
    static int l6 = g1 + isConstEval(); // false
    int l7 = isConstEval() + isConstEval(); // false
    const auto l8 = isConstEval() + 42 + isConstEval(); // true
}
```
当 `std::is_constant_evaluate()` 与 `constexpr` 和 `consteval` 一起使用时：
```cpp
bool runtimeFunc() {
    return std::is_constant_evaluated(); // always false
}
constexpr bool constexprFunc() {
    return std::is_constant_evaluated(); // may be false or true
}
consteval bool constevalFunc() {
    return std::is_constant_evaluated(); // always true
}

void foo()
{
    bool b1 = runtimeFunc(); // false
    bool b2 = constexprFunc(); // false
    bool b3 = constevalFunc(); // true
    static bool sb1 = runtimeFunc(); // false
    static bool sb2 = constexprFunc(); // true
    static bool ab3 = constevalFunc(); // true
    const bool cb1 = runtimeFunc(); // ERROR
    const bool cb2 = constexprFunc(); // true
    const bool cb3 = constevalFunc(); // true
    int y = 42; // 涉及到运行时值总会导致 false
    static bool sb4 = y + runtimeFunc(); // function yields false
    static bool sb5 = y + constexprFunc(); // function yields false
    static bool ab6 = y + constevalFunc(); // function yields true
    const bool cb4 = y + runtimeFunc(); // function yields false
    const bool cb5 = y + constexprFunc(); // function yields false
    const bool cb6 = y + constevalFunc(); // function yields true
}
```
通常，在以下情况使用 `std::is_constant_evaluate()` 没有意义。
作为编译时 `if` 的条件或 `consteval` 函数，总是产生 `true`：
```cpp
if constexpr (std::is_constant_evaluated()) {...} // always true
consteval void foo() {
    if (std::is_constant_evaluated()) { ... }// always true
}
```
纯运行时函数中，这通常会产生 `false`。唯一的例外是用于局部常量求值：
```cpp
void foo() {
    if (std::is_constant_evaluated()) { // always false
        ...
    }
    const bool b = std::is_constant_evaluated(); // true
}
```
使用 `std::is_constant_evaluate()` 通常只在 `constexpr` 函数中有意义，但在 `constexpr` 函数中使用 `std::is_constant_evaluate()` 来调用 `consteval` 函数也是没有意义的，通常不允许从 `constexpr` 函数调用 `consteval` 函数：
```cpp
consteval int funcConstEval(int i) {
    return i;
}

constexpr int foo(int i) {
    if (std::is_constant_evaluated()) {
        return funcConstEval(i); // ERROR
    }
    else return funcRuntime(i);
}
```
`C++20` 标准中，有一个有趣的例子来说明如何使用 `std::is_constant_evaluate()`：
```cpp
int sz = 10;
constexpr bool sz1 = std::is_constant_evaluated() ? 20 : sz; // true, so 20
constexpr bool sz2 = std::is_constant_evaluated() ? sz : 20; // false, so ERROR
```
`sz1` 和 `sz2` 的初始化要么是静态初始化，要么是动态初始化。对于静态初始化，初始化项必须是常量，所以编译器尝试用 `std::is_constant_evaluate()` 的结果 `true` 常量来计算初始化式。
对于 `sz1`，这是成功的。结果是 1，这是一个常数，所以 `sz1` 是一个用 20 初始化的常数。
对于 `sz2`，结果是 `sz`，不是常数。因此，`sz2`(理论上)是动态初始化的，先前的结果将丢弃，并使用 `std::is_constant_evaluate()` 对初始化器进行计算，结果反而产生 `false`，则初始化 `sz2` 的表达式也是 20。 但 `sz2` 不一定是常量，因为 `std::is_constant_evaluate()` 在此求值期间不一定是常量表达式，所以用这个 `20` 初始化 `sz2` 不能编译。 
使用 `const` 而不是 `constexpr` 会使情况更加棘手：
```cpp
int sz = 10;
const bool sz1 = std::is_constant_evaluated() ? 20 : sz; // true, so 20
const bool sz2 = std::is_constant_evaluated() ? sz : 20; // false, so also 20
double arr1[sz1]; // OK
double arr2[sz2]; // may or may not compile
```
只有 `sz1` 是编译时常数，并且总是可以用来初始化数组，`sz2` 也可初始化为 20。但由于初始值不一定是常量，因此 `arr2` 的初始化可能会编译，也可能不会编译(取决于所使用的编译器和优化)。
## Using Heap Memory, Vectors, and Strings at Compile Time
`C++20` 开始，编译时函数可以分配内存，前提是这些内存在编译时也释放。由于这个原因，现在可以在编译时使用字符串或 `vector`，但有一个重要的限制: 在编译时创建的字符串或 `vector` 不能在运行时使用，原因是在编译时分配的内存也必须在编译时释放。
### Using Vectors at Compile Time
下述用 `constexpr` 定义 `modifiedAvg()`，只返回编译时 `vector` 下计算出来的值，由于 `avg` 是用 `constexpr` 声明的，所以 `modiedavg()` 在编译时求值：
```cpp
template<std::ranges::input_range T>
constexpr auto modifiedAvg(const T& rg)
{
    using elemType = std::ranges::range_value_t<T>;
    // initialize compile-time vector with passed elements:
    std::vector<elemType> v{std::ranges::begin(rg), std::ranges::end(rg)};
    // perform several modifications:
    v.push_back(elemType{});
    std::ranges::sort(v);
    auto newEnd = std::unique(v.begin(), v.end());
    ...
    // return average of modified vector:
    auto sum = std::accumulate(v.begin(), newEnd, elemType{});
    return sum / static_cast<double>(v.size());
}

int main() {
    constexpr std::array orig{0, 8, 15, 132, 4, 77};
    constexpr auto avg = modifiedAvg(orig);
    std::cout << "average: " << avg << '\n';
}
```
也可以用 `consteval` 定义 `modifiedAvg()`，此时不会在运行时复制元素，所以可以按值传递参数，然而，如果 `vector` 在运行时使用，则仍然不能在编译时声明和初始化：
```cpp
template<std::ranges::input_range T>
consteval auto modifiedAvg(T rg) {
    using elemType = std::ranges::range_value_t<T>;
    // initialize compile-time vector with passed elements:
    std::vector<elemType> v{std::ranges::begin(rg),
    std::ranges::end(rg)};
    ...
}

int main() {
    constexpr std::vector orig{0, 8, 15, 132, 4, 77}; // ERROR
    ...
}
```
出于同样的原因，编译时函数只能在编译时使用返回值时返回一个 `vector`，不可用在运行时：
```cpp
constexpr auto returnVector() {
    std::vector<int> v{0, 8, 15};
    v.push_back(42);
    ...
    return v;
}

constexpr auto returnVectorSize()
{
    auto coll = returnVector();
    return coll.size();
}

int main()
{
    // constexpr auto coll = returnVector(); // ERROR
    constexpr auto tmp = returnVectorSize(); // OK
    ...
}
```
### Returning a Collection at Compile Time
虽然返回的编译时的 `vector` 不能在运行时使用，但可以使用 `std::array<>` 返回编译时计算的元素集合，唯一的问题是需要知道数组的大小：
```cpp
std::vector v;
...
std::array<int, v.size()> arr; // ERROR
```
但这样的代码永远不会编译，因为 `size()` 是一个运行时值，而 `arr` 的声明需要一个编译时值。若在编译时不知道数组的结果大小，则必须声明具有最大大小的返回数组，并返回结果大小：
```cpp
template<std::ranges::input_range T>
consteval auto mergeValuesSz(T rg, auto... vals)
{
    // create compile-time vector from passed range:
    std::vector<std::ranges::range_value_t<T>> v{std::ranges::begin(rg), std::ranges::end(rg)};
    (... , v.push_back(vals)); // merge all passed parameters
    std::ranges::sort(v); // sort all elements
    // return extended collection as array and its size:
    constexpr auto maxSz = std::ranges::size(rg) + sizeof...(vals);
    // 用 {} 声明 arr，以确保数组中的所有值都初始化，编译时函数不允许产生未初始化的内存
    std::array<std::ranges::range_value_t<T>, maxSz> arr{};
    // 删除排序后的连续重复项
    auto res = std::ranges::unique_copy(v, arr.begin());
    return std::pair{arr, res.out - arr.begin()}; // 返回数组和结果元素的数量
}

int main()
{
    // compile-time initialization of array:
    constexpr std::array orig{0, 8, 15, 132, 4, 77, 3};
    // initialization of sorted extended array:
    auto tmp = mergeValuesSz(orig, 42, 4);
    auto merged = std::views::counted(tmp.first.begin(), tmp.second);
    // print elements:
    for(const auto& i : merged) 
        std::cout << i << ' ';
}
```
上述在 `consteval` 函数中使用 `vector` 将传入的可变数量的实参与传入范围的元素合并，并对其全排 序，最后可将结果集合作为 `std::array` 返回，以便将其传递给运行时上下文。
### Using Strings at Compile Time
对于编译时字符串，现在所有的操作都是 `constexpr`，所以现在可以在编译时使用 `std::string`，也可以使用其他字符串类型，但这也有一个限制，即不能在运行时使用编译时字符串。
```cpp
consteval std::string returnString()
{
    std::string s = "Some string from compile time";
    ...
    return s;
}
void useString()
{
    constexpr auto s = returnString(); // ERROR
    ...
}
constexpr void useStringInConstexpr()
{
    std::string s = returnString(); // ERROR
    ...
}
consteval void useStringInConsteval()
{
    std::string s = returnString(); // OK
    ...
}
```
不能通过使用 `data()` 或 `c_str()` 或 `std::string_view` 返回编译时字符串来解决这个问题，这样做将返回在编译时分配的内存地址。若发生这种情况，编译器会引发编译时错误。 
然而，可以使用与上面描述的 `vector` 相同的技巧，将 `string` 对象转换为固定大小的数组，并返回数组和大小：
```cpp
// function template to export a compile-time string to runtime:
// 字符串转换为 std::array<>，并返回该数组和字符串的大小
template<int MaxSize>
consteval auto toRuntimeString(std::string s)
{
    // ensure the size of the exported array is large enough:
    assert(s.size() <= MaxSize);
    // create a compile-time array and copy all characters into it:
    std::array<char, MaxSize+1> arr{}; // ensure all elems are initialized
    for (int i = 0; i < s.size(); ++i) arr[i] = s[i];
    // return the compile-time array and the string size:
    return std::pair{arr, s.size()};
}

// function to import an exported compile-time string at runtime:
// 接受返回的数组和大小，初始化运行时字符串并返回
std::string fromComptimeString(const auto& dataAndSize)
{
    // init string with exported array of chars and size:
    return std::string{dataAndSize.first.data(), dataAndSize.second};
}

// test the functions:
consteval auto comptimeMaxStr()
{
    std::string s = "max int is " + asString(std::numeric_limits<int>::max())
    + " (" + asString(std::numeric_limits<int>::digits + 1)
    + " bits)";
    return toRuntimeString<100>(s);
}

std::string s = fromComptimeString(comptimeMaxStr());
std::cout << s << '\n';
```





