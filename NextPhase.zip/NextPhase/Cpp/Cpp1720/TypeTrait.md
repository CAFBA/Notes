# Type Trait
## Type Trait
C++通过模板来实现泛型编程，从而减轻运行时绑定开销，C++11的标准库提供了<type_traits>定义一些编译时基于模板类的接口用于查询、修改类型的特征：输入的是类型，输出与该类型相关的特征（属性）。
考虑这么一个场景，给定任意类型T，它可能是bool类型、int类型、string类型或者任何自定义的类型，通过type traits技术编译器可以回答一系列问题：它是否为数值类型？是否为函数对象？是不是指针？有没有构造函数？能不能通过拷贝构造？等等。
通过这些信息就能够提供更具针对性的实现，让编译器在众多选择中决策出最佳的实现。除此之外，type traits技术还能对类型进行变换，比如给定任意类型T，能为这个类型添加const修饰符、添加引用或者指针等。而这一切都发生在编译时，过程没有任何运行时开销。
trait也被称为元函数，因为它能够在编译时计算，输入类型或常量，输出对应的结果。
### Type Trait Predicate
标准库里提供的type traits谓词命名是以is_为前缀，通过访问静态成员常量value得到输出结果。
考虑如下代码，对各种类型进行布尔判断：
```c++
static assert(std::is_integral<int>::value); // true 
static assert(!std::is_integral<float>::value); // false 
static assert(std::is_floating_point<double>: :value); // true 
static assert(std::is_class<struct Point>::value); // true 
static assert(!std::is_same<int, long>::value);// false
```
is_integral用来判断给定的类型是否为整数类型，例如char、short、int、long等都是整数类型，使用尖括号将类型输入给这个trait，通过其成员value来输出一个bool类型的结果，对于int来说结果为真，而float为浮点类型，输出结果为假。
is_floating_point用来判断给定的类型是否为浮点类型，常见的float、double都为浮点类型，因此输入double的结果为真。is_class用来判断给定的类型是否为struct、class定义的类型，对于前向声明一个struct Point结构体而言，结果为真。
is_same用来判断给定的两个类型是否为相同类型，对于输入int和long类型而言，输出结果为假，这个type traits相当有用，尤其是在进行模板元编程时，配合静态断言static_assert来测试输出的类型是否符合预期。
这可以应用于针对整数类型的弹性重载，假设有一个函数foo，对于整数类型和浮点数类型的实参，它该有不同的实现。通常做法是将它重载，使它拥有针对整数类型和“针对浮点数类型两个版本：
```c++
void foo (short);
void foo (int);

void foo (float);
void foo (double);

// 有了type trait后，你可以这么改写：
template <typename T>
void foo_impl (T val, true_type); //provide integral version template <typename T>
void foo_impl (T val, false_type); //provide floating-point version template <typename T>
// 只需提供两份实现，一份针对整数，一份针对浮点数，然后根据 std::is_integral<T>() 导出结果选择正确的实现版本
void foo (T val) {
    foo_impl (val, std::is_integral<T>()); 
}
```
### Variable Template
定义变量模板与定义普通变量的方式很相似，唯一不同的是定义变量模板可以带上模板参数。变量模板可以进行编译时表达式计算，考虑如下代码：
```c++
template<char c> constexpr bool is_digit = (C>='0'&&c<='9'); 
static assert(!is_digit<'x'>); // x不为数字字符
static assert(!is_digit<'0'>); // 0为数字字符
```
is_digit需要接受一个char类型的模板参数，当用户传递模板实参'x'时，输出的结果为布尔表达式的结果，即is_digit<'x'>为假，同理is_digit<'0'>为真。C＋＋的模板参数可以为类型与非类型的：对于模板参数为类型的情况，需要使用typename来声明；若为非类型，则需要指明具体的类型，例如这里的char，C＋＋17的非类型模板参数也可以写成auto。
变量模板与类型别名不一样的地方在于支持特化。首先，定义一个基本变量模板fibonacci，它接受一个size_t类型的非类型模板参数作为输入，返回类型也是size_t，根据定义，结果为前两项之和。接下来两个定义为全特化，当N分别取值为0或1时，结果分别为0或1。最后一个断言进行测试，当N为10时，结果应该为55。从模板支持特化的角度而言，这也是一种编译时多态，根据不同的模板实参选择不同的分支处理：
```c++
template<size_t N> constexpr size_t fibonacci = fibonacci<N-1> + fibonacci<N-2>; 
template<> constexpr size_t fibonacci<0> = 0;
template<> constexpr size_t fibonacci<1> = 1; 
static assert(fibonacci<10> == 55);
```
### Type onversion
标准库中有些type traits拥有修改类型的能力：基于已有类型应用修改得到新的类型，输出类型可以通过访问type类型成员得到结果。值得注意的是类型修改不会原地修改输入的类型，而是产生新的类型以应用这些修改。
![image-20230224191053675](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230224191053675.png)
> add_pointer为输入的类型添加一级指针，因此输入二级指针类型int∗∗后输出类型将为三级指针类型int∗∗∗。
> 一个指向const类型的非常量pointer或reference，并不是一个常量。
```c++
typedef const int& T;
add_const<T>::type;//const int& 
add_lvalue_reference<T>::type;   //const int& 
add_pointer<T>::type;            //const int*   add_pointer<> 必然包含使用remove_reference<>

make_signed<T>::type;			 //undefined behavior 
make_unsigned<T>::type;			 //undefined behavior 

remove_const<T>::type;			 //const int& 
remove_reference<T>::type;		 //const int 
remove_pointer<T>::type;		 //const int& 
```
make_signed<>和 make_unsigned<> 要求实参若非整数型就必须是枚举型，bool除外，所以如果传入reference会导致不明确行为。
注意，add_lvalue_reference<> 把一个 rvalue reference 转换为一个 lvalue reference，然而 add_rvalue_reference<> 并不把一个lvalue reference 转换为一个 rvalue reference（类型保持不变）。因此，必须这么做才能将一个 lvalue 转换为一个rvalue reference：
```c++
add_rvalue_reference<T>::type;   //const int&(yes, lvalue remains lvalue) 
add_rvalue_reference<remove_reference<T>::type>::type 
```
decay语义为类型退化，通过模拟函数或值语义传递时，会使所有应用到的函数参数类型退化。由于decay语义为值语义，输入类型若为引用类型那么会将引用去掉，输入int&则输出为int。数组类型之所以能够传递给一个接受指针类型的函数，是因为在这个过程中数组类型发生了退化，变成了指针类型。
考虑一个稍微复杂的场景，二维数组类型`int[5][6]`退化后的类型会如何？通过`decay<int[5][6]>::type`计算得知结果为数组指针类型`int(*)[6]`，而不是二级指针`int**`，这也是数组与指针的差别：它们本质上是不同的。除了数组类型能退化成指针外，函数类型也能退化成函数指针，例如函数类型`int(int)`退化后的类型为`int(*)(int)`。
### Helper classes
标准库<type_traits>预定义了一些常用的辅助类，方便实现其他的type traits。辅助类integral_constant将值与对应的类型包裹起来，从而能够将值转换成类型，也能从类型转换回值，实现值与类型之间的一一映射关系。
integral_constant类型实现：若其输入一个类型与对应的值，根据标准库的约定，值用静态成员常量value存储。
```c++
template<typename T, T v> 
struct integral_constant {
    using type = integral_constant<T, v>; 
    using value_type = T; //存储值的类型
    static constexpr T value = v; // 可以通过value从类型取回值 
    constexpr operator value_type() { 
        return value;
    } 
};
```
考虑如下代码：
```c++
using Two = std::integral_constant<int, 2>; 
using Four = std::integral_constant<int, 4>;
static_assert(Two::value * Two::value == Four::value );
```
Two和Four为两个类型，分别对应于数值2与4，使用integral_constant将值转换成类型后，进一步通过value静态成员常量从类型中得到值并进行计算。
考虑到标准库中有很多谓词traits，其结果都是一个布尔类型，因此标准库对于布尔类型也提供了辅助类bool_constant，实现时仅仅是integral_constant的类型别名：
```c++
template<bool v> using bool_constant = integral_constant<bool, v>;
```
由于布尔类型只有真假两个值，很容易将这两个值映射成类型：
```c++
using true_type = integral_constant<bool, true>;
using false_type = integral_constant<bool, false>;
```
### common_type
共通类型是一个可以用来对付两个不同类型的值的类型，前提是的确存在这么一个共通类型。举个例子，不同类型的两个值的总和或最小值，就该使用这个所谓的共通类型。否则，如果想实现一个函数，判断不同类型的两值中的最小值，其返回类型该是什么呢？
```c++
template <typename T1,typename T2>
??? min(const T1& x,const T2& y);

// 使用 std::common_type 就可以解决问题：
template <typename T1, typename T2>
typename std::common_type<T1, T2>::type min (const T1& x,const T2& y);

// 如果两个实参都是int或都是long，或一个是int另一个是long，则会产出int
// 如果实参之一是string而另一个是字符串字面常量，产出结果是string
// common＿type是这么实现的：
template <typename T1,typename T2> 
struct common_type<T1, T2> {
    // declval<> 则是个辅助性trait，依据传入的类型提供一个值，但不去核算它（也就是为该值产生一个rvalue reference）。
    typedef decltype(true ? declval<T1>() : declval<T2>()) type; 
};
```
### Implement Of Type Trait
#### is_floating_point
is_floating_point判断给定的类型是否为浮点类型，我们首先定义一个基本的模板类，令其默认返回为假，然后枚举出一些有限的浮点类型并返回为真：
```c++
template<typename T> 
struct is_floating_point: false_type {};
```
这里使用上一节的布尔类型false_type，其拥有一个静态成员常量value且始终为false，根据定义它是一个空类，使用继承方式不仅能达到空基类优化的效果，而且能得到约定的返回结果value。接下来是枚举一些浮点类型，令它们返回为真：
```c++
template<> struct is_floating point<float> : true_type {}; 
template<> struct is floating point<double> : true_type {};
template<> struct is floating point<long double> : true_type {};
```
通过模板类的全特化方式，针对float、double、long double类型分别特化出三个版本，当用户输入的是浮点类型时将实例化特化版本，从而得到预期结果
#### is_same
is_same判断给定的两个类型是否相同，首先给出基本的版本，默认返回假。再通过模板类的偏特化方式，只给出一个模板参数，确保这两个模板参数一致：
```c++
template<typename T, typename U> // 主模板，输入两个类型参数 
struct is_same : false type {};
template<typename T> // 偏特化版本，待确定一个参数 
struct is_same<T, T> : true_type {};
```
采用全特化方式时，需要指明所有确定的模板参数，模板头使用template<>表明没有待确定的参数。而对于判断两个类型是否相同的情况，只要确定其中任意一个类型，让第二个类型为第一个类型即可。因此通过偏特化指明一个待确定的模板参数，模板头使用`template<typename T>`表明待确定一个参数，然后模板名`is_same<T, T>`要求和主模板输入的格式一致：接受两个模板参数，这样就能实现判断两个类型是否相等。
#### remove_const
remove_const将输入的类型移除掉const修饰符，定义一个主模板对输入的任意类型都会返回该类型[插图]，再通过特化方式处理带const修饰的类型。由于输入输出都是类型，根据约定使用type成员类型存储输出的结果：
```c++
template<typename T> // 主模板，输入一个类型参数
struct remove_const {using type = T;};
template<typename T> // 偏特化版本，待确定一个参数 
struct remove_const<const T> { using type = T; };
```
特化版本匹配类型const T，最终输出类型T，从而将const修饰去掉。
#### conditional
std::conditional类似于三元条件操作符，它接受三个模板参数，第一个参数为bool类型的值，当其为真时输出的是第二个类型模板参数，否则输出的是第三个类型模板参数。例如conditional_t<true,int, float>的类型为int，而conditional_-t<false, int, float>的类型为float。
同样存在分支判断，首先定义主模板默认输出第一个类型模板参数，同时定义偏特化版本，当第一个bool类型参数的值为假时，输出第二个模板参数：
```c++
template<bool v, typename Then, typename Else> // 主模板，输入三个模板参数 
struct conditional { using type = Then; };
template<typename Then, typename Else> // 偏特化版本，待确定两个类型参数 
struct conditional<false, Then, Else> { using type = Else; };
```
有了conditional元函数后，就能实现稍微复杂一点的type traits了，考虑decay元函数实现会使类型退化，故首先将类型的引用去掉，然后进一步判断：
- 若类型为数组类型，则退化掉一维成指针类型。
- 否则，若类型为函数类型，则退化成函数指针类型。
- 否则，去除类型的cv修饰符
```c++
template<typename T>
class decay {
using U = std::remove_reference_t<T>;         // 首先将类型的引用去掉，存储至临时类型U
using type = conditional_t<is_array_v<U>,     // 若为数组类型
            remove_extent_t<U>*,              // 则退化掉一维，变成指针类型
            conditional_t<is_function_v<U>,   // 否则，若为函数类型
            add_pointer_t<U>,                 // 则退化成函数指针
            remove_cv_t<U> > >;               // 否则，去除类型的cv修饰
};
```