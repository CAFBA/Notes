# Concept
`C++20` 之前约束模板的方法见 [[Compile-Time Computing#Constraining Templates]]
`C++20` 引入概念用来约束类模板和函数模板的类型和非类型参数的命名要求。这些是作为谓词编写的，在编译期计算这些谓词，以验证传递给模板的模板参数。概念的主要目标是使与模板相关的编译器错误更具有可读性。每个人都遇到过这样的情况：当为类或函数模板提供了错误的参数时，编译器会抛出数百行的错误信息。但要找出那些编译器错误的根本原因并不总是那么容易。 
概念允许编译器在不满足某些类型约束时输出可读的错误消息。因此，为了得到有意义的语义错误，建议编写代码时使用概念来建模语义需求。避免只验证没有任何语义意义的语法方面的概念，例如只检查类型是否支持 `operator+` 的概念，这样的概念将在只检查语法，而不是语义。`string` 支持`operator+`，但很明显，它与整数的 `operator+` 具有完全不同的含义。
## Concept
概念是一个模板，为模板参数的一个或多个需求引入名称，以便可以将这些需求用作约束。概念定义的泛型语法如下：
```cpp
template <parameter-list>
concept concept-name = constraints-expression;
```
与类模板和函数模板不同，概念从不会被实例化。`concept` 是关键字，`concept-name` 可以是任意的，`constraints-expression` 可以是任意的常量表达式(即，可以在编译期计算的任何表达式)。
概念表达式 `concept-name<argument-list>` 的是布尔编译时表达式，计算结果为真或假，若真则表示使用给定的模板实参为概念建模：
```cpp
// 类型特征是在 C++11 中作为标准类型函数引入的，C++17 中引入以 _v 后缀的使用方式
// 因此 std::is_pointer_v<> 是标准类型特征 std::is_pointer<> 的值成员)
template <typename T>
concept IsPointer = std::is_pointer_v;

template<typename T>
requires (!IsPointer<T>)
T maxValue(T a, T b) {
    return b < a ? a : b;
}
```
约束是在 `requires` 子句中表述，通过关键字 `requires` 引入的 (还有其他方式可用来表述约束)。
可以使用 `require` 子句或概念来约束几乎所有形式的泛型代码：函数/类/变量/别名模板/成员函数，但不能约束概念：
```cpp
template<std::ranges::sized_range T> // ERROR
concept IsIntegralValType = std::integral<std::ranges::range_value_t<T>>;
// you have to specify this as follows:
template<typename T>
concept IsIntegralValType = std::ranges::sized_range<T> &&
std::integral<std::ranges::range_value_t<T>>;
```
### Trailing Requires Clauses
对于指针化的版本还有一个隐含要求，解引用之后，值必须可比较。为了让指针版本在声明中直接要求指针所指向的值必须具有可比性，可以在函数中添加另一个约束:
```cpp
auto maxValue(IsPointer auto a, IsPointer auto b)
requires IsComparableWith<decltype(*a), decltype(*b)>
{
    return maxValue(*a, *b);
}
```
使用 `requires` 子句，可以在参数列表之后指定，这样就可以使用一个参数的名称，甚至可以组合多个参数名称来制定约束。
### Requires Expressions
`maxValue()` 模板不适用于像智能指针那样的非原始指针的类指针类型，若代码也要为这些类型编译，可以将指针定义为可以调用解引用操作符的对象。
```cpp
template<typename T>
concept IsPointer = requires(T p) {
    *p; // operator * has to be valid
    p == nullptr; // can compare with nullptr
    {p < p} -> std::same_as<bool>; // operator < yields bool
};
```
使用 `requires` 关键字来引入 `requires` 表达式，其可以定义类型和参数的一个或多个需求，此处的指定三个要求，都适用于定义这个概念的类型 T：
- 表达式 `*p` 必须对类型 `T` 的对象 `p` 有效，即该类型必须支持解引用操作符。 
- 该类型的对象必须可以与 `nullptr` 比较。 这里不要求 `p` 是一个等于 nullptr 的指针，只要求可以将 `p` 与 `nullptr` 进行比较，排除不能与 nullptr 进行比较的迭代器。 
- 该类型必须支持小于操作符，该操作符必须产生 `bool` 类型。不需要两个 `T` 类型的形参来检查是否可以调用小于操作符，但对于如何指定表达式产生的结果有一些限制，不能只指定 `bool` 而不指定 `std::same_as<>`。 
这是一个编译时约束，对生成的代码没有影响，只决定代码编译哪种类型，所以将形参 `p` 声明为值还是引用就无关紧要，也可以直接在 `requires` 子句中使用 `requires` 表达式作为临时约束：
```cpp
template<typename T>
requires requires(T p) { *p; } // constrain template with ad-hoc requirement
auto maxValue(T a, T b)
{
    return maxValue(*a, *b);
}
```
### Constraining Alias Templates
```cpp
// 下面是一个约束别名模板的例子:
template<std::ranges::range T>
using ValueType = std::ranges::range_value_t<T>;
// 该声明等价于:
template<typename T>
requires std::ranges::range<T>
using ValueType = std::ranges::range_value_t<T>;
// 类型 ValueType<> 现在只可对范围类型进行定义:
ValueType<int> vt1; // ERROR
ValueType<std::vector<int>> vt2; // int
ValueType<std::list<double>> vt3; // double
```
### Constraining Variable Templates
```cpp
// 下面是一个约束变量模板的例子:
template<std::ranges::range T>
constexpr bool IsIntegralValType = std::integral<std::ranges::range_value_t<T>>;
// 该声明等价于:
template<typename T>
requires std::ranges::range<T>
constexpr bool IsIntegralValType = std::integral<std::ranges::range_value_t<T>>;
// 类型 IsIntegralValType<> 现在只可在范围中定义:
bool b1 = IsIntegralValType<int>; // ERROR
bool b2 = IsIntegralValType<std::vector<int>>; // true
bool b3 = IsIntegralValType<std::list<double>>; // false
```
### Constraining Member Functions
`requires` 子句也可以是成员函数声明的一部分，开发者就可以根据需求和概念指定不同的 `API`。下述定义一个类 `ValOrColl`，可以保存一个值或一个值的集合，作为 `T` 类型的值。提供两个 `print()`成员函数，类使用标准概念 `std::ranges::range` 来决定使用哪一个: 
- 若类型 T 是一个集合，则满足约束，所以两个 `print()` 成员函数都可用。但重载解析首选第二个 `print()`，因为该成员函数有约束，将遍历集合的元素。
- 若类型 `T` 不是集合，则只有第一个 `print()` 可用。
```cpp
template<typename T>
class ValOrColl {
    T value;
public:
    ValOrColl(const T& val): value{val} {}
    ValOrColl(T&& val): value{std::move(val)} {}
    void print() const {
        std::cout << value << '\n';
    }
    void print() const requires std::ranges::range<T> {
        for (const auto& elem : value) 
            std::cout << elem << ' ';
        std::cout << '\n';
    }
};

ValOrColl o1 = 42;
o1.print();
ValOrColl o2 = std::vector{1, 2, 3, 4};
o2.print();
```
这种方式只能约束模板，不能使用 `requires` 来约束普通函数：
```cpp
void foo() requires std::numeric_limits<char>::is_signed {...} // ERROR
```
### Constraining Non-Type Template Parameters
可以约束的不仅仅是类型，还可以约束非类型模板参数 `NTTP`。例如:
```cpp
template<int Val>
concept LessThan10 = Val < 10;

// more generic:
template<auto Val>
concept LessThan10 = Val < 10;

// This concept can be used as follows:
template<typename T, int Size>
requires LessThan10<Size>
class MyType {
    ...
};
```
## Typical Applications of Concepts and Constraints in Practice
### Overload
通过使用约束和概念，可以重载 `maxValue()` 模板，为指针和其他类型分别提供实现：
```cpp
template<typename T>
requires (!IsPointer<T>)
T maxValue(T a, T b) // maxValue() for non-pointers
{
    return b < a ? a : b; // compare values
}

// 仅用一个概念 (或多个概念与 && 组合) 约束模板的 requires 子句不再需要括号
// 否定的概念总是需要括号
template<typename T>
requires IsPointer<T>
auto maxValue(T a, T b) // maxValue() for pointers
{
    return maxValue(*a, *b); // compare values the pointers point to
}

int x = 42;
int y = 77;
std::cout << maxValue(x, y) << '\n'; // calls maxValue() for non-pointers
std::cout << maxValue(&x, &y) << '\n'; // calls maxValue() for pointers

int* xp = &x;
int* yp = &y;
std::cout << maxValue(&xp, &yp) << '\n'; // calls maxValue() for int**
```
此外，重载解析认为有约束的模板比没有约束的模板更特化，因此可以只约束对指针的实现：
```cpp
template<typename T>
T maxValue(T a, T b) // maxValue() for a value of type T
{
    return b < a ? a : b; // compare values
}

template<typename T>
requires IsPointer<T>
auto maxValue(T a, T b) // maxValue() for pointers (higher priority)
{
    return maxValue(*a, *b); // compare values the pointers point to
}

// 若约束是应用于模板参数的单个概念，则可以在声明模板形参时，直接将其指定为类型约束：
template<IsPointer T> // only for pointers
auto maxValue(T a, T b) {    
    return maxValue(*a, *b); // compare values the pointers point to
}
```
需要注意的是，如果直接约束两个形参，会导致模板规范改变: 不再要求必须具有相同的类型，只要求两者都是指针：
```cpp
// 使用 auto 声明参数时，可以将概念用作类型约束:
auto maxValue(IsPointer auto a, IsPointer auto b) { 
    return maxValue(*a, *b); // compare values the pointers point to 
} //  不再要求 a 和 b 具有相同的类型

// 这也适用于通过引用传递的参数:
auto maxValue3(const IsPointer auto& a, const IsPointer auto& b)
{
    return maxValue(*a, *b); // compare values the pointers point to
}

// 上述等价于
template<IsPointer T1, IsPointer T2> // only for pointers
auto maxValue(T1 a, T2 b)
{
    return maxValue(*a, *b); // compare values the pointers point to
}
```
但在函数实现中会调用非指针类型的实现，因此还应该定义使用不同类型的非指针类型函数模板：
```cpp
// One way to do that is to specify two template parameters:
template<typename T1, typename T2>
auto maxValue(T1 a, T2 b) // maxValue() for values
{
    return b < a ? a : b; // compare values
}

// The other option would be to also use auto parameters:
auto maxValue(auto a, auto b) // maxValue() for values
{
    return b < a ? a : b; // compare values
}
```
对于下述 `add` 函数，若为浮点类型提供特殊实现，则不需要用特定类型声明第二个形参，只需要求要插入的值为浮点类型，可以使用新的标准概念 `std::floating_point` 来约束浮点值的函数模板。
```cpp
template<typename Coll, typename T>
void add(Coll& coll, const T& val) // for generic value types
{
    coll.push_back(val);
}

template<typename Coll, typename T>
requires std::floating_point<T>
void add(Coll& coll, const T& val)
{
    ... // special code for floating-point values
    coll.push_back(val);
}

// 使用的概念只适用于单个模板形参
template<typename Coll, std::floating_point T>
void add(Coll& coll, const T& val)
{
    ... // special code for floating-point values
    coll.push_back(val);
}

void add(auto& coll, const std::floating_point auto& val)
{
    ... // special code for floating-point values
    coll.push_back(val);
}
```
重载解析有一些通用规则：
- 调用普通函数优于调用函数模板。
- 没有类型转换的调用优先于具有类型转换的调用，在调用类型转换和调用函数模板之间做出决定时优先选择带有模板参数的版本。
- 有约束的重载或特化优于约束较少或没有约束的重载或特化
但重载函数的签名差异太大，可能不适用更受约束的重载。例如，上述声明浮点值的重载以按值接受实参， 则传递浮点值会产生二义性：
```cpp
template<typename Coll, typename T>
void add(Coll& coll, const T& val) // note: pass by const reference
{
    coll.push_back(val);
}
template<typename Coll, std::floating_point T>
void add(Coll& coll, T val) // note: pass by value
{
    ... // special code for floating-point values
    coll.push_back(val);
}

std::vector<double> dVec;
add(dVec, 0.7); // ERROR: both templates match and no preference
```
### Restrictions on Narrowing
上述函数模板都允许传递一个 `double` 类型的值，将其添加到 `int` 类型的集合中，若不希望数据窄化，有多个选项。一种选择是通过要求传递的值类型与集合的元素类型匹配， 完全禁用类型转换:
```cpp
std::vector<int> iVec;
add(iVec, 1.9); // OOPS: add 1

requires std::same_as<typename Coll::value_type, T>
```
但这也会禁用有用和安全的类型转换。出于这个原因，最好定义一个概念来确定一个类型是否可以在不缩小的情况下转换为另一个类型：
```cpp
template<typename From, typename To>
concept ConvertsWithoutNarrowing = std::convertible_to<From, To> &&
    requires (From&& x) {
        // 内部的 {} 是初始化语法
        { std::type_identity_t<To[]>{ std::forward<From>(x) } }
        -> std::same_as<To[1]>;
    };

template<typename Coll, typename T>
requires ConvertsWithoutNarrowing<T, typename Coll::value_type>
void add(Coll& coll, const T& val) {...}
```
`std::is_convertible_v` 是一个变量模板，当 `From` 可以隐式转换为 `To` 时，它会返回` true`，否则返回 `false`。
`std::type_identity_t` 是一个类型特征，它返回其模板参数的类型，因此此处用于获取 `To` 类型的数组类型，其唯一的元素是通过转发的 `x`，`std::forward<From>(x)` 确保转换后的数组元素与原始的 `x` 具有相同的值类别，从而避免不必要的拷贝或移动操作。
因此上述约束表达式要求转换后的类型要求 `From` 类型的值可以转换为一个 `To` 类型的数组，并且这个数组只有一个元素。这个数组的创建是为检查转换是否会导致数据丢失，如果转换导致数据丢失，那么 `To[1]` 和 `To[1]` 之间的 `std::same_as` 约束将无法满足，从而导致编译错误。这样，通过检查 `std::same_as<To[1]>`，就可以确保转换是无损的，不会导致数据丢失。
### Subsuming Constraints
编译器总是使用具有最具体约束的模板，更具体的约束包含较少的约束。下面是一个示例:
```cpp
template <typename T> requires integral<T>
void process(const T& t) { cout << "integral<T>" << endl; }

template <typename T> requires (integral<T> && sizeof(T) == 4)
void process(const T& t) { cout << "integral<T> && sizeof(T) == 4" << endl; }

process(int { 1 });
process(short { 2 });

// 输出
integral<T> && sizeof(T) == 4
integral<T>
```
编译器首先通过规范化约束表达式来解析任何包容。在约束表达式的规范化过程中，所有概念表达式都会被递归地扩展它们的定义，直到结果是一个由常量布尔表达式的合取和析取组成的常量表达式。如果编译器可以证明一个规范化的约束表达式包含另一个约束表达式，那么它就包含另一个约束表达式，只考虑使用合取和析取来证明任何包容，而不是否定，
这种包容推理只在语法层面上完成，而不是语义层面。例如，`sizeof(T)>4` 在语义上比 `sizeof(T)>=4` 更具体，但在语法上前者并不会包含后者。 
但是，类型萃取在规范化期间不会被扩展。因此，如果有一个预定义的概念和一个类型萃取可用，那么应该使用这个概念而不是这个萃取。例如，使用 `integral` 概念来代替 `is_integral` 类型萃取。
对于上述窄化转换的概念，其中包含着隐式转化的概念，因此可以只定义窄化转换：
```cpp
template<typename From, typename To>
concept ConvertsWithoutNarrowing = requires (From&& x) {
    { std::type_identity_t<To[]>{std::forward<From>(x)} } -> std::same_as<To[1]>;
};

// 如果既定义隐式转化又定义窄化转换，不会存在二义性，因为是包含关系
```
### Using Requirements to Call Different Functions
下面让 `add()` 函数模板更灵活:
- 支持只提供 `insert()` 而不是 `push_back()` 来插入新元素的集合。
- 支持传递一个集合 (容器或范围) 来插入多个值。
定义一个只需要集合作为模板形参的概念：
```cpp
// 从 C++20 开始，当上下文明确限定成员必须是类型时，不再需要 typename
template<typename Coll>
concept SupportsPushBack = requires(Coll coll, Coll::value_type val) {
    coll.push_back(val);
};
```
可以使用 `std::declval<>()` 来获取元素类型值：
```cpp
// 无论将 coll 声明为值，还是非 const 引用都无关紧要
template<typename Coll>
concept SupportsPushBack = requires(Coll coll) {
    coll.push_back(std::declval<typename Coll::value_type&>());
};
```
概念和需求的定义并没有创建代码，是一个未求值的上下文，因此可以使用 `std::declval<>()` 来表示假设有一个这种类型的对象。
此处作为 `declval` 模板参数的 `&` 允许对于创建的左值使用 `push_back()` 进行复制，如果没有 `&`，则只要求可以插入右值使用 `move` 语义。
当需要集合的元素类型时，使用 `std::ranges::range_value_t<>` 可以使代码更具泛型，使其也适用于原始数组，因此可以使用 `std::ranges::range_value_t` 来代替 `value_type` 的成员:
```cpp
template<typename Coll>
concept SupportsPushBack = requires(Coll coll) {
    coll.push_back(std::declval<std::ranges::range_value_t<Coll>>());
};
```
这里不需要命名需求 `SupportsInsert`，因为带有附加需求的 `add()` 更特殊，所以重载解析更偏向 它。但只有少数容器支持只使用一个参数调用 `insert()`，为避免其他重载和 `add()` 调用的问题，最好在这里也有一个约束。 
```cpp
template<typename Coll, typename T>
requires SupportsPushBack<Coll>
void add(Coll& coll, const T& val)
{ coll.push_back(val); }

template<typename Coll, typename T>
void add(Coll& coll, const T& val)
{ coll.insert(val); }

// 约束是应用于模板参数的单个概念
template<SupportsPushBack Coll, typename T>
void add(Coll& coll, const T& val)
{ coll.push_back(val); }

void add(SupportsPushBack auto& coll, const auto& val)
{ coll.push_back(val); }
```
### If Constexpr
可以在 `if constexpr` 条件中直接使用 `SupportsPushBack` 这个概念，还可以跳过引入的概念，直接将 `requires` 表达式作为条件传递给 `if constexpr`:
```cpp
if constexpr (SupportsPushBack<decltype(coll)>) {
    coll.push_back(val);
}
else {
    coll.insert(val);
}

if constexpr (requires { coll.push_back(val); }) {
    coll.push_back(val);
}
else {
    coll.insert(val);
}
```
### Inserting Single and Multiple Values
概念 `std::ranges::input_range` 是一个用于处理范围的概念，范围是可以使用 `begin()` 和 `end()` 迭代的集合，但范围不需要将 `begin()` 和 `end()` 作为成员函数，所以处理范围的代码应该使用范围库提供的 `std::ranges::begin()` 和 `std::ranges::end()`，这可用于提供为一个集合传递的多个值的重载：
```cpp
template<SupportsPushBack Coll, std::ranges::input_range T>
void add(Coll& coll, const T& val)
{
    coll.insert(coll.end(), std::ranges::begin(val), std::ranges::end(val));
}

template<typename Coll, std::ranges::input_range T>
void add(Coll& coll, const T& val)
{
    coll.insert(std::ranges::begin(val), std::ranges::end(val));
}
```
### Type Constraints and Class Templates
 下述要求`GameBoard`的模板类型参数是 `GamePiece` 的派生类：
```cpp
template <std::derived_from<GamePiece> T>
class GameBoard : public Grid<T>
{
public:
    explicit GameBoard(size_t width = Grid<T>::DefaultWidth,
    size_t height = Grid<T>::DefaultHeight);
    void move(size_t xSrc, size_t ySrc, size_t xDest, size_t yDest);
};
```
相关方法的实现也需要更新，示例如下：
```cpp
template <std::derived_from<GamePiece> T>
void GameBoard<T>::move(size_t xSrc, size_t ySrc, size_t xDest, size_tyDest) 
{ ... }

// Alternatively, you can also use a requires clause as follows:
template <typename T> requires std::derived_from<T, GamePiece>
class GameBoard : public Grid<T> { ... };
```
也可以对类模板的特定方法添加额外的约束。例如，可以进一步限制 `GameBoard` 类模板的 `move` 方法，要求类型 `T` 是可移动的。
```cpp
template <std::derived_from<GamePiece> T>
class GameBoard : public Grid<T>
{
public:
    explicit GameBoard(size_t width = Grid<T>::DefaultWidth,
    size_t height = Grid<T>::DefaultHeight);
    void move(size_t xSrc, size_t ySrc, size_t xDest, size_t yDest)
    requires std::movable<T>;
};
```
这样的 `requires` 子句也需要在方法定义上重复:
```cpp
template <std::derived_from<GamePiece> T>
void GameBoard<T>::move(size_t xSrc, size_t ySrc, size_t xDest, size_t yDest)
 requires std::movable<T>
{ ... }
```
基于选择性实例化，仍然可以使用非移动类型的 `GameBoard` 类模板, 只要不调用它的 `move` 方法。
## Semantic Constraints
概念可同时检查语法和语义约束：
- 语法约束在编译时，可以检查是否满足某些功能需求，是否支持特定的操作，或特定操作是否产生特定类型。 
- 语义约束满足了某些只能在运行时检查的需求，操作是否具有相同的效果，或对特定值 执行相同的操作是否总是产生相同的结果。 
有时，概念允许开发者通过接口来指定是否满足语义约束，从而将语义约束转换为语法约束。
### ranges::sized_range
语义约束的第一个例子是概念 `std::ranges::sized_range`，其保证可以在常量时间内计算一个范围内的元素数量(通过成员函数 `size()` 或计算开始和结束之间的差值)。 若范围类型提供 `size()`(作为成员函数或独立函数)，则默认情况下满足此概念。要从这个概念中退出(例如，迭代所有元素以产生结果)，可以将 `std::disable_size_range` 设置为 `true`:
```cpp
class MyCont {
    ...
    std::size_t size() const; // assume this is expensive, so that this is not a sized range
};
// opt out from concept std::ranges::sized_range:
constexpr bool std::ranges::disable_sized_range<MyCont> = true;
```
### incrementable / weak_incrementable 
`incrementable` 要求相同值的每次递增都产生相同的结果。
`weakly_incrementable` 只要求类型支持自增操作符，增加相同的值，可能会产生不同的结果。
因此，当满足 `incrementable` 时，可以从一个起始值在一个范围内迭代多次。当仅满足 `weakly_incrementable` 条件时，只能在一个范围内迭代一次。具有相同起始值的第二次迭代可能产生不同的结果。 
这种差异对迭代器很重要: 输入流迭代器只能迭代一次，因为下一次迭代产生不同的值，所以输入流迭代器满足 `weakly_incrementable` 概念，但不满足可递增概念，但这些概念不能用于检查这种差异
```cpp
std::weakly_incrementable<std::istream_iterator<int>> // yields true
std::incrementable<std::istream_iterator<int>> // OOPS: also yields true
```
原因是这种差异是一种语义约束，不能在编译时检查，所以这些概念可以用来记录约束条件：
```cpp
template<std::weakly_incrementable T>
void algo1(T beg, T end); // single-pass algorithm

template<std::incrementable T>
void algo2(T beg, T end); // multi-pass algorithm
```
这里对算法使用了不同的名称。由于无法检查约束的语义差异，因此开发者可以决定不传递输入流迭代器：
```cpp
algo1(std::istream_iterator<int>{std::cin}, // OK
std::istream_iterator<int>{});

algo2(std::istream_iterator<int>{std::cin}, // OOPS: violates constraint
std::istream_iterator<int>{});
```
然而，不能根据这个差异来区分两种实现：
```cpp
template<std::weakly_incrementable T>
void algo(T beg, T end); // single-pass implementation
template<std::incrementable T>
void algo(T beg, T end); // multi-pass implementation
```
若在这里传递一个输入流迭代器，编译器将不正确地使用多通道实现，解决办法是提供这些概念：
```cpp
algo(std::istream_iterator<int>{std::cin}, // OOPS: calls the wrong overload
std::istream_iterator<int>{});

template<std::input_iterator T>
void algo(T beg, T end); // single-pass implementation
template<std::forward_iterator T>

void algo(T beg, T end); // multi-pass implementation

// OK: calls the right overload
algo(std::istream_iterator<int>{std::cin}, std::istream_iterator<int>{});
```
## Constraints
要指定对泛型参数的需求，需要约束，这些约束在编译时用于决定是否实例化和编译模板。普通的约束通常使用 `requires` 子句来指定。例如:
```cpp
template<typename T>
void foo(const T& arg)
requires MyConcept<T>
...
```
在模板参数或 `auto` 前面，也可以直接使用概念作为类型约束:
```cpp
template<MyConcept T>
void foo(const T& arg)
// Or
void foo(const MyConcept auto& arg)
```
`requires` 子句使用关键字 `requires` 和编译时布尔表达式来限制模板的可用性。布尔表达式可以是: 编译时的布尔表达式、概念、`requires` 表达式，可以使用布尔表达式的地方都可以使用约束，特别是以 `if constexpr` 作为条件的。
## Requires Clause
### Using && and || in requires Clauses
约束/概念表达式可以使用 `&&` 和 `||` 进行组合，但很少需要指定可选约束，也不应该随意指定，在 `requires` 子句中过度使用运算符 `||` 可能会增加编译资源的负担 (使编译明显变慢)。仅用一个概念 或多个概念与 `&&` 和 `||` 组合约束模板的 `requires` 子句不再需要括号。
下面的示例演示了一个概念，它要求一个类型既是可以自增，也是可以自减。
```cpp
template<typename T>
requires (sizeof(T) > 4) // ad-hoc Boolean expression
    && requires { typename T::value_type; } // requires expression
    && std::input_iterator<T> // concept
    void foo(T x) {
    ...
}

template<typename T>
requires std::integral<T> || std::floating_point<T>
T power(T b, T p);

template <typename T>
concept IncrementableAndDecrementable = Incrementable<T> && Decrementable<T>;
```
`std::ranges::range_value_t` 是一个范围工具，用于在迭代范围时获取元素的类型。 要禁用窄化转换，可使用 `std::ranges::range_value_t` 将范围的元素类型传递给 `ConvertsWithoutNarrowing`。通过汇集所有有用的概念和需求，可以将它们放在不同位置的函数中：
```cpp
template<SupportsPushBack Coll, std::ranges::input_range T>
requires ConvertsWithoutNarrowing<std::ranges::range_value_t<T>,
                                    typename Coll::value_type>
void add(Coll& coll, const T& val)
{
    coll.insert(coll.end(),
    std::ranges::begin(val), std::ranges::end(val));
}
```
也可以在 `requires` 从句中将它们组合在一起:
```cpp
template<typename Coll, typename T>
requires SupportsPushBack<Coll> &&
        std::ranges::input_range<T> &&
        ConvertsWithoutNarrowing<std::ranges::range_value_t<T>,
                                typename Coll::value_type>
void add(Coll& coll, const T& val)
{
    coll.insert(coll.end(), std::ranges::begin(val), std::ranges::end(val));
}
```
单个约束还可以涉及多个模板参数，约束可以在多个类型 (或值) 之间施加影响。例如：
```cpp
template<typename T, typename U>
requires std::convertible_to<T, U>
auto f(T x, U y) {
    ...
}
```
### Ad-hoc Boolean Expressions
为模板制定约束的基本方法是使用 `requires` 子句，`requires` 后跟一个布尔表达式。`requires` 之后，约束可以使用编译时布尔表达式，而不仅是概念或 `requires` 表达式。这些表达可以使用类型谓词/类型特征、用 `constexpr` 或 `constinit` 定义的编译时变量、用 `constexpr` 或 `consteval` 定义的编译时函数。
```cpp
// Available only if int and long have a different size:
template<typename T>
requires (sizeof(int) != sizeof(long))
...

// Available only if sizeof(T) is not too large:
template<typename T>
requires (sizeof(T) <= 64)
...

// Available only if the non-type template parameter Sz is greater than zero:
template<typename T, std::size_t Sz>
requires (Sz > 0)
...

// Available only for raw pointers and the nullptr:
template<typename T>
requires (std::is_pointer_v<T> || std::same_as<T, std::nullptr_t>)
...

// std::same_as is a new standard concept. 
// Instead, you could also use the standard type trait std::is_same_v<>:
template<typename T>
requires (std::is_pointer_v<T> || std::is_same_v<T, std::nullptr_t>)
...

// Available only if the argument cannot be used as a string:
template<typename T>
requires (!std::convertible_to<T, std::string>)
...

// std::convertible_to is a new standard concept. 
// You could also use the standard type trait std::is_convertible_v<>:
template<typename T>
requires (!std::is_convertible_v<T, std::string>)

// Available only if the non-type template parameters Min and Max 
// have a greatest common divisor (GCD) that is greater than one:
template<typename T>
constexpr bool gcd(T a, T b); // greatest common divisor (forward declaration)

template<typename T, int Min, int Max>
requires (gcd(Min, Max) > 1) // available if there is a GCD greater than 1
...

// Disable a template (temporarily):
template<typename T>
requires false // disable the template
...
```
为限制类指针对象可用，假设有一个类型为 `T` 的对象 `std::declare()`，为对象调用解引用操作符 `*`，获取其类型 `decltype()`，删除引用 `std::remove_reference_v<>`，检查是否为整型` std::integral<>`：
```cpp
// Available only if the argument is a pointer or pointer-like object to an integral value:
// std::integral is a new standard concept. 
// You could also use the standard type trait std::is_integral_v<>.
template<typename T>
requires std::integral<std::remove_reference_t<decltype(*std::declval<T>())>>
...
```
### Requires Expressions
`Requires Expressions` 提供一种简单而灵活的语法，用于在一个或多个模板参数上指定多个需求: 必需的类型定义、表达式必须有效、对表达式产生类型的要求，表达式以 `requires` 开头，后跟一个可选的参数列表，然后是一个以分号结束的需求块。例如:
```cpp
template<typename Coll>
... requires {
    typename Coll::value_type::first_type; // elements/values have first_type
    typename Coll::value_type::second_type; // elements/values have second_type
}
```
可选参数列表允许引入一组虚拟变量，可用于在表达式的主体中表达需求，这些形参永远不会由实参取代，所以通过值或引用声明都可以。
```cpp
template<typename T>
... requires(T x, T y) {
    x + y; // supports +
    x - y; // supports -
}

// 要求检查 Coll::value_type 是否有效，以及该类型的对象是否支持输出操作符
template<typename Coll>
... requires(Coll::value_type v) { // 参数还允许引入子类型(参数):
    std::cout << v; // supports output operator
    // true; // dummy requirement because the block cannot be empty
}
```
#### Simple Requirements
简单 `Requirements` 就是必须格式良好的表达式，不允许使用变量声明、循环、条件语句等，并且这个表达式语句永远不会被计算，编译器也只是用于验证它是否已通过编译，调用不会执行，从而操作产生的结果并不重要。
```cpp
// ... 可以是 requires 或 concept name = 
template<typename T1, typename T2>
... requires(T1 val, T2 p) {
    *p; // operator* has to be supported for T2
    p[0]; // operator[] has to be supported for int as index
    p->value(); // calling a member function value() without arguments has to be possible
    *p > val; // support the comparison of the result of operator* with T1
    p == nullptr; // support the comparison of a T2 with a nullptr
}
```
最后一个调用没有要求 `p` 是 `nullptr`，只是要求可以将 `T2` 类型的对象与 `nullptr` 类型的对象进行比较。如果要求 `p` 是 `nullptr`，必须检查 `T2` 是否是类型 `std::nullptr_t`。
调用不会执行会导致下面的概念不要求左子表达式或右子表达式可能成立：
```cpp
template<typename T1, typename T2>
... requires(T1 val, T2 p) {
    *p > val || p == nullptr;
}

// 相反，需要使用
template<typename T1, typename T2>
... requires(T1 val, T2 p) {
    *p > val; // support the comparison of the result of operator* with T1
}
|| requires(T2 p) { // OR
    p == nullptr; // support the comparison of a T2 with nullptr
}
```
下面的概念也不要求 `T` 必须是整型，只要求表达式 `std::integral` 有效，这是所有类型的情况。
```cpp
template<typename T>
... requires {
    std::integral<T>; // OOPS: does not require T to be integral
    ...
};

// 相反，需要使用
template<typename T>
... std::integral<T> && // OK, does require T to be integral
requires {
    ...
};

// Alternatively, as follows:
template<typename T>
... requires {
    requires std::integral<T>; // OK, does require T to be integral
    ...
};
```
#### Type Requirements
类型 `requirement` 是在使用类型名称时必须格式良好的表达式，所以名称必须定义为有效类型，用于验证特定类型是否有效。
```cpp
template<typename T1, typename T2>
... requires {
    typename T1::value_type; // type member value_type required for T1
    typename std::ranges::iterator_t<T1>; // iterator type required for T1
    typename std::common_type_t<T1, T2>; // T1 and T2 have to have a common type
}
```
只能检查给定类型的名称，即类名、枚举类型的名称，来自 `typedef` 或 `using`，不能使用类型检查其他类型声明:
```cpp
template<typename T>
... requires {
    typename int; // ERROR: invalid type requirement
    typename T&; // ERROR: invalid type requirement
}

// The way to test the latter is to declare a corresponding parameter:
template<typename T>
... requires(T&) {
    true; // some dummy requirement
};
```
此外，需求可以检查使用传递的类型定义另一个类型是否有效:
```cpp
template<std::integral T>
class MyType1 {
    ...
};
template<typename T>
requires requires {
    typename MyType1<T>; // instantiation of MyType1 for T would be valid
}
void mytype1(T) { ... }

mytype1(42); // OK
mytype1(7.7); // ERROR
```
注意，简单的需求只检查需求是否有效，而不检查需求是否满足。出于这个原因：
```cpp
// It does not check whether there is a standard hash function for type T:
template<typename T>
concept StdHash = requires {
    typename std::hash<T>; // does not check whether std::hash<> is defined for T
};

// The way to require a standard hash function is to try to create or use it:
template<typename T>
concept StdHash = requires {
    std::hash<T>{}; // OK, checks whether we can create a standard hash function for T
};

// It does not make sense to use type functions that always yield a value:
template<typename T>
... requires {
    std::is_const_v<T>; // not useful: always valid (doesn’t matter what it yields)
}

// To check for constness, use:
template<typename T>
... std::is_const_v<T> // ensure that T is const

// It does not make sense to use type functions that always yield a type:
template<typename T>
... requires {
    typename std::remove_const_t<T>; // not useful: always valid (yields a type)
}
```
使用可能具有未定义行为的类型函数也没有意义。类型特性 `std::make_unsigned<>` 要求传递的参数是整型，而非 `bool` 型。若传递的类型不是整型，则有未定义行为，`std::make_unsigned<>` 作为需求时需要限制调用其类型:
```cpp
template<typename T>
... requires {
    std::make_unsigned<T>::type; // not useful as type requirement (valid or undefined behavior)
}

template<typename T>
... requires {
    requires (std::integral<T> && !std::same_as<T, bool>);
    std::make_unsigned<T>::type; // OK
}
```
### Compound Requirements
复合需求允许将简单需求和类型需求结合起来，可以指定一个表达式，然后添加: 
- `noexcept` 要求表达式保证不抛出异常 。
- `-> type-constraint` 将概念应用于表达式的求值，`type-constraint` 将结果类型作为其第一个模板参数从而指定类型需求。
```cpp
template<typename T>
... requires(T x) {
    { &x } -> std::input_or_output_iterator;
    // { &x } -> std::is_pointer_v<>;
    { x == x };
    { x == x } -> std::convertible_to<bool>;
    { x == x } noexcept;
    { x == x } noexcept -> std::convertible_to<bool>;
}
```
第一个需求中，需求在对类型为 `T` 的对象使用运算符 `&` 时满足 `std::input_or_output_iterator` 的概念，`std::input_or_output_iterator<decltype(&x)>` 产生 `true`。也可以这样指定:
最后一个需求中，两个 T 类型对象的 `==` 操作符的结果作为参数传递时，满足 `std::convertible_to` 的概念。
`requires` 表达式还可以表达对关联类型的需求：
```cpp
template<typename T>
... requires(T coll) {
    { *coll.begin() } -> std::convertible_to<T::value_type>;
}
```
但不能使用嵌套类型指定类型需求，例如，`*p` 的返回值是一个引用，必须先解引用，才能使用它们来要求使用解引用操作符的返回值产生整数值，但又有一个问题是不能在 `requires` 表达式的结果中，使用带有类型特性的嵌套表达式：
```cpp
template<typename T>
concept Check = requires(T p) { // integral 与 remove_reference_t 嵌套
    { *p } -> std::integral<std::remove_reference_t<>>; // ERROR
    { *p } -> std::integral<std::remove_reference_t>; // ERROR
};
```
解决办法是先定义相应的概念或使用嵌套 `requires` 表达式：
```cpp
template<typename T>
concept UnrefIntegral = std::integral<std::remove_reference_t<T>>;

template<typename T>
concept Check = requires(T p) {
    { *p } -> UnrefIntegral; // OK
};
```
### Nested Requirements
嵌套需求可用于在 `requires` 表达式中指定附加约束。以 `requires` 开头，后跟一个编译时布尔表达式，该表达式本身也可能是或使用 `requires` 表达式。嵌套需求的好处是，可以确保编译时表达式产生特定的结果，而不是仅仅确保表达式有效。 
例如，考虑一个概念，必须确保对于给定类型，解引用和 `[]` 操作符产生相同的类型。通过使用嵌套需求，可以这样指定：
```cpp
template<typename T>
concept DerefAndIndexMatch = requires (T p) {
    requires std::same_as<decltype(*p), decltype(p[0])>;
};
```
对于假设有一个 `T` 类型的对象，可以不必使用 `requires` 表达式：
```cpp
template<typename T>
concept DerefAndIndexMatch = std::same_as<decltype(*std::declval<T>()),
                                            decltype(std::declval<T>()[0])>;
```
另一个例子，可以使用嵌套需求来解决在表达式上指定复杂类型需求的问题:
```cpp
template<typename T>
concept Check = requires(T p) {
    requires std::integral<std::remove_cvref_t<decltype(*p)>>;
};
```
下述第一个表达式只要求检查 `const` 性并对结果取反有效，这个需求总是可满足。因为做这个检查总是有效的，所以这个需求毫无价值。 
第二个需求表达式才有价值，若 `T` 是 `int` 则满足要求，但若 `T` 是 `const int` 则不满足。
```cpp
template<typename T>
... requires {
    !std::is_const_v<T>; // OOPS: checks whether we can call is_const_v<>
    requires !std::is_const_v<T>; // OK: checks whether T is not const
}
```
## Concepts in Detail
无论在编译时还是在运行时，都可以在需要布尔表达式值的地方使用一个概念，但不接受地址，因为地址是一个纯右值。此外，不能在函数中定义概念 (所有模板都是如此)。
```cpp
template< ... >
concept name = ... ;

template<typename T>
concept MyConcept = ... ;
std::is_same<MyConcept< ... >, bool> // yields true
```
### Concepts Versus Variable Templates and Type Traits
```cpp
template<typename T>
concept IsOrHasThisOrThat = ... ;

template<typename T>
inline constexpr bool IsOrHasThisOrThat = ... ;

// 使用布尔变量模板与模仿概念的例子
template<typename T>
constexpr bool SupportsPushBack = requires(T coll) {
    coll.push_back(std::declval<typename T::value_type>());
};
```
概念不仅仅是在编译时计算布尔值结果的表达式，与类型特征和布尔变量模板的定义 (定义类型特征的常用方式) 相比：
- 概念并不表示代码，没有类型、存储、生命周期或与对象相关的其他属性，可以与 `if constexpr` 一起使用。 
- 通过在编译时为特定模板参数实例化它们，实例化只会变为 `true` 或 `false`，所以可以在使用 `true` 或 `false` 的地方使用，可以得到这些字面量的所有属性。
- 概念不必声明为内联的，其隐式内联。 
- 概念可以直接用作模板参数或 `auto` 前面的类型约束，变量模板不能这样使用。
- 概念是给约束命名的唯一方法，所以需要其来决定一个约束是否是另一个约束的特殊情况。
- 概念可以互包含。为让编译器决定一个约束是否决定另一个约束，必须将约束公式化为概念。
概念的主要好处是互包含，而类型特征不可互包含。考虑下面的例子，用定义为类型特性的两个需求重载函数 `foo()`：
```cpp
template<typename T, typename U>
requires std::is_same_v<T, U> // using traits
void foo(T, U)
{
    std::cout << "foo() for parameters of same type" << '\n';
}

template<typename T, typename U>
requires std::is_same_v<T, U> && std::is_integral_v<T>
void foo(T, U)
{
    std::cout << "foo() for integral parameters of same type" << '\n';
}

foo(1, 2); // ERROR: ambiguity: both requirements are true
```
问题是，若两个需求都求值为 `true`，则两个重载都适合，并且没有规则表明其中一个优先于另一个，所以编译器将停止编译，并出现歧义错误。若使用相应的概念，编译器会发现第二个需求是一种特化，若两个需求都满足，则更倾向于使用它:
```cpp
template<typename T, typename U>
requires std::same_as<T, U> // using concepts
void foo(T, U)
{
    std::cout << "foo() for parameters of same type" << '\n';
}

template<typename T, typename U>
requires std::same_as<T, U> && std::integral<T>
void foo(T, U)
{
    std::cout << "foo() for integral parameters of same type" << '\n';
}

foo(1, 2); // OK: second foo() preferred
```
### Concepts For Non-Type Template Parameters
概念也可以应用于非类型模板参数(NTTP)。例如:
```cpp
template<auto Val>
concept LessThan10 = Val < 10;

template<int Val>
requires LessThan10<Val>
class MyType {...};

// 以使用一个概念将非类型模板形参的值约束为 2 的幂:
template<auto Val>
concept PowerOf2 = std::has_single_bit(static_cast<unsigned>(Val));

// 使用这个概念要求 Memory 类只接受 2 的幂次大小和类型
template<typename T, auto Val>
requires PowerOf2<Val>
class Memory {}; 

Memory m1<int, 8>; // OK 
Memory m2<int, 9>; // ERROR 
Memory m3<int, 32>; // OK 
Memory m4<int, true>; // OK
```
概念 `PowerOf2` 接受一个值而不是类型作为模板参数，`std::has_single_bit()` 要求有一个无符号整型值。通过强制转换为 `unsigned`，可以传递有符号整型值，并拒绝不能转换为无符号整型值的类型。当 `std::has_single_bit()` 对传递的值产生 `true`(只设置一个位意味着值是 2 的幂)时，概念满足。
注意，不能这样写，这样就对 `Val` 类型提出了要求，但概念 `PowerOf2` 不约束其类型，而是限制其值：
```cpp
template<typename T, PowerOf2 auto Val>
class Memory {...};
```
### Using Concepts as Type Constraints
概念可以用作类型约束。可以在不同的地方使用类型约束：
- 模板类型参数的声明中
- 用 `auto` 声明的调用参数的声明中
- 作为复合需求中的一个需求
```cpp
template<std::integral T> // type constraint for a template parameter
class MyClass {...};

// type constraint for an auto parameter
auto myFunc(const std::integral auto& val) {...};

template<typename T>
concept MyConcept = requires(T x) {
    { x + x } -> std::integral; // type constraint for return type
};
```
### Type Constraints with Multiple Parameters
可以使用带有多个参数的约束，将参数类型或返回值用作参数：
```cpp
template<std::convertible_to<int> T> // conversion to int required
class MyClass {...};

// conversion to int required
auto myFunc(const std::convertible_to<int> auto& val) {...};

template<typename T>
concept MyConcept = requires(T x) {
    { x + x } -> std::convertible_to<int>; // conversion to int required
};
```
另一个经常使用的例子是约束可调用对象的类型，可以使用 `std::invocable` 或 `std::regular_invocable` 概念传递一定数量的特定类型的参数，例如：要求传递一个接受 `int` 和 `std::string` 的操作，则必须声明：
```cpp
template<std::invocable<int, std::string> Callable>
void call(Callable op);

// or:
void call(std::invocable<int, std::string> auto op);
```
`std::invocable` 和 `std::regular_invocable` 的区别在于后者保证不修改传递的操作和参数。这是一种语义上的差异，只有助于记录意图，所以只使用 `std::invocable`。
### Type Constraints and auto
类型约束可以在所有可以使用 `auto` 的地方使用，该特性的主要应用是对用 `auto` 声明的函数参数使用类型约束。例如:
```cpp
void foo(const std::integral auto& val) {...}
```
也可以对 `auto` 使用类型约束:
```cpp
std::floating_point auto val1 = f(); // valid if f() yields floating-point value

// valid if elements are integral values
for (const std::integral auto& elem : coll) { ...}

// To constrain return types:
std::copyable auto foo(auto) {...} // valid if foo() returns copyable value

// To constrain non-type template parameters:
template<typename T, std::integral auto Max>
class SizedColl {...};
```
也适用于接受多个参数的概念：
```cpp
// conversion to T required
template<typename T, std::convertible_to<T> auto Val>
class MyType {...};
```
### Subsuming Constraints with Concepts
两个概念可以有一个包含关系，可以指定一个概念，使其包含一个或多个其他概念。这样做的好处是，当两个约束都得到满足时，重载解析更倾向于使用约束较多的泛型代码，而不是使用约束较少的泛型代码。 例如，假设引入以下两个概念
```cpp
template<typename T>
concept GeoObject = requires(T obj) {
    { obj.width() } -> std::integral;
    { obj.height() } -> std::integral;
    obj.draw();
};

template<typename T>
concept ColoredGeoObject = GeoObject<T> && // subsumes concept GeoObject
requires(T obj) { // additional constraints
    obj.setColor(Color{});
    { obj.getColor() } -> std::convertible_to<Color>;
};
```
因为 `ColoredGeoObject` 显式地规定类型 T 也必须满足概念 `GeoObject` 的约束，所以概念显式地包含概念 `GeoObject`。当为两个概念重载模板并且两个概念都满足时，不会得到歧义错误，重载解析更倾向于包含其他概念的概念：
约束包含仅在使用概念时起作用。若没有使用概念，则具有不同约束的重载不明确：
```cpp
template<typename T>
requires std::is_convertible_v<T, int>
void print(T) {...}

template<typename T>
requires (std::is_convertible_v<T, int> && sizeof(int) >= 4)
void print(T) {...}

print(42); // ERROR: ambiguous (if both constraints are true)

// When using concepts instead, this code works:
template<typename T>
requires std::convertible_to<T, int>
void print(T) {...}

template<typename T>
requires (std::convertible_to<T, int> && sizeof(int) >= 4)
void print(T) {...}

print(42); // OK
```
产生这种行为的一个原因是，处理概念之间的依赖关系需要更多编译的时间。
C++ 标准库提供的概念经过精心设计，以便在有意义时包含其他概念：
std::random_access_range 包含了 std::bidirectional_range，两者都包含了 std::forward_range，三 者都包含了 std::input_range，所以都包含了 std::range。 但是，std::sized_range 只包含 std::range，而不包含其他的概念。 
std::regular 包含了 std::semiregular，而两者都包含了 std::copyable 和 std::default_initializable(其 中包含了其他几个概念，如 std::movable、std::copy_constructible 和 std::destructible)。 
std::sortable 包含 std::permutable，两者都包含 std::indirectly_swappable，这两个参数都是相同 的类型。
### Indirect Subsumptions
约束可以间接包含，所以重载解析仍然可以选择一个重载或特化，即使其约束不是根据彼此定义的。例如，假设已经定义以下两个概念：
```cpp
template<typename T>
concept RgSwap = std::ranges::input_range<T> && std::swappable<T>;

template<typename T>
concept ContCopy = std::ranges::contiguous_range<T> && std::copyable<T>;
```
当为这两个概念重载两个函数，并传递一个同时适合这两个概念的对象时，这并不具有二义性：
```cpp
template<RgSwap T>
void foo1(T) {
    std::cout << "foo1(RgSwap)\n";
}

template<ContCopy T>
void foo1(T) {
    std::cout << "foo1(ContCopy)\n";
}

foo1(std::vector<int>{}); // OK: both fit, ContCopy is more constrained
```
原因是 `ContCopy` 间接包含 `RgSwap`，`contiguous_range` 概念是根据 `input_range` 概念定义，它包含，`copyable` 概念根据可交换的概念来定义，它包含 `movable`，也就包含着可互换。
原因是 `ContCopy` 间接包含 `RgSwap`，`contiguous_range` 概念是根据 `input_range` 概念定义，它包含 `random_access_range`、`bidirectional_range`、`forward_range`、`input_range`。`copyable` 概念根据可交换的概念来定义，它包含 `movable`，也就包含着可互换。
但使用以下声明，当两个概念都适合时，就会产生歧义：
```cpp
template<typename T>
concept RgSwap = std::ranges::sized_range<T> && std::swappable<T>;

template<typename T>
concept ContCopy = std::ranges::contiguous_range<T> && std::copyable<T>;
```
原因是 `contiguous_range` 和 `sized_range` 这两个概念都不包含对方。 
此外，对于下列声明，没有一个概念包含另一个概念：
```cpp
template<typename T>
concept RgCopy = std::ranges::input_range<T> && std::copyable<T>;

template<typename T>
concept ContMove = std::ranges::contiguous_range<T> && std::movable<T>;
```
因为它们都只有一个概念互相包含对方，而不是整个概念包含。
### Defining Commutative Concepts
假设定义概念 `SameAs`:
```cpp
template<typename T, typename U>
concept SameAs = std::is_same_v<T, U>; // define concept SameAs

template<typename T, typename U>
requires SameAs<T, U> // use concept SameAs
void foo(T, U)
{
    std::cout << "foo() for parameters of same type" << '\n';
}

template<typename T, typename U>
requires SameAs<T, U> && std::integral<T> // use concept SameAs again
void foo(T, U)
{
    std::cout << "foo() for integral parameters of same type" << '\n';
}

foo(1, 2); // OK: second foo() preferred
```
这里，`foo()` 的第二个定义包含第一个定义，当传递两个相同整型的参数，并且两个 `foo()` 的约束都满足时，会调用第二个 `foo()`。但在第二个 `foo()` 的约束中调用 `SameAs<>` 时，若稍微修改参数：
```cpp
template<typename T, typename U>
requires SameAs<T, U> // use concept SameAs
void foo(T, U)
{
    std::cout << "foo() for parameters of same type" << '\n';
}

template<typename T, typename U>
requires SameAs<U, T> && std::integral<T> // use concept SameAs with other order
void foo(T, U)
{
    std::cout << "foo() for integral parameters of same type" << '\n';
}

foo(1, 2); // ERROR: ambiguity: both constraints are satisfied without one subsuming the other
```
问题是编译器无法检测到 `SameAs<>` 是可交换的。对于编译器来说，模板参数的顺序很重要，所以第一个需求不一定是第二个需求的子集。为解决这个问题，必须以一种不影响参数顺序的方式来设计 `SameAs` 概念，这里需要一个辅助概念:
```cpp
template<typename T, typename U>
concept SameAsHelper = std::is_same_v<T, U>;

template<typename T, typename U>
concept SameAs = SameAsHelper<T, U> && SameAsHelper<U, T>; // make commutative
```
使用 `SameAsHelper` 后的 `SameAs`，参数的顺序不再重要。
## Standard Concepts
中文版 PDF 101 英文版 113
