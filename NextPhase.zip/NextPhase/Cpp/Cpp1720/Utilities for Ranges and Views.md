# Utilities for Ranges and Views
## Range Adaptor And Factory
`C++` 提供几个范围适配器和范围工厂，以便可以创建具有最佳性能的视图。其中几个适配器适用于特定的视图类型。然而，根据传递范围的特征，其中一些可能会创建不同的东西。若适配器已经具有结果的特征，可能只生成可传递的范围。 
有一些关键的范围适配器和工厂，可以很容易地创建视图，或将范围转换为具有特定特征的视图：
- `std::views::all()` 是将传递的范围转换为视图的范围适配器。  
- `std::views::counted()` 是可将传入的 `begin` 和 `count/size` 转换为视图的范围工厂。
- `std::views::common()` 是一个范围适配器，将开始迭代器和哨兵具有不同类型的范围转换为具有统一的开始和结束类型的视图。
### std::views::all()
范围适配器 `std::views::all()` 是将任何还不是视图的范围转换为视图的适配器，可由一个低成本的句柄来处理范围中的元素。此外，使用容器初始化视图类型時可能会隐式地使用 `all()`。
`all()` 适配器通常用于将范围转换为视图作为轻量级对象传递。将范围转换成视图有两个原因，当按值传递时，移动或复制一个视图的成本更低，相当于按引用传递：
```cpp
void foo(std::ranges::input_range auto coll) { // NOTE: takes range by value
    for (const auto& elem : coll) ...
}

std::vector<std::string> coll{ ... };
foo(coll); // OOPS: copies coll
foo(std::views::all(coll)); // OK: passes coll by reference
```
此处使用 `all()` 类似于 `std::ref()/std::cref()`，但 `all()` 的好处是传递的内容仍然支持通常的范围接口。使用 `all()` 的另一个原因是为满足需要视图的约束，这个要求可能是为确保传递参数的代价不高：
```cpp
void foo(std::ranges::view auto coll) // NOTE: takes view by value
{
    for (const auto& elem : coll) ...
}
std::vector<std::string> coll{ ... };
foo(coll); // ERROR
foo(std::views::all(coll)); // OK (passes coll by reference)
```
`all()` 的返回类型是 `std::views::all_t<>` ，`all(rg)` 根据所调用的范围特征，会返回不同类型：
- 当 `rg` 是左值时，`all(rg)` 返回 `std::ranges::ref_view`。
- 当 `rg` 是右值时，`all(rg)` 返回 `std::ranges::owned_view`。
- 若 `rg` 已经是视图，则返回 `rg` 的副本。
```cpp
std::vector<int> getColl(); // function returning a tmp. container
std::vector coll{1, 2, 3}; // a container
std::ranges::iota_view aView{1}; // a view
auto v1 = std::views::all(aView); // decltype(coll)
auto v2 = std::views::all(coll); // ref_view<decltype(coll)>
auto v3 = std::views::all(std::views::all(coll)); // ref_view<decltype(coll)>
auto v4 = std::views::all(getColl()); // owning_view<decltype(coll)>
auto v5 = std::views::all(std::move(coll)); // owning_view<decltype(coll)>

std::vector<int> v{0, 8, 15, 47, 11, -1, 13};
...
std::views::all_t<decltype(v)> a1{v}; // ERROR
std::views::all_t<decltype(v)&> a2{v}; // ref_view<vector<int>>
std::views::all_t<decltype(v)&&> a3{v}; // ERROR
std::views::all_t<decltype(v)> a4{std::move(v)}; // owning_view<vector<int>>
std::views::all_t<decltype(v)&> a5{std::move(v)}; // ERROR
std::views::all_t<decltype(v)&&> a6{std::move(v)}; // owning_view<vector<int>>
```
接受范围的视图通常使用 `std::views::all_t<>` 来确保传递的范围确实是一个视图。因此，若传递的范围不是视图，则会隐式创建视图。例如：
```cpp
std::views::take(coll, 3)
// has the same effect as calling:
std::ranges::take_view{std::ranges::ref_view{coll}, 3};
```
概念 `viewable_range` 用于检查类型是否可用于 `all_t<>`，从而对应的对象可以传递给 `all()`。
```cpp
std::ranges::viewable_range<std::vector<int>> // true
std::ranges::viewable_range<std::vector<int>&> // true
std::ranges::viewable_range<std::vector<int>&&> // true
std::ranges::viewable_range<std::ranges::iota_view<int>> // true
std::ranges::viewable_range<std::queue<int>> // false
```
### std::views::counted()
范围工厂 `std::views::counted()` 提供从 `begin` 迭代器和计数创建视图的最灵活的方式。
```cpp
// 创建一个以 beg 开头的范围的前 sz 个元素的视图
std::views::counted(beg, sz)
```
使用视图时，由调用者来确保 `begin` 和 `count` 是有效的，否则，程序具的行为未定义。计数存储在视图中，因此是稳定的。即使在视图引用的范围中插入新元素，计数也不会改变。 例如:
```cpp
std::list lst{1, 2, 3, 4, 5, 6, 7, 8};
auto c = std::views::counted(lst.begin(), 5);
print(c); // 1 2 3 4 5

lst.insert(++lst.begin(), 0); // insert new second element in lst
print(c); // 1 0 2 3 4
```
但查看一个范围的前 `num` 个元素，`take view` 提供一种更方便、更安全的方式来获取：
```cpp
// take 会视图检查是否有足够的元素，若没有，则产生更少的元素
std::list lst{1, 2, 3, 4, 5, 6, 7, 8};
auto v1 = std::views::take(lst, 3); // view to first three elements (if they exist)

// 通过使用 drop view，甚至可以跳过特定数量的前置元素:
std::list lst{1, 2, 3, 4, 5, 6, 7, 8};
auto v2 = std::views::drop(lst, 2) | std::views::take(3); // 3rd to 5th element (if exist)
```
`counted(beg, sz)` 根据所调用的范围特征，会返回不同类型：
- 若传递的 `begin` 迭代器是一个 `contiguous_iterator`，则会返回 `std::span`，这适用于 `std::vector<>` 或 `std::array<>` 的原始指针、原始数组和迭代器。
- 若传递的 `begin` 迭代器是一个 `random_access_iterator`，就会返回 `std::ranges::subrange`，这适用于 `std::deque<>` 的迭代器。
- 否则，将产生 `std::ranges::subrange`，以 `std::counts_iterator` 作为开始并以 `std::default_sentinel_t` 类型的伪哨兵作为结束，所以子范围中的迭代器在迭代时计数，这适用于列表、关联容器和无序容器(哈希表)的迭代器。
```cpp
auto vec5 = std::ranges::find(vec, 5);
// v1 is std::span<int>
auto v1 = std::views::counted(vec5, 3); 

std::deque<int> deq{1, 2, 3, 4, 5, 6, 7, 8, 9};
auto deq5 = std::ranges::find(deq, 5);
// v2 is std::ranges::subrange<std::deque<int>::iterator>
auto v2 = std::views::counted(deq5, 3); 

std::list<int> lst{1, 2, 3, 4, 5, 6, 7, 8, 9};
auto lst5 = std::ranges::find(lst, 5);
// v3 is std::ranges::subrange<std::counted_iterator<std::list<int>::iterator>, std::default_sentinel_t>
auto v3 = std::views::counted(lst5, 3); 
```
### std::views::common()
范围适配器 `std::views::common()` 为传递的范围生成一个具有统一类型的视图，用于开始迭代器和哨兵，若其迭代器具有不同的类型，则会从传递的参数创建 `std::ranges::common_view`。`std::ranges::common_view` 的构造函数和辅助类型 `std::common::iterator` 都要求传递的迭代器具有不同的类型，所以若不知道迭代器类型是否不同，则应该使用此适配器。 
`common(rg)` 根据所调用的范围特征，会返回不同类型：
- 若 `rg` 已经是一个具有相同开始和结束迭代器类型的视图，则为 `rg` 的副本。
- 若 `rg` 是一个具有相同开始迭代器和结束迭代器类型的范围对象，则为 `rg` 的 `std::ranges::ref_view` 类型。
- 否则，则为 `rg` 的 `std::ranges::common_view` 类型。
```cpp
std::list<int> lst;
std::ranges::iota_view iv{1, 10};
...
auto v1 = std::views::common(lst); // std::ranges::ref_view<decltype(lst)>
auto v2 = std::views::common(iv); // decltype(iv)
auto v3 = std::views::common(std::views::all(vec)); // std::ranges::ref_view<decltype(lst)>

std::list<int> lst {1, 2, 3, 4, 5, 6, 7, 8, 9};
auto vt = std::views::take(lst, 5); // begin() and end() have different types
auto v4 = std::views::common(vt); // std::ranges::common_view<decltype(vt)>
```
## New Iterator Categories
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121354.png)
在 `C++20` 中，类别的细节发生了变化：
- 新的迭代器类别连续，它的迭代器标记类型为 `std::contiguous_iterator_tag`。
- 产生临时对象 (右值) 的迭代器可以拥有比输入迭代器更强的类别，生成引用的要求不再适用于前向迭代器。 
- 输入迭代器不再保证是可复制的，应该只可移动，它的后置自增操作符不再需要产生任何结果，应该用前置自增操作符代替。
以下更改向后不兼容：
- 对于 `std::vector` 或数组等容器的迭代器，不再检查迭代器是否为随机访问迭代器，开发者必须检查迭代器是否支持随机访问
- 前向迭代器、双向迭代器或随机访问迭代器的值是引用的假设不再适用。 
对于迭代器，成员 `iterator_category` 可能并不总有定义。`C++20` 引入一个新的可选迭代器属性 `iterator_concept`，并可以设置该属性来表示一个不同于传统类别的 `C++20` 类别。例如:
```cpp
std::vector vec{1, 2, 3, 4};
auto pos1 = vec.begin();
decltype(pos1)::iterator_category // type std::random_access_iterator_tag
decltype(pos1)::iterator_concept // type std::contiguous_iterator_tag

auto v = std::views::iota(1);
auto pos2 = v.begin();
decltype(pos2)::iterator_category // type std::input_iterator_tag
decltype(pos2)::iterator_concept // type std::random_access_iterator_tag
```
迭代器概念和范围概念考虑了新的 `C++20` 类别。对于必须处理迭代器类别的代码，`C++20` 起会进行如下处理：
- 使用迭代器概念和范围概念来检查类别，而不是 `std::iterator_traits<I>::iterator_category`
- 若自定义迭代器类型，则考虑提供 `iterator_category` 和 `iterator_concept`
有效的 `C++20` 输入迭代器可能根本不是 `C++17` 迭代器 (例如，不提供复制)。对于这些迭代器，传统的迭代器特性不起作用。由于这个原因，从 `C++20` 开始:
- 使用 `std::iter_value_t` 代替 `iterator_traits<>::value_type`
- 使用 `std::iter_reference_t` 代替 `iterator_traits<>::reference`
- 使用 `std::iter_difference_t` 代替 `iterator_traits<>::difference_type`
## New Iterator and Sentinel Types
为更好地支持范围和视图，`C++20` 引入以下新的迭代器和哨兵类型：
- `std::counted_iterator` 表示本身有一个计数来指定范围结束的迭代器
- `std::common_iterator` 表示可用于两个不同类型的 `common` 迭代器
- `std::default_sentinel_t` 表示强制迭代器检查其结束的 `end` 迭代器/哨兵
- `std::unreachable_sentinel_t` 表示永远无法到达的 `end` 迭代器/哨兵
- `std::move_sentinel `表示将副本映射到 `move` 的 `end` 迭代器/哨兵
### std::counted_iterator
类型 `std::counted_iterator` 有一个计数器，表示要迭代的最大元素数。有两种方法可以使用这样的迭代器：
```cpp
// Iterating while checking how many elements are left:
for (std::counted_iterator pos{coll.begin(), 5}; pos.count() > 0; ++pos) {
    std::cout << *pos << '\n';
}

// Iterating while comparing with a default sentinel:
for (std::counted_iterator pos{coll.begin(), 5}; 
         pos != std::default_sentinel; ++pos) {
    std::cout << *pos << '\n';
}
```
当视图适配器 `std::ranges::counted()` 为非随机访问迭代器生成子范围时，就会使用此功能。
类 `std::counted_iterator<>` 的操作表列出了计数迭代器的 `API`。开发者负责确保:
- 初始计数不高于初始传递的迭代器计数
- 计数迭代器的增量不会超过 `count` 次
- 计数迭代器不访问第 `n` 个元素以外的元素
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121428.png)
### std::common_iterator
类型 `std::common_iterator<>` 用于协调两个迭代器的类型，其包装两个迭代器，使得从外部看两个迭代器具有相同的类型。在内部通常使用 `std::variant<>` 存储两种类型之一的值。
接受开始迭代器和结束迭代器的传统算法要求这些迭代器具有相同的类型，若有不同类型的迭代器，可以使用这个类型函数来调用这些算法：
```cpp
algo(beg, end); // if this is an error due to different types
algo(std::common_iterator<decltype(beg), decltype(end)>{beg}, // OK
std::common_iterator<decltype(beg), decltype(end)>{end});
```
若传递给 `common_iterator<>` 的类型相同，则会导致编译时错误，所以在泛型代码中:
```cpp
template<typename BegT, typename EndT>
void callAlgo(BegT beg, EndT end)
{
    if constexpr(std::same_as<BegT, EndT>) algo(beg, end);
    else {
        algo(std::common_iterator<decltype(beg), decltype(end)>{beg},
        std::common_iterator<decltype(beg), decltype(end)>{end});
    }
}

// 要达到同样的效果，更方便的方法是使用 common() 范围适配器:
template<typename BegT, typename EndT>
void callAlgo(BegT beg, EndT end)
{
    auto v = std::views::common(std::ranges::subrange(beg, end));
    algo(v.begin(), v.end());
}
```
### std::default_sentinel
默认哨兵是一个不提供任何操作的迭代器。`std::default_sentinel` 是类型 `std::default_sentinel_t` 的常量，在 `<iterator>` 中提供。该类型没有成员：
```cpp
namespace std {
    class default_sentinel_t {}; // 类型
    inline constexpr default_sentinel_t default_sentinel{}; // 值
}
```
通过提供类型和值作为伪哨兵，使得迭代器无需查看结束迭代器就知道其结束点，这些迭代器会定义与 `std::default_sentinel` 的比较，但并没有使用默认哨兵，而是在内部检查它是否在结束处或距离结束处有多远。
例如，计数迭代器为自己定义一个 `==` 操作符，并带有一个默认的哨兵来检查其是否位于末尾:
```cpp
namespace std {
    template<std::input_or_output_iterator I>
    class counted_iterator {
        ...
        friend constexpr bool operator==(const counted_iterator& p,
        std::default_sentinel_t) {
        ... // returns whether p is at the end
        }
    };
}

// iterate over the first five elements:
for (std::counted_iterator pos{coll.begin(), 5};
    pos != std::default_sentinel; ++pos) {
    std::cout << *pos << '\n';
}
```
标准用默认的哨兵定义以下操作:
- `std::counted_iterator` 使用操作符 `==` 和 `!=` 进行比较，用运算符 `-` 计算距离。
- `std::views::counted()` 可以创建一个计数迭代器的子范围和一个默认的哨兵。
- `std::istream_iterator/std::istreambuf_iterator` 的默认哨兵可以用作初始值，其效果与默认构造函数相同，使用操作符 `==` 和 `!=` 进行比较。
- `std::ranges::basic_istream_view<>` 生成 `std::default_sentinel` 作为 `end()`，使用操作符 `==` 和 `!=` 进行比较。
- `std::ranges::take_view<>` 可能产生 `std::default_sentinel` 作为 `end()`
- `std::ranges::split_view<>` 可能产生 `std::default_sentinel` 作为 `end()`，使用操作符 `==` 和 `!=` 进行比较。
### std::unreachable_sentinel
`std::unreachable_sentinel` 是类型 `std::unreachable_sentinel_t` 的常量，用于指定不可达的哨兵，此类型和值可用于指定无限范围。使用时可以优化生成的代码，编译器可以检测到它与另一个迭代器进行比较时永远不会返回 `true`，所以可能会跳过对末尾的检查。
例如，若知道 42 存在于一个集合中，就可以这样进行搜索:
```cpp
auto pos42 = std::ranges::find(coll.begin(), std::unreachable_sentinel, 42);
```
该算法将同时比较 42 和 `coll.end()`。因为使用 `unreachable_sentinel` 与迭代器的任何比较总是产生 `false` ，编译器可以优化代码，只与 42 进行比较，所以开发者必须确保 42 是存在的。
### std::move_sentinel
`C++11` 起，`C++` 标准库提供迭代器类型 `std::move_iterator` 用于将迭代器的行为从复制映射到移动，`C++20` 引入相应的哨兵类型 `std::move_sentinel`，此类型只能用于使用操作符 `==` 和 `!=` 比较移动哨兵和移动迭代器，并计算移动迭代器和移动哨兵之间的差异。
若有一个形成有效范围的迭代器和一个满足 `std::sentinel_for` 概念的哨兵，可以将它们转换为一个移动迭代器和一个移动哨兵，以获得仍然满足 `sentinel_for` 的有效范围。可以像下面这样移动哨兵：
```cpp
std::list<std::string> coll{"tic", "tac", "toe"};
std::vector<std::string> v1;
std::vector<std::string> v2;

// copy strings into v1:
for (auto pos{coll.begin()}; pos != coll.end(); ++pos) v1.push_back(*pos);

// move strings into v2:
for (std::move_iterator pos{coll.begin()};
    pos != std::move_sentinel(coll.end()); ++pos) 
    v2.push_back(*pos);
```
但迭代器和哨兵具有不同的类型，所以不能直接初始化 `vector`，必须为 `end` 使用移动迭代器：
```cpp
std::vector<std::string> v3{std::move_iterator{coll.begin()}, std::move_sentinel{coll.end()}}; // ERROR
std::vector<std::string> v4{std::move_iterator{coll.begin()}, std::move_iterator{coll.end()}}; // OK
```
## New Functions
范围库在命名空间 `std::ranges` 和 `std` 中提供几个通用的辅助函数。其中一些在 `C++20` 之前就已经存在，在命名空间 `std` 中具有相同的名称或略有不同的名称(并且仍然提供向后兼容性)，但范围工具通常为特定的功能提供更好的支持，可能会修复旧版本的缺陷，或者使用一些概念来限制旧版本的使用，而不修复命名空间 `std` 中的现有函数而是在命名空间 `std::ranges` 中新增函数，是为了向后兼容。
### Functions for Dealing with the Elements of Ranges (and Arrays)
下述表列出处理范围及其元素的新的独立泛型函数，它们也适用于原始数组。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121537.png)
`C++20` 之前，几乎所有相应的工具函数都可以直接在命名空间 `std` 中使用，例外是 `C++20` 中引入新的 `std::ssize()`，`cdata()` 不存在于命名空间 `std` 中。
优先使用命名空间 `std::ranges` 中的函数/工具，而不是命名空间 `std` 中的函数/工具。原因不仅在于命名空间 `std::ranges` 中的函数/工具使用概念，还在于命名空间 `std` 中的函数有时存在缺陷，`std::ranges` 中的新实现实则修复了以下这些缺陷：
- 参数相关查找 ADL
- `const` 的正确性
在处理泛型代码中的范围时，使用 `std::ranges::begin()` 比使用 `std::begin()` 更好，因为若不巧妙地使用 `std::begin()`，依赖于参数的查找并不总是有效。
假设要编写泛型代码，调用为范围对象 `obj` 定义的 `begin()` 函数。问题在于容器等范围类型需要有 `begin()` 成员函数，但对于原始数组这种类型只有非成员的 `begin()`。若使用非成员的 `begin()`，用于原始数组的标准 `std::begin()` 需要使用 `std::` 进行限定，但其他非标准范围不能处理完整的限定条件 `std::`。例如：
```cpp
class MyColl {...}; // 非标准范围

MyColl obj;
std::begin(obj); // std::begin() does not find ::begin(MyType)

// The new std::ranges::begin() does not have this problem:
std::ranges::begin(obj); // OK, works in all these cases
```
必要的解决方法是在 `begin()` 前添加一个额外的 `using` 声明，并且不限定调用本身：
```cpp
using std::begin;
begin(obj); // OK, works in all these cases
```
`begin` 不是一个使用依赖参数查找的函数，而是一个实现所有可能查找的函数对象。
上述适用于 `std::ranges` 中定义的所有工具，所以使用 `std::ranges` 工具的代码通常支持更多类型和更复杂的用例。
### Functions for Dealing with Iterators
下述表列出所有用于移动迭代器、向前或向后查找以及计算迭代器之间距离的泛型函数。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121600.png)
同样，比起命名空间 `std` 中对应的传统工具，更推荐这些。例如，与 `std::ranges::next()` 相比，`std::next()` 要求为传递的迭代器 `It` 提供`std::iterator_traits<It>::difference_type`。但某些视图类型的内部迭代器不支持迭代器特性，因此若使用 `std::next()`，代码可能无法编译。
### Functions for Swapping and Moving Elements/Values
范围库还提供交换和移动值的函数，用于交换和移动元素。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121610.png)
因为标准概念 `std::swappable` 和 `std::swappable_with` 使用 `std::ranges::swap()`，因此它在 `<concepts>` 中定义。 函数 `std::ranges::iter_swap()` 和 `std::ranges::iter_move()` 则在 `<iterator>` 中定义。
`std::ranges::swap()` 修复在泛型代码中，`std::swap()` 可能找不到为某些类型提供的最佳交换函数的问题。考虑下面的例子：
```cpp
struct Foo {
    Foo() = default;
    Foo(const Foo&) {
        std::cout << " COPY constructor\n";
    }
    Foo& operator=(const Foo&) {
        std::cout << " COPY assignment\n";
        return *this;
    }
    void swap(Foo&) {
        std::cout << " efficient swap()\n"; // swaps pointers, no data
    }
};

void swap(Foo& a, Foo& b) {
    a.swap(b);
}

Foo a, b;
std::cout << "--- std::swap()\n";
std::swap(a, b); // generic swap called

// 同上，添加 using 声明而不限定本身
using std::swap;
swap(a, b); // Foo::swap called

std::cout << "--- std::ranges::swap()\n";
std::ranges::swap(a, b); // Foo::swap swap called
```
`std::move()` 或 `swap()` 必须传入解引用迭代器，而 `std::ranges::iter_move()` 或 `std::ranges::iter_swap()` 只需要传入迭代器不需要解引用：
```cpp
// 使用:
auto val = std::ranges::iter_move(it);
std::ranges::iter_swap(it1, it2);

// 而不是:
auto val = std::move(*it);
using std::swap;
swap(*it1, *it2);
```
### Functions for Comparisons of Values
下述表列出用作比较标准的所有范围工具，其在`<functional>` 中定义。检查相等性时，可以使用概念 `std::equality_comparable_with`，检查顺序时，可以使用 `std::totally_ordered_with` 概念。这并不要求必须支持 `<=>` 操作符，并且该类型不必支持全序，只要求能用 `<`、`>`、`<=` 和 `>=` 比较，但这是一个在编译时无法检查的语义约束。
`C++20` 还引入函数对象类型 `std::compare_three_way`，可以用它来使用新的操作符 `<=>`。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121642.png)
## New Type Functions/Utilities for Dealing with Ranges
### Generic Types of Ranges
下述表列出范围的所有泛型类型定义，它们是使用范围时产生所涉及类型的泛型函数，被定义为别名模板。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121658.png)
这些类型函数的主要优点是它们一般适用于所有类型的范围和视图，甚至适用于原始数组。
### Generic Types of Iterators
范围库为迭代器引入了新的类型特征，这些特征不是在命名空间 `std::ranges` 中定义的，而是在命名空间 `std` 中定义的。下述表列出迭代器的所有泛型类型特征，它们是使用迭代器时产生所涉及类型的泛型函数，被定义为别名模板。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121707.png)
下述表列出用于处理迭代器的所有新类型，它们是迭代器的其他新类型，在 `<iterator>` 中定义。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121732.png)
### New Functional Types
新函数类型表列出可作为辅助函数使用的新类型，在 `<functional>` 中定义。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121717.png)
若算法支持传递投影，函数对象 `std::identity` 通常用于在可以传递投影的地方不传递投影：
```cpp
auto pos = std::ranges::find(coll, 25, // find value 25
            [](auto x) {return x*x;}); // for squared elements
            
// using std::identity enables programmers to pass “no projection:”
auto pos = std::ranges::find(coll, 25, // find value 25
                            std::identity{}); // for elements as they are
```
因此函数对象 `std::identity` 函数对象用作默认模板形参，用于声明可以跳过投影的算法：
```cpp
template<std::ranges::input_range R,
typename T,
typename Proj = std::identity>
constexpr std::ranges::borrowed_iterator_t<R>
find(R&& r, const T& value, Proj proj = {});
```
函数对象类型 `std::compare_three_way` 用于指定调用新的 `<=>` 操作符，就像 `std::less` 或 `std::ranges::less` 表示调用操作符 `<`。
## Range Algorithms
由于支持将范围作为一个参数传递，并且能够处理不同类型的哨兵，`C++20` 提供调用算法的新方法。但其有一些限制，并不是所有的算法都支持传递范围。
### Benefits and Restrictions for Range Algorithms
对于某些算法，还没有允许开发者将范围作为单个参数传递的版本:
- 范围算法不支持并行执行，没有` API` 将范围参数作为单个对象和执行策略。
- 目前还没有针对单对象范围的数值算法。要调用像 `std::accumulate()` 这样的算法，仍然必须传递范围的开始和结束。
若算法支持范围，则会使用概念在编译时查找可能的错误：
- 迭代器和范围的概念确保传递有效的迭代器和范围。
- 可调用对象的概念确保传递有效的辅助函数。
下表列出范围算法的新返回类型，还可能返回租借迭代器。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121743.png)
### Algorithm Overview
本节概述哪些算法以哪种形式可用:
• `Ranges` 表示该算法范围库是否支持
• `_result` 指示是否使用以及使用哪些 `_result` 类型 (例如，`in_out` 表示 `in_out_result`)
• `Borrowed` 指示算法是否返回租借迭代器
不修改算法表列出 `C++20` 中可用的不可修改标准算法
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121801.png)
修改算法表列出 `C++20` 中可用的修改标准算法。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121806.png)
可移除算法表列出可用的移除标准算法，但算法从来没有真正地删除元素，只是改变顺序，将未删除的元素移动到前面，并返回新的 `end` 迭代器。当它们将整个范围作为单个参数时，这仍然适用。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121811.png)
可变异算法表列出可用的变异标准算法。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121817.png)排序算法表列出中可用的排序标准算法。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121821.png)
用于已排序范围的算法表中列出用于排序范围的标准算法。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121827.png)
数学算法表列出可用的数学标准算法。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214121831.png)
# View Types in Detail
## Overview of All Views
本章概述 `C++20` 中所有可用的视图类型，对于几乎所有这些类型，都有辅助的范围适配器/工厂，允许开发者通过调用函数或管道来创建视图。应该使用这些适配器和工厂，而不是直接初始化视图，因为适配器和工厂执行额外的优化，可以在更多的情况下工作，对需求进行双重检查，并且更容易使用。
### Overview of Wrapping and Generating Views
包装和生成视图表列出只能作为管道源元素的标准视图，以及视图的类型和可用于创建视图的范围适配器/工厂的名称(若有的话)。
- 包装视图，对外部资源的元素序列进行操作，例如从输入流读取的容器或元素
- 工厂视图，自己生成元素
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214125810.png)
视图类型使用不同的命名空间:
- `span` 和 `string_view` 在命名空间 `std` 中。
- 所有范围适配器和工厂都在命名空间 `std::views` 中提供，它是 `std::ranges::views` 的别名。
- 所有其他视图类型都在命名空间 `std::ranges` 中提供。
一般来说，最好使用范围适配器和工厂，应该倾向于使用适配器 `std::views::all()`，而不是直接使用类型 `std::ranges::ref_view<>` 和 `std::ranges::owning_view<>`。然而，在某些情况下，没有提供适配器/工厂，只能直接使用视图类型，例如当必须从一对迭代器创建视图时，必须直接初始化 `std::ranges::subrange`。
### Overview of Adapting Views
适配视图表列出以某种方式适配给定范围的元素的标准视图(过滤掉元素、修改元素的值、改变元素的顺序，或者组合或创建子范围)，尤其可以在视图的管道中使用。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214125823.png)
同样，推荐使用范围适配器，而不是直接使用视图类型：
- 应该倾向于使用适配器 `std::views::take()`，而不是类型 `std::ranges::take_view<>`，当可以简单地跳转到底层范围的第 n 个元素时，适配器可能根本不会创建获取视图。
- 应该总是使用适配器 `std::views::common()`，而不是类型 `std::ranges::common_view<>`，因为只有适配器允许传递相同类型的范围，用 `common_view` 包装相同类型的范围会导致编译时错误。
## Base Class and Namespace of Views
### Base Class for Views
所有标准视图都派生自类 `std::ranges::view_interface`。
类模板 `std::ranges::view_interface<>` 基于派生视图类型的 `begin()` 和 `end()` 的定义引入了一系列基本成员函数，这些函数必须作为模板参数传递给这个基类。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214125847.png)
类 `view_interface<>` 还为派生自它的每个类型初始化 `std::ranges::enable_view<>`，因此这些类型满足 `std::ranges::view` 概念。当自定义视图类型时，应该从 `view_interface<>` 派生，并将自己的类型作为参数传递。例如：
```cpp
template<typename T>
class MyView : public std::ranges::view_interface<MyView<T>> {
public:
... begin() ... ;
... end() ... ;
...
};
```
基于 `begin()` 和 `end()` 的返回类型，自己的类型自动提供 `std::ranges::view_interface<>` 的操作表中列出的成员函数。这些成员函数的 `const` 版本要求 `const` 版本的视图类型是一个有效范围。
### Why Range Adaptors/Factories Have Their Own Namespace
范围适配器和工厂有自己的命名空间 `std::ranges::views`，并定义命名空间别名 `std::views`:这样就可以使用可能在其他命名空间中被使用视图名称。当使用的时候需要进行限定：
```cpp
namespace std {
    namespace views = ranges::views;
}

std::ranges::views::reverse // full qualification
std::views::reverse // shortcut
```
通常，不加限定地使用视图是不可能的。`ADL` 不会进行，因为在命名空间 `std::views` 中没有定义范围：
```cpp
std::vector<int> v;
...
take(v, 3) | drop(2); // ERROR: can’t find views (may find different symbol)
```
因此，永远不要使用 `using` 声明跳过范围适配器的限定，以自定义的过滤视图 `composers` 为例：
```cpp
std::vector<int> values;
std::map<std::string, int> composers{ ... };

using namespace std::views; // do not do this
for (const auto& elem : composers | values) {...} // OOPS: finds wrong values
```
本例中，将使用本地 `vector` 值，而非视图，可能会得到一个编译时错误，也可能非限定视图会找到不同的符号，甚至出现覆盖其他对象内存的未定义行为。
## Source Views to External Elements
本节讨论 `C++20` 中创建引用现有外部值的视图的所有特性，通常作为单个范围参数传递，作为开始迭代器和哨兵，或作为开始迭代器和计数。
### Subrange
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214125951.png)
类模板 `std::ranges::subrange<>` 定义一个范围元素的视图，通常以开始迭代器和哨兵(结束迭 代器)对的形式传递，也可以传递单个范围对象，并间接传递开始迭代器和计数。在内部，视图本身通过存储开始迭代器和结束迭代器(哨兵)来表示元素。
主要用例是将一对开始迭代器和哨兵转换为一个对象。例如:
```cpp
std::vector<int> coll{0, 8, 15, 47, 11, -1, 13};
std::ranges::subrange s1{std::ranges::find(coll, 15), std::ranges::find(coll, -1)};
print(coll); // 15 47 11
```
可以用结束值的特殊哨兵来初始化子范围：
```cpp
std::ranges::subrange s2{coll.begin() + 1, EndValue<-1>{}};
print(s2); // 8 15 47 11
```
这两种方法在将一对迭代器转换为范围/视图时都特别有用，这样范围适配器就可以处理元素：
```cpp
void foo(auto beg, auto end) {
    // init view for all but the first five elements (if there are any):
    auto v = std::ranges::subrange{beg, end} | std::views::drop(5);
    ...
}
```
下述是一个例子：
```cpp
void printPairs(auto&& rg)
{
    for (const auto& [key, val] : rg) 
        std::cout << key << ':' << val << ' ';
    std::cout << '\n';
}

// English/German dictionary:
std::unordered_multimap<std::string,std::string> dict = {
    {"strange", "fremd"},
    {"smart", "klug"},
    {"car", "Auto"},
    {"smart","raffiniert"},
    {"trait", "Merkmal"},
    {"smart", "elegant"},
};

// equal_range() 返回键为 smart 的 dict 中所有元素的开头和结尾:
auto [beg, end] = dict.equal_range("smart");
// 使用一个子范围将这两个迭代器转换为一个视图
// 将视图传递给 printPairs()，遍历元素并输出
printPairs(std::ranges::subrange(beg, end));
```
子范围可以改变它的大小，以便在 `begin` 和 `end` 都有效的情况下在 `begin` 和 `end` 之间插入或删除元素：
```cpp
std::list coll{1, 2, 3, 4, 5, 6, 7, 8};
auto v1 = std::ranges::subrange(coll.begin(), coll.end());
print(v1); // 1 2 3 4 5 6 7 8
coll.insert(++coll.begin(), 0);
coll.push_back(9);
print(v2); // 1 0 2 3 4 5 6 7 8 9
```
#### Range Factories for Subranges
没有范围工厂用于从 `begin` 和 `end` 初始化子范围，但有一个范围工厂可以从 `begin` 和 `count` 创建子范围：
```cpp
std::views::counted(rg.begin(), sz);
// 相当于
std::ranges::subrange{std::counted_iterator{rg.begin(), sz}, std::default_sentinel};
```
`std::views::counted()` 从迭代器 `begin` 引用的元素开始创建一个包含非连续范围的前 `sz` 个元素的子范围，而对于连续范围，`counts()` 创建一个 `span` 视图。当 `std::views::counted()` 创建子范围时，子范围以 `std::counted_iterator` 作为开始，以 `std::default_sentinel_t` 类型的伪哨兵作为结束
这样做的效果是，即使插入或删除元素，该子范围内的计数仍然保持稳定:
```cpp
std::list coll{1, 2, 3, 4, 5, 6, 7, 8};
auto v2 = std::views::counted(coll.begin(), coll.size());
print(v2); // 1 2 3 4 5 6 7 8
coll.insert(++coll.begin(), 0);
coll.push_back(9);
print(v2); // 1 0 2 3 4 5 6 7
```
#### Special Characteristics of Subranges
子范围可以是也可以不是一个 `sized range`，因为子范围第三个模板形参是枚举类型 `std::ranges::subrange_kind`，其值可以是 `std::ranges::unsized` 或 `std::ranges::sized`。该模板形参的值可以指定，也可以从为迭代器和哨兵类型调用的 `std::sized_sentinel_for` 概念派生。
```cpp
// If you pass contiguous or random-access iterators of the same type, 
// the subrange is sized:
std::vector vec{1, 2, 3, 4, 5}; // has random access
...
std::ranges::subrange sv{vec.begin()+1, vec.end()-1}; // sized
std::cout << std::ranges::sized_range<decltype(sv)>; // true

// If you pass iterators that do not support random access or 
// that are not common, the subrange is notsized:
std::list lst{1, 2, 3, 4, 5}; // no random access
...
std::ranges::subrange sl{++lst.begin(), --lst.end()}; // unsized
std::cout << std::ranges::sized_range<decltype(sl)>; // false

// In the latter case, you can pass a size to make a subrange a sized range:
std::list lst{1, 2, 3, 4, 5}; // no random access
...
std::ranges::subrange sl2{++lst.begin(), --lst.end(), lst.size()-2}; // sized
std::cout << std::ranges::sized_range<decltype(sl2)>; // true
```
但如果用错误的大小初始化视图，或者在开始和结束之间插入或删除元素之后使用视图，将是未定义行为。
#### Interface of Subranges
类 `std::ranges::subrange<>` 的操作表列出子范围的 `API`。只有当迭代器是默认可初始化时，才提供默认构造函数。使用 `szHint` 参数的构造函数，允许将 `unsized range` 转换为 `sized subrange`。子范围的迭代器指向底层(或临时创建的)范围，所以子范围是租借范围，但当底层范围不再存在时，迭代器仍然悬空。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130119.png)
`std::ranges::subange` 有一个类似于元组的接口来支持结构化绑定，所以可以很容易地初始化一个开始迭代器和一个哨兵(结束迭代器)，方法如下:
```cpp
auto [beg, end] = std::ranges::subrange{coll};
```
为此，类 `std::ranges::subange` 提供
- `std::tuple_size<>` 的特化
- `std::tuple_element<>` 的特化
- 获取索引 0 和 1 的 `get<>()` 函数
#### Using Subranges to Harmonize Raw Array Types
子范围的类型仅取决于迭代器的类型以及是否提供 `size()`，这可以用来协调原始数组的类型。考虑下面的例子：
```cpp
int a1[5] = { ... };
int a2[10] = { ... };
std::same_as<decltype(a1), decltype(a2)> // false
std::same_as<decltype(std::ranges::subrange{a1}), decltype(std::ranges::subrange{a2})> // true
```
这只适用于原始数组，对于 `std::array<>` 和其他容器，迭代器可能具有不同的类型，所以协调的类型与子范围不可移植。
### Ref View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130134.png)
类模板 `std::ranges::ref_view<>` 定义一个引用范围的视图，通过值传递视图的效果就像通过引用传递范围一样。其效果类似于 `std::reference_wrapper<>` 类型，对使用 `std::ref()` 和 `std::cref()` 创建的第一类对象进行引用，这个包装器的好处是仍然可以直接用作范围。
`ref_view` 的用例是将容器转换为复制成本较低的轻量级对象，将容器传递给协程(通常必须按值接受参数)可能是这种技术的一种应用。例如:
```cpp
void foo(std::ranges::input_range auto coll) // NOTE: takes range by value
{
    for (const auto& elem : coll) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

std::vector<std::string> coll{"love", "of", "my", "life"};
printByVal(coll); // copies coll
printByVal(std::ranges::ref_view{coll}); // pass coll by reference
printByVal(std::views::all(coll)); // ditto (using a range adaptor)
```
对于左值，使用 `ref_view`，对于右值，必须使用 `owning_view`。：
```cpp
std::vector coll{0, 8, 15};
...
std::ranges::ref_view v1{coll}; // OK, refers to coll
std::ranges::ref_view v2{std::move(coll)}; // ERROR
std::ranges::ref_view v3{std::vector{0, 8, 15}}; // ERROR
```
#### Range Adaptors for Ref Views
`ref view` 可以(通常应该)用范围工厂创建，`all()` 的返回类型是 `std::views::all_t<>` ，`all(rg)` 根据所传入的参数，会返回不同类型：
- 当 `rg` 是左值时，`all(rg)` 返回 `std::ranges::ref_view`。
- 当 `rg` 是右值时，`all(rg)` 返回 `std::ranges::owned_view`。
- 若 `rg` 已经是视图，则返回 `rg` 的副本。
此外，若向其他接受范围的视图传递不是视图的左值，则间接地为传递的范围调用 `all()`，几乎所有范围适配器也都会创建一个 `ref_view`：
```cpp
std::views::take(coll, 3)
// 等价于
std::ranges::take_view{std::ranges::ref_view{coll}, 3};
```
#### Special Characteristics of Ref Views
`ref view` 存储对底层范围的引用，所以 `ref view` 是一个租借范围。只要引用的视图有效，就可以使用它。例如，若底层视图是一个 `vector`，重新分配并不会使该视图失效，但当底层范围不再存在时，迭代器仍然可以悬空。
#### Interface of Ref Views
类 `std::ranges::ref_view<>` 的操作表列出 `ref_view` 的 `API`，没有为这个视图提供默认构造函数。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130231.png)
### Owning View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130243.png)
类模板 `std::ranges::owning_view<>` 定义一个获取另一个范围元素所有权的视图。这是唯一可能拥有多个元素的视图，但构造成本仍然很低，因为初始范围必须是右值，构造函数将范围移动到视图的内部成员。
```cpp
std::vector vec{0, 8, 15};
std::ranges::owning_view v0{vec}; // ERROR
std::ranges::owning_view v1{std::move(vec)}; // OK
print(v1); // 0 8 15
print(vec); // unspecified value (was moved away)

std::array<std::string, 3> arr{"tic", "tac", "toe"};
std::ranges::owning_view v2{arr}; // ERROR
std::ranges::owning_view v2{std::move(arr)}; // OK
print(v2); // "tic" "tac" "toe"
print(arr); // "" "" ""
```
这是 `C++20` 中唯一一个完全不支持复制的标准视图，只能移动。例如:
```cpp
std::vector coll{0, 8, 15};
std::ranges::owning_view v0{std::move(coll)};
auto v3 = v0; // ERROR
auto v4 = std::move(v0); // OK (range in v0 moved to v4)
```
`owning_view` 的主要用例是从一个范围创建视图，而不再依赖于范围的生命周期。例如:
```cpp
void foo(std::ranges::view auto coll) // NOTE: takes range by value
{
    for (const auto& elem : coll) 
    ...
}
std::vector<std::string> coll{ ... };
foo(coll); // ERROR: no view
foo(std::move(coll)); // ERROR: no view
foo(std::ranges::owning_view{coll}); // ERROR: must pass rvalue
foo(std::ranges::owning_view{std::move(coll)}); // OK: move coll as view
```
#### Range Adaptors for Owning Views
`owning view` 可以(通常应该)用范围工厂创建:
```cpp
std::views::all(rg)
foo(std::views::all(std::move(coll))); // move coll as view
```
`std::views::all()` 为传入的范围 `rg` 创建一个 `owning_view`，前提是 `rg` 是一个右值而不是一个视图，若已经是一个视图则返回 `rg`，否则传递左值则返回 `ref` 视图。 
此外，若向其他接受范围的视图传递不是视图的右值，则间接地为传递的范围调用 `all()`，几乎所有范围适配器也都会创建一个 `owning_view`：
```cpp
auto getColl() {
    return std::vector<std::string>{"you", "don't", "fool", "me"};
}

std::ranges::owning_view v1 = getColl(); // view owning a vector of strings
auto v2 = std::views::all(getColl()); // ditto
static_assert(std::same_as<decltype(v1), decltype(v2)>);

// 创建 std::ranges::drop_view<std::ranges::owning_view<vector<string>>>
// 这是通过使用 std::views::all_t<> 对传递的临时范围间接调用 all() 实现的
for (const auto& elem : getColl() | std::views::drop(1)) 
    std::cout << elem << ' ';
std::cout << '\n';
```
#### Special Characteristics of Owning Views
`owning_view` 将传递的范围移动到自身，若拥有的范围是租借范围，则 `owning_view` 是租借范围。
#### Interface of Owning Views
类 `std::ranges::owning_view<>` 的操作表列出 `owning_view` 的 `API`，只有当迭代器是默认可初始化时，才提供默认构造函数。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130404.png)
### Common View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130413.png)
类模板 `std::ranges::common_view<>` 是协调范围的开始迭代器和结束迭代器类型的视图，以便能够将其传递给需要相同迭代器类型的代码。 注意，视图的构造函数要求传递的范围不是 `common range`(迭代器有不同的类型)。例如:
```cpp
std::list<int> lst{1, 2, 3, 4, 5, 6, 7, 8, 9};
auto v1 = std::ranges::common_view{lst}; // ERROR: is already common
auto take5 = std::ranges::take_view{lst, 5}; // yields no common view
auto v2 = std::ranges::common_view{take5}; // OK
```
#### Range Adaptors for Common Views
通用视图可以(通常应该)使用范围适配器创建，可以使得从已经是 common 的范围中创建 common view 不会引发编译时错误。
`std::views::common()` 创建一个引用 `rg` 的 `common_view`，若 `rg` 已经是 `common`，返回 `std::views::all(rg)`：
```cpp
std::views::common(rg)

std::list<int> lst{1, 2, 3, 4, 5, 6, 7, 8, 9};
auto v1 = std::views::common(lst); // OK
auto take5 = std::ranges::take_view{lst, 5}; // yields no common view

auto v2 = std::views::common(take5); // v2 is common view
std::vector<int> coll{v2.begin(), v2.end()}; // OK
```
通用视图的主要用例是将具有不同类型的范围或视图的 `begin` 和 `end` 迭代器传递给需要 `begin` 和 `end` 具有相同类型的泛型代码。一个典型的例子是将，将范围的开始和结束传递给容器构造函数或传统算法。例如:
```cpp
std::list<int> lst {1, 2, 3, 4, 5, 6, 7, 8, 9};
auto v1 = std::views::take(lst, 5); // Note: types of begin() and end() differ
std::vector<int> coll{v1.begin(), v1.end()}; // ERROR: containers require the same type
auto v2 = std::views::common(std::views::take(lst, 5)); // same type now
std::vector<int> coll{v2.begin(), v2.end()}; // OK
```
#### Interface of Common Views
类 `std::ranges::common_view<>` 的操作表列出通用视图的 `API`。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130504.png)
## Generating Views
本节讨论 `C++20` 中用于创建生成值的视图的所有特性(不引用视图外部的元素或值)。
### Iota View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130530.png)
类模板 `std::ranges::iota_view<>` 是一个生成序列值的视图，这些值可以是整型，也可以使用自加操作符生成指针或迭代器序列，序列可能有限，也可能无限。
`iota` 视图的主要用例是提供在一系列值上迭代的视图或支持创建 `iota` 视图子视图的泛型代码。例如：
```cpp
std::ranges::iota_view v1{1, 100}; // view with values: 1, 2, ... 99
for (auto val : v1) 
    std::cout << val << '\n'; // print these values

// generic function to drop the first element from a view:
auto dropFirst = [] (auto v) {
    return decltype(v){++v.begin(), v.end()};
};
std::ranges::iota_view v1{1, 9}; // iota view with elems from 1 to 8
auto v2 = dropFirst(v1); // iota view with elems from 2 to 8
```
#### Range Adaptors for Iota Views
```cpp
std::views::iota(val)
std::views::iota(val, endVal)
For example:
for (auto val : std::views::iota(1, 100)) // iterate over values 1, 2, ... 99
    std::cout << val << '\n'; // print these values
```
#### Special Characteristics of Iota Views
因为迭代器持有当前值，所以 `iota` 视图是租借范围，其迭代器的生命周期不依赖于视图。若 `iota` 视图有限，并且结束值与开始值具有相同的类型，则该视图是一个 `common view`。若 `iota` 视图无限，或者结束的类型不同于开始的类型，则不是，这是必须使用 `common_view` 来协调开始迭代器和哨兵(结束迭代器)的类型。
#### Interface of Iota Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130558.png)
声明 `iota` 视图时:
```cpp
std::ranges::iota_view v1{1, 100}; // range with values: 1, 2, ... 99
```
`v1` 的类型由 `std::ranges::iota_view` 推导而出并创建提供基本 API 的对象，可以使用 `begin()` 和 `end()` 得到这些值的迭代器。迭代器在内部存储当前值，并用迭代器递增当前值：
```cpp
std::ranges::iota_view v1{1, 100}; // range with values: 1, 2, ... 99
auto pos = v1.begin(); // initialize iterator with value 1
std::cout << *pos; // print current value (here, value 1)
++pos; // increment to next value (i.e., increment value to 2)
std::cout << *pos; // print current value (here, value 2)
```
因此，值的类型必须支持自增操作符，所以 `bool` 或 `std::string` 这样的类型就不行。
迭代器的类型取决于 `iota_view` 的实现，所以必须使用 `auto` 或` std::ranges::iterator_t<>`：
```cpp
std::ranges::iterator_t<decltype(v1)> pos = v1.begin();
```
只有当小写字母具有连续的值 如 `ASCII` 或 `ISO-Latin-1` 或 `UTF-8` 的情况时，视图才只迭代小写字符。通过使用 `char8_t`，可以确保这是可移植的 `UTF-8` 字符：
```cpp
std::ranges::iota_view letters{u8'a', u8'z'+1}; // UTF-8 values from a to z

// If no end value is passed, the view is unlimited 
// and generates an endless sequence of values:
std::ranges::iota_view v2{10L}; // unlimited range with values: 10L, 11L, 12L, ...
std::ranges::iota_view<int> v3; // unlimited range with values: 0, 1, 2, ...
```
v3 的类型是 `std::ranges::iota_view<int, std::unreachable_sentinel_t>`，所以 `end()` 会生成 `std::unreachable_sentinel`。 
无限视图是无尽的，当迭代器表示最大值并迭代到下一个值时，调用自增操作符，这在形式上是未定义行为，实践中，执行通常会溢出，下一个值是值类型的最小值。
#### Using Iota Views to Iterate over Pointers and Iterators
可以用迭代器或指针初始化 `iota` 视图，元素是迭代器/指针，而非值。可以使用它来处理指向范围中所有元素的迭代器：
```cpp
std::list<int> coll{2, 4, 6, 8, 10, 12, 14};
...
// pass iterator to each element to foo():
for (const auto& itorElem : std::views::iota(coll.begin(), coll.end()))
    std::cout << *itorElem << '\n';
```
也可以使用这个特性初始化带有迭代器的容器，该迭代器指向集合 `coll` 的所有元素:
```cpp
std::ranges::iota_view itors{coll.begin(), coll.end()};
std::vector<std::ranges::iterator_t<decltype(coll)>> refColl{itors.begin(), itors.end()};

// Note that if you skip the specification of the element type of refColl, 
// you have to use parentheses. 
std::vector refColl(itors.begin(), itors.end());

// Otherwise, you would initialize the vector with two iterator elements
```
### Single View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130647.png)
类模板 `std::ranges::single_view<>` 是拥有一个元素的视图。除非值类型是 `const`，否则可以对值进行修改。`single` 视图的行为大致类似于一个元素的低成本集合，并且没有分配堆上的内存。 
`single` 视图的主要用例是调用泛型代码来操作只有一个元素/值的视图，这可以用于测试用例，或者用于必须提供只有一个元素的视图的特定上下文中：
```cpp
std::ranges::single_view<int> v1{42}; // single view
for (auto val : v1) {...} // called once 
```
#### Range Adaptors for Single Views
```cpp
for (auto val : std::views::single(42)) {... // called once}
```
#### Special Characteristics of Single Views
`single` 视图基于 `std::ranges::contiguous_range` 和 `std::ranges::sized_range` 概念建模。
接受值的构造函数复制或移动该值到视图中，所以视图不引用初始值，将元素类型声明为引用将不能编译。因为 `begin()` 和 `end()` 会生成相同的值，所以视图总是一个 `common` 范围。因为迭代器引用存储在视图中的值，以便能对其进行修改，所以单视图不是一个租借范围。
#### Interface of Single Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130810.png)
若调用构造函数时没有传递初始值，则单视图中的元素将值初始化，所以要么使用其 `Type` 的默认构造函数，要么用 `0`、`false` 或 `nullptr` 初始化值。
要用需要多个初始化器的对象初始化单视图时，有两个选择:
```cpp
// Passing the initialized object:
std::ranges::single_view sv1{std::complex{1,1}};
auto sv2 = std::views::single(std::complex{1,1});

// Passing the initial values as arguments after an argument std::in_place:
std::ranges::single_view<std::complex<int>> sv4{std::in_place, 1, 1};
```
对于 `non-const single` 视图，可以修改值：
```cpp
std::ranges::single_view v2{42};
std::cout << v2.front() << '\n'; // prints 42
++v2.front(); // OK, modifies value of the view
std::cout << v2.front() << '\n'; // prints 43

std::ranges::single_view<const int> v3{42};
++v3.front();
```
### Empty View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130837.png)
类模板 `std::ranges::empty_view<>` 是一个没有元素的视图，但必须指定元素类型。空视图的主要用例是调用具有低成本视图的泛型代码，该视图没有元素，并且类型系统知道它没有元素，这可以用于测试用例，或者用于视图不能有元素的特定上下文中：
```cpp
std::ranges::empty_view<int> v1; // empty view
for (auto val : v1) {...} // never called
```
#### Range Adaptors for Empty Views
空视图的范围工厂是一个变量模板，所以用模板参数声明：
```cpp
for (auto val : std::views::empty<int>) {...} // never called
```
#### Special Characteristics of Empty Views
空视图的行为大致类似于空 `vector`，还基于 `std::ranges::contiguous_range`(即 `std::ranges::random_access_range`) 和 `std::ranges::sized_range`  概念 
因为 `begin()` 和 `end()` 总是产生 `nullptr`，所以该范围既是 `common` 范围，又是租借范围。
#### Interface of Empty Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130907.png)
空视图提供 `front()`、`back()` 和 `[]` 操作符，但其行为总是未定义的。
### IStream View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214130921.png)
类模板 `std::ranges::basic_istream_view<>` 是一个从输入流中读取元素的视图。与通常的流类型一样，该类型是字符类型的泛型，并提供 `char` 和 `wchar_t` 的特化：
- 类模板 `std::ranges::istream_view<>` 是使用 `char` 类型的字符从输入流中读取元素的视图。
- 类模板 `std::ranges::wistream_view<>` 是使用 `wchar_t` 类型的字符从输入流中读取元素的视图。
```cpp
std::istringstream myStrm{"0 1 2 3 4"};
for (const auto& elem : std::ranges::istream_view<int>{myStrm}) 
    std::cout << elem << '\n';
```
#### Range Adaptors for IStream Views
工厂使用传入范围的字符类型，将参数传递给 `std::ranges::basic_istream_view` 构造函数：
```cpp
std::istringstream myStrm{"0 1 2 3 4"};
for (const auto& elem : std::views::istream<int>(myStrm)) {
    std::cout << elem << '\n';
}
// or:
std::wistringstream mywstream{L"1.1 2.2 3.3 4.4"};
auto vw = std::views::istream<double>(mywstream);
```
`vw` 的初始化相当于:
```cpp
auto vw2 = std::ranges::basic_istream_view<double, wchar_t>{myStrm};
auto vw3 = std::ranges::wistream_view<double>{myStrm};
```
#### IStream Views and const
不能迭代 `const istream` 视图：
```cpp
void printElems(const auto& coll) {
    for (const auto elem& e : coll) 
        std::cout << elem << '\n';
}
std::istringstream myStrm{"0 1 2 3 4"};
printElems(std::views::istream<int>(myStrm)); // ERROR
```
`begin()` 仅为 `non-const istream` 视图提供，因为值分 `begin()/++` 和解引用两步处理，并且值存储在视图中：
```cpp
std::istringstream myStrm{"stream with very-very-very-long words"};
auto v = std::views::istream<std::string>(myStrm);
for (auto pos = v.begin(); pos != v.end(); ++pos) 
    std::cout << *pos << '\n';
```
当迭代器 `pos` 遍历视图 `v` 时，使用` begin()` 和 `++` 从输入流 `myStrm` 中读取字符串，这些字符串必须存储在内部，以便可以通过解引用操作符使用。若将字符串存储在迭代器中，迭代器可能必须为该字符串保存内存，复制迭代器必须复制该内存。复制迭代器的代价不应该太高，所以视图将字符串存储在视图中，从而可在迭代的同时时修改视图。 
因此，必须在泛型代码中使用通用/转发引用来支持此视图:
```cpp
void printElems(auto&& coll) {...}
```
#### Interface of IStream Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131004.png)
所能做的就是使用迭代器逐值读取，直到到达流的末尾，没有提供其他成员函数。
```cpp
// You can fully specify all template parameters:
std::ranges::basic_istream_view<int, char, std::char_traits<char>> v1{myStrm};

// The last template parameter has a working default value, meaning that you can use:
std::ranges::basic_istream_view<int, char> v2{myStrm}; // OK

// However, you cannot skip more parameters:
std::ranges::basic_istream_view<int> v3{myStrm}; // ERROR

// However, the istream views follow the usual convention
// there are special types for char and wchar_t streams without the basic_ prefix:
std::ranges::istream_view<int> v4{myStrm}; // OK for char streams
std::wistringstream mywstream{L"0 1 2 3 4"};
std::ranges::wistream_view<int> v5{mywstream}; // OK for wchar_t streams
```
### String View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131017.png)
类模板 `std::basic_string_view<>` 及其特化 `std::string_view`、`std::u16string_view`、`std::u32string_view` 和 `std::wstring_view` 是 `C++17` 标准库中仅有的视图类型，`C++20` 为 `UTF-8` 字符增加特化 `std::u8strng_view`。 
字符串视图特殊之处在于：
- 定义在命名空间 `std` 而不是 `std::ranges` 中，有自己的头文件，不支持 `bool` 转换。
- 没有范围适配器/工厂来创建视图对象，只提供对元素/字符的读访问。
- 提供 `cbegin()` 和 `cend()` 成员函数。
迭代器不引用这个视图，其引用底层字符序列，因此字符串视图是一个租借范围，但当底层字符序列不再存在时，迭代器仍可以悬空。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131030.png)
### Span
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131041.png)
类模板 `std::span<>` 是存储在连续内存中的元素序列的视图，`span` 的主要优点是支持引用范围的中间或末尾引用 `n` 个元素的子范围。
`span` 视图特殊之处在于定义在命名空间 `std` 而不是 `std::ranges` 中，有自己的头文件，不支持 `bool` 转换。
```cpp
std::vector<std::string> vec{"New York", "Tokyo", "Rio", "Berlin", "Sydney"};
// sort the three elements in the middle:
std::ranges::sort(std::span{vec}.subspan(1, 3));
// print last three elements:
print(std::span{vec}.last(3));
```
#### Range Adaptors for Span Views
没有范围工厂用于从 `begin` 和 `end` 初始化 `span`，但有范围工厂可以使用 `begin` 和 `count` 创建 `span`。`std::views::counted()` 从迭代器 `beg` 开始用连续范围的前 `sz` 个元素创建一个动态大小的 `span` (对于非连续范围，`counted()` 创建子范围)。例如：
```cpp
std::vector<int> vec{1, 2, 3, 4, 5, 6, 7, 8, 9};
auto v = std::views::counted(vec.begin()+1, 3); // span with 2nd to 4th elem of vec
```
#### Special Characteristics of Spans
迭代器不引用这个范围，其引用底层元素，所以 `span` 是一个租借范围，但当底层元素序列不再存在时，迭代器仍然可以悬空。
#### Interface of Span Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131053.png)
## Filtering Views
本节讨论过滤给定范围或视图元素的所有视图。
### Take View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131101.png)
类模板 `std::ranges::take_view<>` 定义一个引用所传递范围前 `num` 个元素的视图，若传递的范围没有足够的元素，则引用所有元素。
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
for (const auto& elem : std::ranges::take_view{rg, 5}) 
// 1 2 3 4 5
```
#### Range Adaptors for Take Views
```cpp
for (const auto& elem : std::views::take(rg, 5)) 
// or:
for (const auto& elem : rg | std::views::take(5)) 
```
但适配器可能并不总是产生 `take_view`：
- 若传递一个 `empty_view`，则只返回该视图。
- 若传递一定大小的随机访问范围(子范围，`iota` 视图，字符串视图和 `span`)，会初始化和 `begin() + num` 相同类型的范围，并返回这样的范围 。
```cpp
std::vector<int> vec;

// using constructors:
std::ranges::take_view tv1{vec, 5}; // take view of ref view of vector
std::ranges::take_view tv2{std::vector<int>{}, 5}; // take view of owing view of vector
std::ranges::take_view tv3{std::views::iota(1,9), 5}; // take view of iota view

// using adaptors:
auto tv4 = std::views::take(vec, 5); // take view of ref view of vector
auto tv5 = std::views::take(std::vector<int>{}, 5); // take view of owning view of vector
auto tv6 = std::views::take(std::views::iota(1,9), 5); // pure iota view
```
#### Special Characteristics of Take Views
`take` 视图在内部存储传递的范围，所以其只有在传递的范围有效的情况下才有效，若传递右值，则在内部使用 `owning view`。 
只有当底层范围是 `sized` 范围和 `common` 范围时，`take` 视图才 `common`，迭代器和哨兵具有相同的类型。为协调类型，可能必须使用 `common view`。
#### Interface of Take Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131130.png)
### Take-While View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131141.png)
类模板 `std::ranges::take_while_view<>` 定义的视图引用传递的范围中匹配某个谓词的所有前置元素：
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};

for (const auto& elem : std::ranges::take_while_view{rg, [](auto x) {
    return x % 3 != 0; }}) { std::cout << elem << ' '; }
// 1 2
```
#### Range Adaptors for Take-While Views
适配器 `std::views::take_while` 将其参数传递给 `std::ranges::take_while_view` 构造函数：
```cpp
for (const auto& elem : std::views::take_while(rg, [](auto x) {
    return x % 3 != 0;
})) {}

// or:
for (const auto& elem : rg | std::views::take_while([](auto x) {
    return x % 3 != 0;
})) {}
```
传递的谓词必须是满足 `std::predicate` 概念的可调用对象，这暗示 `std::regular_invocable`的概念，所以谓词永远不应该修改底层范围的传递值，但不修改值是语义约束，所以在编译时不能总是检查这一点，所以至少应该将谓词声明为按值或按 `const` 引用接受实参。
#### Special Characteristics of Take-While Views
同上
#### Interface of Take-While Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131206.png)
### Drop View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131219.png)
类模板 `std::ranges::drop_view<>` 定义的视图引用传递的范围中除前 `num` 个元素外的所有元素，即产生与 `take` 视图相反的元素：
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
...
for (const auto& elem : std::ranges::drop_view{rg, 5})
// 6 7 8 9 10 11 12 13
```
#### Range Adaptors for Drop Views
```cpp
for (const auto& elem : std::views::drop(rg, 5)) 

// or:
for (const auto& elem : rg | std::views::drop(5)) 
```
适配器可能并不总是产生 `drop_view`：
若传递一个空视图，则直接返回空视图。
- 若传递一定大小的随机访问范围(子范围，`iota` 视图，字符串视图和 `span`)，会初始化和 `begin() + num` 相同类型的范围，并返回这样的范围 。
```cpp
std::vector<int> vec;

// using constructors:
std::ranges::drop_view dv1{vec, 5}; // drop view of ref view of vector
std::ranges::drop_view dv2{std::vector<int>{}, 5}; // drop view of owing view of vector
std::ranges::drop_view dv3{std::views::iota(1,10), 5}; // drop view of iota view

// using adaptors:
auto dv4 = std::views::drop(vec, 5); // drop view of ref view of vector
auto dv5 = std::views::drop(std::vector<int>{}, 5); // drop view of owing view of vector
auto dv6 = std::views::drop(std::views::iota(1,10), 5); // pure iota view
```
#### Special Characteristics Drop Views
`drop` 视图在内部存储传递的范围，所以其只有在传递的范围有效的情况下才有效，若传递右值，则在内部使用 `owning view`。 
只有当底层范围是 `sized` 范围和 `common` 范围时，`drop` 视图才 `common`，迭代器和哨兵具有相同的类型。为协调类型，可能必须使用 `common view`。
下述所说 `drop` 的 `caching`、`const` 特性均适用于后续过滤和反向视图。
#### Drop Views and Caching
`begin` 迭代器在第一次调用 `begin()` 时初始化并缓存。在没有随机访问的范围上，这需要线性时 间，所以重用 `drop` 视图比重新创建要好。
为获得常数复杂度，`drop` 视图会在视图中缓存 `begin()` 的结果，除非范围只是一个输入范围，所以对 `drop` 视图元素的第一次迭代要比以后的迭代更慢。出于这个原因，最好初始化一次 `drop` 视图，并使用它两次而非初始化并使用两次：
```cpp
// better:
auto v1 = coll | std::views::drop(5);
check(v1);
process(v1);

// worse:
check(coll | std::views::drop(5));
process(coll | std::views::drop(5));
```
从形式上讲，将无效视图复制到 `vector` 会创建未定义的行为，因为 `C++` 标准没有指定如何进行缓存。由于 `vector` 的重新分配会使所有迭代器失效，因此缓存的迭代器将会失效，所以对于随机访问范围，视图通常缓存偏移量，将缓存的起始偏移量与视图一起复制，而不是迭代器，此时视图仍然有效，因为它仍然包含符合意图的范围。
当过滤器视图引用的范围被修改时，此缓存可能会产生功能性后果，因此，不要使用在底层范围被修改后调用 `begin()` 的 `drop` 视图：
```cpp
void print(auto&& coll)
{
    for (const auto& elem : coll) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

std::vector vec{1, 2, 3, 4};
std::list lst{1, 2, 3, 4};

auto vVec = vec | std::views::drop(2);
auto vLst = lst | std::views::drop(2);

// insert a new element at the front (=> 0 1 2 3 4)
vec.insert(vec.begin(), 0);
lst.insert(lst.begin(), 0);
print(vVec); // OK: 2 3 4
print(vLst); // OK: 2 3 4

// insert more elements at the front (=> 98 99 0 -1 0 1 2 3 4)
vec.insert(vec.begin(), {98, 99, 0, -1});
lst.insert(lst.begin(), {98, 99, 0, -1});
print(vVec); // OK: 0 -1 0 1 2 3 4
print(vLst); // OOPS: 2 3 4

// creating a copy heals:
auto vVec2 = vVec;
auto vLst2 = vLst;
print(vVec2); // OK: 0 -1 0 1 2 3 4
print(vLst2); // OK: 0 -1 0 1 2 3 4
```
#### Drop View and const
并不能总是迭代 `const drop` 视图，所引用的范围必须是一个可随机访问范围和一定长度的范围：
```cpp
void printElems(const auto& coll) {
    for (const auto elem& e : coll) 
        std::cout << elem << '\n';
}
std::vector vec{1, 2, 3, 4, 5};
std::list lst{1, 2, 3, 4, 5};
printElems(vec | std::views::drop(3)); // OK
printElems(lst | std::views::drop(3)); // ERROR
```
`begin()` 仅为 `non-const-drop` 视图提供，因为缓存迭代器会修改视图。要在泛型代码中支持上述视图，必须使用通用引用：
```cpp
void printElems(auto&& coll) {...}
std::list lst{1, 2, 3, 4, 5};
printElems(lst | std::views::drop(3)); // OK
```
#### Interface of Drop Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131318.png)
### Drop-While View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131330.png)
类模板 `std::ranges::drop_while_view<>` 定义的视图跳过与某个谓词匹配的传递范围的所有前置元素：
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
for (const auto& elem : std::ranges::drop_while_view{rg, [](auto x) {
        return x % 3 != 0;
    }}) { std::cout << elem << ' ';}
// 3 4 5 6 7 8 9 10 11 12 13
```
#### Range Adaptors for Drop-While Views
```cpp
for (const auto& elem : std::views::drop_while(rg, [](auto x) {
    return x % 3 != 0;
})) {}
or:
for (const auto& elem : rg | std::views::drop_while([](auto x) {
return x % 3 != 0;
})) {}
```
其余同上：
```cpp
// better:
auto v1 = coll | std::views::drop_while(myPredicate);
check(v1);
process(v1);

// worse:
check(coll | std::views::drop_while(myPredicate));
process(coll | std::views::drop_while(myPredicate));

void printElems(const auto& coll) {
    for (const auto elem& e : coll) 
        std::cout << elem << '\n';
}
std::vector vec{1, 2, 3, 4, 5};
printElems(vec | std::views::drop_while( ... )); // ERROR

void printElems(auto&& coll) {
...
}
std::list lst{1, 2, 3, 4, 5};
printElems(vec | std::views::drop_while( ... )); // OK
```
#### Interface of Drop-While Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131420.png)
### Filter View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131429.png)
类模板 `std::ranges::filter_view<>` 定义的视图只迭代底层范围中与某个谓词匹配的元素。也就是说，过滤掉所有与谓词不匹配的元素。例如：
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
for (const auto& elem : std::ranges::filter_view{rg, [](auto x) {
    return x % 3 != 0;
}}) { std::cout << elem << ' ';}
```
#### Range Adaptors for Filter Views
适配器将其参数传递给 `std::ranges::filter_view` 构造函数：
```cpp
for (const auto& elem : std::views::filter(rg, [](auto x) {
    return x % 3 != 0;
})) {}
// or
for (const auto& elem : rg | std::views::filter([](auto x) {
    return x % 3 != 0;
})) {}
```
其余同上：
```cpp
// better:
auto v1 = coll | std::views::filter(myPredicate);
check(v1);
process(v1);

// worse:
check(coll | std::views::filter(myPredicate));
process(coll | std::views::filter(myPredicate));

void printElems(const auto& coll) {
    for (const auto elem& e : coll) 
        std::cout << elem << '\n';
}
std::vector vec{1, 2, 3, 4, 5};
printElems(vec | std::views::filter( ... )); // ERROR

void printElems(auto&& coll) {
...
}
std::list lst{1, 2, 3, 4, 5};
printElems(vec | std::views::filter( ... )); // OK
```
#### Filter Views When Modifying Elements
使用过滤器视图时，对写访问有一个重要的附加限制，必须确保修改后的值仍然满足传递给过滤器的谓词。要理解为什么会出现这种情况，请考虑以下代码:
```cpp
void print(const auto& coll)
{
    std::cout << "coll: ";
    for (int i : coll) 
        std::cout << i << ' ';
    std::cout << '\n';
}

std::vector<int> coll{1, 4, 7, 10, 13, 16, 19, 22, 25};

// view for all even elements of coll:
auto isEven = [] (auto&& i) { return i % 2 == 0; };
auto collEven = coll | vws::filter(isEven);
print(coll);

// 对集合中的偶数元素迭代两次并自增
for (int& i : collEven) {
    std::cout << " increment " << i << '\n';
    i += 1; // ERROR: undefined behavior because filter predicate is broken
}
print(coll);

for (int& i : collEven) {
    std::cout << " increment " << i << '\n';
    i += 1; // ERROR: undefined behavior because filter predicate is broken
}
print(coll);

// coll: 1 4 7 10 13 16 19 22 25
// coll: 1 5 7 11 13 17 19 23 25
// coll: 1 6 7 11 13 17 19 23 25
```
第一次使用确保只处理偶数元素的视图时，工作得很好，但视图会缓存与谓词匹配的第一个元素的位置，以便 `begin()` 不必重新计算它。当访问那里的值时，过滤器不会再次应用谓词，因为它已经知道这是第一个匹配元素。因此当第二次迭代时，过滤器不会再对之前第一次匹配成功的位置执行谓词，而对于所有其他元素，必须再次执行谓词，由于没有偶数元素，因此最终只返回之前第一次匹配成功的位置的元素。
```cpp
// 下述写访问会破坏谓词
for (auto& m : collOfMonsters | filter(isDead)) {
    m.resurrect(); // a shaman’s doing, of course
}
// 因此改用普通的循环
for (auto& m : collOfMonsters) {
    if (m.isDead()) 
        m.resurrect(); // a shaman’s doing, of course
}
```
#### Filter Views in Pipelines
过滤视图会对管道的性能有很大的影响，并且有时会以令人惊讶的方式限制对元素的写访问。因此，应该谨慎地使用过滤视图：
- 在修改元素的同时使用过滤器时，需要确保在这些修改之后，过滤器的谓词仍然是满足的。当写访问破坏谓词时，不要将其用于对元素的写访问。 
- 使用过滤器之前，要警惕昂贵的转换，在管道中，应该尽可能早地获得它。
因为过滤器视图前面的视图和适配器可能必须多次评估元素，一次是决定它们是否通过过滤，一次是决定最终使用的值。因此，像下面这样的管道：
```cpp
rg | std::views::filter(pred) | std::views::transform(func)
```
要比下面的方式有更好的性能：
```cpp
rg | std::views::transform(func) | std::views::filter(pred)
```
#### Interface of Filter Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131532.png)
## Transforming Views
本节讨论生成转换所遍历元素值的视图。
### Transform View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131545.png)
类模板 `std::ranges::transform_view<>` 定义的视图返回转换后的底层范围内的所有元素。例如：
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};

for (const auto& elem : std::ranges::transform_view{rg, [](auto x) {
    return x * x;
}}) { std::cout << elem << ' '; }
// 1 4 9 16 25 36 49 64 81 100 121 144 169
```
#### Range Adaptors for Transform Views
适配器将参数传递给 `std::ranges::transform_view` 构造函数：
```cpp
for (const auto& elem : 
     std::views::transform(rg, [](auto x) { return x * x; })) {}

for (const auto& elem : rg | 
     std::views::transform([](auto x) { x * x; })) {}
```
转换必须是满足 `std::regular_invocable`概念的可调用对象，所以转换永远不应该修改底层范围的传递值，但不修改值是语义约束，所以在编译时不能总是检查这一点，所以至少应该将转换声明为按值或按 `const` 引用接受实参。
转换视图返回转换后的值的类型，转换的返回类型甚至可以是引用。例如:
```cpp
void printPairs(const auto& collOfPairs)
{
    for (const auto& elem : collOfPairs) 
        std::cout << elem.first << '/' << elem.second << ' ';
    std::cout << '\n';
}

// initialize collection with pairs of int as elements:
std::vector<std::pair<int,int>> coll{{1,9}, {9,1}, {2,2}, {4,1}, {2,7}};
printPairs(coll);

// function that yields the smaller of the two values in a pair:
auto minMember = [] (std::pair<int, int>& elem) -> int& {
    return elem.second < elem.first ? elem.second : elem.first;
};

// increment the smaller of the two values in each pair element:
for (auto&& member : coll | std::views::transform(minMember)) {
    ++member;
}
printPairs(coll);

// 1/9 9/1 2/2 4/1 2/7
// 2/9 9/2 3/2 4/2 3/7
```
这里传递给 `transform` 的 `Lambda` 必须返回一个引用，否则，`Lambda` 将返回每个元素的副本，递增的是这些副本的成员，而 `coll` 中的元素保持不变。
#### Special Characteristics of Transform Views
`transform` 视图在内部存储传递的范围，所以其只有在传递的范围有效的情况下才有效，若传递右值，则在内部使用 `owning view`。 
`begin` 迭代器和 `end` 迭代器都是特殊的内部辅助类型，若传递的是 `common` 范围，则它们是 `common` 的。
与标准视图一样，`transform` 视图不会将常量性委托给元素。所以即使视图是 `const`，传递给转换函数的元素也不是 `const`。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131625.png)
### Elements View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131631.png)
类模板 `std::ranges::elements_view<>` 定义的视图会选择传递的范围中第 `idx` 个成员，这是通过为范围的成员调用 `get(elem)` 实现的，从而：
- 获取所有 `std::tuple` 元素的第 `idx` 个成员
- 获取所有` std::variant` 元素的第 `idx` 个成员
- 获取 `std::pair` 元素的第一个或第二个成员，但对于关联容器和无序容器的元素，使用 `keys_view` 和 `values_view` 更方便
对于这个视图，类模板参数推导不起作用，因为必须显式地将索引指定为参数，并且类模板不支持部分参数推导：
```cpp
std::vector<std::tuple<std::string, std::string, int>> rg{
    {"Bach", "Johann Sebastian", 1685}, {"Mozart", "Wolfgang Amadeus", 1756},
    {"Beethoven", "Ludwig van", 1770}, {"Chopin", "Frederic", 1810},
};

for (const auto& elem
: std::ranges::elements_view<decltype(std::views::all(rg)), 2>{rg}) {
    std::cout << elem << ' ';
}
// 1685 1756 1770 1810
```
若传递的范围不是视图，则必须使用范围适配器 `all()` 指定底层范围的类型：
```cpp
std::ranges::elements_view<decltype(std::views::all(rg)), 2>{rg} // OK
// You can also specify the type directly using std::views::all_t<>:
std::ranges::elements_view<std::views::all_t<decltype(rg)&>, 2>{rg} // OK
std::ranges::elements_view<std::views::all_t<decltype((rg))>, 2>{rg} // OK
```
若范围不是视图，那么` all_t<>` 的参数必须是左值引用，所以需要在 `rg` 的类型后面加上 `&` 或在 表达式 `rg` 上加双括号以指明是左值，从而使得 `decltype` 产生一个左值引用。
下述例子：
```cpp
void print(std::ranges::input_range auto&& coll)
{
    for (const auto& elem : coll) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

std::vector<std::tuple<int, std::string, double>> coll{
    {1, "pi", std::numbers::pi},
    {2, "e", std::numbers::e},
    {3, "golden-ratio", std::numbers::egamma},
    {4, "euler-constant", std::numbers::phi},
};
std::ranges::sort(coll, std::less{}, [](const auto& e) {return std::get<2>(e);});
print(std::ranges::elements_view<decltype(std::views::all(coll)), 1>{coll});
print(coll | std::views::elements<2>);
// golden-ratio euler-constant e pi
// 0.577216 1.61803 2.71828 3.14159
```
不应该按以下方式对 `coll` 的元素进行排序：
```cpp
std::ranges::sort(coll | std::views::elements<2>); // OOPS
// pi e golden-ratio euler-constant
// 0.577216 1.61803 2.71828 3.14159
```
这将只对元素的值进行排序，而不是对指定的第 `idx` 成员进行排序。
#### Range Adaptors for Elements Views
适配器使视图的使用更容易，不必指定底层范围的类型:
```cpp
std::views::elements<idx>(rg)

for (const auto& elem : std::views::elements<2>(rg)) {}

// or:
for (const auto& elem : rg | std::views::elements<2>) {}

// 使用范围适配器，elements<idx>(rg) 等价于:
std::ranges::elements_view<std::views::all_t<decltype(rg)&>, idx>{rg}
```
`elements` 视图在内部存储传递的范围，所以其只有在传递的范围有效的情况下才有效，若传递右值，则在内部使用 `owning view`。 
`begin` 迭代器和 `end` 迭代器都是特殊的内部辅助类型，若传递的是 `common` 范围，则它们是 `common` 的。
#### Elements Views for Other Tuple-Like Types
为能够将此视图用于用户定义的类型，需要指定一个类似元组的 `API`，但只能对 `std::pair<>` 和 `std::tuple<> `使用 `std::ranges::elements_view` 类或适配器 `std::views::elements<>`。 
但若确保在包含头文件 `<ranges>` 之前定义类似元组的 `API`，就可以工作：
```cpp
#include <iostream>
#include <string>
#include <tuple>
// don’t include <ranges> yet !!

struct Data {
    int id;
    std::string value;
};
std::ostream& operator<< (std::ostream& strm, const Data& d) {
    return strm << '[' << d.id << ": " << d.value << ']';
}

// tuple-like access to Data:
namespace std {
    template<>
        struct tuple_size<Data> : integral_constant<size_t, 2> {
    };
    template<>
    struct tuple_element<0, Data> {
        using type = int;
    };
    template<>
    struct tuple_element<1, Data> {
        using type = std::string;
    };
    template<size_t Idx> auto get(const Data& d) {
        if constexpr (Idx == 0) {
            return d.id;
        }
        else {
            return d.value;
        }
    }
} // namespace std

// 可以这样
void print(const auto& coll)
{
    std::cout << "coll:\n";
    for (const auto& elem : coll) 
        std::cout << "- " << elem << '\n';
}

Data d1{42, "truth"};
std::vector<Data> coll{d1, Data{0, "null"}, d1};
print(coll);
print(coll | std::views::take(2));
print(coll | std::views::elements<1>);
```
#### Interface of Elements Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131726.png)
### Keys and Values View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214131734.png)
类模板 `std::ranges::keys_view<>` 定义的视图从传递的范围的元素中选择第一个成员，这是通过为范围的成员调用 `get<0>(elem)` 实现的。
类模板 `std::ranges::values_view<>` 定义的视图从传递的范围的元素中选择第二个成员，这是通过为范围的成员调用 `get<1>(elem)` 实现的，从而：
- 获 取 `std::pair` 元素的第一/第二成员，这对于选择 `map`、`unordered_map`、`multimap` 和 `unordered_multimap` 的元素的键/值特别有用
- 获取 `std::tuple` 元素的第一/第二个成员 
- 获取 `std::variant` 元素的第一/第二个的成员 
对于 `std::tuple` 和 `std::variant` 直接使用索引为 `0` 的 `elements_view` 元素可更具可读性。同样地，类模板参数推导不起作用，因为必须显式地将索引指定为参数，并且类模板不支持部分参数推导：
```cpp
std::map<std::string, int> rg{
    {"Bach", 1685}, {"Mozart", 1756}, {"Beethoven", 1770},
    {"Tchaikovsky", 1840}, {"Chopin", 1810}, {"Vivaldi", 1678},
};
for (const auto& e : std::ranges::keys_view<decltype(std::views::all(rg))>{rg}) 
    std::cout << e << ' ';
```
#### Range Adaptors for Keys/Values Views
适配器使视图的使用更容易，不必指定底层范围的类型:
```cpp
std::views::keys(rg)
std::views::values(rg)

for (const auto& elem : rg | std::views::keys) {}
// or:
for (const auto& elem : rg | std::views::values) {}
```
所有其他方面都与元素视图相匹配。
## Mutating Views
本节讨论所有改变元素顺序的视图(到目前为止，只有一个)。
### Reverse View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214132238.png)
类模板 std::ranges::reverse_view<> 定义一个以相反顺序遍历基础范围元素的视图。
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
...
for (const auto& elem : std::ranges::reverse_view{rg}) {}
// 13 12 11 10 9 8 7 6 5 4 3 2 1
```
#### Range Adaptors for Reverse Views
```cpp
std::views::reverse(rg)

for (const auto& elem : std::views::reverse(rg)) {}
// or:
for (const auto& elem : rg | std::views::reverse) {}
```
适配器可能并不总是产生 `reverse_view`：
- 反向反转的范围会生成原始范围。
- 若传递反向范围，则返回原始子范围和相应的非反向迭代器。 
`reverse` 视图在内部存储传递的范围，所以其只有在传递的范围有效的情况下才有效，若传递右值，则在内部使用 `owning view`。 
迭代器只是传递范围的反向迭代器。
缓存，`cosnt` 同过滤视图。
```cpp
void printElems(const auto& coll) {
    for (const auto elem& e : coll) 
        std::cout << elem << '\n';
}

std::vector vec{1, 2, 3, 4, 5};
// leading odd elements of vec:
auto vecFirstOdd = std::views::take_while(vec, [](auto x) {return x % 2 != 0;});
printElems(vec | std::views::reverse); // OK
printElems(vecFirstOdd); // OK
printElems(vecFirstOdd | std::views::reverse); // ERROR

void printElems(auto&& coll) {...}

std::vector vec{1, 2, 3, 4, 5};
// leading odd elements of vec:
auto vecFirstOdd = std::views::take_while(vec, [](auto x) {return x % 2 != 0;});
printElems(vecFirstOdd | std::views::reverse); // OK
```
#### Interface of Reverse Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214132320.png)
## Views for Multiple Ranges
本节讨论处理多个范围的所有视图。
### Split and Lazy-Split View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214132334.png)
`std::ranges::split_view<>` 和 `std::ranges::lazy_split_view<>` 两个类模板定义的视图引用通过分隔符分隔的多个子视图。
区别如下: 
- `split_view<>` 不能迭代 `const` 视图，`lazy_split_view<>` 可以，但引用的范围至少是 `forward range`。
- `split_view<>` 只能处理至少具有前向迭代器的范围(必须满足 `forward_range` 的概念)。
- `split_view<>` 元素只是引用范围的迭代器类型的 `std::ranges::subrange`(保持引用范围的类别)。 
- `lazy_split_views<>` 元素是 `std::ranges::lazy_split_view` 类型的视图，其总是`forward range`，这意味着甚至不支持 `size()`。
- `split_view<>` 具有更好的性能。 
综上，应该只使用 `split_view<>`，除非使用输入范围或视图被用作 `const` 范围，例如：
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
...
for (const auto& sub : std::ranges::split_view{rg, 5}) {
    for (const auto& elem : sub) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

1 2 3 4
6 7 8 9 10 11 12 13
```
#### Range Adaptors for Split and Lazy-Split Views
适配器只是将其参数传递给相应的视图构造函数：
```cpp
std::views::split(rg, sep)
std::views::lazy_split(rg, sep)

for (const auto& sub : std::views::split(rg, 5)) {
    for (const auto& elem : sub) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

// or:
for (const auto& sub : rg | std::views::split(5)) {
    for (const auto& elem : sub) 
        std::cout << elem << ' ';
    std::cout << '\n';
}
```
创建的视图可能是空的，当遇到连续分隔符时，每个分隔符都会创建一个空视图。例如：
```cpp
std::list<int> rg{5, 5, 1, 2, 3, 4, 5, 6, 5, 5, 4, 3, 2, 1, 5, 5};
for (const auto& sub : std::ranges::split_view{rg, 5}) {
    std::cout << "subview: ";
    for (const auto& elem : sub) 
        std::cout << elem << ' ';
    std::cout << '\n';
}
```
除单值之外，还可以传递一系列值作为分隔符。例如:
```cpp
std::vector<int> rg{1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3 };
    ...
    // split separated by a sequence of 5 and 1:
    for (const auto& sub : std::views::split(rg, std::list{5, 1})) {
    for (const auto& elem : sub) 
        std::cout << elem << ' ';
    std::cout << '\n';
}
1 2 3 4
2 3 4
2 3
```
传递的元素集合必须是有效的视图和 `forward_range`，所以在容器中指定子序列时，必须将其转换为视图。例如:
```cpp
// split with specified pattern of 4 and 5:
std::array pattern{4, 5};
for (const auto& sub : std::views::split(rg, std::views::all(pattern))) {}

// 可以用来拆分字符串:
std::string str{"No problem can withstand the assault of sustained thinking"};
for (auto sub : std::views::split(str, "th"sv)) { // split by "th"
    std::cout << std::string_view{sub} << '\n';
}
```
每个子字符串 `sub` 的类型为 `std::ranges::subrange`，这样的代码将不能用于 `lazy-split view`。 
上述两个视图在内部存储传递的范围，所以其只有在传递的范围有效的情况下才有效，若传递右值，则在内部使用 `owning view`。 
`begin` 迭代器和 `end` 迭代器都是特殊的内部辅助类型，若传递的是 `common` 范围，则它们是 `common` 的。
#### Split View and const
不能在 `const-split view` 上迭代，特别是将视图传递给一个 `const` 引用的泛型函数:
```cpp
void printElems(const auto& coll) {...}

printElems(std::views::split(rg, 5)); // ERROR
// To support this view in generic code
// you have to use universal/forwarding references:
void printElems(auto&& coll) {...}
```
或选择使用 `lazy_split_view`，但此时子视图元素只能用作 `front range`，所以不能调用 `size()`、向后迭代或对元素排序:
```cpp
std::vector<int> coll{5, 1, 5, 1, 2, 5, 5, 1, 2, 3, 5, 5, 5};
...
const std::ranges::lazy_split_view sv{coll, 5};
for (const auto& sub : sv) { // OK for const lazy-split view
    std::cout << sub.size() << ' '; // ERROR
    std::sort(sub); // ERROR
    for (const auto& elem : sub)  // OK
        std::cout << elem << ' ';
}
```
#### Interface of Split and Lazy-Split Views
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214132435.png)
### Join View
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214132442.png)
类模板 `std::ranges::join_view<>` 定义一个遍历多个范围所有元素的视图。
```cpp
std::vector<int> rg1{1, 2, 3, 4};
std::vector<int> rg2{0, 8, 15};
std::vector<int> rg3{5, 4, 3, 2, 1, 0};
std::array coll{rg1, rg2, rg3};
...
for (const auto& elem : std::ranges::join_view{coll}) {}
```
#### Range Adaptors for Join Views
适配器将其参数传递给 `std::ranges::join_view` 构造函数:
```cpp
for (const auto& elem : std::views::join(coll)) {}
// or:
for (const auto& elem : coll | std::views::join) {}
```
下面是使用连接视图的完整示例：
```cpp
template<typename T>
void printColl(T&& obj, int level = 0)
{
    if constexpr(std::same_as<std::remove_cvref_t<T>, std::string>) {
        std::cout << "\"" << obj << "\"";
    }
    else if constexpr(std::ranges::input_range<T>) {
        std::cout << '[';
        for (auto pos = obj.begin(); pos != obj.end(); ++pos) {
            printColl(*pos, level+1);
            if (std::ranges::next(pos) != obj.end()) {
                std::cout << ' ';
            }
        }
        std::cout << ']';
    }
    else {
        std::cout << obj;
    }
    if (level == 0) std::cout << '\n';
}

std::vector<std::string> rg1{"he", "hi", "ho"};
std::vector<std::string> rg2{"---", "|", "---"};
std::array coll{rg1, rg2, rg1};
printColl(coll); // ranges of ranges of strings
printColl(std::ranges::join_view{coll}); // range of strings
printColl(coll | std::views::join); // range of strings
printColl(coll | std::views::join | std::views::join); // ranges of chars
```
结合类型 `std::ranges::subrange`，可以使用连接视图来连接多个数组。
```cpp
int arr1[]{1, 2, 3, 4, 5};
int arr2[] = {0, 8, 15};
int arr3[10]{1, 2, 3, 4, 5};
...
std::array<std::ranges::subrange<int*>, 3> coll{arr1, arr2, arr3};
for (const auto& elem : std::ranges::join_view{coll}) {
    std::cout << elem << ' '; 
}
Alternatively, you can declare coll as follows:
std::array coll{std::ranges::subrange{arr1},
std::ranges::subrange{arr2},
std::ranges::subrange{arr3}};
```
#### Join View and const
并不总能迭代 `const` 连接视图，若范围不是 `const` 迭代器，或内部范围产生普通值而不是引用，就会发生这种情况。对于后一种情况：
```cpp
void printConstColl(const auto& coll)
{
    printColl(coll);
}

std::vector<int> rg1{1, 2, 3, 4};
std::vector<int> rg2{0, 8, 15};
std::vector<int> rg3{5, 4, 3, 2, 1, 0}; // 上述为内部范围
std::array coll{rg1, rg2, rg3}; // 外部范围

printConstColl(coll);
printConstColl(coll | std::views::join);
// 将范围作为 const 引用。会得 到以下输出
// [[1 2 3 4] [0 8 15] [5 4 3 2 1 0]] 
// [1 2 3 4 0 8 15 5 4 3 2 1 0]

// 然而将整个数组传递给一个转换视图，该视图按值返回所有内部范围
// 调用 printConstColl() 会导致错误
auto collTx = [] (const auto& coll) { return coll; };
auto coll2values = coll | std::views::transform(collTx);

printConstColl(coll2values);
printConstColl(coll2values | std::views::join); // ERROR
```
#### Special Characteristics of Join Views
若外部范围和内部范围是 `bidirectional` 的，并且内部范围是 `common range`，则产生的是双向的。若外部范围和内部范围至少是 `forward range`，则产成的是前向的。否则产生的为 `input range`。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214132527.png)
# Spans
为处理范围，C++20 引入两个视图类型，这些视图类型不会在自己的内存中存储元素，只引用存储在其他范围或视图中的元素，`std::span<>` 类模板就是这种视图。 
历史上看，`span` 是 `C++17` 中引入的字符串视图的泛化。`span` 指的是任何元素类型的数组，作为原始指针和大小的组合，提供通常的集合接口，用于读取和写入存储在连续内存中的元素。 
通过要求 `span` 只能引用连续内存中的元素，迭代器可以是原始指针，该集合提供随机访问，因此可以使用此视图对元素进行排序，或者可以使用生成位于底层范围中间或末尾的 `n` 个元素的子序列的操作。
使用 `span` 既廉价又快速(应该按值传递)，但也有潜在的危险。与原始指针一样，在使用 `span` 时，需要由开发者来确保引用序列的有效性。此外，`span` 支持写访问的情况，可能会破坏 `const` 的正确性。
## Using Spans
### Fixed and Dynamic Extent
声明 `span` 时，可以设置元素数量，也可以不设置。具有指定固定数量元素的 span 称为具有固定区段的 `span`，可以通过指定元素类型和大小作为模板参数来声明，或者通过带有迭代器和大小的数组来初始化，成员函数 `size()` 会返回指定的长度用于模板参数，但不调用默认构造函数(除非区段为 0)。
```cpp
int a5[5] = {1, 2, 3, 4, 5};
std::array arr5{1, 2, 3, 4, 5};
std::vector vec{1, 2, 3, 4, 5, 6, 7, 8};

std::span sp1 = a5; // span with fixed extent of 5 elements
std::span sp2{arr5}; // span with fixed extent of 5 elements
std::span<int, 5> sp3 = arr5; // span with fixed extent of 5 elements
std::span<int, 3> sp4{vec}; // span with fixed extent of 3 elements
std::span<int, 4> sp5{vec.data(), 4}; // span with fixed extent of 4 elements
std::span sp6 = sp1; // span with fixed extent of 5 elements
```
元素数量在其生命周期内不稳定的 `sapn` 称为具有动态区段的 `span`，元素的数量取决于 `span` 所引用的元素序列，并且可能由于分配一个新的范围而改变(没有其他方法可以改变元素的数量)。
```cpp
int a5[5] = {1, 2, 3, 4, 5};
std::array arr5{1, 2, 3, 4, 5};
std::vector vec{1, 2, 3, 4, 5, 6, 7, 8};

std::span<int> sp1; // span with dynamic extent (initially 0 elements)
// 初始化时，可以使用类模板实参推导，从而推导出元素的类型和范围:
std::span sp2{a5, 3}; // span with dynamic extent (initially 3 elements)
std::span<int> sp3{arr5}; // span with dynamic extent (initially 5 elements)
std::span sp4{vec}; // span with dynamic extent (initially 8 elements)
std::span sp5{arr5.data(), 3}; // span with dynamic extent (initially 3 elements)
std::span sp6{a5+1, 3}; // span with dynamic extent (initially 3 elements)
```
### Example Using a Span with a Dynamic Extent
```cpp
std::vector<std::string> vec{"New York", "Tokyo", "Rio", "Berlin", "Sydney"};
// 用 vector 的前三个元素初始化由三个常量字符串组成的动态 span
// 由开发者来确保元素的数量与 span 的范围相匹配，并且元素是有效的
// 若 vector 没有足够的元素，则行为未定义
std::span<const std::string> sp{vec.data(), 3};
```
指定元素为 `const std::string` 时，就不能通过 `span` 进行修改，但将 `span` 本身声明为 `const` 时就能修改，因为对于视图，`const` 不会传播：
```cpp
std::span<const std::string> sp1{vec.begin(), 3}; // elements cannot be modified
const std::span<std::string> sp2{vec.begin(), 3}; // elements can be modified
```
即使 `printSpan<>()` 有非类型模板参数表示 `span` 的大小，但依然可以传入动态 `span`，因为 `std::span<T>` 是具有伪长度 `std::dynamic_extent` 的缩写：
```cpp
std::span<int> sp; // equivalent to std::span<int, std::dynamic_extent>

// In fact, the class template std::span<> is declared as follows:
namespace std {
    template<typename ElementType, size_t Extent = dynamic_extent>
    class span {...};
}
```
这允许开发者提供像 `printSpan<>()` 这样的通用代码，其既适用于固定范围的 `span`，也适用于动态区段的 `span`。当具有固定 `span` 调用 `printSpan<>()` 时，`span` 可作为模板参数传递:
```cpp
std::span<int, 5> sp{ ... };
printSpan(sp); // calls printSpan<int, 5>(sp)
```
`span` 是按值传递的，这是传递 `span` 的推荐方法，因为复制它们的成本很低。在内部，`span` 只有一个指针和一个长度信息，提供 `begin()` 和 `end()` 的迭代器支持。但无论通过值传递还是通过 `const&` 传递 `span`，只要没有将元素声明为 `const`，在函数内部仍可以修改元素。
#### Dealing with Reference Semantics
若底层范围没有将其元素声明为 `cosnt`，则 `span` 可以修改底层范围的值。因为 `span` 具有引用语义，因此这种排序也会影响 `span` 的元素，其结果是 `span` 会引用不同的值。
```cpp
void print(std::ranges::input_range auto&& coll)
{
    for (const auto& elem : coll) 
        std::cout << '"' << elem << "\" ";
    std::cout << '\n';
}

std::vector<std::string> vec{"New York", "Tokyo", "Rio", "Berlin", "Sydney"};

// sort elements in the referenced vector:
std::ranges::sort(vec);
std::cout << "first 3 after sort(): ";
printSpan(sp);

// sort the three elements in the middle:
std::ranges::sort(std::span{vec}.subspan(1, 3));
print(vec);

// print last three elements:
print(std::span{vec}.last(3));
```
引用语义在使用 `span` 时必须谨慎，下述将一个新元素插入 `vector` 中，该 `vector` 中保存 `span` 所引用的元素。由于 `span` 具有引用语义，一旦 `vector` 分配新的内存，会使所有迭代器和指向其元素的指针无效，所以重新分配也会使引用 `vector` 元素的 `span` 失效，`span` 指向不再存在的元素。 出于这个原因，需要在插入前后都要仔细检查容量，若容量发生变化，则重新初始化 `span`，使其指向新内存中的前三个元素。
```cpp
// must reassign the internal array of the vector 
// if it reallocated new memory
auto oldCapa = vec.capacity();
vec.push_back("Cairo");
if (oldCapa != vec.capacity()) {
    sp = std::span{vec.data(), 3};
}
```
#### Assigning a Container to a Span
接下来，将 `vector` 作为一个整体赋值给 `span`，并将其输出，可以看到对具有动态区段 `span` 的赋值可以改变元素的数量。只要容器允许使用成员函数 `data()` 访问这些元素，则 `span` 可以使用任何类型的容器或范围来保存连续内存中的元素。 
```cpp
std::span<const std::string> sp{vec.begin(), 3};
...
sp = vec;

printSpan(vec); // ERROR: template type deduction doesn’t work here
printSpan(std::span{vec}); // OK
```
但由于模板类型推导的限制，不能将这样的容器传递给形参为 `span` 的函数。必须明确指定要将 `vector` 转换为 `span`。
#### Assigning a Different Subsequence
通常，`span` 的赋值操作符接受另一个元素序列，可以使用左闭右开迭代器指定引用的序列，要求满足 `std::size_sentinel_for` 的概念，以便构造函数可以计算差值：
```cpp
std::span<const std::string> sp{vec.data(), 3};
...
// assign view to last five elements:
sp = std::span{vec.end() - 5, vec.end()};
```
最后 `n` 个元素也可以使用 `span` 的成员函数来赋值:
```cpp
std::vector<std::string> vec{"New York", "Tokyo", "Rio", "Berlin", "Sydney"};
std::span<const std::string> sp{vec.data(), 3};
...
// assign view to last four elements:
sp = std::span{vec}.last(4);
```
要处理一个范围的前 `n` 个元素，可以使用范围工厂 `std::views::counted()`，若对一个连续内存中有元素的范围进行迭代器使用，会创建一个具有动态区段的 `span`：
```cpp
std::vector<int> vec{1, 2, 3, 4, 5, 6, 7, 8, 9};
auto v = std::views::counted(vec.begin()+1, 3); // span with 2nd to 4th elem of vec
```
`span` 是唯一提供在范围中间或末尾生成元素序列的视图。只要元素类型合适，就可以传递任何其他类型的元素序列：
```cpp
std::vector<std::string> vec{"New York", "Tokyo", "Rio", "Berlin", "Sydney"};
std::span<const std::string> sp{vec.begin(), 3};
...
std::array<std::string, 3> arr{"Tick", "Trick", "Track"};
sp = arr; // OK
```
但 `span` 不支持元素类型的隐式类型转换。例如，无法编译以下代码：
```cpp
std::span<const std::string> sp{vec.begin(), 3};
...
std::array arr{"Tick", "Trick", "Track"}; // deduces std::array<const char*, 3>
sp = arr; // ERROR: different element types
```
### Example Using a Span with Fixed Extent
```cpp
std::vector<std::string> vec{"New York", "Tokyo", "Rio", "Berlin", "Sydney"};
// 初始化一个由三个固定长度的常量字符串组成的 span:
// 对于固定区段，可指定元素的类型和大小，需要由开发者来保证元素的数量与 span 的区段相匹配
// 若作为第二个参数传递的计数与范围不匹配，则行为未定义
std::span<const std::string, 3> sp3{vec.data(), 3};
```
注意，以下代码将不可编译：
```cpp
// Note that the following would no longer compile:
std::span<const std::string, 3> sp3{vec.data(), 3};
...
sp3 = std::span{vec}.last(3); // ERROR
```
原因是赋值右侧的表达式创建一个具有动态区段的 `span`。
通过使用 `last()` 和指定元素数量作为模板参数的语法，则得到一个具有相应固定区段的 `span`：
```cpp
std::span<const std::string, 3> sp3{vec.data(), 3};
...
sp3 = std::span{vec}.last<3>(); // OK

// 仍可以使用类模板实参推导来为数组元素赋值，甚至可以直接赋值:
std::span<const std::string, 3> sp3{vec.data(), 3};
...
std::array<std::string, 3> arr{"Tic", "Tac", "Toe"};
sp3 = std::span{arr}; // OK
sp3 = arr; // OK
```
### Fixed vs. Dynamic Extent
指定固定的大小使编译器能够在运行时，甚至在编译时检测长度是否违规：
```cpp
std::vector vec{1, 2, 3};
std::array arr{1, 2, 3, 4, 5, 6};
std::span<int, 3> sp3{vec};
std::span sp{vec};
sp3 = arr; // compile-time ERROR
sp = arr; // OK
```
具有固定区段的 `span` 需要更少的内存，不需要具有实际大小的成员(大小是类型的一部分)。
而使用动态 `span` 提供更大的灵活性：
```cpp
std::span<int> sp; // OK
...
std::vector vec{1, 2, 3, 4, 5};
sp = vec; // OK (span has 5 elements)
sp = {vec.data()+1, 3}; // OK (span has 3 elements)
```
## Spans Considered Harmful
`span` 指的是外部值的序列，所以具有具有引用语义的类型所具有的常见问题，需要由开发者来保证 `span` 引用的序列的有效性。
若函数 `getData()` 按值返回一个整数集合，则以下语句会出现致命的运行时错误：
```cpp
std::span<int, 3> first3{getData()}; // ERROR: reference to temporary object
std::span sp{getData().begin(), 3}; // ERROR: reference to temporary object
sp = getData(); // ERROR: reference to temporary object

// This can look a little bit more subtle, such as using the range-based for loop:
// for the last 3 returned elements:
for (auto s : std::span{arrayOfConst()}.last(3)) // fatal runtime ERROR
```
这段代码会导致未定义的行为，因为基于范围的 `for` 循环中存在一个 `bug`，在对临时对象的引用上进行迭代时会使用已经销毁的值。 
编译器可以通过对标准类型的特殊生命周期检查来检测这些问题，目前主要的编译器都实现，但只能检测简单的生存期依赖关系，比如 `span` 和初始化的对象之间的依赖关系。此外，必须确保所引用的元素序列保持有效，若程序的其他部分在引用序列的生命周期结束时仍在使用该 `span`，则可能会出现问题。
```cpp
std::vector<int> vec{1, 2, 3, 4, 5, 6, 7, 8};
std::span sp{vec}; // view to the memory of vec
...
vec.push_back(9); // might reallocate memory
std::cout << sp[0]; // fatal runtime ERROR (referenced array no longer valid)
```
作为一种变通方法，必须用原始 `vector` 重新初始化 `span`，因此使用 `span` 与使用原始指针和其他视图类型一样需要谨慎。
## Design Aspects of Span
### Lifetime Dependencies of Spans
由于引用语义，只有在底层值序列存在才能迭代 `span`，但迭代器并不与创建他们的 `span` 绑定生命周期。
`span` 的迭代器不引用创建它们的 `span`，而是直接引用底层范围，所以 `span` 是一个租借范围，即产生的迭代器是租借迭代器。因此，即使 `span` 不再存在，只要元素序列存在，也可以使用迭代器，当底层范围不再存在时，迭代器就会悬空。
### Performance of Spans
`span` 的设计以最佳性能为目标。`span` 在内部只是一个指针和一个大小，所以复制成本非常低。出于这个原因，应该更倾向于按值传递 `span`，而非通过 `const` 引用传递。此外，内部使用指向元素序列的原始指针希望元素按顺序存储在一个内存块中，所以，`span` 要求元素存储在连续内存中。 
综上，`span` 不需要任何内存分配，也不附带任何间接内容，使用 `span` 的唯一开销是构造。编译时使用概念检查引用序列是否在连续内存中有其元素，初始化序列或赋值新序列时，迭代器必须满足 `std::consecuous_iterator` 概念，容器或范围必须满足 `std::ranges::consecuous_range` 和 `std::ranges::sized_range` 两个概念。
`span` 使用指向内存的原始指针执行元素访问，指向 `vector` 元素的 `span` 操作与指向数组元素的 `span` 操作具有相同的类型，前提是具有相同的 `extent`:
```cpp
std::array arr{1, 2, 3, 4, 5}; // 1, 2, 3, 4, 5 称为 extent
std::vector vec{1, 2, 3, 4, 5};
std::span<int> vecSpanDyn{vec};
std::span<int> arrSpanDyn{arr};
std::same_as<decltype(arrSpanDyn), decltype(vecSpanDyn)> // true
```
然而 `span` 的类模板参数推导从数组推导出 `fixed extent`，从 `vector` 推导出 `dynamic extent`：
```cpp
std::array arr{1, 2, 3, 4, 5};
std::vector vec{1, 2, 3, 4, 5};
std::span arrSpan{arr}; // deduces std::span<int, 5>
std::span vecSpan{vec}; // deduces std::span<int>
std::span<int, 5> vecSpan5{vec};
std::same_as<decltype(arrSpan), decltype(vecSpan)> // false
std::same_as<decltype(arrSpan), decltype(vecSpan5)> // true
```
`span` 与子范围的主要区别是对元素连续存储的要求，此外，`span` 不需要对其引用的类型支持迭代器，可以传递 `data()` 成员函数以访问元素序列的类型。
在内部，子范围仍然使用迭代器，因此可以引用所有类型的容器和范围，但这可能会导致更多的开销。
### Const Correctness of Spana
`span` 是具有引用语义的视图，其行为就像指针，但可以对 `const span` 的底层元素进行写访问，因为视图的 `const` 不会传播，前提是这些元素本身不是 `const`：
```cpp
std::array a1{1, 2, 3, 4, 5, 6,7 ,8, 9, 10};
std::array a2{0, 8, 15};
const std::span<int> sp1{a1}; // span/view is const
std::span<const int> sp2{a1}; // elements are const
sp1[0] = 42; // OK
sp2[0] = 42; // ERROR
sp1 = a2; // ERROR
sp2 = a2; // OK
```
只要 `std::span<>` 的元素没有声明为 `const`，就可以通过一些操作对元素进行写访问，因此所有设计用来确保元素为 `const` 的函数都会因 `std::span` 而无法确保：
```cpp
template<typename T>
void modifyElemsOfConstColl (const T& coll)
{
    coll[0] = {}; // OK for spans, ERROR for regular containers
    auto ptr = coll.data();
    *ptr = {}; // OK for spans, ERROR for regular containers
    for (auto pos = std::cbegin(coll); pos != std::cend(coll); ++pos) {
        *pos = {}; // OK for spans, ERROR for regular containers
    }
}

std::array arr{1, 2, 3, 4, 5, 6, 7 ,8, 9, 10};
modifyElemsOfConstColl(arr); // ERROR: elements are const
modifyElemsOfConstColl(std::span{arr}); // OOPS: compiles and modifies elements of a1
```
因此像 `std::cbegin()` 和 `std::ranges::cbegin()` 这样的函数会破坏具有引用语义的集合。为确保函数只接受不能以这种方式修改元素的序列，可以要求 `const` 容器的 `begin()` 返回一个指向 `const` 元素的迭代器：
```cpp
template<typename T>
void ensureReadOnlyElemAccess (const T& coll)
requires std::is_const_v<std::remove_reference_t<decltype(*coll.begin())>>
{...}
```
提供 `cbegin()` 和 `cend()` 的意义在于确保元素在迭代时不能被修改。最初，`span` 确实为 `const_iterator`、`cbegin()` 和 `cend()` 提供成员以确保不能修改元素。但在最后 `std::cbegin()/std::ranges::cbegin()` 迭代时仍然会修改元素。
然而，不是修复 `std::cbegin()/std::ranges::cbegin()`，而是删除 `span` 中的 `const` 迭代器成员，这使得问题更加严重，因为在 `C++20` 中，现在没有简单的方法对 `span` 进行只读迭代，除非元素为 `const`。
### Using Spans as Parameters in Generic Code
可以通过以下声明实现所有 `span` 的泛型函数：
```cpp
template<typename T, std::size_t Sz>
void printSpan(std::span<T, Sz> sp);
```
这甚至适用于具有动态范围的 `span`，可使用特殊值 `std::dynamic_extent` 作为大小。实现中，可以按以下方式处理固定与动态区段的区别:
```cpp
template<typename T, std::size_t Sz>
void printSpan(std::span<T, Sz> sp) {
    std::cout << '[' << sp.size() << " elems";
    if constexpr (Sz == std::dynamic_extent) 
        std::cout << " (dynamic)";
    else 
        std::cout << " (fixed)";
    std::cout << ':';
    for (const auto& elem : sp) 
        std::cout << ' ' << elem;
    std::cout << "]\n";
}
// 模板类型推导不起作用，需要显式类型转换或显式定义
printSpan(vec); // ERROR: template type deduction doesn’t work
printSpan(std::span{vec}); // OK
printSpan<int, std::dynamic_extent>(vec); // OK (provided it is a vector of ints)
```
可能会考虑将元素类型声明为 `const`：
```cpp
template<typename T, std::size_t Sz>
void printSpan(std::span<const T, Sz> sp);
```
但是，在这种情况下，不能传递具有 `non-const` 元素类型的 `span`，因为 `non-const` 到 `const` 的转换在模板中是不行的。
因此，不应将` std::span<>` 用作处理存储在连续内存中元素序列的泛型函数，出于性能考虑，可以这样做：
```cpp
template<typename E>
void processSpan(std::span<typename E>) {
    ... // span specific implementation
}

template<typename T>
void print(const T& t) {
    if constexpr (std::ranges::contiguous_range<T> t) {
        processSpan<std::ranges::range_value_t<T>>(t);
    }
    else {
        ... // generic implementations for all containers/ranges
    }
}
```
`span` 是租借范围，所以迭代器的生命周期不依赖于 `span`，可以在生成迭代器的算法中使用临时 `span` 作为范围：
```cpp
std::vector<int> coll{25, 42, 2, 0, 122, 5, 7};
auto pos1 = std::ranges::find(std::span{coll.data(), 3}, 42); // OK
std::cout << *pos1 << '\n';
```
但若 `span` 引用的是临时对象，则会出现错误：
```cpp
auto pos2 = std::ranges::find(std::span{getData().data(), 3}, 42);
// 即使返回一个被销毁的临时对象的迭代器也会通过编译
std::cout << *pos2 << '\n'; // runtime ERROR
```
## Span Operations
### Span Operations and Member Types Overview
`span` 不支持以下操作：
- 除 `==` 以外的比较操作
- `swap()`、`assign()`、`at()`
- `I/O` 操作符、哈希、用于结构化绑定的类元组 `API` 
- `cbegin()`，`cend()`，`crbegin()`，`crend()` 
此外，`std::value_type` 不是指定的元素类型(`std::array` 和其他容器的 `value_type` 通常是)，而是去掉 `const` 和 `volatile` 的元素类型。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214133038.png)
### Constructors
只有当 `span` 具有动态区段或范围为 0 时，才提供默认构造函数，此时 `size(`) 返回 0，`data(`) 返回 `nullptr`：
```cpp
std::span<int> sp0a; // OK
std::span<int, 0> sp0b; // OK
std::span<int, 5> sp0c; // compile-time ERROR
```
可以使用数组的开始迭代器和大小为参数初始化 `span`，若开始迭代器指向连续存储器中的元素，将使用 `std::views::counts`，这也适用于类模板参数推导：
```cpp
std::span sp1d{arr.begin() + 5, 5}; // std::span<int>
auto sp1e = std::views::counted(arr.data() + 5, 5); // std::span<int>
```
 当使用原始数组或 `std::array<>` 初始化时，除非显示指定单个元素类型作为模板参数，否则将推导出具有固定范围的 `span`：
```cpp
int a[10] {};
std::array arr{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
std::span sp1a{a}; // std::span<int, 10>
std::span sp1b{arr}; // std::span<int, 15>
std::span<int> sp1c{arr}; // std::span<int>
```
使用 `std::vector<>` 初始化时，除非显式指定 `span` 的大小，否则将推导出具有动态区段的 `span`
```cpp
std::vector vec{1, 2, 3, 4, 5};
std::span sp2a{vec}; // std::span<int>
std::span<int> sp2b{vec}; // std::span<int>
std::span<int, 2> sp2c{vec}; // std::span<int, 2>
std::span<int, std::dynamic_extent> sp2d{vec}; // std::span<int>
std::span<int, 2> sp2e{vec.data() + 2, 2}; // std::span<int, 2>
std::span sp2f{vec.begin() + 2, 2}; // std::span<int>
auto sp2g = std::views::counted(vec.data() + 2, 2); // std::span<int>
```
若使用右值初始化 `span`，则元素必须为 `const`：
```cpp
std::span sp3a{getArrayOfInt()}; // ERROR: rvalue and not const
std::span<int> sp3b{getArrayOfInt()}; // ERROR: rvalue and not const
std::span<const int> sp3c{getArrayOfInt()}; // OK
std::span sp3d{getArrayOfConstInt()}; // OK
std::span sp3e{getVectorOfInt()}; // ERROR: rvalue and not const
std::span<int> sp3f{getVectorOfInt()}; // ERROR: rvalue and not const
std::span<const int> sp3g{getVectorOfInt()}; // OK
```
但使用临时集合初始化的 `span` 可能会导致致命的运行时错误：
```cpp
for (auto elem : std::span{getCollOfConst()}) ... // fatal runtime error
for (auto elem : std::span{getCollOfConst()}.last(2)) ... // fatal runtime error
for (auto elem : std::span<const Type>{getColl()}) ... // fatal runtime error
```
在迭代临时对象返回的引用时，基于范围的 `for` 循环会导致未定义的行为，因为临时对象在循环开始内部迭代之前将会销毁。作为一种解决方案，可以使用带有初始化的基于范围 `for` 循环：
```cpp
for (auto&& coll = getCollOfConst(); auto elem : std::span{coll}) ... // OK
```
无论用一个迭代器和一个长度初始化 `span`，还是用两个定义有效范围的迭代器初始化 `span`，迭代器都必须指向连续内存中的元素(满足 `std::consecuous_iterator` 的概念):
```cpp
std::vector<int> vec{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
std::span<int> sp6a{vec}; // OK, refers to all elements
std::span<int> sp6b{vec.data(), vec.size()}; // OK, refers to all elements
std::span<int> sp6c{vec.begin(), vec.end()}; // OK, refers to all elements
std::span<int> sp6d{vec.data(), 5}; // OK, refers to first 5 elements
std::span<int> sp6e{vec.begin()+2, 5}; // OK, refers to elements 3 to 7 (including)
std::list<int> lst{ ... };
std::span<int> sp6f{lst.begin(), lst.end()}; // compile-time ERROR
```
也可以使用原始数组或 `std::array` 直接创建和初始化 `span`，由于元素数量不合法而导致的一些运行时错误将成为编译时错误:
```cpp
int raw[10];
std::array arr{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
std::span<int> sp8a{raw}; // OK, refers to all elements
std::span<int> sp8b{arr}; // OK, refers to all elements
std::span<int, 5> sp8c{raw}; // compile-time ERROR
std::span<int, 5> sp8d{arr}; // compile-time ERROR
std::span<int, 5> sp8e{arr.data(), 5}; // OK
```
但如果使用 `vector` 初始化 `fixed span`，则必须匹配所传递范围中的元素数量，而且编译器不能在编译时检查：
```cpp
std::vector<int> vec{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
std::span<int, 10> sp7a{vec}; // OK, refers to all elements
std::span<int, 5> sp7b{vec}; // runtime ERROR (undefined behavior)
std::span<int, 20> sp7c{vec}; // runtime ERROR (undefined behavior)
std::span<int, 5> sp7d{vec, 5}; // compile-time ERROR
std::span<int, 5> sp7e{vec.begin(), 5}; // OK, refers to first 5 elements
std::span<int, 3> sp7f{vec.begin(), 5}; // runtime ERROR (undefined behavior)
std::span<int, 8> sp7g{vec.begin(), 5}; // runtime ERROR (undefined behavior)
std::span<int, 5> sp7h{vec.begin()}; // compile-time ERROR
```
### Construction with Implicit Conversions
`span` 必须具有它们引用的序列元素的元素类型，并且不支持转换(甚至是隐式的标准转换)，但允许使用 `const` 等其他限定符，这也适用于复制构造函数：
```cpp
std::vector<int> vec{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
std::span<const int> sp9a{vec}; // OK: element type with const
std::span<long> sp9b{vec}; // compile-time ERROR: invalid element type
std::span<int> sp9c{sp9a}; // compile-time ERROR: removing constness
std::span<const long> sp9d{sp9a}; // compile-time ERROR: different element type
```
为允许容器引用用户定义容器的元素，这些容器必须表明其迭代器要求所有元素都位于连续内存中，即满足 `continuous_iterator` 的概念。
构造函数还允许在 `span` 之间进行以下类型转换：
- 具有固定区段的 `span` 将转换为具有相同的固定区段和附加限定符的 `span`。
- 具有固定区段的 `span` 与具有动态区段的 `span` 互相转换，但只有直接初始化才允许 `dyn span` 隐式转换到 `fixed span`，并且需要区段适合。
```cpp
std::vector<int> vec{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
std::span<int> spanDyn{vec.begin(), 5}; // OK
std::span<int> spanDyn2 = {vec.begin(), 5}; // OK
// 可以使用直接初始化
std::span<int, 5> spanFix{vec.begin(), 5}; // OK
// 但无法使用拷贝初始化：
std::span<int, 5> spanFix2 = {vec.begin(), 5}; // ERROR

void fooDyn(std::span<int>);
void fooFix(std::span<int, 5>);

fooDyn(spanDyn); // OK
fooFix(spanFix); // OK

fooDyn(spanFix); // OK Fix->Dyn
fooFix(spanDyn); // ERROR Dyn->Fix 不允许拷贝初始化

fooDyn({vec.begin(), 5}); // OK
fooFix({vec.begin(), 5}); // ERROR Dyn->Fix 不允许拷贝初始化

spanDyn = spanDyn; // OK
spanDyn = spanFix; // OK
spanFix = spanFix; // OK
spanFix = spanDyn; // ERROR 不允许拷贝初始化
```
### Operations for Sub-Spans
创建 `sub-span` 的成员函数也可以创建动态或固定区段的 `span`，将大小作为调用参数传递通常会产生具有动态区段的 `span`，而将大小作为模板参数传递通常会产生具有固定范围的 `span`：
```cpp
std::vector vec{1.1, 2.2, 3.3, 4.4, 5.5};
std::span spDyn{vec};
auto sp1 = spDyn.first(2); // first 2 elems with dynamic extent
auto sp2 = spDyn.last(2); // last 2 elems with dynamic extent
auto sp3 = spDyn.first<2>(); // first 2 elems with fixed extent
auto sp4 = spDyn.last<2>(); // last 2 elems with fixed extent

std::array arr{1.1, 2.2, 3.3, 4.4, 5.5};
std::span spFix{arr};
auto sp5 = spFix.first(2); // first 2 elems with dynamic extent
auto sp6 = spFix.last(2); // last 2 elems with dynamic extent
auto sp7 = spFix.first<2>(); // first 2 elems with fixed extent
auto sp8 = spFix.last<2>(); // last 2 elems with fixed extent

// 对于 subspan 函数，作为调用参数传递总会产生动态 span，但作为模板参数传递视情况而定
std::vector vec{1.1, 2.2, 3.3, 4.4, 5.5};
std::span spDyn{vec};
auto s1 = spDyn.subspan(2); // 3rd to last elem with dynamic extent
auto s2 = spDyn.subspan(2, 2); // 3rd to 4th elem with dynamic extent
auto s3 = spDyn.subspan(2, std::dynamic_extent); // 3rd to last with dynamic extent

auto s1 = spDyn.subspan<2>(); // 3rd to last with dynamic extent
auto s2 = spDyn.subspan<2, 2>(); // 3rd to 4th with fixed extent
auto s3 = spDyn.subspan<2, std::dynamic_extent>(); // 3rd to last with dynamic extent

std::array arr{1.1, 2.2, 3.3, 4.4, 5.5};
std::span spFix{arr};
auto s4 = spFix.subspan(2); // 3rd to last elem with dynamic extent
auto s5 = spFix.subspan(2, 2); // 3rd to 4th elem with dynamic extent
auto s6 = spFix.subspan(2, std::dynamic_extent); // 3rd to last with dynamic extent

auto s4 = spFix.subspan<2>(); // 3rd to last with fixed extent
auto s5 = spFix.subspan<2, 2>(); // 3rd to 4th with fixed extent
auto s6 = spFix.subspan<2, std::dynamic_extent>(); // 3rd to last with fixed extent
```