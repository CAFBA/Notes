# Modules
## Motivation for Modules Using a First Example
### Export
模块的 `API` 规范定义在其主模块接口单元中，每个模块只有一次：
```cpp modules/mod0.cppm
export module Square; // declare module Square
int square(int i);

export class Square {
private:
    int value;
public:
    Square(int i): value{square(i)} {}
    int getValue() const {
        return value;
    }
};

export template<typename T>
Square toSquare(const T& x) {
    return Square{x};
}

int square(int i) {
    return i * i;
}
```
主接口的关键是使用名称 `Square` 声明和导出模块的那行：
```cpp
export module Square; // declare module Square
export module Math.Square; // declare module “Math.Square”
```
模块名称仅用作导入模块的标识符，与模块内的任何符号都不冲突，不会引入新的作用域或命名空间，模块导出的任何名称仍然在导出时所在的作用域中。模块的名称可以包含句点，而句点在 `C++` 中使用的任何其他类型的标识符中都是无效的，作为模块名称标识符的字符句点是有效的，并且没有特殊含义，使用它们不会产生句法或形式上的后果。
模块的公共 `API` 由使用关键字 `export` 显式导出的所有内容定义。本例中，导出的是类 `Square` 和函数模板 `toSquare<>()`，其他所有内容都没有导出，所以没有导出的函数 `square()` 不能导入该模块使用。 
```cpp
export module MyMod; // declare module MyMod

// 可以导出类型，这将导出所有成员(若有的话)，不必导出类成员或枚举值
// 若导出类型，则自动导出枚举类型的类成员和值
export class MyClass;
export struct MyStruct;
export union MyUnion;
export enum class MyEnum;
export using MyString = std::string;

// 可以导出对象
export std::string progname;
namespace MyStream {
export using std::cout; // export std::cout as MyStream::cout
}
export auto myLambda = [] {};

// 可以导出函数
export friend std::ostream& operator<< (std::ostream&, const MyType&);

// export all symbols from OtherModule as a whole:
export import OtherModule;

// import LogModule to export parts of it:
import LogModule

// export Logger in the namespace LogModule as ::Logger:
export using LogModule::Logger;

// export Logger in the namespace LogModule as LogModule::Logger:
export namespace LogModule {
    using LogModule::Logger;
}

// export global symbol globalLogger:
export using ::globalLogger;

// export global symbol log (e.g., function log()):
export using ::log;
```
### Import
通过 `import`，`C++` 源代码文件都可以导入一个模块来使用导出的函数、类型和对象。`import` 不是一个普通的关键字，是一个上下文关键字。
使用 `import` 的翻译单元或模块单元，必须在模块预编译之后进行编译。否则，可能会得到模块未定义的错误，或可能会针对旧版本的模块进行编译，所以不能循环导入。
要在程序中使用模块的代码，必须以其名称导入该模块。下面是一个简单的程序示例，仅使用上面定义的模块 `Square`：
```cpp
import Square; // import module “Square”

Square x = toSquare(42);
std::cout << x.getValue() << '\n';
```
`import Square` 从模块 `Square` 中导入所有导出的符号，可以使用导出的类 `Square` 和函数模板 `toSquare<>()`，但使用未导出模块中的任何符号都会导致编译时错误。
### Modules and Namespaces
模块的符号会导入到与导出时相同的作用域中，因此与其他一些编程语言不同，`C++` 模块不会自动为模块引入命名空间，但可以通过两种方式将模块中的所有内容，导出到具有其命名空间中。
命名空间中使用 `export` 指定要导出的组件：
```cpp
export module Square; // declare module ”Square”
namespace Square {
    int square(int i);
    export class Square {
        ...
    };

    export template<typename T>
    Square toSquare(const T& x) {
        ...
    }

    int square(int i) { // not exported
        ...
    }
}
```
`export` 声明的命名空间中，指定想要导出的内容：
```cpp
export module Square; // declare module ”Square”
export namespace Square {
    class Square {...};
    template<typename T>
    Square toSquare(const T& x) {...}
}
int square(int i) {...} // not exported
```
这两种情况下，模块都会导出类 `Square::Square` 和 `Square::toSquare<>()`。现在使用该模块的方式如下所示：
```cpp
import Square; // import module ”Square”

Square::Square x = Square::toSquare(42);
std::cout << v.getValue() << '\n';
```
### Compiling Module Units
模块文件不仅仅是一个改进的头文件，它可以同时扮演头文件和源文件的角色，可以包含声明和定义。模块文件中，不必使用内联来定义函数或宏定义保护。可用它做两件事：
- 预编译声明(包括所有泛型代码)，将声明转换为特定编译器的格式
- 定义编译方式，创建通常的目标文件
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240214133741.png)
源模块文件不需要特定的文件扩展名，在这里使用 `.cppm`，假设有主模块接口 `mod0.cppm`，必须用两种方式处理它，如图所示：
- 必须预编译 `mod0.cppm`，创建一个包含所有导出声明(包括预编译的模板定义)的预编译模块文件，由模块 `Square` 的名称标识，而不是源文件的名称。预编译模块文件没有标准化后缀，这是由编译器决定的。通常，`gcc/g++` 对预编译文件使用 `.gcm` 并将它们放在 `gcm.cache` 子目录中。`Visual C++` 对预编译文件使用 `.ifc` 并将它们放在本地目录中。
- 必须编译 `mod0.cppm`，创建一个包含所有定义汇编代码的目标文件 `mod0.o` 或 `mod0.obj`。 
要成功编译导入模块的源文件，需要模块的预编译工件可用，所以必须在预编译 `mod0.cppm` 前编译 `mod0main.cpp`。若没有遵循正确的顺序，可能会导入指定模块的非最新版本，所以不允许循环导入依赖关系。 
##  Module Units
通常，模块由多个模块单元组成。所有模块单元都必须以某种方式编译，只包含声明(传统代码中的头文件)的模块单元也需要进行某种预编译。因此，这些文件总可转换成某种特定于平台的内部格式，以避免一次又一次地(预)编译相同的代码。
`C++` 主要提供以下单元类型来将模块的代码拆分为多个文件：
- `Module implementation units` 允许开发者在自己的文件中实现定义，以避免将它们放在一个文件中，这样就可以单独编译(类似于传统的 `C++` 源代码在 `.cpp` 文件)。
- `Internal partitions` 允许将模块局部声明和定义移到主接口之外，提供仅在模块内可见的声明和定义，可以由主接口导入，也可以只由需要它们的模块单元导入。 
- `Interface partitions` 允许在不同的文件中维护导出的接口。
- `Primary Interface` 将所有内容集合在一起，并指定导出给模块用户的内容(通过直接导出符号或导出导入的接口分区)。 
拥有的模块单元类型取决于 `C++` 源文件中的模块声明，必须以下列之一开头：
- `module;` 引入全局模块，用于使用预处理命令。
- `export module name;` 作为主接口，对于每个模块，只能在 C++ 程序中存在一次。
- `module name;` 作为模块实现单元仅提供定义，可以有多个。 
- `module name:partname;` 作为内部分区，其中的声明和定义仅在模块内使用。可以有多个分区，但是对于每个 `partname`，只能有一个内部分区文件。
- `export module name:partname;` 一个接口分区，拆分主接口。可以有多个接口分区，但是对于每个 `partname`，只能有一个接口分区文件。
### Primary Interface
主接口从 `module;` 开始，表示有一个全局模块。在 `module;` 与 `export module Mod1;` 之间的区域被称为 `global module fragment`，可以在其中使用一些预处理命令，如 `#define` 和 `#include`，但该区域中的内容都不会导出，用声明 `export module Mod1;` 正式启动模块单元之前，不能做其他事情。
```cpp modules/mod1/mod1.cppm
module; // start module unit with global module fragment

#include <string>
#include <vector>

export module Mod1; // module declaration

struct Order {
    int count;
    std::string name;
    double price;
    Order(int c, const std::string& n, double p): count{c}, name{n}, price{p} {}
};

export class Customer {
private:
    std::string name;
    std::vector<Order> orders;
public:
    Customer(const std::string& n): name{n} {}
    void buy(const std::string& ordername, double price) {
        orders.push_back(Order{1, ordername, price});
    }
    void buy(int num, const std::string& ordername, double price) {
        orders.push_back(Order{num, ordername, price});
    }
    double sumPrice() const;
    double averagePrice() const;
    void print() const;
};
```
### Module Implementation Units
模块实现单元以模块文件的声明开始 `module Mod1;`，该声明导入模块的主接口单元，所以 `Order` 和 `Customer` 类型的声明是已知的，可以直接提供它们的成员函数的实现。但模块实现单元不导出任何东西，导出只允许在模块(主接口或接口分区)的接口文件中进行，这些文件是用 `export module` 声明(每个模块只允许一个主接口)。
```cpp modules/mod1/mod1price.cpp
module Mod1; // implementation unit of module Mod1

double Customer::sumPrice() const {
    double sum = 0.0;
    for (const Order& od : orders) sum += od.count * od.price;
    return sum;
}

double Customer::averagePrice() const {
    if (orders.empty()) return 0.0;
    return sumPrice() / orders.size();
}
```
此外，模块实现单元也可能以  `global module fragment` 开始，目的是添加新的头文件：
```cpp modules/mod1/mod1io.cpp
module; // start module unit with global module fragment

#include <iostream>
#include <format>

module Mod1; // implementation unit of module Mod1

void Customer::print() const
{
    // print name:
    std::cout << name << ":\n";
    // print order entries:
    for (const auto& od : orders) {
        std::cout << std::format("{:3} {:14} {:6.2f} {:6.2f}\n",
        od.count, od.name, od.price, od.count * od.price);
    }
    // print sum:
    std::cout << std::format("{:25} ------\n", ' ');
    std::cout << std::format("{:25} {:6.2f}\n", " Sum:", sumPrice());
}
```
使用该模块的代码如下所示：
```cpp
#include <iostream>
import Mod1;
int main()
{
    Customer c1{"Kim"};
    c1.buy("table", 59.90);
    c1.buy(4, "chair", 9.20);
    c1.print();
    std::cout << " Average: " << c1.averagePrice() << '\n';
}
```
### Internal Partitions
前述的 `Order` 仅能在模块内使用，这在大型项目中是无法扩展的。因此需要使用内部分区，在单独的文件中声明和定义模块的内部类型和函数，分区还可以用于在单独的文件中定义导出接口的各个部分。
分区的语法为模块名:分区名，通过使用内部分区，可以在自己的模块单元中定义本地类型 `Order`：
```cpp modules/mod2/mod2order.cppp
module; // start module unit with global module fragment

#include <string>

module Mod2:Order; // internal partition declaration

struct Order {
    int count;
    std::string name;
    double price;
    Order(int c, const std::string& n, double p): count{c}, name{n}, price{p} {}
};
```
主接口只能使用名称来导入这个分区：
```cpp modules/mod2/mod2.cppm
module; // start module unit with global module fragment

#include <string>
#include <vector>

export module Mod2; // module declaration

import :Order; // import internal partition Order

export class Customer {...};
```
主接口必须导入内部分区，因为它使用 `Order` 类型。通过导入内部分区，分区在模块的所有单元中都可用，如果不在主接口导入，则所有需要 `Order` 类型的模块单元都必须直接导入内部分区。 
分区只是模块的内部实现方面，对于代码的用户来说，代码是在主模块中、模块实现单元中还是在内部分区中都无关紧要，但不能导出内部分区中的代码。
### Interface Partitions
接口分区可以将模块的接口拆分为多个文件，这些分区本身可以导出相应的内容。为只定义 `Customer` 接口，可以提供以下文件:
```cpp modules/mod3/mod3customer.cppm
module; // start module unit with global module fragment

#include <string>
#include <vector>

export module Mod3:Customer; // interface partition declaration

import :Order; // import internal partition to use Order

export class Customer {...};
```
接口分区与主接口的区别在于：
- 作为一个分区，在模块名和冒号后面声明其名称
- 像主接口一样，可以导出这个模块分区
主接口仍然是指定模块导出内容的唯一地方，但主模块可以将导入的接口分区作为一个整体直接导出，从而将导出委托给接口分区：
```cpp modules/mod3/mod3.cppm
export module Mod3; // module declaration
export import :Customer; // import and export interface partition Customer
... // import and export other interface partitions
```
通过同时导入接口分区和导出接口分区，主接口导出分区 `Customer` 的接口作为自己的接口。
## Dealing with Module Files with Different Compilers
`C++` 中，扩展是不标准化的，实践中，会使用不同的文件扩展名，所以也没有模块的标准后缀。更糟糕的是，甚至不同意是否有必要 (目前) 进行新的后缀。原则上，有两种判断方法：
- 编译器应该将各种模块文件视为普通的 `C++` 源文件，并根据其内容找出如何处理方法。使用这种方法，所有文件的扩展名仍然是 `.cpp`，`gcc/g++` 遵循这个策略。
- 编译器对模块文件的处理方式不同，因为它们既可以是声明文件(传统的头文件)，也可以是定义文件 (传统的源文件)。由于这个原因，使用不同的后缀非常有帮助，编译器甚至可能间接地要求使用不同的后缀，以避免对相同的扩展使用不同的命令行选项，Visual C++ 遵循这种方法。
对于接口文件(主接口和接口分区)，使用文件扩展名 `.cppm`。原因是：
- 最好的自解释文件扩展名。
- 这是 `Clang` 目前所需要的，也可以在 `gcc` 中使用。
- `Visual C++` 无论如何都需要特殊处理，除非使用扩展名 `.ixx`。
对于模块实现文件(但不是分区实现文件)，使用通常的文件扩展名 `.cpp`。原因是没有生成特殊的工件，不需要特殊的命令行选项。
对于内部分区文件(分区实现文件)，使用文件扩展名 `.cppp`。原因是：
- `Visual C++` 需要命令行选项/internalPartition 来存放这些文件。文件后缀不重要，所以必须使用特殊后缀，以便在不想解析文件内容的构建系统中有机会使用通用规则。 
- 也可以在 `gcc` 中使用。
## Dealing with Header Files
虽然理论上模块可以取代所有传统的头文件，但实际上这永远不会发生。将会有一些不需要使用模块的头文件，其来自为` C++` 和 `C` 开发的代码和库。使用传统头文件的基本方法是使用全局模块：
- 以 `module;` 声明开始后，在进行模块声明之前放置所有必要的预处理器命令 ，包含的头文件中未使用的所有内容都将丢弃，使用的所有内容都将获得模块链接，所以只在整个模块单元中可见，而在其他模块单元和模块外部都不可见。
- 应该在 `#include` 之前使用 `#define`。声明模块之后，不再支持 `#include`，但可以使用其他预处理器命令，如 `#define` 和 `#ifdef`。
```cpp
module;

#define NDEBUG
#include <string>
#include <cassert>

export module ModTest;
...
void foo(std::string s) {
    assert(s.empty()); // valid but not checked
    ...
}
```
这个全局模块中，预处理器符号 `NDEBUG` 和宏 `assert()` 都是在这个模块单元中定义的。但由于 `NDEBUG`，使用 `assert()` 的运行时检查都是禁用的。 `NDEBUG` 和 `assert()` 在该模块或导入模块的其他单元中都不可见。 
未来的目标是使整个 `C++` 标准库作为模块可用。然而，对于标准的 `C++` 头文件，已经可以使用 `import`，然后可以在模块中使用。例如:
```cpp
export module ModTest;
import <chrono>;
```
通过此导入，甚至可以在该模块中看到宏(对于所有其他导入，都不可见)。但在使用 `#define` 导入之前定义的常量不会传递给导入的头文件。这样，就可以保证导入的头文件的内容总是相同的。
此功能只保证在标准 `C++` 头文件上工作，不适用于 `C++` 使用的标准 `C` 头文件。标准模块 `C++20` 只是介绍了这种技术，没有引入任何标准模块，在 `C++23` 将有两个标准模块：
- `std` 将提供来自 `C++` 头文件的命名空间 `std` 中的所有内容，包括那些包装 `C` 的内容。不提供宏和特性测试宏。对于它们，必须手动包。
- `std.compat` 将提供模块 `std` 中的所有内容，以及 `C` 头文件中的 `C` 符号对应项。
## Private Module Fragments
可以在主接口中声明私有模块，使得其中的声明和定义对任何其他模块或翻译单元都是不可见或不可达的。
```cpp
export module MyMod;

// 首先用 export 声明类 C 和函数 print():
export class C; // class C is exported
export void print(const C& c); // print() is exported

class C {}; // provides details of the exported class
void print(const C& c) {} // provides details of the exported function
```
翻译单元都可以导入该模块，并使用 `C` 类型的对象:
```cpp
import MyMod;
...
C c; // OK, definition of class C was exported
print(c); // OK (compiler can replace the function call with its body)
```
若想在模块中封装定义，使得导入代码只看到声明，可以将定义放在私有模块中：
```cpp
export module MyMod;

export class C; // declaration is exported
export void print(const C& c); // declaration is exported

module :private; // following symbols are not even implicitly exported

class C {}; // complete class not exported
void print(const C& c) {} // definition not exported
```
声明私有模块只能发生在主接口中，并且只能发生一次。有了这个声明，之后使用 `export` 来导出内容都是错误的。通过将定义移动到私有模块中，导入代码就不能再使用其中的任何定义，只能使用不完整类型。
```cpp
import MyMod;
...
C c; // ERROR (C only declared, not defined)
print(c); // OK (compiler can replace the function call with its body)

// 声明还是可以使用 C 类型的引用和指针:
import MyMod;
...
void foo(const C& c) { // OK
    print(c); // OK
}
```
## Reachable versus Visible Symbols
当导出的 `API` 提供对未导出的类型的访问时，可能会出现可访问但不可见的符号，因此导入模块时，可以间接导入导出 `API` 所使用的所有类型。
下面的模块将 `getPerson()` 导出为一个可见的符号，将 `Person` 导出为一个可访问的类:
```cpp
module;

#include <iostream>
#include <string>

export module ModPerson; // THE module interface

class Person { // note: not exported
    std::string name;
public:
    Person(std::string n): name{std::move(n)} {}
    std::string getName() const {
        return name;
    }
};

std::ostream& operator<< (std::ostream& strm, const Person& p) {
    return strm << p.getName();
}

export Person getPerson(std::string s) {
    return Person{s};
}
```
导入该模块会产生以下结果：
```cpp
#include <iostream>
import ModPerson; // import module ModPerson
...
Person p1{"Cal"}; // ERROR: Person not visible
Person p2 = getPerson("Kim"); // ERROR: Person not visible
auto p3 = getPerson("Tana"); // OK

std::string s1 = p3.getName(); // ERROR: 没有 #include <string>
auto s2 = p3.getName(); // OK

std::cout << p3 << '\n'; // ERROR: free-standing operator<< not exported
std::cout << s2 << '\n'; // OK

// 甚至可以像下面这样声明一个 Person 类型对象
decltype(std::declval().getPerson("Tana")) P; // P has non-exported type Person
```
间接导出的符号不可见，但可访问的行为允许开发者在其导出的接口中，使用相同符号名称的不同模块。例如，有一个模块定义了一个类 `Person`：
```cpp
export module ModPerson1;
class Person {...};
export Person getPerson1(std::string s) {
    return Person{s};
}

// 另一个模块也定义了一个不同的类 Person:
export module ModPerson2;
class Person {...};

export Person getPerson2(std::string s) {
    return Person{s};
}
```
程序可以导入两个模块而不会产生任何冲突，因为唯一可见的符号是第一个模块的 `getPerson1()` 和第二个模块的 `getPerson2()`。下面的代码可以正常工作:
```cpp
auto p1 = getPerson1("Tana");
auto s1 = p1.getName();
auto p2 = getPerson2("Tana");
auto s2 = p2.getName();
// p1 和 p2 的类型名称相同，但实际类型不同
std::same_as<decltype(p1), decltype(p2)> // yields false
```
