# Something
## if 初始化器
`C++` 允许在 `if` 语句中包括一个初始化器，语法如下:
```cpp
if (<initializer>; <conditional_expression>) {
    <if_body>
} else if (<else_if_expression>) {
    <else_if_body>
} else {
    <else_body>
}

// 与 if 语句一样，可以在 switch 语句中使用初始化器
switch (<initializer>; <expression>) { <body> }
```
`<initializer>` 中引入的任何变量只在 `<conditional_expression>`、`<if_body>`、`<else_if_expression>`、`<else_body>` 中可用，在 `if` 语句以外不可用。
## for 初始化器
从 `C++20` 开始，可以在基于范围的 `for` 循环中使用初始化器：
```cpp
for (<initializer>; <for-range-declaration> : <for-range-initializer>) {
    <body> 
}

for (array arr { 1, 2, 3, 4 }; int i : arr) { cout << i << endl; }
```
## 指派初始化器
`C++20` 引入了指派初始化器，以使用它们的名称初始化聚合的数据成员。聚合类型是满足以下限制的数组类型的对象或结构或类的对象：仅 `public` 数据成员、无用户声明或继承的构造函数、无虚函数和无虚基类、`private` 或 `protected` 的基类。
```cpp
struct Employee {
    char firstInitial;
    char lastInitial;
    int employeeNumber;
    int salary { 75'000 };
};

Employee anEmployee { 'J', 'D', 42, 80'000 };
// 使用指派初始化器，可以被写成这样
Employee anEmployee {
    .firstInitial = 'J',
    .lastInitial = 'D',
    .employeeNumber = 42,
    .salary = 80'000
};
```
指派初始化器以点开头，后跟数据成员的名称，顺序必须与数据成员的声明顺序相同，不允许混合使用指派初始化器和非指派初始化器。
使用指派初始化器，可以跳过某些成员的初始化，因为未使用指派初始化器初始化的任何数据成员都将使用其默认值进行初始化，因此拥有类内初始化器的成员会得到类内初始值，没有类内初始化器的成员会被默认初始化。如果像下面这样跳过初始化 `salary` 数据成员，它就会得到它的默认值 `75'000`。
```cpp
Employee anEmployee {
 .firstInitial = 'J',
 .lastInitial = 'D'
};
```
使用指派初始化器的最后一个好处是，当新成员被添加到数据结构时，使用指派初始化器的现有 代码将继续起作用，新的数据成员将使用其默认值进行初始化。
## 结构化绑定
结构化绑定允许声明多个变量，这些变量使用数组、结构体、`pair` 或元组中的元素以初始化，必须为结构化绑定使用 `auto` 或 `auto&` 或 `const auto&` 关键字，使用结构化绑定声明的变量数量必须与右侧表达式中的值数量匹配。
```cpp
array values { 11, 22, 33 };
auto [x, y, z] { values };
```
如果所有非静态成员都是公有的，也可将结构化绑定用于结构体。
```cpp
struct Point { double m_x, m_y, m_z; };
Point point;
point.m_x = 1.0; point.m_y = 2.0; point.m_z = 3.0;
auto [x, y, z] { point };
```
以下代码段将 `pair` 中的元素分解为单独的变量:
```cpp
pair myPair { "hello", 5 };
auto [theString, theInt] { myPair }; // Decompose using structured bindings.
cout << format("theString: {}", theString) << endl;
cout << format("theInt: {}", theInt) << endl;
```
## Attribute
属性是一种将可选的和/或特定于编译器厂商的信息添加到源代码中的机制。从 C++11 开始，通过使用双方括号语法 `[[attribute]]` 对属性进行标准化的支持。
`[[nodiscard]]` 属性可用于有一个返回值的函数，以使编译器在该函数被调用却没有对返回的值进行任何处理时发出警告，从 C++20 开始，可以字符串形式为 `[[nodiscard]]` 属性提供一个原因：
```cpp
[[nodiscard("Some explanation")]] int func();
```
`[[maybe_unused]]` 属性可用于禁止编译器在未使用某些内容时发出警告
向函数添加 `[[noretum]]` 属性意味着它永远不会将控制权返回给调用点。通常，函数要么导致某种终止，要么引发异常。使用此属性，编译器可以避免发出某些警告或错误。
```cpp
[[noreturn]] void forceProgramTermination()
{
 std::exit(1); // Defined in <cstdlib>
}
```
`[[deprecated]]` 可用于将某些内容标记为已弃用，这意味着仍可以使用它，但不鼓励使用。此属性接受一个可选参数，该参数可用于解释弃用的原因。
`[[likely]] [[unlikely]] `这些可能性属性可用于帮助编译器优化代码。例如，这些属性可用于根据某个分支被采用的可能性来标记 `if` 和 `switch` 语句的分支。
## void_t Meta Function
在C++17标准库中，引入了元函数void_t用于检测一个给定的类型是否良构，进一步根据良构与否选择不同分支的代码，一般用于模板类与其特化版本之间的选择。void_t可简单通过类型别名的方式实现
```c++
template<typename...> using void_t =void;
```
该元函数输入的是一系列类型模板参数，如果这些类型良构，那么输出的类型将为void。考虑编写一个谓词元函数，判断输入的类型是否存在成员类型::type
```c++
template<typename T, typename = void> // typename = void_t<> 
struct HasTypeMember : std::false_type ｛｝; // 主模板

template<typename T> // 偏特化版本，待确定一个类型参数
struct HasTypeMember<T, void t<typename T::type>> : std::true_type {}; 
static assert(!HasTypeMemberint<int>::value); // int没有类型成员::type
static assert (!HasTypeMemberint<ture_type>::value);  // true＿type 有类型成员::type
```
首先，主模板声明要求输入两个类型参数，用户只需要提供第一个类型参数，另一个默认为void类型，默认输出为假。同时提供一个偏特化版本，当输入的类型拥有成员类型：:type时，即类型T::type良构，那么void_t得到的结果为void，从而输出真。主模板与特化版本之间的关系比较微妙，利用主模板第二个默认参数为void，即默认选择偏特化版本，只有当类型良构时，偏特化版本才会成立，否则仍将使用主模板。
通过断言测试来看看void_t元函数具体是怎么工作的。当用户输入的类型诸如int中不存在int::type类型成员时，模板类HasTypeMember<int, void>会选择哪个版本呢？由于偏特化版本的`void_t<typename int::type>`非良构，因此会选择主模板，即输出的结果为假，符合预期。当用户输入的类型为true_type时，该类型存在类型成员::type，模板类`HasTypeMember<true_type，void>`会选择哪个版本呢？由于偏特化版本`void_t<typename true_type::type>`良构，结果为void，因此会选择偏特化版本，输出结果为真，符合预期。
## Empty Base Class Optimization
C++中有些类是空的，这意味着这些类应该只包含类型成员、非虚函数或静态成员变量，只要存在非静态成员变量、虚函数、虚基类则意味着非空。对于空类，实际上它们的大小往往不是0，而是占用一个字节，考虑如下代码：
```c++
struct Base {};
static assert(sizeof (Base) == 1);
```
声明一个空类Base，它占用大小为1，这是因为计算机内存取址的最小单位为1个字节，假设空类只占用0个字节，考虑一个Base数组，每个元素将占用同样的内存地址，而实际上每个元素都应该拥有独立的地址以便区分，因此空类大小必须非零。
考虑将Base以成员组合方式定义Children，那么如下的Children将占用多少内存？由于字段other四字节对齐，而base一字节对齐，多出了3个字节的空隙，故最终占用8个字节：
```c++
struct Children { 
    Base base; 
    int other; 
};
static assert(sizeof(Children) == 8);
```
如果对空类进行继承，那么允许空类基类占用0个字节，即空基类优化。考虑如下等价的代码，以Base作为成员变量时占用1个字节和3个字节的空隙，而以基类的方式实现时最终只占用4个字节，基类占用0个字节：
```c++
struct Children : Base { 
    int other;
};
static assert(sizeof(Children) == 4);
```
由于空类也能包含一些有用的数据，例如using/typedef的类型成员，与空类的静态数据成员，继承它们后子类将复用这些数据，而无须委托。
考虑标准库提供的vector容器实现，它的第二个模板参数用于内存分配器，默认为`std::allocator<T>`，它可以对：:new和：:delete进行封装，允许用户提供自己的内存分配器，只需要根据分配器接口约定传递给vector的第二个模板参数即可。一个vector的实现至少需要存储3个指针：起点begin指针、终点end指针和当前分配的空间尾部指针，在64位编译器上占用24字节的空间。考虑存储额外的分配器对象，那么至少占用24字节。
由于大多数情况下使用标准库提供的默认分配器`allocator<T>`是无状态的空类，如果使用成员变量的方式存储，那么至少浪费1个字节；而用户传递的分配器可能是有状态的非空类。如果统一派生自分配器，那么将会享受到空基类优化的效果：使用无状态的分配器将无任何多余的空间开销；使用有状态的分配器将正常占用分配器的空间。
但这样会带来一个问题，由于分配器是允许用户传递的，在使用继承方式时，用户的分配器可能不知不觉间与vector实现中的成员变量产生冲突，又或者用户传递的分配器是final的而导致无法使用继承。归根结底是因为继承是一种代码白盒复用方式，而将分配器作为成员变量，则是代码黑盒复用方式，后者虽没有这些问题，但是无法实现空基类优化。因此C++20提供了`[[no_unique_address]]`属性来避免这个问题，**将成员变量用它修饰后，若该成员的类为空类，则同样享受被优化的结果，不占用额外空间**。考虑如下代码
```c++
struct Children {
    [[no unique address]]Base base; 
    int other;
};
static assert(sizeof(Children) ==4);
```
和最初的成员方式相比仅仅多了一个`[[no_unique_address]]`修饰，加上Base为空类，最终Children的大小仅占4个字节，实现了同样的空基类优化效果。而且其内存布局和通过空基类优化方式的布局一致。继承是一种代码白盒复用手段，派生类能够直接使用父类的信息；而成员组合是一种黑盒复用手段，因此只能通过委托使用。
## Type Deconstruction
一个类型本身可以由多个部分组成，例如数组类型`int[5]`由两部分组成：int类型与常量5构成；容器类型`vector<int>`由模板类vector与类型int构成；函数类型int(int)由两个int类型构成。通过使用模板类与特化方式，可以解构一个类型的各个组成部分。考虑最基本的一维数组类型，如何获得数组的长度信息
```c++
template<typename T> struct array size; // 元函数声明 
template<typename E, size_t N>          // 模板偏特化
struct array_size<E[N]> { 
    using value type = E;
    static constexpr size_t len = N; 
};

static assert(is_same_v<array_size<int[5]>::value_type, int>); 
static assert(array_size<int[5]>::len == 5);
```
首先，声明一个模板类array_size元函数，其接收一个数组类型作为输入，并在偏特化中实现。偏特化版本的模板头声明了两个模板参数：类型参数E存储的是数组的元素类型、非类型参数N存储的是长度信息，而`E[N]`构成了一个完整的数组类型T。其次，特化实现中存储了元素类型value_type与长度信息len作为元函数的输出。通过静态断言的测试，当输入为`int[5]`时，其组成的部分分别为int和长度5，符合预期。
考虑稍微复杂的场景，如何获得函数类型的各个组成部分？函数类型由一个返回类型与多个输入类型组成：
```c++
template<typename F> struct function trait; // 元函数实现 
template<typename Ret，typename...Args> // 模板偏特化 
struct function trait<Ret (Args...)> {
    using result_type = Ret;
    using args type = tuple<Args...>;
    static constexpr size_t num_of_args = sizeof...(Args);
    template<size_t I> using arg = tuple_element_t<I, args_type>; 
};
```
首先，声明一个模板类function_trait元函数，其接收一个函数类型作为输入，并在偏特化中实现。偏特化版本的模板头声明了一个类型参数Ret作为返回类型、一个可变模板参数包Args作为输入类型，而Ret(Args…)构成了一个完整的函数类型F。
其次，特化实现中存储了函数的返回类型result_type、入参类型args_type（由标准库中的元组tuple存储）、入参个数num_of_args以及成员元函数arg（它输入参数位置信息I，输出第I个入参的类型，由于入参类型存储于元组中，因此可以通过元函数tuple_element获得元组中第I个的类型）。通过静态断言可以构造出如下测试用例：
```c++
using F = void(int, float, vector<char>);
static assert(is_same_v<function_trait<F>::result_type, void>); 
static assert(function_trait<F>::num_of_args == 3);
static assert(is_same_v<function_trait<F>::arg<1>, float>);
```
用例中的函数类型返回类型为void，同时接受3个入参。通过result_type可以确定返回类型符合预期，num_of_args也与入参数量一致，通过成员元函数arg得知第1个入参的类型为float。
## Label Distribution
标签常常是一个空类，例如辅助类true_type和false_type类型可视作标签。关键在于将标签作用于重载函数中，根据不同的标签决议出不同的函数版本。同样考虑对数值进行判等操作的numEq的实现：
```c++
template<typename T> bool numEqImpl(T lhs, T rhs, true_type) { 
    return fabs(lhs - rhs) < numeric_limits<T>::epsilon(); 
}// #1 
template<typename T> bool numEqImpl(T lhs, T rhs, false_type) {
    return lhs == rhs;
}//#2

template<typename T> // 标签分发
auto numEq(T lhs, T rhs) -> enable_if_t<is_arithmetic_v<T>, bool> { 
    return numEqImpl(lhs, rhs, is_floating_point<T>{}); 
};
```
numEq函数原型中使用元函数enable_if以限制输入的类型必须为数值类型（整数和浮点类型），并根据是否为浮点类型对numEqImpl进行分发。这次考虑函数调用numEq(1.,2.)是如何工作的。根据实参的类型进行推导，得出模板参数为double，通过替换模板参数最终得到如下模板实例：
```c++
auto numEq<double>(double lhs, double rhs) -> bool { 
    return numEqImpl(lhs, rhs, is_floating_point<double>{}); 
}; 
// template<typename T> struct is_floating_point : false_type {}; 
// template<> struct is_floating_point<double> : true_type {};
```
is_floating_point元函数通过继承标签类型true_type来提供double类型的特化版本，值`is_floating_point<double>{}`能够自然地转换（协变关系）到它的父类true_type，从而匹配第一个numEqImpl版本，因为它的第三个形参类型为true_type。
## enable_shared_from_this
现代C++中常常使用智能指针管理对象的生命周期与所有权，标准库提供了非侵入式智能指针shared_ptr和unique_ptr，分别用于共享对象所有权和独占对象所有权。对于shared_ptr而言，它除了管理对象内存以外，还有一块额外的引用计数控制块，当引用计数大于0时，表明当前对象仍然被其他对象所占用；当引用计数为0时，则释放该对象的内存，从而避免手动管理内存，减轻了程序员的负担。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20231012000308.png)
shared_ptr拥有多个构造函数，其中最主要的两种是通过make_shared构造和通过new构造，这两种构造方式的内存布局差异如图2-6所示。make_shared通过C++的new特性使引用计数块和对象在内存上连续，而通过new构造的构造函数只能获得对象的指针，需要额外分配引用计数块，内存可能不连续，通过指针方式构造还有可能导致内存泄漏。因此建议使用make_shared来提高运行效率。
也正因为make＿shared构造时将引用计数块和对象一次性分配在一块内存上，当对象没有被任何共享指针所持有时将被销毁，只要有一个弱指针weak＿ptr指向它都不能直接释放引用计数块，从而导致连续的内存无法立即释放，同样存在内存泄漏风险。
异步编程中存在一种场景，需要在类中将该类的对象注册到某个回调类或函数中，不能简单地将this传递给回调类中，很可能因为回调时该对象不存在而导致野指针访问，也有可能在析构函数解注册时被回调，造成对象不完整。。若通过智能指针管理对象，也不能直接将this构造成shared_ptr，因为无法通过裸指针获得引用计数块信息，强行构造会导致对象内存多次释放。
```c++
struct Obj{
    void submit() {
        executor.submit([this] ｛ this->onComplete(); ｝) ; // 内存风险 
    ｝
    void onComplete() { /* ...*/} 
};
```
通过裸this指针构造智能指针的关键在于得到裸指针的引用计数信息，标准库提供的非侵入式智能指针存在引用计数块与对象独立的可能。为了解决这个问题，标准库提供了enable_shared_from_this模板基类，通过奇异递归模板模式在父类中存储子类的指针信息与引用计数信息，并提供shared_from_this和weak_from_this接口以获得智能指针。
智能指针在最初的构造之时，通过编译时多态手段来判断被构造的类是否派生自enable_shared_from_this，若派生则将相关信息存储至基类中供后续使用，否则什么也不做。这也体现了零成本抽象的哲学：如果程序员不需要从裸指针还原得到智能指针，就无须继承它，也无须支付额外开销。
```c++
// 根据是否派生自enable_shared_from_this来派发不同的实现has_esft_base 
template<typename _Yp,typename _Yp2 = typename remove_cv<_Yp>::type> 
typename enable_if<_has_esft_base<_Yp2>::value>::type
_M_enable_shared_from_this_with(_Yp*) noexcept ｛ // 已继承 
    if (auto_base = _enable_shared_from_this_base(_M_refcount, p)) 
        _base->_M_weak_assign(const_cast<_Yp2*>(_p), M_refcount); 
}

template<typename _Yp, typename_Yp2 = typename remove_cv<_Yp>::type> 
typename enable_if<!_has_esft_base<_Yp2>::value>::type
_M_enable_shared＿from_this_with(_Yp*) noexcept｛｝ // 未继承，空实现
```
可以通过enable_shared_from_this将异步回调中的例子改写成弱回调形式：lambda通过捕获weak_from_this接口得到弱指针，回调时通过将弱指针提升至共享指针来判断该对象是否还存在，若存在则调用，否则什么也不做。
```c++
struct Obj : enable_shared_from_this<obj> ｛ // 奇异递归模板模式 
    void submit() ｛ // weak＿from＿this 获得this指针的弱指针
        executor.submit(obj = weak＿from＿this()] ｛  // lock提升至共享指针 
            if (auto spobj = obj.lock()) { 
                spObj->onComplete();
            }
        }); 
    }
    void onComplete() { /* ...*/} 
};
```


# NTTP Extensions
## New Types for Non-Type Template Parameters
`C++` 模板形参不必仅仅是类型，也可以是值，但这些值的类型有限制。C++20 增加了更多可用于非类型模板形参的类型。并且从 `C++20` 开始，可以使用概念来约束 `NTTP` 的值。
自 `C++20` 起，可以为非类型模板形参使用：
- 浮点类型、结构和简单类、字符串字面值、`Lambda`
- 结构类型：`const` 或 `volatile` 限定的算术类型、枚举类型或指针类型、左值引用类型、字面量类型(要么是聚合类型，要么有 `constexpr` 构造函数，没有复制/移动构造函数，没有析构函数，没有复制/移动构造函数或析构函数，并且每个数据成员的初始化都是常量表达式)、所有基类都是 public 继承的、所有非静态成员都是 `public` 且不可变的，并且只使用结构类型或其数组
### Floating-Point Values as Non-Type Template Parameters
```cpp
template<double Vat>
int addTax(int value)
{
    return static_cast<int>(std::round(value * (1 + Vat)));
}
int main()
{
    std::cout << addTax<0.19>(100) << '\n';
    std::cout << addTax<0.19>(4199) << '\n';
    std::cout << addTax<0.07>(1950) << '\n';
}

// 当使用 auto 声明非类型模板形参时，现在也允许传递浮点值：
template<auto Vat>
int addTax(int value)
{
...}
std::cout << addTax<0>(1950) << '\n'; // Vat is the int value 0
std::cout << addTax<0.07>(1950) << '\n'; // Vat is the double value 0.07
```
由于舍入误差，浮点类型的值最终会略微不精确，处理浮点值作为模板参数时会产生影响，当模板的两个实例化具有相同的类型时会有问题：
```cpp
template<double Val>
class MyClass {};
int main()
{
    std::cout << std::boolalpha;
    std::cout << std::is_same_v<MyClass<42.0>, MyClass<17.7>> // always false
    std::cout << std::is_same_v<MyClass<42.0>, MyClass<126.0 / 3>> // true or false
    std::cout << std::is_same_v<MyClass<42.7>, MyClass<128.1/ 3>> // true or false
    std::cout << std::is_same_v<MyClass<0.1 + 0.3 + 0.00001>,
    MyClass<0.3 + 0.1 + 0.00001>> // true or false
    std::cout << std::is_same_v<MyClass<0.1 + 0.3 + 0.00001>,
    MyClass<0.00001 + 0.3 + 0.1>> // true or false
    constexpr double NaN = std::numeric_limits<double>::quiet_NaN();
    // 为 NaN 实例化的模板总是具有相同的类型，即使 NaN == NaN 为 false
    std::cout << std::is_same_v<MyClass<NaN>, MyClass<NaN>> // always true
}```
### Objects as Non-Type Template Parameters
`C++20` 起，可以使用数据结构或类的对象作为非类型模板形参，前提是结构类型：
```cpp
// 声明具有 public 成员的文本数据结构 Tax，一个 constexpr 构造函数和一个额外的成员函数
// 这允许将这种类型的对象作为模板参数传递:
struct Tax {
    double value;
    constexpr Tax(double v): value{v} {
        assert(v >= 0 && v < 1);
    }
    friend std::ostream& operator<< (std::ostream& strm, const Tax& t) {
        return strm << t.value;
    }
};

template<Tax Vat>
int addTax(int value)
{
    return static_cast<int>(std::round(value * (1 + Vat.value)));
}

int main()
{
    constexpr Tax tax{0.19};
    std::cout << "tax: " << tax << '\n';
    std::cout << addTax<tax>(100) << '\n';
    std::cout << addTax<tax>(4199) << '\n';
    std::cout << addTax<Tax{0.07}>(1950) << '\n';
}
```
也可以使用 `std::pair<>` 和 `std::array<>` 类型的编译时对象作为模板形参：
```cpp
template<auto Val>
class MyClass {
...
};
MyClass<std::pair{47,11}> mcp; // OK since C++20
MyClass<std::array{0, 8, 15}> mca; // OK since C++20
```
将字符数组作为公共成员的数据结构是结构类型，就可以很容易地将字符串字面量作为模板参数传递：
```cpp
template<auto Prefix>
class Logger {
    ...
    public:
    void log(std::string_view msg) const {
        std::cout << Prefix << msg << '\n';
    }
};

template<std::size_t N>
struct Str {
    char chars[N];
    const char* value() {
        return chars;
    }
    friend std::ostream& operator<< (std::ostream& strm, const Str& s) {
        return strm << s.chars;
    }
};

template<std::size_t N> Str(const char(&)[N]) -> Str<N>; // deduction guide
int main()
{
    Logger<Str{"> "}> logger;
    logger.log("hello");
}
```
### Lambdas as Non-Type Template Parameters
因为 `Lambda` 只是函数对象的引用，只要 `Lambda` 能在编译时使用，也可以用作非类型模板参数。以下是使用 `Lambda` 作为非类型模板形参的约束：
```cpp
template<std::invocable auto GetVat>
int addTax(int value)
{
    return static_cast<int>(std::round(value * (1 + GetVat())));
}

int main()
{
    auto getDefaultTax = [] {
        return 0.19;
    };
    std::cout << addTax<getDefaultTax>(100) << '\n';
    std::cout << addTax<getDefaultTax>(4199) << '\n';
    std::cout << addTax<getDefaultTax>(1950) << '\n';
    // 甚至可以在调用函数模板时直接定义 Lambda:
    addTax<[]{ return 0.19; }>(100) // passes lambda as template argument
}
```
用 `std::invocable` 或 `std::regular_invocable` 这两个概念约束模板参数就可以记录并确保可以使用指定类型的参数调用传递的可调用对象。通过使用 `std::invocable auto`，要求可调用对象不接受任何参数，若传递的可调用对象应该接受参数，则改为以下：
```cpp
template<std::invocable<std::string> auto GetVat>
int addTax(int value, const std::string& name)
{
    double vat = GetVat(name); // get VAT according to the passed name
    ...
}
```
此处 `auto` 作为类型约束约束可调用对象，若没有 `auto`，约束的将是普通类型形参的函数模板：
```cpp
template<std::invocable auto GetVat> // GetVat is a callable with constrained type
template<std::invocable GetVat> // GetVat is a constrained type
```
若用 `Lambda` 的具体类型声明函数模板也可以：
```cpp
auto getDefaultTax = [] {
    return 0.19;
};

template<decltype(getDefaultTax) GetVat>
int addTax(int value)
{
    return static_cast<int>(std::round(value * (1 + GetVat())));
}
```
