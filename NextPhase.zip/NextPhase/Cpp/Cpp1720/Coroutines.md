# Coroutines
普通函数⼀旦被调⽤，只能从头开始执⾏，直到函数执⾏结束退出，⽽协程则可以执⾏到⼀半就退出，即挂起协程，但此时协程并未真正结束，只是暂时让出 `CPU` 执⾏权，在后⾯适当的时机协程可以重新恢复运⾏，在这段时间⾥其他的协程可以获得 `CPU` 并运⾏，所以协程被描述称为轻量级线程，是可以分多个步骤运行的函数。 
协程存储函数在挂起时间点的执⾏状态，这个状态称为协程上下⽂。协程上下⽂包含函数在当前执⾏状态下的全部 `CPU` 寄存器的值，这些寄存器值记录函数栈帧、代码的执⾏位置等信息。`C++` 中的协程是无栈的，当协程挂起时，协程上下⽂作为一个整体被存储在与栈分离的对象中，以便它可以在完全不同的上下文中(在不同的调用栈中，在另一个线程中等)恢复，因此协程的生命周期会超出嵌套作用域，这也意味着协程是一个将其状态存储在某些内存中的对象。
因此协程的最简单形式是主控制流和协程的控制流都在同一个线程中运行，不需要使用多线程，也不需要处理并发访问，但也可以在不同的线程中运行协程，甚至可以在不同的线程上将协程恢复到先前挂起的位置。但不挂起外部协程的情况下，无法挂起在外部协程中调用的内部协程，只能将外部协程作为一个整体挂起。
与线程不同，线程创建之后，线程的运⾏和调度是由操作系统⾃动完成的，但协程创建后，协程的运⾏和调度都由应⽤程序来完成，就和调⽤函数⼀样，所以协程也被称为⽤户态线程。
协程通常返回一个对象，作为调用者的协程接口。根据协程的目的和用途，该对象可以表示一个不时挂起或切换上下文的正在运行的任务，或不时产生值的生成器，或一个按需惰性地返回一个或多个值的工厂。
## Stackless Coroutines
有栈协程⽤独⽴的执⾏栈来保存协程的上下⽂信息。当协程被挂起时，有栈协程会保存当前执⾏状态，并将控制权交还给调度器。当协程被恢复时，有栈协程会将之前保存的执⾏状态恢复，从上次挂起的地⽅继续执⾏。类似于内核态线程的实现，不同协程间切换还是要切换对应的栈上下⽂，只是不⽤陷⼊内核。 
⽆栈协程不需要独⽴的执⾏栈来保存协程的上下⽂信息，而是将协程的上下⽂都放到内存中。当协程被挂起时，⽆栈协程会将协程的状态保存在堆上的数据结构中，并将控制权交还给调度器。当协程被恢复时，⽆栈协程会将之前保存的状态从堆中取出，并从上次挂起的地⽅继续执⾏。不同协程间切换也不再需要切换对应的栈上下⽂。
## Independent  And Shared stacks
独⽴栈和共享栈都是有栈协程。
共享栈就是所有的协程在运⾏的时候都使⽤同⼀个栈空间，每次协程切换时都会拷⻉这个共享栈空间，处是公共资源内存空间⽐较⼤，相对安全，节省内存空间，坏处则是协程频繁切换需要进⾏内存拷⻉。当协程挂起时，将开辟合适的内存将协程栈内容暂时保存起来，恢复该协程的时候，再将之前保存的栈内容重新拷⻉到运⾏时栈中。
独⽴栈就是每个协程的栈空间都是独⽴的，固定⼤⼩。好处是协程切换的时候，不⽤拷⻉内存，坏处则是浪费内存空间或容易栈溢出。因为栈空间在运⾏时不能随时扩容，否则如果有指针操作执⾏栈内存，扩容后将导致指针失效。为防⽌栈内存不够，每个协程都要预留⾜够的栈空间使⽤。
## Advantages And Disadvantages
### Advantages
协程允许开发者编写异步代码，实现⾮阻塞的并发操作，通过在适当的时候挂起和恢复协程，可以有效地管理多个任务的执⾏，提⾼程序的并发性能。
与线程相⽐，协程是轻量级的，它们的创建和上下⽂切换开销较⼩，可以同时执⾏⼤量的协程，⽽不会导致系统负载过重，可以在单线程下实现异步，使程序不存在阻塞阶段，提⾼资源利⽤率。 
使⽤协程可以简化并发编程的复杂性，通过使⽤适当的协程库或语⾔特性，可以避免显式的线程同步、锁和互斥量等并发编程的常⻅问题，⽤同步的思想就可以编写成异步的程序。
### Disadvantages
线程才是系统调度的基本单位，单线程下的多协程本质上还是串⾏执⾏的，只能⽤到单核计算资源，所以协程往往要与多线程、多进程⼀起使⽤，主要问题是⽆法利⽤多核资源。
协程虽然被称为轻量级线程，但在单线程内，协程并不能并发执行，只能是一个协程结束或挂起后，再执行另一个协程，而线程则是可以真正并发执行的。因为单线程下协程并不是并发执行，而是顺序执行的，所以不要在协程里使用线程级别的锁来做协程同步，如果一个协程在持有锁之后让出执行，那么同线程的其他任何协程一旦尝试再次持有这个锁，整个线程就会锁死，这和单线程环境下，连续两次对同一个锁进行加锁导致的死锁道理完全一样。
## Using Coroutines
下面是使用协程的示例，每次执行循环中的 `print` 语句时，都会挂起协程。因此，函数可中断，协程的用户可以通过恢复触发下一个值的输出。
```cpp coro/coro.hpp
#include <iostream>
#include "corotask.hpp" // for CoroTask
CoroTask coro(int max)
{
    std::cout << " CORO " << max << " start\n";
    for (int val = 1; val <= max; ++val) {
        // print next value:
        std::cout << " CORO " << val << '/' << max << '\n';
        co_await std::suspend_always{}; // SUSPEND
    }
    std::cout << " CORO " << max << " end\n";
}
```
这个函数与普通函数不同：
`co_await` 表达式可挂起协程并阻塞协程，直到协程恢复，称为挂起点。挂起调用的确切行为由紧跟在 `co_await` 后面的表达式定义，此处使用 `std::suspend_always` 类型的默认构造对象，其接受挂起并将控制权交还给调用者，也可以通过将特殊操作数传递给 `co_await` 来拒绝挂起或恢复另一个协程。
虽然协程没有返回语句，但其有一个返回类型 `CoroTask`，此类型用作协程调用者的协程接口。返回类型是必需的，因为调用者需要一个接口来处理协程。`C++20` 中，协程接口类型必须由程序员(或第三方库) 提供，因此不能将返回类型声明为 `auto`。
```cpp coro/coro.cpp
#include <iostream>
#include "coro.hpp"
int main()
{
    // 此处可以使用 auto 作为协程接口类型
    auto coroTask = coro(3); // initialize coroutine
    std::cout << "coro() started\n";
    // 初始化协程后，产生协程接口 coroTask，启动循环一次次地恢复协程:
    while (coroTask.resume())  // RESUME
        // 先执行协程才会执行下述打印，当协程执行结束时 resume 返回 false，将不会有下述打印
        std::cout << "coro() suspended\n";
    std::cout << "coro() done\n";
}

coro() started
CORO 3 start
CORO 1/3
coro() suspended

CORO 2/3
coro() suspended

CORO 3/3
coro() suspended

CORO 3 end
coro() done
```
调用 `coro(3)` 不会等待协程执行结束，而是会返回协程接口来处理协程(在开始处有一个隐式挂起点)。类 `CoroTask` 提供的 `API` 提供成员函数 `resume()` 可用于恢复协程，当它返回 `true` 时意味着协程并未执行结束，每次调用 `resume()` 都允许协程继续在之前挂起的状态下运行，直到下一次挂起或直到协程结束。
协程恢复时会调用协程中的下一组语句，直到挂起点或结束：
```cpp
// First resume, the initial output, the initialization of val
// and the first output inside the loop:
std::cout << " CORO " << max << " start\n";
for (int val = 1; val <= max; ... ) {
    std::cout << " CORO " << val << '/' << max << '\n';
    ...
}
// Then twice resume, the next iteration in the loop:
for ( ... ; val <= max; ++val) {
    std::cout << " CORO " << val << '/' << max << '\n';
    ...
}
// Finally resume, after the last iteration in the loop
// the coroutine performs the final print statement:
for ( ... ; val <= max; ++val) {
    ...
}
std::cout << " CORO " << max << " end\n";
```
上述的控制流如下：
1. 首先，调用协程，使其启动，协程立即挂起，调用返回处理协程的接口对象。
2. 然后，使用接口对象调用来 `resume` 恢复协程，以便执行其语句。
3. 协程内部，处理开始语句直到第一个挂起点，先执行第一个 `print` 语句，然后在循环头部初始化局部计数器 `val`，并在检查 `val` 小于或等于 `max` 之后开始循环内的 `print` 语句。在这部分结束时，协程挂起。
4. 挂起将控制转移回主函数，然后主函数继续执行，直到再次恢复协程。 
5. 协程继续执行下一个语句，直到再次到达挂起点。接着上一次挂起时的状态，增加 `val` 并在检查 `val` 小于或等于 `max` 之后开始循环内的 `print` 语句。在这部分结束时，协程再次挂起。 
6. 再次将控制转移回主函数，然后主函数继续运行，直到再次恢复协程。只要增量 `val` 小于或等于 `max`，就重复上述挂起恢复的过程。
7. 最后，协程在 `val` 大于 `max` 之后离开循环，调用最后的 `print` 语句，值为 `max`。
8. 协程结束时，最后一次将控制转回主函数。然后 `main` 函数结束循环，并继续运行直到结束。 
协程的初始化和接口的确切行为取决于接口类型 `CoroTask`，其中可能是启动协程或提供具有一些初始化的上下文，还会定义协程是立即启动还是惰性启动(意味着立即挂起)。在 `CoroTask` 的当前实现中，是惰性启动的，所以协程的初始调用立即挂起，并没有执行 `coro()`。 
### Using Coroutines Multiple Times
协程是一种准并行函数，通过来回切换控制流来顺序执行，其状态存储在由协程句柄控制的堆内存中，该句柄通常由协程接口持有。通过拥有多个协程接口对象，可以处理多个活动协程的状态，这些协程可能彼此独立地运行或挂起。
```cpp 
#include <iostream>
#include "coro.hpp"
int main()
{
    // start two coroutines:
    auto coroTask1 = coro(3); // initialize 1st coroutine
    auto coroTask2 = coro(5); // initialize 2nd coroutine
    std::cout << "coro(3) and coro(5) started\n";
    coroTask2.resume(); // RESUME 2nd coroutine once
    // loop to resume the 1st coroutine until it is done:
    while (coroTask1.resume())  // RESUME 1st coroutine
        std::cout << "coro() suspended\n";
    std::cout << "coro() done\n";
    coroTask2.resume(); // RESUME 2nd coroutine again
}

coro(3) and coro(5) started
CORO 5 start
CORO 1/5

CORO 3 start
CORO 1/3
coro() suspended

CORO 2/3
coro() suspended

CORO 3/3
coro() suspended

CORO 3 end
coro() done
CORO 2/5
```
对于初始化的协程，可得到两个不同的接口对象，`coroTask1` 和 `coroTask2`。通过有时恢复第一 个协程，有时恢复第二个协程，控制流在主函数和这两个协程之间跳转，甚至可以将协程接口对象传递给不同的函数或线程那里恢复，也能以当前的状态继续执行。
### Lifetime Issues with Call-by-Reference
协程的生命周期通常比最初调用它的语句要长，这意味着若通过引用传递临时对象，可能会遇到致命的运行时问题，因为传递一个临时对象会创建未定义行为，这取决于平台、编译器设置。例如，考虑使用如下方式调用协程：
```cpp coro/cororef.hpp
CoroTask coro(const int& max) {...}

int main()
{
    auto coroTask = coro(3); // OOPS: creates reference to temporary/literal
    std::cout << "coro(3) started\n";
    coro(375); // another temporary coroutine
    std::cout << "coro(375) started\n";
    // loop to resume the coroutine until it is done:
    while (coroTask.resume())  // ERROR: undefined behavior
    std::cout << "coro() suspended\n";
    std::cout << "coro() done\n";
}
```
在有些平台上，初始化协程的语句之后，所引用的传入参数 3 的位置不再可用，当第一次恢复协程时，`val` 的输出和初始化使用的是已销毁对象的引用。 
因此通常不要使用引用来声明协程参数。若复制参数的代价太大，可以通过使用 `std::ref()` 或 `std::cref()` 创建的引用包装器按引用传递。对于容器，还可以使用 `std::views::all()`，将容器作为视图传递：
```cpp
CoroTask printElems(auto coll)
{
    for (const auto& elem : coll) {
        std::cout << elem << '\n';
        co_await std::suspend_always{}; // SUSPEND
    }
}
std::vector<std::string> coll;
...
// start coroutine that prints the elements:
// - use view created with std::views::all() to avoid copying the container
auto coPrintElems = printElems(std::views::all(coll));
while (coPrintElems.resume()) {...} // RESUME
```
## Coroutines Calling Coroutines
协程可以调用其他协程(甚至是间接的)，调用和被调用的协程都可能有挂起点。考虑一个具有一个挂起点的协程：
```cpp
CoroTask coro()
{
    std::cout << " coro(): PART1\n";
    co_await std::suspend_always{}; // SUSPEND
    std::cout << " coro(): PART2\n";
}
```
现在，通过另一个协程 `callCoro()` 间接调用：
```cpp
auto coroTask = callCoro(); // initialize coroutine
std::cout << "MAIN: callCoro() initialized\n";
while (coroTask.resume())  // RESUME
    std::cout << "MAIN: callCoro() suspended\n";
std::cout << "MAIN: callCoro() done\n";
```
问题是如何实现 `callCoro()`。
### No Inner resume()
可以尝试通过 `coro()` 来实现 `callCoro()`：
```cpp
CoroTask callCoro()
{
    std::cout << " callCoro(): CALL coro()\n";
    coro(); // CALL sub-coroutine
    std::cout << " callCoro(): coro() done\n";
    co_await std::suspend_always{}; // SUSPEND
    std::cout << " callCoro(): END\n";
}
```
但 `coro()` 函数体中的 `print` 语句永远不会调用。因为此处的 `coro()` 调用只初始化协程并立即挂起它，返回的协程接口甚至没有使用，`coro()` 永远不会恢复。外部协程的 `resume()` 不会自动恢复任何内部协程。为了在使用协程时至少获得编译器警告，类 `CoroTask` 应该使用 `[[nodiscard]]` 声明。
### Using an Inner resume()
因此必须像处理外部协程一样处理内部协程：
```cpp
CoroTask callCoro()
{
    std::cout << " callCoro(): CALL coro()\n";
    auto sub = coro(); // init sub-coroutine
    while (sub.resume())  // Inner resume() RESUME sub-coroutine 
        std::cout << " callCoro(): coro() suspended\n";
    std::cout << " callCoro(): coro() done\n";
    co_await std::suspend_always{}; // SUSPEND
    std::cout << " callCoro(): END\n";
}

MAIN: callCoro() initialized
callCoro(): CALL coro()
coro(): PART1
callCoro(): coro() suspended

coro(): PART2
callCoro(): coro() done
MAIN: callCoro() suspended

callCoro(): END
MAIN: callCoro() done
```
### Using One Inner resume()
值得注意的是，若在 `callCoro()` 中只恢复一次 `coro()`：
```cpp
CoroTask callCoro()
{
    std::cout << " callCoro(): CALL coro()\n";
    auto sub = coro(); // init sub-coroutine
    sub.resume(); // RESUME sub-coroutine
    std::cout << " callCoro(): call.resume() done\n";
    co_await std::suspend_always{}; // SUSPEND
    std::cout << " callCoro(): END\n";
}

MAIN: callCoro() initialized
callCoro(): CALL coro()
coro(): PART1
callCoro(): call.resume() done
MAIN: callCoro() suspended

callCoro(): END
MAIN: callCoro() done
```
`callCoro()` 初始化 `coro()` 之后，`coro()` 只恢复一次，所以只调用它的第一部分。之后，`coro()` 的挂起将控制流传输回 `callCoro()`，然后 `callCoro()` 挂起自己，则控制流返回到 `main()`。当 `main()` 恢复 `callCoro()` 时，程序完成 `callCoro()`，而 `coro()` 永远不会完成。
### Delegating resume()
可以实现 `CoroTask` 以便 `co_await` 以一种方式注册子协程，从而处理子协程中的挂起，就像处理调用协程中的挂起一样：
```cpp
CoroTaskSub callCoro()
{
    std::cout << " callCoro(): CALL coro()\n";
    co_await coro(); // call sub-coroutine
    std::cout << " callCoro(): coro() done\n";
    co_await std::suspend_always{}; // SUSPEND
    std::cout << " callCoro(): END\n";
}
```
然而，`resume()` 随后必须将恢复请求委托给子协程(若有的话)，所以 `CoroTask` 接口必须成为一个 `awaitable`。
## Implementing the Coroutine Interface
协程接口汇集一些要求，让编译器处理协程，并为调用者提供 `API` 来创建、恢复和销毁协程。要处理 `C++` 中的协程，需要：
- `promise` 类型：用于定义处理协程的某些自定义点，其中的特定成员函数是在特定情况下会调用的回调函数。
- 存储协程状态的协程句柄，类型是 `std::coroutine_handle`：可以通过提供一个底层接口来恢复协程以及处理协程的结束，并检查是否处于结束状态或销毁其内存，从而管理协程的状态。 
上述二者在调用协程时自动创建，处理协程返回类型的类型通常将下述需求结合在一起：
- 必须定义 `promise` 类型，通常定义为类型成员 `promise_type`。
- 必须定义协程句柄，通常定义为数据成员。
- 必须为调用者提供处理协程的接口，例如成员函数 `resume()`。
`CoroTask` 类提供 `promise_type`，存储协程句柄，并定义协程调用者的 `API`，定义如下所示：
```cpp coro/corotask.hpp
#include <coroutine>
#include "corotaskpromise.hpp" // definition of promise_type
// coroutine interface to deal with a simple task
// - providing resume() to resume the coroutine
class [[nodiscard]] CoroTask {
public:
    // initialize members for state and customization:
    struct promise_type; // definition later in corotaskpromise.hpp
    using CoroHdl = std::coroutine_handle<promise_type>;
private:
    CoroHdl hdl; // native coroutine handle
public:
    // constructor and destructor:
    CoroTask(auto h): hdl{h} {} // store coroutine handle in interface
    ~CoroTask() {
        if (hdl) hdl.destroy(); // destroy coroutine handle
    }
    
    // don’t copy or move:
    CoroTask(const CoroTask&) = delete;
    CoroTask& operator=(const CoroTask&) = delete;
    
    // API to resume the coroutine
    // - returns whether there is still something to process
    bool resume() const {
        if (!hdl || hdl.done()) return false; // nothing (more) to process
        hdl.resume(); // RESUME (blocks until suspended again or the end)
        return !hdl.done();
    }
};
```
编译器在协程接口类型中查找的关键成员是类型成员 `promise_type`，通过 `promise` 类型定义原生协程句柄的类型，并引入私有成员 `hdl` 用于存储 `promise` 类型的协程句柄管理协程的状态，存储在 `promise` 中的任何数据都是句柄的一部分，`promise` 中的函数都可以通过句柄访问。 
```cpp
class [[nodiscard]] CoroTask {
public:
    // initialize members for state and customization:
    struct promise_type; // definition later in corotaskpromise.hpp
    using CoroHdl = std::coroutine_handle<promise_type>;
private:
    CoroHdl hdl; // native coroutine handle
    ...
};
```
协程接口类型的构造函数和析构函数初始化协程句柄的成员，并在协程接口销毁之前将其清除。
通过用 `[[nodiscard]]` 声明类，在创建协程但未使用时强制编译器发出警告(当意外地将协程用 作普通函数时尤其可能发生这种情况)。简单起见，禁用复制和移动，提供复制或移动语义是可能的，但必须小心正确地处理。 
最后，为调用者定义唯一的接口：
```cpp
bool resume() const {
    if (!hdl || hdl.done()) return false; // nothing (more) to process
    hdl.resume(); // RESUME (blocks until suspended again or the end)
    return !hdl.done();
}
```
首先，函数检查是否有句柄，尽管在这个实现中协程接口总是有一个句柄，但这是一个必要的检查，因为可能支持移动语义，还要检查协程是否已经结束，只有当协程挂起且尚未结束时才允许调用 `resume()`，之后恢复挂起的协程并阻塞，直到下一个挂起点或结束。成员函数 `done()` 由原生协程句柄提供，表明协程是否结束执行结束。
### Implementing promise_type
`promise` 类型：
- 定义如何创建或获取协程的返回值(通常包括创建协程句柄)
- 决定协程是应该在开始还是结束时挂起 
- 处理协程调用者与协程之间交换的值 
- 处理未处理的异常
```cpp coro/corotaskpromise.hpp
struct CoroTask::promise_type {
    auto get_return_object() { // init and return the coroutine interface
        return CoroTask{CoroHdl::from_promise(*this)};
    }

    auto initial_suspend() { // initial suspend point
        return std::suspend_always{}; // - suspend immediately
    }
    
    void unhandled_exception() { // deal with exceptions
        std::terminate(); // - terminate the program
    }
    
    void return_void() {} // deal with the end or co_return;
    
    auto final_suspend() noexcept { // final suspend point
        return std::suspend_always{}; // - suspend immediately
    }
};
```
`get_return_object()` 用于初始化协程接口，首先为调用此函数的 `promise` 创建原生协程句柄，`from_promise()` 是类模板 `std::coroutine_handle<>` 为此目的提供的静态成员函数：
```cpp
coroHdl = CoroHdl::from_promise(*this) 
```
然后，创建协程接口对象，用刚刚创建的句柄初始化它，并返回接口对象：
```cpp
coroIf = CoroTask{coroHdl}
return coroIf
```
此处在一个语句中完成所有这些：
```cpp
auto get_return_object() {
    return CoroTask{CoroHdl::from_promise(*this)};
}
```
`initial_suspend()` 允许额外的初始准备，并定义协程是主动启动还是惰性启动：
- 返回 `std::suspend_never{}` 表示立即启动，协程在用第一个语句初始化之后立即启动。
- 返回 `std::suspend_always{}` 表示惰性启动，协程立即挂起，不执行任何语句直到恢复，
`return_void()` 定义执行结束或或 `co_return` 声明时的反应。若声明这个成员函数，协程应该永远不会返回值。若协程需要返回数据，则必须使用另一个成员函数。
`unhandled_exception()` 定义如何处理协程中未本地处理的异常，此处指定这会导致程序的异常终止。
`final_suspend()` 定义是否应该最终挂起协程。这个成员函数必须保证不抛出异常，应该返回 `std::suspend_always{}`。
### Bootstrapping Interface, Handle, and Promise
有多种方法可以声明 `promise` 类型和协程句柄，实践中，通常可以这样做：
```cpp
// 声明 promise 类型，声明协程句柄的类型，并定义 promise 类型
class CoroTask {
public:
    struct promise_type; // promise type
    using CoroHdl = std::coroutine_handle<promise_type>;
private:
    CoroHdl hdl; // native coroutine handle
public:
    struct promise_type {
        auto get_return_object() {
            return CoroTask{CoroHdl::from_promise(*this)};
        }
        ...
    };
    ...
};

// 定义 promise 类型并声明协程句柄:
class CoroTask {
public:
    struct promise_type { // promise type
        auto get_return_object() {
            return std::coroutine_handle<promise_type>::from_promise(*this);
        }
        ...
    };
private:
    std::coroutine_handle<promise_type> hdl; // native coroutine handle
public:
    ...
};

// 外部定义 promise 类型为泛型辅助类型:
template<typename CoroIf>
struct CoroPromise {
    auto get_return_object() {
        return std::coroutine_handle<CoroPromise<CoroIf>>::from_promise(*this);
    }
    ...
};

class CoroTask {
public:
    using promise_type = CoroPromise<CoroTask>;
private:
    std::coroutine_handle<promise_type> hdl; // native coroutine handle
public:
...
};

// 因为 promise 类型通常是特定于接口的(有不同或额外的成员)，通常使用以下简化的形式:
class CoroTask {
public:
    struct promise_type;
    using CoroHdl = std::coroutine_handle<promise_type>;
private:
    CoroHdl hdl; // native coroutine handle
public:
    struct promise_type {
        auto get_return_object() { return CoroHdl::from_promise(*this); }
        auto initial_suspend() { return std::suspend_always{}; }
        void return_void() { }
        void unhandled_exception() { std::terminate(); }
        auto final_suspend() noexcept { return std::suspend_always{}; }
        ...
    };
    ...
};
```
### Memory Management
协程具有在不同上下文中使用的状态，因此协程句柄通常将协程的状态存储在堆内存中。堆内存分配可以优化，也可以进行更改。
为了使协程处理的成本更低，没有智能处理此内存的方法。协程句柄只是在初始化时指向内存，直到 `destroy()` 被调用，所以当协程接口销毁时，应该显式调用 `destroy()`。
协程句柄的低成本/原生的实现也使得有必要处理复制和移动。默认情况下，复制协程接口将复制协程句柄，这将产生两个协程句柄共享同一个协程的效果。当一个协程句柄将协程带入另一个句柄不知道的状态时，会带来风险，为减少这种危险，应该小心地为协程提供复制或移动语义。最简单的方法是禁用复制和移动。
支持移动语义可能有意义，但应该确保已移动的对象不再引用协程，并且获得新值的协程会破坏旧值：
```cpp
class CoroTask {
    CoroTask(CoroTask&& c) noexcept : hdl{std::move(c.hdl)} { c.hdl = nullptr; }
    CoroTask& operator=(CoroTask&& c) noexcept {
        // 赋值运算符需要销毁原对象因此需要证同测试
        if (this != &c) { // if no self-assignment
            if (hdl) hdl.destroy(); // - destroy old handle (if there is one)
            hdl = std::move(c.hdl); // - move handle
            c.hdl = nullptr; // - moved-from object has no handle anymore
        }
        return *this;
    }
    ...
};
```
## Coroutines That Yield or Return Values
- `co_yield` 允许协程在每次挂起时产生一个值。
- `co_return` 允许协程在其结束时返回一个值。
### Using co_yield
通过使用 `co_yield`，协程可以在挂起时产生中间结果，当协程到达 `co_yield` 时，将回调 `yield_value()` 来处理此中间结果，然后挂起协程。
下述例子中，将值存储在 `promise` 的成员中，这使得它可以在协程接口中使用，将值存储在 `promise` 中后，返回 `std::suspend_always{}` 来挂起协程，可以在这里编写不同的行为，以便协程有条件地继续：
```cpp
struct promise_type {
    int coroValue = 0; // last value from co_yield
    auto yield_value(int val) { // reaction to co_yield
        coroValue = val; // - store value locally
        return std::suspend_always{}; // - suspend coroutine
    }
    ...
};
```
一个明显的例子是生成值的协程，它循环一些值直到最大值，并将其输出给协程的调用者，每当为返回的协程接口调用 `resume()` 时，协程就会计算并产生最新值，这个值可以通过 `getValue()` 访问。
```cpp
#include <iostream>
#include "corogen.hpp" // for CoroGen
CoroGen coro(int max)
{
    std::cout << " CORO " << max << " start\n";
    for (int val = 1; val <= max; ++val) {
        std::cout << " CORO " << val << '/' << max << '\n';
        co_yield val; // SUSPEND with value
    }
    std::cout << " CORO " << max << " end\n";
}

// start coroutine:
auto coroGen = coro(3); // initialize coroutine
std::cout << "coro() started\n";
// loop to resume the coroutine until it is done:
while (coroGen.resume()) { // RESUME
    auto val = coroGen.getValue();
    std::cout << "coro() suspended with " << val << '\n';
}
std::cout << "coro() done\n";
```
协程接口必须处理产生的值，并提供 `getValue()` 访问存储在 `promise` 中的最新生成值，所以使用不同的类型名称 `CoroGen`，`CoroGen` 类型可以定义如下：
```cpp coro/corogen.hpp 
#include <coroutine>
#include <exception> // for terminate()
class [[nodiscard]] CoroGen {
public:
    // initialize members for state and customization:
    struct promise_type;
    using CoroHdl = std::coroutine_handle<promise_type>;
private:
    CoroHdl hdl; // native coroutine handle
public:
    struct promise_type {
        int coroValue = 0; // recent value from co_yield
        auto yield_value(int val) { // reaction to co_yield
            coroValue = val; // - store value locally
            return std::suspend_always{}; // - suspend coroutine
        }
        // the usual members:
        auto get_return_object() { return CoroHdl::from_promise(*this); }
        auto initial_suspend() { return std::suspend_always{}; }
        void return_void() { }
        void unhandled_exception() { std::terminate(); }
        auto final_suspend() noexcept { return std::suspend_always{}; }
    };
    // constructors and destructor:
    CoroGen(auto h) : hdl{h} { }
    ~CoroGen() { if (hdl) hdl.destroy(); }
    // no copying or moving:
    CoroGen(const CoroGen&) = delete;
    CoroGen& operator=(const CoroGen&) = delete;
    // API:
    // - resume the coroutine:
    bool resume() const {
        if (!hdl || hdl.done()) return false; // nothing (more) to process
        hdl.resume(); // RESUME
        return !hdl.done();
    }
    // - yield value from co_yield:
    int getValue() const { 
        return hdl.promise().coroValue;
    }
};
```
迭代协程产生的值见电子书 510。
### Using co_return
通过使用 `co_return`，协程可以在其结束时向调用者返回结果。
```cpp
#include <iostream>
#include <vector>
#include <ranges>
#include <coroutine> // for std::suspend_always{}
#include "resulttask.hpp" // for ResultTask
ResultTask<double> average(auto coll)
{
    double sum = 0;
    for (const auto& elem : coll) {
        std::cout << " process " << elem << '\n';
        sum = sum + elem;
        co_await std::suspend_always{}; // SUSPEND
    }
    co_return sum / std::ranges::ssize(coll); // return resulting average
}

std::vector values{0, 8, 15, 47, 11, 42};
// start coroutine:
auto task = average(std::views::all(values));
// loop to resume the coroutine until all values have been processed:
std::cout << "resume()\n";
while (task.resume())  // RESUME
    std::cout << "resume() again\n";
// print return value of coroutine:
std::cout << "result: " << task.getResult() << '\n';
```
协程 `average()` 遍历传递的集合中的元素，并将它们的值添加到初始和中，然后协程挂起。最后，协程通过将总和除以元素数量返回平均值。
协程接口必须处理产生的值，并为调用者提供稍微不同的 `API`，所以使用不同的类型名称 `CoroGen`，`CoroGen` 类型可以定义如下：
协程接口根据返回值的类型参数化，并提供 `getResult()` 来请求协程完成后的返回值，所以使用不同的类型名称 `ResultTask`：
```cpp coro/resulttask.hpp 
#include <coroutine>
#include <exception> // for terminate()
template<typename T>
class [[nodiscard]] ResultTask {
public:
    // customization points:
    struct promise_type {
        T result{}; // value from co_return
        void return_value(const auto& value) { // reaction to co_return
            result = value; // - store value locally
        }
        auto get_return_object() {
            return std::coroutine_handle<promise_type>::from_promise(*this);
        }
        auto initial_suspend() { return std::suspend_always{}; }
        void unhandled_exception() { std::terminate(); }
        auto final_suspend() noexcept { return std::suspend_always{}; }
    };
private:
    std::coroutine_handle<promise_type> hdl; // native coroutine handle
public:
    // constructors and destructor:
    // - no copying or moving is supported
    ResultTask(auto h) : hdl{h} { }
    ~ResultTask() { if (hdl) hdl.destroy(); }
    ResultTask(const ResultTask&) = delete;
    ResultTask& operator=(const ResultTask&) = delete;
    // API:
    // - resume() to resume the coroutine
    bool resume() const {
        if (!hdl || hdl.done()) return false; // nothing (more) to process
        hdl.resume(); // RESUME
        return !hdl.done();
    }
    // - getResult() to get the last value from co_yield
    T getResult() const {
        return hdl.promise().result;
    }
};
```
由于这次支持返回值，所以在 `promise` 类型中，不再提供 `return_void()`，而是提供 `return_value()`，当协程到达 `co_return` 表达式时调用。
若协程以有时可能返回值，有时可能不返回值的方式实现，这是未定义行为，则这个协程无效。
## Coroutine Awaitables and Awaiters
协程必须提供 `Awaitables`：
- `Awaitables` 是运算符 `co_await` 的操作数的术语，所以 `Awaitables` 是 `co_await` 可以处理的所有对象。
- `Awaiter` 是实现 `Awaitables` 的一种特定方式的术语，其必须提供三个特定的成员函数来处理协程的挂起和恢复。
`Awaitables` 在调用 `co_await/co_yield` 时使用，提供拒绝请求的代码来挂起或执行一些用于挂起和恢复的逻辑，例如 `std::suspend_always` 和 `std::suspend_never`。
### Awaiters
当协程挂起或恢复时可以调用 `Awaiters`，`Awaiter` 必须提供以下操作：
- `await_ready()` 返回挂起是否被禁用
- `await_suspend(awaitHdl)` 处理挂起 
- `await_resume()` 处理恢复
`await_ready()` 会在协程被挂起之前调用，以提供禁用挂起，若返回 `true`，则协程根本不会挂起。这个函数通常只返回 `false`，只有当挂起无意义时，为节省挂起的成本，可能会有条件地产生 `true`。在该函数内部，协程并未挂起，因此不应该其用来直接或间接地调用 `resume()` 或 `destroy()`。
在协程挂起后将立即为协程调用 `await_suspend(awaitHdl)`，参数 `awaitHdl` 是被挂起的协程的句柄，其类型是 `std::coroutine_handle<PromiseType>`。这个函数中，可以指定下一步要做什么，不同的返回类型允许以不同的方式指定，包括立即恢复挂起的协程，还可以通过直接将控制转移到另一个协程来有效地跳过挂起，甚至可以 `destroy()`，但需要确保不再在其他任何地方使用这个协程。
当成功挂起后恢复协程时，将为协程调用 `await_resume`，此时可以返回一个值给恢复的协程。
### Standard Awaiters
`C++` 标准库提供两个简单的 `awaiter`，它们的 `await_ready()` 返回值有所不同：
- 由于在 `await_ready()` 中返回 `false` 而在 `await_suspend()` 中没有返回任何值，则 `suspend_always` 接受每个挂起，这意味着控制流返回到协程调用者。
- 由于在 `await_ready()` 中返回 `true`，则 `suspend_never` 永远不会接受任何挂起，这意味着协程会继续执行，永远不会调用 `await_suspend()`。 
```cpp
namespace std {
    struct suspend_always {
        constexpr bool await_ready() const noexcept { return false; }
        constexpr void await_suspend(coroutine_handle<>) const noexcept { }
        constexpr void await_resume() const noexcept { }
    };
    struct suspend_never {
        constexpr bool await_ready() const noexcept { return true; }
        constexpr void await_suspend(coroutine_handle<>) const noexcept { }
        constexpr void await_resume() const noexcept { }
    };
}
```
#### Resuming Sub-Coroutines
通过提供 `awaiter API`，允许协程以一种方式处理子协程，使子协程的挂起点成为主协程的挂起点，这允许开发者避免使用嵌套循环进行恢复。以 `CoroTask` 的第一个实现为例，只需要以下修改：
```cpp
class CoroTaskSub {
public:
    struct promise_type;
    using CoroHdl = std::coroutine_handle<promise_type>;
private:
    CoroHdl hdl; // native coroutine handle
public:
    struct promise_type {
        // 协程接口必须知道它的子协程 (若有的话):
        CoroHdl subHdl = nullptr; // sub-coroutine (if there is one)
        ...
    }
    // 协程接口必须提供 awaiter 的 API，以便该接口可以作为 co_await 的 awaitable 使用:
    bool await_ready() { return false; } // do not skip suspension
    void await_suspend(auto awaitHdl) {
        awaitHdl.promise().subHdl = hdl; // store sub-coroutine and suspend
    }
    void await_resume() { }
    // 协程接口必须恢复尚未完成的最深层子协程 (若有的话):
    bool resume() const {
        if (!hdl || hdl.done()) return false; // nothing (more) to process
        // find deepest sub-coroutine not done yet:
        CoroHdl innerHdl = hdl;
        while (innerHdl.promise().subHdl && !innerHdl.promise().subHdl.done())
            innerHdl = innerHdl.promise().subHdl;
        innerHdl.resume(); // RESUME
        return !hdl.done();
    }
    ...
};
```
通过这个就可以注册子协程，从而将恢复请求委托给子协程：
```cpp
#include <iostream>
#include "corotasksub.hpp" // for CoroTaskSub

CoroTaskSub coro()
{
    std::cout << " coro(): PART1\n";
    co_await std::suspend_always{}; // SUSPEND
    std::cout << " coro(): PART2\n";
}

CoroTaskSub callCoro()
{
    std::cout << " callCoro(): CALL coro()\n";
    // callCoro() 内部，可以通过将 coro() 传递给 co_await() 来调用 coro():
    co_await coro(); // call sub-coroutine
    std::cout << " callCoro(): coro() done\n";
    co_await std::suspend_always{}; // SUSPEND
    std::cout << " callCoro(): END\n";
}

auto coroTask = callCoro(); // initialize coroutine
std::cout << "MAIN: callCoro() initialized\n";
while (coroTask.resume())  // RESUME
    std::cout << "MAIN: callCoro() suspended\n";
std::cout << "MAIN: callCoro() done\n";
```
`coro()` 的调用会初始化协程，并产生 `CoroTaskSub` 类型的协程接口，因为这个类型有 `awaiter` 接口，协程接口可以作为 `co_await` 的 `awaitable` 接口使用，因此 `co_await` 用被调用的 `awaiter` 子协程 `coro` 和调用它的 `awaiter` 协程 `callCoro` 作为操作数。
子协程 `coro` 的句柄将调用 `await_ready()` 询问是否禁用挂起，此处为不禁用，然后以 `awaiter` 子协程的句柄作为参数调用 `await_suspend()`，`await_suspend()` 内部通过存储子协程的句柄使得 `callCoro()` 知道其子协程。
由于在 `await_suspend()` 中不返回任何值，因此挂起最终被接受，此处的 `co_await coro();` 将挂起 `callCoro()` 并将控制流传输回 `main()`。当 `main()` 恢复 `callCoro()` 时，`CoroTaskSub::resume()` 的实现发现 `coro()` 作为其最深层的子协程并恢复它，每当子协程挂起时，`CoroTaskSub::resume()` 将返回给调用者。这个过程一直持续到子协程执行完毕，接下来将恢复 `callCoro()`。最后，程序有以下输出：
```cpp
MAIN: callCoro() initialized
callCoro(): CALL coro()
MAIN: callCoro() suspended
coro(): PART1
MAIN: callCoro() suspended
coro(): PART2
MAIN: callCoro() suspended
callCoro(): coro() done
MAIN: callCoro() suspended
callCoro(): END
MAIN: callCoro() done
```
前述的 `co_await coro();` 将挂起 `callCoro()` 并将控制流传输回 `main()`，也可以在这里直接执行 `coro()`，只需要对 `await_suspend()` 进行如下修改：
```cpp
auto await_suspend(auto awaitHdl) {
    awaitHdl.promise().subHdl = hdl; // store sub-coroutine
    return hdl; // and resume it directly
}
```
若 `await_suspend()` 返回协程句柄，则立即恢复该协程。这会将程序的行为改变为以下输出：
```cpp
MAIN: callCoro() initialized
callCoro(): CALL coro()
coro(): PART1
MAIN: callCoro() suspended
callCoro(): coro() done
MAIN: callCoro() suspended
callCoro(): END
MAIN: callCoro() done
```
#### Passing Values From Suspension Back to the Coroutine
`awaitables` 和 `awaiter` 的另一个应用是允许在挂起后将值传递回协程，为支持这一点，协程接口提供一些修改后的常用 `API`:
```cpp
#include "backawaiter.hpp"
#include <coroutine>
#include <exception> // for terminate()
#include <string>
class [[nodiscard]] CoroGenBack {
public:
    struct promise_type;
    using CoroHdl = std::coroutine_handle<promise_type>;
private:
    CoroHdl hdl; // native coroutine handle
public:
    struct promise_type { // promise 类型是协程与调用者共享和交换数据的最佳位置:
        // coroValue 是从协程传递给调用者的值  backValue 是从调用者传回给协程的值
        int coroValue = 0; // value TO caller on suspension
        std::string backValue; // value back FROM caller after suspension
        
        // 要通过 promise 将值传递给调用者，还需要实现 yield_value()
        // yield_value() 会返回一个特殊的类型为 BackAwaiter 的 awaiter 对象
        // 从而能够返回调用者返回的值:
        auto yield_value(int val) { // reaction to co_yield
            coroValue = val; // - store value locally
            backValue.clear(); // - reinit back value
            return BackAwaiter<CoroHdl>{}; // - use special awaiter for response
        }
        
        // the usual members:
        auto get_return_object() { return CoroHdl::from_promise(*this); }
        auto initial_suspend() { return std::suspend_always{}; }
        void return_void() { }
        void unhandled_exception() { std::terminate(); }
        auto final_suspend() noexcept { return std::suspend_always{}; }
    };
    // constructors and destructor:
    CoroGenBack(auto h) : hdl{h} { }
    ~CoroGenBack() { if (hdl) hdl.destroy(); }
    // no copying or moving:
    CoroGenBack(const CoroGenBack&) = delete;
    CoroGenBack& operator=(const CoroGenBack&) = delete;
    // API:
    // - resume the coroutine:
    bool resume() const {
        if (!hdl || hdl.done()) return false; // nothing (more) to process
        hdl.resume(); // RESUME
        return !hdl.done();
    }
    // - yield value from co_yield:
    int getValue() const {
        return hdl.promise().coroValue;
    }
    // - set value back to the coroutine after suspension:
    void setBackValue(const auto& val) {
        hdl.promise().backValue = val;
    }
};
```
`awaiter` 的定义如下所示：
```cpp
template<typename Hdl>
class BackAwaiter {
    Hdl hdl = nullptr; // coroutine handle saved from await_suspend() for await_resume()
public:
    BackAwaiter() = default;
    bool await_ready() const noexcept {
        return false; // do suspend
    }
    void await_suspend(Hdl h) noexcept {
        hdl = h; // save handle to get access to its promise
    }
    auto await_resume() const noexcept {
        return hdl.promise().backValue; // return back value stored in the promise
    }
};
```
`awaiter` 所做的只是将传递给 `await_suspend()` 的协程句柄存储在本地，以便在调用 `await_resume()` 时拥有它，从而在 `await_resume()` 中，使用此句柄从其 `promise` 中得到 `backValue`，而 `backValue` 由调用者使用 `setBackValue()` 存储：
```cpp
#include <iostream>
#include "corogenback.hpp" // for CoroGenBack
CoroGenBack coro(int max)
{
    std::cout << " CORO " << max << " start\n";
    for (int val = 1; val <= max; ++val) {
        std::cout << " CORO " << val << '/' << max << '\n';
        // co_yield 将返回 yield_value 的返回值
        // 这个返回值将挂起协程直到 resume 被调用
        // resume 被调用时将调用 await_resume() 
        // await_resume() 返回的值 backValue 将给恢复后的协程
        auto back = co_yield val; // SUSPEND with value with response
        std::cout << " CORO => " << back << "\n";
    }
    std::cout << " CORO " << max << " end\n";
}

// start coroutine:
auto coroGen = coro(3); // initialize coroutine
std::cout << "**** coro() started\n";
// loop to resume the coroutine until it is done:
std::cout << "\n**** resume coro()\n";
while (coroGen.resume()) { // RESUME
    // process value from co_yield:
    auto val = coroGen.getValue();
    std::cout << "**** coro() suspended with " << val << '\n';
    // set response (the value co_yield yields):
    std::string back = (val % 2 != 0 ? "OK" : "ERR");
    std::cout << "\n**** resume coro() with back value: " << back << '\n';
    coroGen.setBackValue(back); // set value back to the coroutine
}
std::cout << "**** coro() done\n";
```
# Detail
## Coroutine Constraints
### Coroutine Lambdas
```cpp
auto coro = [] (int max) -> CoroTask {
std::cout << " CORO " << max << " start\n";
for (int val = 1; val <= max; ++val) {
// print next value:
std::cout << " CORO " << val << '/' << max << '\n';
co_await std::suspend_always{}; // SUSPEND
}
std::cout << " CORO " << max << " end\n"; 
};
```

```cpp
auto getCoro()
{
string str = " CORO ";
auto coro = [str] (int max) -> CoroTask {
std::cout << str << max << " start\n";
for (int val = 1; val <= max; ++val) {
std::cout << str << val << '/' << max << '\n';
co_await std::suspend_always{}; // SUSPEND
}
std::cout << str << max << " end\n";
};
return coro;
}
auto coroTask = getCoro()(3); // initialize coroutine
// OOPS: lambda destroyed here
coroTask.resume(); // FATAL RUNTIME ERROR
```

```cpp
auto coro = getCoro(); // initialize coroutine lambda
auto coroTask = coro(3); // initialize coroutine
coroTask.resume(); // OK
```
## The Coroutine Frame and the Promises
### How Coroutine Interfaces, Promises, and Awaitables Interact
```cpp
#include <iostream>
#include <coroutine>
#include <exception> // for terminate()
// coroutine interface to deal with a simple task
// - providing resume() to resume it
class [[nodiscard]] TracingCoro {
public:
// native coroutine handle and its promise type:
struct promise_type;
using CoroHdl = std::coroutine_handle<promise_type>;
CoroHdl hdl; // coroutine handle
// helper type for state and customization:
struct promise_type {
promise_type() {
std::cout << " PROMISE: constructor\n";
}
~promise_type() {
std::cout << " PROMISE: destructor\n";
}
auto get_return_object() { // init and return the coroutine interface
std::cout << " PROMISE: get_return_object()\n";
return TracingCoro{CoroHdl::from_promise(*this)};
}
auto initial_suspend() { // initial suspend point
std::cout << " PROMISE: initial_suspend()\n";
return std::suspend_always{}; // - start lazily
}
void unhandled_exception() { // deal with exceptions
std::cout << " PROMISE: unhandled_exception()\n";
std::terminate(); // - terminate the program
}
15.2 The Coroutine Frame and the Promises 509
void return_void() { // deal with the end or co_return;
std::cout << " PROMISE: return_void()\n";
}
auto final_suspend() noexcept { // final suspend point
std::cout << " PROMISE: final_suspend()\n";
return std::suspend_always{}; // - suspend immediately
}
};
// constructor and destructor:
TracingCoro(auto h)
: hdl{h} { // store coroutine handle in interface
std::cout << " INTERFACE: construct\n";
}
~TracingCoro() {
std::cout << " INTERFACE: destruct\n";
if (hdl) {
hdl.destroy(); // destroy coroutine handle
}
}
// don’t copy or move:
TracingCoro(const TracingCoro&) = delete;
TracingCoro& operator=(const TracingCoro&) = delete;
// API to resume the coroutine
// - returns whether there is still something to process
bool resume() const {
std::cout << " INTERFACE: resume()\n";
if (!hdl || hdl.done()) {
return false; // nothing (more) to process
}
hdl.resume(); // RESUME
return !hdl.done();
}
};

```

```cpp
#include <iostream>
class TracingAwaiter {
inline static int maxId = 0;
int id;
public:
TracingAwaiter() : id{++maxId} {
std::cout << " AWAITER" << id << ": ==> constructor\n";
}
~TracingAwaiter() {
std::cout << " AWAITER" << id << ": <== destructor\n";
}
// don’t copy or move:
TracingAwaiter(const TracingAwaiter&) = delete;
TracingAwaiter& operator=(const TracingAwaiter&) = delete;
// constexpr
bool await_ready() const noexcept {
std::cout << " AWAITER" << id << ": await_ready()\n";
return false; // true: do NOT (try to) suspend
}
// Return type/value means:
// - void: do suspend
// - bool: true: do suspend
// - handle: resume coro of the handle
// constexpr
bool await_suspend(auto) const noexcept {
std::cout << " AWAITER" << id << ": await_suspend()\n";
return false;
}
// constexpr
void await_resume() const noexcept {
std::cout << " AWAITER" << id << ": await_resume()\n";
}
};

```

```cpp
#include "tracingcoro.hpp"
#include "tracingawaiter.hpp"
#include <iostream>
TracingCoro coro(int max)
{
std::cout << " START coro(" << max << ")\n";
for (int i = 1; i <= max; ++i) {
std::cout << " CORO: " << i << '/' << max << '\n';
co_await TracingAwaiter{}; // SUSPEND
std::cout << " CONTINUE coro(" << max << ")\n";
}
std::cout << " END coro(" << max << ")\n";
}
int main()
{
// start coroutine:
std::cout << "**** start coro()\n";
auto coroTask = coro(3); // init coroutine
std::cout << "**** coro() started\n";
// loop to resume the coroutine until it is done:
std::cout << "\n**** resume coro() in loop\n";
while (coroTask.resume()) { // RESUME
std::cout << "**** coro() suspended\n";
...
std::cout << "\n**** resume coro() in loop\n";
}
std::cout << "\n**** coro() loop done\n";
}
```

```cpp
class [[nodiscard]] TracingCoro {
public:
...
struct promise_type {
...
auto initial_suspend() { // initial suspend point
std::cout << " PROMISE: initial_suspend()\n";
return std::suspend_never{}; // - start eagerly
}
...
};
...
};
```
## Coroutine Promises in Detail
### Mandatory Promise Operations
#### get_return_object()
```cpp
class CoroTask {
public:
// native coroutine handle and its promise type:
struct promise_type;
using CoroHdl = std::coroutine_handle<promise_type>;
CoroHdl hdl;
struct promise_type {
auto get_return_object() { // init and return the coroutine interface
return CoroTask{CoroHdl::from_promise(*this)};
}
...
}
...
};

```
#### initial_suspend()
```cpp
class CoroTask {
public:
...
struct promise_type {
...
auto initial_suspend() { // suspend immediately
return std::suspend_always{}; // - yes, always
}
...
}
...
};
```
#### final_suspend()
```cpp
class CoroTask {
public:
...
struct promise_type {
...
auto final_suspend() noexcept { // suspend at the end
...
return std::suspend_always{}; // - yes, always
}
...
}
...
};
```
#### unhandled_exception()
### Promise Operations to Return or Yield Values
#### return_void() or return_value()
```cpp
ResultTask<int> coroUB( ... )
{
if ( ... ) {
co_return 42;
}
}
```

```cpp
struct promise_type {
...
void return_value(int val) { // reaction to co_yield for int
... // - process returned int
}
void return_value(std::string val) { // reaction to co_yield for string
... // - process returned string
}
};
```

```cpp
CoroGen coro()
{
int value = 0;
...
if ( ... ) {
co_return "ERROR: can't compute value";
}
...
co_return value;
}
```
#### yield_value(Type)
```cpp
struct promise_type {
...
auto yield_value(int val) { // reaction to co_yield for int
... // - process yielded int
return std::suspend_always{}; // - suspend coroutine
}
auto yield_value(std::string val) { // reaction to co_yield for string
... // - process yielded string
return std::suspend_always{}; // - suspend coroutine
}
};
```

```cpp
CoroGen coro()
{
while ( ... ) {
if ( ... ) {
co_yield "ERROR: can't compute value";
}
int value = 0;
...
co_yield value;
}
}
```
### Optional Promise Operations
## Coroutine Handles in Detail
```cpp
class CoroIf {
public:
struct promise_type {
auto get_return_object() { // init and return the coroutine interface
return CoroIf{std::coroutine_handle<promise_type>::from_promise(*this)};
}
...
};
...
};

```

```cpp
std::coroutine_handle<PrmType> hdl = nullptr;
if (hdl) ... // false

```

```cpp
auto hdl = std::coroutine_handle<decltype(prm)>::from_promise(prm);
...
void* hdlPtr = hdl.address();
...
auto hdl2 = std::coroutine_handle<decltype(prm)>::from_address(hdlPtr);
hdl == hdl2 // true

```
### std::coroutine_handle
```cpp
namespace std {
template<typename Promise>
struct coroutine_handle {
...
// implicit conversion to coroutine_handle<void>:
constexpr operator coroutine_handle<>() const noexcept;
...
};
}
```

```cpp
void callResume(std::coroutine_handle<> h)
{
h.resume(); // OK
h.promise(); // ERROR: no member promise() provided for h
}
auto hdl = std::coroutine_handle<decltype(prm)>::from_promise(prm);
...
callResume(hdl); // OK: hdl converts to std::coroutine_handle<void>
```
## Exceptions in Coroutines

```cpp
void unhandled_exception() {
try {
throw; // rethrow caught exception
}
catch (const std::exception& e) {
std::cerr << "EXCEPTION: " << e.what() << std::endl;
}
catch (...) {
std::cerr << "UNKNOWN EXCEPTION" << std::endl;
}
}

```

```cpp
void unhandled_exception() {
...
std::terminate();
}
```

```cpp
struct promise_type {
std::exception_ptr ePtr;
...
void unhandled_exception() {
ePtr = std::current_exception();
}
};

```

```cpp
class [[nodiscard]] CoroTask {
...
bool resume() const {
if (!hdl || hdl.done()) {
return false;
}
hdl.promise().ePtr = nullptr; // no exception yet
hdl.resume(); // RESUME
if (hdl.promise().ePtr) { // RETHROW any exception from the coroutine
std::rethrow_exception(hdl.promise().ePtr);
}
return !hdl.done();
}
};
```
## Allocating Memory for the Coroutine Frame
### How Coroutines Allocate Memory
```cpp
CoroTask coro(int max)
{
for (int val = 1; val <= max; ++val) {
std::cout << "coro(" << max << "): " << val << '\n';
co_await std::suspend_always{};
}
}
CoroTask coroStr(int max, std::string s)
{
for (int val = 1; val <= max; ++val) {
std::cout << "coroStr(" << max << ", " << s << "): " << '\n';
co_await std::suspend_always{};
}
}

coro(3); // create and destroy temporary coroutine
coroStr(3, "hello"); // create and destroy temporary coroutine
```

```cpp
class CoroTask {
...
public:
struct promise_type {
...
// find out whether heap memory is allocated:
void* operator new(std::size_t sz); // declared, but not implemented
};
...
};
```

```cpp
#include <coroutine>
#include <exception> // for terminate()
#include <cstddef> // for std::byte
#include <array>
#include <memory_resource>
// coroutine interface to deal with a simple task
// - providing resume() to resume it
class [[nodiscard]] CoroTaskPmr {
// provide 200k bytes as memory for all coroutines:
inline static std::array<std::byte, 200’000> buf;
inline static std::pmr::monotonic_buffer_resource
monobuf{buf.data(), buf.size(), std::pmr::null_memory_resource()};
inline static std::pmr::synchronized_pool_resource mempool{&monobuf};
public:
struct promise_type;
using CoroHdl = std::coroutine_handle<promise_type>;
private:
CoroHdl hdl; // native coroutine handle
public:
struct promise_type {
auto get_return_object() { // init and return the coroutine interface
return CoroTaskPmr{CoroHdl::from_promise(*this)};
}
auto initial_suspend() { // initial suspend point
return std::suspend_always{}; // - suspend immediately
}
void unhandled_exception() { // deal with exceptions
std::terminate(); // - terminate the program
}
void return_void() { // deal with the end or co_return;
}
auto final_suspend() noexcept { // final suspend point
return std::suspend_always{}; // - suspend immediately
}
// define the way memory is allocated:
void* operator new(std::size_t sz) {
return mempool.allocate(sz);
}
void operator delete(void* ptr, std::size_t sz) {
mempool.deallocate(ptr, sz);
}
};
// constructor and destructor:
CoroTaskPmr(auto h) : hdl{h} { }
~CoroTaskPmr() { if (hdl) hdl.destroy(); }
// don’t copy or move:
CoroTaskPmr(const CoroTaskPmr&) = delete;
CoroTaskPmr& operator=(const CoroTaskPmr&) = delete;
// API to resume the coroutine
// - returns whether there is still something to process
bool resume() const {
if (!hdl || hdl.done()) {
return false; // nothing (more) to process
}
hdl.resume(); // RESUME (blocks until suspended again or end)
return !hdl.done();
}
};
```

```cpp
class [[nodiscard]] CoroTaskPmr {
// provide 200k bytes as memory for all coroutines:
inline static std::array<std::byte, 200’000> buf;
inline static std::pmr::monotonic_buffer_resource
monobuf{buf.data(), buf.size(), std::pmr::null_memory_resource()};
inline static std::pmr::synchronized_pool_resource mempool{&monobuf};
...
public:
struct promise_type {
...
// define the way memory is allocated:
void* operator new(std::size_t sz) {
return mempool.allocate(sz);
}
void operator delete(void* ptr, std::size_t sz) {
mempool.deallocate(ptr, sz);
}
};
...
};

```

```cpp
#include <iostream>
#include <string>
#include "corotaskpmr.hpp"
#include "tracknew.hpp"
CoroTaskPmr coro(int max)
{
for (int val = 1; val <= max; ++val) {
std::cout << " coro(" << max << "): " << val << '\n';
co_await std::suspend_always{};
}
}
CoroTaskPmr coroStr(int max, std::string s)
{
for (int val = 1; val <= max; ++val) {
std::cout << " coroStr(" << max << ", " << s << "): " << '\n';
co_await std::suspend_always{};
}
}
int main()
{
TrackNew::trace();
TrackNew::reset();
530 Chapter 15: Coroutines in Detail
coro(3); // initialize temporary coroutine
coroStr(3, "hello"); // initialize temporary coroutine
auto coroTask = coro(3); // initialize coroutine
std::cout << "coro() started\n";
while (coroTask.resume()) { // RESUME
std::cout << "coro() suspended\n";
}
std::cout << "coro() done\n";
}
```

```cpp
class CoroTaskPmr {
public:
struct promise_type {
...
void* operator new(std::size_t sz, int, const std::string&) {
return mempool.allocate(sz);
}
};
...
};
```

```cpp
::operator new(std::size_t sz, std::nothrow_t)
```

```cpp
class CoroTask {
...
public:
struct promise_type {
...
static auto get_return_object_on_allocation_failure() {
return CoroTask{nullptr};
}
};
...
};
```


## co_await and Awaiters in Detail
### Letting co_await Update Running Coroutines
```cpp
int CoroPrioDefVal = 10; enum class CoroPrioRequest {same, less, more, def};
```

```cpp
#include "coropriosched.hpp"
#include <iostream>
CoroPrioTask coro(int max)
{
std::cout << " coro(" << max << ")\n";
for (int val = 1; val <= max; ++val) {
std::cout << " coro(" << max << "): " << val << '\n';
co_await CoroPrio{CoroPrioRequest::less}; // SUSPEND with lower prio
}
std::cout << " end coro(" << max << ")\n";
}
```

```cpp
#include "coroprio.hpp"
#include <iostream>
int main()
{
std::cout << "start main()\n";
CoroPrioScheduler sched;
std::cout << "schedule coroutines\n";
sched.start(coro(5));
sched.start(coro(1));
sched.start(coro(4));
std::cout << "loop until all are processed\n";
while (sched.resumeNext()) {
}
std::cout << "end main()\n";
}

```

```cpp
class CoroPrioScheduler
{
std::multimap<int, CoroPrioTask> tasks; // all tasks sorted by priority
...
public:
void start(CoroPrioTask&& task);
bool resumeNext();
bool changePrio(CoroPrioTask::CoroHdl hdl, CoroPrioRequest pr);
};
```

```cpp
class CoroPrioScheduler
{
...
public:
void start(CoroPrioTask&& task) {
// store scheduler in coroutine state:
task.hdl.promise().schedPtr = this;
// schedule coroutine with a default priority:
tasks.emplace(CoroPrioDefVal, std::move(task));
}
...
};
```

```cpp
class CoroPrioTask {
...
friend class CoroPrioScheduler; // give access to the handle
struct promise_type {
...
CoroPrioScheduler* schedPtr = nullptr; // each task knows its scheduler:
auto await_transform(CoroPrioRequest); // deal with co_await a CoroPrioRequest
};
...
}
```

```cpp
class CoroPrio {
private:
CoroPrioRequest prioRequest;
public:
CoroPrio(CoroPrioRequest pr)
: prioRequest{pr} { // deal with co_await a CoroPrioRequest
}
...
void await_suspend(CoroPrioTask::CoroHdl h) noexcept {
h.promise().schedPtr->changePrio(h, prioRequest);
}
...
};
```
### Symmetric Transfer with Awaiters for Continuation
```cpp
class CoroTask
{
public:
struct promise_type;
using CoroHdl = std::coroutine_handle<promise_type>;
private:
CoroHdl hdl; // native coroutine handle
public:
struct promise_type {
std::coroutine_handle<> contHdl = nullptr; // continuation (if there is one)
...
auto final_suspend() noexcept {
// the coroutine is not suspended yet, use awaiter for continuation
return FinalAwaiter{};
}
};
...
};
```

```cpp
struct FinalAwaiter {
bool await_ready() noexcept {
return false;
}
std::coroutine_handle<> await_suspend(CoroTask::CoroHdl h) noexcept {
// the coroutine is now suspended at the final suspend point
// - resume its continuation if there is one
if (h.promise().contHdl) {
return h.promise().contHdl; // return the next coro to resume
}
else {
return std::noop_coroutine(); // no next coro => return to caller
}
}
void await_resume() noexcept {
}
};

```

```cpp
std::coroutine_handle<> coro = std::noop_coroutine();
...
if (coro == std::noop_coroutine()) { // OOPS: does not check whether coro has initial value
...
return coro;
}
```

```cpp
std::coroutine_handle<> coro = nullptr;
...
if (coro) { // OK (checks whether coro has initial value)
...
return std::noop_coroutine();
}
```
## Other Ways of Dealing with co_await
```cpp
co_await 42;
co_await (x + y);
The co_await operator has the same priority as sizeof or new. For this reason, you cannot skip the
parentheses in the example above without changing the meaning. The statement
co_await x + y;
would be evaluated as follows:
(co_await x) + y;
```
### await_transform()
```cpp
class CoroTask {
struct promise_type {
...
auto await_transform(int val) {
return MyAwaiter{val};
}
};
...
};
CoroTask coro()
{
co_await 42;
}
has the same effect as:
class CoroTask {
...
};
CoroTask coro()
{
co_await MyAwaiter{42};
}
You can also use it to enable a coroutine to pass a value to the promise before using a (standard) awaiter:
class CoroTask {
struct promise_type {
...
auto await_transform(int val) {
... // process val
return std::suspend_always{};
}
};
...
};
CoroTask coro()
{
co_await 42; // let 42 be processed by the promise and suspend
}
```

```cpp
co_await CoroPrio{CoroPrioRequest::less}; // SUSPEND with lower prio
We could also allow only the new priority to be passed:
co_await CoroPrioRequest::less; // SUSPEND with lower prio
```

```cpp
class CoroPrioTask {
public:
struct promise_type;
using CoroHdl = std::coroutine_handle<promise_type>;
540 Chapter 15: Coroutines in Detail
private:
CoroHdl hdl; // native coroutine handle
friend class CoroPrioScheduler; // give access to the handle
public:
struct promise_type {
CoroPrioScheduler* schedPtr = nullptr; // each task knows its scheduler:
...
auto await_transform(CoroPrioRequest); // deal with co_await CoroPrioRequest
};
...
};

```

```cpp
inline auto CoroPrioTask::promise_type::await_transform(CoroPrioRequest pr) {
auto hdl = CoroPrioTask::CoroHdl::from_promise(*this);
schedPtr->changePrio(hdl, pr);
return std::suspend_always{};
}

```
### Letting co_await Act Like co_yield
```cpp
struct promise_type {
int coroValue = 0; // last value from co_yield
auto yield_value(int val) { // reaction to co_yield
coroValue = val; // - store value locally
return std::suspend_always{}; // - suspend coroutine
}
...
};
co_yield val; // calls yield_value(val) on promise
```

```cpp
struct promise_type {
int coroValue = 0; // last value from co_yield
auto await_transform(int val) {
coroValue = val; // - store value locally
return std::suspend_always{};
}
...
};
co_await val; // calls await_transform(val) on promise
```

```cpp
In fact,
co_yield val;
is equivalent to
co_await prm.yield_value(val);
```
### operator co_await()
```cpp
class MyType {
auto operator co_await() {
return std::suspend_always{};
}
};
Then, calling co_await for an object of that type:
CoroTask coro()
{
...
co_await MyType{};
}
```

```cpp
CoroTask coro()
{
...
co_await std::suspend_always{};
}

```
## Concurrent Use of Coroutines
### co_await Coroutines
```cpp
#include "coropool.hpp"
#include <iostream>
#include <syncstream> // for std::osyncstream
inline auto syncOut(std::ostream& strm = std::cout) {
return std::osyncstream{strm};
}
CoroPoolTask print(std::string id, std::string msg)
{
syncOut() << " > " << id << " print: " << msg
<< " on thread: " << std::this_thread::get_id() << std::endl;
co_return; // make it a coroutine
}
CoroPoolTask runAsync(std::string id)
{
syncOut() << "===== " << id << " start "
<< " on thread: " << std::this_thread::get_id() << std::endl;
co_await print(id + "a", "start");
syncOut() << "===== " << id << " resume "
<< " on thread " << std::this_thread::get_id() << std::endl;
co_await print(id + "b", "end ");
syncOut() << "===== " << id << " resume "
<< " on thread " << std::this_thread::get_id() << std::endl;
syncOut() << "===== " << id << " done" << std::endl;
}
```

```cpp
CoroPoolTask runAsync(std::string id)
{
...
co_await print( ... );
...
}
```

```cpp
#include "coroasync.hpp"
#include <iostream>
int main()
{
// init pool of coroutine threads:
syncOut() << "**** main() on thread " << std::this_thread::get_id()
<< std::endl;
CoroPool pool{4};
// start main coroutine and run it in coroutine pool:
syncOut() << "runTask(runAsync(1))" << std::endl;
CoroPoolTask t1 = runAsync("1");
pool.runTask(std::move(t1));
// wait until all coroutines are done:
syncOut() << "\n**** waitUntilNoCoros()" << std::endl;
pool.waitUntilNoCoros();
syncOut() << "\n**** main() done" << std::endl;
}
```

```cpp
#include "coroasync.hpp"
#include <iostream>
int main()
{
// init pool of coroutine threads:
syncOut() << "**** main() on thread " << std::this_thread::get_id()
<< std::endl;
CoroPool pool{4};
// start multiple coroutines and run them in coroutine pool:
for (int i = 1; i <= 4; ++i) {
syncOut() << "runTask(runAsync(" << i << "))" << std::endl;
pool.runTask(runAsync(std::to_string(i)));
}
// wait until all coroutines are done:
syncOut() << "\n**** waitUntilNoCoros()" << std::endl;
pool.waitUntilNoCoros();
syncOut() << "\n**** main() done" << std::endl;
}

```
### A Thread Pool for Coroutine Tasks
```cpp
#include <iostream>
#include <list>
#include <utility> // for std::exchange()
#include <functional> // for std::function
#include <coroutine>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
class CoroPool;
class [[nodiscard]] CoroPoolTask
{
friend class CoroPool;
public:
struct promise_type;
using CoroHdl = std::coroutine_handle<promise_type>;
private:
CoroHdl hdl;
public:
struct promise_type {
15.9 Concurrent Use of Coroutines 547
CoroPool* poolPtr = nullptr; // if not null, lifetime is controlled by pool
CoroHdl contHdl = nullptr; // coro that awaits this coro
CoroPoolTask get_return_object() noexcept {
return CoroPoolTask{CoroHdl::from_promise(*this)};
}
auto initial_suspend() const noexcept { return std::suspend_always{}; }
void unhandled_exception() noexcept { std::exit(1); }
void return_void() noexcept { }
auto final_suspend() const noexcept {
struct FinalAwaiter {
bool await_ready() const noexcept { return false; }
std::coroutine_handle<> await_suspend(CoroHdl h) noexcept {
if (h.promise().contHdl) {
return h.promise().contHdl; // resume continuation
}
else {
return std::noop_coroutine(); // no continuation
}
}
void await_resume() noexcept { }
};
return FinalAwaiter{}; // AFTER suspended, resume continuation if there is one
}
};
explicit CoroPoolTask(CoroHdl handle)
: hdl{handle} {
}
~CoroPoolTask() {
if (hdl && !hdl.promise().poolPtr) {
// task was not passed to pool:
hdl.destroy();
}
}
CoroPoolTask(const CoroPoolTask&) = delete;
CoroPoolTask& operator= (const CoroPoolTask&) = delete;
CoroPoolTask(CoroPoolTask&& t)
: hdl{t.hdl} {
t.hdl = nullptr;
}
CoroPoolTask& operator= (CoroPoolTask&&) = delete;
// Awaiter for: co_await task()
548 Chapter 15: Coroutines in Detail
// - queues the new coro in the pool
// - sets the calling coro as continuation
struct CoAwaitAwaiter {
CoroHdl newHdl;
bool await_ready() const noexcept { return false; }
void await_suspend(CoroHdl awaitingHdl) noexcept; // see below
void await_resume() noexcept {}
};
auto operator co_await() noexcept {
return CoAwaitAwaiter{std::exchange(hdl, nullptr)}; // pool takes ownership of hdl
}
};
class CoroPool
{
private:
std::list<std::jthread> threads; // list of threads
std::list<CoroPoolTask::CoroHdl> coros; // queue of scheduled coros
std::mutex corosMx;
std::condition_variable_any corosCV;
std::atomic<int> numCoros = 0; // counter for all coros owned by the pool
public:
explicit CoroPool(int num) {
// start pool with num threads:
for (int i = 0; i < num; ++i) {
std::jthread worker_thread{[this](std::stop_token st) {
threadLoop(st);
}};
threads.push_back(std::move(worker_thread));
}
}
~CoroPool() {
for (auto& t : threads) { // request stop for all threads
t.request_stop();
}
for (auto& t : threads) { // wait for end of all threads
t.join();
}
for (auto& c : coros) { // destroy remaining coros
c.destroy();
}
}
15.9 Concurrent Use of Coroutines 549
CoroPool(CoroPool&) = delete;
CoroPool& operator=(CoroPool&) = delete;
void runTask(CoroPoolTask&& coroTask) noexcept {
auto hdl = std::exchange(coroTask.hdl, nullptr); // pool takes ownership of hdl
if (coroTask.hdl.done()) {
coroTask.hdl.destroy(); // OOPS, a done() coroutine was passed
}
else {
schedule coroutine in the pool
}
}
// runCoro(): let pool run (and control lifetime of) coroutine
// called from:
// - pool.runTask(CoroPoolTask)
// - co_await task()
void runCoro(CoroPoolTask::CoroHdl coro) noexcept {
++numCoros;
coro.promise().poolPtr = this; // disables destroy in CoroPoolTask
{
std::scoped_lock lock(corosMx);
coros.push_front(coro); // queue coro
corosCV.notify_one(); // and let one thread resume it
}
}
void threadLoop(std::stop_token st) {
while (!st.stop_requested()) {
// get next coro task from the queue:
CoroPoolTask::CoroHdl coro;
{
std::unique_lock lock(corosMx);
if (!corosCV.wait(lock, st, [&] {
return !coros.empty();
})) {
return; // stop requested
}
coro = coros.back();
coros.pop_back();
}
// resume it:
coro.resume(); // RESUME
550 Chapter 15: Coroutines in Detail
// NOTE: The coro initially resumed on this thread might NOT be the coro finally called.
// If a main coro awaits a sub coro, then the thread that finally resumed the sub coro
// resumes the main coro as its continuation.
// => After this resumption, this coro and SOME continuations MIGHT be done
std::function<void(CoroPoolTask::CoroHdl)> destroyDone;
destroyDone = [&destroyDone, this](auto hdl) {
if (hdl && hdl.done()) {
auto nextHdl = hdl.promise().contHdl;
hdl.destroy(); // destroy handle done
--numCoros; // adjust total number of coros
destroyDone(nextHdl); // do it for all continuations done
}
};
destroyDone(coro); // recursively destroy coroutines done
numCoros.notify_all(); // wake up any waiting waitUntilNoCoros()
// sleep a little to force another thread to be used next:
std::this_thread::sleep_for(std::chrono::milliseconds{100});
}
}
void waitUntilNoCoros() {
int num = numCoros.load();
while (num > 0) {
numCoros.wait(num); // wait for notification that numCoros changed the value
num = numCoros.load();
}
}
};
// CoroPoolTask awaiter for: co_await task()
// - queues the new coro in the pool
// - sets the calling coro as continuation
void CoroPoolTask::CoAwaitAwaiter::await_suspend(CoroHdl awaitingHdl) noexcept
{
newHdl.promise().contHdl = awaitingHdl;
awaitingHdl.promise().poolPtr->runCoro(newHdl);
}

```

```cpp
class [[nodiscard]] CoroPoolTask
{
...
struct promise_type {
CoroPool* poolPtr = nullptr; // if not null, lifetime is controlled by pool
...
};
...
};
```

```cpp
class [[nodiscard]] CoroPoolTask
{
...
struct promise_type {
...
CoroHdl contHdl = nullptr; // coro that awaits this coro
...
auto final_suspend() const noexcept {
struct FinalAwaiter {
bool await_ready() const noexcept { return false; }
std::coroutine_handle<> await_suspend(CoroHdl h) noexcept {
if (h.promise().contHdl) {
return h.promise().contHdl; // resume continuation
}
else {
return std::noop_coroutine(); // no continuation
}
}
void await_resume() noexcept {}
};
return FinalAwaiter{}; // AFTER suspended, resume continuation if there is one
}
};
...
};
```

```cpp
class [[nodiscard]] CoroPoolTask
{
...
struct CoAwaitAwaiter {
CoroHdl newHdl;
bool await_ready() const noexcept { return false; }
void await_suspend(CoroHdl awaitingHdl) noexcept; // see below
void await_resume() noexcept {}
};
auto operator co_await() noexcept {
return CoAwaitAwaiter{std::exchange(hdl, nullptr)}; // pool takes ownership of hdl
}
};
void CoroPoolTask::CoAwaitAwaiter::await_suspend(CoroHdl awaitingHdl) noexcept
{
newHdl.promise().contHdl = awaitingHdl;
awaitingHdl.promise().poolPtr->runCoro(newHdl);
}
When we call print() with co_await:
CoroPoolTask runAsync(std::string id)
{
...
co_await print( ... );
...
}
```

```cpp
std::list<std::jthread> threads; // list of threads

```

```cpp
std::list<CoroPoolTask::CoroHdl> coros; // queue of scheduled coros
std::mutex corosMx;
std::condition_variable_any corosCV;
• To avoid stopping the pool too early, the pool also tracks the total number of coroutines owned by the
pool:
std::atomic<int> numCoros = 0; // counter for all coros owned by the pool
```

```cpp
void runCoro(CoroPoolTask::CoroHdl coro) noexcept {
++numCoros;
...
}
```

```cpp
std::function<void(CoroPoolTask::CoroHdl)> destroyDone;
destroyDone = [&destroyDone, this](auto hdl) {
if (hdl && hdl.done()) {
auto nextHdl = hdl.promise().contHdl;
hdl.destroy(); // destroy handle done
--numCoros; // adjust total number of coros
destroyDone(nextHdl); // do it for all continuations done
}
};
destroyDone(coro); // recursively destroy coroutines done
```

```cpp
numCoros.notify_all(); // wake up any waiting waitUntilNoCoros()
...
void waitUntilNoCoros() {
int num = numCoros.load();
while (num > 0) {
numCoros.wait(num); // wait for notification that numCoros changed the value
num = numCoros.load();
}
}

```

```cpp
class CoroPool
{
...
void syncWait(CoroPoolTask&& task) {
std::binary_semaphore taskDone{0};
auto makeWaitingTask = [&]() -> CoroPoolTask {
co_await task;
struct SignalDone {
std::binary_semaphore& taskDoneRef;

bool await_ready() { return false; }
bool await_suspend(std::coroutine_handle<>) {
taskDoneRef.release(); // signal task is done
return false; // do not suspend at all
}
void await_resume() { }
};
co_await SignalDone{taskDone};
};
runTask(makeWaitingTask());
taskDone.acquire();
}
};
```

```cpp
bool await_ready() {
taskDoneRef.release(); // signal task is done
return true; // do not suspend at all
}
```
## Coroutine Traits
```cpp
void coro(int max, CoroTask&)
{
std::cout << "CORO " << max << " start\n";
for (int val = 1; val <= max; ++val) {
// print next value:
std::cout << "CORO " << val << '/' << max << '\n';
co_await std::suspend_always{}; // SUSPEND
}
std::cout << "CORO " << max << " end\n";
}
```

```cpp
template<>
struct std::coroutine_traits<void, int, CoroTask&>
{
using promise_type = CoroTask::promise_type;
};

```

```cpp
class CoroTask {
public:
// required type for customization:
struct promise_type {
promise_type(int, CoroTask& ct) { // init passed coroutine interface
ct.hdl = CoroHdl::from_promise(*this);
}
void get_return_object() { // nothing to do anymore
}
...
};
private:
// handle to allocate state (can be private):
using CoroHdl = std::coroutine_handle<promise_type>;
CoroHdl hdl;
public:
// constructor and destructor:
CoroTask() : hdl{} { // enable coroutine interface without handle
}
...
};

```

```cpp
CoroTask coroTask; // create coroutine interface without coroutine
// start coroutine:
coro(3, coroTask); // init and store coroutine in the interface created
// loop to resume the coroutine until it is done:
while (coroTask.resume()) { // resume
std::this_thread::sleep_for(500ms);
}
```

```cpp

```
