# Ranges and Views
自第一个 `C++` 标准以来，处理容器和其他序列元素的方法一直是使用迭代器，来确定第一个元素的位置和最后一个元素后面的位置。对范围进行操作的算法通常使用两个参数来处理容器的所有元素，容器提供了 `begin()` 和 `end()` 等函数来提供这些参数。
`C++20` 提供了一种处理范围的新方法，支持将范围和子范围定义和使用为单个对象，将其作为一个整体作为单个参数传递，而不是处理两个迭代器。
## Ranges
`C++20` 引入范围的概念，表示一系列值的单个对象，可以将容器作为一个范围传递给算法:
```cpp
std::vector<int> coll{25, 42, 2, 0, 122, 5, 7};
std::ranges::sort(coll); // sort all elements of the collection
```
### namespace
`C++` 标准库提供处理特殊命名空间中的范围的所有功能，大多数在命名空间 `std::ranges` 中提供，其中一些在 `std::views` 中提供，这是 `std::ranges::views` 的别名。 
```cpp
#include<algorithm>
#include<vector>
#include<ranges>
namespace rg = std::ranges; // define shortcut for std::ranges
std::vector<int> coll{25, 42, 2, 0, 122, 5, 7};
rg::sort(coll); // sort all elements of the collection
```
### Header Files for Ranges
范围库的许多新特性都在新的头文件 `<ranges>` 中提供，但其中一些是在现有的头文件中提供的。范围算法就是一个例子，在 `<algorithm>` 中声明。因此，要使用为范围提供的算法作为单个参数，只需要包含 `<algorithm>`。 但对于范围库提供的一些附加特性，需要头文件 `<ranges>`。
### Constraints and Utilities for Ranges
范围的新标准算法将范围参数声明为模板参数，为了在处理这些范围参数时指定和验证必要的要求，`C++20` 引入了几个范围概念。此外，工具可用于使用这些概念。例如，sort() 算法定义如下：
```cpp
template<std::ranges::random_access_range R, typename Comp = std::ranges::less>
requires std::sortable<std::ranges::iterator_t<R>, Comp>
... sort(R&& r, Comp comp = {});
```
两个标准概念规定通过范围 R 的要求：
- 概念 `std::ranges::random_access_range` 要求 R 是提供随机访问迭代器的范围 (可以使用迭代器在元素之间来回跳转，并计算其距离)。这个概念包含范围 `std::range` 的基本概念，要求对于传递的参数，至少使用 `std::ranges::begin()` 和 `std::ranges::end()`，可以从 `begin()` 到 `end()` 遍历元素，所以数组也满足这个概念。
- `sortable` 概念要求范围 R 中的元素可以用排序条件 `Comp` 进行排序。 
新的类型工具 `std::ranges::iterator_t` 用于将迭代器类型传递给 `std::sortable`。
比较谓词 `std::ranges::less` 用作默认的比较条件，其定义排序算法使用 < 操作符对元素进行排序。`std::ranges::less` 是一种概念约束的 `std::less`，确保支持所有比较操作符，并确保值具有总排序。所以，可以通过随机访问迭代器和可排序元素传递任何范围。例如：
```cpp
void print(const auto& coll) {
    for (const auto& elem : coll) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

std::vector<std::string> coll{"Rio", "Tokyo", "New York", "Berlin"};
std::ranges::sort(coll); // sort elements
std::ranges::sort(coll[0]); // sort character in first element
print(coll);

int arr[] = {42, 0, 8, 15, 7};
std::ranges::sort(arr); // sort values in array
print(arr);
```
### Range Concepts
基本范围概念表列出了定义范围需求的基本概念。

|                           |                                                              |
| ------------------------- | ------------------------------------------------------------ |
| Concept | Requires                                                     |
| range                     | Can be iterated from begin to end 可以从头到尾迭代           |
| output_range             | Range of elements to write values to 写入值的元素的范围      |
| input_range              | Range to read element values from 读取元素值的范围           |
| forward_range            | Range you can iterate over the elements multiple times 范围可多次迭代这些元素 |
| bidirectional_ range      | Range you can iterate over the elements forward and backward 可以向前和向后遍历元素 |
| random_access_range    | Range with random access 随机访问范围                        |
| contiguous_range         | Range with all elements in contiguous memory 连续内存中包含所有元素的范围 |
| sized_range              | Range with constant-time size() 具有恒定时间 size() 的范围   |
`std::ranges::range` 是所有其他范围概念的基本概念 (所有其他概念都包含这个概念)。 
`output_range`，`input_range`, `forward_range`, `bidirectional_range`, `random_access_range` 和 `contiguous_range` 的层次结构映射到相应的迭代器类别，并构建相应的包容层次结构。
`std::ranges::consecuous_range` 是一个新的范围/迭代器类别，其保证元素存储在连续内存中，通过使用指针迭代元素。
`std::ranges::sized_range` 独立于其他约束，只是它是一个范围。
迭代器和相应的范围类别在 C++20 中略有变化，C++ 标准现在支持两个版本的迭代器类别 C++20 之前的版本和 C++20 之后的版本，它们可能不一样。 
其他范围概念表列出用于特殊情况的其他一些范围概念。

| 概念 | 要求                                          |
| -------------------- | --------------------------------------------- |
| view                 | 复制或移动和分配成本较低的范围                |
| viewable_range       | 可以转换为视图的范围(使用 std::ranges::all()) |
| borrowed_range       | 使用与范围的生命周期无关的迭代器进行范围操作  |
| common_range         | 开始和结束的范围具有相同的类型                |
## Views
为了处理范围，`C++20` 引入了视图。视图是轻量级的范围，创建和复制/移动成本都很低，只使用小的或不重要的内联函数，所以至少在通常情况下，优化编译器可以避免显著的开销。视图通常用于在特定的基础上，处理基础范围的元素子集或经过一些可选转换后的值。
例如，可以使用一个视图来迭代一个范围的前五个元素，如下所示:
```cpp
// 创建前 5 个元素的视图，若容器少于 5 个，则以最后一个元素结束
for (const auto& elem : std::views::take(coll, 5)) {...}

for (int val : std::views::iota(1, 11)) {...} // iterate from 1 to 10
```
`std::views::take()` 是一个范围适配器，用于创建对传递的范围 `coll` 进行操作的视图。
此外，`C++20` 提供几个标准视图，可以用来将一个范围转换为一个视图，或者将一个视图转换为一个范围/视图。
对于每一种视图类型，都有一个相应的函数对象，允许开发者调用函数来创建视图。若函数从传递的范围中创建视图，则这样的函数对象称为范围适配器。若函数在不传递现有范围的情况下创建视图，则称为范围工厂。大多数情况下，这些函数对象都定义在特殊的命名空间 `std::views` 中，具有不带 `_view` 后缀的视图名，唯一不以 `_view` 结尾的视图类型是 `std::subange` 和 `std::span`。一些更通用的函数对象可能会根据传递的参数创建不同的视图。
源视图表列出 `C++20` 中从外部资源创建视图或生成值的标准视图，这些视图可以作为视图管道中的起始构建块。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240213204725.png)
适配视图表列出 `C++20` 中处理范围和其他视图的范围适配器和标准视图，可以作为视图管道中的任何地方的构建块，包括在视图的开头。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240213204737.png)
### Pipelines of Ranges and Views
调用作为单个参数传递的范围适配器有另一种语法:
```cpp
for (const auto& elem : coll | std::views::take(5)) {}
```
这两种形式等价，但管道语法使得在范围上创建视图序列更加方便，这样，简单的视图就可以用作更复杂的元素集合处理的构建块。假设想使用以下三个视图:
```cpp
// view with elements of coll that are multiples of 3:
std::views::filter(coll, [] (auto elem) {
    return elem % 3 == 0;
})

// view with squared elements of coll:
std::views::transform(coll, [] (auto elem) {
    return elem * elem;
})

// view with first three elements of coll:
std::views::take(coll, 3)

// Because a view is a range, can use a view as an argument of another view:
// view with first three squared values of the elements in coll that are multiples of 3:
auto v = std::views::take(
    std::views::transform(
        std::views::filter(coll,
            [] (auto elem) { return elem % 3 == 0; }),
            [] (auto elem) { return elem * elem; }),
            3);
```
这种嵌套很难阅读和维护，可以从另一种管道语法中让视图对范围进行操作：
```cpp
// view with first three squared values of the elements in coll that are multiples of 3:
auto v = coll
        | std::views::filter([] (auto elem) { return elem % 3 == 0; })
        | std::views::transform([] (auto elem) { return elem * elem; })
        | std::views::take(3);
```
下面视图从 `map` 中找到值大于 1700 的前三个键
```cpp
namespace vws = std::views;
// map of composers (mapping their name to their year of birth):
std::map<std::string, int> composers{
    {"Bach", 1685},
    {"Mozart", 1756},
    {"Beethoven", 1770},
    {"Tchaikovsky", 1840},
    {"Chopin", 1810},
    {"Vivaldi ", 1678},
};

// iterate over the names of the first three composers born since 1700:
for (const auto& elem : composers
            | vws::filter([](const auto& y) { // since 1700
                return y.second >= 1700;
            })
            | vws::take(3) // first three
            | vws::keys // keys/names only
    ) {
    std::cout << "- " << elem << '\n';
}
```
### Type and Lifetime of Views
作为左值传递的范围的视图(简称为左值视图)都有引用语义，存储着对传递范围的引用，所以必须确保视图的引用范围和迭代器存在并且有效，所以只有当底层范围存在并且存储在视图或其迭代器中的引用有效时，才能使用视图。左值视图通常具有引用语义，所以视图既可以用于读取，也可以用于写入，修改引用范围的元素或视图的元素都会同步修改对方。
对作为左值传递的范围(作为第一个构造函数参数或使用管道)进行操作的视图，都在内部存储对传递范围的引用。使用视图时，底层范围必须存在。这样的代码会导致未定义行为：
```cpp
auto getValues() {
    std::vector coll{1, 2, 3, 4, 5};
    return coll | std::views::drop(2); // ERROR: return reference to local range
}
```
而在作为右值传递的范围对象上使用视图很好，可以将一个视图返回给一个临时范围对象或用 `std::move()` 标记底层范围：
```cpp
auto getValues() {
    // std::vector{1, 2, 3, 4, 5} 是临时对象
    return std::vector{1, 2, 3, 4, 5} | std::views::drop(2); // OK
}

// Or you can mark the underlying range with std::move():
auto getValues() {
    std::vector coll{1, 2, 3, 4, 5};
    return std::move(coll) | std::views::drop(2); // OK
}
```
可以使用 `auto` 来声明视图，例如：
```cpp
// std::ranges::<std::ranges::ref_view<std::vector<int>>>
auto v1 = std::views::take(coll, 5);
auto v2 = coll | std::views::take(5);
...
for (int val : v1) {...}
std::ranges::sort(v2);
```
在内部，适配器和构造函数可以创建嵌套视图类型，例如 `std::ranges::take_view` 或 `std::ranges::iota_view` 引用 `std::ranges::ref_view` 用于引用传入的外部容器的元素。 
也可以直接声明和初始化真实的视图，但通常应该使用提供的适配器和工厂来创建和初始化视图。使用适配器和工厂通常更好，因为更容易使用、更智能，并且可以提供优化。例如，若传递的范围已经是 `std::string_view`，`take()` 可能只产生一个 `std::string_view`。 
### Views on Ranges
容器和字符串不是视图，因为不够轻量级，没有提供低成本的复制构造函数，所以必须复制元素。然而，可以很容易地使用容器作为视图：
- 通过将容器传递给范围适配器 `std::views::all()`，可以显式地将容器转换为视图。
- 通过将 `begin` 迭代器和 `end`/哨兵 或大小传递给 `std::ranges::subrange` 或 `std::views::counts()`，可以显式地将容器的元素转换为视图。
- 可以通过将容器传递给其中一个适配器来隐式地将其转换为视图。 
```cpp
// 可以将范围作为参数传递给视图的构造函数
std::ranges::take_view first4{coll, 4};

// 可以把这个范围作为参数传递给相应的适配器
auto first4 = std::views::take(coll, 4);

// 可以通过管道将范围传入相应的适配器
auto first4 = coll | std::views::take(4);
```
视图 `first4` 只迭代 `coll` 的前 4 个元素，但这里发生什么取决于 coll 是什么类型：
- 若 `coll` 已经是一个视图，`take()` 会按原样获取视图。
- 若 `coll` 是一个容器，`take()` 使用一个到容器的视图，该视图是用适配器 `std::views::all()` 自动创建的。适配器会产生一个 `ref_view`，若容器作为左值传递，将引用容器的所有元素。若作为右值，则该范围将移动到 `owning_view` 中，然后 `owning_view` 直接保存传递类型的范围，其中包含所有移动的元素。
例如：
```cpp
std::vector<std::string> coll{"just", "some", "strings", "to", "deal", "with"};
auto v1 = std::views::take(coll, 4); // iterates over a ref_view to coll
// iterates over an owning_view to a local vector<string>
auto v2 = std::views::take(std::move(coll), 4); 
auto v3 = std::views::take(v1, 2); // iterates over v1
```
`std::views::take()` 会创建一个新的获取视图，最终迭代在 `coll` 中初始化的值，但结果类型和确切的行为有如下不同：
- `v1` 是 `take_view<ref_view<vector<string>>>`。 将容器 `coll` 作为左值传递，所以 `take view` 通过 `ref view` 迭代容器。
- `v2` 是 `take_view<owning_view<vector<string>>>`. 将 `coll` 作为右值传递，所以 `take view` 视图通过 `owning view` 视图迭代容器，该视图拥有用传递的集合初始化的字符串 `vector`。
- `v3` 是 `take_view<take_view<ref_view<vector<string>>>`，因为传递视图 `v1`，所以 `take view` 迭代这个视图，最终迭代 `coll`，但由于其中的元素已经由第二条语句移除，所以第二条语句之后不需要再遍历。
这种行为允许基于范围的 `for` 循环迭代临时范围:
```cpp
for (const auto& elem : getColl() | std::views::take(5)) 
    std::cout << "- " << elem << '\n';
for (const auto& elem : getColl() | std::views::take(5) | std::views::drop(2)) {
    std::cout << "- " << elem << '\n';
```
通常，使用对临时对象的引用作为基于范围的 `for` 循环迭代的集合是一个运行时错误，但由于传递临时范围对象将范围移动到 `owning_view` 中，因此视图不会引用外部容器，从而不会出现运行时错误。
### Lazy Evaluation
视图在定义后不会开始处理，其会按需运行：
- 若需要视图的下一个元素，则通过执行必要的迭代来计算其是哪一个。
- 若需要一个视图元素的值，则通过执行定义的转换来计算其值。
```cpp
namespace vws = std::views;

std::vector<int> coll{ 8, 15, 7, 0, 9 };

auto vColl = coll 
            | vws::filter([] (int i) {
                std::cout << " filter " << i << '\n';
                return i % 3 == 0;
            })
            | vws::transform([] (int i) {
                std::cout << " trans " << i << '\n';
                return -i;
            });

std::cout << "*** coll | filter | transform:\n";
for (int val : vColl) std::cout << "val: " << val << "\n\n";
```
上述定义视图 `vColl`，只过滤和转换范围 `coll` 的元素，使用 `std::views::filter()` 只处理那些是 3 的倍数的元素，使用 `std::views::transform()` 对每个值求反。
定义视图 `vColl` 之后，不会调用 `filter()` 和 `transform()`。当使用视图时，才会开始处理。视图使用延迟求值，只是对处理的描述，当需要下一个元素或值时才真正进行处理。假设对 `vColl` 进行更多的手动迭代，调用 `begin()` 和 `++` 来获取下一个值，使用解引用操作符来获取其值：
```cpp
std::cout << "pos = vColl.begin():\n";
auto pos = vColl.begin();

std::cout << "*pos:\n";
auto val = *pos;
std::cout << "val: " << val << "\n\n";

std::cout << "++pos:\n";
++pos;
std::cout << "*pos:\n";
val = *pos;
std::cout << "val: " << val << "\n\n";
```
当调用 `begin()` 时，会发生以下情况：
- 获取 `vColl` 的第一个元素的请求会传递给转换视图，转换视图将其传递给过滤器视图，过滤器视图将其传递给 `coll`，生成迭代器的第一个元素 8。
- 过滤器视图查看第一个元素的值并拒绝，并通过调用 `++` 向 `coll` 请求下一个元素。过滤器获取第二个元素的位置 15，并将其位置传递给变换视图。因此，`pos` 初始化为指向第二个元素的位置的迭代器。
当使用 `*pos` 时，会发生以下情况：因为需要这个值，所以现在为当前元素调用转换视图，并生成其负值，用当前元素的负值初始化 `val`。 
当使用 `++pos` 时，同样的情况会再次发生：获取下一个元素的请求传递给过滤器，过滤器将请求传递给 `coll`，直到找到合适的元素或到达 `coll` 的末尾，因此，`pos` 获取第四个元素的位置。通过再次调用 `*pos`，执行转换并为循环生成下一个值。
这个迭代会一直持续下去，直到范围或其中一个视图表示已经到达终点。
这种 `pull` 模型的好处在于不处理不需要的元素，而且视图的序列或管道甚至可以在无限范围内操作。不会在不知道使用了多少的情况下计算无限个值，从而根据视图的用户请求计算尽可能多的值。
### Performance Issues with Filters
`Pull` 模式也有缺点，为演示这一点，改变上面涉及的两个视图的顺序：
```cpp
std::vector<int> coll{ 8, 15, 7, 0, 9 };
// define a view:
auto vColl = coll
            | vws::transform([] (int i) {
                std::cout << " trans: " << i << '\n';
                return -i;
            })
            | vws::filter([] (int i) {
                std::cout << " filt: " << i << '\n';
                return i % 3 == 0;
            });
std::cout << "*** coll | transform | filter:\n";
for (int val : vColl) std::cout << "val: " << val << "\n\n";
```
这里会调用两次 `transform`，第一次是对每个元素使用，第二次是对过滤后的元素。
范围和视图在范围的元素上分两步迭代，首先计算位置/迭代器，然后作为单独的步骤，使用解引用操作符来获取值，因此对于每个过滤器来说，需要转换后的值来进行检查。而对于过滤后的元素，过滤器只返回元素的位置，而不返回值，所以当使用过滤器的用户需要某个值时，就必须再次执行转换操作。 
```cpp
// 应该
if (-x % 3 == 0) return -x; // first transformation then filter
// 而非
if (x % 3 == 0) return -x; // first filter then transformation
```
若担心管道的性能，应该在使用过滤器之前避免耗时的转换。所有视图提供的功能通常都优化为只保留转换和过滤器中的表达式。
### Caching in Views
一些视图使用缓存。若使用 `begin()` 访问视图的第一个元素需要一些计算，视图可能会缓存 `begin()` 的返回值，以便下次调用 `begin()` 时，不必再次计算第一个元素的位置。然而，这种优化有一些后果: 
- 要求视图在遍历其元素时不能是 `const`，当视图为 `const` 时，可能无法遍历视图。
- 即使没有修改任何东西，并发迭代也会导致未定义行为。 
- 早期的读访问可能会使视图元素的后期迭代失效或更改。 
若根本不遍历视图的元素，那么在初始化时进行缓存将会带来不必要的性能开销。若在视图的元素上迭代一秒或更多次，完全不缓存将会带来不必要的性能成本，某些情况下，在丢弃段视图上应用反向视图，甚至可能具有二次复杂度。 
在范围中插入或删除元素，可能会对视图的功能产生重大影响。经过这样的修改后，视图的行为可能会有所不同，甚至不再有效。因此，强烈建议在需要视图之前使用它们，若在初始化视图和使用视图之间发生修改，则必须谨慎。
多次迭代一个视图一次又一次地计算第一个有效元素时，跳过的元素视图会在调用 `begin()` 后进行缓存。例如在视图 `vColl` 的元素上迭代两次:
```cpp
std::cout << "*** coll | filter | transform:\n";
for (int val : vColl) {...}
std::cout << "-------------------\n";

std::cout << "*** coll | filter | transform:\n";
for (int val : vColl) std::cout << "val: " << val << "\n\n";
```
第二次使用 `vcol.begin()` 时，不再尝试查找第一个元素，因为与过滤器元素的第一次迭代一起进行了缓存，但 `begin()` 的缓存有好有坏，如果在调用 `begin()` 之后修改范围可能会使视图失效：
```cpp
// 若在修改之前不调用 begin()，这个视图通常是有效的，以后使用时也能正常工作
std::list coll{1, 2, 3, 4, 5};
auto v = coll | std::views::drop(2);
coll.push_front(0); // coll is now: 0 1 2 3 4 5
print(v); // initializes begin() with 2 and prints: 2 3 4 5

// 但若在修改之前调用 begin()(例如，打印元素)，就很容易得到错误的元素
std::list coll{1, 2, 3, 4, 5};
auto v = coll | std::views::drop(2);
print(v); // init begin() with 3
coll.push_front(0); // coll is now: 0 1 2 3 4 5
print(v); // begin() is still 3, so prints: 3 4 5

// 也可能得到无效的值
std::vector vec{1, 2, 3, 4};
auto biggerThan2 = [](auto v){ return v > 2; };

auto vVec = vec | std::views::filter(biggerThan2);
print(vVec); // OK: 3 4

++vec[1];
vec[2] = 0; // vec becomes 1 3 0 4
print(vVec); // OOPS: 0 4;
```
`begin()` 缓存为一个迭代器，若向范围中添加或删除新元素，视图就不再对基础范围中的所有元素进行操作。 
### Views on Ranges That Change
对底层范围的进一步修改可能会以各种方式使视图无效：
- 缓存的 `begin()` 可能不再有效。
- 缓存的偏移量可能在基础范围的末尾之后。
- 符合谓词的新元素可能不会在以后的迭代中使用。
- 不适合的新元素可能会在后面的迭代中使用。
缓存 `begin()` 的视图若没有特别使用，并且底层范围发生变化，可能会遇到严重的问题：
```cpp
void print(auto&& coll)
{
    for (const auto& elem : coll) 
        std::cout << ' ' << elem;
    std::cout << '\n';
}

std::vector vec{1, 2, 3, 4, 5};
std::list lst{1, 2, 3, 4, 5};

auto over2 = [](auto v) { return v > 2; };
auto over2vec = vec | std::views::filter(over2);
auto over2lst = lst | std::views::filter(over2);

std::cout << "containers and elements over 2:\n";
print(vec); // OK: 1 2 3 4 5
print(lst); // OK: 1 2 3 4 5
print(over2vec); // OK: 3 4 5
print(over2lst); // OK: 3 4 5

// modify underlying ranges:
vec.insert(vec.begin(), {9, 0, -1});
lst.insert(lst.begin(), {9, 0, -1});

std::cout << "containers and elements over 2:\n";
print(vec); // vec now: 9 0 -1 1 2 3 4 5
print(lst); // lst now: 9 0 -1 1 2 3 4 5
print(over2vec); // OOPS: -1 3 4 5
print(over2lst); // OOPS: 3 4 5

// copying might eliminate caching:
auto over2vec2 = over2vec;
auto over2lst2 = over2lst;

std::cout << "elements over 2 after copying the view:\n";
print(over2vec2); // OOPS: -1 3 4 5
print(over2lst2); // OK: 9 3 4 5
```
第一次迭代中，两个视图都缓存视图的开头，但方式不同：
- 对于像 `vector` 这样的随机访问范围，视图将偏移量缓存到第一个元素，当再次使用视图时，使 `begin()` 失效的重新分配就不会导致未定义行为。
- 对于像 `list` 这样的其他范围，视图实际上会缓存调用 `begin()` 的结果。若缓存的元素被删除，则缓存的 `begin()` 不再有效，这可能是一个严重的问题。若前面插入新的元素，也会造成混乱。
此外，复制视图有时可能会使缓存无效，复制后，视图到 `vector` 的缓存偏移量仍然使用，但视图到 `list` 的缓存已经被移除，因缓存会视图的副本可能与其源的状态不同。由于这个原因，在复制视图之前应该三思而行，通常情况下会按引用传递视图。 
当使用过滤器视图时，写访问有一些重要的附加限制，由于过滤视图缓存，修改后的元素可能会通过过滤器，即使不应该通过。此外，必须确保修改后的值仍然满足传递给过滤器的谓词。否则，将得到未定义行为。
### Overloading For Views
```cpp
// 对于视图，可能只需要添加一个约束视图的函数，并按值接受参数就可以重载:
void print(const auto& rg); // for containers
void print(std::ranges::view auto rg) // for views

// 但当一次按值传递，一次按引用传递时，可能会导致歧义:
std::vector vec{1, 2, 3, 4, 5, 6, 7, 8, 9};
print(vec | std::views::take(3)); // ERROR: ambiguous

// 对于包含用于一般情况的概念的视图，使用概念也没有帮助:
void print(const std::ranges::range auto& rg); // for containers
void print(std::ranges::view auto rg) // for views

std::vector vec{1, 2, 3, 4, 5, 6, 7, 8, 9};
print(vec | std::views::take(3)); // ERROR: ambiguous

// 相反，必须声明 const& 重载不适用于视图:
template<std::ranges::input_range T> // for containers
requires (!std::ranges::view<T>) // and not for views
void print(const T& rg);

void print(std::ranges::view auto rg) // for views

std::vector vec{1, 2, 3, 4, 5, 6, 7, 8, 9};
print(vec | std::views::take(3)); // OK

// 但是复制视图可能会创建一个与源视图具有不同状态和行为的视图
// 所以按值传递视图是否是好的行为需要考虑
```
### Views with Write Access
视图不应该修改传递的参数或为其调用非 `const` 操作，视图及其副本对于相同的输入具有相同的行为。对于使用辅助函数检查或转换值的视图，这些辅助函数永远不应该修改元素。理想情况下，应该按值或按 `const` 引用取值。若修改作为非 `const` 引用传递的实参，就会有未定义行为:
```cpp
coll | std::views::transform([] (auto& val) { // better declare val as const&
    ++val; // ERROR: undefined behavior
})

coll | std::views::drop([] (auto& val) { // better declare val as const&
    return ++val > 0; // ERROR: undefined behavior
})
```
编译器不能检查辅助函数或谓词是否修改传递的值，因为不修改值只是语义约束。但是，支持使用视图来限制要修改的元素子集。例如:
```cpp
// assign 0 to all but the first five elements of coll:
for (auto& elem : coll | vws::drop(5)) {
    elem = 0;
}
```
### Sentinels
为了处理范围，必须引入一个新术语——哨兵，表示范围的结束。 哨兵是一个特殊的值，标志着结束或终止。在范围库中，哨兵定义范围的结束。在 `STL` 的传统方法中，哨兵将是 `end` 迭代器，通常与迭代集合的迭代器具有相同的类型。`end` 迭代器必须与定义范围的开始迭代器和用于遍历元素的迭代器具有相同的类型，这一要求导致了一些缺陷。
创建一个 `end` 迭代器可能很昂贵，若需要一个 end 迭代器来处理范围，首先必须遍历整个范围以找到其 `end`。而且有时，不可能迭代两次 (一次查找末尾，一次处理范围的元素)。这适用于使用纯输入迭代器的范围，例如使用从其读取的输入流作为范围。为了计算输入的末尾 `EOF`，必须读取输入，再次读取输入是不可能的，或者会产生不同的值。
因此 `C++20` 范围支持不同类型的哨兵，`end` 迭代器作为哨兵的泛化，`C++20` 前，也可以有这些类型的哨兵，但必须与迭代器具有相同的类型。通过放宽哨兵现在必须与迭代迭代器具有相同类型的要求，有几个好处：
- 可以在开始处理之前跳过寻找结尾的需要，同时处理值并在迭代时找到结束值。
- 对于 `end` 迭代器，可以使用禁用导致未定义行为的操作的类型。例如调用解引用操作符，因为末尾没有值。当尝试解引用 `end` 迭代器时，可以使用该特性在编译时发出错误信号。 
- 定义 `end` 迭代器变得更加容易。
```cpp
// 使用 auto 作为形参类型，就使成员函数具有泛型，可以与任意类型的对象 pos 进行比较
// 只将 == 操作符定义为泛型成员函数，尽管算法通常使用 != 操作符来比较迭代器和哨兵
// 但 C++20 现在可以用任意顺序的操作数将 != 映射到 == 操作符。
struct NullTerm {
    bool operator== (auto pos) const {
        return *pos == '\0'; // end is where iterator points to ’\0’
    }
};

const char* rawString = "hello world";

// 将 pos 初始化为一个迭代器，该迭代器遍历字符并使用 *pos 输出其值
// 当其与 NullTerm{} 的比较产生 pos 的值不等于’\0’ 时，循环运行
// 因此，NullTerm{} 就起到了哨兵的作用，其类型与 pos 不同
// 但支持与 pos 进行比较，从而检查 pos 所引用的当前值
for (auto pos = rawString; pos != NullTerm{}; ++pos) 
    std::cout << ' ' << *pos;
std::cout << '\n';

// C++20 为不再要求开始迭代器和哨兵具有相同类型的算法提供重载
// 但这些重载会在命名空间 std::ranges 中提供:
// call range algorithm with iterator and sentinel:
std::ranges::for_each(rawString, // begin of range
                      NullTerm{}, // end is null terminator
            [] (char c) { std::cout << ' ' << c; });
            std::cout << '\n';
}
```
若有两个不同类型的迭代器，则类型 `std::common_iterator` 为传统算法提供了一种协调方法，因 为数字算法、并行算法和容器仍然要求开始和结束迭代器具有相同的类型。
### Range Definitions with Sentinels and Counts
范围可以不仅仅是容器或一对迭代器，也可以通过以下方式定义：
- 同一类型的开始和结束迭代器
- 开始迭代器和哨兵(可能是不同类型的结束标记)
- 开始迭代器和 `count`
- 数组
为了定义迭代器和哨兵的范围，范围库提供 `std::ranges::subrange<>` 类型。子范围是泛型类型，可将迭代器和哨兵定义的范围转换为表示该范围的单个对象，所以子范围具有引用语义，并且复制成本很低。子范围并不总是通用范围，只产生传递定义范围的内容，对它们调用 `begin()` 和 `end()` 可能会产生不同的类型。
```cpp
struct NullTerm {
    bool operator== (auto pos) const {
        return *pos == '\0'; // end is where iterator points to ’\0’
    }
};

const char* rawString = "hello world";

// 定义一个范围对象，表示字符串的开始，哨兵作为字符串的结束:
std::ranges::subrange rawStringRange{ rawString, NullTerm{} };

// use the range in an algorithm:
std::ranges::for_each(rawStringRange, [](char c) { std::cout << ' ' << c; });

// 即使子范围不是公共范围，也可以将其传递给基于范围的 for 循环
// 基于范围的 for 循环接受开始迭代器和哨兵 (结束迭代器) 类型不同的范围
// range-based for loop also supports iterator/sentinel:
for (char c : rawStringRange) 
    std::cout << ' ' << c;
```
通过定义一个类模板，可以在其中指定范围结束的值，从而使这种方法更加通用：
```cpp
// 将 EndValue<> 定义为结束迭代器，检查作为模板形参传递的结束值
template<auto End>
struct EndValue {
    bool operator== (auto pos) const {
        return *pos == End; // end is where iterator points to End
    }
};

std::vector coll = {42, 8, 0, 15, 7, -1};

// EndValue<7>{} 创建一个 结束迭代器，其中 7 结束范围
std::ranges::subrange range{coll.begin(), EndValue<7>{}};

// sort the elements of this range:
std::ranges::sort(range);

// print the elements of the range:
std::ranges::for_each(range, [] (auto val) { std::cout << ' ' << val; });

// EndValue<-1>{} 创建一个结束迭代器，其中 -1 结束范围
std::ranges::for_each(coll.begin(), EndValue<-1>{},
    [] (auto val) {
        std::cout << ' ' << val;
    });
```
### Ranges of Begin and a Count
范围库提供多种处理定义为起始和计数的范围的方法，使用 `begin` 迭代器和计数创建范围的最方便方法，是使用范围适配器 `std::views::counted()`，创建一个指向 `begin` 迭代器/指针的前 `n` 个元素的低成本视图。
```cpp
std::vector<int> coll{1, 2, 3, 4, 5, 6, 7, 8, 9};
auto pos5 = std::ranges::find(coll, 5);

if (std::ranges::distance(pos5, coll.end()) >= 3) {
    for (int val : std::views::counted(pos5, 3)) 
        std::cout << val << ' ';
}
```
`std::views::counted(pos5, 3)` 创建了一个视图，该视图表示从 `pos5` 所引用的元素开始的三 个元素。`counted()` 不会检查是否存在元素，传递的计数过高会导致未定义行为，因此需要使用 `std::ranges::distance()`，检查是否有足够的元素，但如果集合没有随机访问迭代器，这种检查的开销可能会很大)。 
只有当确实有一个迭代器和一个计数时，才可以使用 `counted()`。若已经有一个范围， 并且只想处理前 `n` 个元素，请使用 `std::views::take()`。
### Projections
`sort()` 和许多其他用于范围的算法一样，通常有一个额外的可选模板参数：
```cpp
template<std::ranges::random_access_range R, 
typename Comp = std::ranges::less,
typename Proj = std::identity>
requires std::sortable<std::ranges::iterator_t<R>, Comp, Proj>
... sort(R&& r, Comp comp = {}, Proj proj = {});
```
可选的附加参数允许在算法进一步处理之前为每个元素指定一个转换/投影。 例如，`sort()` 允许指定要排序的元素的投影，按照投影进行排序：
```cpp
std::ranges::sort(coll, std::ranges::less{}, // still compare with <
    [] (auto val) { // but use the absolute value
        return std::abs(val);
    });

// This might be more readable or easier to program than:
std::ranges::sort(coll,
    [] (auto val1, auto val2) {
        return std::abs(val1) < std::abs(val2);
    });
```
默认的投影是 `std::identity()`，只产生传递给它的参数，因此根本不执行投影/转换，用户定义的投影只需要接受一个参数并为转换后的参数返回一个值。
### Utilities for Implementing Code for Ranges
为方便针对所有不同类型的范围进行编程，范围库提供了以下工具:
- 泛型函数，生成迭代器或范围的大小 
- 类型函数，生成迭代器的类型或元素的类型 
假设想要实现一个在一个范围内产生最大值的算法：
```cpp
template<std::ranges::input_range Range>
std::ranges::range_value_t<Range> maxValue(Range&& rg) {
    if (std::ranges::empty(rg)) 
        return std::ranges::range_value_t<Range>{};
    auto pos = std::ranges::begin(rg);
    auto max = *pos;

    while (++pos != std::ranges::end(rg)) 
        if (*pos > max) max = *pos;
    return max;
}
```
这里，使用几个标准实用程序来处理范围 `rg`：
- 概念 `std::ranges::input_range` 要求传递的参数是一个可以读取的范围 
- 类型函数 `std::ranges::range_value_t` 产生范围内相应类型的元素
- 辅助函数 `std::ranges::empty()` 判断产生范围是否为空
- 辅助函数 `std::ranges::begin()` 生成指向第一个元素的迭代器
- 辅助函数 `std::ranges::end()` 产生范围的哨兵
泛型 `maxValue()` 函数应该将传递的范围 `rg` 声明为通用引用，因为当一些轻量级范围(视图)是 `const` 时，将无法迭代它们。
### Limitations and Drawbacks of Ranges
`C++20` 中，范围也有一些主要的限制和缺点：
```cpp
// There is no ranges support for numeric algorithms yet. 
// To pass a range to a numeric algorithm, you have
// to pass begin() and end() explicitly:
std::ranges::accumulate(cont, 0L); // ERROR: not provided
std::accumulate(cont.begin(), cont.end(), 0L); // OK

// There is no support for ranges for parallel algorithms yet.
std::ranges::sort(std::execution::par, cont); // ERROR: not provided
std::sort(std::execution::par, cont.begin(), cont.end()); // OK
```
- 通过向视图传递 `begin()` 和 `end()` 来使用现有的并行算法时，应该谨慎。对于某些视图，并发迭代会导致未定义行为，只有在将视图声明为 `const` 之后才这样做。
- 一些由开始迭代器和结束迭代器定义的范围的传统 `api` 要求迭代器具有相同的类型 ，这适用于容器和命名空间 std 中的算法，可能需要与 `std::views::common()` 或 `std::common_iterator` 协调其类型。
- 对于某些视图，当视图为 `const` 时，不能遍历元素，所以泛型代码可能必须使用通用/转发引用。
- `cbegin()` 和 `cend()` 函数的设计目的是确保不会修改所遍历的元素，但对于引用非 `const` 对象的视图来说无效。
- 当视图引用容器时，可能会破坏 `const` 的传播。
- 范围会导致严重的命名空间混乱。
## Borrowed Iterators and Ranges
### Borrowed Iterators
许多算法返回迭代器操作的范围。然而，若传递一个临时范围并返回迭代器，当范围销毁时，返回的迭代器可能会在语句结束时失效。使用返回的迭代器或其副本会导致未定义行为。例如，考虑将一个临时范围传递给 `find()` 算法，该算法在一个范围中搜索一个值:
```cpp
std::vector<int> getData(); // forward declaration
auto pos = find(getData(), 42); // returns iterator to temporary vector
// temporary vector returned by getData() is destroyed here
std::cout << *pos;
```
`getData()` 的返回值在使用它的语句结束时销毁，所以 `pos` 指的是一个不再存在的集合元素，使用 `pos` 会导致未定义行为。 
为解决这个问题，范围标准库引入租借迭代器的概念。租借迭代器确保其生命周期不依赖于可能已销毁的临时对象。若存在，使用它会导致编译时错误。租借迭代器会发出信号，表明是否可以安全地超过所传递的范围，若该范围不是临时的，或者迭代器的状态不依赖于所传递范围的状态，就会出现这种情况。
若有一个租借迭代器来引用一个范围，则这个迭代器可以安全使用，即使在范围销毁时也不会悬空。使用类型 `std::ranges::borrowed_iterator_t<>`，算法可以将返回的迭代器声明为租借的，所以该算法会返回一个可以在语句后安全使用的迭代器。若为悬空，则使用一个特殊的返回值来发出信号， 并将可能的运行时错误转换为编译时错误。 
例如，单个范围的 `std::ranges::find()` 声明如下：
```cpp
template<std::ranges::input_range Rg,
typename T,
typename Proj = identity>
...
constexpr std::ranges::borrowed_iterator_t<Rg>
find(Rg&& r, const T& value, Proj proj = {});
```
通过将返回类型指定为 `Rg` 的 `std::ranges::borrow_iterator_t<>`，该标准启用编译时检查: 若传递给算法的范围 `R` 是右值，则返回类型变为悬空迭代器。此时返回值是 `std::ranges::dangling` 类型的对象，对此类对象的使用(复制和赋值除外)都会导致编译时错误。 
下面的代码会出现编译时错误：
```cpp
std::vector<int> getData(); // forward declaration
auto pos = std::ranges::find(getData(), 42); // returns iterator to temporary vector
// temporary vector returned by getData() was destroyed
std::cout << *pos;
```
为能够为临时对象使用 `find()`，必须将其作为左值传递，所以其必须有一个名字，为返回集合指定名称的最佳方法是将其绑定到引用，集合就永远不会复制，根据规则，临时对象的引用总是会延长其生命周期：
```cpp
std::vector<int> getData(); // forward declaration
reference data = getData(); // give return value a name to use it as an lvalue
// lifetime of returned temporary vector ends now with destruction of data
...
```
可以在这里使用左值引用：
```cpp
std::vector<int> getData(); // forward declaration
const auto& data = getData(); // give return value a name to use it as an lvalue
auto pos = std::ranges::find(data, 42); // yields no dangling iterator
if (pos != data.end()) std::cout << *pos; // OK
```
这个引用使返回值为 `const`，这可能不是期望的，因此当某些视图是 `const` 时，不能进行迭代，但由于视图的引用语义，在返回时必须非常谨慎。
更泛型的代码中，应该使用通用引用或 `decltype(auto)`，以便保持返回值的 `non-const`：
```cpp
... getData(); // forward declaration
auto&& data = getData(); // give return value a name to use it as an lvalue
auto pos = std::ranges::find(data, 42); // yields no dangling iterator
if (pos != data.end()) 
std::cout << *pos; // OK
```
租借迭代器的副作用是，即使结果代码有效，也不能将临时对象传递给算法：
```cpp
process(std::ranges::find(getData(), 42)); // compile-time ERROR
```
`find()` 返回一个 `std::ranges::dangling` 对象会导致编译错误，尽管迭代器在函数调用期间是有效的(因为临时 `vector` 将在调用后才销毁)。
同样，处理此问题的最佳方法是声明 `getData()` 返回值的引用:
```cpp
const auto& data = getData(); // give return value a name to use it as an lvalue
process(std::ranges::find(data, 42)); // passes a valid iterator to process()

auto&& data = getData(); // give return value a name to use it as an lvalue
auto pos = std::ranges::find(data, 42); // yields a valid iterator
```
通常情况下，需要一个返回值的名称来检查返回值是否指向一个元素：
```cpp
auto&& data = getData(); // give return value a name to use it as an lvalue
auto pos = std::ranges::find(data, 42); // yields a valid iterator
if (pos != data.end()) std::cout << *pos; // OK
```
### Borrowed Ranges
范围类型可以声明为租借范围，当范围本身不再存在时，迭代器仍可以使用。`C++20` 为此提供 `std::ranges::borrowed_range` 的概念，若范围类型的迭代器从不依赖于其范围的生存期，或者传递的范围对象为左值，则满足此概念，该概念检查该范围创建的迭代器在该范围不存在后是否可以使用，而作为临时对象传递的容器和作为右值传递的范围的视图都不是租借范围。但有两种方法让这样的视图成为租借范围：
- 迭代器存储所有用于本地迭代的信息。例如，`std::ranges::iota_view` 生成一个递增的值序列，迭代器在本地存储当前值，并且不引用任何其他对象。`std::ranges::empty_view` 任何迭代器总是在末尾，因此其根本不能迭代元素值。
- 迭代器直接引用底层范围，而不使用调用 `begin()` 和 `end()` 的视图。例如，`std::ranges::subrange`、`std::ranges::ref_view`、`std::span`、`std::string_view`。当租借迭代器引用底层范围，并且底层范围不再存在时，仍然会悬空。
```cpp
std::vector coll{0, 8, 15};

// find 需要一个范围，这个范围必须是租借范围
auto pos0 = std::ranges::find(coll, 8); // borrowed range
std::cout << *pos0; // OK (undefined behavior if no 8)

// 传递的 std::vector{8} 是临时对象
auto pos1 = std::ranges::find(std::vector{0, 8, 15}, 8); // yields dangling
std::cout << *pos1; // compile-time ERROR

// For temporary views the situation depends. 
// 传递的范围是右值
auto pos2 = std::ranges::find(std::views::single(0, 8, 15), 8); // yields dangling
std::cout << *pos2; // compile-time ERROR

// 尽管传递的范围是右值，但 iota 存储副本
auto pos3 = std::ranges::find(std::views::iota(0, 8, 15), 8); // borrowed range
std::cout << *pos3; // OK (undefined behavior if no 8 found)

auto pos4 = std::ranges::find(std::views::empty<int>, 8); // borrowed range
std::cout << *pos4; // undefined behavior as no 8 found

auto pos5 = std::ranges::find(std::views::take(std::vector{0, 8, 15}, 2), 8);

auto pos6 = std::ranges::find(
    std::views::counted(std::vector{0, 8, 15}.begin(), 2), 8);
std::cout << *pos6; // runtime ERROR even if 8 found
```
单视图迭代器是作为右值传递的范围的视图，其中的引用无效，因此单视图不是租借范围。另一方面，`iota` 视图迭代器保存元素的副本，所以 `iota` 视图会声明为租借范围，此外，适配器 `std::views::take()` 也会检查右值。
## Views and Const
在使用视图以及一般的范围库时，有一些关于常量性的事情令人惊讶，甚至是不正常的。 
- 对于某些视图，当视图为 `const` 时，不可能遍历元素。
- 视图消除了对元素常量性的传播。
- 像 `cbegin()` 和 `cend()` 这样的函数的目标是确保元素在迭代时为 `const`，但要么没有提供，要么已破坏。 
### Generic Code for Both Containers and Views
实现一个可以遍历每种类型的容器和视图的元素，并具有良好性能的泛型函数是非常复杂的。像下面这样声明一个打印所有元素的函数并不总有效：
```cpp
void print(const auto& rg) // OOPS: might not work for some views
{
    for (const auto& elem : rg) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

std::vector vec{1, 2, 3, 4, 5, 6, 7, 8, 9};
std::list lst{1, 2, 3, 4, 5, 6, 7, 8, 9};

// 将 vector 传递给 take 视图和 drop 视图的效果很好:
print(vec | std::views::take(3)); // OK
print(vec | std::views::drop(3)); // OK
print(lst | std::views::take(3)); // OK

// 将 drop 视图传递给 list 无法编译:
print(lst | std::views::drop(3)); // ERROR

// 然而，直接迭代 drop 视图却运行良好:
for (const auto& elem : lst | std::views::drop(3))  // OK
    std::cout << elem << ' ';

// 对 vector 传递一个过滤器视图会得到所有范围的错误:
auto isEven = [] (const auto& val) {
    return val % 2 == 0;
};
print(vec | std::views::filter(isEven)); // ERROR
```
这是因为 `const&` 并不适用于所有视图，当视图为 `const` 时，视图并不总是支持遍历元素。因为迭代这些视图的元素有时需要能够修改视图的状态，例如缓存。对于某些视图如过滤器视图永远不会工作，对于某些视图如 `drop` 视图，只是有时会起作用。 
若用 `const` 声明以下标准视图中的元素，则不能迭代：`Filter view`、`Drop-while view`、`Split view`、`IStream view`。
只能偶尔迭代的 `const` 视图：
- `Drop view`：若引用的范围没有随机访问或没有 `size()`
- `Reverse view`：若引用的范围对于开始迭代器和哨兵具有不同的类型
- `Join view`：若引用的范围生成值而不是引用
对于这些视图，`begin()` 和 `end()` 作为 `const` 成员函数只能有条件地提供，或者根本不提供。对 丢弃视图，只有当传递的范围满足随机访问范围和大小范围的要求时，才会提供 `const` 对象的 `begin()`，在实现中使用概念进行约束。因此若将形参声明为 `const` 引用，则无法提供可以处理所有范围和视图元素的泛型函数。
非 `const&&` 对所有视图都有效，为了在泛型代码中支持这些视图，应该将范围参数声明为通用引用。这些引用适用于所有表达式，同时保留引用对象不是 `const` 的事实。例如：
```cpp
// 是否对范围参数的类型有约束并不重要:
void print(std::ranges::input_range auto&& coll); // can in principle pass all views

template<std::ranges::random_access_range T>
void foo(T&& coll); // can in principle pass all views

void print(auto&& rg) {
    for (const auto& elem : rg) 
        std::cout << elem << ' ';
    std::cout << '\n';
}

std::vector vec{1, 2, 3, 4, 5, 6, 7, 8, 9};
std::list lst{1, 2, 3, 4, 5, 6, 7, 8, 9};

print(vec | std::views::take(3)); // OK
print(vec | std::views::drop(3)); // OK
print(lst | std::views::take(3)); // OK
print(lst | std::views::drop(3)); // OK

for (const auto& elem : lst | std::views::drop(3)) std::cout << elem << ' ';

auto isEven = [] (const auto& val) {
    return val % 2 == 0;
};
print(vec | std::views::filter(isEven)); // OK
```
`C++20` 起，不再有一种方法可以声明一个泛型函数来接受所有标准集合类型(const 和非 const 容器和视图)，并保证不修改元素。
所能做的就是获取范围/视图，并确保不在函数体中实现中修改元素，但这样做可能会很复杂，因为：
- 将视图声明为 `const` 并不一定使元素成为 `const`。
- 视图没有 `const_iterator` 成员。
- 视图目前还不提供 `cbegin()` 和 `cend()` 成员。
- `std::ranges::cbegin()` 和 `std::cbegin()` 对于视图是无效的。
- 将视图元素声明为 `const` 可能没有效果。
关于使用通用引用的建议，有一个重要的限制：当同时遍历视图时不应该使用，对并发迭代应该使用 `const&`。
```cpp
std::list<int> lst{1, 2, 3, 4, 5, 6, 7, 8};
auto v = lst | std::views::drop(2);
// while another thread prints the elements of the view:
std::jthread printThread{[&] {
    for (auto&& elem : v) 
        std::cout << elem << '\n';
}};

// this thread computes the sum of the element values:
auto sum = std::accumulate(v.begin(), v.end(), // fatal runtime ERROR
0L);
```
使用 `std::jthread` 启动一个线程，该线程遍历视图 `v` 的元素并进行输出，之后遍历 `v` 来计算元素值的和。对于标准容器，只进行读操作的并行迭代是安全的，这是对于容器的保证，其将会调用 `begin()` 可以作为读访问计数，但此保证不适用于标准视图。
因为可能会并发地为视图 `v` 调用 `begin()`，所以这段代码会导致未定义行为 (可能的数据竞争)。执行只读并发迭代的函数应该使用 `const` 视图，将可能的运行时错误转换为编译时错误：
```cpp
const auto v = lst | std::views::drop(2);
std::jthread printThread{[&] {
    for (const auto& elem : v) // compile-time ERROR
        std::cout << elem << '\n';
}};
auto sum = std::accumulate(v.begin(), v.end(), // compile-time ERROR
0L);
```
### Views May Remove the Propagation of const
容器具有值语义并拥有自己的元素，所以可将任何常量性传播给其元素。当容器为 `const` 类型时，其元素也是 `const` 类型，所以以下代码无法编译:
```cpp
template<typename T>
void modifyConstRange(const T& range) { // 非 const 容器会转化为 const 容器
    range.front() += 1; // modify an element of a const range
}

std::array<int, 10> coll{}; // array of 10 ints with value 0
...
modifyConstRange(coll); // compile-time ERROR: elements are const

// 可以使用范围适配器 std::views::all() 将非 const 容器变为视图
// 从而传递给接受范围作为 const 引用的泛型函数，使得容器中的元素可以修改
// 但如果是 const 容器，这种办法没有效果
modifyConstRange(std::views::all(coll)); // OK, elements of coll are not const
```
对视图来说，作为左值传递的范围的视图具有引用语义，引用存储在其中的元素，这些视图不会将常量性传播到其元素上。
```cpp
std::array<int, 10> coll{}; // array of 10 ints with value 0
...
std::ranges::take_view v{coll, 5}; // view to first five elements of coll
modifyConstRange(v); // OK, modifies the first element of coll

// 这适用于所有作为左值传递的范围的视图
modifyConstRange(coll | std::views::drop(5)); // OK, elements of coll are not const
modifyConstRange(coll | std::views::take(5)); // OK, elements of coll are not const

// 对右值的视图(如果它们是有效的)通常仍然传播常量性:
readConstRange(getColl() | std::views::drop(5)); // compile-time ERROR (good)
readConstRange(getColl() | std::views::take(5)); // compile-time ERROR (good)

// 因此，通过在视图引用容器之前将容器设置为 const
// 可以确保容器的元素不会接受该视图的函数修改:
std::array<int, 10> coll{}; // array of 10 ints with value 0
// std::as_const 只有在创建视图时使用才有效，使 coll 具有 const
std::ranges::take_view v{std::as_const(coll), 5}; // view to five elems of const coll
modifyConstRange(v); // compile-time ERROR
modifyConstRange(std::as_const(coll) | std::views::take(5)); // compile-time ERROR
```
依然不能使用视图修改 `const` 容器的元素，`const` 容器会传播 `const`：
```cpp
const std::array<int, 10> coll{}; // array of 10 ints with value 0
auto v = std::views::take(coll, 5); // view to first five elements of coll
modifyConstRange(v); // compile-time ERROR (good)
```
`C++23` 引入一个带有范围适配器 `std::views::as_const()` 的辅助视图 `std::ranges::as_const_view` 可以简单地将视图的元素设置为 `const`，如下所示：
```cpp
std::views::as_const(v); // make elements of view v const
// 与 std::as_const 区别在于命名空间
```
命名空间 `std` 和命名空间 `std::ranges` 中的函数 `as_const()` 都使某些东西成为 `const`，但前者使对象成为 `const`，而后者使元素成为 `const`。
为什么使用引用语义的视图没有被设计成传播常量的方式。一个论点是在内部使用指针，因此应该表现得像指针。然而，右值的视图不是这样工作的。另一种说法是，`const` 几乎没什么作用，其可以很容易地通过将视图复制到非 `const` 视图来删除:
```cpp
void foo(const auto& rg) { // if rg would propagate constness for views on lvalues
    auto rg2 = rg; // rg2 would no longer propagate constness
    ...
}
```
初始化的行为类似于 `const_cast<>`，但若这是容器的泛型代码，开发者已经习惯不按值传递，这样做的代价很高。
### Bringing Back Deep Constness to Views
对作为视图的范围使用 `const` 是一个问题，原因有两个：
- `const` 可以禁用元素的迭代
- `const` 可能不会传播到视图的元素 
问题是如何确保代码在使用视图时不能修改范围的元素，视图库的设计者计划禁用某些视图声明元素 `const` 的效果，使用 `C++` 标准视图时，将集合或其元素设置为 `const` 可能不起作用。
通常将容器的所有元素都设置为 `const` 的方法不适用于视图：
```cpp
// 通常，视图不提供 const_iterator 来执行以下操作:
for (decltype(rg)::const_iterator pos = rg.begin(); // not for views
    pos != range.end(); ++pos) {
        elemfunc(*pos);
}

// 因此，也不能简单地将整个范围转换为:
std::ranges::subrange<decltype(rg)::const_iterator> crg{rg}; // not for views

// 通常，视图没有成员函数 cbegin() 和 cend() 来执行以下操作:
callTraditionalAlgo(rg.cbegin(), rg.cend()); // not for views
```
从 `C++11` 开始提供的 `std::cbegin()` 和 `std::cend()`引入目的为确保元素在迭代时是 `const` 的，但 `std::cbegin()` 和 `std::cend()` 对于视图来说是无效的。还要注意，在使用这些辅助函数时，`ADL` 存在一些问题。`C++20` 在命名空间 `std::ranges` 中引入 `range` 库的相应帮助函数，但 `C++20` 中的视图中破坏了 `std::ranges::cbegin()` 和 `std::ranges::cend()`，这将在 `C++23` 中修复
```cpp
for (auto pos = std::cbegin(range); pos != std::cend(range); ++pos) {
    elemfunc(*pos); // does not provide constness for values of views
}

for (auto pos = std::ranges::cbegin(rg); pos != std::ranges::cend(rg); ++pos) {
    elemfunc(*pos); // OOPS: Does not provide constness for the values in C++20
}
```
因此，`C++20` 中，当使视图的所有元素都为 `const` 时，还会遇到另一个严重的问题，在泛型代码中使用 `cbegin()`，`cend()`，`cdata()` 时要谨慎，这些函数在某些视图中不可用或已破坏。
综上，确保视图中的元素不能修改的方法是，对元素或容器(容器会传播常量性)强制使用 `const`:
```cpp
// Either by using const in the range-based for loop:
for (const auto& elem : rg) {...}

// 将传递的元素变为 const
for (auto pos = rg.begin(); pos != rg.end(); ++pos) {
    elemfunc(std::as_const(*pos));
}

// 使用 Cpp23 引入的 std::views::as_const 在泛型函数内部，将元素变为 const
void print(auto&& rgPassed) {
    auto rg = std::views::as_const(rgPassed); // ensure all elements are const
    ... // use rg instead of rgPassed now
}

// As another approach, you can do the following:10
void print(R&& rg) {
    if constexpr (std::ranges::const_range<R>) {
        // the passed range and its elements are constant
        ...
    }
    else {
        // call this function again after making view and elements const:
        print(std::views::as_const(std::forward<R>(rg)));
    }
}
```
`C++23` 仍然没有提供一种通用的方法来声明容器和视图的引用形参，以保证内部元素是 `const`，无法声明在其签名中保证不修改元素的函数。
## Summary of All Container Idioms Broken By Views
使用容器时可以依赖的一些习惯用法会被视图打破。这里有一个总结，当在容器和视图中使用泛型代码时，应该考虑到：
- 当标准视图为 `const` 时，可能无法遍历其元素。因此，所有类型范围(容器和视图)的泛型代码必须将参数声明为通用引用。但当有并发迭代时，不要使用通用/转发引用，而是使用 const。
- 左值范围的标准视图不传播常量，将这样的视图声明为 `const` 并没有将元素声明为 `const`。
- 标准视图上的并发迭代可能导致数据竞争，即使它们只读取。
- 读取迭代可能会影响以后的功能行为，甚至使以后的迭代无效。 
- 复制视图可能会创建一个与源视图具有不同状态和行为的视图。 
- 没有 `cbegin()` 和 `cend()` 成员函数。
- 类型 `const_iterator` 通常不可用。
对于某些标准视图，将元素声明为 `const` 可能没有影响，可能能够修改视图的 `const` 元素的成员。所以标准视图并不总是一个限制或处理范围元素的纯子集，其可能提供在使用整个范围时不允许的选项和操作。因此，要特别小心地使用视图，不要考虑任何临时的常量。最好避免使用标准视图，而使用具有更安全设计的视图。



```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```
