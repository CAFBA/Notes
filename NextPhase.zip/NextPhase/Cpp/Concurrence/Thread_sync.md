# 线程同步

线程同步的四项原则，按重要性排列：

- 首要原则是尽量最低限度地共享对象，减少需要同步的场合。一个对象能不暴露给别的线程就不要暴露；如果要暴露，优先考虑immutable对象；实在不行才暴露可修改的对象，并用同步措施来充分保护它。
- 其次是使用高级的并发编程构件，如TaskQueue、Producer-Consumer Queue、CountDownLatch等等。
- 最后不得已必须使用底层同步原语（primitives）时，只用非递归的互斥器和条件变量，慎用读写锁，不要用信号量。
- 除了使用atomic整数之外，不自己编写lock-free代码，也不要用“内核级”同步原语。

## mutex

互斥器保护了临界区，任何一个时刻最多只能有一个线程在此mutex划出的临界区内活动。单独使用mutex时，主要为了保护共享数据。我个人的原则是：

- 用RAII手法封装mutex的创建、销毁、加锁、解锁这四个操作。
- 只用非递归的mutex（即不可重入的mutex）。
- 不手工调用lock()和unlock()函数，一切交给栈上的Guard对象的构造和析构函数负责。Guard对象的生命期正好等于临界区。这样保证始终在同一个函数同一个scope里对某个mutex加锁和解锁。避免在foo()里加锁，然后跑到bar()里解锁；也避免在不同的语句分支中分别加锁、解锁。这种做法被称为Scoped Locking。
- 在每次构造Guard对象的时候，思考一路上（调用栈上）已经持有的锁，防止因加锁顺序不同而导致死锁。由于Guard对象是栈上对象，看函数调用栈就能分析用锁的情况，非常便利。

次要原则有：

- 不使用跨进程的mutex，进程间通信只用TCP sockets。
- 加锁、解锁在同一个线程，线程a不能去unlock线程b已经锁住的mutex，别忘了解锁，不重复解锁（均由RAII自动保证）。
- 必要的时候可以考虑用PTHREAD_MUTEX_ERRORCHECK来排错。

### post/traverse

mutex分为递归（recursive）和非递归（non-recursive）两种，这是POSIX的叫法，另外的名字是可重入（reentrant）与非可重入。这两种mutex作为线程间（inter-thread）的同步工具时没有区别，它们的唯一区别在于：同一个线程可以重复对recursive mutex加锁，但是不能重复对non-recursive mutex加锁。

首选非递归mutex，绝对不是为了性能，而是为了体现设计意图。non-recursive和recursive的性能差别其实不大，因为少用一个计数器，前者略快一点点而已。在同一个线程里多次对non-recursive mutex加锁会立刻导致死锁，我认为这是它的优点，能帮助我们思考代码对锁的期求，并且及早（在编码阶段）发现问题。

毫无疑问recursive mutex使用起来要方便一些，因为不用考虑一个线程会自己把自己给锁死了，正因为它方便，recursive mutex可能会隐藏代码里的一些问题。典型情况是你以为拿到一个锁就能修改对象了，没想到外层代码已经拿到了锁，正在修改（或读取）同一个对象呢。来看一个具体的例子

![image-20230405181732994](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405181732994.png)

post()加锁，然后修改foos对象；traverse()加锁，然后遍历foos向量。这些都是正确的。将来有一天，Foo::doit()间接调用了post()，那么会很有戏剧性的结果：

- mutex是非递归的，于是死锁了。
- mutex是递归的，由于push_back()可能扩容（但不总是）导致vector迭代器失效，程序偶尔会crash。

这时候就能体现**non-recursive的优越性：把程序的逻辑错误暴露出来**。死锁比较容易debug，把各个线程的调用栈打出来，只要每个函数不是特别长，很容易看出来是怎么死的。或者可以用PTHREAD_MUTEX_ERRORCHECK一下子就能找到错误（前提是MutexLock带debug选项）。

> 如果确实需要在遍历的时候修改vector，有两种做法，一是把修改推后，记住循环中试图添加或删除哪些元素，等循环结束了再依记录修改foos；二是用copy-on-write。

如果一个函数既可能**在已加锁的情况下调用，又可能在未加锁的情况下调用**，那么就拆成两个函数：

- 跟原来的函数同名，函数加锁，转而调用第2个函数。即该函数用于没有持有锁的情况下调用。

- 给函数名加上后缀WithLockHold，不加锁，把原来的函数体搬过来。即该函数用于持有锁的情况下调用。

![image-20230405181954121](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405181954121.png)

### Inventory/Request 

有一个Inventory（清单）class，记录当前的Request对象。容易看出，下面这个Inventory class的add()和remove()成员函数都是线程安全的，它使用了mutex来保护共享数据requests_。

![image-20230405182639994](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405182639994.png)

Request class与Inventory class的交互逻辑很简单，在处理（process）请求的时候，往g_inventory中添加自己。在析构的时候，从g_inventory中移除自己。目前看来，整个程序还是线程安全的。

![image-20230405182645590](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405182645590.png)

Inventory class 还有一个功能是打印全部已知的Request对象。Inventory::printAll()里的逻辑单独看是没问题的，但是它有可能引发死锁。

![image-20230405182656212](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405182656212.png)

通过gdb查看两个线程的函数调用栈，我们发现两个线程都等在mutex上（__lll_lock_wait），估计是发生了死锁。因为一个程序中的线程一般只会等在condition variable上，或者等在epoll_wait上。

![image-20230405182803164](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405182803164.png)

注意到main()线程是先调用Inventory::printAll(#6)（锁住Inventory的锁）再调用Request::print(#5)（锁住Request的锁），而threadFunc()线程是先调用Request::～Request(#6)（锁住Request的锁）再调用Inventory::remove(#5)（锁住Inventory的锁）。

这两个调用序列对两个mutex的加锁顺序正好相反，于是造成了经典的死锁。一旦main()线程中的printAll()在另一个线程的～Request()和remove()之间开始执行，死锁已不可避免。

解决死锁的办法很简单，要么把print()移出printAll()的临界区，这可以用 copy-on-write 的办法；要么把remove()移出～Request()的临界区，比如交换L13和L15两行代码的位置。

这里也出现了对象析构的race condition，即一个线程正在析构对象，另一个线程却在调用它的成员函数。

> 思考：Inventory::printAll→Request::print有没有可能与Request::process→Inventory::add发生死锁？会
>
> 考：如果printAll()晚于remove()执行，还会出现死锁吗？不会

## condition variable

互斥器（mutex）是加锁原语，用来排他性地访问共享数据，它不是等待原语。在使用mutex的时候，一般都会期望加锁不要阻塞，总是能立刻拿到锁。然后尽快访问数据，用完之后尽快解锁，这样才能不影响并发性和性能。

如果需要等待某个条件成立，应该使用条件变量。条件变量顾名思义是一个或多个线程等待某个布尔表达式为真，即等待别的线程“唤醒”它。条件变量的学名叫管程（monitor）。条件变量只有一种正确使用的方式，几乎不可能用错。

对于wait端：

- 必须与mutex一起使用，该布尔表达式的读写需受此mutex保护。
- 在mutex已上锁的时候才能调用wait()。
- 把判断布尔条件和wait()放到while循环中。

![image-20230405215517360](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405215517360.png)

对于signal/broadcast端：

- 不一定要在mutex已上锁的情况下调用signal（理论上）。
- 在signal之前一般要修改布尔表达式。
- 修改布尔表达式通常要用mutex保护（至少用作full memory barrier）。
- 注意区分signal与broadcast：“broadcast通常用于表明状态变化，signal通常用于表示资源可用。

![image-20230405215617530](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405215617530.png)

> enqueue()中每次添加元素都会调用Condition::notify()，如果改成只在queue.size()从0变1的时候才调用Condition::notify()，会出现什么后果？

倒计时（CountDownLatch）是一种常用且易用的同步手段。它主要有两种用途：

- 主线程发起多个子线程，等这些子线程各自都完成一定的任务之后，主线程才继续执行。通常用于主线程等待多个子线程完成初始化。
- 主线程发起多个子线程，子线程都等待主线程，主线程完成其他一些任务之后通知所有子线程开始执行。通常用于多个子线程等待主线程发出“起跑”命令。

CountDownLatch的接口很简单：

![image-20230405220125668](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405220125668.png)

![image-20230405220132451](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405220132451.png)

> 注意到CountDownLatch::countDown()使用的是Condition::notifyAll()，而前面的enqueue()使用的是Condition::notify()，这都是有意为之。请读者思考，如果交换两种用法会出现什么情况？

互斥器和条件变量构成了多线程编程的全部必备同步原语，用它们即可完成任何多线程同步任务，二者不能相互替代。

下面这个muduo::Condition class简单地封装了Pthreads condition variable，用起来也容易：

![image-20230405220932377](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405220932377.png)

## rwlock

Readers-Writer lock，是个看上去很美的抽象，它明确区分了read和write两种行为。

初学者常干的一件事情是，一见到某个共享数据结构频繁读而很少写，就把mutex替换为rwlock。甚至首选rwlock来保护共享状态，这不见得是正确的

- 从正确性方面来说，一种典型的易犯错误是在持有read lock的时候修改了共享数据。这通常发生在程序的维护阶段，为了新增功能，程序员不小心在原来read lock保护的函数中调用了会修改状态的函数。这种错误的后果跟无保护并发读写共享数据是一样的。
- 从性能方面来说，读写锁不见得比普通mutex更高效。无论如何reader lock加锁的开销不会比mutex lock小，因为它要更新当前reader的数目。如果临界区很小，锁竞争不激烈，那么mutex往往会更快。
- reader lock可能允许提升（upgrade）为writer lock，也可能不允许提升。考虑post()和traverse()示例，如果用读写锁来保护foos对象，那么post()应该持有写锁，而traverse()应该持有读锁。如果允许把读锁提升为写锁，后果跟使用recursive mutex一样，会造成迭代器失效，程序崩溃。如果不允许提升，后果跟使用non-recursive mutex一样，会造成死锁。
- 通常reader lock是可重入的，writer lock是不可重入的。但是为了防止writer饥饿，writer lock通常会阻塞后来的reader lock，因此reader lock在重入的时候可能死锁。

## Semaphore

信号量不是必备的同步原语，因为条件变量配合互斥器可以完全替代其功能，而且更不易用错。除了[RWC]指出的“semaphore has no notion of ownership”之外，信号量的另一个问题在于它有自己的计数值，而通常自己的数据结构也有长度值，这就造成了同样的信息存了两份，需要时刻保持一致，这增加了程序员的负担和出错的可能。如果要控制并发度，可以考虑用muduo::ThreadPool。

说一句不知天高地厚的话，如果程序里需要解决如“哲学家就餐”之类的复杂IPC问题，我认为应该首先检讨这个设计：为什么线程之间会有如此复杂的资源争抢（一个线程要同时抢到两个资源，一个资源可以被两个线程争夺）？如果在工作中遇到，我会把“想吃饭”这个事情专门交给一个为各位哲学家分派餐具的线程来做，然后每个哲学家等在一个简单的condition variable上，到时间了有人通知他去吃饭。从哲学上说，教科书上的解决方案是平权，每个哲学家有自己的线程，自己去拿筷子；我宁愿用集权的方式，用一个线程专门管餐具的分配，让其他哲学家线程拿个号等在食堂门口好了。这样不损失多少效率，却让程序简单很多。

## sleep(3)不是同步原语

sleep()/usleep()/nanosleep()只能出现在测试代码中，比如写单元测试的时候；或者用于有意延长临界区，加速复现死锁的情况。sleep不具备memory barrier语义，它不能保证内存的可见性。

生产代码中线程的等待可分为两种：一种是**等待资源可用**（要么等在select/poll/epoll_wait上，要么等在条件变量上）；一种是等着进入临界区（等在mutex上）以便读写共享数据。后一种等待通常极短，否则程序性能和伸缩性就会有问题。

在程序的正常执行中，如果需要等待一段已知的时间，应该往event loop里注册一个timer，然后在timer的回调函数里接着干活，因为线程是个珍贵的共享资源，不能轻易浪费（阻塞也是浪费）。如果等待某个事件发生，那么应该采用条件变量或IO事件回调，不能用sleep来轮询。不要使用下面这种业余做法：

```c
while (true) {
    if (!dataAvailable) sleep(some_time);
    else consumeDate();
}
```

如果多线程的安全性和效率要靠代码主动调用sleep来保证，这显然是设计出了问题。等待某个事件发生，正确的做法是用select()等价物或Condition，抑或（更理想地）高层同步工具；在用户态做轮询（polling）是低效的。

## copy-on-write

解决办法都基于同一个思路，那就是用shared_ptr来管理共享数据。原理如下：

- shared_ptr是引用计数型智能指针，如果当前只有一个观察者，那么引用计数的值为1。

- 对于write端，如果发现引用计数为1，这时可以安全地修改共享对象，不必担心有人正在读它。

	如果发现引用计数大于1，说明这时别的线程正在读取，不能原地修改，而是复制一份。

- 对于read端，在读之前把引用计数加1，读完之后减1，这样保证在读的期间其引用计数大于1，可以阻止并发写。

### post()和traverse()死锁

post()和traverse()死锁。数据结构改成：

![image-20230405221810415](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405221810415.png)

在read端，用一个栈上局部FooListPtr变量当做“观察者”，它使得g_foos的引用计数增加(L6)。traverse()函数的临界区是L4～L8，临界区内只读了一次共享变量g_foos，使得引用计数加1（这里多线程并发读写shared_ptr，因此必须用mutex保护），在读之后自动析构 foos，引用计数减1。而且多个线程同时调用traverse()也不会相互阻塞。

![image-20230405221822143](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405221822143.png)

关键看write端的post()该如何写。按照前面的描述，如果g_foos.unique()为true，可以放心地在原地（in-place）修改FooList。如果g_foos.unique()为false，说明这时别的线程正在读取FooList，不能原地修改，而是复制一份（L23），在副本上修改（L27）。这样就避免了死锁。

注意这里临界区包括整个函数（L20～L27），其他写法都是错的。

![image-20230405221831332](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405221831332.png)

假设现在在 traverse 中调用的 doit 间接调用 post，由于 traverse 改用引用计数管理共享数据，因此不会死锁，而是采用 copy-on-write。

### 把Request::print()移出Inventory::printAll()临界区

解把Request::print()移出Inventory::printAll()临界区有两个做法。其一很简单，把requests_复制一份，在临界区之外遍历这个副本。

![image-20230405221937666](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405221937666.png)

这么做有一个明显的缺点，它复制了整个std::set中的每个元素，开销可能会比较大。如果遍历期间没有其他人修改requests_，那么可以减小开销，这就引出了第二种做法。

第二种做法的要点是用shared_ptr管理std::set，在遍历的时候先增加引用计数，阻止并发修改。当然Inventory::add()和Inventory::remove()也要相应修改，采用post()和traverse()的方案。

```c
typedef std::set<Request*> RequestList;
typedef boost::shared_ptr<RequestList> RequestListPtr;

RequestListPtr getData() const
{
    muduo::MutexLockGuard lock(mutex_);
    return requests_;
}

mutable muduo::MutexLock mutex_;
RequestListPtr requests_;

void add(Request* req)
{
    muduo::MutexLockGuard lock(mutex_);
    if (!requests_.unique())
    {
        requests_.reset(new RequestList(*requests_));
        printf("Inventory::add() copy the whole list\n");
    }
    assert(requests_.unique());
    requests_->insert(req);
}

void remove(Request* req) // __attribute__ ((noinline))
{
    muduo::MutexLockGuard lock(mutex_);
    if (!requests_.unique())
    {
        requests_.reset(new RequestList(*requests_));
        printf("Inventory::remove() copy the whole list\n");
    }
    assert(requests_.unique());
    requests_->erase(req);
}

void Inventory::printAll() const
{
  RequestListPtr requests = getData(); // 引用计数加1
  sleep(1);
  for (std::set<Request*>::const_iterator it = requests->begin();
      it != requests->end();
      ++it)
  {
    (*it)->print();
  }
}
```

### 解决Request对象析构的race condition

因此参照前述 Observe，不在析构函数中执行清理工作，而是将析构函数中的 Remove 移动到其他函数中，使用 shared_from_this 保证执行期间对象存活。

```c++
// 解决前
~Request() __attribute__ ((noinline))
{
    muduo::MutexLockGuard lock(mutex_);
    x_ = -1;
    sleep(1);
    g_inventory.remove(this);
}

void threadFunc()
{
    Request* req = new Request;
    req->process();
    delete req;
}

// 使用
~Request()
{
    x_ = -1;
}

void cancel() __attribute__ ((noinline))
{
    muduo::MutexLockGuard lock(mutex_);
    x_ = 1;
    sleep(1);
    printf("cancel()\n");
    g_inventory.remove(shared_from_this());
}

void threadFunc()
{
    RequestPtr req(new Request);
    req->process();
    req->cancel();
}

int main()
{
    muduo::Thread thread(threadFunc);
    thread.start();
    usleep(500*1000);
    g_inventory.printAll();
    thread.join();
}
```

