# 线程安全的对象生命期管理

一个线程安全的class应当满足以下三个条件：

- 多个线程同时访问时，其表现出正确的行为。
- 无论操作系统如何调度这些线程，无论这些线程的执行顺序如何交织（interleaving）。
- 调用端代码无须额外的同步或其他协调动作。

> MutexLock封装临界区（critical section），这是一个简单的资源类，用RAII手法**封装互斥器的创建与销毁**。临界区在Windows上是struct CRITICAL_SECTION，是可重入的；在Linux下是pthread_mutex_t，默认是不可重入的。MutexLock一般是别的class的数据成员。
>
> MutexLockGuard**封装临界区的进入和退出**，即加锁和解锁。MutexLockGuard一般是个栈上对象，它的作用域刚好等于临界区域。
>
> `mutex_`成员一般是mutable的，意味着const成员函数也能直接使用non-const的`mutex_`。

## 构造函数

对象构造要做到线程安全，唯一的要求是在构造期间不要泄露this指针，即

- 不要在构造函数中注册任何回调，也不要在构造函数中把this传给跨线程的对象；

	之所以这样规定，是因为在构造函数执行期间对象还没有完成初始化，如果this被泄露给了其他对象（其自身创建的子对象除外），那么别的线程有可能访问这个半成品对象，这会造成难以预料的后果。

	综上，应该另外定义一个函数，在构造之后执行回调函数的注册工作。这需要进行二段式构造（即构造函数+initialize()），既然允许二段式构造，那么构造函数不必主动抛异常，调用方靠initialize()的返回值来判断对象是否构造成功，这能简化错误处理。

- 即使构造函数的最后一行也不要泄露thi。

	因为Foo有可能是个基类，基类先于派生类构造，执行完Foo::Foo()的最后一行代码还会继续执行派生类的构造函数，这时most-derived class的对象还处于构造中，仍然不安全。

## 析构函数

当一个对象能被多个线程同时看到时，那么对象的销毁时机就会变得模糊不清，可能出现多种竞态条件（race condition）：

- 在即将析构一个对象时，从何而知此刻是否有别的线程正在执行该对象的成员函数？
- 如何保证在执行成员函数期间，对象不会在另一个线程被析构？
- 在调用某个对象的成员函数之前，如何得知这个对象还活着？它的析构函数会不会碰巧执行到一半？

对象析构，这在单线程里不构成问题，最多需要注意避免空悬指针和野指针。而在多线程程序中，存在了太多的竞态条件。对一般成员函数而言，做到线程安全的办法是让它们顺次执行，而不要并发执行（关键是不要同时读写共享状态），也就是让每个成员函数的临界区不重叠。这是显而易见的，不过有一个隐含条件：**成员函数用来保护临界区的互斥器本身必须是有效的。而析构函数破坏了这一假设，它会把mutex成员变量销毁掉**。

> 空悬指针（dangling pointer）指向已经销毁的对象或已经回收的地址，野指针（wild pointer）指的是未经初始化的指针

mutex只能保证函数一个接一个地执行，考虑下面的代码，它试图用互斥锁来保护析构函数：

![image-20230405162738448](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405162738448.png)

尽管线程A在销毁对象之后把指针置为了NULL，尽管线程B在调用x的成员函数之前检查了指针x的值，但还是无法避免一种race condition：

1. 线程A执行到了析构函数的(1)处，已经持有了互斥锁，即将继续往下执行。
2. 线程B通过了if(x)检测，阻塞在(2)处。

即线程A将指针对象销毁但未置 NULL 前，线程B通过了if(x)检测，阻塞在(2)处，但析构函数会把 mutex_ 销毁掉，即 mutex_ 不再有效。

因此作为class数据成员的MutexLock只能用于同步本class的其他数据成员的读和写，它不能保护安全地析构。**因为MutexLock成员的生命期最多与对象一样长，而析构动作可说是发生在对象已经身故之后（或者身亡之时）**。另外，对于基类对象，那么调用到基类析构函数的时候，派生类对象的那部分已经析构了，那么基类对象拥有的MutexLock不能保护整个析构过程。再说，**析构过程本来也不需要保护，因为只有别的线程都访问不到这个对象时，析构才是安全的**，否则会有竞态条件发生。

## 死锁

另外如果要同时读写一个class的两个对象，有潜在的死锁可能。比方说有swap()这个函数：

![image-20230405163300893](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405163300893.png)

如果线程A执行swap(a, b);而同时线程B执行swap(b, a);，就有可能死锁。operator=()也是类似的道理。

![image-20230405163306478](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405163306478.png)

一个函数如果要锁住相同类型的多个对象，为了保证始终按相同的顺序加锁，我们可以比较mutex对象的地址，始终先加锁地址较小的mutex。

## shared_ptr/weak_ptr

shared_ptr控制对象的生命期。shared_ptr是强引用，只要有一个指向x对象的shared_ptr存在，该x对象就不会析构。当指向对象x的最后一个shared_ptr析构或reset()的时候，x保证会被销毁。

weak_ptr不控制对象的生命期，但是它知道对象是否还活着。如果对象还活着，那么它可以提升为有效的shared_ptr；如果对象已经死了，提升会失败，返回一个空的shared_ptr。“提升／lock()”行为是线程安全的。

shared_ptr/weak_ptr的“计数”在主流平台上是原子操作，没有用锁，性能不俗。

shared_ptr/weak_ptr的线程安全级别与std::string和STL容器一样。

需要注意一点：scoped_ptr/shared_ptr/weak_ptr都是值语意，要么是栈上对象，或是其他对象的直接数据成员，或是标准库容器里的元素。

还要注意，如果**这几种智能指针是对象x的数据成员，而它的模板参数T是个incomplete类型，那么x的析构函数不能是默认的或内联的**，必须在.cpp文件里边显式定义，否则会有编译错或运行错。

### 线程安全

虽然借shared_ptr来实现线程安全的对象释放，但是shared_ptr本身不是100％线程安全的。它的引用计数本身是安全且无锁的，但对象的读写则不是，因为shared_ptr有两个数据成员，读写操作不能原子化。shared_ptr的线程安全级别和内建类型、标准库容器、std::string一样，即：

- 一个shared_ptr对象实体可被多个线程同时读取；
- 两个shared_ptr对象实体可以被两个线程同时写入，“析构”算写操作；
- 如果要从多个线程读写同一个shared_ptr对象，那么需要加锁。

要在多个线程中同时访问同一个shared_ptr，正确的做法是用mutex保护：

![image-20230405165348820](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405165348820.png)

globalPtr能被多个线程看到，那么它的读写需要加锁，在以上基础上设计如下：

![image-20230405165521323](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405165521323.png)

注意到上面的read()和write()在临界区之外都没有再访问globalPtr，而是用了一个指向同一Foo对象的栈上shared_ptr local copy。只要有这样的local copy存在，shared_ptr作为函数参数传递时不必复制，用reference to const作为参数类型即可。

写入加锁的代码中，new Foo是在临界区之外执行的，这种写法通常比在临界区内写globalPtr.reset(new Foo)要好，因为缩短了临界区长度。

如果要销毁对象，固然可以在临界区内执行globalPtr.reset()，但是这样往往会让对象析构发生在临界区以内，增加了临界区的长度。一种改进办法是像上面一样定义一个localPtr，用它在临界区内与globalPtr交换（swap()），这样能保证把对象的销毁推迟到临界区之外。



练习：在write()函数中，globalPtr＝newPtr;这一句有可能会在临界区内销毁原来globalPtr指向的Foo对象，设法将销毁行为移出临界区。

### 带来的问题

**意外延长对象的生命期**：shared_ptr是强引用，只要有一个指向x对象的shared_ptr存在，该对象就不会析构。而shared_ptr又是允许拷贝构造和赋值的，如果不小心遗留了一个拷贝，那么对象就永世长存了。

**bind**：bind 会把实参拷贝一份，如果参数是个 shared_ptr，那么对象的生命期就不会短于 function 对象：

![image-20230405171035575](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405171035575.png)

这里func对象持有了shared_ptr<Foo>的一份拷贝，有可能会在不经意间延长倒数第二行创建的Foo对象的生命期。

**函数参数**：因为要修改引用计数（而且拷贝的时候通常要加锁），shared_ptr的拷贝开销比拷贝原始指针要高，但是需要拷贝的时候并不多。多数情况下它可以以const reference方式传递，**一个线程只需要在最外层函数有一个实体对象，之后都可以用const reference来使用这个shared_ptr。**遵照这个规则，基本上不会遇到反复拷贝shared_ptr导致的性能问题。另外由于pFoo是栈上对象，不可能被别的线程看到，那么读取始终是线程安全的。

例如有几个函数都要用到Foo对象：

![image-20230405171145892](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405171145892.png)

**析构动作在创建时被捕获**：这是一个非常有用的特性，这意味着：

- 虚析构不再是必需的。
- shared_ptr<void>可以持有任何对象，而且能安全地释放。
- shared_ptr对象可以安全地跨越模块边界，比如从DLL里返回，而不会造成从模块A分配的内存在模块B里被释放这种错误。
- 二进制兼容性，即便Foo对象的大小变了，那么旧的客户代码仍然可以使用新的动态库，而无须重新编译。前提是Foo的头文件中不出现访问对象的成员的inline函数，并且Foo对象的由动态库中的Factory构造，返回其shared_ptr。
- 析构动作可以定制。这个特性的实现比较巧妙，因为shared_ptr<T>只有一个模板参数，而“析构行为”可以是函数指针、仿函数（functor）或者其他什么东西。

**析构所在的线程**：对象的析构是同步的，当最后一个指向x的shared_ptr离开其作用域的时候，x会同时在同一个线程析构。这个线程不一定是对象诞生的线程。这个特性是把双刃剑：如果对象的析构比较耗时，那么可能会拖慢关键线程的速度（如果最后一个shared_ptr引发的析构发生在关键线程）；同时，可以用一个单独的线程来专门做析构，通过一个BlockingQueue<shared_ptr<void> >把对象的析构都转移到那个专用线程，从而解放关键线程。

**现成的RAII handle**：RAII（资源获取即初始化）是C++语言区别于其他所有编程语言的最重要的特性，一个不懂RAII的C++程序员不是一个合格的C++程序员。初学C++的教条是“new和delete要配对，new了之后要记着delete”；如果使用RAII，要改成“**每一个明确的资源配置动作（例如new）都应该在单一语句中执行，并在该语句中立刻将配置获得的资源交给handle对象（如shared_ptr），程序中一般不出现delete**”。shared_ptr是管理共享资源的利器，需要注意避免循环引用，通常的做法是**owner持有指向child的shared_ptr，child持有指向owner的weak_ptr**。

## 系统地避免各种指针错误

缓冲区溢出：用std::vector<char>/std::string或自己编写Buffer class来管理缓冲区，自动记住用缓冲区的长度，并通过成员函数而不是裸指针来修改缓冲区。

空悬指针／野指针：用shared_ptr/weak_ptr。

重复释放：用scoped_ptr，只在对象析构的时候释放一次。

内存泄漏：用scoped_ptr，对象析构的时候自动释放内存。

不配对的new[]/delete：把new[]统统替换为std::vector/scoped_array。

## 线程安全的 Observer 

一个动态创建的对象是否还活着，光看指针是看不出来的（引用也一样看不出来）。指针就是指向了一块内存，这块内存上的对象如果已经销毁，那么就根本不能访问，既然不能访问又如何知道对象的状态呢？换句话说，判断一个指针是不是合法指针没有高效的办法，这是C/C++指针问题的根源（万一原址又创建了一个新的对象呢？再万一这个新的对象的类型异于老的对象呢？）。

在面向对象程序设计中，对象的关系主要有三种：composition、aggregation、association。

- composition（组合／复合）关系在多线程里不会遇到什么麻烦，因为对象x的生命期由其唯一的拥有者owner控制，owner析构的时候会把x也析构掉。从形式上看，x是owner的直接数据成员，或者scoped_ptr成员，抑或owner持有的容器的元素。
- association（关联／联系）是一种很宽泛的关系，它表示一个对象a用到了另一个对象b，调用了后者的成员函数。从代码形式上看，a持有b的指针（或引用），但是b的生命期不由a单独控制。
- aggregation（聚合）关系从形式上看与association相同，除了a和b有逻辑上的整体与部分关系。如果b是动态创建的并在整个程序结束前有可能被释放，那么就会出现竞态条件。

综上，如果**对象x注册了任何非静态成员函数回调，那么必然在某处持有了指向x的指针，也就有着指向 x 的指针已经不再存活的情况，这就暴露在了race condition之下**。

### 问题所在

一个典型的场景是Observer模式：

![image-20230405163820788](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405163820788.png)

当Observable通知每一个Observer时(L17)，它从何得知Observer对象x还活着？考虑为了当 Observable 通知每个 Observer 时得知 Observer 对象是否存活，在析构函数中调用 unregister 解注册，从 observers_ 中弹出，即不会被通知。

但如果让析构函数调用 unregister，将会存在竞态条件：

- 为了调用 unregister 需要得知 subject_ 是否存活
- 若线程 A 还没来得及 unregister 该对象，该对象正处于析构状态，此时线程 B 已经在 notifyObservers 中通过该对象调用 update。既然x所指的Observer对象正在析构，调用它的任何非静态成员函数都是不安全的，何况是虚函数
- 该对象是 Observer 类型，即基类，当 unregister 时派生类对象已经被析构，此时对象已经不完整了。Observer是个基类，派生类对象已经析构掉了，这时候整个对象处于将死未死的状态，core dump恐怕是最幸运的结果。

> C++标准对在构造函数和析构函数中调用虚函数的行为有明确规定，但是没有考虑并发调用的情况。

综上，Observable 需要保存的不是原始的 Observer* 对象，而是可以分辨 Observer 是否存活的对象，为了在析构函数中调用 unregister 解注册去处理释放资源以外的逻辑，又需要 Observer 需要保存的也不能是原始的 Observable* 对象。

### 解决方案

两个指针 p1 p2 同时指向同一个对象 object，当其中一个指针销毁了 object，p2 无法得知此时 object 是否存活，因此 p2 成了空悬指针。为了解决这个问题引入一层间接性，让 p1 p2 指向一个永久有效的对象 Proxy，再由 Proxy 指向 object，通过 Proxy 判断 object 是否存活，还需要控制 Proxy 释放 object 的时机，不能出现 p1 销毁而 p2 无法得知的情况。为此需要引用计数，当引用计数为 0 时，才能销毁 Proxy 所指向的对象。

> 引入另外一层间接性（another layer of indirection），用对象来管理共享资源（把Object看作资源），亦即handle/body惯用技法（idiom）。

综上所述，使用 shared_ptr 管理 Observer，再通过 weak_ptr 作为引用指向 Observer 来判断 Observer 是否存活。但注意必须使用 weak_ptr 来判断 Observer，若 observers_ 的类型为 shared_ptr，会增加引用计数，除非手动释放，否则 Observer 对象永远不会析构。

**只有别的线程都访问不到这个对象时，析构才是安全的，此处就借用智能指针判断对象是否已经被析构，使得不会出现正在析构状态下被访问。**

![image-20230405165214411](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405165214411.png)

### 优化方案

**侵入性** 强制要求Observer必须以shared_ptr来管理。

**不是完全线程安全** Observer的析构函数会调用subject_->unregister(this)，万一subject_已经不复存在了呢？为了解决它，又要求Observable本身是用shared_ptr管理的，并且subject_多半是个weak_ptr<Observable>。

**锁争用（lock contention）** 即Observable的三个成员函数都用了互斥器来同步，这会造成register_()和unregister()等待notifyObservers()，而后者的执行时间是无上限的，因为它同步回调了用户提供的update()函数。我们希望register_()和unregister()的执行时间不会超过某个固定的上限，以免殃及无辜群众。

**死锁** 万一L62的update()虚函数中调用了(un)register呢？如果mutex_是不可重入的，那么会死锁；如果mutex_是可重入的，程序会面临迭代器失效（core dump是最好的结果），因为vector observers_在遍历期间被意外地修改了。这个问题乍看起来似乎没有解决办法，除非在文档里做要求。（一种办法是：用可重入的mutex_，把容器换为std::list，并把++it往前挪一行。）

我个人倾向于使用不可重入的mutex，例如Pthreads默认提供的那个，因为“要求mutex可重入”本身往往意味着设计上出了问题（§2.1.1）。Java的intrinsic lock是可重入的，因为要允许synchronized方法相互调用（派生类调用基类的同名synchronized方法），我觉得这也是无奈之举。

Observer模式的本质问题在于其面向对象的设计。换句话说，我认为正是面向对象（OO）本身造成了Observer的缺点。Observer是基类，这带来了非常强的耦合，强度仅次于友元（friend）。这种耦合不仅限制了成员函数的名字、参数、返回值，还限制了成员函数所属的类型（必须是Observer的派生类）。

Observer class是基类，这意味着如果Foo想要观察两个类型的事件（比如时钟和温度），需要使用多继承。这还不是最糟糕的，如果要重复观察同一类型的事件（比如1秒一次的心跳和30秒一次的自检），就要用到一些伎俩来work around，因为不能从一个Base class继承两次。

现在的语言一般可以绕过Observer模式的限制，比如Java可以用匿名内部类，Java 8用Closure，C#用delegate，C++用boost::function/boost::bind [20](vscode-webview://1162qj1qi5aml929pseib393kdjueqql03igh6buiq10u31hubq2/OEBPS/text00005.html#jz_20_46) 。

在C++里为了替换Observer，可以用Signal/Slots，我指的不是QT那种靠语言扩展的实现，而是完全靠标准库实现的thread safe、race condition free、thread contention free的Signal/Slots，并且不强制要求shared_ptr来管理对象，也就是说完全解决了§1.8列出的Observer遗留问题。这会用到§2.8介绍的“借shared_ptr实现copy-on-write”技术。

在C++11中，借助variadic template，实现最简单（trivial）的一对多回调可谓不费吹灰之力，代码如下。

![image-20230405174653000](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405174653000.png)

## **对象池**与弱回调

假设有Stock类，代表一只股票的价格。每一只股票有一个唯一的字符串标识，比如Google的key是"NASDAQ:GOOG"，IBM是"NYSE:IBM"。Stock对象是个主动对象，它能不断获取新价格。为了节省系统资源，同一个程序里边每一只出现的股票只有一个Stock对象，如果多处用到同一只股票，那么Stock对象应该被共享。如果某一只股票没有再在任何地方用到，其对应的Stock对象应该析构，以释放资源，这隐含了“引用计数”。

为了达到上述要求，我们可以设计一个对象池StockFactory。它的接口很简单，根据key返回Stock对象。我们已经知道，在多线程程序中，既然对象可能被销毁，那么返回shared_ptr是合理的。自然地，我们写出如下代码（可惜是错的）。

![image-20230405172908852](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405172908852.png)

get()的逻辑很简单，如果在`stocks_`里找到了key，就返回`stocks_`[key]；否则新建一个Stock，并存入stocks_[key]。

这里有一个问题，Stock对象永远不会被销毁，因为map里存的是shared_ptr，除去返回的 shared_ptr，总会在 map 中有一份 shared_ptr，因此引用计数总是大于等于 1，不会自动销毁。那么或许应该仿照前面 Observable 那样存一个weak_ptr，当返回的 shared_ptr 被销毁时，map 即 stocks_ 中的对象会自动销毁。

![image-20230405172801831](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405172801831.png)

这么做固然Stock对象是销毁了，但是程序却出现了轻微的内存泄漏，因为`stocks_`的大小只增不减，stocks_.size()是曾经存活过的Stock对象的总数，即便活的Stock对象数目降为0。

解决的办法是，利用shared_ptr的定制析构功能。shared_ptr的构造函数可以有一个额外的模板类型参数，传入一个函数指针或仿函数d，在析构对象时执行d(ptr)，其中ptr是shared_ptr保存的对象指针。这样就可以在析构Stock对象的同时清理stocks_：

![image-20230405173149820](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405173149820.png)

这里向pStock.reset()传递了第二个参数，一个boost::function，让它**在析构Stock* p时调用本StockFactory对象的deleteStock成员函数**。

有一个问题，那就是StockFactory::get()把原始指针this保存到了boost::function中，如果StockFactory的生命期比Stock短，那么Stock析构时去回调StockFactory::deleteStock就会core dump。正如Observer在析构函数里去调用Observable::unregister()，而那时Observable对象可能已经不存在了。

似乎应该惯用的shared_ptr大法来解决对象生命期问题，但是StockFactory::get()本身是个成员函数，如何**获得一个指向当前对象的shared_ptr<StockFactory>对象**呢？答案是用enable_shared_from_this。这是一个以其派生类为模板类型实参的基类模板，继承它，this指针就能变身为shared_ptr。

为了使用shared_from_this()，StockFactory不能是stack object，必须是heap object且由shared_ptr管理其生命期，即：

![image-20230405173605718](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405173605718.png)

这样一来，**boost::function里保存了一份shared_ptr<StockFactory>（因为 bind 拷贝实参，且拷贝的类型也是实参类型），可以保证调用StockFactory::deleteStock的时候那个StockFactory对象还活着。**

注意一点，shared_from_this()不能在构造函数里调用，因为在构造StockFactory的时候，它还没有被交给shared_ptr接管。

把shared_ptr绑（boost::bind）到boost:function里，那么回调的时候StockFactory对象始终存在，是安全的。这同时也延长了对象的生命期，使之不短于绑得的boost:function对象。

有时候需要“**如果对象还活着，就调用它的成员函数，否则忽略之**”的语意，就像Observable::notifyObservers()那样，称之为“弱回调”。这也是可以实现的，利用weak_ptr，可以把weak_ptr绑到boost::function里，这样对象的生命期就不会被延长。然后在回调的时候先尝试提升为shared_ptr，如果提升成功，说明接受回调的对象还健在，那么就执行回调，在析构Stock对象的同时清理stocks_：；如果提升失败，就只需要释放资源。

使用这一技术的完整StockFactory代码如下：

![image-20230405174044493](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405174044493.png)

![image-20230405174051881](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230405174051881.png)