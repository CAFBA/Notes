# Future

1. condition_variable：互斥的选择，代码细节（unlock）
2. async：作用，std::launch
3. packaged_task<>：作用，使用，API
4. promises：作用，使用，API
5. shared_future：get，应用场景，同步方式，构造方式，转移归属权
6. then：作用，异常情况
7. when_all：应用场景，返回值
8. when_any：应用场景，与 when_all 的区别，返回值，可变参数

## condition_variable

C++标准库提供了条件变量的两种实现：std::condition_variable 和std::condition_variable_any。它们都在标准库的头文件<condition_variable>内声明。两者都需配合互斥，方能提供妥当的同步操作。std::condition_variable仅限于与std::mutex一起使用，而std::condition_variable_any只要能和某一类型符合成为互斥的最低标准就可以使用。

```c++
std::mutex mut;
std::queue<data_chunk> data_queue;  // 使用std::queue队列在两个线程之间传递数据
std::condition_variable data_cond;
void data_preparation_thread() {            // 由线程乙运行
    while(more_data_to_prepare()) {
        data_chunk const data = prepare_data(); 
        {
            std::lock_guard<std::mutex> lk(mut);
            data_queue.push(data); // 一旦线程乙准备好数据，就使用std::lock_guard锁住互斥以保护队列，并压入数据
        } // 离开该代码块，锁 lk 会自动销毁从而解锁。若线程甲立刻觉醒，也无须等待互斥解锁，从而不会被阻塞。
        data_cond.notify_one(); // 线程乙调用std::condition_variable实例的成员函数notify_one()，通知线程甲
    } // 不能等到此刻才解锁
}
void data_processing_thread() {          // 由线程甲运行
    while(true) {
        std::unique_lock<std::mutex> lk(mut); 
        // 调用wait()，传入锁对象和一个lambda函数
        // 若成立（true），则wait()返回；否则（false），wait()解锁互斥，并令线程进入阻塞状态或等待状态。
        data_cond.wait(lk, []{return !data_queue.empty();}); // 调用wait()，传入锁对象和一个lambda函数，后者用于表达需要等待成立的条件
        data_chunk data = data_queue.front(); // 
        data_queue.pop();
        lk.unlock(); // 一旦数据就绪，即便还没正式开始处理，也把锁释放。
        process(data); // 数据处理操作有可能相当耗时，因此在必要范围之外锁住互斥是不当的设计思维。
        if(is_last_chunk(data)) break;
    }
}
```

> 假设内层花括号不存在，则锁lk的生存期持续至while循环末尾。若线程甲在语句执行后立即觉醒，而互斥仍被锁住，则线程甲还需等待锁lk销毁。内层花括号令锁lk在语句执行前销毁，即在线程甲觉醒前解锁互斥，算是微小的性能改进。

线程甲等待接收处理数据，对互斥加锁使用的是std::unique_lock而非std::lock_guard。线程乙将数据准备好后，即调用notify_one()通知条件变量，线程甲随之从休眠中觉醒（阻塞解除），重新在互斥上获取锁，再次查验条件：若条件成立，则从wait()函数返回，且互斥仍被锁住；若条件不成立，则线程甲解锁互斥，并继续等待。

舍弃std::lock_guard而采用std::unique_lock，**原因就在这里：线程甲在等待期间，必须解锁互斥，而结束等待之后，必须重新加锁，但std::lock_guard无法提供这种灵活性**。假设线程甲在休眠的时候，互斥依然被锁住，那么即使线程乙备妥了数据，也不能锁住互斥，无法将其添加到队列中。结果线程甲所等待的条件永远不能成立，它将无止境地等下去。

> 即 condition_variable 与 lock_guard 无法搭配使用

在wait()的调用期间，条件变量可以多次查验给定的条件，次数不受限制；在查验时，互斥总会被锁住；另外，当且仅当传入的判定函数返回true时（它判定条件成立），wait()才会立即返回。**如果线程甲重新获得互斥，并且查验条件，而这一行为却不是直接响应线程乙的通知，则称之为伪唤醒（spurious wake）。**按照C++标准的规定，这种伪唤醒出现的数量和频率都不确定。故此，若判定函数有副作用，则不建议选取它来查验条件。

条件变量也适用于多个线程都在等待同一个目标事件的情况。若要将工作负荷分配给多个线程，那么，对于每个通知应该仅有一个线程响应。如果几个线程都在等待同一个目标事件，那么还存在另一种可能的行为方式：它们全部需要做出响应。

以上行为会在两种情形下发生：共享数据的初始化或所有负责处理的线程都用到同一份数据，但都需要等待数据初始化完成。尽管条件变量适用，但可以选择其他更好的处理方式，如**std::call_once()函数。所有线程都要等待共享数据更新**（如定期执行的重新初始化）。

负责准备的线程原本在条件变量上调用notify_one()，而对于这两种情形只需改为调用成员函数notify_all()。顾名思义，该函数通知当前所有执行wait()而正在等待的线程，让它们去查验所等待的条件。条件变量未必是这种同步模式的最佳选择。**若所等待的条件需要判定某份数据是否可用，future更适合。**

## future

future 用于线程需要等待特定事件这种情况，其**周期性的等待或检查事件是否触发，等待事件期间可以先执行另外的任务**，直到对应的任务触发，而后等待future 的状态会变为就绪状态。当等待的事件发生时(状态为就绪)，这个 future 就不能重置了。

C++标准库中有两种future，声明在`<future>`头文件中: unique future(`std::future<>`)和shared futures(`std::shared_future<>`)。`std::future`只能与指定事件相关联，而`std::shared_future`就能关联多个事件。后者的实现中，所有实例会在同时变为就绪状态，并且可以访问与事件相关的数据。

**future对象本身并不提供同步访问。当多个线程需要访问一个独立future对象时，必须使用互斥量或类似同步机制进行保护**。不过，当多个线程对一个`std::shared_future<>`副本进行访问，即使同一个异步结果，也不需要同步future。

Conclusion：

- future 对象用于等待任务完成的同时执行其它任务的情景。
- std::async 函数用于执行异步任务，返回包含异步任务结果的 future 对象。
- std::packaged_task 是可调用对象，用于对一系列的异步任务进行包装，便于修改异步任务的类型，并返回包含结果的 future 对象。
- std::promises 对象用于线程通信，通知 future 对象就绪。

## async

假设有一个需要长时间的运算，需要计算出一个有效值，但并不迫切需要这个值。可以启动新线程来执行这个计算，而`std::thread`并不提供直接接收返回值的机制。这里就需要`std::async`函数模板(在头文件`<future>`)。

当暂时不需要任务结果时，可以向`std::async`传递任务函数启动一个异步任务。与`std::thread`对象等待的方式不同，`std::async`会返回一个`std::future`对象，这个对象持有最终计算出来的结果。当需要这个值时，只需要调用这个对象的get()成员函数，就会阻塞线程直到future为就绪为止，并返回计算结果。

`std::async`允许通过添加额外的调用参数，向函数传递额外的参数：

- 如果是成员函数，则第一个参数是指向成员函数的指针，第二个参数提供这个函数成员类的具体对象(或指针)，剩余的参数可作为函数的参数传入。
- 如果是普通函数或可调用对象，则第二个和随后的参数将作为函数的参数，或作为指定可调用对象的参数。和`std::thread`一样，当参数为右值时，拷贝操作将使用移动的方式转移原始数据，就可以使用只移动类型作为函数对象和参数。

```c++
struct X {
  void foo(int, std::string const&);
  std::string bar(std::string const&);
};
X x;
auto f1 = std::async(&X::foo, &x, 42, "hello");  // 调用p->foo(42, "hello")，p是指向x的指针
auto f2 = std::async(&X::bar, x, "goodbye");  // 调用tmpx.bar("goodbye")， tmpx是x的拷贝副本

struct Y {
  double operator()(double);
};
Y y;
auto f3 = std::async(Y(), 3.141);  // 调用tmpy(3.141)，tmpy通过Y的移动构造函数得到
auto f4 = std::async(std::ref(y), 2.718);  // 调用y(2.718)

X baz(X&); // baz 是可调用对象
std::async(baz, std::ref(x));  // 调用baz(x)

class move_only {
public:
  move_only();
  move_only(move_only&&)
  move_only(move_only const&) = delete;
  move_only& operator=(move_only&&);
  move_only& operator=(move_only const&) = delete;
  
  void operator()();
};
auto f5 = std::async(move_only());  // 调用tmp()，tmp是通过std::move(move_only())构造得到
```

`std::async`会返回一个`std::future`对象，而这个future的等待取决于`std::async`是否启动一个线程，或是否有任务在进行同步，通过向其传递额外参数指定，参数类型为 std::launch ：

- `std::launch::defered`：在当前线程上延后调用任务函数，等到在future上调用了wait()或get()，任务函数才会执行（不调用不执行）；
- `std::launch::async`：必须另外开启专属的线程，在其上运行任务函数；
- `std::launch::deferred | std::launch::async`：由std::async()的实现自行选择运行方式；
- 默认参数

```c++
auto f6 = std::async(std::launch::async, Y(), 1.2);  // 开启专属的线程，在其上运行任务函数
auto f7 = std::async(std::launch::deferred, baz, std::ref(x));  // 调用wait()或get()才运行任务函数
auto f8 = std::async(std::launch::deferred | std::launch::async, baz,std::ref(x));  // 交由实现自行选择运行方式
auto f9 = std::async(baz, std::ref(x)); 
f7.wait();  // 任务函数调用被延后，到这里才运行
```

## packaged_task<>

`std::packaged_task<>`会将future与函数或可调用对象进行绑定。当调用`std::packaged_task<>`对象时，就会调用相关函数或可调用对象，当future状态为就绪时，会存储返回值。

`std::packaged_task<>`的模板参数是一个函数签名。构造`std::packaged_task<>`实例时，就必须传入函数或可调用对象，并与作为模板参数的函数签名相匹配（类型可以隐式转换）。

```c++
template<>
class packaged_task<std::string(std::vector<char>*, int)> {
public:
  template<typename Callable>
  explicit packaged_task(Callable&& f);
  std::future<std::string> get_future(); // 函数签名的返回类型用来标识从get_future()返回的std::future<>的类型
  void operator()(std::vector<char>*, int); // 函数签名的参数列表，用来指定packaged_task函数调用操作符的参数列表
};
```

`std::packaged_task`是个可调用对象，可以封装在`std::function`对象中，从而作为线程函数传递到`std::thread`对象中，或作为可调用对象传递到另一个函数中或直接调用。当`std::packaged_task`作为函数调用时，实参将由函数调用操作符传递至底层函数，并且**返回值作为异步结果存储在`std::future`中，并且可通过get_future()获取**。因此可以用`std::packaged_task`对任务进行打包，并适时的取回future。当异步任务需要返回值时，可以等待future状态变为就绪。

```c++
std::mutex m;
std::deque<std::packaged_task<void()>> tasks;
bool gui_shutdown_message_received();
void get_and_process_gui_message();
void gui_thread() {  // 在GUI线程上 
    while(!gui_shutdown_message_received()) { // 若有消息指示界面关闭，则循环终止
        get_and_process_gui_message();    // 轮询任务队列和待处理的界面消息（如用户的单击）
        std::packaged_task<void()> task;
        {
            std::lock_guard<std::mutex> lk(m);
            if(tasks.empty()) continue; // 假如任务队列一无所有，则循环继续
            task = std::move(tasks.front());    // 否则，就从中取出任务
            tasks.pop_front();
        }
        // std::packaged_task作为函数调用，在任务完成时，与它关联的future会进入就绪状态
        task();   // 释放任务队列上的锁，随即运行该任务
    }
}
std::thread gui_bg_thread(gui_thread);
template<typename Func>
std::future<void> post_task_for_gui_thread(Func f) {
    std::packaged_task<void()> task(f);  // 依据给定的函数创建新任务，将任务包装在内
    std::future<void> res = task.get_future();  // 随即通过调用成员函数get_future()，取得与该任务关联的future
    std::lock_guard<std::mutex> lk(m);
    tasks.push_back(std::move(task));    // 然后将任务放入任务队列
    return res;   // 接着向post_task_for_gui_thread()的调用者返回future
}

// 接下来，有关代码向GUI线程投递消息，假如这些代码需判断任务是否完成，以获取结果进而采取后续操作，那么只要等待future就绪即可；
// 否则，任务的结果不会派上用场，关联的future可被丢弃。
```

本例采用std::packaged_task<void()>表示任务，包装某个函数（或可调用对象），它不接收参数，返回void（倘若真正的任务函数返回任何其他类型的值，则会被丢弃）。针对不同的任务函数，std::packaged_task的函数调用操作符须就此修改参数，保存于相关的future实例内的返回值类型也须变动，而只要通过模板参数，指定对应任务的函数签名即可。可轻松扩展上例，改动那些只准许在GUI线程上运行的任务，令其接收参数，并凭借std::future返回结果，std::future不再局限于充当指标，示意任务是否完成。

## promises

std::promise<T>给出了一种异步求值的方法（类型为T），某个std::future<T>对象与结果关联，能延后读出需要求取的值。配对的std::promise和std::future可实现下面的工作机制：**等待数据的线程在future上阻塞，而提供数据的线程利用相配的promise设定关联的值，使future准备就绪**。

若需从给定的std::promise实例获取关联的std::future对象，调用前者的成员函数get_future()即可。promise的值通过成员函数set_value()设置，只要设置好，future即准备就绪，凭借它就能获取该值。如果std::promise在被销毁时仍未曾设置值，保存的数据则由异常代替。

假设，有个应用需要处理大量网络连接，往往倾向于运用多个独立线程，一对一地处理各个连接，原因是这能简化网络通信的构思，程序编写也相对容易。如果连接数量较少（因而线程数量也少），此方式行之有效；无奈，随着连接数量攀升，它就渐渐力不从心了。过多线程导致消耗巨量系统资源，一旦线程数量超出硬件所支持的并发任务数量，还可能引起繁重的上下文切换，影响性能。极端情况下，在网络连接超出负荷之前，操作系统就可能已经先耗尽别的资源，无法再运行新线程。

故此，**若应用要处理大量网络连接，通常交由少量线程负责处理（可能只有一个），每个线程同时处理多个连接。**

代码4.10 使用promise解决单线程多连接问题

```c++
// 向外发送的数据包取自发送队列，并通过连接发出。
void process_connections(connection_set& connections) {
    while(!done(connections)) { // 函数process_connections()反复循环，若done()返回true则停止
        for(connection_iterator connection = connections.begin(), end = connections.end(); 
            connection!=end; ++connection) { // 每轮循环中，程序依次检查各个连接
            if(connection->has_incoming_data()) {   // 若有数据传入，则接收
                data_packet data=connection->incoming();
                // 假定传入的数据包本身已含有ID和荷载数据。令每个ID与各std::promise对象（它们可能存储到关联容器中，利用查找而实现）一一对应
                std::promise<payload_type>& p = connection->get_promise(data.id); 
                p.set_value(data.payload);
            }
            if(connection->has_outgoing_data()) {  // 或者，若发送队列中有数据，则向外发送
                outgoing_packet data = connection->top_of_outgoing_queue(); // 向外发送的数据包取自发送队列，并通过连接发出。
                connection->send(data.payload);
                data.promise.set_value(true); // 只要发送完成，与向外发送数据关联的promise就会被设置为true，示意数据发送成功
            }
        }
    }
}
```

## shared_future

只要同步操作是一对一地在线程间传递数据，std::future就都能处理。然而，对于某个std::future实例，如果其成员函数由不同线程调用，它们却不会自动同步。若在多个线程上访问同一个std::future对象，而不采取额外的同步措施，将引发数据竞争并导致未定义行为。因此std::future模拟了对异步结果的独占行为，get()仅能被有效调用唯一一次。这个特性令并发访问失去意义，**只有一个线程可以获取目标值，原因是第一次调用get()会进行移动操作，之后该值不复存在。**

假设，并发代码却必须让多个线程等待同一个目标事件。std::future仅能移动构造和移动赋值，所以归属权可在多个实例之间转移，但在相同时刻，只会有唯一一个future实例指向特定的异步结果；std::shared_future的实例则能复制出副本，因此可以持有该类的多个对象，它们全指向同一异步任务的状态数据。

**即便改用std::shared_future，同一个对象的成员函数却依然没有同步。若从多个线程访问同一个对象，就必须采取锁保护以避免数据竞争。首选方式是，向每个线程传递std::shared_future对象的副本，它们为各线程独自所有，并被视作局部变量。**因此，这些副本就作为各线程的内部数据，由标准库正确地同步，可以安全地访问。

若多个线程共享异步状态，只要它们通过自有的std::shared_future对象读取状态数据，则该访问行为是安全的，如图4.1所示。

> std::shared_future 等待的是多个线程，而 when_all 等待的是多个 future。

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/4-1-1.png)

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/4-1-2.png) 

图4.1 使用多个`std::shared_future`对象来避免数据竞争

std::shared_future的实例依据std::future的实例构造而得，前者所指向的异步状态由后者决定。因为std::future对象独占异步状态，其归属权不为其他任何对象所共有，所以**若要按默认方式构造std::shared_future对象，则须用std::move向其默认构造函数传递归属权**，这使std::future变成空状态（empty state）。

```c++
std::promise<int> p;
std::future<int> f(p.get_future());
assert(f.valid());    ⇽---  ① future对象f有效
std::shared_future<int> sf(std::move(f));
assert(!f.valid());    ⇽---  ②对象f不再有效
assert(sf.valid());    ⇽---  ③对象sf开始生效
```

这段代码中，对象f最开始是有效的①，它指向和promise对象p关联的异步状态，但在状态转移给对象sf以后，对象f就不再有效②，而对象sf随即生效③。

与其他可移动对象相似，右值对象的归属权会进行隐式转移。因而，依据std::promise的成员函数get_future()的返回值，就能直接构造std::shared_future对象，举例如下：

```c++
std::promise<std::string> p;
std::shared_future<std::string> sf(p.get_future());    ⇽---  ①隐式转移归属权
```

这里发生了归属权的隐式转移，依据std::future\<std::string>类型的右值创建出std::shared_future<>对象。

std::future具有成员函数share()，直接创建新的std::shared_future对象，并向它转移归属权。

```c++
std::promise< std::map< SomeIndexType, SomeDataType, SomeComparator, SomeAllocator>::iterator> p;
auto sf = p.get_future().share();
```

这个例子中，sf的类型推导为`std::shared_future<std::map<SomeIndexType, SomeDataType, SomeComparator, SomeAllocator>::iterator>`。当比较器或分配器有所改动，只需要对promise的类型进行修改即可。future的类型会自动与promise的修改进行匹配。

## then

并发技术规约在名字空间std::experimental内，给出了对应std::promise和std::packaged_task的新版本，它们都返回std::experimental::future实例，而非std::future。

then()可以为future添加后续调用，从而实现一旦结果数据就绪，就接着进行某项处理的功能。then()调用的返回值保存在std::experimental::future类内部，其值只能取出一次，如果该值已经为后续所用，则别的代码再也无法访问。所以，只要用then()添加了后续调用，原来的future对象就会失效，then()的调用会返回新的future对象，后续函数的结果由它持有。

```c++
std::experimental::future<int> find_the_answer();
auto fut = find_the_answer();
// 一旦最开始的future准备就绪，则后续函数find_the_question()会在“某一线程上”运行，但无法确定具体是哪个线程
auto fut2 = fut.then(find_the_question);
assert(!fut.valid());
assert(fut2.valid());
```

与调用 std::async()或构造 std::thread 不同的是，无法向后续函数传递参数，因为参数已经由程序库预设好，先前准备就绪的future会传入后续函数，它所包含的结果会触发后续函数的调用，作为后续函数的参数。假定上例的find_the_answer()函数返回int值，那么find_the_question()函数则必须接收唯一一个参数，类型是std::experimental::future<int>，如下所示：

```c++
std::string find_the_question(std::experimental::future<int> the_answer); // 传递的不是值，而是包含值的 future
```

这是强制规定，因为future上的后续函数发生连锁调用，而该future可能会持有结果的值，也可能持有异常。

假若隐式地将值从future提取出来，再直接传递给后续函数，就不得不交由线程库决定如何处理异常，但只要把future传递给后续函数，异常就能交由它处理。这可以由fut.get()完成，它准许后续函数重新抛出异常并向外传递。异步函数通过std::async()运行，若异常从后续函数逃逸，则会保存在对应的future中，该future也用来保存后续函数的运行结果。

并发技术规约没有提供具备以下功能的函数：既与std::async()等价，又支持std::experimental::future。但凭借std::experimental::promise预先获取future对象，然后生成新线程运行一个lambda表达式，进而通过该lambda表达式执行任务函数，并将promise的值设定为任务函数的返回值可以实现，如代码清单4.17所示。

```c++
template<typename Func>
std::experimental::future<decltype(std::declval<Func>()())>
spawn_async(Func&& func){
    std::experimental::promise<decltype(std::declval<Func>()())> p;
    auto res = p.get_future();
    std::thread t([p=std::move(p),f=std::decay_t<Func>(func)]()
            mutable{
            try{
                p.set_value_at_thread_exit(f());
            } catch(...){
                p.set_exception_at_thread_exit(std::current_exception());
            }
    });
    t.detach();
    return res;
}
```

以上代码的行为与std::async()一致，任务函数的运行结果保存在std::experimental::future对象内部，若任务函数抛出异常，则会被捕获，也保存在该对象中。这里还用到两个函数——set_value_at_thread_exit()和set_exception_at_thread_exit()，功能是确保在future对象就绪之前，thread_local变量会被妥善地清理。

## 异步登录方式

假定有一系列耗时的任务需要执行，而且，为了让主线程抽身执行其他任务，想按异步方式执行这些任务。例如，当用户登录应用程序时，就需向后端服务器发送信息以验证身份；完成身份验证之后，需再次向后端服务器请求其账户信息；最后，一旦取得了相关信息，就做出更新并显式呈现。若读者为此编写串行代码，则可能与代码清单4.18相似。

代码4.18 处理用户登录——同步方式

```c++
void process_login(std::string const& username,std::string const& password) {
    try {
        user_id const id = backend.authenticate_user(username,password);
        user_data const info_to_display = backend.request_current_info(id);
        update_display(info_to_display);
    } catch(std::exception& e){
        display_error(e);
    }
}
```

然而，不想要串行代码，而想令代码异步运行，这样就不会阻塞用户界面线程。如果直接使用std::async()，全部代码就会集中到后台的某一线程上运行，如代码清单4.19所示。但是，该后台线程仍会消耗大量资源以逐一完成各任务，因而发生阻塞。若这样的任务很多，那将导致大量线程无所事事，它们只是在空等。

代码4.19 处理用户登录——异步方式

```c++
std::future<void> process_login(std::string const& username, std::string const& password){
    return std::async(std::launch::async, [=](){
        try {
            user_id const id = backend.authenticate_user(username, password);
            user_data const info_to_display = backend.request_current_info(id);
            update_display(info_to_display);
        } catch(std::exception& e){
            display_error(e);
        }
    });
}
```

这个线程因承担过多任务而发生阻塞，应予避免。因而需要按照后续函数的方式，将任务接合，形成调用链，每完成一个任务，就执行下一个。代码清单4.20的总体处理过程和前例相同，但这次登录流程被拆分成一系列任务，每个任务各自作为上一个任务的后续函数，接合成调用链。

代码4.20 处理用户登录——持续性方式

```c++
std::experimental::future<void> process_login(std::string const& username,std::string const& password) {
    return spawn_async([=]() { // 后续函数（即传入 then 这些 lambda）可能阻塞，因此封装为 future 
        return backend.authenticate_user(username, password); // 该函数返回 user_id，将保存在 spawn_async 返回的 future 中
    }).then([](std::experimental::future<user_id> id) { // future 通过 then  调用后续函数
        return backend.request_current_info(id.get()); // 该函数返回 id，将保存在 then 返回的 future 中
    }).then([](std::experimental::future<user_data> info_to_display){
        try {
            update_display(info_to_display.get());
        } catch(std::exception& e){
            display_error(e);
        }
    });
}
```

每个后续函数都接收std::experimental::future对象作为唯一的参数，然后用get()获取其所含的值。这样的意义是，倘若调用链中的任何后续函数抛出了异常，那么异常会沿着调用链向外传递，在最末尾的后续函数中，经由info_to_display.get()的调用抛出，该处的catch块能集中处理全部异常，与代码清单4.18中catch块的行为相似。

上例中，**有些后续函数与后端服务器发生互动，假如网络消息传递延迟或数据库操作缓慢，它们就会被迫等待而在内部发生阻塞**，那么处理过程也随之停滞。若将任务进一步拆分成相互独立的部分，这些调用仍会发生阻塞，甚至致使线程阻塞。针对涉及后端服务器的后端函数调用，需要让其返回future对象，它会随着数据就绪而自然就绪，那样就不会阻塞任何线程。backend.async_authenticate_user(username, password)本来只是简单地返回user_id，根据上述设计则需改为返回std::experimental::future<user_id>。

因为后继函数若要返回future实例，那么该实例就会根据类模板具现化成future<future<some_value>>，后续具有一个灵便的特性，名为future展开（future-unwrapping）。假设传递给then()的后续函数返回future<some_type>对象，那么then()的调用会相应地返回future<some_type>。利用该特性，最终写出的代码会与代码清单4.21相似。在异步函数调用链上不会发生阻塞。

> 即原本的then()调用返回值会保存在future，若后继函数返回future实例，那么会变为 future<future<some_value>> 形式，但由于future展开，会展开为 future<some_value>。

代码4.21  处理用户登录——全异步操作

```c++
std::experimental::future<void> process_login(std::string const& username,std::string const& password) {
    return backend.async_authenticate_user(username, password).then( 
        [](std::experimental::future<user_id> id) {
            return backend.async_request_current_info(id.get()); 
        }).then([](std::experimental::future<user_data> info_to_display){
            try{
                update_display(info_to_display.get());
            } catch(std::exception& e){
                display_error(e);
            }
        });
}
```

这与代码清单4.18的串行代码几乎一样直接、易懂，只是多了一些公式化（boilerplate）代码，将then()调用和lambda声明包围在内。本例中，lambda函数的参数是特化的future类型，若编译器支持C++14的泛型lambda（generic lambda），则该参数可用关键字auto代替，从而进一步简化为如下代码：

```c++
return backend.async_authenticate_user(username,password).then(
        [](auto id){
            return backend.async_request_current_info(id.get());
        });
```

td::experimental::shared_future也支持后续。两者的区别是，std::experimental::shared_future可能具有多个后续。另外，它的后续函数的参数属于std::experimental::shared_future类型，而非std::experimental::future。

其原因自然是std::experimental::shared_future的共享本质：由于该类的多个对象可共同指向一个共享状态，因此若仅仅容许一个后续存在，则可能会在两个线程间引发条件竞争，它们都试图给自己的std::experimental::shared_future对象添加后续。这样显然不行，所以要容许多个后续共存。一旦容许多个后续共存，那么也要相应地允许它们全都通过同一个std::experimental::shared_future实例添加，而不是限制每个对象仅仅添加一个后续。

另外，若意欲将共享状态传递到某个下游后续，以下做法不可行：将它包装成仅用一次的std::experimental::future实例，先传递给上游后续，再向下传递。其原因是，传递给后续函数的参数必须也是std::experimental::shared_future。

```c++
auto fut = spawn_async(some_function).share();
auto fut2 = fut.then([](std::experimental::shared_future<some_data> data){
    do_stuff(data);
    });
auto fut3 = fut.then([](std::experimental::shared_future<some_data> data){
    return do_other_stuff(data);
    });
```

变量fut属于std::experimental::shared_future类型，通过调用share()而创建，因此后续函数必须接收一个std::experimental::shared_future类型的变量作为参数。然而，后续函数的返回值只是一个普通的std::experimental::future对象，它并不是共享值，除非将其转换为共享值，所以fut2和fut3的类型都是std::experimental::future。

## when_all

假定有大量数据需要处理，而且每项数据都能独立完成，此时，只要生成一组异步任务，分别处理数据，使之通过future各自返回处理妥当的项目，就能充分利用手头的硬件资源。但这难以适用于下述流程模式：若存在最后的汇总处理步骤，要求各分项结果全部齐备，则需等待所有任务完成，必须等待future逐一准备就绪，才可获得每个分项结果。若采用另一异步任务专门收集结果，那么可能需要为此生成一个线程，交由该任务占用以统筹等待，或不停地查验future的状态，等到它们全都准备就绪才生成新任务，最后汇总。代码清单4.22给出了这样的示范。

代码4.22 使用`std::async`从多个future中收集结果

```c++
std::future<FinalResult> process_data(std::vector<MyData>& vec) {
    size_t const chunk_size = whatever;
    std::vector<std::future<ChunkResult>> results;

    for (auto begin = vec.begin(), end = vec.end(); beg != end;){
        size_t const remaining_size = end - begin;
        size_t const this_chunk_size = std::min(remaining_size, chunk_size);
        results.push_back(std::async(process_chunk, begin, begin+this_chunk_size));
        begin += this_chunk_size;
    }

    return std::async([all_results=std::move(results)](){
        std::vector<ChunkResult> v;
        v.reserve(all_results.size());
        for (auto& f : all_results) v.push_back(f.get());    // 1 
        return gather_results(v);
    });
}
```

这段代码新生成一个异步任务，专门等待收集分项结果，只要这些结果全部得出，就进行最后的汇总处理。然而，因为它等待每个任务，但凡有分项结果得出，就会在①处被系统任务调度器反复唤醒。不过，若它发现有任务尚未得出结果，旋即再次休眠。这既会占据等待的线程，更会在各个future就绪时，导致多余的上下文切换，带来额外的开销。

可以使用` std::experimental::when_all`来避免这里的等待和切换，向该函数传入一系列需要等待的future，由它生成并返回一个新的总领future，等到传入的future全部就绪，此总领future也随之就绪。接下来，后续函数就能运用这个总领future安排更多工作。代码清单4.23就此给出了示范。

代码4.23 使用` std::experimental::when_all`从多个future中收集结果

```c++
std::experimental::future<FinalResult> process_data(std::vector<MyData>& vec) {
	...

  return std::experimental::when_all(results.begin(), results.end()).then(
    [](std::future<std::vector<std::experimental::future<ChunkResult>>> ready_results) {
      std::vector<std::experimental::future<ChunkResult>> all_results = ready_results.get();
      
      std::vector<ChunkResult> v;
      v.reserve(all_results.size());
      for (auto& f: all_results) v.push_back(f.get()); // 此时已经全部就绪，不需要被唤醒检查任务是否得出结果
      return gather_results(v);
    });
}
```

本例中，使用std::experimental::when_all()函数等待future全部就绪，然后使用then()编排后续函数，而非std::async()。

尽管在形式上，此处的lambda函数仍与前文一样，但实质区别在于，其参数不再从捕获列表取得，而改为接收传入的future实例，其内包装了一个vector容器，装载着各分项结果。而且，在各future之上调用get()函数不会引发阻塞，因为当执行流程到达该处时，所有分项结果的值都已就绪，从而免去休眠后唤醒的频繁调用。

## when_any

假定，依据某些具体条件，从庞大的数据集中查找值。不过，若存在多个值同时满足要求，则选取其中任意一个皆可。这正是并行计算的最主要目的：可以生成多个线程，它们分别查找数据集的子集；若有线程找到了符合条件的值，就设立标志示意其他线程停止查找，并设置最终结果的值。按这种方式，一有任务首先查找到结果，希望立刻更进一步处理，即使别的线程还没有完成善后清理工作。

可以采用std::experimental::when_any()函数统筹众多future，它生成一个新的future返回给调用者，**只要原来的future中至少有一个准备就绪，则该新future也随之就绪**。std::experimental::when_all()函数产生一个新的future，将传入的多个future全部包装在内，而std::experimental::when_any()与之不同，**它产生的新future还增加了一层结构即一个依照类模板std::experimental::when_any_result<>而产生的内部实例，它由一个序列和一个索引值组成，其中序列包含传入的全体future，索引值则指明哪个future就绪，因而触发上述的新future**。

代码4.24 使用` std::experimental::when_any `处理第一个被找到的值

```c++
std::experimental::future<FinalResult>
find_and_process_value(std::vector<MyData>&data) {
    unsigned const concurrency = std::thread::hardware_concurrency();
    unsigned const num_tasks = (concurrency > 0) ? concurrency : 2;
    
    std::vector<std::experimental::future<MyData *>> results;
    auto const chunk_size = (data.size() + num_tasks - 1) / num_tasks;
    auto chunk_begin = data.begin();
    std::shared_ptr<std::atomic<bool>> done_flag = std::make_shared<std::atomic<bool>>(false);
    
    for (unsigned i = 0; i < num_tasks; ++i) { // 代码产生多个异步任务，数目为num_tasks
        auto chunk_end = (i < (num_tasks - 1)) ? chunk_begin + chunk_size : data.end();
        results.push_back(spawn_async([=] {  // 每个任务都开始运行lambda函数
            for (auto entry = chunk_begin; !*done_flag && (entry != chunk_end); ++entry) {
                if (matches_find_criteria(*entry)) {
                    *done_flag = true;
                    return &*entry;
                }
            }
            return (MyData *)nullptr;
        }));
        chunk_begin = chunk_end;
    }
    std::shared_ptr<std::experimental::promise<FinalResult>> final_result =
        std::make_shared<std::experimental::promise<FinalResult>>();
    
    struct DoneCheck {
        std::shared_ptr<std::experimental::promise<FinalResult>> final_result;

        DoneCheck(std::shared_ptr<std::experimental::promise<FinalResult>> final_result_)
            : final_result(std::move(final_result_)) {}

        void operator()( // 在最初的众多查找任务中，只要有一个完成，则DoneCheck类的函数调用操作符即作为后继，紧接着运行
            std::experimental::future<std::experimental::when_any_result<
                std::vector<std::experimental::future<MyData *>>>> results_param) {
            auto results = results_param.get();
            MyData *const ready_result = results.futures[results.index].get(); // 从就绪的future中提取出结果
            if (ready_result)
                final_result->set_value(process_found_value(*ready_result)); // 若查找到目标值，则做出处理，并设定要返回的结果
            else {
                results.futures.erase(results.futures.begin() + results.index); // 否则，从集合中将已经就绪的future丢弃
                if (!results.futures.empty()) {
                    // 如果还有future需要检查，则发起新的std::experimental::when_any()调用
                    // 那样，当下一个future就绪时，后续函数就会被触发。
                    std::experimental::when_any(results.futures.begin(), results.futures.end()).then(std::move(*this));
            } else  // 若没有剩余的future等待处理，则所有任务都没有找到目标值，那么向最终结果存入异常
                final_result->set_exception(std::make_exception_ptr(std::runtime_error("Not found")));
        }
    };
	// 当全部任务产生完毕，就着手处理第一个返回结果的任务，通过连锁调用的形式给std::experimental::when_any()添加后续函数
    std::experimental::when_any(results.begin(), results.end()).then(DoneCheck(final_result));     ⇽---  ③
    return final_result->get_future(); // find_and_process_value()函数返回一个future，与最终结果对应
}
```

lambda函数按复制值的方式捕获外部变量，所以每个任务都具有自己的chunk_begin值和chunk_end值，还具有共享指针done_flag的副本。这样避免了任何牵涉生存期的问题。

在前文的两个范例中，用到的std::experimental::when_all()和std::experimental::when_any()都是**基于迭代器范围的重载函数**，它们都接收一对迭代器作为参数，代表容器范围的开头和结尾，需要等待其范围内的future。

这两个函数还具有**可变参数的重载形式**，能接收多个future直接作为参数，都返回future对象：std::experimental::when_all()所返回的future持有元组（tuple），而when_any()返回的future持有when_any_result实例。

```c++
std::experimental::future<int> f1=spawn_async(func1);
std::experimental::future<std::string> f2=spawn_async(func2);
std::experimental::future<double> f3=spawn_async(func3);
std::experimental::future<
    std::tuple<
        std::experimental::future<int>,
        std::experimental::future<std::string>,
        std::experimental::future<double>>> 
    result = std::experimental::when_all(std::move(f1),std::move(f2),std::move(f3));
```

此例意在强调一个重点，其涉及std::experimental::when_any()和std::experimental:: when_all()的全部使用方式：两者都通过容器将多个std::experimental::future移动复制到函数中，而且它们都以传值的方式接收参数，所以需要显式地向函数内部移动future，或传递临时变量。

## 将异常存与future中

若经由std::async()调用的函数抛出异常，则会被保存到future中，代替本该设定的值，future随之进入就绪状态，等到其成员函数get()被调用，存储在内的异常即被重新抛出。假如把任务函数包装在std::packaged_task对象内，也依然如是。若包装的任务函数在执行时抛出异常，则会代替本应求得的结果，被保存到future内并使其准备就绪。只要调用get()，该异常就会被再次抛出。

std::promise也具有同样的功能，它通过成员函数的显式调用实现。假如不想保存值，而想保存异常，就不应调用set_value()，而应调用成员函数set_exception()。若算法的并发实现会抛出异常，则该函数通常可用于其catch块中，捕获异常并装填promise。

```c++
extern std::promise<double> some_promise;
try {
    some_promise.set_value(calculate_value());
}
catch(...) {
    some_promise.set_exception(std::current_exception());
}
```

这里的std::current_exception()用于捕获抛出的异常。此外，还能用std::make_exception_ptr()直接保存新异常，而不触发抛出行为：

```c++
some_promise.set_exception(std::make_exception_ptr(std::logic_error("foo ")));
```

假定能预知异常的类型，那么，相较try/catch块，后面的代替方法不仅简化了代码，还更有利于编译器优化代码，因而应优先采用。

还有另一种方法可将异常保存到future中：不调用promise的两个set()成员函数，也不执行包装的任务，而直接销毁与future关联的std::promise对象或std::packaged_task对象。如果关联的future未能准备就绪，无论销毁两者中的哪一个，其析构函数都会将异常std::future_error存储为异步任务的状态数据，它的值是错误代码std::future_errc::broken_promise。

> 一旦创建future对象，便是许诺会按异步方式给出值或异常，但刻意销毁产生它们的来源，就无法提供所求的值或出现的异常，导致许诺被破坏。在这种情形下，倘若编译器不向future存入任何数据，则等待的线程有可能永远等不到结果。
>
> future和promise都具备成员函数valid()，用于判别异步状态是否有效。

## functional programming

函数式编程（functional programming）是指一种编程风格，函数调用的结果完全取决于参数，而不依赖任何外部状态。它的意义是，若以相同的参数调用同一个函数两次，结果会完全一致。**future对象可在线程间传递，所以一个计算任务可以依赖另一个任务的结果，却不必显式地访问共享数据，**以C++实现函数式编程风格的并发编程。

```c++
template<typename T>
std::list<T> parallel_quick_sort(std::list<T> input) {
    if(input.empty()) return input;
    std::list<T> result;
    result.splice(result.begin(),input,input.begin());
    T const& pivot=*result.begin();
    auto divide_point=std::partition(input.begin(),input.end(),[&](T const& t){ return t<pivot; });
    std::list<T> lower_part;
    lower_part.splice(lower_part.end(),input,input.begin(),divide_point);
    
	// 链表前半部分的排序不再由当前线程执行，而是通过std::async()在另一线程上操作
    std::future<std::list<T>> new_lower(std::async(&parallel_quick_sort<T>, std::move(lower_part)));
    auto new_higher(parallel_quick_sort(std::move(input)));    ⇽---  ②

    result.splice(result.end(),new_higher);    ⇽---  ③
    // 本例中变量new_lower的类型已不再是链表，而是std::future<std::list<T>>，因此，需要先通过get()取得其值，再调用splice()
    // 这将等待后台任务完成，并把结果转移进splice()。new_lower包含结果链表，而get()返回其右值引用，所以结果链表按移动方式向外返回
    result.splice(result.begin(),new_lower.get());    ⇽---  ④
    return result;
}
```


# 构建线程安全队列

代码4.2 `std::queue`接口

```c++
template <class T, class Container = std::deque<T> >
class queue {
public:
    explicit queue(const Container&);
    explicit queue(Container&& = Container());
    template <class Alloc> explicit queue(const Alloc&);
    template <class Alloc> queue(const Container&, const Alloc&);
    template <class Alloc> queue(Container&&, const Alloc&);
    template <class Alloc> queue(queue&&, const Alloc&);
    void swap(queue& q);
    bool empty() const;
    size_type size() const;
    T& front();
    const T& front() const;
    T& back();
    const T& back() const;
    void push(const T& x);
    void push(T&& x);
    void pop();
    template <class... Args> void emplace(Args&&... args);
};
```

假如忽略构造、赋值和互换，那么只剩下3组操作：

一是empty()和size()，用于查询队列的整体状态；

二是front()和back()，用于查询队列中的元素；

三是push()、pop()和emplace()，用于修改队列。

这与栈容器相似，其接口还是存在固有的条件竞争。所以，需要把front()和pop()合并成一个函数，这与栈容器的top()和pop()的合并十分相似。**要对外提供pop()的两个变体，try_pop()和wait_and_pop()：它们都试图弹出队首元素，前者总是立即返回，即便队列内空无一物（通过返回值示意操作失败）；后者会一直等到有数据压入可供获取。**依照前文的栈容器范例，借鉴其成员函数签名，则队列容器的接口看起来就像代码清单4.3所示的内容。

代码4.3 线程安全队列的接口

```c++
#include <memory>    ⇽---  ①为使用std::shared_ptr而包含此头文件
template<typename T>
class threadsafe_queue
{
public:
    threadsafe_queue();
    threadsafe_queue(const threadsafe_queue&);
    threadsafe_queue& operator=(const threadsafe_queue&) = delete;    ⇽---  ②为简化设计而禁止赋值操作
    void push(T new_value);
    bool try_pop(T& value);    ⇽---  ③
    std::shared_ptr<T> try_pop();    ⇽---  ④
    void wait_and_pop(T& value);
    std::shared_ptr<T> wait_and_pop();
    bool empty() const;
};
```

为了简化代码，删除了构造函数和赋值操作符，处理手法和栈容器相似。与代码清单4.2一样，**针对try_pop()和wait_for_pop()，都给出两个版本。在try_pop()的第一个重载中③，由参数所引用的变量保存获取的值，则函数能通过返回值指明操作成功与否：若成功获取值就返回true，否则返回false。函数的第二个重载④却无法做到这点，因为它直接返回获取的值。只不过，如果它没有获取值，则返回的指针会被设置成NULL。**

然而，以上这些与代码清单4.1有什么关联呢？其实，只要依据代码清单4.1，就可以写出push()和wait_and_pop()，如代码清单4.4所示。

代码4.4 从代码4.1中提取push()和wait_and_pop()

```c++
#include <queue>
#include <mutex>
#include <condition_variable>
template<typename T>
class threadsafe_queue {
private:
    std::mutex mut;
    std::queue<T> data_queue;
    std::condition_variable data_cond;
public:
    void push(T new_value)
    {
        std::lock_guard<std::mutex> lk(mut);
        data_queue.push(new_value);
        data_cond.notify_one();
    }
    void wait_and_pop(T& value)
    {
        std::unique_lock<std::mutex> lk(mut);
        data_cond.wait(lk, [this]{return !data_queue.empty();});
        value = data_queue.front();
        data_queue.pop();
    }
};

threadsafe_queue<data_chunk> data_queue;    ⇽---  ①
void data_preparation_thread()
{
    while(more_data_to_prepare())
    {
        data_chunk const data=prepare_data();
        data_queue.push(data);    ⇽---  ②
    }
}
void data_processing_thread()
{
    while(true)
    {
        data_chunk data;
        data_queue.wait_and_pop(data);    ⇽---  ③
        process(data);
        if(is_last_chunk(data)) break;
    }
}
```

这样互斥和条件变量就都包含在threadsafe_queue实例中了，而不必使用单独的变量①，push()的调用也无须与外部同步②。wait_and_pop()还负责处理条件变量上的等待③。

代码4.5 使用条件变量的线程安全队列(完整版)

```c++
#include <queue>
#include <memory>
#include <mutex>
#include <condition_variable>
template<typename T>
class threadsafe_queue
{
private:
    mutable std::mutex mut;    ⇽---  ①互斥必须用mutable修饰（针对const对象，准许其数据成员发生变动）
    std::queue<T> data_queue;
    std::condition_variable data_cond;
public:
    threadsafe_queue()
    {}
    threadsafe_queue(threadsafe_queue const& other)
    {
        std::lock_guard<std::mutex> lk(other.mut);
        data_queue=other.data_queue;
    }
    void push(T new_value)
    {
        std::lock_guard<std::mutex> lk(mut);
        data_queue.push(new_value);
        data_cond.notify_one();
    }
    void wait_and_pop(T& value)
    {
        std::unique_lock<std::mutex> lk(mut);
        data_cond.wait(lk,[this]{return !data_queue.empty();});
        value=data_queue.front();
        data_queue.pop();
    }
    std::shared_ptr<T> wait_and_pop()
    {
        std::unique_lock<std::mutex> lk(mut);
        data_cond.wait(lk,[this]{return !data_queue.empty();});
        std::shared_ptr<T> res(std::make_shared<T>(data_queue.front()));
        data_queue.pop();
        return res;
    }
    bool try_pop(T& value)
    {
        std::lock_guard<std::mutex> lk(mut);
        if(data_queue.empty())
            return false;
        value=data_queue.front();
        data_queue.pop();
        return true;
    }
    std::shared_ptr<T> try_pop()
    {
        std::lock_guard<std::mutex> lk(mut);
        if(data_queue.empty()) return std::shared_ptr<T>();
        std::shared_ptr<T> res(std::make_shared<T>(data_queue.front()));
        data_queue.pop();
        return res;
    }
    bool empty() const
    {
        std::lock_guard<std::mutex> lk(mut);
        return data_queue.empty();
    }
};
```

虽然empty()是const成员函数，拷贝构造函数的形参other也是const引用，但是其他线程有可能以非const形式引用队列容器对象，也可能调用某些成员函数，它们会改动数据成员，因此仍需锁定互斥。**由于互斥因锁操作而变化，因此它必须用关键字mutable修饰①，这样才可以在empty()函数和拷贝构造函数中锁定。**

```c++
mutex mtx;
condition_variable controlVal;

class Queue {
public:
    void put(int val) {
        unique_lock<mutex> lck(mtx);
        while (!que.empty()) {
            controlVal.wait(lck);
        }
        que.push(val);
        controlVal.notify_all();
        cout << "produce " << val << endl;
    }
    int get() {
        unique_lock<mutex> lck(mtx);
        while (que.empty()) {
            controlVal.wait(lck);
        }
        int val = que.front();
        que.pop();
        controlVal.notify_all();
        cout << "consume " << val << endl;
        return val;
    }
private:
    queue<int> que;
};

void producer(Queue *que) {
    for (int i = 1; i <= 10; i++) {
        que->put(i);
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}

void consumer(Queue *que){
    for (int i = 1; i <= 10; i++) {
        que->get();
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}
int main() {
    Queue que;

    thread t1(producer, &que);
    thread t2(consumer, &que);

    t1.join();
    t2.join();
}
```

# 限时等待

有两种超时（timeout）机制可供选用：一是迟延超时（duration-based timeout），线程根据指定的时长而继续等待（如30毫秒）；二是绝对超时（absolute timeout），在某特定时间点（time point）来临之前，线程一直等待。大部分等待函数都具有变体，专门处理这两种机制的超时。处理迟延超时的函数变体以_for为后缀，而处理绝对超时的函数变体以\_until为后缀。

例如，std::condition_variable含有成员函数wait_for()和wait_until()，它们各自具备两个重载，分别对应wait()的两个重载：其中一个重载停止等待的条件是收到信号、超时，或发生伪唤醒；需要向另一个重载函数提供断言，在对应线程被唤醒之时，只有该断言成立（向条件变量发送信号），它才会返回，如果超时，这个重载函数也会返回。

### 时钟

就C++标准库而言，时钟（clock）是时间信息的来源。具体来说，每种时钟都是一个类，提供4项关键信息：当前时刻；时间值的类型（从该时钟取得的时间以它为表示形式）；该时钟的计时单元的长度（tick period）；计时速率是否恒定，即能否将该时钟视为恒稳时钟（steady clock）。

若要获取某时钟类的当前时刻，调用其静态成员函数now()即可，例如，std::chrono::system_clock::now()可返回系统时钟的当前时刻。每个时钟类都具有名为time_point的成员类型（member type），它是该时钟类自有的时间点类。据此，some_clock::now()的返回值的类型就是some_clock::time_point。

时钟类的计时单元属于名为period的成员类型，它**表示为秒的分数形式**：若时钟每隔 1/25 秒计数1次(时钟每秒计数25次)，它的计时单元即为std::ratio<1,25>；若时钟每隔2.5秒计数1次，则其计时单元为std::ratio<5,2>。

假如计时单元的长短只有在运行期才可以确定，随着应用逐次运行，计时单元的长短会发生变化，那么它可以取平均长度，或可能实现的最小长度，也容许程序库作者另选合适的值。虽然时钟类设定了计时单元，但是这并不保证其长短与运行期实际观测的值一致。

若时钟的计时速率恒定（无论速率是否与计时单元相符）且无法调整，则称之为恒稳时钟。时钟类具有静态数据成员is_steady，该值在恒稳时钟内为true，否则为false。通常，std::chrono::system_clock类不是恒稳时钟，因为它可调整。即便这种调整自动发生，作用是消除本地系统时钟的偏差，依然可能导致：调用两次now()，后来返回的时间值甚至早于前一个，结果违反恒定速率的规定。

恒稳时钟对于超时时限的计算至关重要，因此，C++标准库提供了恒稳时钟类std::chrono::steady_clock。C++标准库还给出了其他时钟类：如前文提到的系统时钟类std::chrono::system_clock，该类表示系统的“真实时间”，它具备成员函数from_time_t()和to_time_t()，将time_t类型的值和自身的time_point值互相转化。

### 时间段

std::chrono::duration<>是标准库中最简单的时间部件（C++标准库用到不少处理时间的工具，它们全都位于名字空间std::chrono内）。它是类模板，具有两个模板参数，**前者指明采用何种类型表示计时单元的数量**（如int、long或double），**后者是一个分数，设定该时长类的每一个计时单元代表多少秒**。

例如，采用short值计数的分钟时长类是`std::chrono::duration<short, std::ratio<60,1>>`，因为1分钟包含60秒；采用double值计数的毫秒时长类是`std::chrono::duration<double, std::ratio<1, 1000>>`，因为1毫秒是1/1000秒。

标准库在std::chrono名字空间中，给出了一组预设的时长类的typedef声明：nanoseconds、microseconds、milliseconds、seconds、minutes和hours，分别对应纳秒、微秒、毫秒、秒、分钟、小时。它们都采用取值范围足够大的整型表示计数。

针对国际单位制的词头倍数，头文件`<ratio>`给出了它们的全部typedef声明，范围从std::atto（10−18）到std::exa（1018）（只要平台支持128位整型，范围可以更大）。它们可以用于自定义时长，如`std::duration<double, std::centi>`，其单元为百分秒，并以double值表示计数。



为方便起见，C++14引入了名字空间std::chrono_literals，其中预定义了一些字面量后缀运算符（literal suffix operator）。这能够缩短明文写入代码的时长值，举例如下。

```c++
using namespace std::chrono_literals;
auto one_day=24h;
auto half_an_hour=30min;
auto max_time_between_messages=30ms;
```

如果与整数字面值一起使用，这些后缀就相当于由typedef预设的时长类，因此，15ns和std::chrono::nanoseconds(15)是两个相等的值。然而，假如和浮点数字面值一起使用，这些后缀会按适当的量级创建出时长类，它以某种浮点值计数，但具体类型并不明确。因此，2.5min将具现化为`std::chrono::duration<some-floating-point-type, std::ratio <60, 1>>`。字面量后缀运算符由程序库实现自行选择具体的浮点类型，也随之决定了数值的范围和精度。如果读者认为这事关重大，就不应为了方便而使用字面量后缀运算符，而需手动构建时长对象，并以适合的数值类型表示计数。



隐式转换不能截断时长值，也就是，小时转化为秒是可行的，但秒转化为小时是不可行的。显式转换通过std::chrono::duration_cast<>完成。

```c++
std::chrono::milliseconds ms(54802);
std::chrono::seconds s = std::chrono::duration_cast<std::chrono::seconds>(ms);
```

上例的结果被截断，而非四舍五入，故此，时长变量s的值是54。



时长类支持算术运算，将时长乘或除以一个数值（这个数值与该时长类的计数类型相符，即其第一个模板参数），或对两个时长进行加减，就能得出一个新时长。所以，5\*seconds(1)等于seconds(5)，还等于minutes(1) −seconds(55)。

计时单元的数量可通过成员函数count()获取，因而std::chrono::milliseconds(1234).count()得到1234。



支持迟延超时的等待需要用到std::chrono::duration<>的实例。举例如下，等待某个future进入就绪状态，并以35毫秒为限。

```c++
std::future<int> f = std::async(some_task);
if(f.wait_for(std::chrono::milliseconds(35)) == std::future_status::ready) do_something_with(f.get());
```

所有等待函数都返回一个状态值，指明是否超时或目标事件是否已发生。上例中，借助future进行等待，所以一旦超时，函数就返回std::future_status::timeout；假如准备就绪，则函数返回std::future_status::ready；若future的相关任务被延后，函数返回std::future_status::deferred。

迟延超时的等待需要一个参照标准，它采用了标准库内部的恒稳时钟，只要代码指定了等待35毫秒，那现实中等待的时间就是35毫秒，即使期间系统时钟发生调整（无论提前还是延后）。当然，在形形色色的操作系统中，调度策略变化各异，且系统时钟精度互不相同，这就有可能导致从线程发起调用到函数返回，历时远超35毫秒。

### 时间点

在时钟类中，时间点由类模板std::chrono::time_point<>的实例表示，它的第一个模板参数指明所参考的时钟，第二个模板参数指明计时单元（std::chrono::duration<>的特化）。

时间点是一个时间跨度，始于一个称为时钟纪元的特定时刻，终于该时间点本身。跨度的值表示某具体时长的倍数。时钟纪元是一个基础特性，却无法直接查询，C++标准也未进行定义。典型的时钟纪元包括1970年1月1日0时0分0秒，或运行应用的计算机的启动时刻。多个时钟可能共享一个时钟纪元，也可能分别有各自的时钟纪元。

时钟类内部具有一个time_point成员类型的typedef。假设两个时钟类都参考同一个时钟纪元，则可用该typedef指定跟另一个时钟类共用的time_point成员类型。尽管时钟纪元的时刻无从得知，不过，可以在给定的时间点上调用time_since_epoch()，这个成员函数返回一个时长对象，表示从时钟纪元到该时间点的时间长度。

例如，可以用`std::chrono::time_point<std::chrono::system_clock, std::chrono::minutes>`指定一个时间点，它持有某个时刻，以系统时钟为参考，计时单元则为分钟。而原生的系统时钟精度通常是秒级别或者更精准的级别，这有别于该时间点。

可将时间点加减时长（即令std::chrono::time_point<>的实例加减std::chrono::duration<>实例），从而得出新的时间点。据此，std::chrono::high_resolution_clock::now() + std::chrono::nanoseconds(500)会给出500纳秒以后的未来时刻。只要知道运行某段代码所允许的最大时限，就能方便地计算出绝对超时的时刻。然而，假使代码自身所含的调用涉及等待函数，或者在等待函数之前存在非等待函数，则其都会占用一部分预算时间。

若两个时间点共享同一个时钟，也可以将它们相减，得到的结果是两个时间点间的时长。这能用于代码计时，举例如下。

```c++
auto start = std::chrono::high_resolution_clock::now();
do_something();
auto stop = std::chrono::high_resolution_clock::now();
std::cout<<"do_something() took "
  <<std::chrono::duration<double,std::chrono::seconds>(stop-start).count()
  <<" seconds"<<std::endl;
```

std::chrono::time_point<>实例的第一个模板参数是某时钟类，它除了间接指定时钟纪元，还有别的功能。等待函数若要处理绝对超时，则需接收时间点实例作为参数，该实例的相关时钟会用作参考，计算是否超时。一旦时钟被改动，将产生重大影响，因为等待会跟随时钟变化，若时钟的成员函数now()的返回值早于指定的时限，则等待函数不返回。如果时钟调快，等待所允许的总长度则有可能缩短（按恒稳时钟计算）；如果时钟调慢，允许的等待长度则有可能增加。

时间点用于带有后缀“\_until”的等待函数的变体。为了预先安排操作，需计算某一具体未来时刻（它对用户可见）。虽然可以用静态函数std::chrono::system_clock::to_time_point()转换time_t值，从而求出基于系统时钟的时间点，但其实最“地道”的方法是在程序代码中的某个固定位置，将some_clock::now()和前向偏移相加得出时间点。假定某目标事件与条件变量相关，若最多可以等待500毫秒，则实现代码可参考代码清单4.11。

代码4.11 等待条件变量满足条件——有超时功能

```c++
#include <condition_variable>
#include <mutex>
#include <chrono>
std::condition_variable cv;
bool done;
std::mutex m;
bool wait_loop() {
    auto const timeout = std::chrono::steady_clock::now() + std::chrono::milliseconds(500);
    std::unique_lock<std::mutex> lk(m);
    while(!done)  {
        if(cv.wait_until(lk, timeout) == std::cv_status::timeout) break;
    }
    return done;
}
```

条件变量之上的等待函数理应接收一个断言，借此判定所等的条件是否成立。假如读者不提供断言，则该函数只能依据是否超越时限来决定要继续等待还是要结束，那么，我推荐效仿上例的方式，这样就限定了循环的总耗时。否则，若凭借条件变量等待，却未传入断言，那么需不断循环来处理伪唤醒。

假设循环中使用的是wait_for()，那么，若在等待时间快消耗完时发生伪唤醒，而如果要再次等待，就得重新开始一次完整的迟延等待。这也许会不断重复，令等待变得漫无边际。

### 使用超时

超时时限的最简单用途是，推迟特定线程的处理过程，若它无所事事，就不会占用其他线程的处理时间。设立一个“完成”标志，在循环过程中反复查验，有两个函数可用于该例：std::this_thread::sleep_for()和std::this_thread::sleep_until()。它们的功能就像简单的闹钟：线程或采用sleep_for()按指定的时长休眠，或采用sleep_until()休眠直到指定时刻为止。

sleep_for()最适合4.1节的范例，原因是某些操作必须按周期执行，而其中的关键是耗时控制。另外，sleep_until()函数允许在特定的时刻唤醒线程。这可以用于触发夜间数据备份程序，或在早晨6:00运行工资单输出程序，或播放影像时在两帧画面的刷新之间暂停线程。

休眠并非唯一能处理超时的工具。超时时限可以配合条件变量，或配合future一起使用。只要互斥支持，在尝试给互斥加锁的时候，甚至也能设定超时时限。普通的std::mutex 和std::recursive_mutex不能限时加锁，但std::timed_mutex和std::recursive_timed_mutex可以。这两种锁都含有成员函数try_lock_for()和try_lock_until()，前者尝试在给定的时长内获取锁，后者尝试在给定的时间点之前获取锁。

表4.1列出了C++标准库中接受超时时限的函数，并说明了其参数和返回值。以duration列出的参数必须是std::duration<>的实例，而以time_point列出的参数必须是std::time_point<>的实例。

表4.1 可接受超时的函数

<table border=1>
  <td>类型/命名空间</td>
  <td>函数</td>
  <td>返回值</td>
<tr>
  <td rowspan=2> std::this_thread 命名空间 </td>
  <td> sleep_for(duration) </td>
  <td rowspan=2>N/A</td>
</tr>
<tr>
  <td>sleep_until(time_point)</td>
</tr>
<tr>
  <td rowspan = 2>std::condition_variable 或 std::condition_variable_any</td>
  <td>wait_for(lock, duration)</td>
  <td rowspan = 2>std::cv_status::time_out 或 std::cv_status::no_timeout</td>
</tr>
<tr>
  <td>wait_until(lock, time_point)</td>
</tr>
<tr>
  <td rowspan = 2> </td>
  <td> wait_for(lock, duration, predicate)</td>
  <td rowspan = 2>bool —— 当唤醒时，返回谓词的结果</td>
</tr>
<tr>
  <td>wait_until(lock, duration, predicate)</td>
</tr>
<tr>
  <td rowspan = 2>std::timed_mutex 或 std::recursive_timed_mutex</td>
  <td>try_lock_for(duration)</td>
  <td rowspan = 2> bool —— 获取锁时返回true，否则返回fasle</td>
</tr>
<tr>
  <td>try_lock_until(time_point)</td>
</tr>
<tr>
  <td rowspan = 2>std::unique_lock&lt;TimedLockable&gt;</td>
  <td>unique_lock(lockable, duration)</td>
  <td>N/A —— 对新构建的对象调用owns_lock();</td>
</tr>
<tr>
  <td>unique_lock(lockable, time_point)</td>
  <td>当获取锁时返回true，否则返回false</td>
</tr>
<tr>
  <td rowspan = 2></td>
  <td>try_lock_for(duration)</td>
  <td rowspan = 2>bool —— 当获取锁时返回true，否则返回false</td>
</tr>
<tr>
  <td>try_lock_until(time_point)</td>
</tr>
<tr>
  <td rowspan = 3>std::future&lt;ValueType&gt;或std::shared_future&lt;ValueType&gt;</td>
  <td>wait_for(duration)</td>
  <td>当等待超时，返回std::future_status::timeout</td>
</tr>
<tr>
  <td rowspan = 2>wait_until(time_point)</td>
  <td>当期望值准备就绪时，返回std::future_status::ready</td>
</tr>
<tr>
  <td>当期望值持有一个为启动的延迟函数，返回std::future_status::deferred</td>
</tr>
</table>

# 线程闩和线程卡

有时候，需要等待某些线程，待其运行到代码中某个特定的地方，或者等它们互相配合完成一定量的数据项的处理。比起future，这些情形更适合使用线程闩和线程卡，这两个特性由并发技术规约提出。

线程闩是一个同步对象，内含计数器，同一线程能令线程闩计数器多次减持，而多个线程也可分别令其计数器减持一次，或者两者兼有。一旦计数器减到 0，就会进入就绪状态，此时线程闩会对线程加闩，并保持封禁状态（只要它就绪，就一直保持该状态不变，除非对象被销毁）。因此，线程闩是一个轻量级工具，用于等待一系列目标事件发生。

相反地，线程卡是可重复使用的同步构件，针对一组给定的线程，在它们之间进行同步。在线程卡的每个同步周期内，只准许每个线程唯一一次运行到其所在之处。线程运行到线程卡处就会被阻塞，一直等到同组的线程全都抵达，在那个瞬间，它们会被全部释放。然后，这个线程卡可以被重新使用。在下一个同步周期中，同组的线程再度运行到该处而被阻塞，需再次等齐同组线程。

1. latch：使用，与future的区别，与barrier的区别
2. barrier：使用，API，与 flex 的区别

## latch

latch的构造函数接收唯一一个参数，在构建该类对象时，需通过这个参数设定其计数器的初值。接下来，每当等待的目标事件发生时，就在线程闩对象上调用count_down()，一旦计数器减到0，它就进入就绪状态。若要等待线程闩的状态变为就绪，则在其上调用wait()；若需检查其是否已经就绪，则调用is_ready()。最后，假如要使计数器减持，同时要等待它减到0，则应该调用count_down_and_wait()。

```c++
void foo() {
    unsigned const thread_count = ...;
    latch done(thread_count); // 依据需要等待的目标事件数目，先构建线程闩对象done
    my_data data[thread_count];
    std::vector<std::future<void>> threads;
    for(unsigned i = 0; i < thread_count; ++i)
        threads.push_back(std::async(std::launch::async, [&, i]{  // 用std::async()发起相同数量的线程
            data[i]=make_data(i);
            done.count_down();    // 各线程负责生成相关的数据块，在完成时即令计数器减持
            do_more_stuff();      // 然后进行下一步处理(各线程分别完成各自最后的处理步骤)
        }));
    done.wait();    // 主线程在处理生成的数据之前,只要在线程闩上等待
    process_data(data, thread_count);    // 就能等到全部数据准备完成，对数据进行整体处理
} // std::future的析构函数会发生自动调用，这保证了前面所启动的线程全都会结束运行。
```

传递给std::async()的lambda函数，除了按值捕获变量i，其他变量均按引用方式捕获。这么做的原因在于变量i是循环计数器，按引用方式捕获会导致数据竞争和未定义行为，但是却需共享访问变量data和变量done。

在本例所示的情形中，只需单独等待一个线程闩，因为**各线程将数据准备妥当以后，还需各自进行额外的处理**；否则，只要直接等待所有future就绪，也足以保证在数据的整体处理开始之前，生成数据的任务全都已经完成。

可以在process_data()的调用内安全地访问变量data。尽管它是由运行在其他线程上的任务存入的，但由于线程闩是一个同步对象，因此这就保证了若某线程调用count_down()，可以看到线程闩对象发生了变动，若其他线程在同一对象上调用了wait()，它们也照样看得到这些变动，并会因此结束wait()而返回。按正式规范，count_down()的调用会与wait()的调用同步。

## barrier

假定有一组线程在协同处理某些数据，各线程相互独立，分别处理数据，因此操作过程不必同步。但是，只有在全部线程都完成各自的处理后，才可以操作下一项数据或开始后续处理，barrier针对的就是这种场景。为了同步一组线程（synchronization group，下称同步组），创建线程卡，并指定参与同步的线程数目。线程在完成自身的处理后，就运行到线程卡处，通过在线程卡对象上调用arrive_and_wait()等待同步组的其他线程。只要组内最后一个线程也运行至此，所有线程即被释放，线程卡会自我重置。接着，同步组的线程视具体情况各自继续，或处理下一项数据，或进行下一阶段的处理。

线程闩的意义在于关闸拦截：一旦它进入了就绪状态，就始终保持不变。而线程卡则不同，线程卡会释放等待的线程并且自我重置，因此它们可重复使用。另外，线程卡只与一组固定的线程同步，若某线程不属于同步组，它就不会被阻拦，亦无须等待相关的线程卡变为就绪。只要在线程卡上调用arrive_and_drop()，即可令线程显式地脱离其同步组，那样，它就再也无法被阻拦，因此也不能等待线程卡进入就绪状态，并且，在下一个同步周期中，必须运行到该线程卡处的线程数目（阻拦数目）要比当前周期少1。

```c++
result_chunk process(data_chunk);
std::vector<data_chunk> divide_into_chunks(data_block data, unsigned num_threads);

void process_data(data_source& source, data_sink& sink) {
  unsigned const concurrency = std::thread::hardware_concurrency();
  unsigned const num_threads = (concurrency > 0) ? concurrency : 2;

  barrier sync(num_threads);
  std::vector<joining_thread> threads(num_threads);

  std::vector<data_chunk> chunks;
  result_block result;
  // 为了充分利用系统中的并发资源，将每个大数据块都切分成num_thread个小段
  for (unsigned i = 0; i < num_threads; ++i) {
    threads[i] = joining_thread([&, i] { // joining_thread 创建线程，运行 lambda 函数
      while (!source.done()) { // 全部线程都不断循环，直到source报告全部工作都已完成
        if (!i) { // 切分动作须以串行方式完成，最开始的大数据块只会在0号线程上运行（i==0）
          data_block current_block = source.get_next_data_block();
          chunks = divide_into_chunks(current_block, num_threads);
        }
        // 两个arrive_and_wait()调用所在的位置很重要，它们保证全部线程都已到达，否则任何线程都不能继续前行
        // 通过线程卡给出了清晰的界限，其他所有线程都在该处等待0号线程
        sync.arrive_and_wait(); 
        // 直到这些串行代码执行完毕，才进入并行区域，各线程独立处理其数据小段并更新结果
        result.set_chunk(i, num_threads, process(chunks[i]));  
        // 随即再次同步，0号线程在该处等待其他线程，只有它们全部到达，它才可将完成的结果写到sink
        sync.arrive_and_wait();   
        if (!i) sink.write_data(std::move(result)); // 0号线程将结果写到sink
      }
    });
  }
}  // 一旦完成全部处理，所有线程都会退出循环，而在process_data()函数的末尾
// joining_thread对象的析构函数将静候这些线程结束运行，进而进行清理，joining_thread详见代码清单2.7
```

请注意，随着各线程共同不断循环，while()内首尾两部分的串行区域①⑤会接合起来。由于只有0号线程会在该处工作，因此程序整体上依然并发运行，所有线程都会在第一个线程卡处彼此同步②。

## flex_barrier

flex_barrier类的接口与barrier类的不同之处仅仅在于：前者具备另一个构造函数，其参数既接收线程的数目，还接收补全函数。只要全部线程都运行到线程卡处，该函数就会在其中一个线程上运行（并且是唯一一个）。它不但提供了机制，可以设定后续代码，令其必须按串行方式运行，还给出了方法，用于改变下一同步周期须到达该处的线程数目（所阻拦的线程数目）。线程卡的计数器可以调整为任何数目，比原来大或小皆可。若程序员要采用这个特性，则需自行决定准确的线程数目，令相应数目的线程在下一周期运行至该处。

```c++
void process_data(data_source &source, data_sink &sink) {
  unsigned const concurrency = std::thread::hardware_concurrency();
  unsigned const num_threads = (concurrency > 0) ? concurrency : 2;

  std::vector<data_chunk> chunks;
  // 提取出一个lambda函数，其内部封装了循环的开头部分的代码，它们原本由0号线程运行，功能是将下一个大块数据切分成小段
  auto split_source = [&] { 
    if (!source.done()) { // 第一次调用时切分的就是第一个大数据块
      data_block current_block = source.get_next_data_block();
      chunks = divide_into_chunks(current_block, num_threads);
    }
  };

  split_source(); // 在主循环开始前，该lambda函数就先被调用一次，因此其它线程就不必等待 0 线程

  result_block result;
  // 对象sync的类型已被改成std::experimental::flex_barrier，需向构造函数传入线程数目和补全函数
  // 当各个线程都到达线程卡后，它们当中的一个就会运行补全函数
  flex_barrier sync(num_threads, [&] {   
    sink.write_data(std::move(result)); // 循环结尾的代码也封装在补全函数内随之运行，这些代码原本由0号线程负责
    split_source();  // 程序调用前面新提取出来的lambda函数split_source()，它原本要在下一轮循环中运行
    return -1;// 若返回值是-1，就说明参与同步的线程保持数目不变；若返回值是0或正数，则将其作为指标，设定参与下一同步周期的线程数目。
  });
  std::vector<joining_thread> threads(num_threads);

  for (unsigned i = 0; i < num_threads; ++i) {
    threads[i] = joining_thread([&, i] {
      while (!source.done()) {    // 主循环得到了简化
        result.set_chunk(i, num_threads, process(chunks[i]));
        sync.arrive_and_wait();   // 它只含有并行代码，因而只需要一个同步点
      }
    });
  }
}
```

