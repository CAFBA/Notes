# std::jthread and Stop Tokens
## Motivation for std::jthread
### The Problem of std::thread
```cpp
void foo()
{
...
// start thread calling task() with name and val as arguments:
std::thread t{task, name, val};
... // neither t.join() nor t.detach() called
} // std::terminate() called
```

```cpp
void foo()
{
...
// start thread calling task() with name and val as arguments:
std::thread t{task, name, val};
... // calls std::terminate() on exception
// wait for tasks to finish:
t.join();
...
}
```


```cpp
void foo()
{
...
// start thread calling task() with name and val as arguments:
std::thread t{task, name, val};
try {
... // might throw an exception
}
catch (...) { // if we have an exception
// clean up the thread started:
t.join(); // - wait for thread (blocks until done)
throw; // - and rethrow the caught exception
}
// wait for thread to finish:
t.join();
...
}

```


```cpp
void foo()
{
...
// start thread calling task1() with name and val as arguments:
12.1 Motivation for std::jthread 405
std::thread t1{task1, name, val};
std::thread t2;
try {
// start thread calling task2() with name and val as arguments:
t2 = std::thread{task2, name, val};
...
}
catch (...) { // if we have an exception
// clean up the threads started:
t1.join(); // wait for first thread to end
if (t2.joinable()) { // if the second thread was started
t2.join(); // - wait for second thread to end
}
throw; // and rethrow the caught exception
}
// wait for threads to finish:
t1.join();
t2.join();
...
}

```

#### Using std::jthread
```cpp
void foo()
{
...
// start thread calling task1() with name and val as arguments:
std::jthread t1{task1, name, val};
// start thread calling task2() with name and val as arguments:
std::jthread t2{task2, name, val};
...
406 Chapter 12: std::jthread and Stop Tokens
// wait for threads to finish:
t1.join();
t2.join();
...
}
```

#### Stop Tokens and Stop Callbacks
```cpp
• If the callable only provides parameters for all passed arguments, the request to stop would be ignored:
void task (std::string s, double value)
{
... // join() waits until this code ends
}
• To react to the stop request, the callable can add a new optional first parameter of type std::stop_token
and check from time to time whether a stop was requested:
void task (std::stop_token st,
std::string s, double value)
{
while (!st.stop_requested()) { // stop requested (e.g., by the destructor)?
... // ensure we check from time to time
}
}
```


```cpp
void foo()
{
...
// start thread calling task() with name and val as arguments:
std::jthread t{task, name, val};
...
if ( ... ) {
t.request_stop(); // explicitly request task() to stop its execution
}
...
// wait for thread to finish:
t.join();
...
}
```


```cpp
void task (std::stop_token st,
std::string s, double value)
{
std::stop_callback cb{st, [] {
... // called on a stop request
}};
...
}
```

#### Stop Tokens and Condition Variables
```cpp
#include <iostream>
#include <queue>
#include <thread>
#include <stop_token>
#include <mutex>
#include <condition_variable>
using namespace std::literals; // for duration literals
int main()
{
std::queue<std::string> messages;
std::mutex messagesMx;
std::condition_variable_any messagesCV;
// start thread that prints messages that occur in the queue:
std::jthread t1{[&] (std::stop_token st) {
while (!st.stop_requested()) {
std::string msg;
{
// wait for the next message:
std::unique_lock lock(messagesMx);
if (!messagesCV.wait(lock, st,
[&] {
return !messages.empty();
})) {
return; // stop requested
}
// retrieve the next message out of the queue:
msg = messages.front();
messages.pop();
}
// print the next message:
std::cout << "msg: " << msg << std::endl;
}
}};
12.1 Motivation for std::jthread 409
// store 3 messages and notify one waiting thread each time:
for (std::string s : {"Tic", "Tac", "Toe"}) {
std::scoped_lock lg{messagesMx};
messages.push(s);
messagesCV.notify_one();
}
// after some time
// - store 1 message and notify all waiting threads:
std::this_thread::sleep_for(1s);
{
std::scoped_lock lg{messagesMx};
messages.push("done");
messagesCV.notify_all();
}
// after some time
// - end program (requests stop, which interrupts wait())
std::this_thread::sleep_for(1s);
}

```


```cpp
while (!st.stop_requested()) {
std::string msg;
{
// wait for the next message:
std::unique_lock lock(messagesMx);
if (!messagesCV.wait(lock, st,
[&] {
return !messages.empty();
})) {
return; // stop requested
}
// retrieve the next message out of the queue:
msg = messages.front();
messages.pop();
}
// print the next message:
std::cout << "msg: " << msg << std::endl;
}
```
## Stop Sources and Stop Tokens

```cpp
#include <stop_token>
...
// create stop_source and stop_token:
std::stop_source ssrc; // creates a shared stop state
std::stop_token stok{ssrc.get_token()}; // creates a token for the stop state

```

### Stop Sources and Stop Tokens in Detail
```cpp
std::stop_source ssrc{std::nostopstate}; // no associated shared stop state
...
ssrc = std::stop_source{}; // assign new shared stop state
```
### Using Stop Callbacks

```cpp
void task(std::stop_token st)
{
// register temporary callback:
std::stop_callback cb{st, []{
std::cout << "stop requested\n";
...
}};
...
} // unregisters callback
```


```cpp
// create stop_source with associated stop state:
std::stop_source ssrc;
// register/start task() and pass the corresponding stop token to it:
registerOrStartInBackgound(task, ssrc.get_token());
...

```


```cpp
#include <iostream>
#include <stop_token>
#include <future> // for std::async()
#include <thread> // for sleep_for()
#include <syncstream> // for std::osyncstream
#include <chrono>
using namespace std::literals; // for duration literals
auto syncOut(std::ostream& strm = std::cout) {
return std::osyncstream{strm};
}
void task(std::stop_token st, int num)
{
auto id = std::this_thread::get_id();
syncOut() << "call task(" << num << ")\n";
12.2 Stop Sources and Stop Tokens 415
// register a first callback:
std::stop_callback cb1{st, [num, id]{
syncOut() << "- STOP1 requested in task(" << num
<< (id == std::this_thread::get_id() ? ")\n"
: ") in main thread\n");
}};
std::this_thread::sleep_for(9ms);
// register a second callback:
std::stop_callback cb2{st, [num, id]{
syncOut() << "- STOP2 requested in task(" << num
<< (id == std::this_thread::get_id() ? ")\n"
: ") in main thread\n");
}};
std::this_thread::sleep_for(2ms);
}
int main()
{
// create stop_source and stop_token:
std::stop_source ssrc;
std::stop_token stok{ssrc.get_token()};
// register callback:
std::stop_callback cb{stok, []{
syncOut() << "- STOP requested in main()\n" << std::flush;
}};
// in the background call task() a bunch of times:
auto fut = std::async([stok] {
for (int num = 1; num < 10; ++num) {
task(stok, num);
}
});
// after a while, request stop:
std::this_thread::sleep_for(120ms);
ssrc.request_stop();
}

```


```cpp
auto func = [] { ... };
std::stop_callback cb{myToken, func}; // deduces stop_callback<decltype(func)>
```


```cpp
auto func = [] { ... };
std::stop_callback cb1{myToken, func}; // copies func
std::stop_callback cb2{myToken, std::move(func)}; // moves func
std::stop_callback cb3{myToken, [] { ... }}; // moves the lambda
```
### Constraints and Guarantees of Stop Tokens
## std::jthread in Detai
### Using Stop Tokens with std::jthread
```cpp
std::jthread t1{[] (std::stop_token st) {
...
}};
...
foo(t1.get_token()); // pass stop token to foo()
...
std::stop_source ssrc{t1.get_stop_source()};
ssrc.request_stop(); // request stop on stop token of t1
```


```cpp
{
std::vector<std::jthread> threads;
for (int i = 0; i < numThreads; ++i) {
pool.push_back(std::jthread{[&] (std::stop_token st) {
while (!st.stop_requested()) {
...
}
}});
}
...
} // destructor stops all threads
```


```cpp
for (auto& t : threads) {
t.request_stop();
t.join();
}

```


```cpp
{
std::vector<std::jthread> threads;
for (int i = 0; i < numThreads; ++i) {
pool.push_back(std::jthread{[&] (std::stop_token st) {
while (!st.stop_requested()) {
...
}
}});
}
...
// BETTER: request stops for all threads before we start to join them:
for (auto& t : threads) {
t.request_stop();
}
} // destructor stops all threads
```


```cpp
// initialize a common stop token for all threads:
std::stop_source allStopSource;
std::stop_token allStopToken{allStopSource.get_token()};
for (int i = 0; i < 9; ++i) {
threads.push_back(std::jthread{[] (std::stop_token st) {
...
while (!st.stop_requested()) {
...
}
},
allStopToken // pass token to this thread
});
}

```
# Concurrency Features
## Thread Synchronization with Latches and Barriers
### Latches
```cpp
#include <iostream>
#include <array>
#include <thread>
#include <latch>
423
424 Chapter 13: Concurrency Features
using namespace std::literals; // for duration literals
void loopOver(char c) {
// loop over printing the char c:
for (int j = 0; j < c/2; ++j) {
std::cout.put(c).flush();
std::this_thread::sleep_for(100ms);
}
}
int main()
{
std::array tags{'.', '?', '8', '+', '-'}; // tags we have to perform a task for
// initialize latch to react when all tasks are done:
std::latch allDone{tags.size()}; // initialize countdown with number of tasks
// start two threads dealing with every second tag:
std::jthread t1{[tags, &allDone] {
for (unsigned i = 0; i < tags.size(); i += 2) { // even indexes
loopOver(tags[i]);
// signal that the task is done:
allDone.count_down(); // atomically decrement counter of latch
}
...
}};
std::jthread t2{[tags, &allDone] {
for (unsigned i = 1; i < tags.size(); i += 2) { // odd indexes
loopOver(tags[i]);
// signal that the task is done:
allDone.count_down(); // atomically decrement counter of latch
}
...
}};
...
// wait until all tasks are done:
std::cout << "\nwaiting until all tasks are done\n";
allDone.wait(); // wait until counter of latch is zero
std::cout << "\nall tasks done\n"; // note: threads might still run
...
}

```


```cpp
• We initialize a latch with the number of tags/tasks:
std::latch allDone{tags.size()};
• We let each task decrement the counter when it is done:
allDone.count_down();
• We let the main thread wait until all tasks are done (the counter is zero):
allDone.wait();

```


```cpp
#include <iostream>
#include <array>
#include <vector>
#include <thread>
#include <latch>
using namespace std::literals; // for duration literals
int main()
{
std::size_t numThreads = 10;
// initialize latch to start the threads when all of them have been initialized:
std::latch allReady = 10; // initialize countdown with number of threads
1 Thanks to Anthony Williams for describing this scenario.
426 Chapter 13: Concurrency Features
// start numThreads threads:
std::vector<std::jthread> threads;
for (int i = 0; i < numThreads; ++i) {
std::jthread t{[i, &allReady] {
// initialize each thread (simulate to take some time):
std::this_thread::sleep_for(100ms * i);
...
// synchronize threads so that all start together here:
allReady.arrive_and_wait();
// perform whatever the thread does
// (loop printing its index):
for (int j = 0; j < i + 5; ++j) {
std::cout.put(static_cast<char>('0' + i)).flush();
std::this_thread::sleep_for(50ms);
}
}};
threads.push_back(std::move(t));
}
...
}

```


```cpp
• We initialize the latch with the number of threads:
std::latch allReady{numThreads};
• We let each thread decrement the counter to wait until the initialization of all threads is done:
allReady.arrive_and_wait(); // count_down() and wait()
```


```cpp
std::latch l1{10}; // OK
std::latch l2{10u}; // warnings may occur
std::vector<int> coll{ ... };
...
std::latch l3{coll.size()}; // ERROR
std::latch l4 = coll.size(); // ERROR
std::latch l5(coll.size()); // OK (no narrowing checked)
std::latch l6{int(coll.size())}; // OK
std::latch l7{ssize(coll)}; // OK (see std::ssize())
```
### Barriers

```cpp
#include <iostream>
#include <format>
#include <vector>
#include <thread>
#include <cmath>
#include <barrier>
int main()
{
// initialize and print a collection of floating-point values:
std::vector values{1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0};
// define a lambda function that prints all values
// - NOTE: has to be noexcept to be used as barrier callback
auto printValues = [&values] () noexcept{
for (auto val : values) {
std::cout << std::format(" {:<7.5}", val);
}
std::cout << '\n';
};
// print initial values:
printValues();
// initialize a barrier that prints the values when all threads have done their computations:
std::barrier allDone{int(values.size()), // initial value of the counter
printValues}; // callback to call whenever the counter is 0
// initialize a thread for each value to compute its square root in a loop:
std::vector<std::jthread> threads;
for (std::size_t idx = 0; idx < values.size(); ++idx) {
threads.push_back(std::jthread{[idx, &values, &allDone] {
// repeatedly:
for (int i = 0; i < 5; ++i) {
// compute square root:
values[idx] = std::sqrt(values[idx]);
// and synchronize with other threads to print values:
allDone.arrive_and_wait();
}
}});
}
...
}

```


```cpp
// initialize and print a collection of floating-point values:
std::vector values{1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0};
// define a lambda function that prints all values
// - NOTE: has to be noexcept to be used as barrier callback
auto printValues = [&values] () noexcept{
for (auto val : values) {
std::cout << std::format(" {:<7.5}", val);
}
std::cout << '\n';
};

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```

