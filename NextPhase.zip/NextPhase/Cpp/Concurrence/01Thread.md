# Thread

1. thread：线程持有函数局部变量的指针或引用解决办法
2. join/detach：含义，作用，joinable，RAII
3. 传递参数：传递方式，ref，成员函数
4. 转移所有权：意义，赋值操作，一组线程
5. joining_thread的实现
6. thread::id：两个 API，应用方式

## std::thread

使用C++线程库启动线程，就是构造`std::thread`对象：

```c++
void do_some_work();
std::thread my_thread(do_some_work);
```

当把函数对象传入到线程构造函数中时，需要避免语法解析，如果你传递了一个临时变量，而不是一个命名的变量。C++编译器会将其解析为函数声明，而不是类型对象的定义。为此需要使用在前面命名函数对象的方式，或使用多组括号，或使用统一的初始化语法。

```c++
class background_task  {
public:
  void operator()() const {
    do_something();
    do_something_else();
  }
};

background_task f;
std::thread my_thread(f); // 传入命名变量

std::thread my_thread(background_task()); // error，传入临时变量

std::thread my_thread((background_task()));  
std::thread my_thread{background_task()};    
std::thread my_thread([]{
  do_something();
  do_something_else();
});
```

线程启动后是要等待线程结束，还是让其自主运行。如果当`std::thread`对象销毁之前还没有做出决定，程序就会终止(`std::thread`的析构函数会调用`std::terminate()`)，若此时产生异常将因为程序终止无法捕获。因此需要确保线程能够正确汇入(joined)或分离(detached)。如果不等待线程汇入，就必须保证线程结束之前，访问数据的有效性。

单线程代码中，对象销毁之后再去访问，也会产生未定义行为，不过，线程的生命周期增加了这个问题发生的几率。这种情况很可能发生在线程还没结束，**函数已经退出的时候，这时线程函数还持有函数局部变量的指针或引用**：

```c++
struct func {
  int& i;
  func(int& i_) : i(i_) {}
  void operator()() {
    for (unsigned j = 0; j < 1000000; ++j) do_something(i);           // 潜在访问隐患：空引用
  }
};

void oops() {
  int some_local_state=0;
  func my_func(some_local_state);
  std::thread my_thread(my_func);
  my_thread.detach();          // 不等待线程结束
}                              // 新线程可能还在运行
```

代码中，已经决定不等待线程(使用了detach())，所以当oops()函数执行完成时，线程中的函数可能还在运行。如果线程还在运行，就会去调用do\_something(i)，这时就会访问已经销毁的变量。如同一个单线程程序——允许在函数完成后继续持有局部变量的指针或引用。当然，这种情况发生时，错误并不明显，会使多线程更容易出错。有两种处理方式：

- 将数据复制到线程中。如果使用一个可调用的对象作为线程函数，这个对象就会复制到线程中，而后原始对象会立即销毁，但对于对象中包含的指针和引用还需谨慎。**使用访问局部变量的函数去创建线程是一个糟糕的主意。**

- 可以通过join\(\)函数来**确保线程在主函数完成前结束**，就可以确保局部变量在线程完成后才销毁。

只要调用了join()，隶属于该线程的任何存储空间即会因此清除，std::thread对象遂不再关联到已结束的线程，因此对于某个给定的线程，join()仅能调用一次，只要std::thread对象曾经调用过join()，线程就不再可汇合（joinable），成员函数joinable()将返回false。

## join()

在std::thread对象被销毁前，需确保已经调用join()或detach()。通常，若要分离线程，在线程启动后调用detach()即可，这不成问题。然而，假使打算等待线程结束，则需小心地选择执行代码的位置来调用join()。原因是，**如果线程启动以后有异常抛出，而join()尚未执行，则该join()调用会被略过**。

假如代码必须确保新线程先行结束，之后当前线程的函数才退出（无论是因为新线程持有引用，指向函数内的局部变量，还是其他缘故），那么关键就在于，全部可能的退出路径都必须保证这种先后次序，无论是正常退出，还是抛出异常。

因此就算出现了异常，同样需要调用join()，以避免意外的生存期问题。为达成前面的目标，运用标准的RAII手法，在其析构函数中调用join()：

```c++
class thread_guard {
    std::thread& t;
public:
    explicit thread_guard(std::thread& t_): t(t_) {}
    ~thread_guard() {
        if(t.joinable()) t.join(); 
    }
    thread_guard(thread_guard const&)=delete;
    thread_guard& operator=(thread_guard const&)=delete;
}; 
struct func; 
void f() {
    int some_local_state=0;
    func my_func(some_local_state);
    std::thread t(my_func);
    thread_guard g(t);
    do_something_in_current_thread();
}
```

当主线程执行到f()末尾时，按构建的逆序，全体局部对象都会被销毁。因此类型thread_guard的对象g首先被销毁，在其析构函数中，新线程汇合。即便do_something_in_current_thread()抛出异常，函数f()退出，以上行为仍然会发生。

thread_guard的析构函数先调用joinable()，判别std::thread对象能否汇合，接着才调用join()。该检查必不可少，因为在任何执行线程上，join()只能被调用一次，假若线程已经汇合过，那么再次调用join()则是错误行为。

复制构造函数和复制赋值操作符都以“=delete”标记，限令编译器不得自动生成相关代码。复制这类对象或向其赋值均有可能带来问题，因为所产生的新对象的生存期也许更长，甚至超过了与之关联的线程。在销毁原对象和新对象时，分别发生两次析构，将重复调用join()。只要把它们声明为删除函数，试图复制thread_guard对象就会产生编译错误。

## detach()

若不需要等待线程结束，可以将其分离，从而防止异常引发的安全问题。分离操作会切断线程和std::thread对象间的关联。这样，std::thread对象在销毁时肯定不调用std::terminate()，即便线程还在后台运行，也不会调用，因此能够正常捕获异常。

调用std::thread对象的成员函数detach()，会令线程在后台运行，遂无法与之直接通信。假若线程被分离，就无法等待它完结，也不可能获得与它关联的std::thread对象，因而无法汇合该线程。然而分离的线程确实仍在后台运行，其归属权和控制权都转移给C++运行时库（runtime library，又名运行库），由此保证，一旦线程退出，与之关联的资源都会被正确回收。

若要分离线程，则需在std::thread对象上调用其成员函数detach()。调用完成后，std::thread对象不再关联实际的执行线程，故它变得从此不可汇合。

```c++
std::thread t(do_background_work);
t.detach();
assert(!t.joinable());
```

如果要把std::thread对象和线程分离，就必须存在与其关联的执行线程：若没有与其关联的执行线程，便不能在std::thread对象上凭空调用detach()。这与调用join()的前提条件毫无二致，检查方法完全相同，只有当t.joinable()返回true时，才能调用t.detach()。

## 传递参数

若需向新线程上的函数或可调用对象传递参数，方法相当简单，直接向std::thread的构造函数增添更多参数即可。不过线程具有内部存储空间，参数会按照默认方式先复制到该处，新创建的执行线程才能直接访问它们。然后，**这些副本被当成临时变量，以右值形式传给新线程上的函数或可调用对象**。即便函数的相关参数按设想应该是引用，上述过程依然会发生。例如：

```c++
void f(int i, std::string const& s);
std::thread t(f, 3, "hello");
```

这两行代码借由构造对象t新创建一个执行线程，它们互相关联，并在新线程上调用f(3, "hello")。尽管函数f()的第二个参数属于std::string类型，但字符串的字面内容仍以指针char const*的形式传入，进入新线程的上下文环境以后，才转换为std::string类型。如果参数是指针，并且指向自动变量，那么这一过程会产生非常重大的影响，举例说明：

```c++
void f(int i, std::string const& s);
void oops(int some_param) {
    char buffer[1024];                  //    ⇽---  ①
    sprintf(buffer, "%i", some_param);
    std::thread t(f, 3, buffer);          //    ⇽---  ②
    // std::thread t(f, 3, std::string(buffer)); // 使用std::string避免悬空指针
    t.detach();
}
```

在本例中，向新线程②传递的是指针buffer，指向一个局部数组变量①。原本设想，buffer会在新线程内转换成std::string对象，但在此完成之前，oops()函数极有可能已经退出，导致局部数组被销毁而引发未定义行为。这一问题的根源在于：本来希望将指针buffer隐式转换成std::string对象，再将其用作函数参数，可惜转换未能及时发生，原因是**std::thread 的构造函数原样复制所提供的值，没有令其转换为预期的参数类型，即只是按照实参的类型进行复制**。解决方法是，在buffer传入std::thread的构造函数之前，就把它转化成std::string对象。

考虑函数参数列表中有非 const 引用：

```c++
void update_data_for_widget(widget_id w, widget_data& data); 
void oops_again(widget_id w) {
    widget_data data;
    std::thread t(update_data_for_widget, w, data); 
    display_status();
    t.join();
    process_widget_data(data);
}
```

根据update_data_for_widget()函数的声明，第二个参数会以引用方式传入，可是std::thread的构造函数对此却并不知情，它全然忽略update_data_for_widget()函数所期望的参数类型，直接复制提供的值。然而，线程库的内部代码会把参数的副本当成move-only型别（只能移动，不可复制），并以右值的形式传递。最终，update_data_for_widget()函数调用会收到一个右值作为参数。这段代码会编译失败。因为update_data_for_widget()预期接受非const引用，不能向它传递右值。

对于这种**必须按引用方式传递参数**，需要用std::ref()函数加以包装即可。把创建线程的语句改写成：

```c++
// update_data_for_widget 第二个参数类型是引用，而不是指针，因此必须使用 ref 转化
// 对于下一个例子来说，由于成员函数有隐式参数 this，因此传入的是指针，不用 ref
std::thread t(update_data_for_widget, w, std::ref(data)); 
```

这样传入update_data_for_widget()函数的就不是变量data的临时副本，而是指向变量data的引用，代码遂能成功编译。

类似这种**需要传入引用的情况**是将某个类的成员函数设定为线程函数，则应传入一个函数指针，指向该成员函数，还要给出合适的对象指针，作为该函数的第一个参数，即 this：

```c++
class X {
public:
    void do_lengthy_work();
};
X my_x;
std::thread t(&X::do_lengthy_work, &my_x); // 类似于 bind，均应用于成员函数的情况，因为成员函数有隐式参数 this
```

上述对象指针由my_x的地址充当，这段代码将它传递给std::thread的构造函数，因此新线程会调用my_x.do_lengthy_work()。还能为成员函数提供参数：若给std::thread的构造函数增添第3个参数，则它会传入成员函数作为第1个参数，以此类推。

## 转移所有权

C++11引入了另一种传递参数的方式：参数只能移动但不能复制，即数据从某个对象转移到另一个对象内部，而原对象则被搬空。若原对象是临时变量，移动就会自动发生。若原对象是具名变量，则必须通过调用std::move()直接请求转移。下面示范了std::move()函数的用法，借助它向线程转移动态对象的归属权：

```c++
void process_big_object(std::unique_ptr<big_object>);
std::unique_ptr<big_object> p(new big_object);
p->prepare_data(42);
std::thread t(process_big_object, std::move(p)); // 不会复制到线程的内部存储空间，直接移动给 process_big_object
```

在调用std::thread的构造函数时，依据std::move(p)所指定的操作，big_object对象的归属权会发生转移，先进入新创建的线程的内部存储空间，再转移给process_big_object()函数。、

虽然std::thread类的实例并不拥有动态对象（这与std::unique_ptr不同），但它们拥有另一种资源：每份实例都负责管控一个执行线程。因为std::thread类的实例能够移动却不能复制，故此线程的归属权可以在其实例之间转移。这就保证了，**对于任一特定的执行线程，任何时候都只有唯一的std:::thread对象与之关联，还准许程序员在其对象之间转移线程归属权**。

假设通过新线程返回的所有权去调用一个需要后台启动线程的函数，并需要在函数中转移线程的所有权。这些操作都要等待线程结束才能进行，并且需要线程的所有权能够进行转移。下面将展示一个例子。例子中，创建了两个执行线程，并在`std::thread`实例之间\(t1，t2和t3\)转移所有权：

```c++
void some_function();
void some_other_function();
std::thread t1(some_function);             
std::thread t2 = std::move(t1);            
t1 = std::thread(some_other_function);     // 创建临时对象，自动转移所有权给 t1
```

新线程与t1相关联。当显式使用`std::move()`创建t2后，t1的所有权就转移给了t2。之后，t1和执行线程已经没有关联了，执行some\_function的函数线程与t2关联。然后，临时`std::thread`对象相关的线程启动了。为什么不显式调用`std::move()`转移所有权呢？因为，所有者是一个临时对象——移动操作将会隐式的调用。

```c++
std::thread t3;                           
t3 = std::move(t2);                        
t1 = std::move(t3);                        // 赋值操作将使程序崩溃
```

t3使用默认构造方式创建，没有与任何线程进行关联。调用`std::move()`将t2关联线程的所有权转移到t3中。因为t2是一个命名对象，需要显式的调用`std::move()`。移动操作完成后，t1与执行some\_other\_function的线程相关联，t2与任何线程都无关联，t3与执行some\_function的线程相关联。

最后一个移动操作，将some\_function线程的所有权转移给t1。不过，t1已经有了一个关联的线程\(执行some\_other\_function的线程\)，所以这里系统直接调用`std::terminate()`终止程序继续运行。这样做(不抛出异常，`std::terminate()`是noexcept)函数\)是为了保证与`std::thread`的析构函数的行为一致。需要在线程对象析构前，显式的等待线程完成，或者分离它，进行赋值时也需要满足这些条件(不能通过赋新值给`std::thread`对象的方式来丢弃一个线程\)。

```c++
// 线程的所有权可以在函数外进行转移
std::thread g() {
  void some_other_function(int);
  std::thread t(some_other_function, 42);
  return t;
}
// 所有权可以在函数内部传递
void f(std::thread t);
void g() {
  void some_function();
  f(std::thread(some_function));
  std::thread t(some_function);
  f(std::move(t));
}
```

`std::thread`中对移动语义的支持，也适用于使用`std::thread`的**移动敏感**(move-aware)容器(比如，`std::vector<>`)，可以量产一些线程，并且等待它们结束。将`std::thread`放入`std::vector`是向线程自动化管理迈出的第一步：并非为这些线程创建独立的变量，而是把它们当做一个组。创建一组线程\(数量在运行时确定\)，而非创建固定数量的线程。

```c++
void do_work(unsigned id);
void f() {
  std::vector<std::thread> threads;
  for (unsigned i = 0; i < 20; ++i) threads.emplace_back(do_work,i); // 产生线程
  for (auto& entry : threads) entry.join();       // 对每个线程调用 join()
}
```

## scoped_thread

scoped_thread 的首要目标，是在离开其对象所在的作用域前，确保线程已经完结。

新线程会直接传递到scoped\_thread中，而非创建一个独立变量。当主线程到达f()末尾时，scoped\_thread对象就会销毁，然后在析构函数中完成汇入。之前的thread\_guard类，需要在析构中检查线程是否可汇入。这里把检查放在了构造函数中，并且当线程不可汇入时抛出异常。

```c++
class scoped_thread {
  std::thread t;
public:
  explicit scoped_thread(std::thread t_): t(std::move(t_)) {
    if(!t.joinable()) throw std::logic_error(“No thread”);
  }
  ~scoped_thread() {
    t.join(); 
  }
  scoped_thread(scoped_thread const&)=delete;
  scoped_thread& operator=(scoped_thread const&)=delete;
};

struct func; 

void f() {
  int some_local_state;
  scoped_thread t(std::thread(func(some_local_state)));  
  do_something_in_current_thread();
} 
```

## joining_thread

```c++
class joining_thread {
  std::thread t;
public:
  joining_thread() noexcept = default;
  
  template<typename Callable,typename ... Args>
  explicit joining_thread(Callable&& func,Args&& ... args): t(std::forward<Callable>(func),std::forward<Args>(args)...) {}
  
  explicit joining_thread(std::thread t_) noexcept: t(std::move(t_)) {}
  joining_thread(joining_thread&& other) noexcept: t(std::move(other.t)) {}
  
  ~joining_thread() noexcept {
    if(joinable()) join();
  }
  
  joining_thread& operator=(joining_thread&& other) noexcept {
    if（joinable()）join();
    t = std::move(other.t);
    return *this;
  }
  joining_thread& operator=(std::thread other) noexcept {
    if(joinable()) join();
    t = std::move(other);
    return *this;
  }

  void swap(joining_thread& other) noexcept {
    t.swap(other.t);
  }
  
  std::thread::id get_id() const noexcept{
    return t.get_id();
  }
  
  bool joinable() const noexcept {
    return t.joinable();
  }
  
  void join() {
    t.join();
  }
  void detach() {
    t.detach();
  }
  
  std::thread& as_thread() noexcept {
    return t;
  }
  const std::thread& as_thread() const noexcept {
    return t;
  }
};
```

## std::thread::id

线程标识为`std::thread::id`类型，可以通过两种方式进行检索

- **可以通过调用`std::thread`对象的成员函数`get_id()`来直接获取**。如果`std::thread`对象没有与任何执行线程相关联，`get_id()`将返回`std::thread::type`默认构造值，这个值表示无线程；
- **当前线程中调用`std::this_thread::get_id()`(在`<thread>`头文件中)也可以获得线程标识。**

`std::thread::id`对象可以自由的拷贝和对比，因为标识符可以复用。如果两个对象的`std::thread::id`相等，那就是同一个线程，或者都无线程。如果不等，那么就代表了两个不同线程，或者一个有线程，另一没有线程。

`std::thread::id`类型对象提供了相当丰富的对比操作。比如，为不同的值进行排序。这意味着开发者可以将其当做为容器的键值做排序，或做其他比较。按默认顺序比较不同的`std::thread::id`：当`a<b`，`b<c`时，得`a<c`，等等。标准库也提供`std::hash<std::thread::id>`容器，`std::thread::id`也可以作为无序容器的键值。

`std::thread::id`实例常用作**检测线程是否需要进行一些操作**。比如：当用线程来分割一项工作，主线程可能要做一些与其他线程不同的工作，启动其他线程前，可以通过`std::this_thread::get_id()`得到自己的线程ID，然后判断其拥有的线程ID是否与主线程的ID相同。

```c++
std::thread::id master_thread;
void some_core_part_of_algorithm() {
  if(std::this_thread::get_id() == master_thread) {
    do_master_thread_work();
  }
  do_common_work();
}
```

也当前线程的`std::thread::id`将存储到数据结构中，这个结构体对当前线程的ID与存储的线程ID做对比，来决定操作是允许，还是需要。同样，作为线程和本地存储不适配的替代方案，线程ID在容器中可作为键值。例如，容器可以存储其掌控下每个线程的信息，或在多个线程中互传信息。

`std::thread::id`可以作为线程的通用标识符，当标识符只与语义相关(比如，数组的索引)时，就需要这个方案了。也可以使用输出流(`std::cout`)来记录一个`std::thread::id`对象的值。

```c++
std::cout<<std::this_thread::get_id();
```

具体的输出结果是严格依赖于具体实现的，C++标准的要求就是保证ID相同的线程必须有相同的输出。

## hardware_concurrency()

**`std::thread::hardware_concurrency()`会返回并发线程的数量**。例如，多核系统中，返回值可以是CPU核芯的数量。返回值也仅仅是一个标识，当无法获取时，函数返回0。

下面实现了并行版的`std::accumulate`。代码将整体工作拆分成小任务，交给每个线程去做，并设置最小任务数，避免产生太多的线程，程序会在操作数量为0时抛出异常。比如，`std::thread`无法启动线程，就会抛出异常。

```c++
template<typename Iterator, typename T>
struct accumulate_block {
  void operator()(Iterator first, Iterator last, T& result) {
    result = std::accumulate(first, last, result);
  }
};

template<typename Iterator,typename T>
T parallel_accumulate(Iterator first, Iterator last, T init) {
  unsigned long const length = std::distance(first, last);

  // 如果输入的范围为空，就会得到init的值。
  if(!length) return init;
  // 如果范围内的元素多于一个时，需要用范围内元素的总数量除以线程(块)中最小任务数，从而确定启动线程的最大数量。
  unsigned long const min_per_thread = 25;
  unsigned long const max_threads = (length + min_per_thread - 1) / min_per_thread; 

  unsigned long const hardware_threads = std::thread::hardware_concurrency();
  // 因为上下文频繁切换会降低线程的性能，所以计算量的最大值和硬件支持线程数，较小的值为启动线程的数量
  // std::thread::hardware_concurrency()返回0时，可以选择一个合适的数字。在本例中，选择了"2"。
  unsigned long const num_threads = std::min(hardware_threads != 0 ? hardware_threads : 2, max_threads);

  // 每个线程中处理的元素数量，是范围中元素的总量除以线程的个数得出的
  unsigned long const block_size = length / num_threads;

  // 确定了线程个数，创建一个`std::vector<T>`容器存放中间结果，并为线程创建一个`std::vector<std::thread>`容器
  // 因为在启动之前已经有了一个线程(主线程)，所以启动的线程数必须比num_threads少1。
  std::vector<T> results(num_threads);
  std::vector<std::thread> threads(num_threads - 1); 

  Iterator block_start = first;
  for(unsigned long i = 0; i < (num_threads - 1); ++i) { // 使用循环来启动线程：block_end迭代器指向当前块的末尾
    Iterator block_end = block_start;
    std::advance(block_end, block_size); 
    threads[i] = std::thread(accumulate_block<Iterator,T>(), block_start, block_end, std::ref(results[i])); // 并启动一个新线程为当前块累加结果
    block_start = block_end;  // 当迭代器指向当前块的末尾时，启动下一个块
  }
  // 启动所有线程后，⑨中的线程会处理最终块的结果。因为知道最终块是哪一个，所以最终块中有多少个元素就无所谓了。
  accumulate_block<Iterator, T>()(block_start, last, results[num_threads - 1]); // 9

  for (auto& entry : threads) entry.join(); // 累加最终块的结果后，汇入线程
  // 之后使用`std::accumulate`将所有结果进行累加
  return std::accumulate(results.begin(), results.end(), init); 
}
```

结束这个例子之前，需要明确：T类型的加法不满足结合律(比如，对于float型或double型，在进行加法操作时，系统很可能会做截断操作)，因为对范围中元素的分组，会导致parallel_accumulate得到的结果可能与`std::accumulate`的结果不同。同样的，这里对迭代器的要求更加严格：必须是前向迭代器。对于results容器，需要保证T有默认构造函数。可以需要根据算法本身的特性，选择不同的并行方式。

因为不能直接从一个线程中返回值，所以需要传递results容器的引用到线程中去。另一个办法，通过地址来获取线程执行的结果。

当线程运行时，所有必要的信息都需要传入到线程中去，包括存储计算结果的位置。有时候可以传递一个标识数，例如代码的i。不过，需要标识的函数在调用栈的底层，同时其他线程也可调用该函数，那么标识数就会变成累赘。好消息是在设计C++的线程库时，就有预见了这种情况，实现中给每个线程附加了唯一标识符。

