# 互斥量

1. lock_guard：指针或引用引起的问题
2. 共享数据可能因接口原因产生条件竞争：empty 与 top，top 与 pop，线程安全的栈
3. lock：swap 产生的死锁问题，lock 的使用，scoped_lock
4. unique_lock：adopt_lock、defer_lock、owns_lock
5. std::call_once：必须使用和可以不使用的场景
6. shared_mutex：应用场景，概况使用方式

## lock_guard

通过实例化`std::mutex`创建互斥量实例，成员函数lock()可对互斥量上锁，unlock()为解锁。不过，不推荐直接去调用成员函数，调用成员函数就意味着，必须在每个函数出口都要去调用unlock()(若出现异常，没有调用 unlock，可能会死锁)。

C++标准库为互斥量提供了RAII模板类`std::lock_guard`，**在构造时就能提供已锁的互斥量，并在析构时进行解锁**，从而保证了互斥量能被正确解锁。

```c++
std::list<int> some_list;    
std::mutex some_mutex;    // 全局变量被一个全局的互斥量保护

void add_to_list(int new_value) {
  std::lock_guard<std::mutex> guard(some_mutex);    // 3
  some_list.push_back(new_value);
}

bool list_contains(int value_to_find) {
  std::lock_guard<std::mutex> guard(some_mutex);    // 4
  return std::find(some_list.begin(),some_list.end(),value_to_find) != some_list.end();
}
// C++17中添加了一个新特性，称为模板类参数推导
std::lock_guard guard(some_mutex); // 其模板参数列表可以省略
```

某些情况下使用全局变量没问题，但大多数情况下，互斥量通常会与需要保护的数据放在同一类中，而不是定义成全局变量。这是面向对象设计的准则：将其放在一个类中，就可让他们联系在一起，也可对类的功能进行封装，并进行数据保护。这种情况下，函数add_to_list和list_contains可以作为这个类的成员函数。所有成员函数都会在调用时对数据上锁，结束时对数据解锁，这就保证了访问时数据不变量的状态稳定。

但当其中一个成员函数返回的是保护数据的指针或引用时，也会破坏数据。**具有访问能力的指针或引用可以访问(并可能修改)保护数据，而不会被互斥锁限制。**这就需要对接口谨慎设计，要确保互斥量能锁住数据访问，并且不留后门。

使用互斥量来保护数据，并不是在每一个成员函数中加入一个`std::lock_guard`对象那么简单。一个指针或引用，也会让这种保护形同虚设。不过，检查指针或引用很容易，只要没有成员函数通过返回值或者输出参数的形式，向其调用者返回指向受保护数据的指针或引用，数据就是安全的。**确保成员函数不会传出指针或引用的同时，检查成员函数是否通过指针或引用的方式来调用也是很重要的**，函数可能没在互斥量保护的区域内存储指针或引用，这样就很危险。

更危险的是：将保护数据作为一个运行时参数，无意中传递了保护数据的引用，如同下面代码中所示。

```c++
class some_data {
  int a;
  std::string b;
public:
  void do_something();
};

class data_wrapper {
private:
  some_data data; // 受保护数据
  std::mutex m;
public:
  template<typename Function>
  void process_data(Function func) {
    std::lock_guard<std::mutex> l(m);
    func(data);    // 传递“保护”数据给用户函数
  }
};

some_data* unprotected;
void malicious_function(some_data& protected_data) {
  unprotected = &protected_data; // 指针指向受保护数据
}

data_wrapper x;
void foo() {
  x.process_data(malicious_function);    // 传递一个恶意函数，process_data内部调用这个函数，并传递保护数据
  unprotected->do_something();    // 使得在无保护的情况下访问保护数据
}
```

## 接口间的条件竞争

使用了互斥量或其他机制保护了共享数据，就不必再为条件竞争所担忧吗？并不是，依旧需要确定数据是否受到了保护。例如，构建一个类似于`std::stack`的栈，除了构造函数和swap()以外，需要对`std::stack`提供五个操作：push()一个新元素进栈，pop()一个元素出栈，top()查看栈顶元素，empty()判断栈是否是空栈，size()了解栈中有多少个元素。即使修改了top()，返回一个拷贝而非引用，这个接口仍存在条件竞争。这个问题不仅存在于互斥量实现接口中，在无锁实现接口中，也会产生条件竞争。这是接口的问题，与实现方式无关。

虽然empty()和size()可能在返回时是正确的，但结果不可靠。一旦函数返回，其他线程就不再受限，从而能自由地访问栈容器，可能马上有新元素入栈，或者，现有的元素会立刻出栈，令前面的线程得到的结果失效而无法使用。

非共享的栈对象，无论栈是否为空，使用empty()检查再调用top()访问栈顶部的元素都是安全的。但对于共享的栈对象，这样的调用顺序就不再安全，因为在调用empty()和调用top()之间，可能有另一个线程调用pop()，弹出栈顶元素。它的根本原因在于函数接口，即使在内部使用互斥保护栈容器中的元素，也无法防范。

```c++
stack<int> s;
if (!s.empty()){    // 1
  int const value = s.top();    // 2
  s.pop();	// 3
  do_something(value);
}
```

问题根源是接口设计，所以解决方法是变更接口。最简单的方式是将top()声明为一旦空栈调用，top()就抛出异常。虽然此法直击要害，但实际使用却很麻烦。原因是，按这样处理，尽管栈容器非空，即empty()返回false，却还是有可能在调用top()时抛出异常，仍须进行捕捉。相反，假定栈容器原本已经全空，在此前提下执行top()肯定抛出异常，相当于额外开销，那么借empty()做判断防止了空栈调用top()，if语句便成了优化手段，而非必要的设计。其实，依照上述方式，只有在empty()和top()两个调用之间，栈容器因多线程共享从非空状态转变为全空状态时，异常才会抛出。

考虑两个线程，都在同一个栈容器s上同时运行这段代码。栈上最开始只有两个元素，所以不必担心哪个线程会在empty()和top()之间竞争。现在考虑下面可能的执行方式。如果栈容器内部具有互斥保护，任何时刻都只准许单一线程运行其成员函数，那么函数调用便交错有秩，而do_something()也得以并发运行。

表3.1 一种可能执行顺序

| Thread A                   | Thread B                   |
| -------------------------- | -------------------------- |
| if (!s.empty);             |                            |
|                            | if(!s.empty);              |
| int const value = s.top(); |                            |
|                            | int const value = s.top(); |
| s.pop();                   |                            |
| do_something(value);       | s.pop();                   |
|                            | do_something(value);       |

假设只有这两个线程运行，并且在两个top()调用之间不存在其他操作，那么栈容器不会被更改，则本意是得到栈顶元素与栈顶下一个元素，结果是**栈顶元素被读取了两次，而栈顶的第二个元素却始终未被读取就被丢弃**。相比empty()和top()竞争导致的未定义行为，这是另一潜藏得更隐蔽的条件竞争。至于最终造成什么后果，显然还取决于do_something()的内部具体操作。

这要求从根本上更改接口设计，其中一种改法是把top()和pop()组成一个成员函数，再采取互斥保护。但这带来了新的问题，在向调用者复制数据的过程中，有可能抛出异常。万一弹出的元素已从栈上移除，但复制却不成功，就会令数据丢失！

综上，把 top() 和 pop() 组成一个成员函数同时执行依然会产生条件竞争（由于异常），因此采用以下措施：

**选项1：传入一个引用**

第一个选项是将变量的引用作为参数，传入pop()函数中获取“弹出值”：

```c++
std::vector<int> result;
some_stack.pop(result);
```

这在许多情况下行之有效，但还是有明显短处。如果代码要调用pop()，则须先依据栈容器中的元素型别构造一个实例，将其充当接收目标传入函数内。对于某些型别，构建实例的时间代价高昂或耗费资源过多，所以不太实用。在另一些型别的栈元素的内部代码中，其构造函数不一定带有参数，故此法也并不总是可行。

最后，这种方法还要求栈容器存储的型别是可赋值的（assignable）。该限制不可忽视：许多用户定义的型别并不支持赋值，尽管它们支持移动构造甚至拷贝构造（准许pop()按值返回）。

**选项2：无异常抛出的拷贝构造函数或移动构造函数**

假设pop()按值返回，若它抛出异常，则牵涉异常安全的问题只会在这里出现。许多型别都含有不抛出异常的拷贝构造函数。对于线程安全的栈容器，一种可行的做法是限制其用途，只允许存储上述型别的元素按值返回，且不抛出异常。

这虽然安全，效果却不理想。就用户定义的型别而言，其中一些含有会抛出异常的拷贝构造函数，却不含移动构造函数，另一些则含有拷贝构造函数和/或移动构造函数，而且不抛出异常。假若线程安全的栈容器无法存储这些型别，那实在可惜。

**选项3：返回指向弹出值的指针**

方法3是返回指针，指向弹出的元素，而不是返回它的值。其优点是指针可以自由地复制，不会抛出异常。但此法存在缺点：在返回的指针所指向的内存中，分配的目标千差万别，既可能是复杂的对象，也可能是简单的型别，这便构成了额外的负担，也许会产生超过按值返回相应型别的开销。若函数接口采取上述方法，则指针型别std::shared_ptr是不错的选择。

**选项4：“选项1 + 选项2”或 “选项1 + 选项3”**

**例：定义线程安全的堆栈**

代码中是一个接口没有条件竞争的堆栈类定义，它实现了选项1和选项3：重载了pop()，使用局部引用去存储弹出值，或返回`std::shared_ptr<>`对象。它有一个简单的接口，只有两个函数：push()和pop()。在空栈上调用pop()会抛出empty_stack异常。所以，即使栈容器在调用empty()之后被改动，一切仍能正常工作。

于是原有的5个栈操作变成3个——push()、pop()和empty()，甚至empty()也是多余的。简化接口让我们得以确保互斥能针对完整操作而锁定，从而更好地掌控数据。

这个栈容器的实现是可复制的，拷贝构造函数先在源对象上锁住互斥，再复制内部的std::stack。没采用成员初始化列表，而是在构造函数的函数体内进行复制操作，从而保证互斥的锁定会横跨整个复制过程。

```c++
struct empty_stack: std::exception 
{
  const char* what() const throw() {
		return "empty stack!";
  };
};

template<typename T>
class threadsafe_stack
{
private:
    std::stack<T> data;
    mutable std::mutex m;
public:
    threadsafe_stack(){}
    threadsafe_stack(const threadsafe_stack& other)
    {
        std::lock_guard<std::mutex> lock(other.m);
        data = other.data;    ⇽---  ①在构造函数的函数体（constructor body）内进行复制操作
    }
  
    threadsafe_stack& operator=(const threadsafe_stack&) = delete;
  
    void push(T new_value)
    {
        std::lock_guard<std::mutex> lock(m);
        data.push(std::move(new_value));
    }

    std::shared_ptr<T> pop()
    {
        std::lock_guard<std::mutex> lock(m);
        if(data.empty()) throw empty_stack();    ⇽---  ②试图弹出前检查是否为空栈
        std::shared_ptr<T> const res(std::make_shared<T>(data.top()));    ⇽---  ③改动栈容器前设置返回值
        data.pop();
        return res;
    }

    void pop(T& value)
    {
        std::lock_guard<std::mutex> lock(m);
        if(data.empty()) throw empty_stack();
        value = data.top();
        data.pop();
    }

    bool empty() const
    {
        std::lock_guard<std::mutex> lock(m);
        return data.empty();
    }
};
```

之前对top()和pop()函数的讨论中，因为锁的粒度太小，恶性条件竞争已经出现，需要保护的操作并未全覆盖到。不过，锁的颗粒度过大同样会有问题。还有一个问题，**一个全局互斥量要去保护全部共享数据，在一个系统中存在有大量的共享数据时，线程可以强制运行，甚至可以访问不同位置的数据，抵消了并发带来的性能提升。**

使用多个互斥量保护所有的数据，细粒度锁也有问题。互斥量保护一个独立类的实例，锁状态的下一个阶段，不是离开锁定区域将锁定区域还给用户，就是有独立的互斥量去保护这个类的全部实例，两种方式都不怎么好。**一个给定操作需要两个或两个以上的互斥量时，另一个潜在的问题将出现：死锁。**

## lock()/scoped_lock

线程有对锁的竞争：一对线程需要对他们所有的互斥量做一些操作，其中每个线程中都存在一个互斥量，正在等待另一个解锁。因为他们都在等待对方释放互斥量，没有线程能工作。这种情况就是死锁，它的问题就是由两个或两个以上的互斥量进行锁定。

防范死锁的建议通常是，始终按相同顺序对两个互斥加锁。若总是先锁互斥A再锁互斥B，则永远不会发生死锁。有时候，这直观、易懂，因为诸多互斥的用途各异。但也会出现棘手的状况，例如，运用多个互斥分别保护多个独立的实例，这些实例属于同一个类。考虑一个函数，其操作同一个类的两个实例，互相交换它们的内部数据。为了保证互换正确完成，免受并发改动的不良影响，两个实例上的互斥都必须加锁。

可是，如果选用了固定的次序（两个对象通过参数传入，总是先给第一个实例的互斥加锁，再轮到第二个实例的互斥），前面的建议就适得其反：针对两个相同的实例，若两个线程都通过该函数在它们之间互换数据，只是两次调用的参数顺序相反，会导致它们陷入死锁！

C++标准库有办法解决这个问题，`std::lock`——可以一次性锁住多个(两个以上)的互斥量，并且没有副作用(死锁风险)：

```c++
class some_big_object;
void swap(some_big_object& lhs, some_big_object& rhs);
class X {
private:
  some_big_object some_detail;
  std::mutex m;
public:
  X(some_big_object const& sd):some_detail(sd){}

  friend void swap(X& lhs, X& rhs) {
    // 一开始就对比两个参数，以确定它们指向不同实例，此项判断必不可少。
    // 若已经在某个std::mutex对象上获取锁，那么再次试图从该互斥获取锁将导致未定义行为
    if(&lhs == &rhs) return;
    // 调用std::lock()锁定两个互斥，并依据它们分别构造std::lock_guard实例
    std::lock(lhs.m, rhs.m);  // std::lock 不具有 RAII，因此需要传给 std::lock_guard 实例
    // std::adopt_lock参数表示指明互斥已被锁住，即互斥上有锁存在
    // std::lock_guard实例应当据此接收锁的归属权，不得在构造函数内试图另行加锁。
    std::lock_guard<std::mutex> lock_a(lhs.m, std::adopt_lock);
    std::lock_guard<std::mutex> lock_b(rhs.m, std::adopt_lock);
    swap(lhs.some_detail, rhs.some_detail);
  }
};
```

> 互斥量可以在同一线程上多次上锁，标准库中`std::recursive_mutex`提供这样的功能

无论函数是正常返回，还是因受保护的操作抛出异常而导致退出，std::lock_guard都保证了互斥全都正确解锁。另外，值得注意的是，std::lock()在其内部对lhs.m或rhs.m加锁，这一函数调用可能导致抛出异常，这样，异常便会从std::lock()向外传播。

假如std::lock()**函数**在其中一个互斥上成功获取了锁，但它试图在另一个互斥上获取锁时却有异常抛出，那么第一个锁就会自动释放：若加锁操作涉及多个互斥，则std::lock()函数的语义是 all-or-nothing，或全部成功锁定，或没获取任何锁并抛出异常。

针对上述场景，C++17还进一步提供了新的RAII类模板std::scoped_lock<>。std::scoped_lock<>和std::lock_guard<>完全等价，只不过前者是可变参数模板，接收各种互斥型别作为模板参数列表，还**以多个互斥对象作为构造函数的参数列表（即可以一次性锁住多个互斥量）**。下列代码中，传入构造函数的两个互斥都被加锁，机制与std::lock()函数相同，因此，当构造函数完成时，它们就都被锁定，而后，在析构函数内一起被解锁：

```c++
void swap(X& lhs, X& rhs) {
  if(&lhs == &rhs) return;
  std::scoped_lock guard(lhs.m, rhs.m); // 类模板参数推导 std::scoped_lock<std::mutex, std::mutex> guard(lhs.m,rhs.m);
  swap(lhs.some_detail, rhs.some_detail);
}
```

## unique_lock

类模板std::unique_lock<>放宽了不变量的成立条件，std::unique_lock对象不一定始终占有与之关联的互斥，其构造函数接收第二个参数：

- std::adopt_lock：指明std::unique_lock对象管理的互斥已被锁住；
- std::defer_lock：使互斥在完成构造时处于无锁状态，等以后有需要时才在std::unique_lock对象上调用lock()而获取锁，或把std::unique_lock对象交给std::lock()函数加锁；

交换操作中`std::lock()`和`std::unique_lock`的使用，仅有一处小差别：std::unique_lock占用更多的空间，也比std::lock_guard略慢。但std::unique_lock对象可以不占有关联的互斥，具备这份灵活性需要付出代价：需要存储并且更新互斥信息：

```c++
class some_big_object;
void swap(some_big_object& lhs,some_big_object& rhs);
class X {
private:
    some_big_object some_detail;
    std::mutex m;
public:
    X(some_big_object const& sd):some_detail(sd){}
    friend void swap(X& lhs, X& rhs) {
        if(&lhs==&rhs) return;
        std::unique_lock<std::mutex> lock_a(lhs.m, std::defer_lock);   // 实例std::defer_lock将互斥保留为无锁状态   
        std::unique_lock<std::mutex> lock_b(rhs.m, std::defer_lock);    
        std::lock(lock_a, lock_b); // 到这里才对互斥加锁
        swap(lhs.some_detail, rhs.some_detail);
    }
};
```

因为std::unique_lock类具有成员函数lock()、try_lock()和unlock()，所以它的实例得以传给std::lock()函数。std::unique_lock实例在底层与目标互斥关联，此互斥也具备这3个同名的成员函数，因此上述函数调用转由它们实际执行。

**std::unique_lock实例还含有一个内部标志，亦随着这些函数的执行而更新，以表明关联的互斥目前是否正被该类的实例占据。**这一标志必须存在，作用是保证析构函数正确调用unlock()。假如std::unique_lock实例的确占据着互斥，则其析构函数必须调用unlock()；若不然，实例并未占据互斥，便绝不能调用unlock()。此标志可以通过调用成员函数**owns_lock()**查询。

> 不过，若条件允许，最好还是采用C++17所提供的变参模板类std::scoped_lock，除非必须采用std::unique_lock类（实际传给std::lock()函数，底层通过互斥的成员函数加锁）进行某些操作，如转移锁的归属权。
>

上述标志需要占用存储空间。故std::unique_lock对象的“体积”往往大于std::lock_guard对象的。并且，由于该标志必须适时更新或检查，因此若采用std::unique_lock替换std::lock_guard，便会导致轻微的性能损失。所以，如果std::lock_guard已经能满足所需，建议优先采用。

`std::unique_lock`实例没有与自身相关的互斥量，互斥量的所有权可以通过移动操作，在不同的实例中进行传递。某些情况下，这种转移是自动发生的，若是左值（一个实际的值或是引用）则必须显式转移。若是右值（一个临时变量），便会自动发生。`std::unique_lock`是可移动，但不可赋值的类型。

> lock_guard 与 unique_lock 均是构造时获取锁，析构时释放锁。但 lock_guard 不能用作函数形参与返回值，因为拷贝构造与赋值运算符都是被删除的。unique_lock 则多与条件变量使用，当条件变量调用 wait 方法时，使线程进入等待状态并释放锁。

一种使用可能是允许函数去锁住一个互斥量，并且将所有权移到调用者上，所以调用者可以在这个锁保护的范围内执行额外的动作。下面的程序片段展示了：函数get_lock()锁住了互斥量，然后准备数据，返回锁的调用函数。

```c++
std::unique_lock<std::mutex> get_lock() {
  extern std::mutex some_mutex;
  std::unique_lock<std::mutex> lk(some_mutex);
  prepare_data();
  return lk;  // lk在函数中被声明为自动变量，它不需要调用`std::move()`，可以直接返回
}
void process_data() {
  std::unique_lock<std::mutex> lk(get_lock()); // 直接转移`std::unique_lock`实例的所有权
  do_something();
}
```

## 避免死锁的进阶指导

假定需要同时获取多个锁，那么std::lock()函数和std::scoped_lock<>模板即可帮助防范死锁；但若代码分别获取各个锁，它们就鞭长莫及了。在这种情况下，唯有依靠经验力求防范死锁。知易行难，死锁是最棘手的多线程代码问题之一，绝大多数情形中，纵然一切都运作正常，死锁也往往无法预测。尽管如此，编写的代码只要服从一些相对简单的规则，便有助于防范死锁。

死锁通常是对锁的使用不当造成。无锁的情况下，仅需要两个线程`std::thread`对象互相调用join()就能产生死锁。这种情况下，没有线程可以继续运行，因为他们正在互相等待。这种情况很常见，一个线程会等待另一个线程，其他线程同时也会等待第一个线程结束，所以三个或更多线程的互相等待也会发生死锁。为了避免死锁，这里意见：**不要谦让**。

### 避免嵌套锁

第一个建议往往是最简单的：线程获得一个锁时，就别再去获取第二个。每个线程只持有一个锁，就不会产生死锁。当需要获取多个锁，使用`std::lock`来做这件事(对获取锁的操作上锁)，避免产生死锁。

### 避免在持有锁时调用外部代码

若程序接口由用户自行实现，则无从得知它到底会做什么，它可能会随意操作，包括试图获取锁。一旦已经持锁，若再调用由用户提供的程序接口，而它恰好也要获取锁，那便违反了避免嵌套锁的准则，可能发生死锁。不过，有时这实在难以避免。只要其操作与模板参数的型别有关，它就不得不依赖用户提供的程序接口。因此需要另一条新的准则。

### 使用固定顺序获取锁

**如果多个锁是绝对必要的，却无法通过std::lock()在一步操作中全部获取，只能退而求其次，在每个线程内部都依从固定顺序获取这些锁**。

若在两个互斥上获取锁，则有办法防范死锁：关键是，事先规定好加锁顺序，令所有线程都依从。这在一些情况下相对简单、易行。以栈容器为例，互斥在栈容器的实例内部发挥作用，但假如操作涉及栈容器存放的元素，就须调用由用户提供的接口。然而也可以约束栈容器内存储的元素：任何针对元素所执行的操作，均不得牵扯到栈容器本身。该限制给栈容器的使用者造成了负担。不过，栈容器中存储的元素极少会访问栈容器本身，万一发生访问，也能明显觉察，故这种负担并非难以承受。

另外几种情况很直观，如互换操作。虽然这种方式并不一定总是可行，但在该情况下，至少可以同时对两个互斥加锁。回顾双向链表，便能发现一种可行的方法：给每个节点都配备互斥来保护链表。因此，线程为了访问链表，须对涉及的每个节点加锁。就执行删除操作的线程而言**，它必须在3个节点上获取锁，即要被删除的目标节点和两侧的相邻节点**，因为它们全都会在不同程度上被改动。类似地，若要遍历链表，线程必须持有当前节点的锁，同时在后续节点上获取锁，从而确保前向指针不被改动。一旦获取了后续节点上的锁，当前节点的锁便再无必要，遂可释放。

按照这种方式，链表容许多个线程一起访问，前提是它们不会同时访问同一个节点。不过，节点必须依从相同的锁定顺序以预防死锁：假如两个线程从相反方向遍历链表，并采用交替前进的加锁方式，它们就会在途中互相死锁。假定A和B是链表中的两个相邻节点，正向遍历的线程会先尝试持有节点A的锁，接着再从节点B上获取锁。逆向遍历的线程则持有节点B的锁，并试图从节点A上获取锁，这会导致出现经典场景，发生死锁！如图3.2所示。

|            线程1             |            线程2             |
| :--------------------------: | :--------------------------: |
|      锁住主入口的互斥量      |                              |
|        读取头结点指针        |                              |
|       锁住头结点互斥量       |                              |
|       解锁主入口互斥量       |                              |
|                              |       锁住主入口互斥量       |
|      读取head->next指针      |       锁住尾结点互斥量       |
|     锁住next结点的互斥量     |      读取tail->prev指针      |
|      读取next->next指针      |      解锁尾结点的互斥量      |
|             ...              |             ...              |
|      锁住A结点的互斥量       |      锁住C结点的互斥量       |
| 读取A->next指针(也就是B结点) | 读取C->next指针(也就是B结点) |
|                              |       锁住B结点互斥量        |
| 阻塞，尝试锁住B结点的互斥量  |       解锁C结点互斥量        |
|                              | 读取B->prev指针(也就是A结点) |
|                              | 阻塞，尝试锁住A结点的互斥量  |
|            死锁！            |                              |

图3.2 不同线程以相反顺序访问列表所造成的死锁

类似地，假设节点B位于节点A和C之间，若线程甲要删除B，便先在B上获取锁，然后再锁住A和C。如果线程乙正同时遍历链表，则可能会先锁住A或C（具体锁住哪个，取决于遍历方向），却随即发现无法在节点B上获取锁，因线程甲已经持有B的锁，并尝试在A或C上获取锁。遂甲、乙线程互相死锁。此处有一个方法可防范死锁：规定遍历的方向。从而令线程总是必须先锁住A，再锁住B，最后锁住C。这样，我们就可以以禁止逆向遍历为代价而防范可能的死锁。其他数据结构也会设定相似的准则。

### 使用层次锁结构

锁的层级划分就是按特定方式规定加锁次序，在运行期据此查验加锁操作是否遵从预设规则。按照构思把应用程序分层，并且明确每个互斥位于哪个层级。若**某线程已对低层级互斥加锁，则不准它再对高层级互斥加锁。具体做法是将层级的编号赋予对应层级应用程序上的互斥，并记录各线程分别锁定了哪些互斥。**这种模式虽然常见，但C++标准库尚未提供直接支持，故需自行编写定制的互斥型别hierarchical_mutex，如代码清单3.7所示。

```c++
// 依据相应的层级编号而构造（层级越低编号越小）
// 这套机制旨在设定加锁的规则，如果已在某hierarchical_mutex互斥上持有锁
// 那么只能由相对低层级的hierarchical_mutex互斥获取锁，从而限制代码的行为。
hierarchical_mutex high_level_mutex(10000);   
hierarchical_mutex low_level_mutex(5000);   
hierarchical_mutex other_mutex(6000);   
int do_low_level_stuff();
int low_level_func() {
    // 假定do_low_level_stuff()函数没有锁住任何互斥，而low_level_func()函数处于最低层级，且锁住了互斥low_level_mutex
    std::lock_guard<hierarchical_mutex> lk(low_level_mutex); 
    return do_low_level_stuff();
}

void high_level_stuff(int some_param);
void high_level_func() {
    // high_level_func()函数先对互斥high_level_mutex加锁，随后调用low_level_func()
    std::lock_guard<hierarchical_mutex> lk(high_level_mutex);   
    high_level_stuff(low_level_func()); // 这两步操作符合加锁规则，因为互斥high_level_mutex所在的层级（10000）高于low_level_mutex所在的层级（5000）
}
void thread_a() { // thread_a()同样遵循规则，所以运行无碍
    high_level_func();
}

void do_other_stuff();
void other_stuff() {
    high_level_func(); 
    do_other_stuff();
}
// 相反地，thread_b()无视规则，因此在运行期出错。它先对互斥other_mutex加锁，其层级编号是6000，说明该互斥位于中间层级
void thread_b() { 
    std::lock_guard<hierarchical_mutex> lk(other_mutex);
    // 在other_stuff()函数调用high_level_func()之时，就违反了层级规则
    // high_level_func()试图在互斥high_level_mutex上获取锁，但其层级编号却是10000，远高于当前层级编号6000。
    // 结果，互斥hierarchical_mutex会报错，可能抛出异常，也可能中止程序。
    other_stuff();
}
```

层级互斥之间不可能发生死锁，因为互斥自身已经被强制限定了加锁次序。只要两个层级锁都位于相同层级，便无法一并持有。若将层级锁应用于前文交替前进的加锁策略，那么链表中每个互斥的层级须低于其前驱节点互斥的层级。

代码清单3.7还展示了另一点：依据用户自定义的互斥型别，将类模板std::lock_guard<>具体化。hierarchical_mutex类并非标准的一部分，但不难编写；代码清单3.8给出了简单实现。尽管它属于用户自定义的型别，但也能与std::lock_guard<>结合使用，因其实现了3个成员函数——lock()、unlock()和try_lock()，满足了互斥概念所需具备的操作。

> try_lock()：若另一线程已在目标互斥上持有锁，则函数立即返回false，完全不等待。std::lock()也可在内部利用该函数，实现防范死锁的算法。

为了存储当前层级编号，hierarchical_mutex的实现使用了线程专属的局部变量。所有互斥的实例都能读取该变量，但它的值因不同线程而异。这使代码可以独立检测各线程的行为，各互斥都能判断是否允许当前线程对其加锁。

代码3.8 简单的层级互斥量实现

```c++
class hierarchical_mutex {
    std::mutex internal_mutex;
    unsigned long const hierarchy_value;
    unsigned long previous_hierarchy_value;
    // 使用线程专属的变量（名为this_thread_hierarchy_value，以关键字thread_local修饰）表示当前线程的层级编号
    // 最开始，任意hierarchical_mutex互斥都能被加锁。
    // 因为声明由thread_local修饰，每个线程都具有自己的this_thread_hierarchy_value副本
    // 所以该变量在某线程上的值与另一线程上的值完全无关。
    static thread_local unsigned long this_thread_hierarchy_value;
    void check_for_hierarchy_violation() {
        // 某线程第一次锁住hierarchical_mutex的某个实例时，变量this_thread_hierarchy_value的值是ULONG_MAX。
        // 根据定义，它大于任何其他值，因而check_for_hierarchy_violation()的检查顺利通过
        // 假设已持有互斥hierarchical_mutex的锁，那么this_thread_hierarchy_value的值反映出前者所在层级的编号
        // 若要再对另一互斥加锁，后面互斥的层级必须低于前面已被锁定的互斥的层级，才可以通过检查
        if(this_thread_hierarchy_value <= hierarchy_value) {
            throw std::logic_error("mutex hierarchy violated");
        }
    }

    void update_hierarchy_value() {
        previous_hierarchy_value=this_thread_hierarchy_value; // 记录当前线程的层级编号，将其保存为上一次加锁的层级
        this_thread_hierarchy_value=hierarchy_value;
    }

public:
    explicit hierarchical_mutex(unsigned long value):
    hierarchy_value(value),
    previous_hierarchy_value(0)
    {}
    void lock() {
        check_for_hierarchy_violation(); // 检查完成后
        internal_mutex.lock(); // lock()委托内部的互斥加锁
        // 只有锁定内部互斥internal_mutex之后，才保存上一次加锁的层级
        update_hierarchy_value();  // 只要成功锁定，层级编号即能更新
    }
    void unlock() {
        // 为了避免乱序解锁而引发层级混淆，如果解锁某个层级的互斥，却发现它不是最后一个被加锁的，就抛出异常
        if(this_thread_hierarchy_value!=hierarchy_value) throw std::logic_error("mutex hierarchy violated");
        // 执行unlock()时，线程的层级按保存的值复原 
        // 否则，就无法重新锁定层级较高的互斥，即使当前线程不再持有任何锁
        this_thread_hierarchy_value=previous_hierarchy_value; // 在内部互斥解锁之前，复原已经完成
        internal_mutex.unlock();
    }
    bool try_lock() {
        check_for_hierarchy_violation();
        // try_lock()与lock()的工作原理相同，差别在于，若调用try_lock()，它对内部互斥internal_mutex加锁失败
        if(!internal_mutex.try_lock()) return false; // 因此，当前线程的层级编号不进行更新，并且函数返回false而不是true
        update_hierarchy_value();
        return true;
    }
};
// 初始化为unsigned long可表示的最大值
thread_local unsigned long hierarchical_mutex::this_thread_hierarchy_value(ULONG_MAX); 
```

### 超越锁的延伸扩展

死锁现象并不单单因加锁操作而发生，任何同步机制导致的循环等待都会导致死锁出现。因此也值得为那些情况推广上述准则。譬如，应尽可能避免获取嵌套锁；若当前线程持有某个锁，却又同时等待别的线程，这便是坏的情况，因为万一后者恰好也需获取锁，反而只能等该锁被释放才能继续运行。

类似地，如果要等待线程，那就值得针对线程规定层级，使得每个线程仅等待层级更低的线程。有一种简单方法可实现这种机制：让同一个函数启动全部线程，且汇合工作也由之负责。

## 锁的粒度

锁的粒度用来描述通过一个锁保护着的数据量大小。*一个细粒度锁*(a fine-grained lock)能够保护较小的数据量，*一个粗粒度锁*(a coarse-grained lock)能够保护较多的数据量。锁操作有两个要点：一是选择足够粗大的锁粒度，确保目标数据受到保护；二是限制范围，务求只在必要的操作过程中持锁。

假定多个线程正等待使用同一个资源，如果任何线程在必要范围以外持锁，就会增加等待所耗费的总时间。只要条件允许，仅仅在访问共享数据期间才锁住互斥，让数据处理尽可能不用锁保护。

请特别注意，持锁期间应避免任何耗时的操作，如读写文件。同样是读写总量相等的数据，文件操作通常比内存慢几百倍甚至几千倍。除非锁的本意正是保护文件访问，否则，为I/O操作加锁将毫无必要地阻塞其他线程（它们因等待获取锁而被阻塞），即使运用了多线程也无法提升性能。

这种情况可用std::unique_lock处理：假如代码不再需要访问共享数据，那就调用unlock()解锁；若以后需重新访问，则调用lock()加锁：

```c++
void get_and_process_data() {
    std::unique_lock<std::mutex> my_lock(the_mutex);
    some_class data_to_process=get_next_data_chunk();
    my_lock.unlock();  // 假定process()函数全程无须为互斥加锁，那应该在调用前手动解锁
    result_type result=process(data_to_process);
    my_lock.lock(); // 其后重新锁定
    write_result(data_to_process,result);
}
```

若只用单独一个互斥保护整个数据结构，不但很可能加剧锁的争夺，还将难以缩短持锁时间。假设某项操作需对同一个互斥全程加锁，当中步骤越多，则持锁时间越久。这是一种双重损失，恰恰加倍促使尽可能改用粒度精细的锁。上例说明，加锁时选用恰当的粒度，不仅事关锁定数据量的大小，还牵涉持锁时间以及持锁期间能执行什么操作。一般地，若要执行某项操作，那应该只在所需的最短时间内持锁。换言之，除非绝对必要，否则不得在持锁期间进行耗时的操作，如等待I/O完成或获取另一个锁（即便知道不会死锁）。

在代码清单3.6和代码清单3.9中，数据互换操作显然必须并发访问两个对象，该操作需锁定两个互斥。设想原本的场景变成：试图比较两个简单的数据成员，其型别是C++的原生int。新、旧场景存在区别吗？存在。因为int的值复制起来开销甚低，所以程序可以先锁住比较运算的目标对象，从中轻松地复制出各自相关的数据，再用复制的值进行比较运算。这样做的意义是，并非先持有一个锁再锁定另一个互斥，而是分别对两个互斥加锁，使得持锁时间最短。

代码清单3.10　在比较运算的过程中，每次只锁住一个互斥

```c++
class Y {
    private:
    int some_detail;
    mutable std::mutex m;
    int get_detail() const { // 为了缩短持锁定的时间，一次只持有一个锁（这也排除了死锁的可能），而原本的场景则将两个对象一起锁定
        std::lock_guard<std::mutex> lock_a(m); // 该函数先加锁保护数据，再取值
        return some_detail;
    }
    public:
    Y(int sd):some_detail(sd){}

    friend bool operator==(Y const& lhs, Y const& rhs) {
        if(&lhs==&rhs) return true;
        // 比较运算符首先调用成员函数get_detail()，以获取需要比较的值
        int const lhs_value = lhs.get_detail();  
        int const rhs_value = rhs.get_detail();  
        return lhs_value == rhs_value;  // 比较运算符对比取得的值
    }
};
```

新场景中隐秘地篡改了比较运算的原有语义。在代码清单3.10中，若比较运算符返回true，则其意义是：lhs.some_detail在某时刻的值等于rhs.some_detail在另一时刻的值。在两次获取之间，它们的值有可能已经以任意形式发生变化，令比较运算失去意义。例如，尽管事实上两者在任何时刻都不相等，但在上述过程中双方发生了互换，最终令比较运算结果为true，错误地表明它们等值。因而做这种改动时必须保持谨慎，免得运算语义遭到篡改而产生问题：若未能持有必要的锁以完全保护整个运算，便会将自己置身于条件竞争的危险中。

# 保护共享数据的方式

互斥量是一种通用的机制，但其并非保护共享数据的唯一方式。有很多方式可以在特定情况下，对共享数据提供合适的保护。一个特别极端的情况就是，共享数据在并发访问和初始化时(都需要保护)，需要进行隐式同步。这可能是因为数据作为只读方式创建，所以没有同步问题，或者因为必要的保护作为对数据操作的一部分。任何情况下，数据初始化后锁住一个互斥量，纯粹是为了保护其初始化过程，并且会给性能带来不必要的影响。

## std::call_once()

假设需要某个共享数据，而它创建起来开销不菲。因为创建它可能需要建立数据库连接或分配大量内存，所以等到必要时才真正着手创建。这种方式称为延迟初始化（lazy initialization），常见于单线程代码。对于需要利用共享资源的每一项操作，要先在执行前判别该数据是否已经初始化，若没有，则及时初始化，然后方可使用。使用延迟初始化的过程：

```c++
std::shared_ptr<some_resource> resource_ptr;
void foo() {
  if(!resource_ptr) {
    resource_ptr.reset(new some_resource);
  }
  resource_ptr->do_something();
}
```

假定共享数据本身就能安全地被并发访问，若将上面的代码转化成多线程形式，则仅有初始化过程需要保护。不过，如果数据为多个线程所用，那么它们便无法被并发访问，线程只能毫无必要地循序运行，因为每个线程都必须在互斥上轮候，等待查验数据是否已经完成初始化。使用延迟初始化(线程安全)的过程：

```c++
std::shared_ptr<some_resource> resource_ptr;
std::mutex resource_mutex;

void foo() {
  std::unique_lock<std::mutex> lk(resource_mutex);  // 所有线程在此序列化 
  if(!resource_ptr) {
    resource_ptr.reset(new some_resource);
  }
  lk.unlock();  // 只有初始化过程需要保护 
  resource_ptr->do_something();
}
```

上面的代码毫无必要地迫使多个线程循序运行，很有问题。为此，许多人尝试改进，包括实现倍受诟病的双重检验锁定模式：

```c++
void undefined_behaviour_with_double_checked_locking()
{
  if(!resource_ptr) { // 在无锁条件下读取指针，只有读到空指针才获取锁，当前线程先判別空指针
    std::lock_guard<std::mutex> lk(resource_mutex); // 随即加锁
    if(!resource_ptr) { // 两步操作之间存在间隙，其他线程或许正好借机完成初始化。需再次检验空指针
      resource_ptr.reset(new some_resource);  
    }
  }
  resource_ptr->do_something();
}
```

这种新的模式饱受诟病，因为它有可能诱发恶性条件竞争，问题的根源是：当前线程在锁保护范围外读取指针，而对方线程却可能先获取锁，顺利进入锁保护范围内执行写操作，因此读写操作没有同步，产生了条件竞争，既涉及指针本身，还涉及其指向的对象。尽管当前线程能够看见其他线程写入指针，却有可能无视新实例some_resource的创建，结果do_something()的调用就会对不正确的值进行操作。C++标准将此例定义为数据竞争，是条件竞争的一种，其将导致未定义行为。

在C++标准库中提供了std::once_flag类和std::call_once()函数，以专门处理该情况。上述代码先锁住互斥，再显式检查指针，导致问题出现。因此令所有线程共同调用std::call_once()函数，从而**确保在该调用返回时，指针初始化由其中某线程安全且唯一地完成**（通过适合的同步机制）。**必要的同步数据则由std::once_flag实例存储，每个std::once_flag实例对应一次不同的初始化。**

相比显式使用互斥，std::call_once()函数的额外开销往往更低，特别是在初始化已经完成的情况下，所以如果功能符合需求就应优先使用。运用std::call_once()重写代码即得出下面的代码，两者均实现了相同的操作。

下面的代码中，初始化通过函数调用完成，不过只要一个类具备函数调用操作符，则该类的实例也可以轻松地通过这种方式进行初始化。标准库中的一些函数接收函数或断言作为参数，std::call_once()与它们当中的大多数相似，能与任何函数或可调用对象配合工作：

```c++
std::shared_ptr<some_resource> resource_ptr;
std::once_flag resource_flag;    ⇽---  ①
void init_resource() {
    resource_ptr.reset(new some_resource);
}
void foo() {
    std::call_once(resource_flag, init_resource); // 初始化函数准确地被唯一一次调用
    resource_ptr->do_something();
}
```

使用`std::once_flag`作为类成员的延迟初始化(线程安全)：

```c++
class X {
private:
    connection_info connection_details;
    connection_handle connection;
    std::once_flag connection_init_flag;
    void open_connection() {
        connection = connection_manager.open(connection_details);
    }
public:
    X(connection_info const& connection_details_): connection_details(connection_details_) {}
    void send_data(data_packet const& data) {   
        std::call_once(connection_init_flag, &X::open_connection, this);    
        connection.send_data(data);
    }
    data_packet receive_data() {  
        std::call_once(connection_init_flag, &X::open_connection, this); // 初始化或在receive_data()的第一次调用中进行
        return connection.receive_data();
    }
};
```



如果把局部变量声明成静态数据，那样便有可能让初始化过程出现条件竞争。根据C++标准规定，**只要控制流程第一次遇到局部静态数据的声明语句，变量即进行初始化。若多个线程同时调用同一函数，而它含有局部静态数据，则任意线程均可能首先到达其声明处，这就形成了条件竞争的隐患。**

C++11标准发布之前，许多编译器都未能在实践中正确处理该条件竞争。其原因有可能是众多线程均认定自己是第一个，都试图初始化变量；也有可能是某线程上正在进行变量的初始化，但尚未完成，而别的线程却试图使用它。**C++11解决了这个问题，规定初始化只会在某一线程上单独发生，在初始化完成之前，其他线程不会越过静态数据的声明而继续运行。**

于是，这使得条件竞争原来导致的问题变为，初始化应当由哪个线程具体执行。某些类的代码只需用到唯一一个全局实例，这种情形可用以下方法代替std::call_once()：

```c++
class my_class;
my_class& get_my_class_instance() {
  static my_class instance;  // 线程安全的初始化过程
  return instance;
}
```

多个线程可以安全地调用get_my_class_instance()，而无须担忧初始化的条件竞争。

## shared_mutex/shared_lock

假定需要一种数据结构，若线程对其进行更新操作，则并发访问从开始到结束完全排他，及至更新完成，数据结构方可重新被多线程并发访问。若采用std::mutex保护数据结构，则过于严苛，原因是即便没发生改动，它照样会禁止并发访问。需在这里采用新类型的互斥。由于新的互斥具有两种不同的使用方式，因此通常被称为读写互斥：允许单独一个写线程进行完全排他的访问，也允许多个读线程共享数据或并发访问。

C++为此提供了std::shared_mutex和std::shared_timed_mutex（支持更多操作），从而利用std::shared_mutex的实例施加同步操作。更新操作可用排他锁std::lock_guard\<std::shared_mutex>和std::unique_lock\<std::shared_mutex>锁定，而那些无须更新数据结构的线程，可以另行改用共享锁std::shared_lock\<std::shared_mutex>实现共享访问。

C++14引入的共享锁的类模板std::shared_lock\<>，其工作原理是RAII过程，使用方式则与std::unique_lock相同，只不过多个线程能够同时锁住同一个std::shared_mutex。**共享锁仅有一个限制，即假设它已被某些线程所持有，若别的线程试图获取排他锁，就会发生阻塞，直到那些线程全都释放该共享锁。反之，如果任一线程持有排他锁，那么其他线程全都无法获取共享锁或排他锁，直到持锁线程将排他锁释放为止。**

代码3.13 使用`std::shared_mutex`对数据结构进行保护

```c++
class dns_entry;
class dns_cache {
  std::map<std::string,dns_entry> entries;
  mutable std::shared_mutex entry_mutex;
public:
  dns_entry find_entry(std::string const& domain) const {
    // 其他线程均在读取时，无法获取排他锁
    std::shared_lock<std::shared_mutex> lk(entry_mutex);  // find_entry()使用std::shared_lock<>来保护共享和只读权限
    std::map<std::string, dns_entry>::const_iterator const it = entries.find(domain);
    return (it == entries.end())?dns_entry():it->second;
  }
  void update_or_add_entry(std::string const& domain, dns_entry const& dns_details) {
    // update_or_add_entry()使用std::lock_guard<>实例，当表格需要更新时，为其提供独占访问权限
    // update_or_add_entry()函数调用时，独占锁会阻止其他线程对数据结构进行修改，并且阻止线程调用find_entry()。
    std::lock_guard<std::shared_mutex>lk(entry_mutex); 
    entries[domain]=dns_details;
  }
};
```

## std::recursive_mutex

线程对已经获取的`std::mutex`(已经上锁)再次上锁是错误的，尝试这样做会导致未定义行为。在某些情况下，一个线程会尝试在释放一个互斥量前多次获取。因此，C++标准库提供了`std::recursive_mutex`类。除了可以在同一线程的单个实例上多次上锁，其他功能与`std::mutex`相同。其他线程对互斥量上锁前，当前线程必须释放拥有的所有锁，所以如果你调用lock()三次，也必须调用unlock()三次。正确使用`std::lock_guard<std::recursive_mutex>`和`std::unique_lock<std::recursive_mutex>`可以帮你处理这些问题。

使用嵌套锁时，要对代码设计进行改动。嵌套锁一般用在可并发访问的类上，所以使用互斥量保护其成员数据。每个公共成员函数都会对互斥量上锁，然后完成对应的操作后再解锁互斥量。不过，有时成员函数会调用另一个成员函数，这种情况下，第二个成员函数也会试图锁住互斥量，这就会导致未定义行为的发生。“变通的”解决方案会将互斥量转为嵌套锁，第二个成员函数就能成功的进行上锁，并且函数能继续执行。

但是这种方式过于草率和不合理，所以不推荐这样的使用方式。特别是，对应类的不变量通常会被破坏。这意味着，当不变量被破坏时，第二个成员函数还需要继续执行。一个比较好的方式是，从中提取出一个函数作为类的私有成员，这个私有成员函数不会对互斥量进行上锁(调用前必须获得锁)。然后，需要仔细考虑一下，这种情况调用新函数时数据的状态。