# 内存模型基础

## 对象和内存区域

C++程序的数据全部都由对象构成。虽然C++为对象赋予了各种性质，如类型和生存期，但C++标准只将对象定义为某一存储范围。这些对象中，有的属于内建基本类型（如int和float），用于存储简单的数值，其他则是用户自定义类型的实例。某些对象具有子对象，如数列、派生类的实例、含有非静态数据成员的类的实例等，而其他则没有。

不论对象属于什么类型，它都会存储在一个或多个内存区域中。每个内存区域或是对象/子对象，属于标量类型（scalar type），如unsigned short和my_class*，或是一串连续的位域（bit field）。

> 尽管相邻的位域分属不同对象，但照样算作同一内存区域

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/5-1.png)

完整的struct是一个有多个子对象(每一个成员变量)组成的对象。位域bf1和bf2共享同一个内存区域(int是4字节、32位类型)，并且`std::string`类型的对象s由内部多个内存区域组成，但是其他的成员都拥有自己的内存区域。bf3是0宽度位域（其变量名被注释掉，因为0宽度位域必须匿名），与bf4彻底分离，将bf4排除在bf3的内存区域之外，但bf3实际上并不占有任何内存区域。

> 在C++和C中规定，宽度为0的一个未命名位域强制下一位域对齐到其下一type边界，其中type是该成员的类型。这里使用命名变量为0的位域，可能只是想展示其与bf4是如何分离的)

从中总结出4个要点：

1. 每个变量都是对象，对象的数据成员也是对象；
2. 每个对象都占用至少一块内存区域；
3. 若变量属于内建基本类型（如int或char），则不论其大小，都占用一块内存区域（且仅此一块），即便它们的位置相邻或它们是数列中的元素；
4. 相邻的位域属于同一内存区域。

## 对象、内存区域和并发

所有与多线程相关的事项都会牵涉内存区域。如果两个线程各自访问分离的内存区域，则相安无事，一切运作良好；反之，如果两个线程访问同一内存区域，就要警惕了。假使没有线程更新内存区域，则不必在意，只读数据无须保护或同步。

任一线程改动数据都有可能引发条件竞争。要避免条件竞争，就必须强制两个线程按一定的次序访问。这个次序可以固定不变，即某一访问总是先于另一个；也可变动，即随应用软件的运行而间隔轮换访问的次序。但无论如何，必须保证访问次序条理清晰分明。

若在两个访问发生前，先行锁定相关互斥，那么每次仅容许一个线程访问目标内存区域，遂一个访问必然先于另一个（通常无从预知具体哪个访问在前）。还有一种方法是，利用原子操作的同步性质，在目标内存区域（或相关内存区域）采取原子操作，从而强制两个线程遵从一定的访问次序。假如多个线程访问相同的内存区域，则它们两两间必须全都有明确的访问次序。

假设两个线程访问同一内存区域，却没有强制它们服从一定的访问次序，如果其中至少有一个是非原子化访问，并且至少有一个是写操作，就会出现数据竞争，导致未定义行为。

## 改动序列

在一个C++程序中，每个对象都具有一个改动序列，它由所有线程在对象上的全部写操作构成，其中第一个写操作即为对象的初始化。大部分情况下，这个序列会随程序的多次运行而发生变化，但是在程序的任意一次运行过程中，所含的全部线程都必须形成相同的改动序列。

若多个线程共同操作某一对象，但它却不属于原子类型，就要自己负责充分施行同步操作，进而确保对于一个变量，所有线程就其达成一致的改动序列。变量的值会随时间推移形成一个序列。在不同的线程上观察属于同一个变量的序列，如果所见各异，就说明出现了数据竞争和未定义行为。若采用了原子操作，那么编译器有责任保证必要的同步操作有效、到位。

**为了实现上述保障，要求禁止某些预测执行（speculative execution），原因是在改动序列中，只要某线程看到过某个对象，则该线程的后续读操作必须获得相对新近的值，并且，该线程就同一对象的后续写操作，必然出现在改动序列后方。**另外，如果某线程先向一个对象写数据，过后再读取它，那么必须读取前面写的值。若在改动序列中，上述读写操作之间还有别的写操作，则必须读取最后写的值。在程序内部，对于同一个对象，全部线程都必须就其形成相同的改动序列，并且在所有对象上都要求如此，而多个对象上的改动序列只是相对关系，线程之间不必达成一致。

# C++中的原子操作及其类别

原子操作是不可分割的操作。在系统的任一线程内，都不会观察到这种操作处于半完成状态；它或者完全做好，或者完全没做。考虑读取某对象的过程，假如其内存加载行为属于原子操作，并且该对象的全部修改行为也都是原子操作，那么通过内存加载行为就可以得到该对象的初始值，或得到某次修改而完整存入的值。

与之相反，非原子操作（non-atomic operation）在完成到一半的时候，有可能为另一线程所见。假定由原子操作组合出非原子操作，例如向结构体的原子数据成员赋值，那么别的线程有可能观察到其中的某些原子操作已完成，而某些却还没开始，若多个线程同时赋值，而底层操作相交进行，本来意图完整存入的数据就会彼此错杂。因此，有可能观察到，也有可能得出一个“混合值”的结构体。因此在任何情况下访问非原子变量却欠缺同步保护，会造成简单的条件竞争，进而诱发问题。具体而言，这种级别的访问可能构成数据竞争，并导致未定义行为。

## 标准原子类型

标准原子类型的定义位于头文件<atomic>内。这些类型的操作全是原子化的，并且，根据语言的定义，C++内建的原子操作也仅仅支持这些类型，但也可以用互斥锁来模拟原子操作。

成员函数 is_lock_free() ：准许使用者判定某一给定类型上的操作是能由原子指令直接实现，还是要借助编译器和程序库的内部锁来实。

相对应的宏：针对由不同整数类型特化而成的各种原子类型，在编译期判定其是否属于无锁数据结构。

全部原子类型都含有一个静态常量表达式（static constexpr）成员变量 X::is_always_lock_free，功能与那些宏相同：考察编译生成的一个特定版本的程序，当且仅当在所有支持该程序运行的硬件上，原子类型X全都以无锁结构形式实现，该成员变量的值才为true：

`ATOMIC_BOOL_LOCK_FREE`,  `ATOMIC_CHAR_LOCK_FREE` ,  `ATOMIC_CHAR16_T_LOCK_FREE` ,  `ATOMIC_CHAR32_T_LOCK_FREE` ，`ATOMIC_WCHAR_T_LOCK_FREE`， `ATOMIC_SHORT_LOCK_FREE` ,  `ATOMIC_INT_LOCK_FREE` ,  `ATOMIC_LONG_LOCK_FREE` , `ATOMIC_LLONG_LOCK_FREE`和`ATOMIC_POINTER_LOCK_FREE`

这一功能可在许多情形中派上大用场，原子操作的关键用途是取代需要互斥的同步方式。但是，假如原子操作本身也在内部使用了互斥，就很可能无法达到所期望的性能提升，而更好的做法是采用基于互斥的方式，该方式更加直观且不易出错。

假设一个程序含有原子类型std::atomic<uintmax_t>，而相关的原子操作必须用到某些CPU指令，如果多种硬件可以运行该程序，但仅有其中一部分支持这些指令，那么等到运行时才可以确定它是否属于无锁结构，因此std::atomic<uintmax_t>::is_always_lock_free的值在编译期即确定为false。相反地，若在任意给定的目标硬件上，std::atomic<int>都以无锁结构形式实现，std::atomic<int>::is_always_lock_free的值会是true。

如果原子类型的实现由编译器厂商给出，那么除了直接用类模板std::atomic<>写出别名，还有一组别名可供采用。原子类型历经多时才加入C++标准，逐步演化定型。所以，若使用比较旧的编译器，这些别名作为替换，就会具有两种含义：可能指对应的std::atomic<>特化，也可能指该特化的基类。不过，只要编译器完全支持C++17，那么就可以肯定它们唯一地表示对应的std::atomic<>特化。

| 原子类型        | 相关特化类                         |
| --------------- | ---------------------------------- |
| atomic_bool     | std::atomic&lt;bool>               |
| atomic_char     | std::atomic&lt;char>               |
| atomic_schar    | std::atomic&lt;signed char>        |
| atomic_uchar    | std::atomic&lt;unsigned char>      |
| atomic_int      | std::atomic&lt;int>                |
| atomic_uint     | std::atomic&lt;unsigned>           |
| atomic_short    | std::atomic&lt;short>              |
| atomic_ushort   | std::atomic&lt;unsigned short>     |
| atomic_long     | std::atomic&lt;long>               |
| atomic_ulong    | std::atomic&lt;unsigned long>      |
| atomic_llong    | std::atomic&lt;long long>          |
| atomic_ullong   | std::atomic&lt;unsigned long long> |
| atomic_char16_t | std::atomic&lt;char16_t>           |
| atomic_char32_t | std::atomic&lt;char32_t>           |
| atomic_wchar_t  | std::atomic&lt;wchar_t>            |

除了标准的原子类型，C++标准库还提供了一组标准的原子类型的typedef，对应标准库中内建类型的typedef，例如std::size_t。

表5.2 标准原子类型定义(typedefs)和对应的内置类型定义(typedefs)

| 原子类型定义          | 标准库中相关类型定义 |
| --------------------- | -------------------- |
| atomic_int_least8_t   | int_least8_t         |
| atomic_uint_least8_t  | uint_least8_t        |
| atomic_int_least16_t  | int_least16_t        |
| atomic_uint_least16_t | uint_least16_t       |
| atomic_int_least32_t  | int_least32_t        |
| atomic_uint_least32_t | uint_least32_t       |
| atomic_int_least64_t  | int_least64_t        |
| atomic_uint_least64_t | uint_least64_t       |
| atomic_int_fast8_t    | int_fast8_t          |
| atomic_uint_fast8_t   | uint_fast8_t         |
| atomic_int_fast16_t   | int_fast16_t         |
| atomic_uint_fast16_t  | uint_fast16_t        |
| atomic_int_fast32_t   | int_fast32_t         |
| atomic_uint_fast32_t  | uint_fast32_t        |
| atomic_int_fast64_t   | int_fast64_t         |
| atomic_uint_fast64_t  | uint_fast64_t        |
| atomic_intptr_t       | intptr_t             |
| atomic_uintptr_t      | uintptr_t            |
| atomic_size_t         | size_t               |
| atomic_ptrdiff_t      | ptrdiff_t            |
| atomic_intmax_t       | intmax_t             |
| atomic_uintmax_t      | uintmax_t            |

它们具有简单的关联模式：对于类型T的标准typedef，只要为相同的名称冠以前缀“atomic_”，写成atomic_T，即为相应的原子类型。

> 只有一个原子类型不提供is_lock_free()成员函数：std::atomic_flag。它是简单的布尔标志，因此必须采取无锁操作。只要利用这种简单的无锁布尔标志，就能实现一个简易的锁，进而基于该锁实现其他所有原子类型。其余的原子类型都是通过类模板std::atomic<>特化得出的，功能更加齐全，但可能不属于无锁结构。

对于原子类型上的每一种操作，都可以提供额外的参数，从枚举类std::memory_order取值，用于设定所需的内存次序语义。枚举类std::memory_order具有6个可能的值，包括std::memory_order_relaxed、std::memory_order_acquire、std::memory_order_consume、std::memory_order_acq_rel、std::memory_order_release和 std::memory_order_seq_cst。

操作分为三类：

1. *Store*操作，可选如下内存序：`memory_order_relaxed`, `memory_order_release`, `memory_order_seq_cst`。
2. *Load*操作，可选如下内存序：`memory_order_relaxed`, `memory_order_consume`, `memory_order_acquire`, `memory_order_seq_cst`。
3. *Read-modify-write*(读-改-写)操作，可选如下内存序：`memory_order_relaxed`, `memory_order_consume`, `memory_order_acquire`, `memory_order_release`, `memory_order_acq_rel`, `memory_order_seq_cst`。

## std::atomic_flag

std::atomic_flag是最简单的标准原子类型，表示一个布尔标志。该类型的对象只有两种状态：成立或置零。二者必居其一。经过刻意设计，它相当简单，唯一用途是充当构建单元。

std::atomic_flag类型的对象必须由宏ATOMIC_FLAG_INIT初始化，它把标志初始化为置零状态：

```c++
std::atomic_flag f = ATOMIC_FLAG_INIT
```

无论在哪里声明，也无论处于什么作用域，std::atomic_flag对象永远以置零状态开始，别无他选。

全部原子类型中，只有std::atomic_flag必须采取这种特殊的初始化处理，它也是唯一保证无锁的原子类型。如果std::atomic_flag对象具有静态存储期（static storage duration），它就会保证以静态方式初始化，从而避免初始化次序的问题。对象在完成初始化后才会操作其标志。

完成std::atomic_flag对象的初始化后，只能执行 3 种操作：

- 销毁操作 析构函数；
- 存储操作 clear()：将标志清零，能设定内存次序语义；
- 读改写操作 test_and_set()：获取原有的值，并设置标志成立，能设定内存次序语义；

clear()是存储操作，因此无法采用std::memory_order_acquire或std::memory_order_acq_rel内存次序，而test_and_set()是读-改-写操作，因此能采用任何内存次序。它们默认内存次序都是std::memory_order_seq_cst。

```c++
f.clear(std::memory_order_release);    ⇽---  ①
bool x = f.test_and_set();    ⇽---  ②
```

上面的代码中，clear()的调用显式地采用释放语义将标志清零，而test_and_set()的调用采用默认的内存次序，获取旧值并设置标志成立。

无法从std::atomic_flag对象拷贝构造出另一个对象，也无法向另一个对象拷贝赋值，这两个限制并非std::atomic_flag独有，所有原子类型都同样受限。原因是按定义，原子类型上的操作全都是原子化的，但拷贝赋值和拷贝构造都涉及两个对象，而牵涉两个不同对象的单一操作却无法原子化。

在拷贝构造或拷贝赋值的过程中，必须先从来源对象读取值，再将其写出到目标对象。这是在两个独立对象上的两个独立操作，其组合不可能是原子化的。所以，**原子对象禁止拷贝赋值和拷贝构造**。然而，它们其实可以接受内建类型赋值，也支持隐式地转换成内建类型，还可以直接经由成员函数处理，如load()和store()、exchange()、compare_exchange_weak()和compare_exchange_strong()等。

正因为std::atomic_flag功能有限，所以它可以完美扩展成自旋锁互斥（spin-lock mutex）。最开始令原子标志置零，表示互斥没有加锁。反复调用test_and_set()试着锁住互斥，一旦读取的值变成false，则说明线程已将标志设置成立（其新值为true），则循环终止。而简单地将标志置零即可解锁互斥。

```c++
class spinlock_mutex {
    std::atomic_flag flag; // 初始化为 0
public:
    spinlock_mutex():
        flag(ATOMIC_FLAG_INIT) {}    
    void lock() {
        while(flag.test_and_set(std::memory_order_acquire)); // 获取锁，置为 1
    }
    void unlock() {
        flag.clear(std::memory_order_release); // 清除为 0
    }
};
```

这个互斥非常简单，但已经能够配合std::lock_guard<>运用自如，足以保证互斥发挥功效。然而，从本质上来讲，上述自旋锁互斥在lock()函数内忙等。因此，若不希望出现任何程度的竞争（自旋锁会占用大量的 CPU 时间），那么该互斥远非最佳选择。

由于std::atomic_flag严格受限，甚至不支持单纯的无修改查值操作（test_and_set() 读取旧值必然伴随着修改为新值），无法用作普通的布尔标志，因此最好还是使用std::atomic<bool>。

## std::atomic<bool>

最基本的原子整型类型就是`std::atomic<bool>`，它有着比`std::atomic_flag`更加齐全的布尔标志特性。尽管std::atomic<bool>也无法拷贝构造或拷贝赋值，但还是能依据非原子布尔量创建其对象，初始值是true或false皆可。该类型的实例还能接受非原子布尔量的赋值。

```c++
std::atomic<bool> b(true);
b = false;
```

按C++惯例，赋值操作符通常返回一个引用，指向接受赋值的目标对象（等号左侧的对象）。而非原子布尔量也可以向std::atomic<bool>赋值，但该赋值操作符的行为有别于惯常做法：它直接返回赋予的布尔值。这是原子类型的又一个常见模式：**它们所支持的赋值操作符不返回引用，而是按值返回（该值属于对应的非原子类型）**。

假设返回的是指向原子变量的引用，若有代码依赖赋值操作的结果，那它必须随之显式地加载该结果的值，而另一线程有可能在返回和加载间改动其值。按值返回赋值操作的结果（该值属于非原子类型），就会避开多余的加载动作，从而确保获取的值正是赋予的值。

std::atomic&lt;bool> 有以下成员函数：

- 载入操作 load()：单纯的读取（没有伴随的修改行为），能设定内存次序语义；
- 存储操作 store()：存储（true和false皆可），能设定内存次序语义；
- 读改写操作 exchange()：获取原有的值，自行选定新值作为替换，能设定内存次序语义；

```c++
std::atomic<bool> b;
bool x = b.load(std::memory_order_acquire);
b.store(true);
x = b.exchange(false, std::memory_order_acq_rel);
```

std::atomic<bool>还引入了一种操作：若原子对象当前的值符合预期，就赋予新值。它与exchange()一样，同为读-改-写操作。

这一新操作被称为比较-交换（compare-exchange），实现形式是成员函数compare_exchange_weak()和compare_exchange_strong()。使用者给定一个期望值，原子变量将它和自身的值比较，**如果相等，就存入另一既定的值；否则，更新期望值所属的变量，向它赋予原子变量的值**。比较-交换函数返回布尔类型，如果完成了保存动作（前提是两值相等），则操作成功，函数返回ture；反之操作失败，函数返回false。

对于compare_exchange_weak()，即使原子变量的值等于期望值，保存动作还是有可能失败，因为原子化的比较-交换必须由一条指令单独完成，而某些处理器没有这种指令，无从保证该操作按原子化方式完成，在这种情形下，原子变量维持原值不变，该函数返回false。

要实现比较-交换，负责的线程则须改为连续运行一系列指令，但在这些计算机上，只要出现线程数量多于处理器数量的情形，线程就有可能执行到中途因系统调度而切出，导致操作失败。这种计算机最有可能引发上述的保存失败，称之为佯败（spurious failure）。其败因不是变量值本身存在问题，而是函数执行时机不对。因为compare_exchange_weak()可能佯败，所以它往往必须配合循环使用。

```c++
bool expected = false;
extern atomic<bool> b; //由其他源文件的代码设定变量的值
// 若 b == expected 将 b 变为 true，否则，将 expected 变为 b 的值
while(!b.compare_exchange_weak(expected, true) && !expected);
```

此例中，只要expected变量还是false，就说明compare_exchange_weak()的调用发生佯败，就继续循环。另一方面，只有当原子变量的值不符合预期时，compare_exchange_strong()才返回false。得以明确知悉变量是否成功修改，或者是否存在另一线程抢先切入而导致佯败，从而能够摆脱上例所示的循环。

不论原子变量具有什么初始值，假设就是想要修改它（也许是要根据当前值进行更新），那么针对变量expected的更新则会发挥作用。每次循环它都会重新载入，所以如果两者不相等，又没有其他线程同时进行改动，变量expected即被赋予原子变量的值，compare_exchange_weak()或compare_exchange_strong()的调用在下一轮循环将成功。

假如经过简单计算就能得出要保存的值，而在某些硬件平台上，虽然使用compare_exchange_weak()可能导致佯败，但改用compare_exchange_strong()却会形成双重嵌套循环（compare_exchange_strong()自身内部含有一个循环），那么采用compare_exchange_weak()比较有利于性能。反之，如果存入的值需要耗时的计算，选择compare_exchange_strong()则更加合理。因为只要预期值没有变化，就可避免重复计算。就std::atomic<bool>而言，这并不是很重要，毕竟只有两种可能的值。但是对于体积较大的原子类型，这两种处理的区别很大。

比较-交换函数还有一个特殊之处：它们接收两个内存次序参数。这使程序能区分成功和失败两种情况，从而采用不同的内存次序语义，对此有以下规定：

- 失败操作设定的内存次序不能比成功操作的更严格；若将失败操作的内存次序指定为std::memory_order_acquire或std::memory_order_seq_cst，则要向成功操作设定同样的内存次序。
- 失败操作没有存储行为，所以不可能采用std::memory_order_release内存次序或std::memory_order_acq_rel内存次序。因而这两种内存次序不准用作失败操作的参数。

合适的做法是：**若操作成功，就采用std::memory_order_acq_rel内存次序，否则改用std::memory_order_relaxed内存次序。**

如果没有设定失败操作的内存次序，那么编译器就假定它和成功操作具有同样的内存次序，但其中的释放语义会被移除：memory_order_release会变成std::memory_order_relaxed，而std::memory_order_acq_rel则变成std::memory_order_acquire。若成功和失败两种情况都未设定内存次序，则它们采用默认内存次序std::memory_order_seq_cst，依照完全顺次的方式读写内存。下面代码中的两次compare_exchange_weak()调用等价。

```c++
std::atomic<bool> b;
bool expected;
b.compare_exchange_weak(expected, true, memory_order_acq_rel, memory_order_acquire);
b.compare_exchange_weak(expected, true, memory_order_acq_rel);
```

std::atomic<bool>和std::atomic_flag的另一个不同点是，前者有可能不具备无锁结构，它的实现可能需要在内部借用互斥，以保证操作的原子性。这通常不成问题，但保险起见，我们还可以调用成员函数is_lock_free()，检查std::atomic<bool>是否具备真正的无锁操作。除std::atomic_flag之外，所有原子类型都提供这项检查功能。

## std::atomic<T*>

指向类型T的指针，其原子化形式为std::atomic<T*>，类似于原子化的布尔类型std::atomic<bool>。两者的接口相同，但操作目标从布尔类型变换成相应的指针类型。

它与std::atomic<bool>相似，同样不能拷贝复制或拷贝赋值。然而，只要依据适合的指针，就可以创建该原子类型的对象，接受其赋值。根据类模板的定义，std::atomic<T*>也具备成员函数is_lock_free()、load()、store()、exchange()、compare_exchange_weak()和compare_exchange_strong() ，它们与std::atomic<bool>中的对应函数有着相同的语义，但接收的参数和返回值不再是布尔类型，而是T\*类型。

std::atomic<T\*>提供的新操作是算术形式的指针运算。成员函数fetch_add()和fetch_sub()给出了最基本的操作，分别就对象中存储的地址进行原子化加减。另外，该原子类型还具有包装成重载运算符的+=和−=，以及++和−−的前后缀版本。

这些运算符作用在原子类型之上，效果与作用在内建类型上一样：假设变量x属于类型std::atomic<Foo\*>，其指向Foo对象数组中的第一项，那么操作x+=3会使之变为指向数组第四项，并返回Foo\*型的普通指针，其指向第四项。

而fetch_add()和fetch_sub()则稍微不同，它们**返回原来的地址**。因此，操作x.fetch_add(3)会更新x，令其指向数组第四项，但返回的指针则指向第一项。该操作又名交换相加，与exchange()和compare_exchange_weak()/compare_exchange_strong()同属一类，也是一种读-改-写操作。与其他原子操作相同，返回的是非原子类型，它返回T\*型的普通指针，而不是指向std::atomic<T*>对象的引用。

```c++
class Foo{};
Foo some_array[5];
std::atomic<Foo*> p(some_array);
Foo* x=p.fetch_add(2);    ⇽---  ①令p加2，返回旧值
assert(x==some_array);
assert(p.load()==&some_array[2]);
x=(p-=1);    ⇽---  ②令p减1，返回新值
assert(x==&some_array[1]);
assert(p.load()==&some_array[1]);
```

由于fetch_add()和fetch_sub()都是“读-改-写”操作，因此可以为其选取任何内存次序，它们还能参与释放序列。无法向运算符给出内存次序信息，因此不能设定内存次序语义，因此这些形式的操作总是服从std::memory_order_seq_cst内存次序。

在 std::atomic<int>和std::atomic<unsigned long long>这样的整数原子类型上的相关操作：

- 原子操作：load()、store()、exchange()、compare_exchange_weak()和compare_exchange_strong()
- 原子运算：fetch_add()、fetch_sub()、fetch_and()、fetch_or()、fetch_xor()
- 复合：+=、−=、&=、|=和^=，++x、x++、−−x和x−−，虽然整数原子类型上的相关操作尚不算全面，但已经近乎完整，所缺少的重载运算符仅仅是乘除与位移。这并非严重缺陷。实际上，整数原子类型往往只用作计数器或位掩码（bitmask）

上述操作的语义非常接近std::atomic<T*>类型的fetch_add()和fetch_sub()：具名函数按原子化方式执行操作，并返回原子对象的旧值，然而复合赋值运算符则返回新值。前后缀形式的自增和自减都按既有方式工作：++x令变量自增，并返回新值；x++也令变量自增，但返回旧值。前后缀形式的加减操作全都返回对应的内置整型值。

## std::atomic<>

除了前文的标准原子类型，使用者还能利用泛化模板，依据自定义类型创建其他原子类型。给出一自定义类型UDT，其原子化类型就是std::atomic<UDT>，所提供的接口与std::atomic<bool>相同，不同之处在于，函数中凡是涉及该类原子对象所表示的值，它的参数和返回值就要改成UDT类型。只有比较-交换操作依然用结果说明成败，参数还是布尔值。

然而，无法在std::atomic<>上随意套用任何自定义类型。对于某个自定义类型UDT，**要满足一定条件才能具现化出std::atomic<UDT>**：必须具备平实拷贝赋值操作符，它不得含有任何虚函数，也不可以从虚基类派生得出，还必须由编译器代其隐式生成拷贝赋值操作符；另外，若自定义类型具有基类或非静态数据成员，则它们同样必须具备平实拷贝赋值操作符。由于以上限制，赋值操作不涉及任何用户编写的代码，因此编译器可借用memcpy()或采取与之等效的行为完成它。

最后，值得注意的是，比较-交换操作所采用的是逐位比较运算，效果等同于直接使用memcmp()函数。即使UDT自行定义了比较运算符，在这项操作中也会被忽略。若自定义类型含有填充位，却不参与普通比较操作，那么即使UDT对象的值相等，比较-交换操作还是会失败。

上述限制的来由：若采用锁保护数据，而代码又涉及使用者提供的函数，则不得将受保护数据的指针或引用传入该函数，因为那样会让它脱离锁的作用域。编译器往往没能力为std::atomic<UDT>生成无锁代码，因此它必须在内部运用锁保护所有操作。如果准许UDT自行定义拷贝赋值操作符或比较运算符，就需要向其传入受保护数据的引用作为参数。此外，程序库完全有可能根据需要而仅凭唯一一个锁保护所有原子操作，若调用用户提供的函数中也有锁，可能会产生死锁。另外，万一自定义的比较运算耗时过长，则会致使其他线程阻塞。最后，通过这种种限制，编译器遂能将用户自定义类型视为原始字节，从而使某些特定的原子类型按无锁方式具现化，增加为std::atomic<UDT>类型直接执行原子指令的机会。

内建浮点类型确实满足了memcpy()和memcmp()的适用条件，故类型std::atomic<float>和std::atomic<double>可以使用。但内在因素可能导致compare_exchange_weak()失败。即便原子类型内本来存有的值与比较的值相等，若两个值的表示方式不同，依然会令函数操作失败。浮点值的算术原子运算并不存在。假设用某个自定义类型特化std::atomic<>，而该类型定义了自己的等值比较运算符重载，它的判别方式与memcmp()不同，如果就这一特化调用compare_exchange_strong()，那么该函数的行为与处理浮点原子类型的情况类似，虽然参与比较的两个值相等，但比较-交换操作还是会因表示方式不同而失败。

若依据自定义类型T将原子类模板实例化，则类型std::atomic<T>的接口与std::atomic<bool>相似，可用的操作有限，包括load()、store()、exchange()、compare_exchange_weak()和compare_exchange_strong()，以及接受类型T的实例的赋值、转换成类型T的实例。

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/5-3-table.png)

## 原子操作的非成员函数

大部分非成员函数依据对应的成员函数命名，只不过冠以前缀atomic\_（如std::atomic_load()），它们还针对各原子类型进行了重载。只要有可能指定内存次序，这些函数就衍化出两个变体：一个带有后缀_explicit，接收更多参数以指定内存次序，而另一个则不带后缀也不接收内存次序参数:

```c
std::atomic_store_explicit(&atomic_var,new_value,std::memory_order_release)
std::atomic_store(&atomic_var,new_value)
```

成员函数的调用会隐式地操作原子对象，但所有非成员函数的第一个参数都是指针，指向所要操作的目标原子对象。

例如，std::atomic_is_lock_free()只有一个变体（其实该函数还是为每个原子类型进行了重载），就原子类型的对象a而言，函数调用std::atomic_is_lock_free(&a)和a.is_lock_free()等价，且返回值相同。类似地，std::atomic_load(&a)和a.load()行为一致，而a.load(std:: memory_order_acquire)的等价调用则是std::atomic_load_explicit(&a, std::memory_order_acquire)。

根据C++标准的设计，这些非成员函数要兼容C语言，所以它们全都只接收指针，而非引用。例如，成员函数compare_exchange_weak()和compare_exchange_strong()的第一个参数都是引用（期望值），而非成员函数std::atomic_compare_exchange_weak()的第二个参数与之对应，却是指针（其第一个参数是目标原子对象的指针）。

负责比较-交换的成员函数都具有两个重载，一个版本只接受一种内存次序（默认参数值为std::memory_order_seq_cst），而另一个版本则接受两种内存次序，分别用于成功和失败的情况。但非成员函数std::atomic_compare_exchange_weak_explicit()则没有重载版本，须同时为两种情况各自设定内存次序。

操作std::atomic_flag的非成员函数是std::atomic_flag_test_and_set()和std::atomic_flag_clear()，它们并未严格遵从上述规则，在名字中加入了“−flag”。它们也具有其他变体，以后缀“_explicit”结尾，用于指定内存次序，如std::atomic_flag_test_and_set_explicit()和std::atomic_flag_clear_explicit()。

C++标准库还提供了非成员函数，按原子化形式访问std::shared_ptr<>的实例。这是一个突破。因为原则上只有原子类型才支持原子操作，而std::shared_ptr<>不属于原子类型（如果多个线程访问同一个std::shared_ptr<T>对象，但它们都未采用原子函数访问，也未借助外界同步，那就会诱发数据竞争和未定义行为）。

标准库给出了共享指针的原子操作（载入、存储、交换和比较-交换），它们与标准原子类型上的操作一样，都是对应的同名函数的重载，而且第一个参数都属于std:shared_ptr<>*类型。C++标准库也对原子类型中的`std::shared_ptr<>`智能指针类型提供非成员函数，这打破了只有原子类型，才能提供原子操作的原则。可使用的原子操作有：load, store, exchange和compare/exchange，这些操作重载了标准原子类型的操作，并且可获取`std::shared_ptr<>*`作为第一个参数：

```c++
std::shared_ptr<my_data> p;
void process_global_data() {
    std::shared_ptr<my_data> local = std::atomic_load(&p);
    process_data(local);
}
void update_global_data() {
    std::shared_ptr<my_data> local(new my_data);
    std::atomic_store(&p,local);
}
```

操作std::share_ptr的函数也具有变体，与其他类型上的非成员原子操作的变体相同，都以后缀“_explicit”结尾，能设定内存次序。而std::atomic_is_lock_free()也有针对std::share_ptr的重载，功能是检验它是否通过锁来实现原子性。

并发技术规约还提供了std::experimental::atomic_shared_ptr<T>，其也是一种原子类型。我们须包含头文件<experimental/atomic>才能使用该类型。与std::atomic<UDT>上的操作一样，它具备以下操作：载入、存储、交换和比较-交换。atomic_shared_ptr<>被设计成一个独立类型，因为按照这种形式，它有机会通过无锁方式实现，而且比起普通的std::shared_ptr对象，它没有增加额外开销。但是在目标硬件平台上，仍需查验它是否属于无锁实现，这可以由成员函数is_lock_free()判定，与类模板std::atomic<>上的做法相同。

在多线程环境下处理共享指针，要避免采用普通的std::share_ptr类型，也不要通过非成员原子函数对其进行操作（开发者很容易忘记这么做而误用普通函数），类型std::experimental::atomic_shared_ptr应予优先采用（就算它不是无锁实现）。原因是，后者可以使代码更加清晰，并确保全部访问都按原子化方式进行，还能预防误用普通函数，最终避免数据竞争。若利用原子类型及其操作是为了程序加速，那就大有必要进行性能剖析（profile），并对比其他同步方式的效果。

# 同步操作和强制次序

标准原子类型不仅能避免未定义操作、防范数据竞争，还能让用户强制线程间的操作服从特定次序。数据保护和操作工具的同步，如std::mutex和std::future<>，都以这种强制服从的内存次序为基础。

假设有两个线程共同操作一个数据结构，其中一个负责增添数据，另一个负责读取数据。为了避免恶性条件竞争，写线程设置一个标志，用以表示数据已经存储妥当，而读线程则一直待命，等到标志成立才着手读取。

```c++
std::vector<int> data;
std::atomic<bool> data_ready(false);

void reader_thread() {
  while(!data_ready.load()) { // 1
    std::this_thread::sleep(std::milliseconds(1));
  }
  std::cout<<"The answer="<<data[0]<<"\m";  // 2
}
void writer_thread() {
  data.push_back(42);  // 3
  data_ready=true;  // 4
}
```

在一份数据上进行非原子化的读 2 与写 3，却没有强制这些访问服从一定的次序，将导致未定义行为，因此要让代码正确运作，就必须为其施行某种次序。

因此需要原子变量data_ready的操作提供所需的强制次序，它属于std::atomic<bool>类型，凭借两种内存模型关系“先行”和“同步”，这些操作确定了必要的次序。数据写出 3 在设置标志成立 4 之前发生，且 4 在从标志读取true值 1 之前发生，而 1 在读取数据 2 之前发生，又因为先行关系可传递，所以这些操作被强制施行了预定的次序：数据写出在数据读取操作前面发生。

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/5-2.png)

## 同步

同步关系只存在于原子类型的操作之间。如果一种数据结构含有原子类型，并且其整体操作都涉及恰当的内部原子操作，那么该数据结构的多次操作之间（如锁定互斥）就可能存在同步关系。但同步关系从根本上来说来自原子类型的操作。

同步关系的基本思想是：对变量 x 执行原子写操作 W 和原子读操作 R，且两者都有适当的标记。只要满足下面其中一点，它们即彼此同步。

- R 读取了 W 直接存入的值。
- W 所属线程随后还执行了另一原子写操作，R 读取了后面存入的值。
- 任意线程执行一连串读-改-写操作，而其中第一个操作读取的值由 W 写出。

所有细微的差别都在“适当的标记”中，C++内存模型允许为原子类型提供各种次序约束。

## 先行

先行关系和严格先行关系是在程序中确立操作次序的基本要素；它们的用途是清楚界定哪些操作能看见其他哪些操作产生的结果。在单一线程内，这种关系通常非常直观：若某项操作按控制流程顺序在另一项之前执行，前者即先于后者发生，且前者严格先于后者发生。具体而言，在源代码中，若甲操作的语句位于乙操作之前，那么甲就先于乙发生，且甲严格先于乙发生。

上述例子在写线程上，容器data的写操作 3 先于原子标志 data_ready 的写操作 4。但**如果同一语句内出现多个操作，则它们之间通常不存在先行关系，因为 C++ 标准没有规定执行次序（换言之，执行次序不明）**。代码清单5.3会输出 1,2 或 2,1，但因两次调用get_num()的次序不明，所以无法确定到底输出哪一个。

代码5.3 对于参数中的函数调用顺序未指定顺序

```c++
#include <iostream>
void foo(int a, int b) {
  std::cout << a <<”,”<< b << std::endl;
}
int get_num() {
  static int i = 0;
  return ++i;
}
int main() {
  foo(get_num(), get_num());  // 无序调用get_num()
}
```

某些单一语句含有多个操作，还是会按一定的顺序执行：譬如由内建逗号操作符拼接而成的表达式；又如，一个表达式的结果可以充当另一个表达式的参数。但**单一语句中的多个操作往往没有规定次序，它们之间不存在控制流程的先后关系，因而也没有先行关系**，一条语句中的所有操作全在下一条语句的所有操作之前执行。

若某一线程执行甲操作，另一线程执行乙操作，从跨线程视角观察，甲操作先于乙操作发生，则甲操作先行于乙操作。虽然引入的新的线程间先行关系似乎不太有用，但其实它对多线程的代码编写具有重要意义。在基础层面上，线程间先行（inter-thread happens-before）关系相对简单，它依赖于同步关系：**如果甲、乙两操作分别由不同线程执行，且它们同步，则甲操作跨线程地先于乙操作发生。**这也是可传递关系：若甲操作跨线程地先于乙操作发生，且乙操作跨线程地先于丙操作发生，则甲操作跨线程地先于丙操作发生。

上面的两条规则同样适用于严格先行关系：若甲操作与乙操作同步，或甲操作按流程顺序在乙操作之前发生，则甲操作严格地在乙操作之前发生。传递规律也都适用。区别在于，在线程间先行关系和先行关系中，各种操作都被标记为memory_order_consume，而严格先行关系则无此标记。

## 原子操作的内存次序

原子类型上的操作服从 6 种内存次序：：

1. memory_order_relaxed
2. memory_order_consume
3. memory_order_acquire
4. memory_order_release
5. memory_order_acq_rel
6. memory_order_seq_cst

其中，memory_order_seq_cst是可选的最严格的内存次序，各种原子类型的所有操作都默认遵从该次序。

虽然内存次序共有6种，但它们只代表3种模式：先后一致次序（memory_order_seq_cst）、获取-释放次序（memory_order_consume、memory_order_acquire、memory_order_release和memory_order_acq_rel）、宽松次序（memory_order_relaxed）。

### 先后一致次序

假设在多线程程序的全部原子类型的实例上，所有操作都保持先后一致，那么若将它们按某种特定次序改由单线程程序执行，则两个程序的操作将毫无区别。只要服从该次序，全部线程所见的一切操作都必须服从相同的次序，这是目前最容易理解的内存次序，它因此被选作默认内存次序。

代码5.4 全序——序列一致性

```c++
std::atomic<bool> x,y;
std::atomic<int> z;

void write_x() {
    x.store(true,std::memory_order_seq_cst);   
}

void write_y() {
    y.store(true,std::memory_order_seq_cst); 
}

void read_x_then_y() {
    while(!x.load(std::memory_order_seq_cst)); // x == true 
    if(y.load(std::memory_order_seq_cst)) ++z; // 才能加载 y
}

void read_y_then_x() {
    while(!y.load(std::memory_order_seq_cst)); // y == true 
    if(x.load(std::memory_order_seq_cst)) ++z; // 才能加载 x
}

int main() {
    x=false;
    y=false;
    z=0;
    std::thread a(write_x);
    std::thread b(write_y);
    std::thread c(read_x_then_y);
    std::thread d(read_y_then_x);
    a.join();
    b.join();
    c.join();
    d.join();
    assert(z.load()!=0); // 断言肯定不会触发，因为x和y其中一个的存储操作必然先行发生，虽然并不明确哪个会先发生。
}
```

首先初始化为 false，只有当 x 或 y 中一个执行了存储操作，才能执行 read_x_then_y 或 read_y_then_x 函数，因此，**存储操作一定在载入操作前执行**。

其次：

- 若在 read_x_then_y() 函数中，变量 y 载入失败而返回 false，则说明 x == true，x 的存储操作则必然发生在 y 的存储操作之前，在此基础上，read_y_then_x() 中变量 x 载入必会是 true，因为只有 y == true 才能执行载入操作。
- 若在 read_y_then_x() 函数中，变量 x 载入失败而返回 false，则说明 y == true，y 的存储操作则必然发生在 x 的存储操作之前，在此基础上，read_x_then_y() 中变量 y 载入必会是 true，因为只有 x == true 才能执行载入操作。

图5.3描绘了其中多个操作的先行关系。在函数read_x_then_y()中，虚线从变量y的载入操作引出，指向函数write_y()中的y的存储操作，这说明必须存在次序关系才可能保持先后一致：要实现上述运行结果，在服从memory_order_seq_cst次序的全局操作序列中，载入操作必须在存储操作之前完成。

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/5-3.png)

先后一致次序是最直观、最符合直觉的内存次序，但由于它要求在所有线程间进行全局同步，因此也是代价最高的内存次序。在多处理器系统中，处理器之间也许为此而需要频繁通信。

### 非先后一致次序

即使多个线程上运行的代码相同，由于某些线程上的操作没有显式的次序约束，因此它们有可能无法就多个事件的发生次序达成一致，而在不同的CPU缓存和内部缓冲中，同一份内存数据也可能具有不同的值。因此线程之间不必就事件发生次序达成一致。

不仅须舍弃交替执行完整操作的思维模式，还得修正原来的认知，不再任由编译器或处理器自行重新排列指令。如果没有指定程序服从哪种内存次序，则采用默认内存次序。它仅仅要求一点：全部线程在每个独立变量上都达成一致的修改序列。不同变量上的操作构成其特有的序列，假设各种操作都受施加的内存次序约束，若线程都能看到变量的值相应地保持一致，就容许这个操作序列在各线程中出现差别。

完全脱离先后一致次序的最佳示范就是，将上例的全部操作改用memory_order_relaxed次序。

### 宽松次序

如果采用宽松次序，那么原子类型上的操作不存在同步关系。**在单一线程内，同一个变量上的操作仍然服从先行关系，但几乎不要求线程间存在任何次序关系。该内存次序的唯一要求是，在一个线程内，对相同变量的访问次序不得重新编排。**

对于给定的线程，一旦它见到某原子变量在某时刻持有的值，则该线程的后续读操作不可能读取相对更早的值。memory_order_relaxed次序无须任何额外的同步操作，线程间仅存的共有信息是每个变量的改动序列。

代码5.5 非限制操作只有非常少的顺序要求

```c++
std::atomic<bool> x,y;
std::atomic<int> z;
void write_x_then_y() {
    x.store(true,std::memory_order_relaxed);    ⇽---  ①
    y.store(true,std::memory_order_relaxed);    ⇽---  ②
}
void read_y_then_x() {
    while(!y.load(std::memory_order_relaxed));    ⇽---  ③
    if(x.load(std::memory_order_relaxed)) ++z;   ⇽---  ④
}
int main() {
    x=false;
    y=false;
    z=0;
    std::thread a(write_x_then_y);
    std::thread b(read_y_then_x);    
    a.join();
    b.join();
    assert(z.load()!=0); // 断言会触发错误
}
```

即使变量 y 的载入操作读取了 true 值，且变量 x 的存储操作在 y 的存储操作之前发生，变量 x 的载入操作也可能读取 false 值。

因为变量 x 的存储操作和载入操作分属不同线程，变量 x 和 y 分别执行操作，让各自的值发生变化，但它们**采用了宽松次序，不保证其变化可为对方所见**，所以后者不一定能见到前者执行产生的效果，即存储的新值 true 还停留在 CPU 缓存中，而读取的 false 值是来自内存的旧值。

不同变量上的宽松原子操作可自由地重新排列，前提是这些操作受到限定而须服从先行关系（譬如在同一个线程内执行的操作），不会产生同步关系。

图5.4展示了代码清单5.5中的先行关系。在变量 x 和 y 的两项存储操作之间，以及它们的两项载入操作之间，确实有着先行关系。但是，任一存储操作与任一载入操作之间却不存在同步关系。

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/5-4.png)

要想获取额外的同步，且不使用全局排序一致，可以使用*获取-释放序*(acquire-release ordering)。

### 获取-释放次序

获取-释放次序比宽松次序严格一些，它会产生一定程度的同步效果，而不会形成服从先后一致次序的全局总操作序列。在该内存模型中，原子化载入即为获取操作（memory_order_acquire），**原子化存储即为释放操作**（memory_order_release），而原子化读-改-写操作则为获取或释放操作，或二者皆是（memory_order_acq_rel）。

这种内存次序在成对的读写线程之间起到同步作用。**释放与获取操作构成同步关系，前者写出的值由后者读取。**

代码5.7 **获取-释放不意味着统一操作顺序**

```c++
std::atomic<bool> x,y;
std::atomic<int> z;
void write_x() {
    x.store(true,std::memory_order_release);
}
void write_y() {
    y.store(true,std::memory_order_release);
}
void read_x_then_y() {
    while(!x.load(std::memory_order_acquire));
    if(y.load(std::memory_order_acquire)) ++z; // 1
}
void read_y_then_x() {
    while(!y.load(std::memory_order_acquire));
    if(x.load(std::memory_order_acquire)) ++z; // 2
}
int main() {
    x=false;
    y=false;
    z=0;
    std::thread a(write_x);
    std::thread b(write_y);
    std::thread c(read_x_then_y);
    std::thread d(read_y_then_x);
    a.join();
    b.join();
    c.join();
    d.join();
    assert(z.load()!=0); // 3
}
```

例子中断言可能会触发(就如同自由排序那样)，因为在加载 x 和 y 时，可能读取到 false。因为 x 和 y 是由不同线程写入，所以序列中的每一次释放和获取都不会影响到其他线程的操作。因此只是提供了同步，没有强制操作顺序。

图5.6展示了代码5.7的先行关系，对于读取的结果，两个(读取)线程看到的是两个完全不同的世界。如前所述，这可能是因为这里没有对先行顺序进行强制规定导致的。

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/5-6.png)

为了了解获取-释放序的优点，需要考虑将两次存储由一个线程来完成，就像代码5.5那样。当需要使用 memory_order_release 改变 y 中的存储，并使用 memory_order_acquire 来加载 y 中的值，而后就会影响对 x 的操作。

代码5.8 获取-释放序操作会影响释放操作

```c++
std::atomic<bool> x,y;
std::atomic<int> z;

void write_x_then_y() {
  x.store(true,std::memory_order_relaxed);  // 1 
  y.store(true,std::memory_order_release);  // 2
}
void read_y_then_x() {
  while(!y.load(std::memory_order_acquire));  // 3 自旋，等待y被设置为true
  if(x.load(std::memory_order_relaxed))  // 4
    ++z;
}
int main() {
  x=false;
  y=false;
  z=0;
  std::thread a(write_x_then_y);
  std::thread b(read_y_then_x);
  a.join();
  b.join();
  assert(z.load()!=0);  // 5
}
```

最后，读取 y 时会得到true，和存储时写入的一样。存储使用的是memory_order_release，读取使用的是memory_order_acquire，存储与读取就同步。因为这两个操作是由同一个线程串行完成的，所以存储 x 的操作先行于存储 y 的操作。对 y 的存储同步与对 y 的加载，存储 x 也就先行于对 y 的加载，并且扩展先行于 x 的读取。因此，加载 x 的值必为 true，并且断言不会触发。

为了保证同步，载入和释放操作必须成对。所以，无论有何影响，释放操作存储的值必须要让获取操作看到。当存储②或加载③都是一个释放操作时，对x的访问就无序了，也就无法保证④处读到的是true，并且还会触发断言。

### 获取-释放序传递同步

需要至少3个线程来解释次序传递。线程甲改动某些共享变量，在其中一个变量上执行存储-释放操作。然后，线程乙用载入-获取操作读取该变量，该操作服从存储-释放次序。接着，线程乙对第二个共享变量执行存储-释放操作。最后，线程丙对第二个共享变量执行载入-获取操作。假设同步关系确立的前提条件是存储-释放操作写出的值能为载入-获取操作所见，那么以此为据，线程丙就能够读取线程甲所存储的其他变量，即使这些变量与过渡线程（乙）全无接触。

代码5.9 使用获取和释放序传递同步

```c++
std::atomic<int> data[5];
std::atomic<bool> sync1(false),sync2(false);
void thread_1() {
    data[0].store(42,std::memory_order_relaxed);
    data[1].store(97,std::memory_order_relaxed);
    data[2].store(17,std::memory_order_relaxed);
    data[3].store(-141,std::memory_order_relaxed);
    data[4].store(2003,std::memory_order_relaxed);
    sync1.store(true,std::memory_order_release);    ⇽---  ①设置sync1成立
}
void thread_2() {
    while(!sync1.load(std::memory_order_acquire));    ⇽---  ②一直循环，到sync1成立为止
    sync2.store(true,std::memory_order_release);    ⇽---  ③设置sync2成立
}
void thread_3() {
    while(!sync2.load(std::memory_order_acquire));    ⇽---  ④一直循环，到sync2成立为止
    assert(data[0].load(std::memory_order_relaxed)==42);
    assert(data[1].load(std::memory_order_relaxed)==97);
    assert(data[2].load(std::memory_order_relaxed)==17);
    assert(data[3].load(std::memory_order_relaxed)==-141);
    assert(data[4].load(std::memory_order_relaxed)==2003);
}
```

尽管线程thread_2只接触过变量sync1和sync2，但这足以同步线程thread_1和thread_3，从而保证每个断言都不会触发。首先，线程thread_1对各数组data和变量sync1执行操作，因同属一个线程，故各**data元素的存储均在变量sync1的存储之前发生**。

而线程 thread_2 运用 while 循环反复载入变量 sync1，因此该操作最终会见到线程 thread_1 所存储的值，这两项操作形成配对，服从获取-释放次序。一旦变量 sync1 载入true值，while 循环随即停止，这说明变量 sync1 的存储操作在此之前发生。

在线程 thread_2 上，按控制流程顺序，变量 sync1 的载入操作在 sync2 的存储操作之前发生。类似地，变量 sync2 的存储操作在其载入操作之前发生，而 sync2 的载入操作在各 data 元素的载入操作前发生。

再考虑到先行关系可传递，将以上操作串接起来：各 data 元素的存储操作在变量 sync1 的存储操作之前发生，变量 sync1 的存储操作在变量 sync1 的载入操作之前发生，变量 sync1 的载入操作在变量 sync2 的存储操作之前发生，变量 sync2 的存储操作在其载入操作之前发生，而其载入操作在data 元素的载入操作之前发生。因此，各 data 元素的存储操作在其载入操作之前发生（前者由线程thread_1执行，后者由线程thread_3执行），断言不会触发。　　

上例中，还能进一步将变量 sync1 和 sync2 融合成单一变量，在线程 thread_2 上对其执行读-改-写操作，该操作采用 memory_order_acq_rel 次序。可以选用 compare_exchange_strong() 来执行操作。通过这个函数可以保证，只有见到线程 thread_1 完成存储之后，才更新该单一变量。

```c++
std::atomic<int> sync(0);
void thread_1() {
  // ...
  sync.store(1,std::memory_order_release);
}

void thread_2() {
  int expected=1;
  while(!sync.compare_exchange_strong(expected, 2, std::memory_order_acq_rel)) expected=1;
}
void thread_3() {
  while(sync.load(std::memory_order_acquire)<2);
  // ...
}
```

如果使用读-改-写操作，选择满足需要的内存次序语义则是关键。上面的场景中，同时需要获取语义和释放语义，所以选择次序 memory_order_acq_rel 正合适。

举个反例，采用 memory_order_acquire 次序的 fetch_sub() 不会与任何操作同步，因为它不是释放操作。类似地，存储操作无法与采用memory_order_release 次序的 fetch_or() 同步，因为 fetch_or() 所含的读取行为并不是获取操作。若读-改-写操作采用memory_order_acq_rel次序，则其行为是获取和释放的结合，因此前方的存储操作会与之同步，而它也会与后方的载入操作同步，正如本例所示。

若将获取-释放操作与保序操作交错混杂，那么保序载入的行为就与服从获取语义的载入相同，保序存储的行为则与服从释放语义的存储相同。如果读-改-写操作采用保序语义，则其行为是获取和释放的结合。混杂其间的宽松操作仍旧宽松，但由于获取-释放语义引入了同步关系（也附带引入了先行关系），这些操作的宽松程度因此受到限制。

尽管锁操作的运行效果有可能远离预期，但如果使用过锁，就要面对一个次序问题：给互斥加锁是获取操作，解锁互斥则是释放操作。互斥的有效使用方法是必须确保锁住了同一个互斥，才读写受保护的相关变量。同理，获取和释放操作唯有在相同的原子变量上执行，才可确保这些操作服从一定的次序。如果要凭借互斥保护数据，由于锁具有排他性质，因此其上的加锁和解锁行为服从先后一致次序。

类似地，假设利用获取-释放次序实现简单的锁，那么考察一份使用该锁的代码，其行为表现将服从先后一致次序，而加锁和解锁之间的内部行为则不一定。如果原子操作对先后一致的要求不是很严格，那么由成对的获取-释放操作实现同步，开销会远低于由保序操作实现的全局一致顺序。

> memory_order_consume 次序相当特别：它完全针对数据依赖，引入了线程间先行关系中的数据依赖细节。在实际代码中，凡是要用到memory_order_consume次序的情形，应当一律改用memory_order_acquire次序。

## 释放队列与同步

针对同一个原子变量，可以在线程甲上对其执行存储操作，在线程乙上对其执行载入操作，从而构成同步关系。即使存储和读取之间还另外存在多个读-改-写操作，同步关系依然成立，但这一切的前提条件是，所有操作都采用适合的内存次序标记。

如果存储操作的标记是memory_order_release、memory_order_acq_rel或memory_order_seq_cst，而载入操作则以memory_order_consume、memory_order_acquire或memory_order_seq_cst标记，这些操作前后相扣成链，每次载入的值都源自前面的存储操作，那么该操作链由一个释放序列组成。若最后的载入操作服从内存次序memory_order_acquire或memory_order_seq_cst，则最初的存储操作与它构成同步关系。操作链中，每个读-改-写操作都可选用任意内存次序，甚至也能选用memory_order_relaxed次序。

> 但如果该载入操作服从的内存次序是memory_order_consume，那么两者构成前序依赖关系。

代码5.11 使用原子操作从队列中读取数据

```c++
std::vector<int> queue_data;
std::atomic<int> count;
void populate_queue() {
    unsigned const number_of_items=20;
    queue_data.clear();
    for(unsigned i=0;i<number_of_items;++i) {
        queue_data.push_back(i);
    } 
    count.store(number_of_items, std::memory_order_release);    ⇽---  ①最初的存储操作
}

void consume_queue_items() {    
    while(true) {
        int item_index;
        if((item_index = count.fetch_sub(1,std::memory_order_acquire)) <= 0)    ⇽---  ②一项“读—改—写”操作
        {
            wait_for_more_items();    ⇽---  ③等待队列容器装入新数据项
            continue;
        }
        process(queue_data[item_index-1]);    ⇽---  ④从内部容器 queue_data 读取数据项是安全行为
    }
}
int main() {
    std::thread a(populate_queue);
    std::thread b(consume_queue_items);
    std::thread c(consume_queue_items);
    a.join();
    b.join();
    c.join();    
}
```

代码以生产-消费模式为例，让生产线程将生成的数据存储到共享缓冲，然后执行`count.store(number_of_items, std::memory_order_release)`，让其他线程知悉已有数据可用。消费线程则执行`count.fetch_sub(1,std::memory_order_acquire)`，表示向其他线程通告它会从容器取出一项数据，然后才真正读取共享缓冲。一旦计数器的值变为0，即再无数据项可取，消费线程必须就此等待。

如果只存在一个消费线程，那么一切如常。fetch_sub()是服从memory_order_acquire次序的读取操作，而且存储操作服从memory_order_release次序，所以存储和读取构成同步关系，该线程可以从共享缓冲读取数据。

若有两个线程读取数据，那它们都会按原子化方式执行fetch_sub()，但后一个进程所读取的值是前一个写出的结果。假设上述释放序列的规则不成立，那么两个消费线程之间不会构成先行关系，进而读取共享缓冲的并发读取就不再安全，除非前一个fetch_sub()也采用memory_order_release次序，但这会在两个线程间引发过分严格的同步，实无必要。要是释放序列的规则不成立，或fetch_sub()没有采用memory_order_release次序，那么queue_data容器上的存储就不会为第二个消费线程所见，结果引发数据竞争。

万幸事实并非如此，第一个fetch_sub()处于释放序列中，所以store()也与第二个fetch_sub()同步。但其实两个消费线程之间仍未构成同步关系。图5.7描绘了本例的逻辑次序，其中的虚线表示释放序列，而实线则表示先行关系。

操作链上可以有任意多的操作，前提是那些操作均为读-改-写操作，例如以memory_order_acquire标记的fetch_sub()，并且每个都有对应的store()与之同步。本例中，所有操作都是获取操作，但它们可以是不同类型的操作，并且以不同内存次序语义标记。

![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/5-7.png)

## 栅栏

如果缺少栅栏（fence）功能，原子操作的程序库就不完整。栅栏具备多种操作，用途是强制施加内存次序，却无须改动任何数据。通常，它们与服从memory_order_relaxed次序的原子操作组合使用。

栅栏操作全部通过全局函数执行。**当线程运行至栅栏处时，它便对线程中其他原子操作的次序产生作用。**栅栏也常常被称作内存卡或内存屏障，其得名原因是它们在代码中划出界线，限定某些操作不得通行。针对不同变量上的宽松操作，编译器或硬件往往可以自主对其进行重新编排。栅栏限制了这种重新编排。在一个多线程程序中，可能原来并非处处具备先行关系和同步关系，栅栏则在欠缺之处引入这两种关系。

代码5.12 栅栏可以让自由操作变的有序

```c++
std::atomic<bool> x,y;
std::atomic<int> z;
void write_x_then_y() {
    x.store(true,std::memory_order_relaxed);    ⇽---  ①
    std::atomic_thread_fence(std::memory_order_release);    ⇽---  ②
    y.store(true,std::memory_order_relaxed);    ⇽---  ③
}
void read_y_then_x() {
    while(!y.load(std::memory_order_relaxed));    ⇽---  ④
    std::atomic_thread_fence(std::memory_order_acquire);    ⇽---  ⑤
    if(x.load(std::memory_order_relaxed))    ⇽---  ⑥
        ++z;
}
int main() {
    x=false;
    y=false;
    z=0;
    std::thread a(write_x_then_y);
    std::thread b(read_y_then_x);
    a.join();
    b.join();
    assert(z.load()!=0);    ⇽---  ⑦
}
```

因变量 y 的载入操作④需读取③处存储的值，在②处加入释放栅栏，在⑤处加入获取栅栏，两个栅栏形成同步。这一改动使得变量 x 的存储操作①在其载入操作⑥之前发生，故读取的值必然是true，⑦处的断言肯定不会触发。

> 未改动版本，可能存储操作已经发生但载入操作并不知道，改动后若进行载入操作，则存储操作肯定已经发生。

程序修改之后的行为与原来不同：加入栅栏之前，变量 x 的存储操作和读取操作是没有确定次序的，故此断言有可能触发。请注意，加入的两个栅栏都有必要：一个线程需要进行释放操作，另一个线程则需进行获取操作，唯有配对才可以构成同步关系。

在上例中，释放栅栏的作用是令变量 y 的存储操作不再服从 memory_order_relaxed 次序，改用次序 memory_order_release。类似地，还加入了获取栅栏，变量 y 的载入操作遂改用次序 memory_order_acquire，**则变量 y 的载入与存储操作形成同步关系，又变量 x 的存储操作先于 y 的存储操作发生，变量 y 的载入操作先于 x 的存储操作发生，故 x 的存储先于 x 的载入发生。**

栅栏的整体运作思路是：若存储操作处于释放栅栏后面，而存储操作的结果为获取操作所见，则该释放栅栏与获取操作同步；若载入操作处于获取栅栏前面，而载入操作见到了释放操作的结果，则该获取栅栏与释放操作同步。在两个线程上都加上栅栏，情形如上例所述，载入操作④处于获取栅栏⑤前面，而存储操作③处于释放栅栏②后面，释放栅栏②即与获取栅栏⑤同步，从而**使载入操作看见存储操作写入的值**。

**尽管栅栏之间的同步取决于其前后的读写操作，但同步点是栅栏本身。**如果修改代码清单5.12中的write_x_then_y()函数代码，将变量 x 的写出移动到栅栏后面，如下所示，断言所判别的条件将不能保证肯定成立，即使变量 x 的写出在 y 的写出之前也依然不能。

```c++
void write_x_then_y() {
    std::atomic_thread_fence(std::memory_order_release);
    x.store(true,std::memory_order_relaxed);
    y.store(true,std::memory_order_relaxed);
}
```

栅栏不再前后分隔这两个写出操作，因此它们之间原来的先后次序不复存在。栅栏只有放置在变量 x 和 y 的存储操作之间，才会强制这两个操作服从先后次序。就其他原子操作之间的先行关系而言，栅栏存在与否并不影响已经加诸其上的次序。

## 原子操作对非原子的操作排序

再次修改代码清单5.12，将原子变量 x 的类型改成非原子化的普通bool类型，如代码清单5.13所示。可以肯定的是，程序的行为与原来的完全相同。

代码5.13 使用非原子操作执行序列

```c++
#include <atomic>
#include <thread>
#include <assert.h>
bool x=false;    ⇽---  ①现在 x 已改为普通的非原子变量
std::atomic<bool> y;    
std::atomic<int> z;
void write_x_then_y()
{
    x=true;    ⇽---  ②变量x的存储操作位于栅栏前面
    std::atomic_thread_fence(std::memory_order_release);
    y.store(true,std::memory_order_relaxed);    ⇽---  ③变量y的存储操作位于栅栏后面
}
void read_y_then_x()
{
    while(!y.load(std::memory_order_relaxed));    ⇽---  ④一直循环等待，直到看见②处写出true值才停止
    std::atomic_thread_fence(std::memory_order_acquire);
    if(x)     ⇽---  ⑤这里读取①处所写出的值
        ++z;
}
int main()
{
    x=false;
    y=false;
    z=0;
    std::thread a(write_x_then_y);
    std::thread b(read_y_then_x);    
    a.join();
    b.join();
    assert(z.load()!=0);    ⇽---  ⑥此断言不会触发
}
```

本例中还是有两个栅栏，分别位于变量x和y的存储操作之间②③，以及y和x的载入操作之间④⑤，依旧令①和②的存储操作服从先后次序，也令④和⑤的读取操作服从先后次序，而变量x的存储操作和读取操作之间还是存在先行关系，断言仍旧不会触发⑥。变量y的存储操作③和载入操作④仍必须采用原子操作，否则其上就会出现数据竞争；然而，只要读线程见到变量y上所存储的true值，两个栅栏即通过联合作用，向变量x的读写操作强制施行次序，尽管变量x上的读写操作分别由不同线程执行，但是该强制次序排除了x上的数据竞争。

## 非原子操作排序

先行关系中蕴含着控制流程的先后执行顺序。利用这一重要性质，即可借原子操作强制非原子操作服从内存次序。如果按照控制流程，非原子操作甲在原子操作乙之前执行，而另一线程上执行了原子操作丙，并且操作乙在操作丙之前发生，那么操作甲同样在操作丙之前发生。在代码清单5.13中，对变量x执行非原子操作和原子操作，它们正是因为上面这一点才服从先后一致次序，这也是代码清单5.2正确运行的内在原因。C++标准库的高层级工具，如互斥和条件变量，同样以它作为逻辑基础。

为了理解该性质如何产生作用，我们来回想代码清单5.1的自旋锁互斥。

lock()的实现方式是在循环中反复调用flag.text_and_set()，其中所采用的次序为std::memory_order_acquire；unlock()实质上则是服从std::memory_order_release次序的flag.clear()操作。第一个线程调用lock()时，标志flag正处于置零状态，test_and_set()的第一次调用会设置标志成立并返回false，表示负责执行的线程已获取了锁，遂循环结束，互斥随即生效。该线程可修改受其保护的数据而不受干扰。此时标志已设置成立，如果任何其他线程再调用lock()，都会在test_and_set()所在的循环中阻塞。

当持锁线程完成了受保护数据的改动，就调用unlock()，再进一步按std::memory_order_release次序语义执行flag.clear()。若第二个线程因调用lock()而反复执行flag. test_and_set()，又因该操作采用了std::memory_order_acquire次序语义，故标志flag上的这两项操作形成同步。根据互斥的使用规则，首先，受保护数据的改动须按流程顺序在调用unlock()前完成；其次，只有在解锁以后才能重新加锁；最后，第二个线程需要先获取锁，接着才可以访问目标数据。所以，改动先于unlock()发生，自然也先于第二个线程的lock()调用，进而更加先于第二个线程的数据访问。

尽管其他互斥实现的内部操作各有不同，但其基本原理都一样：lock()与unlock()都是某内部内存区域之上的操作，前者是获取操作，后者则是释放操作。它们根据同步关系，按各种形式为相关内存次序提供了保证。正因如此，得以运用这些机制来同步数据，确立相关内存次序。这些工具所给出的同步关系如下。

**std::thread**

* std::thread构造新线程时，构造函数与调用函数或新线程的可调用对象间的同步。
* 对std::thread对象调用join，可以和对应的线程进行同步。

**std::mutex, std::timed_mutex, std::recursive_mutex, std::recursibe_timed_mutex**

* 对给定互斥量对象调用lock和unlock，以及对try_lock，try_lock_for或try_lock_until，会形成该互斥量的锁序。
* 对给定的互斥量调用unlock，需要在调用lock或成功调用try_lock，try_lock_for或try_lock_until之后，这样才符合互斥量的锁序。
* 对try_lock，try_lock_for或try_lock_until失败的调用，不具有任何同步关系。

**std::shared_mutex ,  std::shared_timed_mutex**

* 对给定互斥量对象调用lock、unlock、lock_shared和unlock_shared，以及对 try_lock ,  try_lock_for ,  try_lock_until ,  try_lock_shared ,  try_lock_shared_for或 try_lock_shared_until的成功调用，会形成该互斥量的锁序。
* 对给定的互斥量调用unlock，需要在调用lock或shared_lock，亦或是成功调用try_lock ,  try_lock_for,  try_lock_until,  try_lock_shared,  try_lock_shared_for或try_lock_shared_until之后，才符合互斥量的锁序。
* 对try_lock，try_lock_for，try_lock_until，try_lock_shared，try_lock_shared_for或try_lock_shared_until 失败的调用，不具有任何同步关系。

**std::shared_mutex和std::shared_timed_mutex**

* 成功的调用std::promise对象的set_value或set_exception与成功的调用wait或get之间同步，或是调用wait_for或wait_until的返回例如future状态std::future_status::ready与promise共享同步状态。
* 给定std::promise对象的析构函数，该对象存储了一个std::future_error异常，成功的调用wait或get后，共享同步状态与promise之间的同步，或是调用wait_for或wait_until返回的future状态std::future_status::ready时，与promise共享同步状态。

**std::packaged_task ,  std::future和std::shared_future**

* 成功的调用std::packaged_task对象的函数操作符与成功的调用wait或get之间同步，或是调用wait_for或wait_until的返回future状态std::future_status::ready与打包任务共享同步状态。
* std::packaged_task对象的析构函数，该对象存储了一个std::future_error异常，其共享同步状态与打包任务之间的同步在于成功的调用wait或get，或是调用wait_for或wait_until返回的future状态std::future_status::ready与打包任务共享同步状态。

**std::async ,  std::future和std::shared_future**

* 使用std::launch::async策略性的通过std::async启动线程执行任务与成功的调用wait和get之间是同步的，或调用wait_for或wait_until返回的future状态std::future_status::ready与产生的任务共享同步状态。
* 使用std::launch::deferred策略性的通过std::async启动任务与成功的调用wait和get之间是同步的，或调用wait_for或wait_until返回的future状态std::future_status::ready与promise共享同步状态。

**std::experimental::future ,  std::experimental::shared_future和持续性**

* 异步共享状态变为就绪的事件与该共享状态上调度延续函数的调用同步。
* 持续性函数的完成与成功调用wait或get的返回同步，或调用wait_for或wait_until返回的期望值状态std::future_status::ready与调用then构建的持续性返回的future同步，或是与在调度用使用这个future的操作同步。

**std::experimental::latch**

* 对std::experimental::latch实例调用count_down或count_down_and_wait与在该对象上成功的调用wait或count_down_and_wait之间是同步的。

**std::experimental::barrier**

* 对std::experimental::barrier实例调用arrive_and_wait或arrive_and_drop与在该对象上随后成功完成的arrive_and_wait之间是同步的。

**std::experimental::flex_barrier**

* 对std::experimental::flex_barrier实例调用arrive_and_wait或arrive_and_drop与在该对象上随后成功完成的arrive_and_wait之间是同步的。
* 对std::experimental::flex_barrier实例调用arrive_and_wait或arrive_and_drop与在该对象上随后完成的给定函数之间是同步的。
* 对std::experimental::flex_barrier实例的给定函数的返回与每次对arrive_and_wait的调用同步，当调用给定函数线程会在栅栏处阻塞等待。

**std::condition_variable和std::condition_variable_any**

* 条件变量不提供任何同步关系，它们是对忙等待的优化，所有同步都由互斥量提供。

