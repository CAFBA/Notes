### 03不要以多态方式处理数组
若向函数中传递给基类数组形参一个派生类数组参数，编译器依然假设形参数组中每一元素的大小为基类的大小，这会引发未定义行为
C＋＋语言规范：过 base class 指针删除一个由derived classes objects构成的数组，其结果未定义
### 04非必要不提供default constructor
 由于 EquipmentPiece 缺乏 default constructor，其运行可能在3种情况下出现问题：
在产生数组的时候一般而言没有任何方法可以为数组中的对象指定 constructor 自变量，所以几乎不可能产生一个由 EquipmentPiece objects 构成的数组
Classes 如果缺乏 default constructors，带来的第二个缺点是：它们将不适用于许多 template-based container classes。对那些 templates 而言，被实例化（instantiated） 的目标类型必须得有一个 default constructors。这是一个普遍的共同需求，因为在那些 templates 内几乎总是会产生一个以template 类型参数作为类型而架构起来的数组。
virtual base class constructors 的自变量必须由欲产生的对象的派生层次最深（所谓 most derived）的class 提供。于是，一个缺乏 default constructor 的 virtual base class，要求其所有的 derived classes，不论距离多么遥远都必须知道、了解其意义，并且提供 virtual base class 的 constructors 自变量。
### 06区别 increment／decrement
```c++
//前置式：累加然后取出（increment and fetch）
UPInt& UPInt::operator++() {
	*this += 1;//累加（increment）
	return *this://取出（fetch）
}

//后置式：取出然后累加（fetch and increment）
const UPInt UPInt::operator++(int) {
	UPInt oldValue = *this;//取出（fetch）
	++(*this);//累加（increment）
	return oldValue;//返回先前被取出的值
}
```
### 08各种不同意义的new和delete
当你写出这样的代码：
```
string *ps = new string("Memory Management"); 
```
你所使用的 new 是所谓的 new operator。这个操作符是由语言内建的，就像sizeof 那样，不能被改变意义，总是做相同的事情。它的动作分为两方面。第一，它分配足够的内存，用来放置某类型的对象。以上例而言，它分配足够放置一个string 对象的内存。第二，它调用一个constructor，为刚才分配的内存中的那个对象设定初值。new operator总是做这两件事，无论如何你不能够改变其行为。

你能够改变的是用来容纳对象的那块内存的分配行为。new operator 调用某个函数，执行必要的内存分配动作，你可以重写或重载那个函数，改变其行为。这个函数的名称叫做 operator new。

函数 operator new 通常声明如下：  

```
void * operator new(size_t size); 
```

其返回值类型是 void＊。此函数返回一个指针，指向一块原始的、未设初值的内存（如果你喜欢，可以写一个新版的 operator new，在其返回内存指针之前先将那块内存设定初值。只不过这种行为颇为罕见就是了）。函数中的 size_t 参数表示需要分配多少内存。你可以将 operator new 重载，加上额外的参数，但第一参数的类型必须总是 size_t（如何撰写 operator new，相关信息请参考条款E8~E10)

或许你从未想到要直接调用 operator new，但如果你要，你可以像调用任何其他函数一样地调用它：

```
 void *rawMemory = operator new(sizeof(string)); 
```

这里的operator new将返回指针，指向一块足够容纳一个string对象的内存。

和malloc一样，operator new的唯一任务  就是分配内存。它不知道什么是constructors， operator new 只负责内存分配。取得 operator new 返回的内存并将之转换为一个对象，是new operator的责任。

当你的编译器看到这样一个句子： string *ps = new string("Memory Management"); 它必须产生一些代码，或多或少会反映以下行为（：

```c++
void *memory = operator new(sizeof(string));
//取得原始内存（raw memory）用来放置一个 string 对象。

call string::string（＂Memory Management＂）on *memory; //将内存中的对象初始化。 

string *ps = static_cast<string*>(memory);//让ps指向新完成的对象。
```

注意上述第二步骤涉及调用一个 constructor，身为程序员的你没有权力这么做。然而你的编译器百无禁忌，可以为所欲为。这就是为什么如果你想要做出一个heap-based object，一定得使用 new operator的原因：你无法直接调用对象初始化所必需的constructor（尤其它可能得为重要成分 vtbl 设定初值，见条款24）。



有时候你真的会想直接调用一个 constructor。针对一个已存在的对象调用其constructor 并无意义，因为 constructors 用来将对象初始化，而对象只能被初始化一次。但是偶尔你会有一些分配好的原始内存，你需要在上面构建对象。有一个特殊版本的 operator new，称为 placement new，允许你那么做。

下面示范如何使用 placement new：

```c++
class Widget{
	public:
		Widget(int widgetsize); 
};

Widget * constructWidgetInBuffer(void *buffer, int widgetSize) {
	return new (buffer) Widget(widgetsize); 
}
```

此函数返回指针，指向一个 Widget object，它被构造于传递给此函数的一块内存缓冲区上。当程序运行到  shared memory 或  memory-mapped I／O ，这类函数可能是有用的，因为在那样的运用中，对象必须置于特定地址，或是置于以特殊函数分配出来的内存上（条款4列有 placement new 的另一个运用实例）。

在 constructWidgetInBuffer 函数内部，唯一一个表达式是：  new (buffer) Widget(widgetSize) 

这只是 new operator 的用法之一，其中指定一个额外自变量（buffer）作为 new operator 隐式调用 operator new时所用。于是，被调用的 operator new 除了接受一定得有的 size_t 自变量之外，还接受了一个 void＊参数，指向一块内存，准备用来接受构造好的对象。这样的operator new 就是所谓的 placement new，看起来像这样：

```
void * operator new(size_t, void *location) {
	return location; 
}
```

operator new 的目的是要为对象找到一块内存，然后返回一个指针指向它。在placement new 的情况下，调用者已经知道指向内存的指针了，因为调用者知道对象应该放在哪里。因此 placement new 唯一需要做的就是将它获得的指针再返回。至于没有用到（但一定得有）的size_t 参数，之所以不赋予名称，为的是避免编译器发出某物未被使用的警告（见条款6）。

如果你希望**将对象产生于 heap，请使用 new operator，它不但分配内存而且为该对象调用一个constructor。**

如果你只是**打算分配内存，请调用 operator new，那就没有任何 constructor 会被调用**。

如果你**打算在 heap objects 产生时自己决定内存分配方式，请写一个自己的 operator new，并使用 new operator，它将会自动调用你所写的 operator new**。

如果你**打算在已分配（并拥有指针）的内存中构造对象，请使用placement new**



为了避免 resource leaks（资源泄漏），每一个动态分配行为都必须匹配一个相应但相反的释放动作。函数 operator delete 对于内建的 delete operator，就好像 operatornew 对于 new operator 一样。当你写出这样的代码：

```c++
string *ps;
delete ps://使用 delete operator。
```

你的编译器必须产生怎样的代码？它必须既能够析构 ps所指对象，又能够释放被该对象占用的内存。

内存释放动作是由函数 operator delete 执行，通常声明如下：

```
 void operator delete(void *memoryToBeDeallocated);  
```

因此，下面这个动作：

```c++
delete ps;
```

会造成编译器产生近似这样的代码：

```c++
ps->~string();//调用对象的 dtor operator。 
operator delete(ps);//释放对象所占用的内存。
```

这里呈现的一个暗示就是，如果你只打算处理原始的、未设初值的内存，应该完全回避 new operator 和 delete operators，改调用 operator new 取得内存并以 operator delete 归还给系统：

```c++
void *buffer = operator new（50＊sizeof（char))；
//分配足够的内存，放置50个chars，没有调用任何 ctors ...

operator delete(buffer);//释放内存，没有调用任何 dtors。

//operator new（50＊sizeof（char））；
```

如果你**使用 placement new，在某内存块中产生对象，你应该避免对那块内存使用 delete operator**。因为 delete operator 会调用 operator delete 来释放内存， 但是该内存内含的对象最初并非是由 operator new 分配得来的。placement new 只是返回它所接收的指针而已，编译器不知道那个指针从哪里来，所以为了抵消该对象的 constructor的影响，你应该直接调用该对象的 destructor：

```c++
//以下函数用来分配及释放 shared memory 中的内存。
void* mallocShared(size_t size);
void freeShared(void *memory);

void *sharedMemory = mallocShared(sizeof(Widget)); 
Widget *pw = constructWidgetInBuffer(sharedMemory, 10);
//和先前相同，运用placement new。 

delete pw;//无定义！因为 sharedMemory 来自mallocShared，不是来自 operator new。 

pw->~Widget();//可！析构 pw 所指的 widget 对象，但并未释放 widget 占用的内存。
freeShared(pw);//可！释放 pw 所指的内存，不调用任何 destructor。
```

如此例所示，如果交给 placement new 的原始内存（raw memory）本身是动态分配而得（通过某种非传统做法），那么你最终还是得释放那块内存，以免遭受内存泄漏（memory leak）之苦

目前为止一切都好，但我们还有更远的路要走。截至目前我们考虑的每件事情都只在单一对象身上打转。面对数组怎么办？下面会发生什么事情：

```c++
string *ps = new string[10];//分配一个对象数组
```

上述使用的 new 仍然是那个 new operator，但由于诞生的是数组，所以 new operator 的行为与先前产生单一对象的情况略有不同。是的，内存不再以 operatornew 分配，而是由其数组版兄弟，一个名为 operator new［］的函数负责分配（通常被称为array new）。和 operator new 一样，operator new［］ 也可以被重载。这使你得夺取数组的内存分配权，就像你可以控制单一对象的内存分配一样（不过条款E8对此有些警告）。

数组版与单一对象版的new operator的不同是，它所调用的constructor数量。数组版 new operator 必须针对数组中的每个对象调用一个 constructor： 

```c++
string *ps = new string[10];
//调用 operator new［］以分配足够容纳 10个 string 对象的内存，然后针对每个元素调用 string default ctor。

//当 delete operator 被用于数组，它会针对数组中的每个元素调用其destructor，然后再调用 operator delete［］释放内存： 

delete [] ps;//为数组中的每个元素调用 string dtor，然后调用 operator delete［］以释放内存。
```

### 19了解临时对象的来源

程序员交谈的时候，往往把一个短暂需要的变量称为临时变量。例如下面这个 swap 函数：

```c++
template<class T>
void swap(T& object1, T& object2) {
	T temp = object1; 
	object1 = object2; 
	object2 = temp; 
}
```

常有人将 temp 称为一个临时对象。但是在C＋＋眼中，temp 并不是临时对象，它只是函数中的一个局部对象。

**C＋＋真正的所谓的临时对象是不可见的，不会在你的源代码中出现。只要你产生一个 non-heap object 而没有为它命名，便诞生了一个临时对象。**此等匿名对象通常发生于两种情况：一是当**隐式类型转换被施行起来以求函数调用能够成功**；二是**当函数返回对象的时候**。

了解这些临时对象如何（以及为什么）被产生和被销毁，是很重要的，因为其所伴随的构造成本和析构成本可能对你的程序性能带来值得注意的影响。

**隐式类型转换**

首先考虑为了让函数调用成功而产生的临时对象。此乃发生于传递某对象给一个函数，而其类型与它即将绑定上去的参数类型不同的时候。例如，考虑一个函数，用来计算字符串中的某字符出现次数：

```c++
//返回 ch 在 str 中的出现个数。
size_t countChar(const string& str, char ch); 
char buffer [MAX_STRING_LEN];
char c;//读入一个char 和一个 string，利用 setw 避免在读入 string 时产生缓冲区满溢的情况。
cin >> c >> setw(MAX_STRING_LEN) >> buffer; 
cout << "There are " << countChar(buffer, c) 
     << "occurrences of the character" << c << " in " << buffer << endl;
```

请看 countChar 的调用动作。其第一自变量是个 char 数组，但是相应的函数参数类型却是 const string＆。当类型不吻合的状态消除，此函数调用才会成功；你的编译器很乐意消除此状态，做法是产生一个类型为 string 的临时对象。该对象的初始化方式是：以 buffer 作为自变量，调用 string constructor。于是 countChar 的 str 参数会被绑定于此 string 临时对象上。当   countChar 返回， 此临时对象会被自动销毁。

这样的转换很方便（虽然也很危险—见ME5），但是从效率角度观之，一个 string 临时对象的构造和析构，有其非必要的成本。有两个做法可以消除此种转换，一是重新设计你的代码，使这类转换不会发生，此策略验证于ME5；另一做法就是修改你的软件，使这类转换不再需要，ME21描述了这种做法。

**只有当对象以 by value方式传递，或是当对象被传递给一个 reference-to-const 参数时，这些转换才会发生。如果对象被传递给一个 reference-to-non-const 参数，并不会发生此类转换。**考虑这个函数：

```c++
void uppercasify(string& str);//将str中的所有chars改为大写。
char subtleBookPlug[] = "Effective C++";
uppercasify(subtleBookPlug);
```

在上一个（计算字符个数）例子中，我们可以成功地将一个字符数组传递给 countChar，但是在这里，将一个字符数组交给   uppercasify 会导致调用失败

不再有任何临时对象被产生出来以成全此函数的调用。为什么？

假设编译器为此产生一个临时对象，然后此临时对象被传递给 uppercasify ，以便将其中的字符全部修改为大写。此函数的实元— subtleBookPlug  并未受到影响，只有  subtleBookPlug 为本所产生的那个 string 临时对象受到影响。这当然不是程序员所企盼的结果。程序员将 subtleBookPlug 传给 uppercasify  ， 就是希望 subtleBookPlug 被修改。

**当程序员期望非临时对象被修改，此时如果编译器针对 references-to-non-const 对象进行隐式类型转换，被修改的将是临时对象而不是非临时对象。这就是为什么C＋＋语言禁止为 non-const reference 参数产生临时对象的原因。Reference-to-const   参数则不需要承担此问题，因为此等参数由于 const 之故，无法被改变。**

**当函数返回一个对象**

第二种会产生临时对象的情况是当函数返回一个对象时。

例如，operator＋必须返回一个对象，表现其操作数的总和（见条款E23）。假设有一个 Number 类型，其 operator＋ 声明如下：

```c++
const Number operator+(const Number& lhs,const Number& rhs);
```

此函数的返回值是个临时对象，因为它没有名称：它就是函数的返回值，如此而已。每当你调用 operator，便得为此对象付出构造和析构成本（条款E21有解释为什么这个返回值是 const ）。

一般而言你并不会想要承担这份成本。对于此特殊函数，你可以改用一个类似的函数 operator+= 免掉这份成本。条款22会详述这种做法。但是对其他返回对象的函数而言，大多数难以被另一个函数替代，所以没办法避免返回值的构造和析构。至少，观念上没办法。

但是在观念和实务之间，有一个名为优化的黝黯地带，有时候你可以以某种方式撰写你那返回值为一个对象的函数，使编译器得以将临时对象优化，使它不复存在。在这些优化策略中，最常见也最有用的就是所谓的返回值优化，那正是ME20的主题。

结论是：临时对象可能很耗成本，所以你应该尽可能消除它们。然而更重要的是，如何训练出锐利的眼力，看出可能产生临时对象的地方。**任何时候只要你看到一个 reference-to-const 参数，就极可能会有一个临时对象被产生出来绑定至该参数上。任何时候只要你看到函数返回一个对象，就会产生临时对象（并于稍后销毁）**。

### 21利用重载技术避免隐式类型转换

以下代码，除了看起来极为合理之外，没什么特别：

```c++
class UPInt{//这个 class 用于无限精密的整数。
	public:
		UPInt(); 
		UPInt(int value); 
};
const UPInt operator+(const UPInt& lhs, const UPInt& rhs); 
UPInt upi, upi2;
UPInt upi3 = upil + upi2;
```

没有什么值得惊讶的地方。 upi1  和 upi2  都是  UPInt  对象，所以只需调用UPInt 的  operator＋ 便可将它们加在一起。

现在考虑以下语句： 

```c++
upi3 = upil + 10; 
upi3 = 10 + upi2;
```

这些句子也能成功，因为产生了临时对象，并将整数10转换为  UPInts （见条款19）。

由编译器来执行这类转换，很是方便，但是此类转换所产生的临时对象带来一些我们并不想要的成本。大部分C＋＋程序员希望获得隐式类型转换，却不希望承受临时对象所带来的任何成本。

我们可以退回一步，承认我们的目标并非真正在于类型转换，而是希望能够以一个  UPInt  自变量和一个  int  自变量调用  operator+ 。只不过碰巧隐式类型转换是一种手段罢了，千万不要把手段和目的混淆了。如果有其他做法可以让 operator+ 在自变量类型混杂的情况下被调用成功，那便消除了类型转换的需求。如果我们希望能够对  UPInt  和 int  进行加法，我们需要做的就是将我们的意图告诉编译器，做法是声明数个函数，每个函数有不同的参数表：

```c++
const UPInt operator+（const UPInt＆ lhs，const UPInt& rhs);//将 UPInt和UPInt相加。
const UPInt operator+（const UPInt＆ lhs，int rhs);
const UPInt operator+ (int lhs, const UPInt& rhs);
UPInt upil, upi2; 
UPInt upi3 ＝ upil ＋ upi2； //很好，不会针对upi1或upi2产生临时对象。 
upi3 = upi1 + 10;//很好，不会针对upi1或10产生临时对象。
upi3 = 10 + upi2;//很好，不会针对10或upi2产生临时对象。
//一旦开始以重载技术消除类型转换，你可能会热情地进一步写出以下函数声明：
const UPInt operator＋（int lhs，int rhs）；//错误！
```

这样的想法原是颇为合理的。毕竟面对类型 UPInt 和 int ，我们希望将 operator＋ 的所有可能组合都予以重载。上述3种组合之外，唯一遗漏的就是获得两个  int  自变量的 operator＋ ，所以我们要加上它。

不论是否合理，C＋＋存在许多游戏规则，其中一个就是：**每个重载操作符必须获得至少一个用户定制类型的自变量**。int 不是用户定制类型，所以我们不能够将一个只获得 int 自变量的操作符加以重载。（如果这个规则不存在，程序员就可以改变预先定义的操作符意义，而那当然会导致天下大乱。例如，上述的 operator＋ 多载版本，会改变 ints 的加法意义。难道这真是我们所希望的吗？）

### 22考虑以op=取代op

```c++
//大部分程序员都希望，如果他们能够这样写：
x = x + y;
x = x - y; 
//他们也能够写成这样：
x += y;
x -= y;
```

如果x和y属于定制类型，就不保证一定能够如此。到目前为止C＋并不考虑在  operator＋， operator＝ 和  operator+= 之间设立任何互动关系。所以如果你希望这3个操作符都存在并且有着你所期望的互动关系，你必须自己实现。

要确保操作符的复合形式和其独身形式之间的自然关系能够存在，一个好方法就是以前者为基础实现后者（见条款6）。这很容易做到：

```c++
class Rational { 
	public: 
		Rational& operator+=(const Rational& rhs); 
		Rational& operator-=(const Rational& rhs); 
};
//以 operator+= 实现 operator＋，条款E21 曾解释为什么此处的返回值是 const。
const Rational operator+(const Rational& lhs, const Rational& rhs) {
	return Rational(lhs) += rhs; 
}
//以 operator-＝ 实现 operator-。
const Rational operator-(const Rational& lhs, const Rational& rhs) {
	return Rational(lhs) -= rhs; 
}
```

此例中的  operator+= 和  operator-= 都是从头做起的，而  operator＋ 和  operator- 则是调用前者以供应它们所需的机能。如果采用这种设计，那么这些操作符之中就只有复合形式才需要维护，此外，如果这些操作符的复合形式是在 class 的 public 接口内，那么就不需要让独身形式成为该  class  的  friends （见条款E19）。

如果不介意把所有独身形式操作符放在全局范围内，你可以利用 templates，完全消除独身形式操作符的撰写必要：

```c++
template<class T>
const T operator+(const T& lhs, const T& rhs) {
	return T(lhs) += rhs;
}
template<class T>
const T operator-(const T& 1hs, const T& rhs) {
	return T(lhs) -= rhs;
}
```

有了这些  templates  之后，只要程序中针对类型定义有一个复合操作符，对应的独身版本就会在需要的时候被自动产生出来。

这些都很好，但是到现在为止我们还没有考虑效率问题，而效率毕竟是本章的主题。3个与效率有关的情况值得注意。

第一，一般而言，复合操作符比其对应的独身版本效率高，因为独身版本通常必须返回一个新对象，而我们必须因此负担一个临时对象的构造和析构成本（见条款19和20及条款E23）。至于复合版本则是直接将结果写入其左端自变量，所以不需要产生一个临时对象来放置返回值。

第二，如果同时提供某个操作符的复合形式和独身形式，便允许你的客户在效率与便利性之间做取舍（虽然那是极其困难的抉择）。也就是说，你的客户可以决定是否写这样的代码：

```c++
Rational a, b, c, d,result; ...
result = a + b + c + d;

result = a;
result += b;
result += c;
result += d;
```

前者较易撰写、调试、维护，并在80％的时间内供应足可接受的性能（见条款16）。后者效率较高，而且（或许）对汇编语言程序员比较直观。如果同时供应两种选择，你便允许客户以较易理解的操作符独身版本来发展程序并调试，而同时仍保留将独身版本用更有效率的复合版本取代的权力。此外，借由以复合版本作为独身版本的实现基础，你可以确保，当客户从某种选择改变为另一种选择时，操作语法仍可保持不变。

我们把最后一个效率观察放在独身形式操作符身上。再次看看  operator＋ 实现码：

```c++
template<class T>
const T operator+(const T& lhs, const T& rhs) {
	return T(lhs) += rhs;
}
```

表达式 T（lhs） 是个调用动作，调用 T 的 copy constructor 。它会产生一个临时对象，其值和 lhs 相同。这个临时对象然后被用来调用  operator＋＝ ，并以 rhs 作为自变量，运算结果则被 operator＋ 返回。这段码似乎过于晦涩，这样写难道不更好吗：

```c++
template<class T>
const T operator+(const T& lhs, const T& rhs) {
	T result(1hs);//将1hs 复制给 result。 
	return result += rhs;//将rhs 加到 result 上然后返回。 
}
```

这个 template 几乎等同于上一个，但其间有个重要差异。第二个  template  内含了一个命名对象  result 。这个事实意味着，返回值优化（return value optimization， 见条款20）无法施展于此 operator＋实现代码身上（除非根据最新发展，见p104尾注）。至于第一个 template 则总是适用返回值优化，所以它虽然诡异，却比较有机会让你的编译器为它实现最佳服务。

现在，我必须指出，以下表达式： return T(lhs) += rhs; 

比大部分编译器所能接受的返回值优化形式更为复杂。前述第一个  template 可能需要在函数内消耗一个临时对象，就像使用命名对象  result  的成本一样。然而，自古以来匿名对象总是比命名对象更容易被消除，所以当你面临命名对象或临时对象的抉择时，最好选择临时对象。它应该绝不会比其命名兄弟耗用更多成本，反倒是极有可能降低成本（尤其在搭配旧式编译器时）。

> 至少那是假设会发生的事情。某些编译器会把T（lhs）视为一个转型动作，于是移除lhs的常量性（constness），然后把 rhs 加到 lhs 并返回一个 reference 指向修改后的lhs！请在信赖本文所述之行为前，先检测你的编译器行为。



命名对象、匿名对象、编译器优化等相关讨论都相当有趣，但是我们不要忘了本条款的主题：操作符的复合版本（例如，operator＋＝）比其对应的独身版本（例如，operator＋）有着更高效率的倾向。身为一位程序库设计者，你应该两者都提供；身为一位应用软件开发者，如果性能是重要因素的话，你应该考虑以复合版本操作符取代其独身版本。

