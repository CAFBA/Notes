### 04确定对象被使用前已被初始化

C++规定：对象成员变量的初始化动作发生在进入构造函数本体之前，应该使用成员初值列初始化，因为赋值版本首先调用default构造函数设初值，然后立刻对其赋予新值。而成员初值列中针对每个成员设置的实参，被用作各成员变量之于构造函数的实参

尽管对于内置类型，初始化和赋值的成本相同，但也应该使用成员初值列；若成员变量是const或references，就一定需要初值，而不是赋值

基类总是更早于其派生类被初始化，class的成员变量总是以其声明次序被初始化



所谓static对象，其寿命从被构造出来直到程序结束为止，因此stack 和 heap-based 对象都被排除。这种对象包括 global对象、定义于namespace 作用域内的对象、在classes内、在函数内、以及在file作用域内被声明为 static 的对象。

**函数内的static对象称为local static对象(因为它们对函数而言是local)，其他static对象称为non-local static 对象。**

**程序结束时static对象会被自动销毁，也就是它们的析构函数会在main()结束时被自动调用。**

所谓编译单元(translation unit)是指产出单一目标文件(singleobject file)的那些源码。基本上它是单一源码文件加上其所含入的头文件(#include files)

```c++
class FileSystem{
	public:
	std::size_t numDisks() const;
};

extern FileSystem tfs;

class Directory{
	Directory() {; 
};

Directory::Directory() {
	std::size_t disks = tfs.numDisks();
}

Directory tempDir;
```

除非tfs在tempDir之前先被初始化，否则tempDir会用到尚未初始化的tfs，但由于二者是定于于不同编译单元的non-local static ，所以无从确定是否tfs先被初始化

为解决这个问题，**将每个non-local static对象搬到自己的专属函数内（该对象在函数内声明为static），这些函数返回一个引用指向它所含的对象，然后调用这些函数但不直接指涉这些对象，也就是说它们使用函数返回的指向static对象的引用，而不再使用static对象本身**

**C++保证：函数内的local static对象会在该函数被调用期间，首次遇到该对象定义式时被初始化，这就保证了引用指向了一个历经初始化的对象**

```c++
class FileSystem{...};
FileSystem& tfs() { 
    static FileSystem fs;
    return fs;
}

class Directory {...};
Directory::Directory(params)
{
	std::size_t disks = tfs().numDisks();
}

Directory& tempDir()
{
	static Directory td;
	return td;
}
```

### 06拒绝编译器自动生成的函数

若不希望class支持某一机能，只需要不声明对应函数即可，但对于构造函数等会默认生成的函数，这是不管用的，因此需要采取以下两种做法，驳回编译器自动提供的机能

**将成员函数声明为private且故意不实现它们**，藉由明确声明成员函数，阻止编译器创建；令这些函数为private，使得阻止其被调用



由于必须由公共成员函数调用私有成员函数，那么copy assignment和copy ctor这样声明后，只能由member函数和friend函数能够使用它们，诸如T h1(h2) 或者 h1 = h2 的语句将被阻止

```c++
class uncopy{
	protected://允许派生类对象构造和析构
		uncopy(){}
		~uncopy(){}
	private://但阻止派生类copy assignment和copy
		uncopy(const copy& );
		uncopy operator=(const uncopy& );		
};
class T: public uncopy{
    ...//class不再声明copy assignment和copy
};
```

这样做之后，每当尝试copy时，编译器会尝试生成copy assignment和copy ctor并调用base class的copy assignment和copy ctor，但这个调用会被拒绝，因为base class的copy assignment和copy ctor是private

### 07为多态基类声明virtual析构函数

**当derived class对象经由一个base指针被删除，而该base class没有virtual虚构函数，那么将调用base class的析构函数，这会释放derived对象的base部分指向的内存，但不会释放derived成分**

因此，需要给base class一个virtual析构函数，这样，程序将使用为对象类型（此处指的是derived class）定义的方法，即**先调用derived的析构函数，然后再调用base的析构函数**

综上，带有多态性质的base class应该声明一个virtual析构函数。若class类带有任何virtual函数，就应该拥有一个virtual析构函数，设计目的是通过base class接口处理derived class对象，即 作为base class使用 和 具备多态性，virtual析构函数的缺点详见E7

> 因为所有STl容器不带有virtual析构函数，因此不要将其作为base class
>
> 如果使用指向对象的引用或指针来调用虚方法，程序将使用为  **对象类型定义**  的方法，而不使用为 **引用或指针类型定义** 的方法

pure virtual函数使得这个class成为abstract class，即不能被实体化的class，不能为这种类创建对象，但必须为pure virtual函数提供定义，因为编译器会在base class的derived class的析构函数中创建一个对base class析构函数的调用动作

**若abstract class被当作base class来用，应该为其声明一个pure virtual析构函数**

```c++
class A{
	virtual ~A() = 0;//pure virtual函数
};
A::~A(){ }
```

> 析构函数的运作方式：最深层派生的class其析构函数最先被调用，然后是其每一个base class的析构函数被调用

### 08别让异常离开析构函数

析构函数在程序运行结束销毁对象时被调用，如果析构第一个元素时，有异常被抛出，接着析构第二个元素时异常又被抛出，在两个以上异常同时存在的情况下，程序若不是结束执行就是导致不明确的行为，因此，析构函数绝对不要吐出异常

但若析构函数必须执行某个动作，比如调用函数，而这个动作可能抛出异常，则析构函数应该捕获任何异常，然后吞下（不传播）它们或结束程序

### 09不在析构和构造过程中调用virtual函数

```c++
class A {
	public:
		A();
		virtual void log() const = 0;
};
A::A(){... log()};

class B: public A{
	virtual void log() const = 0;
};

B b;
```

当创建派生类对象时，derived的base成分会在derived自身成分被构造之前先构造妥当，因此一定是base class类的构造函数先被调用

而base class的构造函数中调用了log，这时候被调用的log是A内的版本，而不是B内的，**base class构造函数期间virtual函数绝不会下降到derived阶层**，在构造函数期间，virtual函数不是virtual函数

以上有以下两个理由

**由于base class类的构造函数先被调用，当base class执行时derived class成员变量尚未初始化，若这时候virtual函数下降到derived阶层，但此时derived阶层的变量还未初始化，这时候就可能有使用未初始化成分的风险**

在derived的base构造期间，对象的类型是base class而不是derived class。不只virtual函数会被编译器解析至base class，若使用运行期间类型信息dynamic_cast，也会将对象视为base class

那么可以这样理解：**对象内的derived成分尚未初始化，那么将其视作不存在，即 对象在derived class构造函数开始执行前不会成为一个derived class对象**

同样的，**一旦derived class析构函数开始执行，对象内的derived class成员变量就呈现未初始化，则c++将其视作不存在，进入base class析构函数后对象就成为了base class对象**

确保每次一有继承体系被创建，就会有相应版本的函数被调用，这就需要将这个函数改为non-virtual，然后让derived class构造函数传递信息给base class的构造函数

这之后，那个构造函数便可安全地调用non-virtual

```c++
class A{
	public:
		A();
		void log() const;
};
A::A(){... log()};

class B: public A{
	public:
		B(p): A(crate(p));
	private:
		static std::string crate(p);
};
```

无法使用virtual函数从base class向下调用，那么就不用virtual，改由让derived class将必要的构造信息向上传递给base class构造函数来完成其初始化

而又因为static函数地存在，就不可能意外指向derived class对象内未初始化的成员变量

利用辅助函数创建一个值传递给base构造函数要优于使用成员初值列直接赋值

### 10-11operator=

为类实现赋值运算符时应遵守协议：令operator=返回一个reference指向操作符左侧的实参

```c++
widget& operator=(const widget& rhs) {
	...
	return* this;
};
```

```c++
//潜在的自我继承
a[i] = a[j]; //i j 具有相同的值
*px = *py //px py 指向同一个对象
class A{...};
class B: public A{...};
void do(const A& rb, B* pd);
//rb与pd可能是同一个对象，因为一个基类的引用或指针可以指向派生类对象
```

> 别名：有一个以上的方法指称某对象
>
> 若某段代码操作指针或引用而它们被用来指向多个相同类型的对象，就需要考虑这些对象是否为同一个

```c++
class bitmap{...};
class widget{
	bitmap* pb;
};

widget& operator=(const widget& rhs) {
    if(this == rhs) return* this;//证同测试，赋予自我赋值安全
	delete pb; 
	//销毁当前对象（赋值运算符左边）的bitmap，若*this和rhs是同一个对象，则也删除了rhs.pb
	pb = new bitmap(*rhs.pb); //若*this和rhs是同一个对象，则指向的将是一个已经被删除的对象
	return* this;
};
```

若new bitmap导致异常（分配时内存不足或bitmap的copy构造函数抛出异常），wedget最后会持有一个指针指向一块被删除的bitmap（new失败了，自然没有新的bitmap了，但旧的biemap被删除了）

因此需要在复制pb所指向东西之前别删除pb

```c++
widget& operator=(const widget& rhs) {
	bitmap* temp = pb;//记录原先的pb
	pb = new bitmap(*rhs.pb);//令pb指向*pb的副本，现在pb指向的东西就改变了
	delete temp; //删除原先的pb
	return* this;
};
```

**copy and swap** 

```c++
class bitmap{...};
class widget{
	bitmap* pb;
	void swap(widget& rhs);//交换*this和rhs的数据
};

widget& operator=(const widget& rhs) {
    widget temp(rhs);//为rhs数据制作副本
    swap(temp);//将*this与上述副本的数据交换
	return* this;
};
```

### 12复制每一个成分

由自己编写的copying函数，在以后的应用过程中，可能执行的是局部拷贝，大多数编译器对此不会发出警告

若derived class的copying函数并没有指定实参传给其base class构造函数，除非由default构造函数，否则无法通过编译，为此，**需要让derived class的copying函数调用相应的base class函数**

```c++
class A{
	public:
		A(const A& rhs);
		A& operator=(const A& rhs);
	private:
		int a, b;
		double c;
};
class B: public A{
	private:
		int pri;
	public:
		B(const B& rhs);
		B& operator=(const B& rhs);
};
B::B(const B& rhs): A(rhs), pri(rhs.pri) {}
B::operator=(const B& rhs){
	A::operator=(rhs);
	pri = rhs.pri;
	return* this;
}
```

因此，**为确保每一个成分被复制，当为class添加一个成员变量或者将其作为base class时，都需要注意改写copying函数**

**Copying函数应该确保复制“对象内的所有成员变量”及“所有base class成分”。**

> 令copy assignment操作符调用copy构造函数是不合理的，因为这就像试图构造一个已经存在的对象。这件事如此荒谬，乃至于根本没有相关语法。是有一些看似如你所愿的语法，但其实不是;也的确有些语法背后真正做了它，但它们在某些情况下会造成你的对象败坏，所以我不打算将那些语法呈现给你看。
>
> 单纯地接受这个叙述吧:你不该令copy assignment操作符调用copy构造函数。
>
> 令copy构造函数调用copy assignment操作符-同样无意义。构造函数用来初始化新对象，而assignment操作符只施行于已初始化对象身上。对一个尚未构造好的对象赋值，就像在一个尚未初始化的对象身上做“只对已初始化对象才有意义”的事一样。

如果你发现你的copy构造函数和copy assignment操作符有相近的代码，消除重复代码的做法是，建立一个新的成员函数给两者调用。这样的函数往往是private而且常被命名为init。这个策略可以安全消除copy构造函数和copyassignment操作符之间的代码重复。

**不要尝试以某个copying函数实现另一个copying函数。应该将共同机能放进第三个函数中，并由两个coping函数共同调用。**

### 16成对使用new和delete时采取相同形式

**当使用new(也就是通过new动态生成一个对象)：**

内存被分配出来(通过名为operator new的函数，见条款49和条款51)。针对此内存会有一个(或更多)构造函数被调用。

**当使用delete：**

针对此内存会有一个(或更多)析构函数被调用，然后内存才被释放(通过名为operatordelete的函数，见条款51)。

delete的最大问题在于：即将被删除的内存之内究竟存有多少对象?

这个问题的答案决定了有多少个析构函数必须被调用起来。

> 即将被删除的那个指针，所指的是单一对象或对象数组?这是个必不可缺的问题
>
> 因为单一对象的内存布局一般而言不同于数组的内存布局。更明确地说，数组所用的内存通常还包括数组大小的记录，以便 delete知道需要调用多少次析构函数。单一对象的内存则没有这笔记录。

```c++
std::string* stringPtrl = new std::string;
std::string* stringPtr2 =new std::string[100];
delete stringPtrl;	//删除一个对象	
delete [] stringPtr2;	//删除一个由对象组成的数组	
```

对 stringPtr1使用delete[]形式，会发生什么事?

结果未有定义，但不太可能让人愉快。假设内存布局如上，delete会读取若干内存并将它解释为“数组大小”，然后开始多次调用析构函数，浑然不知它所处理的那块内存不但不是个数组，也或许并未持有它正忙着销毁的那种类型的对象。
如果没有对stringPtr2使用 delete[] 形式，又会发生什么事呢?

其结果亦未有定义，但可以猜想可能导致太少的析构函数被调用。犹有进者，这对内置类型如int者亦未有定义(甚至有害)，即使这类类型并没有析构函数。

**如果调用new时使用[]，必须在对应调用delete时也使用[]。**

**如果调用new时没有使用[]，那么也不该在对应调用delete时使用[]。**

当撰写的class 含有一个指针指向动态分配内存，并提供多个构造函数时，上述规则尤其重要，因为这种情况下必须小心地在所有构造函数中使用相同形式的new将指针成员初始化。如果没这样做，又如何知道该在析构函数中使用什么形式的delete 呢?

这个规则对于喜欢使用typedef的人也很重要，因为它意味typedef的作者必须说清楚，当程序员以 new创建该种 typedef 类型对象时，该以哪一种 delete形式删除之。考虑下面这个 typedef:

```c++
typedef std::string AddressLines[4];	//每个人的地址有4行，每行是一个string
std::string* pal = new AddressLines; 
//注意，"new AddressLines”返回一个 string*，就像"new string[4]"一样。
//由于AddressLines 是个数组，如果这样使用new那就必须匹配“数组形式”的delete:
delete pal;	//行为未有定义!	
delete [] pal;	//很好。	
```


为避免诸如此类的错误，最好尽量不要对数组形式做 typedef动作。这很容易达成，因为C++标准程序库含有string vector等templates，可将数组的需求降至几乎为零。

### 17以独立语句将newed对象置入智能指针

假设我们有个函数用来揭示处理程序的优先权，另一个函数用来在某动态分配所得的 widget 上进行某些带有优先权的处理:

```c++
int priority();
void processWidget(std::trl::shared_ptr<Widget> pw, int priority);
processWidget(new Widget, priority());//调用processWidget，error
processWidget(std::trl::shared_ptr<widget>(new Widget), priority);//right
// tr1::shared_ptr构造函数数需要一个原始指针(raw pointer)，但该构造函数是个explicit构造函数，无法造行隐式转换
// 将得自new Widge的原始指针转换为processWidget所要求的tr1::shared_ptr
```

上述调用却可能泄漏资源。

编译器产出一个processWidget 调用码之前，必须首先核算即将被传递的各个实参。

上述第二实参只是一个单纯的对 priority函数的调用，但第一实参由两部分组成:

- 执行new Widget表达式
- 调用tr1::shared ptr构造函数

于是在调用processWidget之前，编译器必须创建代码，做以下三件事:

- 调用  priority
- 执行 new Widget
- 调用tr1::shared ptr构造函数

和其他语言如Java和C#不同，那两种语言总是以特定次序完成函数参数的核算。

可以确定的是new Widget一定执行于 tr1::shared ptr 构造函数被调用之前，因为这个表达式的结果还要被传递作为trl::shared_ptr 构造函数的一个实参，但对 priority 的调用则可以排在第一或第二或第三执行。

如果编译器选择以第二顺位执行它，最终获得这样的操作序列:

1. 执行 new Widget
2. 调用 priority
3. 调用 tr1::shared ptr构造函数

万一对priority的调用导致异常，会发生什么事?在此情况下 new Widget 返回的指针将会遗失，因为它尚未被置入 trl::shared_ptr内，后者是我们期盼用来防卫资源泄漏的武器。

是的，在对processWidget的调用过程中可能引发资源泄漏，因为在 资源被创建 和 资源被转换为资源管理对象 两个时间点之间有可能发生异常干扰。

避免这类问题的办法很简单:使用分离语句

```c++
std::trl::shared ptr<widget> pw(new Widget);	
//在单独语句内以智能指针存储newed所得对象。
processWidget(pw, priority());	//这个调用动作绝不至于造成泄漏
```

**以独立语句将newed对象存储于(置入)智能指针内。如果不这样做，一旦异常被抛出，有可能导致难以察觉的资源泄漏。**

### 20以按引用常量传递替换按值传递

省情况下C++以by-value方式(一个继承自C的方式)传递对象至(或来自)函数。除非你另外指定，否则函数参数都是以实际实参的复件(副本)为初值，而调用端所获得的亦是函数返回值的一个复件。这些复件(副本)系由对象的copy构造函数产出，这可能使得pass-by-value成为昂贵的操作

```c++
class Person { 
	public:
		Person();			//为求简化，省略参数	
		virtual ~Person();	//条款7告诉你为什么它是 virtual	
		...
	private:
		std::string name; 
		std::string address;
};
class Student: public Person{ 
	public:
		Student();	//再次省略参数	
		~Student();
		...
	private:
		std::string schoolName;
		std::string schoolAddress;
};
//调用函数validateStudent，后者需要一个 Student实参(by-value)并返回它是否有效
bool validateStudent(Student s);//函数以by value 方式接受学生
```

Student对象内有两个string对象，所以每次构造一个 Student 对象也就构造了两个string对象。此外student 对象继承自 Person对象，所以每次构造Student对象也必须构造出一个Person对象。一个Person对象又有两个string对象在其中，因此每一次Person构造动作又需承担两个string构造动作。

最终结果是，以by-value方式传递一个 Student 对象会导致调用一次Student copy构造函数、一次Person copy构造函数、四次string copy构造函数。当函数内的那个 Student 复件被销毁，每一个构造函数调用动作都需要一个对应的析构函数调用动作。因此，以by-value方式传递一个 Student对象，总体成本是六次构造函数和六次析构函数

```
bool validateStudent(const Student& s);
```

这种传递方式的效率高得多:没有任何构造函数或析构函数被调用，因为没有任何新对象被创建。

修订后的这个参数声明中的const是重要的。原先的 validateStudent以 by-value方式接受一个Student参数，因此调用者知道他们受到保护，函数内绝不会对传入的 Student 作任何改变，validateStudent只能够对其复件(副本)做修改。现在 Student 以 by reference方式传递，将它声明为const 是必要的，因为不这样做的话调用者会忧虑 validateStudent会不会改变他们传入的那个 Student

**当一个 derived class 对象以 by-value方式传递并被视为一个base class对象，base class的copy构造函数会被调用，而造成此对象的行为像个derived class对象那些特化性质全被切割掉了，仅仅留下一个base class对象。**

```c++
class Window{ 
	public:
		std::string name() const;	//返回窗口名称	
		virtual void display() const;	//显示窗口和其内容	
};
class WindowWithScrol1Bars: public Window{ 
	public:
		...
		virtual void display() const;
}；
    
void printNameAndDisplay(Window w){	//不正确!参数可能被切割。	
	std::cout <<w.name(); 
    w.display();
}

WindowWithScrollBars wwsb; 
printNameAndDisplay(wwsb);

void printNameAndDisplay(const Windows& w){	//很好,参数不会被切割
	std::cout <<w.name(); 
    w.display();
}
```

passed-by-value会导致传入的wwsb被构造成为一个Window对象，而造成wwsb之所以是个WindowWithScrol1Bars对象的所有特化信息都会被切除。

在printNameAndDisplay函数内不论传递过来的对象原本是什么类型，参数w就像一个Window对象(因为其类型是Window)

在printNameAndDisplay内调用display调用的总是Window::display，绝不会是WindowWithScrol1Bars::display

解决切割(slicing)问题的办法，就是以by-reference-to-const的方式传递w 

**尽量以pass-by-reference-to-const替换pass-by-value。前者通常比较高效，并可避免切割问题**

**以上规则并不适用于内置类型，以及STL迭代器和函数对象。对它们而言， pass-by-value往往比较适当**

### 21必须返回对象时，别返回其reference

考虑一个用以表现有理数（rational numbers）的 class，内含一个函数用来计算两个有理数的乘积：

```c++
class Rational{ 
	public:
		Rational(int numerator=0, int denominator=1);
		//条款24说明为什么这个构造函数不声明为explicit 
	private:
		int n, d;
 		friend const Rational operator*(const Rational& lhs, const Rational& rhs); 
        //条款3说明为什么返回类型是const operator*，为了防止出现a * b = c
};
```

这个版本的operator＊以by value方式返回其计算结果（一个对象）

若不想付出该对象的构造和析构成本，可以改而传递reference。但是所谓 reference只是个名称，代表某个既有对象。任何时候看到一个reference声明式，你都应该立刻问自己，它的另一个名称是什么？因为它一定是某物的另一个名称。以上述operator＊为例，如果它返回一个 reference，后者一定指向某个既有的Rational对象，内含两个Rational对象的乘积。

当然不可能期望这样一个（内含乘积的）Rational对象在调用operator＊之前就存在。也就是说，如果有：

```c++
Rational a(1,2);//a=1/2 
Rational b(3,5);//b=3/5 
Rational c = a * b;//c应该是3/10
//如果是按值传递，返回的将是3/10的临时副本，便是合理的
//但如果按引用传递，必须原本就存在一个其值为3/10的Rational对象
//如果 operator＊要返回一个reference指向如此数值，它必须自己创建那个Rational对象
```

途径有二：在stack空间或在heap空间创建之。

如果定义一个 local变量，就是在stack空间创建对象：

```c++
const Rational& operator* (const Rational& lhs, const Rational& rhs) 
{
	Rational result(lhs.n * rhs.n, lhs.d * rhs.d);//警告！糟糕的代码！ 
    //这里实际使用的是未重载的*对int类型进行相乘，然后将结果作为初始化的值
	return result;
}
```

但这种做法必须用构造函数构造result，但你的目标是要避免调用构造函数。

更严重的是：这个函数返回一个reference 指向 result，但 result是个local对象，而local对象在函数退出前被销毁了。因此，这个版本的operator＊并未返回 reference 指向某个 Rational，它返回的reference指向一个已经被销毁的对象

任何调用者甚至只是对此函数的返回值做任何一点点运用，都将立刻坠入无定义行为的恶地。事情的真相是，任何函数如果返回一个reference指向某个local对象，都将一败涂地。（如果函数返回指针指向一个local对象，也是一样）



在heap 内构造一个对象，并返回reference指向它。Heap-based 对象由new创建

```c++
const Rational& operator* (const Rational& lhs, const Rational& rhs) 
{
	 Rational* result = new Rational (lhs.n * rhs.n, lhs.d * rhs.d); 
	 return *result;
}
Rational w, x, y, z; 
w = x * y * z;//与operator＊（operator＊（x，y），z）相同
```

还是必须付出一个构造函数调用代价，因为分配所得的内存将以一个适当的构造函数完成初始化动作。但此外现在又有了另一个问题：谁该对着被你new出来的对象实施delete？

同一个语句内调用了两次 operator＊，因而两次使用new，也就需要两次 delete。但却没有合理的办法让 operator＊使用者进行那些 delete 调用，因为没有合理的办法让他们取得 operator＊返回的 references 背后隐藏的那个指针。这绝对导致资源泄漏。

上述不论on-the-stack 或 on-the-heap 做法，都因为对 operator＊ 返回的结果调用构造函数而存在问题。最初目标是要避免如此的构造函数调用动作。那么如果采取下述方法：

让operator＊返回的 reference指向一个被定义于函数内部的static Rational对象：

```c++
const Rational& operator* (const Rational& lhs, const Rational& rhs) {
	static Rational result;
	//static对象，此函数将返回其reference。
	result = ...;//将lhs乘以rhs，并将结果置于result内。
	return result;
}
bool operator==(const Rational& lhs, const Rational＆ rhs）；
//一个针对Rationals而写的operator＝=
Rational a, b, c,d;
...
if((a * b) == (c * d)){...}//当乘积相等时，做适当的相应动作
else{...}//当乘积不等时，做适当的相应动作
```

表达式

```
((a * b) = (c * d))
```

总是被核算为true，不论abcd的值是什么！

将代码重新写为等价的函数形式：if (operator==(operator* (a, b), operator* (c, d)))

在operator==被调用前，已有两个 operator＊ 调用式起作用，每一个都返回 reference 指向 operator＊内部定义的 static Rational对象。两次 operator＊调用的确各自改变了 static Rational对象值，但由于它们返回的都是reference，因此调用端看到的永远是static Rational对象的现值

一个必须返回新对象的函数的正确写法是：

```c++
inline const Rational operator * (const Rational& lhs, const Rational& rhs) {
	return Rational(lhs.n * rhs.n, lhs.d * rhs.d); 
}
```

当然，仍然得承受 operator＊返回值的构造成本和析构成本，然而长远来看那只是为了获得正确行为而付出的一个小小代价。但万一账单很恐怖，你承受不起，别忘了C＋＋和所有编程语言一样，允许编译器实现者施行最优化，用以改善产出码的效率却不改变其可观察的行为。因此某些情况下 operator＊返回值的构造和析构可被安全地消除。如果编译器运用这一事实（它们也往往如此），你的程序将继续保持它们该有的行为，而执行起来又比预期的更快。

> 当你必须在返回一个reference和返回一个object之间抉择时，你的工作就是挑出行为正确的那个
>
> **绝不要返回pointer或reference指向一个local stack对象**
>
> **或返回 reference 指向一个heap-allocated对象**
>
> **或返回pointer 或 reference 指向一个local static对象而有可能同时需要多个这样的对象**
>
> 条款4 已经为“在单线程环境中合理返回 reference 指向一个local static对象”提供了一份设计实例

### 22将成员变量声明为private

**从封装的角度观其实只有两种访问权限：private（提供封装）和其他（不提供封装）**

**将成员变量声明为private。这可赋予客户访问数据的一致性、可细微划分访问控制、允诺约束条件获得保证，并提供class作者以充分的实现弹性。**

**protected并不比public更具封装性。**

如果成员变量不是 public，客户唯一能够访问对象的办法就是通过成员函数。如果public接口内的每样东西都是函数，客户就不需要在打算访问class成员时迷惑地试着记住是否该使用小括号（圆括号）。他们只要做就是了，因为每样东西都是函数。

使用函数可以让你对成员变量的处理有更精确的控制。如果你令成员变量为public，每个人都可以读写它，但如果你以函数取得或设定其值，你就可以实现出不准访问、只读访问以及读写访问以及惟写访问

```c++
class AccessLevels{ 
	public:
	...
		int getReadonly() const { return readonly;) 
		void setReadWrite(int value) { readWrite = value; } 
		int getReadWrite( ) const { return readwrite;} 
		void setWriteOnly(int value) { writeOnly = value; } 
	private: 
		int noAccess;  //对此int无任何访问动作
		int readonly;  //对此int 做只读访问（read-only access） 
		int readWrite; //对此int 做读写访问（read-write access） 
		int writeonly; //对此int 做惟写访问（write-only access） 
};
```

出于封装的考虑：如果你通过函数访问成员变量，日后可改以某个计算替换这个成员变量，而 class 客户一点也不会知道 class的内部实现已经起了变化。

假设你正在写一个自动测速程序，当汽车通过，其速度便被计算并填入一个速度收集器内：

```c++
class SpeedDataCollection{ 
	public:
		void addValue(int speed);//添加一笔新数据
    	double averageSoFar() const;//返回平均速度 
};
```

现在考虑成员函数 averageSoFar

做法之一是在class内设计一个成员变量，记录至今以来所有速度的平均值。当averageSoFar被调用，只需返回那个成员变量就好。这一种做法（随时保持平均值）会使每一个SpeedDataCo1lection对象变大，因为你必须为用来存放目前平均值、累积总量、数据点数的每一个成员变量分配空间。然而 averageSoFar却可因此而十分高效；它可以只是一个返回目前平均值的inline函数（见条款30）。

另一个做法是令averageSoFar每次被调用时重新计算平均值，此函数有权力调取收集器内的每一笔速度值，相反地，被询问才计算平均值会使得 averageSoFar执行较慢，但每一个 SpeedDataCollection 对象比较小。

重点是，由于通过成员函数来访问平均值（也就是封装了它），你得以替换不同的实现方式（以及其他你可能想到的东西），客户最多只需重新编译。（如果遵循条款31所描述的技术，甚至可以消除重新编译的不便性。）

如果你对客户隐藏成员变量（也就是封装它们），你可以确保class的约束条件总是会获得维护，因为只有成员函数可以影响它们。犹有进者，你保留了日后变更实现的权利。如果你不隐藏它们，你很快会发现，即使拥有class原始码，改变任何public事物的能力还是极端受到束缚，因为那会破坏太多客户码。Public 意味不封装，而几乎可以说，不封装意味不可改变，特别是对被广泛使用的classes 而言。被广泛使用的classes是最需要封装的一个族群，因为它们最能够从“改采用一个较佳实现版本”中获益。

条款23：某些东西的封装性与当其内容改变时可能造成的代码破坏量成反比。因此，成员变量的封装性与成员变量的内容改变时所破坏的代码数量成反比。

**假设我们有一个public 成员变量，而我们最终取消了它。所有使用它的客户码都会被破坏，而那是一个不可知的大量。因此 public成员变量完全没有封装性**

**假设我们有一个protected成员变量，而我们最终取消了它，所有使用它的derived classes都会被破坏，那往往也是个不可知的大量。因此，protected 成员变量就像 public成员变量一样缺乏封装性**

因为在这两种情况下，如果成员变量被改变，都会有不可预知的大量代码受到破坏。虽然这个结论有点违反直观，但经验丰富的程序库作者会告诉你，它是真的。一旦你将一个成员变量声明为public或 protected 而客户开始使用它，就很难改变那个成员变量所涉及的一切。太多代码需要重写、重新测试、重新编写文档、重新编译。

### 23以non-member、non-friend替换member函数

如果要在一个member、friend函数（它不只可以访问class内的private数据，也可以取用private函数、enums、typedefs 等等）和一个non-member， non—friend函数（它无法访问上述任何东西）之间做抉择，而且两者提供相同机能，那么，导致较大封装性的是 non—member non—friend函数，因为它并不增加能够访问class内private成分的函数数量。

```c++
class WebBrowser{ 
	public:
	...
	void clearCache(); 
	void clearHistory(); 
	void removeCookies(); 
	//许多用户会想一整个执行所有这些动作，因此WebBrowser也提供这样一个函数
	void clearEverything();  //调用clearCache，clearHistory和removeCookies
};
//这一机能也可由一个non—member函数调用适当的member函数而提供出来：
void clearBrowser(WebBrowser& wb){
	wb.clearCache(); 
	wb.clearHistory();
	wb.removeCookies();
}
```

只因在意封装性而让函数成为class的non—member，并不意味它不可以是另一个class的member。例如可以令 clearBrowser成为某工具类（utility class）的一个 static member函数。 只要它不是WebBrowser的一部分（或成为其friend），就不会影响 webBrowser的private成员封装性。

在C++，比较自然的做法是让clearBrowser成为一个non-member函数并且位于 WebBrowser所在的同一个namespace（命名空间）内：

```c++
namespace WebBrowserStuff{ 
	class WebBrowser(...);
	void clearBrowser(WebBrowser& wb);
}
```

namespace和classes不同，前者可跨越多个源码文件而后者不能。

像clearBrowser这样的函数是个提供便利的函数，如果它既不是 members 也不是 friends，就没有对 WebBrowser 的特殊访问权力，也就说明可以以其它方式（不同于必须使用对象来调用其成员的方式）调用它。举个例子，如果 clearBrowser不存在，客户端就只好自行调用 clearCache，clearHistory 和removeCookies。

将所有便利函数放在多个头文件内但隶属同一个命名空间，意味客户可以轻松扩展这一组便利函数。他们需要做的就是添加更多non—member、non—friend函数到此命名空间内。

### 24若所有参数皆需类型转换，采用non-member

```c++
class Rational{
	public：
		Rational (int numerator = 0, int denominator = 1);
		//构造函数刻意不为explicit；允许int—to—Rational 隐式转换。
		int numerator () const;
		int denominator () const;
		...
        const Rational operator* (const Rational& rhs) const;
};
result = oneHalf * 2;//good  result = oneHalf.operator* (2);
```

成功的调用，是因为发生了隐式类型转换（implicit type conversion）。编译器知道你正在传递一个int，而函数需要的是Rational；但它也知道只要调用Rational构造函数并赋予你所提供的int，就可以变出一个适当的Rational来。于是它就那样做了。

为什么即使Rational构造函数不是explicit，仍然只有一个可通过编译，另一个不可以：

```c++
result = 2 * oneHalf;//error result = 2.operator* (oneHalf);
```

因为只有当参数被列于参数列（parameter list）内，这个参数才是隐式类型转换的合格参与者，this对象的那个隐喻参数，绝不是隐式转换的合格参与者，上述2作为调用者而不是被传入的参数

支持混合式算术运算，可行之道是，让 operator*成为一个non—member函数，允许编译器在每一个实参身上执行隐式类型转换：

```c++
class Rational{...}；//不包括operator*
const Rational operator* (const Rational& lhs, const Rational& rhs){
	return Rational (lhs.numerator() * rhs.numerator(), lhs.denominator() * rhs.denominator())
}
```

如果你需要为某个函数的所有参数（包括被this指针所指的那个隐喻参数）进行，类型转换，那么这个函数必须是个non-member

### 25编写swap函数

**对于编写swap接口**

置换以指针指向一个对象，内含真正数据那种class（而非 class template）时：在class中提供一个public swap成员函数做真正的置换工作，然后将std::swap特化，令它调用该成员函数

```c++
class Widget{ //与前同，唯一差别是增加swap函数
	public:
		void swap(Widget& other) {
			using std::swap;
			swap(pImpl, other.pImpl);//若要置换Widgets，就置换其plmpl指针
        }
};
//以后碰到swap，将会使用下述特定化swap，然后这个swap将会调用widget的成员函数swap
namespace std { 
	template<>
	void swap<widget>(widget&a, Widget& b) {
		a.swap(b);//若要置换widgets，调用其swap成员函数
	}
}
```

假设为class templates时：在你的class或template所在的命名空间内提供一个non-member swap，并令它调用上述swap成员函数，但不再将那个non-member swap声明为std::swap的特化版本或重载版本。C++的名称查找法则会找到widgetStuff内的widget专属版本。

```c++
namespace widgetStuff{ 
	...
	template<typename T>//模板化的WidgetImp1等等
	class Widget{...};//同前，内含swap成员函数。
	...
	template<typename T>
	void swap(Widget<T>& a, Widget<T>&b){ 
        a.swap(b); //non-member swap函数, 这里并不属于std命名空间。
    }
}
```

有一个理由使你应该为classes 特化 std::swap，所以如果你想让你的class专属版swap在尽可能多的语境下被调用，你需得同时在该class所在命名空间内写一个non-member版本以及一个std::swap特化版本。

**对于使用swap接口：**

如果调用swap，请确定包含一个using声明式，以便让std::swap在你的函数内曝光可见，然后不加任何namespace修饰符调用 swap

```c++
template<typename T>
void dosomething(T& obj1, T& obj2){
	using std::swap;//令std::swap在此函数内可用
	swap(obj1, obj2);
    // 如果T是Widget并位于命名空间widgetStuff内，编译器会使用实参取决查找规则找出widgetStuff内的swap 
    // 如果没有T专属swap存在，编译器就使用std内的swap的T专属特化版，而非一般化的那个template
} 

std::swap(obj1, obj2);
// 这便强迫编译器只认std内的swap（包括其任何template特化），不会考虑其它名称空间中适合的版本
// 这正是classes对std::swap进行全特化的重要原因：全特化后，这个代码也可以使用类型专属的swap实现版
```

> 注意：std名称空间内的东西可以特化但不要重载
>
> C++只允许对 class templates 偏特化，在function templates 身上偏特化是行不通的

### 26延后变量定义式出现的时间

不只应该延后变量的定义，应该延后直到非得使用该变量的前一刻为止，甚至应该尝试延后这份定义直到能够给它初值实参为止。如果这样，不仅能够避免构造（和析构）非必要对象，还可以避免无意义的default构造行为。更深一层说，以具明显意义之初值将变量初始化，还可以附带说明变量的目的。

如果变量只在循环内使用并且每次都需要赋值，那么付出的成本为

把它定义于循环外并在每次循环迭代时赋值给它：1个构造函数＋1个析构函数＋n个赋值操作

把它定义于循环内：n个构造函数＋n个析构函数

### 27少做转型动作

```c++
class Window {
	public:
		virtual void onResize(){...}
    	...
}
class SpecialWindow: public Window {
	public:
	virtual void onResize() {
        static_cast<window>(*this).onResize();
        //将＊this转型为Window，然后调用其onResize，这不可行！
    	...//这里进行SpecialWindow 专属行为。 
    }
} ;
```

这段程序将＊this转型为window，对函数 onResize的调用也因此调用了window::onResize。但它调用的并不是当前对象上的函数，而是转型动作所建立的一个＊this对象的base class成分的暂时副本身上的onResize

上述代码并非在当前对象身上调用 window::onResize 之后又在该对象身上执行SpecialWindow专属动作。而是在当前对象的base class成分的副本上调用window::onResize，然后在当前对象身上执行SpecialWindow专属动作。

如果window::onResize修改了对象内容，当前对象其实没被改动，改动的是副本。然而 Specialwindow::onResize内如果也修改对象，当前对象真的会被改动。这使当前对象：其base class成分的更改没有落实，而derived class成分的更改倒是落实了。

解决之道是拿掉转型动作，并不将＊this视为一个base class对象，目的只是调用 base class版本的onResize函数，令它作用于当前对象身上。所以请这么写：

```c++
class SpecialWindow: public Window {
	public:
		virtual void onResize() {
			Window::onResize();//调用Window::onResize作用于＊this身上
			...
		}
	...
};
```

如果可以，尽量避免转型，特别是在注重效率的代码中避免 dynamic＿casts。如果有个设计需要转型动作，试着发展无需转型的替代设计

### 28避免返回handles指向对象内部成分

```c++
class Point{
	public:
		Point(int x, int y); 
		void setX(int newVal); 
		void setY(int newVal); 
}；
struct RectData{
	Point ulhc;
	Point lrhc;
}；
class Rectangle {
 	public:
		Point& upperLeft() const { return pData->ulhc;} 
		Point& lowerRight() const { return pData->lrhc;}
	private:
		std::tr1::shared＿ptr<RectData> pData；
}
Point coord1(0, 0); 
Point coord2(100,100);
const Rectangle rec(coord1,coord2);//rec是个const矩形，从（0，0）到（100，100）
rec.upperLeft().setx(50);//现在rec却变成从（50，0）到（100，100）
//upperLeft的调用者能够使用被返回的reference（指向rec内部的Point成员变量）来更改成员。但rec其实应该是不可变的（const）
```

一方面upperLeft和lowerRight 被声明为 const成员函数，因为它们的目的只是为了提供客户一个得知Rectangle相关坐标点的方法，而不是让客户修改Rectangle（见条款3）。

另一方面两个函数却都返回 references 指向private内部数据，调用者于是可通过这些references更改内部数据


这说明：

第一，成员变量的封装性最多只等于返回其reference的函数的访问级别。本例之中虽然ulhc和lrhc都被声明为 private， 它们实际上却是public，因为public函数upperLeft和lowerRight传出了它们的references。

第二，如果const成员函数传出一个reference，后者所指数据与对象自身有关联，而它又被存储于对象之外，那么这个函数的调用者可以修改那笔数据。这正是bitwise constness的一个附带结果，见条款3。

解决办法是对它们的返回类型加上const:

```c++
class Rectangle {
 	public:
		const Point& upperLeft() const { return pData->ulhc;} 
		const Point& lowerRight() const { return pData->lrhc;}
	private:
		std::tr1::shared＿ptr<RectData> pData；
}
```

References、指针和迭代器统统都是所谓的 handles（号码牌，用来取得某个对象），而返回一个代表对象内部数据的handle，随之而来的便是降低对象封装性的风险。同时，它也可能导致虽然调用const成员函数却造成对象状态被更改

### 29异常安全措施

异常安全有两个条件：不泄漏任何资源，不允许数据败坏

异常安全函数（Exception-safe functions）提供以下三个保证之一：

**基本承诺**：如果异常被抛出，程序内的任何事物仍然保持在有效状态下。没有任何对象或数据结构会因此而败坏，所有对象都处于一种内部前后一致的状态 。然而程序的现实状态（exact state）恐怕不可预料。

**强烈保证**：如果异常被抛出，程序状态不改变。调用这样的函数需有这样的认知：如果函数成功，就是完全成功，如果函数失败，程序会回复到调用函数之前的状态。在调用一个提供强烈保证的函数后，程序状态只有两种可能：如预期般地到达函数成功执行后的状态，或回到函数被调用前的状态。 

与此成对比的是，如果调用一个只提供基本承诺的函数，而真的出现异常，程序有可能处于任何状态—只要那是个合法状态。

**不抛掷（nothrow）保证**：承诺绝不抛出异常，因为它们总是能够完成它们原先承诺的功能。作用于内置类型（例如 ints，指针等等）身上的所有操作都提供nothrow保证。这是异常安全码中一个必不可少的关键基础材料。

```c++
void PrettyMenu::changeBackground(std::istream& imgSrc) {
	Lock ml(&mutex);//来自条款14：获得互斥器并确保它稍后被释放
	delete bgImage;//摆脱旧的背景图像 
	++imageChanges;//修改图像变更次数 
	bgImage = new Image(imgSrc);//安装新的背景图像 
    // 如果new Image(imgSrc)抛出异常，bgImage就是指向一个已被删除的对象，imageChanges也已被累加
}

class PrettyMenu{
	std::trl::shared_ptr<Image> bgImage; 
}；
void PrettyMenu::changeBackground(std::istream& imgSrc) {
	Lock ml(&mutex);
	bgImage.reset(new Image(imgSrc));//以new Image的执行结果设定bgImage内部指针
    // trl::shared_ptr::reset函数只有在其参数（也就是new Image(imgSrc)的执行结果） 被成功生成之后才会被调用。
    // delete 只在 reset 函数内被使用，所以如果从未进入那个函数也就绝对不会使用delete。
    ++imageChanges;
}
```

有个一般化的设计策略很典型地会导致强烈保证，这个策略被称为 copy and swap：为你打算修改的对象（原件）做出一份副本，然后在那副本身上做一切必要修改。若有任何修改动作抛出异常，原对象仍保持未改变状态。待所有改变都成功后，再将修改过的那个副本和原对象在一个不抛出异常的操作中置换（swap）。

实现上通常是将所有隶属对象的数据从原对象放进另一个对象内，然后赋予原对象一个指针，指向那个所谓的实现对象,这种手法常被称为pimpl idiom

```c++
struct PMImpl{
	std::tr1::shared_ptr<Image> bgImage;
	int imageChanges;
};

class PrettyMenu{ 
	...
	private:
		Mutex mutex;
		std::trl::shared_ptr<PMImpl> pImpl; 
};

void PrettyMenu::changeBackground(std::istream& imgsrc) {
	using std::swap;
	Lock ml(&mutex);//获得mutex的副本数据
	std::trl::shared_ptr<PMImp1> pNew(new PMImp1(*pImp1));//创建副本
	pNew -> bgImage.reset(new Image(imgSrc))；//修改副本 
	++pNew->imageChanges;
	swap(pImpl, pNew);//置换（swap）数据，释放mutex
}
```

函数提供的异常安全保证通常最高只等于其所调的各个函数的异常安全保证中的最弱者。

### 30inlining

inline 函数背后的整体观念是，将对此函数的每一个调用都以函数本体替换之。这样做可能增加你的目标码（object code）大小。在一台内存有限的机器上，过度热衷inlining会造成程序体积太大（对可用空间而言）。 即使拥有虚内存，inline造成的代码膨胀亦会导致额外的换页行为（paging），降低指令高速缓存装置的击中率（instruction cache hit rate），以及伴随这些而来的效率损失。

大部分编译器拒绝将太过复杂（例如带有循环或递归）的函数inlining，而所有对 virtual 函数的调用（除非是最平淡无奇的）也都会使inlining 落空。因为 virtual 意味等待，直到运行期才确定调用哪个函数，而inline 意味执行前，先将调用动作替换为被调用函数的本体。如果编译器不知道该调用哪个函数， 你就很难责备它们拒绝将函数本体inlining。

一个表面上看似inline的函数是否真是 inline， 取决于你的建置环境，主要取决于编译器。大多数编译器提供了一个诊断级别：如果它们无法将你要求的函数inline化，会给你一个警告信息。有时候虽然编译器有意愿inlining某个函数，还是可能为该函数生成一个函数本体。

与此并提的是，编译器通常不对通过函数指针而进行的调用实施inlining， 这意味对inline函数的调用有可能被inlined，也可能不被inlined，取决于该调用的实施方式

```c++
inline void f()//假设编译器有意愿inline对f的调用
void(*pf)() = f；//pf指向f
f();//这个调用将被inlined，因为它是一个正常调用
pf();//这个调用或许不被inlined，因为它通过函数指针达成。
```

inline存在以下问题：

- C++ 对于对象被创建和被销毁时发生什么事做了各式各样的保证，在这些情况中C++描述了什么一定会发生，但没有说如何发生。而编译器会为了处理异常而在构造函数和析构函数中产生代码，Derived构造函数会陆续调用其成员变量和base class两者的构造函数，而那些调用（它们自身也可能被inlined）会影响编译器是否对此函数 inlining。相同理由也适用于Base构造函数，所以如果它被inlined，所有替换Base构造函数调用而插入的代码也都会被插入到Derived构造函数调用内（因为 Derived构造函数调用了Base构造函数）。
- inline函数无法随着程序库的升级而升级。换句话说如果f是程序库内的一个inline函数，客户将f函数本体编进其程序中，一旦程序库设计者决定改变f，所有用到f的客户端程序都必须重新编译。

### 32确定public塑模出is-a关系

public继承意味is-a。适用于base classes身上的每一件事情一定也适用于derived classes 身上，因为每一个 derived class 对象也都是一个base class对象。

### 33避免遮掩继承而来的名称

C++的名称遮掩规则（name—hiding rules）所做的唯一事情就是：遮掩名称。至于名称是否应和相同或不同的类型，并不重要

当位于一个derived class成员函数内指涉（refer to）base class内的某物（也许是个成员函数、typedef、或成员变量）时，编译器可以找出我们所指涉的东西，因为derived classes 继承了声明于base classes内的所有东西。 实际运作方式是，derived class 作用域被嵌套在base class作用域内

如果你继承base class并加上重载函数，而你又希望重新定义或覆写其中一部分，那么你必须为那些原本会被遮掩的每个名称引入一个using声明式，否则某些你希望继承的名称会被遮掩

```c++
Derived d; 
int x; 
d.mf1();//没问题，调用Derived::mf1 
d.mf1(x);//错误！因为Derived::mf1遮掩了Base::mf1 
d.mf2();//没问题，调用Base::mf2 
d.mf3();//没问题，调用Derived::mf3
d.mf3(x);//错误！因为Derived::mf3遮掩了Base::mf3 

class Base{
	public:
		virtual void mf1() = 0;
		virtual void mf1(int);
		virtual void mf2();
		void mf3();
		void mf3(double);
class Derived: public Base{
	public:
		//让Base class内名为mf1和mf3的所有东西 在Derived作用域内都可见（并且public） 
		using Base::mf1;
		using Base::mf3;
		virtual void mf1(); 
		void mf3();
		void mf4(); 
}；
```

例如假设Derived以private形式继承Base，而Derived唯一想继承的mf1是那个无参数版本。using声明式在这里派不上用场，因为using声明式会令继承而来的某给定名称之所有同名函数在 derived class中都可见。这时候就需要转交函数(forwarding function):

```c++
class Base {
	public:
		virtual void mf1() = 0; 
		virtual void mfl(int);
};
class Derived: private Base { 
	public:
		virtual void mf1() { Base::mf1(); } //转交函数
}
Derived d; 
int x; 
d.mf1();// 很好，调用的是Derived::mf1
d.mf1(x);// 错误！Base::mf1()被遮掩了
```

### 34区分接口继承和实现继承

```c++
class Shape{ 
	public:	
		virtual void draw() const = 0;// pure virtual 函数
		virtual void error(const std::string& msg); // impure virtual 函数
		int objectID() const;// non-virtual 函数
};
class Rectangle: public Shape {...}; 
class Ellipse: public Shape {...};
```

pure virtual 函数有两个最突出的特性：它们必须被任何继承了它们的具象class 重新声明，而且它们在抽象 class 中通常没有定义。即**声明一个pure virtual 函数的目的是为了让 derived classes 只继承函数接口**。

Shape class无法为此函数提供合理的缺省实现，因此让 derived classes 只继承函数接口，因此使用pure virtual

derived classes 继承impure virtual函数接口，但impure virtual函数会提供一份实现代码，derived classes 可能覆写它。即**声明 impure virtual 函数的目的，是让derived classes继承该函数的接口和缺省实现**。

如果成员函数是个non-virtual函数，意味是它并不打算在 derived classes 中有不同的行为。实际上一个 non-virtual 成员函数所表现的不变性（invariant）凌驾其特异性（specialization），因为它表示不论 derived class变得多么特异化，它的行为都不可以改变。即**声明 non-virtual函数的目的是为了令derived classes继承函数的接口及一份强制性实现**。

允许impure virtual函数同时指定函数声明和函数缺省行为，却有可能造成危险。

为避免这种危险，就需要只指定函数声明，并强制要求必须给出自己定义的版本，不能只继承缺省版本

```c++
class Airplane{ 
	public:
		virtual void fly(const Airport& destination) = 0; 
};
void Airplane::fly（const Airport& destination）//pure virtual 函数实现 
{...}//缺省行为，将飞机飞至指定的目的地

class ModelA: public Airplane{ 
	public:
		virtual void fly(const Airport& destination) { Airplane::fly(destination); }
};

class ModelB: public Airplane{ 
	public:
		virtual void fly(const Airport& destination) {Airplane::fly(destination);}
};

class Modelc:public Airplane{ 
	public:
		virtual void fly(const Airport& destination); 
};
void ModelC::fly(const Airport& destination) {...}//将C型飞机飞至指定的目的地
```

### 35考虑virtual函数以外的选择

**传统的Strategy做法**：将健康计算函数做成一个分离的继承体系中的virtual成员函数。

```c++
class GameCharacter;//前置声明（forward declaration）
class HealthCalcFunc{
	public:
		virtual int calc(const GameCharacter& gc) const {...}
};

HealthCalcFunc defaultHealthCalc; 

class GameCharacter{
	public:
		explicit GameCharacter (HealthCalcFunc* phcf = &defaultHealthCalc):pHealthCalc(phcf) {}
		int healthValue() const { return pHealthCalc->calc(*this);} 
	private:
		HealthCalcFunc* pHealthCalc; 
};
```

这个解法的吸引力在于，熟悉标准 Strategy模式的人很容易辨认它，而且它还提供将一个既有的健康算法纳入使用的可能性—只要为HealthCalcFunc继承体系添加一个 derived class 即可。

**Non-Virtual Interface**：通过public non-virtual成员函数间接调用private virtual函数

在NVI手法下其实没有必要让virtual函数一定得是private。某些class继承体系要求 derived class在virtual 函数的实现内必须调用其base class的对应兄弟，而为了让这样的调用合法，virtual 函数必须是 protected，不能是private。有时候 virtual 函数甚至一定得是public（例如具备多态性质的base classes 的析构函数—见条款7），这么一来就不能实施NVI手法了。

> NVI手法允许 derived classes 重新定义 virtual 函数，从而赋予它们如何实现机能的控制能力，但base class 保留诉说函数何时被调用的权利。一开始这些听起来似乎诡异，但C++的这种 derived classes 可重新定义继承而来的 private virtual 函数的规则完全合情合理。

```c++
class GameCharacter {
	public:
		int healthValue() const {
             ...//做事前工作
			int retVal = doHealthvalue();//做真正工作
			...//做事后工作
			return retVal;
		}
	private:
    	//derived classes 可重新定义它
		virtual int doHealthValue() const {...}//缺省算法，计算健康指数
};
```

NVI手法的一个优点在上述代码注释做一些事前工作和做一些事后工作之中。

那些注释用来告诉你当时的代码保证在virtual函数进行真正工作之前和之后被调用。这意味外覆器（wrapper）确保得以在一个 virtual 函数被调用之前设定好适当场景，并在调用结束之后清理场景。

**藉由 Function Pointers 实现 Strategy 模式**：通过函数指针替换virtual函数，优点例如每个对象可各自拥有自己的健康计算函数和可在运行期改变计算函数，缺点在于如果涉及到访问non-public成分，就必须降低GameCharacter封装性

将机能从成员函数移到class外部函数，带来的一个缺点是，非成员函数无法访问class的non-public成员

```c++
class GameCharacter;//前置声明（forward declaration） 
//以下函数是计算健康指数的缺省算法。
int defaultHealthCalc(const GameCharacter& gc); 

class GameCharacter{
	public:
		typedef int (*HealthCalcFunc)(const GameCharacter&);
    	//构造函数接受一个指针，指向一个健康计算函数
		explicit GameCharacter(HealthCalcFunc hcf = defaultHealthCalc):healthFunc(hcf) {}
		int healthValue() const { return healthFunc(*this);} 
    private:
		HealthCalcFunc healthFunc;//HealthCalcFunc是一个指向函数的指针
};

//同一人物类型之不同实体可以有不同的健康计算函数
class EvilBadGuy:public GameCharacter{ 
    public:
		explicit EvilBadGuy(HealthCalcFunc hcf = defaultHealthCalc):GameCharacter(hcf) {...} 
};

int loseHealthQuickly(const GameCharacter&);//健康指数计算函数1
int loseHealthSlowly(const GameCharacter&);//健康指数计算函数2
//相同类型的人物搭配不同的健康计算方式
EvilBadGuy ebg1(loseHealthQuickly);
EvilBadGuy ebg2(loseHealthSlowly);
```

**藉由 tr1::function 完成 Strategy 模式**：tr1::function对象可持有（保存）任何可调用物（callable entity，也就是函数指针、函数对象、或成员函数指针），只要其签名式兼容于需求端。所谓兼容，意思是这个可调用物的参数可被隐式转换为 const GameCharacter＆，而其返回类型可被隐式转换为int。

```c++
class GameCharacter;
int defaultHealthCalc(const GameCharacter& gc);
class GameCharacter{
	public:
		//HealthCalcFunc可以是任何可调用物（callable entity），可被调用并接受
    	//这里tr1::function代表的函数是接受一个reference指向const GameCharacter，并返回int。
		typedef std::tr1::function<int (const GameCharacter&)> HealthCalcFu
		explicit GameCharacter(HealthCalcFunc hcf = defaultHealthCalc):healthFunc(hcf) {}
		int healthValue()const { return healthFunc(*this);} 
	private:
		HealthCalcFunc healthFunc; 
};


class EvilBadGuy: public GameCharacter{...};
class EyeCandyCharacter: public GameCharacter{...};

short calcHealth(const GameCharacter&);//健康计算函数注意其返回类型为non—int
EvilBadGuy ebg1(calcHealth);//人物1，使用函数计算健康指数

struct HealthCalculator{//为计算健康而设计的函数对象
	int operator()(const GameCharacter&) const{...} 
};
EyeCandyCharacter ecc1(HealthCalculator());//人物2，使用函数对象计算健康指数

class GameLevel{ 
	public:
		float health(const GameCharacter&) const;//成员函数，用以计算健康，注意其non—int返回类型
};

GameLevel currentLevel;//人物3，使用对象的成员函数计算健康指数
EvilBadGuy ebg2(std::tr1::bind(&GameLevel::health, currentLevel, _1);
// 为计算ebg2的健康指数，应该使用GameLevel class的成员函数health。GameLevel::health 宣称它自己接受一个参数
// 但它实际上接受两个参数，因为它也获得一个隐式参数GameLevel，也就是this所指的那个。
// 然而GameCharacters的健康计算函数只接受单一参数：GameCharacter
// 于是我们将 currentLevel 绑定为 GameLevel对象，让它在每次GameLevel::health被调用以计算ebg2的健康时被使用。
// 那正是tr1::bind的作为：它指出ebg2的健康计算函数应该总是以currentLevel作为GameLevel对象。
```

### 36不重新定义继承而来的的non-virtual函数

```c++
class B{ 
	public: 
		void mf(); 
};
class D:public B{	
	void mf();//遮掩（hides）了B::mf；见条款33
};
D x;
B* pB = &x; pB->mf();//调用B::mf
D* pD = &x; pD->mf();//调用D::mf
```

non-virtual 函数如B::mf和D::mf都是静态绑定

这意思是，由于pB被声明为一个pointer-to-B，通过pB调用的non-virtual函数永远是B所定义的版本，即使pB指向一个类型为B派生之 class的对象，一如本例。

但另一方面，virtual函数却是动态绑定（dynamically bound，见条款37），如果mf是个virtual函数，不论是通过pB或pD调用mf， 都会导致调用D::mf，因为pB和pD真正指的都是一个类型为D的对象。

### 37不重新定义继承而来的缺省参数值

对象的所谓静态类型（static type），就是它在程序中被声明时所采用的类型。

```c++
class Shape{
	public:
		enum ShapeColor { Red, Green, Blue }; //所有形状都必须提供一个函数，用来绘出自己
		virtual void draw(ShapeColor color = Red) const = 0; 
};

class Rectangle:public Shape{
	public:
		virtual void draw(ShapeColor color = Green) const; 
};
//注意，赋予不同的缺省参数值。这真糟糕！
class Circle: public Shape{ 
	public:
		virtual void draw(ShapeColor color) const;
		// 请注意，以上这么写则当客户以对象调用此函数，一定要指定参数值，因为静态绑定下这个函数并不从其base继承缺省参数值。
		// 但若以指针（或reference）调用此函数，可以不指定参数值，因为动态绑定下这个函数会从其base继承缺省参数值
}；
    
//现在考虑这些指针：
Shape* ps;//静态类型为Shape＊
Shape* pc = new Circle;//静态类型为Shape＊
Shape* pr = new Rectangle;//静态类型为Shape＊
```

对象的所谓**动态类型（dynamic type）则是指目前所指对象的类型** 。也就是说，动态类型可以表现出一个对象将会有什么行为。以上例而言，pc的动态类型是Circle＊，pr的动态类型是Rectangle＊。ps没有动态类型，因为它尚未指向任何对象。

Virtual 函数系动态绑定而来，意思是**调用一个virtual函数时，究竟调用哪一份函数实现代码，取决于发出调用的那个对象的动态类型**：

```c++
pc->draw(Shape::Red);//调用 Circle::draw（Shape::Red） 
pr->draw(Shape::Red);//调用 Rectangle::draw（Shape::Red）
```

**当你考虑带有缺省参数值的virtual函数，virtual函数是动态绑定，而缺省参数值却是静态绑定**。意思是你可能会在调用一个定义于derived class内的 virtual函数的同时，却使用 base class为它所指定的缺省参数值：

```c++
pr->draw();//调用 Rectangle::draw(Shape::Red)
```

此例之中，pr的动态类型是Rectangle＊，所以调用的是Rectangle的virtual函数，Rectangle::draw 函数的缺省参数值应该是GREEN，但由于pr的静态类型是 Shape＊，所以此一调用的缺省参数值来自 Shape class 而非 Rectangle class！

当你想令 virtual 函数表现出你所想要的行为但却遭遇麻烦，聪明的做法是考虑替代设计，其中之一是NVI手法：令base class内的一个 public non-virtual 函数调用 private virtual 函数，后者可被 derived classes 重新定义。这里我们可以让 non-virtual 函数指定缺省参数，而 private virtual 函数负责真正的工作：

```c++
class Shape{ 
	public:
		enum ShapeColor { Red, Green, Blue }; 
		void draw(ShapeColor color = Red) const//如今它是 non-virtual 
		{ doDraw(color); }//调用一个virtual
	private:
		//真正的工作在此处完成
		virtual void doDraw(ShapeColor color) const ＝ 0； 
};
class Rectangle: public Shape {
	public:
    	...
	private:
		virtual void doDraw (ShapeColor color) const;//注意，不须指定缺省参数值。 
};
```

由于non-virtual 函数应该绝对不被 derived classes覆写（见条款36），这个设计很清楚地使得draw函数的color缺省参数值总是为Red。

**绝对不要重新定义一个继承而来的缺省参数值，因为缺省参数值都是静态绑定，而 virtual 函数-你唯一应该覆写的东西-却是动态绑定。**

### 38通过复合塑模出has-a或根据某物实现出

复合（composition）的意义和public继承完全不同，在应用域，复合意味has-a，在实现域 （implementation domain），复合意味 is-implemented-in-terms-of（根据某物实现出）。

### 39使用private继承

如果classes之间的继承关系是private，编译器不会自动将一个derived class对象转换为一个base class对象

由 private baseclass 继承而来的所有成员，在derived class 中都会变成 private 属性，纵使它们在 base class 中原本是protected或public属性。

Private 继承意味 implemented-in-terms-of （根据某物实现出）。如果你让class D以 private 形式继承 class B，你的用意是为了采用classB内已经备妥的某些特性，不是因为B对象和D对象存在有任何观念上的关系。

尽可能使用复合，必要时（当 protected成员或virtual函数牵扯进来的时候）才使用private继承

```c++
class Widget{ 
	private:
		class WidgetTimer: public Timer{ 
			public:
				virtual void onTick() const;
		};
	WidgetTimer timer;
	...
}；
```

这个设计比只使用 private 继承要复杂一些些，因为它同时涉及public继承和复合，并导入一个新 class，这会使 widget 使它得以拥有 derived classes，但同时会阻止 derived classes 重新定义 onTick。如果widget继承自Timer，上面的想法就不可能实现，即使是private继承也不可能（条款35曾说 derived classes可以重新定义virtual函数，即使它们不得调用它）但如果 widgetTimer是widget内部的一个 private 成员并继承 Timer，Widget 的 derived classes 将无法取用 WidgetTimer，因此无法继承它或重新定义它的virtual函数。



private继承主要用于当一个意欲成为 derived class 者想访问一个意欲成为base class者的protected成分，或为了重新定义一或多个virtual函数。 但这时候两个classes之间的概念关系其实是is-implemented-in-terms-of而非is—a。

然而有一种激进情况涉及空间最优化，可能会促使你选择private继承而不是继承加复合。这个激进情况真是有够激进，只适用于所处理的class不带任何数据时。

这样的 classes 没有 non—static成员变量，没有 virtual 函数（因为这种函数的存在会为每个对象带来一个vptr，见条款7），也没有 virtual base classes（因为这样的 base classes 也会招致体积上的额外开销，见条款40）。于是这种所谓的 empty classes对象不使用任何空间，因为没有任何隶属对象的数据需要存储。

然而由于技术上的理由，**C++裁定凡是独立（非附属）对象都必须有非零大小**，所以如果你这样做：

```c++
class Empty{};//没有数据，所以其对象应该不使用任何内存
class HoldsAnInt{//应该只需要一个int空间
	private:
		int x; 
		Empty e;//应该不需要任何内存
}；
```

你会发现 sizeof(HoldsAnInt) > sizeof(int) 一个Empty成员变量竟然要求内存。

在大多数编译器中 sizeof（Empty）获得1，因为对大小为零之独立（非附属）对象，通常C++官方勒令默默安插一个char到空对象内。然而齐位需求（alignment，见条款50）可能造成编译器为类似 HoldsAnInt 这样的 class 加上一些衬垫（padding），所以有可能HoldsAnInt对象不只获得一个char大小，也许实际上被放大到足够又存放一个int。

但或许你注意到了，我很小心地说独立（非附属）对象的大小一定不为零。也就是说，**这个约束不适用于derived class对象内的base class成分，因为它们并非独立（非附属）**。如果你继承Empty，而不是内含一个那种类型的对象：

```c++
class HoldsAnInt: private Empty{ 
	private:
		int x; 
};
```

几乎可以确定sizeof(HoldsAnInt) == sizeof(int)。这是所谓的EBO（empty base optimization；空白基类最优化），我试过的所有编译器都有这样的结果。如果你是一个程序库开发人员，而你的客户非常在意空间，那么值得注意EBO。

另外还值得知道的是，EBO一般只在单一继承（而非多重继承）下才可行，统治C++对象布局的那些规则通常表示EBO无法被施行于拥有多个base的derived classes 身上。

大多数 classes 并非 empty，所以EBO很少成为private 继承的正当理由。更进一步说，大多数继承相当于is—a，这是指public继承，不是private继承。复合和 private 继承都意味 is-implemented-in-terms-of，但复合比较容易理解，所以无论什么时候，只要可以，你还是应该选择复合。

Private 继承意味 is-implemented-in-terms of（根据某物实现出）。它通常比复合 （composition）的级别低。但是当 derived class 需要访问 protected base class的成员，或需要重新定义继承而来的virtual函数时，这么设计是合理的。和复合（composition）不同，private继承可以造成 empty base 最优化。这对致力于对象尺寸最小化的程序库开发者而言，可能很重要。

### 40使用多重继承

```c++
class BorrowableItem {//图书馆允许你借某些东西
	public:
		void checkout();
};

class ElectronicGadget {
	private:
		bool checkout() const;
};

class MP3Player: public BorrowableItem, public ElectronicGadget {...};

MP3Player mp;
mp.checkOut();//歧义！调用的是哪个 checkOut？
mp.BorrowableItem::checkout();
//为了解决这个歧义，你必须明白指出你要调用哪一个base class内的函数
//可以尝试明确调用 ElectronicGadget::checkout，但会获得一个尝试调用private成员函数的错误。
```

多重继承的意思是继承一个以上的base classes，但这些 base classes并不常在继承体系中又有更高级的base classes：

```c++
class File{...};

class InputFile: public File{...};

class OutputFile: public File {...};

class IOFile: public InputFile, public OutputFile {...};
```

任何时候如果你有一个继承体系而其中某个 base class 和某个 derived class 之间有一条以上的相通路线，你就必须面对这样一个问题：是否打算让 base class 内的成员变量经由每一条路径被复制？假设File class有个成员变量 fileName，那么IOFile内该有多少笔这个名称的数据呢？

从某个角度说，IOFile 从其每一个base class继承一份，所以其对象内应该有两份 fileName成员变量。

但从另一个角度说，简单的逻辑告诉我们，IOFile对象只该有一个文件名称，所以它继承自两个base classes 而来的 fileName不该重复，因此必须令那个带有此数据的class（也就是File）成为一个 virtual base class。

```c++
class File{...};

class InputFile: virtual public File{...};

class OutputFile:virtual public File {...};

class IOFile: public InputFile, public OutputFile {...};
```

为避免继承得来的成员变量重复，编译器必须提供若干幕后戏法，而其后果是：使用 virtual 继承的那些 classes所产生的对象往往比使用non-virtual继承的兄弟们体积大，访问 virtual base classes的成员变量时，也比访问 non—virtual base classes的成员变量速度慢。种种细节因编译器不同而异，但基本重点很清楚：你得为 virtual 继承付出代价。

virtual 继承的成本还包括其他方面。支配virtual base classes 初始化的规则比起 non-virtual bases的情况远为复杂且不直观。virtual base的初始化责任是由继承体系中的最低层（most derived）class负责，这暗示

1. classes 若派生自 virtual bases 而需要初始化，必须认知其 virtual bases—不论那些 bases距离多远，
2. 当一个新的 derived class加入继承体系中，它必须承担其 virtual bases（不论直接或间接） 的初始化责任。

对 virtual base classes（亦相当于对 virtual继承）的忠告很简单。

1. 非必要不使用 virtual bases。平常请使用non-virtual 继承。

2. 如果你必须使用 virtual base classes，尽可能避免在其中放置数据。这么一来你就不需担心这些classes身上的初始化（和赋值）所带来的诡异事情了。


### 41隐式接口和编译期多态

对classes而言接口是显式的，以函数签名为中心，多态（polymorphism）则是通过 virtual 函数发生于运行期。

对 template 参数而言，接口是隐式的，奠基于有效表达式。多态则是通过template具现化和函数重载解析（function overloading resolution）发生于编译期。

以不同的template参数具现化function templates会导致调用不同的函数，这便是所谓的编译期多态

### 42typename的双重意义

template内出现的名称（iter）如果相依于某个template参数（模板参数C），称之为从属名称（dependent names），如果从属名称又嵌套了其它类型（C类型），则称它为嵌套从属名称（nested dependent name）。 

```c++
//注意这不是有效的C＋代码
template<typename C>
void print2nd(const C& container)
{
	if (container.size() >= 2){
	C::const_iterator iter(container.begin());//C::const_iterator嵌套从属类型名称
	int value = *iter;//int非从属名称
	std::cout <<value;
	}
}
```

如果解析器在template中遭遇一个嵌套从属名称，它便假设这名称不是个类型，除非你告诉它是，所以缺省情况下嵌套从属名称不是类型，任何时候当你想要在template中指涉一个嵌套从属类型名称，就必须在紧临它的前一个位置放上关键字 typename

```c++
//typename只被用来验明嵌套从属类型名称；其他名称不该有它存在
template<typename C>//允许使用typename或class
void f(const C& container,//不允许使用typename
		typename C::iterator iter);//一定要使用typename
```

上述的C并不是嵌套从属类型名称（它并非嵌套于任何取决于template参数的东西内），所以声明container时并不需要以typename为前导，但C::iterator是个嵌套从属类型名称，所以必须以typename为前导。

typename 必须作为嵌套从属类型名称的前缀词这一规则的例外是，typename 不可以出现在 base classes list 内的嵌套从属类型名称之前，也不可在 member initialization list（成员初值列）中作为 base class 修饰符

```c++
template<typename T>//base class list中不允许 typename
class Derived: public Base<T>::Nested {
	public:
		explicit Derived(int x):Base<T>::Nested(x)//mem.init.list中不允许typename
	{ 
		typename Base<T>::Nested temp;//既不在base class list中也不在mem.init.list中，作为一个base class修饰符需加上 typename
	}
}；
```

```c++
template<typename IterT>
void workWithIterator(IterT iter) {
	typedef typename 
	std::iterator_traits<IterT>::value_type value_type;
    // 由于std::iterator_traits<IterT>::value_type是个嵌套从属类型名称:
    // value＿type被嵌套于iterator_traits<IterT>::value_type之内, 而IterT是个template参数
	value_type temp(*iter);
}
```

### 43处理模板化基类内的名称

```c++
template<typename Company>
class LoggingMsgSender: public MsgSender<Company> { 
	public:
		void sendClearMsg(const MsgInfo& info) {
            //将“传送前”的信息写至log；
            sendClear(info);//调用base class函数；这段码无法通过编译
            //将“传送后”的信息写至log；
		} 
};
```

基类模板可能会因为参数的特定要求而改变其内容，这时候便要模板全特化，而全特化版本这时候可能就不会提供一般性的接口，因此在派生类模板内是不会去寻找寻找继承而来的名称，这个名称由于全特化很可能不存在，那索性一开始就不找了

那就是为什么C++拒绝这个调用的原因：它知道 base class templates有可能被特化，而那个特化版本可能不提供和一般性 template 相同的接口。因此它往往拒绝在templatized base classes（本例的 MsgSender<Company>）作用域内寻找继承而来的名称（本例的SendClear）。

```c++
this->sendClear(info);//在 base class 函数调用动作之前加上this->
using MsgSender<Company>::sendClear;//告诉编译器，请它假设sendClear位于base class内
MsgSender<Company>::sendClear(info);//明白指出被调用的函数位于base class内，但这往往是最不让人满意的一个解法，因为如果被调用的是virtual函数，上述的明确资格修饰（explicit qualification）会关闭virtual绑定行为
```

从名称可视点（visibility point）的角度出发，上述每一个解法做的事情都相同：对编译器承诺base class template的任何特化版本都将支持其一般（泛化）版本所提供的接口。

### 44将与参数无关的代码抽离templates

因类型参数（type parameters）而造成的代码膨胀，往往可降低，做法是让带有完全相同二进制表述（binary representations）的具现类型（instantiation types） 共享实现码

因非类型模板参数（non-type template parameters）而造成的代码膨胀，往往可消除，做法是以函数参数或class成员变量替换 template 参数

```c++
template<typename T, std::size_t n>
class SquareMatrix{
	public:
		void invert();//求逆矩阵 
};
SquareMatrix<double, 5> sml; 
sm1.invert();//调用SquareMatrix<double, 5>::invert

SquareMatrix<double, 10> sm2;
sm2.invert();//调用SquareMatrix<double, 10>::invert

//以函数参数替换template参数
template<typename T>
class SquareMatrixBase {
	protected:
		void invert(std::size_t matrixSize);//以给定的尺寸求逆矩阵
};

template<typename T, std::size_t n>
class SquareMatrix: private SquareMatrixBase<T> { 
	private:
		using SquareMatrixBase<T>::invert;//避免遮掩base版的invert, 见条款33 
	public:
		void invert() { this->invert(n); }//制造一个inline 调用，调用base class版的 invert
};

//以class成员变量替换template参数
template<typename T> class SquareMatrixBase{ 
	protected:
		SquareMatrixBase (std::size_t n, T* pMem)//存储矩阵大小和一个指针，指向矩阵数值
		:size(n), pData(pMem) {}
		void setDataPtr(T* ptr) { pData = ptr;}//重新赋值给pData
	private:
		std::size_t size;
		T* pData;//指针，指向矩阵内容
};

template<typename T, std::size_t n>
class SquareMatrix: private SquareMatrixBase<T> { 
	public:
		SquareMatrix():SquareMatrixBase<T>(n, data){}//送出矩阵大小和数据指针给base class
	private:
		T data[n * n]; 
};

template<typename T, std::size_t n>
class SquareMatrix: private SquareMatrixBase<T>{ 
	public:
		SquareMatrix():SquareMatrixBase<T>(n, 0), pData(new T[n*n])
         { this->setDataPtr(pData.get()); }
		//将base class的数据指针设为null为矩阵内容分配内存
		//将指向该内存的指针存储起来，然后将它的一个副本交给base class 
    private:
		boost::scoped_array<T> pData;//关于boost::scoped＿array见条款13。
};
```

### 45运用成员函数模板接受所有兼容类型

```c++
template<typename T>
class SmartPtr{ 
	public:
		template<typename U>
    	//这个行为只有当存在某个隐式转换可将一个U*指针转为一个T*指针时才能通过编译
		SmartPtr(const SmartPtr<U>& other):heldPtr(other.get()){...}
		T* get() const { return heldPtr;}
	private: 
		T* heldPtr;//这个SmartPtr持有的内置（原始）指针
};
```

泛化（generalized）copy构造函数：并未被声明为explicit，因为原始指针类型之间的转换（例如从 derived class指针转为base class指针）是隐式转换，无需明白写出转型动作（cast），我们希望根据一个 SmartPtr<Bottom>创建一个SmartPtr<Top>，却不希望根据一个SmartPtr<Top>创建一个SmartPtr<Bottom>， 因为那对 public 继承而言是矛盾的。我们也不希望根据一个SmartPtr<double>创建一个 SmartPtr<int>，因为现实中并没有将 int* 转换为 double* 的对应隐式转换行为，必须从某方面对这一member template所创建的成员函数群进行拣选或筛除。

如果你声明 member templates 用于泛化copy构造或泛化 assignment操作， 你还是需要声明正常的copy构造函数和 copy assignment操作符

```c++
template<class T> 
class shared_ptr{ 
	public:
		shared_ptr(shared_ptr const& r);//copy构造函数
		template<class Y>//泛化copy构造函数
		shared_ptr(shared_ptr<Y> const& r);
		
		shared_ptr& operator=(shared_ptr const& r);//copy assignment
		
		template<class Y>//泛化 copy assignment
		shared_ptr& operator=(shared_ptr<Y> const& r);
};
```

### 46需要类型转换时为模板定义非成员函数

在能够调用一个函数之前，首先必须知道那个函数存在。而为了知道它，必须先为相关的function template推导出参数类型（然后才可将适当的函数具现化出来），但在template实参推导过程中从不将隐式类型转换函数纳入考虑，虽然传递给 operator* 的第一实参（oneHalf）的类型是 Rational<int>，可以推导出T一定是int，但第二实参2却无法推导出T是int

```c++
template<typename T> class Rational{ 
	public:
        Rational(const T& numerator = 0,
        const T& denominator = 1);
        const T numerator() const;
        T denominator() const;
};

template<typename T>
const Rational<T> operator* (const Rational<T>& lhs, const Rational<T>& rhs) {...}

Rational<int> oneHalf(1, 2);
Rational<int> result = oneHalf * 2;//错误！无法通过编译。
```

Class templates 并不倚赖 template 实参推导（只施行于function templates身上），所以编译器总是能够在 class Rational<T>具现化时得知T，这意味着当对象 oneHalf 被声明为一个Rational<int>，class Rational<int>于是被具现化出来，而作为过程的一部分，friend函数 operator*（接受Rational<int>参数）也就被自动声明出来。 后者身为一个函数而非函数模板（function template），因此编译器可在调用它时使用隐式转换函数（例如Rational的non-explicit构造函数），而这便是混合式调用之所以成功的原因。

但目前还有一个问题：那个函数只被声明于Rational内，并没有被定义出来。我们意图在class外提供定义式，但是行不通，为了令这个函数被自动具现化，我们需要将它声明在class内部

```c++
template<typename T>
class Rational{ 
	public:
		friend const Rational operator*(const Rational& lhs, const Rational& rhs) {
			return Rational(lhs.numerator() * rhs.numerator(), lhs.denominator() * rhs.denominator());
		}
};
```

当我们编写一个 class template，而它所提供与此 template 相关的函数支持所有参数隐式类型转换时，请将那些函数定义为class template 内部的friend函数。

### 47使用traits classes表现类型信息

Traits是一种技术，这个技术的要求之一是，它对内置（built-in）类型和用户自定义（user-defined）类型的表现必须一样好，作用是允许你在编译期间取得某些类型信息。

iterator_traits的运作方式是，针对每一个类型IterT，在struct iterator_traits<IterT>内一定声明某个 typedef 名为 iterator_category。这个 typedef 用来确认IterT的迭代器分类。

iterator_traits 以两个部分实现上述所言。它要求每一个用户自定义的迭代器类型必须嵌套一个typedef，名为 iterator_category，用来确认适当的卷标结构（tag struct）。为了支持指针迭代器，iterator_traits 特别针对指针类型提供一个偏特化版本。由于指针的行径与 random access 迭代器类似，所以iterator_traits为指针指定的迭代器类型是：

```c++
template<...>//略而未写template 参数 
class deque{
	public:
		class iterator{ 
			public:
				typedef random_access_iterator_tag iterator_category;
};

template<typename IterT> 
struct iterator_traits {
	typedef typename IterT::iterator_category iterator_category; 
};

template<typename IterT>//template 偏特化 针对内置指针 
struct iterator_traits<IterT*> {
	typedef random_access_iterator_tag iterator_category; 
};
```

IterT类型在编译期间获知，所以iterator_traits<IterT>::iterator_category也可在编译期间确定，为了在编译期对类型执 if...else测试，需要有doAdvance重载版本，advance需要做的只是调用它们并额外传递一个对象，后者必须带有适当的迭代器分类。于是编译器运用重载解析机制（overloading resolution）调用适当的实现代码

```c++
template<typename IterT, typename DistT>
void doAdvance(IterT& iter, DistT d, std::random_access_iterator_tag){
	iter += d; 
}

template<typename IterT, typename DistT>
void doAdvance(IterT& iter, DistT d, std::bidirectional_iterator_tag){
	if (d >= 0) { while (d--) ++iter;}
    else{ while (d++) --iter;} 
}

template<typename IterT, typename DistT> 
void advance(IterT& iter, DistT d) {
	doAdvance(iter, d, typename std::iterator_traits<IterT>::iterator_category());
}
```

### 48template元编程

Template metaprogramming（TMP，模板元编程）是编写 template-based C++程序并执行于编译期的过程。所谓 template metaprogram（模板元程序）是以C++写成、执行于C++编译器内的程序。一旦TMP程序结束执行，其输出，也就是从templates具现出来的若干C++源码，便会一如往常地被编译。

```c++
template<unsigned n>
struct Factorial{
	enum { value = n * Factorial<n - 1>::value};
}; 
template<>
struct Factorial<0>{
	enum{ value = 1};
};
int main() {
	std::cout<<Factorial<5>::value;//印出120 
	std::cout<<Factorial<10>::value;//印出3628800
}
```

### 49new-handler的行为

当operator new无法满足内存申请时，它会不断调用new-handler函数，直到找到足够内存。一个设计良好的new-handler函数必须做以下事情：

- 让更多内存可被使用。这便造成 operatornew内的下一次内存分配动作可能成功。实现此策略的一个做法是，程序一开始执行就分配一大块内存，而后当new-handler 第一次被调用，将它们释还给程序使用。
- 安装另一个 new-handler。如果目前这个 new-handler无法取得更多可用内存，或许它知道另外哪个 new-handler 有此能力。果真如此，目前这个 new-handler就可以安装另外那个 new-handler 以替换自己（只要调用 set_new_handler）。 下次当 operator new 调用 new-handler，调用的将是最新安装的那个。（这个旋律的变奏之一是让 new-handler修改自己的行为，于是当它下次被调用，就会做某些不同的事。为达此目的，做法之一是令 new-handler 修改会影响new-handler行为的static数据、namespace 数据或global数据。）
- 卸除 new-handler，也就是将null指针传给 set_new_handler。一旦没有安装任何new-handler， operator new会在内存分配不成功时抛出异常。
- 抛出bad_alioc（或派生自bad_alloc）的异常。这样的异常不会被operator new捕捉，因此会被传播到内存索求处。
- 不返回，通常调用abort或exit。




有时候你或许希望以不同的方式处理内存分配失败情况，你希望视被分配物属于哪个class而定：

```c++
class X{ 
	public:
	static void outofMemory(); 
};

class Y{ 
	public:
	static void outofMemory(); 
};

X* p1 = new X;//如果分配不成功，调用x::outOfMemory 
Y* p2 = new Y;//如果分配不成功，调用Y::outOfMemory
```

**C＋＋并不支持 class 专属之 new-handlers**，但其实也不需要。你可以自己实现出这种行为。

只需令每一个 class 提供自己的 set_new_handler和 operator new 即可。**其中 set_new_handler 使客户得以指定 class 专属的 new-handler**，至于 **operator new 则确保在分配 class 对象内存的过程中以 class 专属的 new-handler 替换 global new-handler。**

现在，假设你打算处理 widget class的内存分配失败情况。首先你必须能够访问当operator new无法为一个widget对象分配足够内存时调用的函数，所以你需要声明一个类型为new_handler的static成员，用以指向 classWidget的new-handler：

```c++
class Widget{ 
	public:
		static std::new_handler set_new_handler (std:::new_handler p) throw(); 	
         static void* operator new(std::size_t size) throw(std::bad_alloc); 
	private:
		static std::new_handler currentHandler; 
};

//Static成员必须在class定义式之外被定义（除非它们是const而且是整数型，见条款2）
std::new_handler Widget::currentHandler = 0;//在class实现文件内初始化为nu11

class NewHandlerHolder{ 
	public:
    	//取得目前的new handler
		explicit NewHandlerHolder(std::new_handler nh):handler(nh){}
         //将Widget的operator new被调用前的那个global new-handler恢复回来。
		~NewHandlerHolder(){ 
            std::set_new_handler(handler);
         }
	private:
		std::new_handler handler;//记录下来
		NewHandlerHolder(const NewHandlerHolder&);//阻止 copying（见条款14）
		NewHandlerHolder& operator=(const NewHandlerHolder&);
}

//Widget内的set_new_handler函数会将它获得的指针存储起来，然后返回先前（在此调用之前）存储的指针
//这也正是标准版set_new_handler的作为：
std::new_handler Widget::set_new_handler (std::new_handler p) throw() {
	std::new_handler oldHandler = currentHandler; 
	//此前调用的new_handler就是类内声明的
	currentHandler = p;//现在调用的new_handler就是传入的参数
	return oldHandler; //返回此前调用的new_handler
}

void* Widget::operator new(std::size_t size) throw(std::bad_alloc) {
	NewHandlerHolder h(std::set_new_handler(currentHandler));
	//安装Widget的 new-handler，这个new-handler开始处理之前分配不成功的情况
    //global operator new会调用widget的new-handler，即刚才安装的这个
	return ::operator new(size);//先恢复global new-handler，然后分配内存或抛出异常
    //分配内存的动作始终是由operator new实现的，而不是Widget::operator new
    //是Widget::operator new中调用了operator new得以实现了分配内存
    //抛出异常则是由Widget::operator new实现的
}

//Widget的客户应该类似这样使用其new-handling：
void outOfMem();//函数声明。此函数在Widget对象分配失败时被调用
Widget::set_new_handler(outOfMem);//设定outOfMem为Widget的new-handling函数
Widget* pw1 = new Widget;//如果内存分配失败，调用outOfMem 
std::string* ps = new std::string;//如果内存分配失败，调用global new-handling 函数（如果有的话）.
Widget::set_new_handler(0);//设定Widget 专属的new-handling 函数为null
Widget* pw2 = new widget;//如果内存分配失败，立刻抛出异常.因为class Widget 并没有专属的new-handling函数
```

widget的 operator new 内存分配失败时做以下事情：

1. 先调用的是标准 set_new_handler，告知Widget的错误处理函数。这会将widget的 new-handler 安装为 global new-handler。（也就是**先进行标准的再进行类专属的**）

2. 调用 global operator new，执行实际之内存分配。

3. 如果global operator new分配失败，global operator new会调用widget的new-handler，然后会抛出一个 bad_alloc异常，在此情况下 widget 的 operator new 要恢复原本的 global new-handler，然后再传播该异常。。

   如果global operator new无法分配足够内存，为确保原本的new-handler总是能够被重新安装回去，widget将 global new-handler 视为资源并遵守条款13的忠告，运用资源管理对象（resource-managing objects）防止资源泄漏。

4. 如果 global operator new分配成功，Widget的 operator new 会返回一个指针，指向分配所得。Widget 析构函数会管理global new-handler，它会自动将Widget的operator new被调用前的那个global new-handler 恢复回来。

实现这一方案的代码并不因class的不同而不同，因此在它处加以复用是个合理的构想。一个简单的做法是建立起一个mixin风格的 base class，这种 base class 用来允许 derived classes 继承单一特定能力，这个设计的base class 部分让 derived classes 继承它们所需的set_new_handler 和 operator new，而 template 部分则确保每一个 derived class获得一个实体互异的 currentHandler 成员变量

```c++
template<typename T>//mixin风格的base class，用以支持 class 专属的set_new_handler
class NewHandlerSupport{
	public:
		static std::new_handler set_new_handler (std::new_handler p) throw(); 
		static void* operator new(std::size_t size) throw(std::bad_alloc);
	private:
		static std::new_handler currentHandler; 
};

//set_new_handler定义部分
template<typename T> 
std::new_handler
NewHandlerSupport<T>::set_new_handler (std::new_handler p) throw() {
	std::new_handler oldHandler = currentHandler; 
	currentHandler = p;
	return oldHandler; 
}
//new定义部分
template<typename T>
void* NewHandlerSupport<T>::operator new(std::size_t size) throw(std::bad_alloc)
{
	NewHandlerHolder h(std::set_new_handler(currentHandler)); 
	return::operator new(size);
}

//以下将每一个 currentHandler 初始化为null 
template<typename T>
std::new_handler NewHandlerSupport<T>::currentHandler = 0;

class Widget: public NewHandlerSupport<Widget>{
	...
};
//和先前一样，但不必声明set_new_handler或operator new
```

直至1993年，C＋＋都还要求 operator new 必须在无法分配足够内存时返回null。新一代的operator new则应该抛出 bad_alloc异常，但很多C＋＋程序是在编译器开始支持新修规范前写出来的。C＋＋标准委员会不想抛弃那些侦测null的族群，于是提供另一形式的 operator new，负责供应传统的分配失败便返回null行为。这个形式被称为nothrow形式—某种程度上是因为他们在new的使用场合用了nothrow对象（定义于头文件＜new＞）：

```c++
class Widget{...}; 
Widget* pw1 = new Widget;//如果分配失败，抛出bad_alloc.
if(pw1 == 0)...//这个测试一定失败.
Widget* pw2 = new (std::nothrow) Widget;//如果分配Widget失败，返回0．
if(pw2 == 0)...//这个测试可能成功
```

nothrow new 对异常的强制保证性并不高。

表达式new（std::nothrow）Widget发生两件事，第一，nothrow 版的 operator new 被调用，用以分配足够内存给widget对象。如果分配失败便返回null指针，一如文档所言。如果分配成功，接下来 widget 构造函数会被调用，而在那一点上所有的筹码便都耗尽，因为Widget 构造函数可以做它想做的任何事。它有可能又new一些内存，而没人可以强迫它再次使用 nothrow new。

因此虽然new（std::nothrow）Widget调用的operator new并不抛掷异常，但Widget构造函数却可能会。如果它真那么做，该异常会一如往常地传播。结论就是：使用 nothrow new 只能保证operator new不抛掷异常，不保证像 new （std::nothrow）Widget这样的表达式绝不导致异常。因此你其实没有运用 nothrow new的需要。

### 51编写new和delete时需固守常规

C++规定，即使客户要求0bytes，operator new也得返回一个合法指针

```c++
// 下面是 non-member operator new的伪码
void* operator new(std::size_t size) throw(std::bad_alloc) {
	if (size == 0) {//处理0—byte 申请．
		size = 1;//将它视为1—byte申请．
	}
	while(true){
		// 尝试分配 size bytes	
		if（分配成功）return（一个指针，指向分配得来的内存）;
		// 分配失败, 找出目前的new—handling函数
		new_handler globalHandler = set_new_handler(0); 
		set_new_handler(globalHandler);
		
		if (globalHandler) (*globalHandler)(); 
		else throw std::bad_alloc();
	}
}
// 针对classx而设计的 operator new，其行为很典型地只为大小刚好为 sizeof（X）的对象而设计。
// 然而一旦被继承下去，有可能base class的 operator new被调用用以分配 derived class 对象
class Base{
	public:
		static void* operator new(std::size_t size) throw(std::bad_alloc); 
};
class Derived：public Base {...};//假设Derived未声明operator new 
Derived＊ p ＝ new Derived； //这里调用的是 Base::operator new    
// 如果 Base class 专属的 operator new并非被设计用来对付上述情况（实际上往往如此）
// 处理此情势的最佳做法是将内存申请量错误的调用行为改采标准operator new    
void* Base::operator new(std::size_t size) throw(std::bad_alloc) {
	if (size != sizeof(Base))//如果大小错误，
		return ::operator new（size）；//令标准的operator new起而处理。
	...//否则在这里处理。
}   
```

 C++保证删除null指针永远安全，所以你必须兑现这项保证。

```c++
// 下面是 non-member operator delete的伪码
void operator delete(void* rawMemory) throw()
{
	if (rawMemory == 0) return;//如果将被删除的是个null指针，那就什么都不做。
	// 现在，归还rawMemory所指的内存；
}
// 万一你的class专属的operator new将大小有误的分配行为转交::operator new执行
// 你也必须将大小有误的删除行为转交::operator delete执行：
class Base {
	public:
	static void operator delete(void* rawMemory, std::size_t size) throw(); 
};

void Base::operator delete (void* rawMemory, std::size_t size) throw() {
	if (rawMemory == 0) return;//检查null指针。
	if (size != sizeof(Base)){//如果大小错误，令标准版operator delete 处理此一申请。
		return::operator delete(rawMemory);
	}
	// 现在，归还rawMemory所指的内存 return;
}
```

如果即将被删除的对象派生自某个base class而后者欠缺 virtual 析构函数，那么C++传给 operator delete的size_t数值可能不正确。这是让你的base classes 拥有 virtual 析构函数的一个够好的理由，如果你的 base classes 遗漏 virtual析构函数，operator delete可能无法正确运作。

### 52placement new与placement delete

如果 operator new 接受的参数除了一定会有的那个size_t之外还有其他，这便是个所谓的 placement new

```c++
void* operator new(std::size_t, void* pMemory) throw();//placement new, 接受一个指针指向对象该被构造之处
```

如果一个带额外参数的 operator new 没有带相同额外参数的对应版 operator delete，那么当new的内存分配动作需要取消并恢复旧观时就没有任何 operator delete 会被调用。

```c++
class Widget{ 
	public:
	static void* operator new(std::size_t size, std::ostream& logStream) throw(std::bad_alloc);
	static void operator delete(void* pMemory) throw();
	static void operator delete (void* pMemory, std::ostream& logStream) throw();
};

//这样改变之后，如果以下语句引发Widget 构造函数抛出异常
Widget* pw = new (std::cerr) Widget;
//这次不再泄漏, 对应的placement delete会被自动调用，让widget有机会确保不泄漏任何内存。

//然而如果没有抛出异常（通常如此），而客户代码中有个对应的 delete，会发生什么事：
delete pw;//调用正常的 operator delete
```

placement delete只有在伴随 placement new 调用而触发的构造函数出现异常时才会被调用。对着一个指的pw）施行 delete绝不会导致调用placement delete。

这意味如果要对所有与 placement new相关的内存泄漏宣战，我们必须同时提供一个正常的operator delete（用于构造期间无任何异常被抛出）和一个placement版本（用于构造期间有异常被抛出后者的额外参数必须和operator new一样。



由于成员函数的名称会掩盖其外围作用域中的相同名称，必须小心避免让class专属的news掩盖客户期望的其他news（包括正常版本）。

```c++
class Base{ 
	public:
		static void* operator new(std::size_t size,std::ostream& logStream) throw(std::bad_a11oc);
		//这个new会遮掩正常的global 形式
};
Base* pb = new Base;
//错误！因为正常形式的operator new 被掩盖.

Base* pb = new (std::cerr) Base;
//正确，调用Base的placement new. 

//同样道理，derived classes中的operator news会掩盖global版本和继承而得的operator new版本：
class Derived: public Base{//继承自先前的Base
    public:
        static void* operator new（std::size＿t size）//重新声明正常形式的new
        throw(std::bad_alloc);
};

Derived* pd = new(std::clog) Derived;//错误！因为Base的placement new 被掩盖了。 
Derived* pd = new Derived;//没问题，调用Derived的operator new.
```

对于撰写内存分配函数，你需要记住的是，缺省情况下C＋＋在global作用域内提供以下形式的operator new：

```c++
void* operator new(std::size_t) throw(std::bad_alloc); //normal new. 
void* operator new(std::size_t, void*) throw();//placement new. 
void* operator new(std::size_t, const std::nothrow＿t＆）throw（）；//nothrow new
```

如果你在class 内声明任何operator news，它会遮掩上述这些标准形式。除非你的意思就是要阻止class的客户使用这些形式，否则请确保它们在你所生成的任何定制型 operator new之外还可用。对于每一个可用的operator new也请确定提供对应的 operator delete。如果你希望这些函数有着平常的行为，只要令你的class 专属版本调用global版本即可。

完成以上所言的一个简单做法是，建立一个 base class，内含所有正常形式的new和delete：

```c++
class StandardNewDeleteForms{ 
	public:
		//normal new/delete
		static void* operator new(std::size_t size) throw(std::bad_alloc) { 
			return ::operator new(size); 
		}

		static void operator delete(void* pMemory) throw() {
			return ::operator delete(pMemory);
		}
    
		//placement new/delete
		static void* operator new(std::size_t size, void* ptr) throw() { 
			return ::operator new(size, ptr); 
		}

		static void operator delete(void* pMemory, void* ptr) throw() { 
			return ::operator delete (pMemory, ptr);
		}

		// nothrow new/delete
		static void* operator new(std::size_t size, const std::nothrow_t& nt) throw 		
        { return ::operator new(size, nt);}

		static void operator delete(void *pMemory,const std::nothrow_t&) throw() 
		{ return ::operator delete(pMemory); }

};

//凡是想以自定形式扩充标准形式的客户，可利用继承机制及using声明式（见条款33）取得标准形式：
class Widget:public StandardNewDeleteForms(//继承标准形式 
	public:
		//让这些形式可见 
		using StandardNewDeleteForms::operator new
		using StandardNewDeleteForms::operator delete;
		
		//添加一个自定的placement new
		static void* operator new(std::size_t size,std::ostream& logStream)
		throw(std::bad_alloc);
		
		//添加一个对应的placement delete 
		static void operator delete(void* pMemory,std::ostream& logStream) throw();
}; 
```

