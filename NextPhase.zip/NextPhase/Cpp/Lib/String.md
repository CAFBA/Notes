# Dynamic String
## C-Style Strings
字符串字面值是一种通用结构的实例，这种结构即 `C++` 由 `C` 继承而来的 `C` 风格字符串。按此习惯书写的字符串存放在字符数组中并以空字符结束。
![image-20221007194110920](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221007194110920.png)
比较标准库 `string` 对象的时候，用的是普通的关系运算符和相等性运算符，如果把这些运算符用在两个 `C` 风格字符串上，实际比较的将是指针而非字符串本身：
```c
const char cal[] = "A string example"; 
const char ca2[] = "A different string"; 
if (cal < ca2) // 未定义的：试图比较两个无关地址
```
当使用数组的时候其实真正用的是指向数组首元素的指针。因此，上面的条件实际上比较的是两个 `const char*` 的值。这两个指针指向的并非同一对象，所以将得到未定义的结果。 
要想比较两个 `C` 风格字符串需要调用 `strcmp` 函数，此时比较的就不再是指针。如果两个字符串相等，`strcmp` 返回 0，如果前面的字符串较大，返回正值；如果后面的字符串较大，返回负值。
如果为一个由几个其他字符串构成的字符串分配空间，应该使用 `strcat` 函数和 `strcpy` 函数，还必须提供一个用于存放结果字符串的数组，该数组必须足够大以便容纳下结果字符串及末尾的空字符。
```cpp
char* appendStrings(const char* str1, const char* str2, const char* str3)
{
    char* result { new char[strlen(str1) + strlen(str2) + strlen(str3) + 1] };
    strcpy(result, str1);
    strcat(result, str2);
    strcat(result, str3);
    return result;
}
```
`sizeof` 操作符可用于获得给定数据类型或变量的大小。但在 `C` 风格的字符串中，它根据 `C` 风格的字符串的存储方式来返回不同大小。如果 `C` 风格的字符串存储为 `char[]`, 则 `sizeof` 返回字符串使用的实际内存，包括 `\0` 字符。但是，如果 `C` 风格的字符串存储为 `char*`，`sizeof` 就返回指针的大小。
```cpp
char text1[] { "abcdef" };
size_t s1 { sizeof(text1) }; // is 7
size_t s2 { strlen(text1) }; // is 6

const char* text2 { "abcdef" };
size_t s3 { sizeof(text2) }; // is platform-dependent
size_t s4 { strlen(text2) }; // is 6
```
混用string对象和C风格字符串：
- 允许使用字符串字面值来初始化string对象，更一般的情况是，任何出现字符串字面值的地方都可以用以空字符结束的字符数组来替代。
- 允许使用以空字符结束的字符数组来初始化string对象或为string对象赋值。
- 在string对象的加法运算中允许使用以空字符结束的字符数组作为其中一个运算对象（不能两个运算对象都是）；在string对象的复合赋值运算中允许使用以空字符结束的字符数组作为右侧的运算对象。 
上述性质反过来就不成立了：如果程序的某处需要一个C风格字符串，无法直接用string对象来代替它。例如，不能用string对象直接初始化指向字符的指针。为了完成该功能，string专门提供了一个名为c_str的成员函数：
```c
char *str = s；                    // 错误, 不能用string对象初始化 
const char *str = s.c_str();       // 正确
```
c_str函数的返回值是一个C风格的字符串。也就是说，函数的返回结果是一个指针，该指针指向一个以空字符结束的字符数组，而这个数组所存的数据恰好与那个string对象的一样。结果指针的类型是const char＊，从而确保不会改变字符数组的内容。
```c++
char c[20];
string s ="1234";
strcpy(c, s.c_str());
// c_str函数的返回值是const char*，不能直接赋值给char*，需要通过strcpy函数转化
```
无法保证c_str函数返回的数组一直有效，事实上，如果后续的操作改变了s的值就可能让之前返回的数组失去效用。
> 在string转换C字符串的时候，需要注意c_str()与data()的区别，两个函数都返回const char\*指针，但c_str()会在末尾添加一个`'\0'`
## String Literals
字符串字面量实际上存储在内存的只读部分。通过这种方式，编译器可重用相同字符串字面量的引用，从而优化内存的使用。也就是说，即使一个程序使用了 500 次 `hello` 字符串字面量， 编译器也只在内存中创建一个 `hello` 实例，这种技术称为字面量池。
字符串字面量可赋值给变量，但因为字符串字面量位于内存的只读部分，且使用字面量池，所以这样做会产生风险。C++ 标准正式指出：字符串字面量的类型为 `n` 个 `const char` 的数组，然而为了向后兼容较老的不支持 `const` 的代码，大部分编译器不会强制程序将字符串字面量赋值给 `const char*` 类型的变量。这些编译器允许将字符串字面量赋值给 `non-const char*`，而且整个程序可正常运行, 除非试图修改字符串。
一般情况下，试图修改字符串字面量的行为是没有定义的。一种更安全的编码方法是在引用字符串常量时，使用指向 `const` 字符的指针。
还可将字符串字面量用作字符数组的初始值。这种情况下，编译器会创建一个足以放下这个字符串的数组，然后将字符串复制到这个数组。因此，编译器不会将字面量放在只读的内存中，也不会进行字面量池的操作。
### Raw String Literals
#cpp11
原始字符串字面量是可横跨多行代码的字符串字面量，其中转义序列不按照转义序列的方式处理，而是按照普通文本的方式处理。原始字符串字面量形式如下：
```c++
auto str1 = R"(char""'')";    // 原样输出：char""''
auto str2 = R"(\r\n\t\")";    // 原样输出：\r\n\t\"
auto str3 = R"(\\\$)";        // 原样输出：\\\$
auto str4 = "\\\\\\$";        // 转义后输出：\\\$
```
因为原始字符串字面量以 `)"` 结尾，所以使用这种语法时，不能在字符串中嵌入 `)"`。如果需要嵌入 `)"` ，则需要使用扩展的原始字符串字面量语法，如下所示：
```cpp
const char* str { R"(Embedded )" characters)" }; // Error!
// R"d-char-sequence(r-char-sequence)d-char-sequence"
const char* str { R"-(Embedded )" characters)-" };
auto str5 = R"==(R"(xxx)")==";// 原样输出：R"(xxx)"
```
`r-char-sequence` 是实际的原始字符串。`d-char-sequence` 是可选的分隔符序列，原始字符串首尾的分隔符序列应该一致。分隔符序列最多能有 16 个字符，应选择未出现在原始字符串字面量中的序列作为分隔符序列。
### string Literals
#cpp14
`C++14` 为方便使用字符串，新增了一个字面量的后缀 `s`，明确地表示它是 `string` 字符串类型，而不是 `C` 字符串，这就可以利用 `auto` 来自动类型推导，而且在其他用到字符串的地方，也可以省去声明临时字符串变量的麻烦。
为避免与用户自定义字面量的冲突，后缀 `s` 不能直接使用，必须用 `using` 指定命名空间：
```c++
using namespace std::literals::string_literals;  
auto str = "std string"s;      // 后缀s，表示是标准字符串，直接类型推导
assert("time"s.size() == 4);   // 标准字符串可以直接调用成员函数
```
# String
## Initialize
![image-20221007195512991](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221007195512991.png)
```c++
char alls[] = "All's well that ends well";
string five(alls, 20);              // ctor #5
// 构造函数将一个C-风格字符串和一个整数作为参数，其中的整数参数表示要复制多少个字符
// 如果字符数超过了C-风格字符串的长度，仍将复制请求数目的字符
// 即构造函数将内存中位于字符串“All's well that ends well”后面的内容作为字符

string six(alls + 6, alls + 10);     // ctor #6
// 构造函数将使用begin和end指向的位置之间的值，对string对象进行初始化

string seven(&five[6], &five[10]);   // ctor #6 again
// five[6]是一个char值，所以&five[6]是一个地址，因此可被用作该构造函数的一个参数。

string eight(four, 7, 16);           // ctor #7
// 将一个string对象的部分内容复制到构造的对象中，从four的第8个字符（位置7）开始，将16个字符复制到eight中
```
## size_type
`size_type` 是一个无符号类型的值而且能足够存放下任何 `string` 对象的大小。所有用于存放 `string` 类的 `size` 函数返回值的变量，都应该是 `string::size_type` 类型的。
由于 `size` 函数返回的是一个无符号整型数，因此如果在表达式中混用带符号数和无符号数将可能产生意想不到的结果。例如，假设 `n` 是一个具有负值的 `int`，则表达式 `s.size()<n` 的判断结果几乎肯定是 `true`。这是因为负值 `n` 会自动地转换成一个比较大的无符号值。
## Func
```cpp
// 元素访问     
at
front
back
data
c_str
operator basic_string_view

// 容量
empty
size
length
max_size
reserve
capacity
shrink_to_fit

// 操作
clear
insert
insert_range
erase
push_back 
pop_back 
append
append_range 
operator+=
compare
starts_with 
ends_with
contains
replace
replace_with_range
substr
copy 
resize
resize_and_overwrite
swap

// 查找
find
rfind
find_first_of      // 查找参数中任何一个字符首次出现的位置
find_last_of       // 查找最后一次出现的位置
find_first_not_of  // 查找第一个不包含在参数中的字符的位置
find_last_not_of   // 查找最后一个不包含在参数中的字符的位置（返回的是正向位置）
```
### IO
在使用 `cin` 执行读取操作时，`string` 对象会自动忽略开头的空白（即空格符、换行符、制表符等）并从第一个真正的字符开始读起，直到遇见下一处空白为止。
```c++
string x;
cin >> x; //     hello   world
cout << x << endl; // hello
```
`getline` 函数的参数是一个输入流和一个 `string` 对象，函数从给定的输入流中读入内容，直到遇到换行符为止（换行符也被读取），然后把所读的内容存入到 `string` 对象中去，但不存换行符。`getline` 只要一遇到换行符就结束读取操作并返回结果，如果输入一开始就是换行符，那么所得的结果是个空 `string`。和输入运算符一样，`getline` 也会返回它的流参数，也能用 `getline` 的结果作为条件。
```c++
// 有一个可选参数，用于指定使用哪个字符来确定输入的边界
getline(cin, s, ':');    //read up to :  discard :

// 输出字符串，自动换行，头文件 cstdio
puts(s) 

// 每次读入一个字符，在读入一次之后会判断是否读完整个文件
// 若读完，会返回特殊常量 EOF 标志读入结束，手动输入 CTRL Z 提示已经读完，会返回 EOF
getchar()

// 用于C风格字符串
cin.get(s, 100);    // read a line, leave \n in queue
cin.getline(s, 100) // read a line, discard \n  
```
### ccytpe
![image-20221007202634201](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221007202634201.png)
## Numeric Conversions
### High-Level Numeric Conversions
#### Converting to Strings
```
string to_string(T val);
```
T 可以是 `(unsigned)int`、`(unsigned) long`、`(unsigned)long long`、`float`、`double` 以及 `long double`。所有这些函数都负责内存分配，它们会创建一个新的 `string` 对 象并返回。
#### Converting to Strings
在这些函数原型中，`str` 表示要转换的字符串，`idx` 是一个指针，这个指针接收第一个未转换的字符的索引，`base` 表示转换过程中使用的进制。`idx` 指针可以是空指针，如果是空指针，则被忽略。如果不能执行任何转换，这些函数会抛出 `invalid_argument` 异常。如果转换的值超出返回类型的范围，则抛出 `out_of_range` 异常：
```cpp
int stoi(const string& str, size_t *idx=0, int base=10);
long stol(const string& str, size_t *idx=0, int base=10);
unsigned long stoul(const string& str, size_t *idx=0, int base=10);
long long stoll(const string& str, size_t *idx=0, int base=10);

unsigned long long stoull(const string& str, size_t *idx=0, int base=10);
float stof(const string& str, size_t *idx=0);
double stod(const string& str, size_t *idx=0);
long double stold(const string& str, size_t *idx=0);
```
`base` 的默认值为 10, 采用数字为 0~9 的十进制，`base` 为 16 表示采用十六 进制。如果 `base` 被设为 0, 函数会按照以下规则自动计算给定数字的进制：
- 如果数字以 `0x` 或者 `0X` 开头，则被解析为十六进制数字。
- 如果数字以 `0` 开头，则被解析为八进制数字。 
- 其他情况下，被解析为十进制数字。
```c++
assert(stoi("42") == 42);            // 字符串转整数
assert(stol("253") == 253L);         // 字符串转长整数
assert(stod("2.0") == 2.0);          // 字符串转浮点数
assert(to_string(1984) == "1984");   // 整数转字符串
```
### Low-Level Numeric Conversions
C++也提供了许多低级数值转换函数，在 `<charconv>` 文件中定义。这些函数不执行内存分配，也不直接使用 `string`，而使用由调用者分配的缓存区。
最终的结果是，这些函数可以比其他高级数值转换函数快几个数量级。这些函数也是为所谓的完美往返而设计的，这意味着将数值序列化为字符串表示，然后将结果字符串反序列化为数值，结果与原始值完全相同。
#### Converting to Strings
```cpp
to_chars_result to_chars(char* first, char* last, IntegerT value, int base = 10);
```
`IntegerT` 可以是任何有符号或无符号的整数类型或 `char` 类型。结果是 `to_chars_result` 类型， 类型定义如下所示。如果转换成功，`ptr` 成员将等于所写入字符尾后位置的指针。如果转换失败(即 `ec == errc::value_too_large`)，则等于 `last`。
```cpp
struct to_chars_result {
    char* ptr;
    errc ec;
};
```
使用示例：
```cpp
const size_t BufferSize { 50 };
string out(BufferSize, ' '); // A string of BufferSize space characters.
auto result { to_chars(out.data(), out.data() + out.size(), 12345) };
if (result.ec == errc{}) { cout << out << endl; /* Conversion successful. */ }

// 使用结构化绑定
string out(BufferSize, ' '); // A string of BufferSize space characters.
auto [ptr, error] { to_chars(out.data(), out.data() + out.size(), 12345) };
if (error == errc{}) { cout << out << endl; /* Conversion successful. */ }
```
下面的一组转换函数可用于浮点类型：
```cpp
to_chars_result to_chars(char* first, char* last, FloatT value);
to_chars_result to_chars(char* first, char* last, FloatT value,
 chars_format format);
to_chars_result to_chars(char* first, char* last, FloatT value,
 chars_format format, int precision);
```
`FloatT` 可以是 `float`、`double` 或 `long double`。可使用 `chars_format` 标志的组合指定格式：
```cpp
enum class chars_format {
    scientific, // Style: (-)d.ddde±dd
    fixed, // Style: (-)ddd.ddd
    hex, // Style: (-)h.hhhp±d (Note: no 0x!)
    general = fixed | scientific // See next paragraph.
};
```
默认格式是 `chars format::general`，这将导致 `to_chars()` 将浮点值转换为 `(-)ddd.ddd` 形式的十进制表示形式，或 `(-)d.ddde±dd` 形式的十进制指数表示形式，得到最短的表示形式，小数点前至少有一位数字(如果存在)。如果指定格式，但未指定精度，将为给定格式自动确定最简短的表示形式，最大精度为 6 个数字。例如：
```cpp
double value { 0.314 };
string out(BufferSize, ' '); // A string of BufferSize space characters.
auto [ptr, error] { to_chars(out.data(), out.data() + out.size(), value) };
if (error == errc{}) { cout << out << endl; /* Conversion successful. */ }
```
#### Converting to Strings
对于相反的转换，即将字符串转换为数值，可使用下面的一组函数。
```cpp
from_chars_result from_chars(const char* first, const char* last,
 IntegerT& value, int base = 10);
from_chars_result from_chars(const char* first, const char* last,
 FloatT& value,
 chars_format format = chars_format::general);
```
`from_chars_result` 的类型定义如下:
```cpp
struct from_chars_result {
    const char* ptr;
    errc ec;
};
```
结果类型的 `ptr` 成员是指向第一个未转换字符的指针，如果所有字符都成功转换，则它等于 `last`。如果所有字符都未转换，则 `ptr` 等于 `first`，错误代码的值将为 `errc::invalid_argument`。如果解析后的值过大，无法由给定类型表示，则错误代码的值将是 `errc::result_out_of_range`，忽略任何前导空白。
`to_chars()` 和 `form_chars()` 的完美往返特性可以表示如下：
```cpp
double value1 { 0.314 };
string out(BufferSize, ' '); // A string of BufferSize space characters.
auto [ptr1, error1] { to_chars(out.data(), out.data() + out.size(), value1) };
if (error1 == errc{}) { cout << out << endl; /* Conversion successful. */ }

double value2;
auto [ptr2, error2] { from_chars(out.data(), out.data() + out.size(), value2) };
if (error2 == errc{}) {
    if (value1 == value2) {
        cout << "Perfect roundtrip" << endl;
    } else {
        cout << "No perfect roundtrip?!?" << endl;
    }
}
```
# String_view
#cpp17
在 `C++17` 之前，接收只读字符串的函数会编写多个重载版本，一个接收 `const char*`，另一个接收 `const string&`，前者必须调用 `string` 上的 `c_str()` 或 `data()` 来获取 `const char*`，函数将失去 `string` 良好的面向对象的方面及其良好的辅助方法，后者始终需要 `string`，如果传递一个字符串字面量，编译器将默认创建一个临时字符串对象，并将该对象传递给函数，因此会增加一点开销。
在 `C++17` 中，通过引入 `string_view` 类解决了所有这些问题，`string_view` 类是 `basic string_view` 类模板的实例化，在 `<string_view>` 中定义。`string_view` 从不复制字符串，支持与 `string` 类似的接口，缺少 `c_str()`，但 `data()` 是可用的。
另外，`string_view` 有 `remove_prefix(size_t)` 和 `remove_suffix(Size_t)` 方法，前者将起始指针前移给定的偏移量收缩字符串，后者则将结尾指针倒退给定的偏移量来收缩字符串。 `string_view` 构造函数可以接收任意原始缓冲区和长度，用于从字符串缓冲区构建 `string_view`。
通常按值传递 `string_views`, 因为它们的复制成本极低，它们**只包含指向字符串的指针以及字符串的长度**。在每当函数需要将只读字符串作为一个参数时，可使用 `string_view` 替代 `const char*` 或 `const string&`。但返回字符串的函数应返回 `const string&` 或 `string`, 不应返回 `string_view`，返回 `string_view` 会带来使返回的 `string_view` 无效的风险，例如当它指向的字符串需要重新分配时。因此**将 `const string&` 或 `string_view` 存储为类的数据成员需要确保它们指向的字符串在对象的生命周期内保持有效状态，存储 `string` 更安全**。
无法从 `string_views` 隐式构建一个 `string`，要么使用一个显式的 `string` 构造函数，要么使用 `string_view::data` 成员。例如，假设有以下接收 `const string&` 的函数。
```cpp
string_view extractExtension(string_view filename) {
 return filename.substr(filename.rfind('.'));
}

void handleExtension(const string& extension) { /* ... */ }
handleExtension(extractExtension("my file.ext")); // 不能采用这种方式调用该函数

handleExtension(extractExtension("my file.ext").data()); // data() method
handleExtension(string { extractExtension("my file.ext") }); // explicit ctor
// 无法连接一个 string 和一个 String_View
string str { "Hello" };
string_view sv { " world" };
auto result { str + sv };

auto result1 { str + sv.data() };
string result2 { str }; 
result2.append(sv.data(), sv.size());
```
`string_views` 不应该用于保存一个临时字符串的视图，考虑以下示例:
```cpp
string s { "Hello" };
string_view sv { s + " World!" };
cout << sv;
```
字符串视图 `sv` 的初始化表达式将生成一个临时字符串，其中包含 “HelloWorld!”。然后， `string_views` 存储指向此临时字符串的指针。在第二行代码的末尾，这个临时字符串被销毁，留下一个悬空指针的 `string_views`。
可使用标准的用户定义的字面量 `sv`, 将字符串字面量解释为 `string_views`：
```cpp
using namespace std::literals::string_view_literals;
auto sv { "My string_view"sv };
```
可以在 `C++11` 里实现一个简化版本：
```c++
class my_string_view final        // 简单的字符串视图类，示范实现
{
public:
    using this_type = my_string_view;     // 各种内部类型定义
    using string_type = string;
    using string_ref_type = const string&;

    using char_ptr_type = const char*;
    using size_type = size_t;
private:
    char_ptr_type ptr = nullptr;     // 字符串指针
    size_type len = 0;               // 字符串长度
public:
    my_string_view() = default;
   ~my_string_view() = default;

    my_string_view(string_ref_type str) noexcept
        : ptr(str.data()), len(str.length())
    {}
public:
    char_ptr_type data() const     // 常函数，返回字符串指针
    {
        return ptr;
    }

    size_type size() const        // 常函数，返回字符串长度
    {
        return len;
    }
};
```
# String Formatting
`C++20` 引入 `std::format` 用来格式化字符串，它定义在 `<format>` 中。
`format()` 的第一个参数是待格式化的字符串，后续参数是用于填充待格式化字符串中占位符的值。使用的占位符一般都是一对花括号，在这些花括号内可以是格式为 `[index][:specifier]` 的字符串。
可以省略所有占位符中的 `index`, 也可以为所有占位符指定从零开始的索引，以指明应用于此占位符的参数。如果省略 `index`, 则后续参数传递的值将按给定顺序用于所有占位符。
`specifier` 是一种格式说明符，用于更改值在输出中格式化的方式。如果需要输出 `{or}` 字符，要将其转义为 `{{or}}`。
## Index
```cpp
auto s1 { format("Read {} bytes from {}", n, "file1.txt") };   // 自动索引
auto s2 { format("Read {0} bytes from {1}", n, "file1.txt") }; // 手动索引
auto s2 { format("Read {0} bytes from {}", n, "file1.txt") };  // 不允许混合使用手动和自动索引
auto s3 { format(L"从{1}中读取{0}个字节。", n, L"file1.txt") }  // 顺序以索引为主
```
## Specifier
格式说明符用于控制值在输出中的格式，前缀为冒号。格式说明符的一般形式如下所示，均是可选的，在精度和类型之间可以有一个可选的 `L`：
```cpp
[[fill]align][sign][#][0][width][.precision][type]
```
`width` 指定待格式化的值所占字段的最小宽度。`width` 也可以是另一组花括号，称为动态宽度。如果在花括号中指定索引，例如 `{3}`，则动态宽度的 `width` 取自给定的索引对应的 `format()` 的实参。如果未指定索引，例如 `{}`, 则 `width` 取自 `format()` 的实参列表中的下一个参数。
```cpp
int i { 42 };
cout << format("|{:5}|", i) << endl;    
cout << format("|{:{}}|", i, 7) << endl; 
```
`[fill]align` 说明使用哪个字符作为填充字符，然后是值在其字段中的对齐方式：
- `<` 表示左对齐(非整数和非浮点数的默认对齐方式)。
- `>` 表示右对齐(整数和浮点数的默认对齐方式)。
- `^` 表示居中对齐。
`fill` 字符会被插入输入中，以确保输出中的字段达到说明符 `[width]` 指定的最小宽度。如果未指定 `[width]` 则 `[fill]align` 无效。
```cpp
int i { 42 };
cout << format("|{:7}|", i) << endl;
cout << format("|{:<7}|", i) << endl; 
cout << format("|{:_>7}|", i) << endl; 
cout << format("|{:_^7}|", i) << endl; 
```
`sign` 可以是下列三项之一
- `-` 表示只显示负数的符号(默认方式)。
- `+` 表示显示正数和负数的符号。
- `space` 表示对于负数使用负号，对于正数使用空格。
```cpp
int i { 42 };
cout << format("|{:<5}|", i) << endl; // |42 |
cout << format("|{:<+5}|", i) << endl; // |+42 |
cout << format("|{:< 5}|", i) << endl; // | 42 |
cout << format("|{:< 5}|", -i) << endl; // |-42 |
```
`#` 启用所谓的备用格式规则。如果为整型启用，并且还指定十六进制、二进制或八制数字格式，则备用格式会在格式化数字前面插入 0x、0X、0b、0B 或0。如果为浮点类型启用，则备用格式将始终输出十进制分隔符，即使后面没有数字。
type 指定给定值要被格式化的类型，以下是几个选项：
- 整型：`bB` 二进制，`d` 十进制，`o` 八进制，`xX` 小大写字母的十六进制。如果 `type` 未指定，整型默认使用 `d`。
- 浮点型：`eE` 表示指数的科学表示法，按照给定精度或 6 格式化、`fF` 固定表示法，按照给定精度或 6 格式化、`gG` 表示指数的通用表示法，按照给定精度或 6 格式化、`aA` 十六进制表示法。如果 `type` 未指定，浮点型默认使用 `g`。
- 布尔型：`s` 以文本形式输出 `true` 或 `false`，`bBcdoxX` 以整型输出 1 或 0。如果 `type` 未指定，布尔型默认使用 `s`。
- 字符型：`c` 输出字符副本，`bBdoxX` 整数表示）。如果 `type` 未指定，字符型默认使用 `c`。
- 字符串：`s` 输出字符串副本。如果 `type` 未指定，字符串默认使用 `s`。
- 指针：`p` 0x为前缀的十六进制表示法。如果 `type` 未指定，指针默认使用 `p`。
```cpp
int i { 42 };
cout << format("|{:10d}|", i) << endl;
cout << format("|{:10b}|", i) << endl; 
cout << format("|{:#10b}|", i) << endl; 
cout << format("|{:10X}|", i) << endl; 
cout << format("|{:#10X}|", i) << endl; 

string s { "ProCpp" };
cout << format("|{:_^10}|", s) << endl; // |__ProCpp__|
```
`precision` 只能用于浮点和字符串类型。它的格式为一个点后跟浮点类型要输出的小数位数，或字符串要输出的字符数。就像 `width` —样，这也可以是另一组花括号，在这种情况下，它被称为动态精度。`precision` 取自 `foimat` 的实参列表中的下一个实参或具有给定索引的实参。
```cpp
double d { 3.1415 / 2.3 };
cout << format("|{:12g}|", d) << endl; 
cout << format("|{:12.2}|", d) << endl; 
cout << format("|{:12e}|", d) << endl;
int width { 12 };
int precision { 3 };
cout << format("|{2:{0}.{1}f}|", width, precision, d) << endl; 
```
`0` 表示，对于数值，将 `0` 插入格式化结果中，以达到 `[width]` 指定的最小宽度。这些 0 插入在数值的前面，但在符号以及任何前缀之后。如果指定对齐，则将忽略本选项。


