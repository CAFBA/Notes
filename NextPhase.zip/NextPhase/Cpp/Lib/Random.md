# Random
在新标准出现之前，C和C++都依赖于一个简单的C库函数`rand`来生成随机数。该函数生成均匀分布的伪随机整数，每个随机数的范围在0和一个系统相关的最大值（至少为32767）之间。
头文件`random`中的随机数库定义了一组类来解决`rand`函数的一些问题：
**随机数引擎类（random-number engines）可以生成`unsigned`随机数序列；随机数分布类（random-number distribution classes）使用引擎类生成指定类型、范围和概率分布的随机数。**
C++程序不应该使用`rand`函数，而应该使用`default_random_engine`类和恰当的分布类对象。
## 随机数引擎
随机数引擎是函数对象类，定义了一个不接受参数的调用运算符，返回一个随机`unsigned`整数。调用一个随机数引擎对象可以生成原始随机数。随机数引擎生成的`unsigned`整数在一个系统定义的范围内。一个引擎类型的范围可以通过调用该类型对象的`min`和`max`成员来获得。
```c++
default_random_engine e;    // generates random unsigned integers
for (size_t i = 0; i < 10; ++i)
    cout << e() << " ";
```
标准库定义了多个随机数引擎类，区别在于性能和随机性质量。每个编译器都会指定其中一个作为`default_random_engine`类型，此类型一般具有最常用的特性。
所有随机数引擎类都支持的操作如下：

|       名称       |                       功能                        |
| :--------------: | :-----------------------------------------------: |
|     Engine e     |                  创建一个引擎。                   |
|   Engine e(s)    |          创建一个引擎，并用 s 作为种子。          |
|    e.seed(s)     |            使用种子 s 重置 e 的状态。             |
| e.min(), e.max() |            e 能生成的最小值和最大值。             |
|   e.discard(u)   | 将 e 推进 u 步（u 的类型为 unsigned long long）。 |

即使随机数发生器生成的数看起来是随机的，但对于一个给定的发生器，每次运行程序时它都会返回相同的数值序列。
通过为引擎提供一个种子（seed），可以让引擎在程序每次运行时生成不同的序列。种子是一个数值，引擎利用它从序列中的一个新位置重新开始生成随机数。
- 在创建对象时提供种子。
- 调用引擎的`seed`成员设置种子。
```c++
default_random_engine e1;    // uses the default seed
default_random_engine e2(2147483646);   // use the given seed value
e3.seed(32767);     // call seed to set a new seed value
```
选择种子的常用方法是调用系统函数`time`。该函数定义在头文件`ctime`中，返回从一个特定时刻到当前经过的秒数。**`time`函数接受单个指针参数，指向用于写入时间的数据结构。如果指针为空，则函数简单地返回时间。**
```c
default_random_engine e1(time(0));   // a somewhat random seed
```
由于`time`函数返回以秒计算的时间，因此用`time`返回值作为种子的方式只适用于生成种子的间隔为秒级或更长时间的应用。另外如果程序作为一个自动过程的一部分反复运行，这种方式也会无效，可能多次使用的是相同的种子。
## 随机数分布
使用分布类对象可以得到指定范围的随机数。类似引擎类型，分布类型也是函数对象类。分布类型定义了一个**接受一个随机数引擎参数的调用运算符**。**分布对象使用它的引擎参数生成随机数，并将其映射到指定的分布区间。**
下表随机数分布类共有的操作：

|   名称    |                        功能                         |
| :-------: | :-------------------------------------------------: |
|    U u    |                 创建一个分布类 u 。                 |
|   u(e)    |  用随机数引擎 e 生成随机数（u 代表随机数分布类）。  |
|  u.min()  |                 u 能生成的最小值。                  |
|  u.max()  |                 u 能生成的最大值。                  |
| u.reset() | 重置 u 的状态，使随后 u 生成的值不受之前的值影响 。 |

新标准库的`uniform_int_distribution<unsigned>`类型生成均匀分布的`unsigned`值。
```c++
uniform_int_distribution<unsigned> u(0,9);
default_random_engine e;    // generates unsigned random integers
for (size_t i = 0; i < 10; ++i) cout << u(e) << " ";
```
**如果函数需要局部的随机数发生器，应该将其（包括引擎和分布对象）定义为`static`对象，这样随机数发生器就能在函数调用期间保持状态**。否则每次调用函数都会生成相同的序列。
```c++
vector<unsigned> good_randVec()
{
    static default_random_engine e;
    static uniform_int_distribution<unsigned> u(0,9);
    vector<unsigned> ret;
    for (size_t i = 0; i < 100; ++i) ret.push_back(u(e));
    return ret;
}
```
使用新标准库的`uniform_real_distribution`类型可以获得随机浮点数。
```c++
default_random_engine e;    // generates unsigned random integers
// uniformly distributed from 0 to 1 inclusive
uniform_real_distribution<double> u(0,1);
for (size_t i = 0; i < 10; ++i) cout << u(e) << " ";
```
> 从`rand`函数获得随机浮点数的一个常用但不正确的方法是用`rand`的结果除以`RAND_MAX`。但因为随机整数的精度通常低于随机浮点数，所以使用这种方法时，有一些浮点值永远不会被生成。

除了总是生成`bool`类型的`bernouilli_distribution`外，其他分布类型都是模板。每个模板都接受单个类型参数，指定分布生成的结果类型。
分布类型限制了可以作为模板类型的参数类型，一些模板只能生成浮点数，而其他模板只能生成整数。分布类型还定义了一个默认模板类型参数，整型分布的默认参数是`int`，浮点数分布的默认参数是`double`。使用默认类型时应该在模板名后使用空尖括号。
```c
// empty <> signify we want to use the default result type
uniform_real_distribution<> u(0,1);    // generates double by default
```
`bernouilli_distribution`类型是一个普通类，而非模板。该分布返回一个`bool`值，其中`true`的概率是一个常数，默认为0.5。
```c++
default_random_engine e;
bernoulli_distribution u;
for(int i = 0; i < 10; i++) cout << u(e) << endl;
```
由于引擎会返回相同的随机数序列，因此需要在循环中使用引擎时，**必须在循环体外定义引擎对象**。否则每次循环都会创建新引擎，生成相同序列。同样，分布对象也需要保持运行状态，也**必须在循环体外定义**。
## 测试代码
```c++
int *generateRandomArray(int maxSize, int maxValue)
{
  // static保证每次调用函数时随机数发生器能在函数调用期间保持状态
  // 而不是每次调用生成新的随机数发生器，使得多次调用结果一致
  // time(nullptr)保证每次运行程序时随机数种子不同，即每次运行程序的结果
  static default_random_engine e(time(nullptr));
  static uniform_real_distribution<double> u(0,1);

  int randomSize = (int)(maxSize * u(e));
  int *arr = new int[randomSize]; // 长度随机
  for (int i = 0; i < randomSize; i++)
  {
    arr[i] = (int)(maxValue * u(e) - (int)u(e));
    cout << arr[i] << " ";
  }
  cout << endl;
  return arr;
}

int main() {
  generateRandomArray(10, 100);
  generateRandomArray(10, 100);
}
```

