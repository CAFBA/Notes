在 `<optional>` 定义的 `std::optional` 保留特定类型的值，或者不包含任何值。基本上，如果想要允许值是可选的，则将 `optional` 用于函数的参数。如果函数可能返回也可能不返回某些内容，则将 `optional` 用作函数的返回类型。
```cpp
optional<int> getData(bool giveIt) {
    if (giveIt) return 42;
    return nullopt; // or simply return {};
}

optional data1 { getData(true) }; 
optional data2 { getData(false) };
```
可以用 `has_value()` 方法判断一个 `optional` 是否有值，或简单地将 `optional` 用在 `if` 语句中。
```cpp
cout << "data1.has_value = " << data1.has_value() << endl;
if (data2) cout << "data2 has a value." << endl;
```
如果 `optional` 有值，可以使用 `value()` 或解引用运算符访问它。`value_or()` 可以用来返回 `optional` 的值，如果 `optional` 为空，则返回指定的值。如果对一个空的 `optional` 使用 `value()` 将会抛出 `std::bad_optional_access` 异常。
```cpp
cout << "data1.value = " << data1.value() << endl;
cout << "data1.value = " << *data1 << endl;
cout << "data2.value = " << data2.value_or(0) << endl;
```
不能将引用保存在 `optional` 中，所以 `optional<T&>` 是无效的。但是, 可以将指针保存在 `optional` 中。
