## The bitset Type
标准库在头文件`bitset`中定义了`bitset`类，用于处理二进制位。`bitset`可以处理超过最长整型类型大小的位集合。
### Defining and Initializing bitsets
`bitset`类是一个模板，类似`array`，具有固定的大小。定义一个`bitset`时需要指明它包含的二进制位数。
![17-2](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-2.png)
使用一个整型值初始化`bitset`时，此值会被转换为`unsigned long long`类型并被当作位模式处理。`bitset`中的二进制位就是此模式的副本。如果`bitset`的大小大于`unsigned long long`中的二进制位数，剩余的高位会被置为0。如果`bitset`的大小小于`unsigned long long`中的二进制位数，则只使用给定值的低位部分。
```c
// bitvec1 is smaller than the initializer; high-order bits from the initializer are discarded
bitset<13> bitvec1 (0xbeef);    // bits are 1111011101111
// bitvec2 is larger than the initializer; high-order bits in bitvec2 are set to zero
bitset<20> bitvec2(0xbeef);     // bits are 00001011111011101111
// on machines with 64-bit long long 0ULL is 64 bits of 0, so ~0ULL is 64 ones
bitset<128> bitvec3(~0ULL);     // bits 0 ... 63 are one; 63 ... 127 are zero
```
可以使用`string`或字符数组指针来初始化`bitset`，字符直接表示位模式。使用字符串表示数时，字符串中下标最小的字符对应`bitset`的高位。如果`string`包含的字符数比`bitset`少，则`bitset`的高位被置为0。
```c
bitset<32> bitvec4("1100"); // bits 2 and 3 are 1, all others are 0
string str("1111111000000011001101");
bitset<32> bitvec5(str, 5, 4);           // four bits starting at str[5], 1100
bitset<32> bitvec6(str, str.size()-4);   // use last four characters
```
![](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-3.png)
### Operations on bitsets
`bitset`操作：
![17-4](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-4.png)
`bitset`的下标运算符对`const`属性进行了重载。`const`版本的下标运算符在指定位置置位时返回`true`，否则返回`false`。非`const`版本返回`bitset`定义的一个特殊类型，用来控制指定位置的值。
`to_ulong`和`to_ullong`操作用来提取`bitset`的值。只有当`bitset`的大小不大于对应操作的返回值（`to_ulong`为`unsigned long`，`to_ullong`为`unsigned long long`）时，才能使用这两个操作。如果`bitset`中的值不能存入给定类型，则会引发`overflow_error`异常。
```c
unsigned long ulong = bitvec3.to_ulong();
cout << "ulong = " << ulong << endl;
```
`bitset`的输入运算符从输入流读取字符，保存到临时的`string`对象中。遇到下列情况时停止读取：
- 读取的字符数达到对应`bitset`的大小。
- 遇到不是1和0的字符。
- 遇到文件结尾。
- 输入出现错误。
读取结束后用临时`string`对象初始化`bitset`。如果读取的字符数小于`bitset`的大小，则`bitset`的高位被置为0。