# The IO Library
部分IO库设施：
- `istream`：输入流类型，提供输入操作。
- `ostream`：输出流类型，提供输出操作。
- `cin`：`istream`对象，从标准输入读取数据。
- `cout`：`ostream`对象，向标准输出写入数据。
- `cerr`：`ostream`对象，向标准错误写入数据。
- `>>`运算符：从`istream`对象读取输入数据。
- `<<`运算符：向`ostream`对象写入输出数据。
- `getline`函数：从`istream`对象读取一行数据，写入`string`对象。
## IO类
**头文件`iostream`定义了用于读写流的基本类型，`fstream`定义了读写命名文件的类型，`sstream`定义了读写内存中`string`对象的类型。**
![image-20221015131725546](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221015131725546.png)
宽字符版本的IO类型和函数的名字以`w`开始，如`wcin`、`wcout`和`wcerr`分别对应`cin`、`cout`和`cerr`。它们与其对应的普通`char`版本都定义在同一个头文件中，如头文件`fstream`定义了`ifstream`和`wifstream`类型。
可以将派生类的对象当作其基类的对象使用。类型ifstream和istringstream都继承自istream。因此，可以像使用istream对象一样来使用ifstream和istringstream对象。也就是说，我们是如何使用cin的，就可以同样地使用这些类型的对象。例如，可以对一个ifstream或istringstream对象调用getline，也可以使用>>从一个ifstream或istringstream对象中读取数据。

### IO对象无拷贝或赋值

不能拷贝或对IO对象赋值。

```c++
ofstream out1, out2;
out1 = out2;    // error: cannot assign stream objects
ofstream print(ofstream);   // error: can't initialize the ofstream parameter
out2 = print(out2);     // error: cannot copy stream objects
```

由于IO对象不能拷贝，因此不能将函数形参或返回类型定义为流类型。进行IO操作的函数通常以引用方式传递和返回流。读写一个IO对象会改变其状态，因此传递和返回的引用不能是`const`的。

### 条件状态
IO库条件状态：
![8-2](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/8-2.png)

一个流一旦发生错误，其上后续的IO操作都会失败。只有当一个流 处于无错状态时，才可以从它读取数据，向它写入数据。由于流可 能处于错误状态，因此代码通常应该在使用一个流之前检查它是否处于良好状态。确定一个流对象的状态的最简单的方法是将它当作一个条件来使用：

```c++
while (cin >> word)
    // ok: read operation successful...
```

IO库定义了一个与机器无关的iostate类型，它提供了表达流状态的完整功能。IO库定义了4个iostate类型的 constexpr值，表示特定的位模式。这些值用来表示特定类型的IO条件，可以与位运算符一起使用来一次性检测或设置多个标志位。

- `badbit`表示系统级错误，如不可恢复的读写错误。通常情况下，一旦`badbit`被置位，流就无法继续使用了。
- 在发生可恢复错误后，`failbit`会被置位，如期望读取数值却读出一个字符。
- 如果到达文件结束位置，`eofbit`和`failbit`都会被置位。
- 如果流未发生错误，则`goodbit`的值为0。

> 如果`badbit`、`failbit`和`eofbit`任何一个被置位，检测流状态的条件都会失败。

`good`函数在所有错误均未置位时返回`true`。而`bad`、`fail`和`eof`函数在对应错误位被置位时返回`true`。此外，在`badbit`被置位时，`fail`函数也会返回`true`。因此应该使用`good`或`fail`函数确定流的总体状态，`eof`和`bad`只能检测特定错误。

流对象的`rdstate`成员返回一个`iostate`值，表示流的当前状态。`setstate`成员用于将指定条件置位（叠加原始流状态）。`clear`成员的无参版本清除所有错误标志；含参版本接受一个`iostate`值，用于设置流的新状态（覆盖原始流状态）。

```c++
// remember the current state of cin
auto old_state = cin.rdstate();     // remember the current state of cin
cin.clear();    // make cin valid
process_input(cin);     // use cin
cin.setstate(old_state);    // now reset cin to its old state
```

### 管理输出缓冲

每个输出流都管理一个缓冲区，用来保存程序读写的数据。文本串可能立即打印出来，但也有可能被操作系统保存在缓冲区 中，随后再打印。有了缓冲机制，操作系统就可以将程序的多个输出操作组合成单一的系统级写操作。由于设备的写操作可能很耗时，允许操作系统将多个输出操作组合为单一的设备写操作可以带来很大的性能提升。

每个输出流都管理一个缓冲区，用于保存程序读写的数据。导致缓冲刷新（即数据真正写入输出设备或文件）的原因有很多：

- 程序正常结束。
- 缓冲区已满。
- 使用操纵符（如`endl`）显式刷新缓冲区。
- 在每个输出操作之后，可以用`unitbuf`操纵符设置流的内部状态，从而清空缓冲区。默认情况下，对`cerr`是设置`unitbuf`的，因此写到`cerr`的内容都是立即刷新的。
- 一个输出流可以被关联到另一个流。这种情况下，当读写被关联的流时，关联到的流的缓冲区会被刷新。默认情况下，`cin`和`cerr`都关联到`cout`，因此，读`cin`或写`cerr`都会刷新`cout`的缓冲区。

**`flush`操纵符刷新缓冲区，但不输出任何额外字符。`ends`向缓冲区插入一个空字符，然后刷新缓冲区。**

```c++
cout << "hi!" << endl;   // writes hi and a newline, then flushes the buffer
cout << "hi!" << flush;  // writes hi, then flushes the buffer; adds no data
cout << "hi!" << ends;   // writes hi and a null, then flushes the buffer
```

**如果想在每次输出操作后都刷新缓冲区，可以使用`unitbuf`操纵符。**它令流在接下来的每次写操作后都进行一次`flush`操作。**而`nounitbuf`操纵符则使流恢复使用正常的缓冲区刷新机制。**

```c++
cout << unitbuf;    // all writes will be flushed immediately
// any output is flushed immediately, no buffering
cout << nounitbuf;  // returns to normal buffering
```

如果程序异常终止，输出缓冲区不会被刷新。

### 关联输入和输出流

**当一个输入流被关联到一个输出流时，任何试图从输入流读取数据的操作都会先刷新关联的输出流。**标准库将`cout`和`cin`关联在一起，因此下面的语句会导致`cout`的缓冲区被刷新：

```c++
cin >> ival;
```

> 交互式系统通常应该关联输入流和输出流。这意味着包括用户提示信息在内的所有输出，都会在读操作之前被打印出来。
>

使用`tie`函数可以关联两个流。它有两个重载版本：无参版本返回指向输出流的指针。如果本对象已关联到一个输出流，则返回的就是指向这个流的指针，否则返回空指针。`tie`的第二个版本接受一个指向`ostream`的指针，将本对象关联到此`ostream`，返回指向原本关联的输出流的指针。

```c++
cin.tie(&cout);     // illustration only: the library ties cin and cout for us
// old_tie points to the stream (if any) currently tied to cin
ostream *old_tie = cin.tie(nullptr); // cin is no longer tied
// ties cin and cerr; not a good idea because cin should be tied to cout
cin.tie(&cerr);     // reading cin flushes cerr, not cout
cin.tie(old_tie);   // reestablish normal tie between cin and cout
```

在这段代码中，为了将一个给定的流关联到一个新的输出流，将新流的指针传递给了tie。为了彻底解开流的关联，传递了一个空指针。每个流同时最多关联到一个流，但多个流可以同时关联到同一个ostream

## 文件输入输出

头文件`fstream`定义了三个类型来支持文件IO：`ifstream`从给定文件读取数据，`ofstream`向指定文件写入数据，`fstream`可以同时读写指定文件。
![8-3](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/8-3.png)
### 使用文件流对象

每个文件流类型都定义了`open`函数，它完成一些系统操作，定位指定文件，并视情况打开为读或写模式。

创建文件流对象时，如果提供了文件名（可选），`open`会被自动调用。

```c++
ifstream in(ifile);   // construct an ifstream and open the given file
ofstream out;   // output file stream that is not associated with any file
```

在C++11中，文件流对象的文件名可以是`string`对象或C风格字符数组。旧版本的标准库只支持C风格字符数组。

在要求使用基类对象的地方，可以用继承类型的对象代替。因此一个接受`iostream`类型引用或指针参数的函数，可以用对应的`fstream`类型来调用。

可以先定义空文件流对象，再调用`open`函数将其与指定文件关联。如果`open`调用失败，`failbit`会被置位。

对一个已经打开的文件流调用`open`会失败，并导致`failbit`被置位。随后试图使用文件流的操作都会失败。如果想将文件流关联到另一个文件，必须先调用`close`关闭当前文件，再调用`clear`重置流的条件状态（`close`不会重置流的条件状态）。

当`fstream`对象被销毁时，`close`会自动被调用。

### 文件模式

每个流都有一个关联的文件模式，用来指出如何使用文件。
![8-4](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/8-4.png)
- 只能对`ofstream`或`fstream`对象设定`out`模式。
- 只能对`ifstream`或`fstream`对象设定`in`模式。
- 只有当`out`被设定时才能设定`trunc`模式。
- 只要`trunc`没被设定，就能设定`app`模式。在`app`模式下，即使没有设定`out`模式，文件也是以输出方式打开。
- 默认情况下，即使没有设定`trunc`，以`out`模式打开的文件也会被截断。如果想保留以`out`模式打开的文件内容，就必须同时设定`app`模式，这会将数据追加写到文件末尾；或者同时设定`in`模式，即同时进行读写操作。
- `ate`和`binary`模式可用于任何类型的文件流对象，并可以和其他任何模式组合使用。
- 与`ifstream`对象关联的文件默认以`in`模式打开，与`ofstream`对象关联的文件默认以`out`模式打开，与`fstream`对象关联的文件默认以`in`和`out`模式打开。

默认情况下，打开`ofstream`对象时，文件内容会被丢弃，阻止文件清空的方法是同时指定`app`或`in`模式。

流对象每次打开文件时都可以改变其文件模式。

```
ofstream out;   // no file mode is set
out.open("scratchpad");    // mode implicitly out and trunc
out.close();    // close out so we can use it for a different file
out.open("precious", ofstream::app);   // mode is out and app
out.close();
```

## string流（string Streams）

头文件`sstream`定义了三个类型来支持内存IO：`istringstream`从`string`读取数据，`ostringstream`向`string`写入数据，`stringstream`可以同时读写`string`的数据。
![8-5](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/8-5.png)
### 使用istringstream（Using an istringstream）

```
// members are public by default
struct PersonInfo
{
    string name;
    vector<string> phones;
};

string line, word;   // will hold a line and word from input, respectively
vector<PersonInfo> people;    // will hold all the records from the input
// read the input a line at a time until cin hits end-of-file (or another error)
while (getline(cin, line))
{
    PersonInfo info;    // create an object to hold this record's data
    istringstream record(line);    // bind record to the line we just read
    record >> info.name;    // read the name
    while (record >> word)  // read the phone numbers
        info.phones.push_back(word);   // and store them
    people.push_back(info);    // append this record to people
}
```

### 使用ostringstream（Using ostringstreams）

```c++
cfor (const auto &entry : people)
{ // for each entry in people
    ostringstream formatted, badNums;   // objects created on each loop
    for (const auto &nums : entry.phones)
    { // for each number
        if (!valid(nums))
        {
            badNums << " " << nums;  // string in badNums
        }
        else
            // ''writes'' to formatted's string
            formatted << " " << format(nums);
    }

    if (badNums.str().empty())   // there were no bad numbers
        os << entry.name << " "  // print the name
            << formatted.str() << endl;   // and reformatted numbers
    else  // otherwise, print the name and bad numbers
        cerr << "input error: " << entry.name
            << " invalid number(s) " << badNums.str() << endl;
}
```

## io library

### 格式化输入与输出（Formatted Input and Output）

除了条件状态外，每个`iostream`对象还维护着一个格式状态来控制IO格式化细节。

标准库定义了一组操纵符（manipulator）来修改流的格式状态。操纵符是一个函数或对象，会影响流的状态，并能作为输入和输出运算符的运算对象。类似输入和输出运算符，操纵符也返回它所处理的流对象。

操纵符用于两大类输出控制：控制数值的输出格式，控制补白的数量和位置。

操纵符改变流的格式状态时，通常改变后的状态对所有后续IO都生效。大多数改变格式状态的操纵符都是设置/复原成对的，一个操纵符用于设置新格式，另一个用于恢复正常格式。

默认情况下，`bool`值输出为1（`true`）或0（`false`）。对流使用`boolalpha`操纵符可以输出`true`或`false`，还原格式时使用`noboolalpha`操纵符。

```
cout << "default bool values: " << true << " " << false
    << "\nalpha bool values: " << boolalpha
    << true << " " << false << endl;
```

输出：

```
default bool values: 1 0
alpha bool values: true false
```

默认情况下，整型值的输入输出使用十进制。可以使用`hex`、`oct`和`dec`操纵符将其改为十六进制、八进制或改回十进制。

```
cout << "default: " << 20 << " " << 1024 << endl;
cout << "octal: " << oct << 20 << " " << 1024 << endl;
cout << "hex: " << hex << 20 << " " << 1024 << endl;
cout << "decimal: " << dec << 20 << " " << 1024 << endl;
```

输出：

```
default: 20 1024
octal: 24 2000
hex: 14 400
decimal: 20 1024
```

`hex`、`oct`和`dec`操纵符只影响整型运算对象，浮点值的表示形式不受影响。

默认情况下，在输出数值时，没有可见的标识指出当前使用的进制模式。如果需要输出八进制或十六进制值，应该使用`showbase`操纵符。对流应用`showbase`后，在输出结果中会显示进制，显示模式和指定整型常量进制的规范相同。

- 前导`0x`表示十六进制。
- 前导`0`表示八进制。
- 无前导字符表示十进制。

还原格式时使用`noshowbase`操纵符。

```
cout << showbase;    // show the base when printing integral values
cout << "default: " << 20 << " " << 1024 << endl;
cout << "in octal: " << oct << 20 << " " << 1024 << endl;
cout << "in hex: " << hex << 20 << " " << 1024 << endl;
cout << "in decimal: " << dec << 20 << " " << 1024 << endl;
cout << noshowbase;   // reset the state of the stream
```

输出：

```
default: 20 1024
in octal: 024 02000
in hex: 0x14 0x400
in decimal: 20 1024
```

默认情况下，十六进制值（包括前导字符）以小写格式输出。使用`uppercase`操纵符可以输出大写字母。还原格式时使用`nouppercase`操纵符。

```
cout << uppercase << showbase << hex
    << "printed in hexadecimal: " << 20 << " " << 1024
    << nouppercase << noshowbase << dec << endl;
```

输出：

```
printed in hexadecimal: 0X14 0X400
```

浮点数的输出格式涉及三个方面：

- 输出精度（即输出多少个数字）。
- 十六进制、定点十进制或者科学记数法形式输出。
- 没有小数部分的浮点值是否输出小数点。

默认情况下，浮点值按六位数字精度输出；如果浮点值没有小数部分，则不输出小数点；根据浮点数的值选择输出为定点十进制或科学计数法形式：非常大或非常小的值输出为科学记数法形式，其他值输出为定点十进制形式。

默认情况下，精度控制输出的数字总位数。输出时，浮点值按照当前精度四舍五入而非截断。

调用IO对象的`precision`成员或者使用`setprecision`操纵符可以改变精度。

- `precision`成员是重载的。一个版本接受一个`int`值，将精度设置为此值，并返回旧精度值。另一个版本不接受参数，直接返回当前精度值。
- `setprecision`操纵符接受一个参数来设置精度。

`setprecision`操纵符和其他接受参数的操纵符都定义在头文件`iomanip`中。

```
// cout.precision reports the current precision value
cout << "Precision: " << cout.precision()
    << ", Value: " << sqrt(2.0) << endl;
// cout.precision(12) asks that 12 digits of precision be printed
cout.precision(12);
cout << "Precision: " << cout.precision()
    << ", Value: " << sqrt(2.0) << endl;
// alternative way to set precision using the setprecision manipulator
cout << setprecision(3);
cout << "Precision: " << cout.precision()
    << ", Value: " << sqrt(2.0) << endl;
```

输出：

```
Precision: 6, Value: 1.41421
Precision: 12, Value: 1.41421356237
Precision: 3, Value: 1.41
```

定义在头文件`iostream`中的操纵符：

![17-20](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-20.png)

操纵符可以强制流使用科学记数法、定点十进制或十六进制形式输出浮点值。

- `scientific`使用科学记数法表示浮点值。
- `fixed`使用定点十进制表示浮点值。
- `hexfloat`（新标准库）使用十六进制表示浮点值。
- `defaultfloat`（新标准库）将流恢复到默认状态。

除非程序需要控制浮点数的表示方式，否则最好由标准库来选择计数法。

```
cout << "default format: " << 100 * sqrt(2.0) << '\n'
    << "scientific: " << scientific << 100 * sqrt(2.0) << '\n'
    << "fixed decimal: " << fixed << 100 * sqrt(2.0) << '\n'
    << "hexadecimal: " << hexfloat << 100 * sqrt(2.0) << '\n'
    << "use defaults: " << defaultfloat << 100 * sqrt(2.0) << '\n';
```

输出：

```
default format: 141.421
scientific: 1.414214e+002
fixed decimal: 141.421356
hexadecimal: 0x1.1ad7bcp+7
use defaults: 141.421
```

`scientific`、`fixed`和`hexfloat`操纵符会改变流的精度含义。执行这些操纵符后，精度控制的将是小数点后面的数字位数，而默认情况下控制的是数字总位数。

默认情况下，当浮点值的小数部分为0时，不显示小数点。使用`showpoint`操纵符可以强制输出小数点，`noshowpoint`操纵符还原默认行为。

```
cout << 10.0 << endl;        // prints 10
cout << showpoint << 10.0    // prints 10.0000
    << noshowpoint << endl;  // revert to default format for the decimal point
```

按列输出时，通常需要非常精细地控制数据格式。

- `setw`指定下一个数字或字符串值的最小空间。
- `left`表示左对齐输出。
- `right`表示右对齐输出（默认格式）。
- `internal`控制负数的符号位置，它左对齐符号，右对齐值，中间空间用空格填充。
- `setfill`指定一个字符代替默认的空格进行补白。

`setw`类似`endl`，不改变输出流的内部状态，只影响下一次输出的大小。

```
int i = -16;
double d = 3.14159;
// pad the first column to use a minimum of 12 positions in the output
cout << "i: " << setw(12) << i << "next col" << '\n'
    << "d: " << setw(12) << d << "next col" << '\n';
// pad the first column and left-justify all columns
cout << left
    << "i: " << setw(12) << i << "next col" << '\n'
    << "d: " << setw(12) << d << "next col" << '\n'
    << right;   // restore normal justification
// pad the first column and right-justify all columns
cout << right
    << "i: " << setw(12) << i << "next col" << '\n'
    << "d: " << setw(12) << d << "next col" << '\n';
// pad the first column but put the padding internal to the field
cout << internal
    << "i: " << setw(12) << i << "next col" << '\n'
    << "d: " << setw(12) << d << "next col" << '\n';
// pad the first column, using # as the pad character
cout << setfill('#')
    << "i: " << setw(12) << i << "next col" << '\n'
    << "d: " << setw(12) << d << "next col" << '\n'
    << setfill(' ');    // restore the normal pad character
```

输出：

```
i: -16next col
d: 3.14159next col
i: -16 next col
d: 3.14159 next col
i: -16next col
d: 3.14159next col
i: - 16next col
d: 3.14159next col
i: -#########16next col
d: #####3.14159next col
```

头文件`iomanip`中定义的操纵符：
![17-21](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-21.png)
默认情况下，输入运算符会忽略空白字符（空格符、制表符、换行符、换纸符和回车符）。使用`noskipws`操纵符可以让输入运算符读取空白符，`skipws`操纵符还原默认行为。
```
cin >> noskipws;    // set cin so that it reads whitespace
while (cin >> ch)
    cout << ch;
cin >> skipws;      // reset cin to the default state so that it discards whitespace
```

### 未格式化的输入/输出操作（Unformatted Input/Output Operations）

标准库提供了一组低层操作，支持未格式化IO（unformatted IO）。这些操作可以将一个流当作无解释的字节序列来处理。

一些未格式化操作每次处理流的一个字节，它们会读取而不是忽略空白符。

![17-22](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-22.png)

使用未格式化IO操作`get`和`put`可以读取和写入一个字符。

```
char ch;
while (cin.get(ch))
    cout.put(ch);
```

有时读取完一个字符后才发现目前无法处理该字符，希望将其放回流中。标准库提供了三种方法退回字符。

- `peek`返回输入流中下一个字符的副本，但不会将其从流中删除。
- `unget`使输入流向后移动，令最后读取的值回到流中。即使不知道最后从流中读取了什么值，也可以调用`unget`。
- `putback`是特殊版本的`unget`，它退回从流中读取的最后一个值，但它接受一个参数，该参数必须与最后读取的值相同。

一般情况下，在读取下一个值之前，标准库保证程序可以退回最多一个值。

`peek`和无参数的`get`函数都以`int`类型从输入流返回字符。这些函数使用`int`的原因是可以返回文件尾标记。`char`范围中的每个值都表示一个真实字符，因此没有额外的值可以表示文件尾。返回`int`的函数先将要返回的字符转换为`unsigned char`，再将结果提升为`int`。因此即使字符集中有字符映射到负值，返回的`int`也是正值。而标准库使用负值表示文件尾，这样就能保证文件尾与任何合法字符的值都不相同。头文件`cstdio`定义了一个名为`EOF`的常量值，可以用它检测函数返回的值是否是文件尾。

```
int ch;    // use an int, not a char to hold the return from get()
// loop to read and write all the data in the input
while ((ch = cin.get()) != EOF)
    cout.put(ch);
```

一个常见的编程错误是将`get`或`peek`函数的返回值赋给`char`而非`int`对象，但编译器不能发现这个错误。

```
char ch;   // using a char here invites disaster!
// the return from cin.get is converted to char and then compared to an int
while ((ch = cin.get()) != EOF)
    cout.put(ch);
```

当`get`返回`EOF`时，该值会先被转换为`unsigned char`，之后提升得到的`int`值与`EOF`值不再相等，因此循环永远不会停止。

一些未格式化IO操作一次处理大块数据，这些操作可以提高程序执行速度，但需要自己分配并管理用来保存和提取数据的字符数组。

![17-23](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-23.png)

`get`和`getline`函数接受相同的参数，它们的行为类似但不相同。两个函数都一直读取数据，直到遇到下列情况之一：

- 已经读取了`size - 1`个字符。
- 遇到了文件尾（`EOF`）。
- 遇到了分隔符。

两个函数的区别在于处理分隔符的方式：`get`将分隔符留在输入流中作为下一个字符，而`getline`读取并丢弃分隔符。两个函数都不会将分隔符保存在结果数组中。

读取流数据时的一个常见错误是忘记从流中删除分隔符。

一些操作可能从输入流中读取了未知个数的字节，使用`gcount`函数可以确定上一次未格式化输入操作读取了多少字符。`gcount`函数应该在任何后续未格式化输入操作前调用，将字符退回流的操作也属于未格式化输入操作。如果在调用`gcount`前使用了`peek`、`unget`或`putback`操作，则`gcount`的返回值为0。

使用`clear`、`ignore`和`sync`函数可以清空输入流中的数据。读到非法字符时，输入流将处于错误状态。为了继续获取输入数据，先调用`clear`函数重置流的错误标记。再调用`ignore`清空流中指定大小的数据，或者调用`sync`直接清空流中所有数据。`numeric_limits<streamsize>::max()`返回流的缓冲区大小。

```
// 重置错误标志
cin.clear();

// 清除流中所有数据
cin.clear();
cin.ignore(numeric_limits<streamsize>::max());

// 清除流中一行数据
cin.ignore(numeric_limits<streamsize>::max(), '\n');
```

### 流随机访问（Random Access to a Stream）

随机IO本质上是依赖于操作系统的。

为了支持随机访问，IO类型通过维护一个标记来确定下一次读写操作的位置。`seek`函数用于移动标记，`tell`函数用于获取标记。标准库实际上定义了两对`seek`和`tell`函数，一对用于输入流（后缀为`g`，表示get），一对用于输出流（后缀为`p`，表示put）。

![17-24](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-24.png)

虽然标准库为所有流类型都定义了`seek`和`tell`函数，但它们是否有意义取决于流绑定到哪个设备。在大多数系统中，绑定到`cin`、`cout`、`cerr`和`clog`的流不支持随机访问。对这些流可以调用`seek`和`tell`函数，但在运行时会出现错误，流也会被置为无效状态。

从逻辑上考虑，`seek`和`tell`函数的使用范围如下：

- 可以对`istream`、`ifstream`、`istringstream`类型使用`g`版本。
- 可以对`ostream`、`ofstream`、`ostringstream`类型使用`p`版本。
- 可以对`iostream`、`fstream`、`stringstream`类型使用`g`和`p`版本。

一个流中只有一个标记——不存在独立的读标记和写标记。`fstream`和`stringstream`类型可以读写同一个流。在这些类型中，有单一的缓冲区用于保存读写的数据，同时标记也只有一个，表示缓冲区中的当前位置。标准库将两个版本的`seek`和`tell`函数都映射到这个标记。

由于流中只有一个标记，因此在切换读写操作时，必须使用`seek`函数来重定位标记。

`seek`函数有两个重载版本：一个版本使用绝对地址移动流标记；另一个版本使用指定位置和偏移量移动流标记。

```
// set the marker to a fixed position
seekg(new_position);    // set the read marker to the given pos_type location
seekp(new_position);    // set the write marker to the given pos_type location
// offset some distance ahead of or behind the given starting point
seekg(offset, from);    // set the read marker offset distance from from
seekp(offset, from);    // offset has type off_type
```

参数`new_position`和`offset`的类型分别是`pos_type`和`off_type`，这两个类型都是机器相关的，定义在头文件`istream`和`ostream`中。`pos_type`表示文件位置，而`off_type`表示距离当前位置的偏移量，偏移量可以是正数也可以是负数。

`tellg`和`tellp`函数返回一个`pos_type`值，表示流的当前位置。