# Regular Expressions
## 正则表达式
C++ 正则表达式主要有两个类。
- regex：表示一个正则表达式，是 basic_regex 的特化形式；
- smatch：表示正则表达式的匹配结果，是 match_results 的特化形式。
C++ 正则匹配有三个算法，注意它们都是“只读”的，不会变动原字符串。
- regex_match()：完全匹配一个字符串；
- regex_search()：在字符串里查找一个正则匹配；
- regex_replace()：正则查找再做替换。
所以，你只要用 regex 定义好一个表达式，然后再调用匹配算法，就可以立刻得到结果
```c++
auto make_regex = [](const auto& txt)    // 生产正则表达式
{
    return std::regex(txt);
};

auto make_match = []()                  // 生产正则匹配结果
{
    return std::smatch();
};

auto str = "neir:automata"s;          // 待匹配的字符串
auto reg = 
    make_regex(R"(^(\w+)\:(\w+)$)");  // 原始字符串定义正则表达式
auto what = make_match();             // 准备获取匹配的结果
```
这里我先定义了两个简单的 lambda 表达式，生产正则对象，主要是为了方便用 auto 自动类型推导。当然，同时也隐藏了具体的类型信息，将来可以随时变化（这也有点函数式编程的味道了）。
然后我们就可以调用 regex_match() 检查字符串，函数会返回 bool 值表示是否完全匹配正则。如果匹配成功，结果存储在 what 里，可以像容器那样去访问，第 0 号元素是整个匹配串，其他的是子表达式匹配串：
```c++
assert(regex_match(str, what, reg));  // 正则匹配

for(const auto& x : what) {          // for遍历匹配的子表达式
    cout << x << ',';
}

auto str = "god of war"s;             // 待匹配的字符串

auto reg  = 
  make_regex(R"((\w+)\s(\w+))");    // 原始字符串定义正则表达式
auto what = make_match();          // 准备获取匹配的结果

auto found = regex_search(          // 正则查找，和匹配类似
                str, what, reg);

assert(found);                        // 断言找到匹配
assert(!what.empty());                // 断言有匹配结果
assert(what[1] == "god");              // 看第一个子表达式
assert(what[2] == "of");              // 看第二个子表达式

auto new_str = regex_replace(      // 正则替换，返回新字符串
    str,                           // 原字符串不改动
    make_regex(R"(\w+$)"),         // 就地生成正则表达式对象
    "peace"                        // 需要指定替换的文字
);

cout << new_str << endl;          // 输出god of peace
```
这段代码的 regex_search() 搜索了两个连续的单词，然后在匹配结果里以数组下标的形式输出。
regex_replace() 不需要匹配结果，而是要提供一个替换字符串，因为算法是“只读”的，所以它会返回修改后的新字符串。利用这一点，就可以把它的输出作为另一个函数的输入，用“函数套函数”的形式实现“函数式编程”。
在使用 regex 的时候，还要注意正则表达式的成本。因为正则串只有在运行时才会处理，检查语法、编译成正则对象的代价很高，所以尽量不要反复创建正则对象，能重用就重用。在使用循环的时候更要特别注意，一定要把正则提到循环体外。
## regex
正则表达式是一种描述字符序列的方法。C++11新标准增加了正则表达式库，定义在头文件`regex`中，包含多个组件。
![17-5](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-5.png)
`regex`类表示一个正则表达式。
```c
// find the characters ei that follow a character other than c
string pattern("[^c]ei");
// we want the whole word in which our pattern appears
pattern = "[[:alpha:]]*" + pattern + "[[:alpha:]]*";
regex r(pattern);    // construct a regex to find pattern
smatch results;      // define an object to hold the results of a search
// define a string that has text that does and doesn't match pattern
string test_str = "receipt freind theif receive";
// use r to find a match to pattern in test_str
if (regex_search(test_str, results, r))     // if there is a match
    cout << results.str() << endl;     // print the matching word
```
`regex_match`和`regex_search`函数确定一个给定的字符序列与一个`regex`是否匹配。如果整个输入序列与表达式匹配，则`regex_match`函数返回`true`；如果输入序列中的一个子串与表达式匹配，则`regex_search`函数返回`true`。这两个函数的其中一个重载版本接受一个类型为`smatch`的附加参数。如果匹配成功，函数会将匹配信息保存在给定的`smatch`对象中。二者的参数形式如下：
![17-6](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-6.png)
### 使用正则表达式库（Using the Regular Expression Library）
默认情况下，`regex`使用的正则表达式语言是ECMAScript。
定义一个`regex`或者对一个`regex`调用`assign`为其赋新值时，可以指定一些标志来影响`regex`的操作。`ECMAScript`、`basic`、`extended`、`awk`、`grep`和`egrep`这六个标志指定编写正则表达式时所使用的语言。这六个标志中必须设置其中之一，且只能设置一个。默认情况下，`ECMAScript`标志被设置，`regex`会使用ECMA-262规范，这也是很多Web浏览器使用的正则表达式语言。
![17-7](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-7.png)
正则表达式的语法是否正确是在运行期间解析的。如果正则表达式存在错误，标准库会抛出类型为`regex_error`的异常。除了`what`操作外，`regex_error`还有一个名为`code`的成员，用来返回错误类型对应的数值编码。`code`返回的值是由具体实现定义的。RE库能抛出的标准错误如下，`code`返回对应错误的编号（从0开始）。
![17-8](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-8.png)
正则表达式在程序运行时才编译，这是一个非常慢的操作。因此构造一个`regex`对象或者给一个已经存在的`regex`赋值是很耗时间的。为了最小化这种开销，应该尽量避免创建不必要的`regex`。特别是在循环中使用正则表达式时，应该在循环体外部创建`regex`对象。
RE库为不同的输入序列都定义了对应的类型。使用时RE库类型必须与输入类型匹配。
- `regex`类保存`char`类型的正则表达式；`wregex`保存`wchar_t`类型的正则表达式。
- `smatch`表示`string`类型的输入序列；`cmatch`表示字符数组类型的输入序列；`wsmatch`表示`wstring`类型的输入序列；`wcmatch`表示宽字符数组类型的输入序列。
![17-9](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-9.png)
### 匹配与Regex迭代器类型（The Match and Regex Iterator Types）
`regex`迭代器是一种迭代器适配器，它被绑定到一个输入序列和一个`regex`对象上，每种输入类型都有对应的迭代器类型。
`sregex_iterator`操作：
![17-10](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-10.png)
以`sregex_iterator`为例，将`sregex_iterator`绑定到一个`string`和一个`regex`对象时，迭代器自动定位至给定`string`中的第一个匹配位置。即，`sregex_iterator`构造函数对给定`string`和`regex`调用`regex_search`。解引用迭代器时，返回最近一次搜索结果的`smatch`对象。递增迭代器时，它调用`regex_search`在输入`string`中查找下一个匹配位置。
```c++
// find the characters ei that follow a character other than c
string pattern("[^c]ei");
// we want the whole word in which our pattern appears
pattern = "[[:alpha:]]*" + pattern + "[[:alpha:]]*";
regex r(pattern, regex::icase);     // we'll ignore case in doing the match
// it will repeatedly call regex_search to find all matches in file
for (sregex_iterator it(file.begin(), file.end(), r), end_it;
        it != end_it; ++it)
    cout << it->str() << endl;   // matched word
```
![17-11](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-11.png)
匹配类型有两个名为`prefix`和`suffix`的成员，分别返回表示输入序列中当前匹配之前和之后部分的`ssub_match`对象。一个`ssub_match`对象有两个名为`str`和`length`的成员，分别返回匹配的`string`和该`string`的长度。
```c++
// same for loop header as before
for (sregex_iterator it(file.begin(), file.end(), r), end_it;
    it != end_it; ++it)
{
    auto pos = it->prefix().length();    // size of the prefix
    pos = pos > 40 ? pos - 40 : 0;       // we want up to 40 characters
    cout << it->prefix().str().substr(pos)          // last part of the prefix
        << "\n\t\t>>> " << it->str() << " <<<\n"    // matched word
        << it->suffix().str().substr(0, 40)         // first part of the suffix
        << endl;
}
```
![17-12](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-12.png)
`smatch`支持的操作：![17-13](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-13.png)
### 使用子表达式（Using Subexpressions）
正则表达式中的模式通常包含一个或多个子表达式。子表达式是模式的一部分，本身也有意义。正则表达式语法通常用括号表示子表达式。
```
// r has two subexpressions: the first is the part of the file name before the period
// the second is the file extension
regex r("([[:alnum:]]+)\\.(cpp|cxx|cc)$", regex::icase);
```
匹配对象除了提供匹配整体的相关信息外，还可以用来访问模式中的每个子表达式。子匹配是按位置来访问的，第一个子匹配位置为0，表示整个模式对应的匹配，随后是每个子表达式对应的匹配。
子表达式的一个常见用途是验证必须匹配特定格式的数据，如电话号码和电子邮箱地址。
ECMAScript正则表达式语言的一些特性：
- 模式`[[:alnum:]]`匹配任意字母。
- 符号`+`表示匹配一个或多个字符。
- 符号`*`表示匹配零个或多个字符。
- `\{d}`表示单个数字，`\{d}{n}`表示一个n个数字的序列。
- 在方括号中的字符集合表示匹配这些字符中的任意一个。
- 后接`?`的组件是可选的。
- 类似C++，ECMAScript使用反斜线进行转义。由于模式包含括号，而括号是ECMAScript中的特殊字符，因此需要用`\(`和`\)`来表示括号是模式的一部分。
因为反斜线`\`是C++中的特殊字符，所以在模式中使用`\`时，需要一个额外的反斜线进行转义。
子匹配操作：
![17-14](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-14.png)
### 使用regex_replace（Using regex_replace）
正则表达式替换操作：
![17-15](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-15.png)
标准库定义了用于在正则表达式替换过程中控制匹配或格式的标志。这些标志可以传递给`regex_search`、`regex_match`函数或者`smatch`类的`format`成员。匹配和格式化标志的类型为`match_flag_type`，定义在命名空间`regex_constants`中。由于`regex_constants`定义在`std`中，因此在使用这些名字时，需要同时加上两个命名空间的限定符。
![17-16](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/17-16.png)
默认情况下，`regex_replace`输出整个输入序列。未与正则表达式匹配的部分会原样输出，匹配的部分按照格式字符串指定的格式输出。使用`format_no_copy`标志可以只输出匹配部分。
```
// generate just the phone numbers: use a new format string
string fmt2 = "$2.$5.$7 ";    // put space after the last number as a separator
// tell regex_replace to copy only the text that it replaces
cout << regex_replace(s, r, fmt2, format_no_copy) << endl;
```

