## Pair
```c++
pair<T1,T2> p  // Default 构造函数，建立一个pair，其元素类型分别为T1和T2，各自以其default构造函数初始化
pair<T1,T2> p(val1, val2)  // 建立一个pair，元素类型分别为T1和T2，以val1和val2 为初值
pair<T1,T2> p(piecevise_construct, t1, t2) // 建立一个pair，元素类型分别为tuple T1和T2，以tuple t1和t2的元素为初值

p.first 等价于 get<0>(p) // 获得pair内的第一value（直接成员访问）
p.second 等价于 get<1>(p) // 获得pair内的第二value（直接成员访问）
p1 == p2 等价于 p1.first == p2.first && p1.second == p2.second

make_pair(val1, val2) // 返回一个pair，带有val1和val2的类型和数值
```
自C++11起，可以对pair使用一份 tuple-like 接口。因此，你可以使用 tuple_size<>::value 获得元素个数，使用 tuple_element<>::type 获得某指定元素的类型：
```c
typedef std::pair<int, float> IntFloatPair; 
IntFloatPair p(42, 3.14);

std::tuple_size<IntFloatPair>::value //yields 2 
std::tuple_element<0, IntFloatPair>::type//yields int 
```
Copy构造函数同时存在两个版本，版本1接受相同类型的pair，版本2是个member template，在构造过程中需要隐式类型转换时被调用。
Class pair<>提供三个构造函数，用以初始化first和second成员：
```c++
namespace std {
    template <typename T1, typename T2> 
    struct pair {
        pair(const T1& x, const T2& y);
        template<typename U, typename V> pair(U&& x, V&& y); 
        template <typename... Args1, typename... Args2> 
        pair(piecewise_construct_t, tuple<Args1...> first_args, tuple<Args2...> second_args); 
    };
} 
```
如果传递1或2个tuple，最前面两个构造函数允许初始化一个pair，其 first 或 second 是tuple。但第三个构造函数允许传递两个tuple，将其元素传递给 first 和 second 的构造函数。为了强迫执行这样的行为，必须传递 std::piecewise_construct 作为额外的第一实参：
```c++
class Foo {
    public:
    Foo (tuple<int, float>){
        cout << "Foo::Foo(tuple)" << end1; 
    }
    template <typename...Args> Foo (Args... args) {
        cout << "Foo::Foo(args...)" << endl; 
    }
};

int main() {
    tuple<int, float> t(1, 2.22);
    pair<int, Foo> p1 (42, t); // "Foo::Foo(tuple)"
    pair<int, Foo> p2 (piecewise_construct, make_tuple(42), t); // "Foo::Foo(args...)"
}
```
只有当 piecewise_construct 被当作第一实参，并且两个实参是 tuple，class Foo 才会被迫使用那个接受 tuple 的元素而非 tuple 整体的构造函数。因此，第一实参 42 被显式转换为一个 tuple，用的是 make_tuple。
> 注意，这种初始化形式的必要性发生在当需要安放（emplace）一个新元素到 map 或 multimap 中时。

当必须对一个接受pair为实参的函数传递两个value时：
```c++
void f(std::pair<int,const char*>);
void g(std::pair<const int,std::string>); 

void foo(){
    f(std::make_pair(42, "empty")); // f({42, "empty");
    g(std::make_pair(42, "chair")); // g({42, "chair"});
}
```
然而一个表达式如果明白指出类型，便带有一个优势：产生出来的pair将有绝对明确的类型。例如：
```c++
std::pair<int, float>(42, 7.77) 
std::make_pair(42, 7.77) 
```
后者所生成的pair的第二元素的类型是double（因为无任何限定符的浮点字面常量的类型被视为double）。当使用重载函数或template时，确切的类型非常重要。
面对C++11新语义，你可以借由强迫使用move semantic或reference semantic来影响make_pair() 的产出类型。如果你的选择是move semantic，只需使用 move() 声明被传递的实参不再使用。如果你的选择是 reference semantic，就必须使用 ref()，那会强迫形成一个 reference 类型，或使用 cref() 强迫形成一个 constant reference 类型。下面的语句中，有个pair指向某个int两次，因此最终i的值是2：
```c++
int i = 0;
auto p = std::make_pair(std::ref(i), std::ref(i)); // creates pair<int&, int&> 
++p.first;
++p.second;
std::cout<< "i:" << i << std::endl;

// 自C++11起，你也可以使用定义于 <tuple> 内的 tie 接口，抽取出 pair 的 value：
std::pair<char, char> p = std::make_pair('x','y'); 
// pair p 被赋值给一个 tuple，该 tuple 的第二 value 是个 reference，指向 c 
std::tie(std::ignore, c) = p; //extract second value into c (ignore first one) 
```
两个pair互相比较时，第一元素具有较高的优先级。所以如果两个pair的第一元素不相等，其比较结果就成为整个比较的结果。如果first相等，才继续比较second，并把比较结果当作整体结果：
```c++
template <typename T1, typename T2>
bool operator < (const pair<T1,T2>& x, const pair<T1,T2>& y) {
    return x.first < y.first || (!(y.first < x.first） && x.second < y.second);
}
```
## Tuple
tuple呈现出一个异质元素列（heterogeneous list of elements），其中每个类型都可以被指定，或来自编译期推导。class tuple拥有至少10个类型各异的template参数，每个都带有实现赋予的默认类型。未用到的tuple元素也有个默认类型，但没有作用。这实际上就是variadic template的仿效品，只不过又累赘又有限制。
Tuple不是寻常的容器，不允许迭代元素。对于tuple可以使用其成员函数来处理元素，因此必须在编译期知道你打算处理的元素的索引值。运行期才传入一个索引值是不被允许的。
```c++
tuple<T1,T2,...,Tn> t // 以n个给定类型的元素建立一个tuple，以各元素类型的default构造函数完成初始化（基础类型的初值将是0）
tuple<T1,T2&,...,Tn> t(vl,v2,...,vn) // 以n个给定类型的元素建立一个tuple，以给定值完成初始化，tuple的元素类型可以是reference

tuple<T1,T2> t(p) // 建立一个tuple，带有两个元素，分别使用给定之类型，并以给定之pair p为初值（类型必须吻合）
make_tuple(vl, v2,...) // 以传入的所有数值和类型建立一个 tuple，并允许由此 tuple 提取数值
tie(refl, ref2,...)  // 建立一个由reference构成的tuple，并允许由此tuple提取个别数值
```
各个构造函数中，接受不定个数的实参的版本被声明为 explicit，这是为了避免单一值被隐式转换为带着一个元素的tuple。这使得当使用初值列定义tuple内容时不可以使用赋值语法将某个 tuple 初始化，因为那会被视为一个隐式转换，同时也不可以将初值列传至期望获得一个 tuple 的地方，对于tuple，必须明确地将初值转为一个tuple。
```c++
tuple<size_t, size_t, size_t> threeD = { 1, 2, 3 };   // error
tuple<size_t, size_t, size_t> threeD{ 1, 2, 3 };      // ok
```
可以使用`get`访问`tuple`的成员。`get`是一个函数模板，使用时必须指定一个显式模板实参，表示要访问的成员索引。传递给`get`一个`tuple`实参后，会返回其指定成员的引用。
```c++
auto book = get<0>(item);    // returns the first member of item
auto cnt = get<1>(item);     // returns the second member of item
auto price = get<2>(item)/cnt;    // returns the last member of item
get<2>(item) *= 0.8;    // apply 20% discount

std::string s;
auto x = std::make_tuple(s);
std::get<0>(x) = "my value"; // modifies x but not s
auto y = std::make_tuple(ref(s)); // y is of type tuple<string&>, thus y refers to s 
std::get<0>(y) = "my value"; // modifies y and s
```
可以使用`tuple_size`和`tuple_element`这两个辅助类模板查询`tuple`成员的数量和类型。
- `tuple_size`通过一个`tuple`类型来初始化，它有一个名为`value`的静态公有数据成员，类型为`size_t`，表示给定`tuple`中成员的数量。
- `tuple_element`通过一个索引值（整型常量）和一个`tuple`类型来初始化，它有一个名为`type`的公有数据成员，表示给定`tuple`中指定成员的类型。
使用`decltype`可以确定一个对象的类型。
```c++
typedef decltype(item) trans;    // trans is the type of item
// returns the number of members in object's of type trans
size_t sz = tuple_size<trans>::value;    // returns 3
// cnt has the same type as the second member in item
tuple_element<1, trans>::type cnt = get<1>(item);    // cnt is an int
```
`tuple`的关系和相等运算符逐对比较两个`tuple`对象的成员。只有当两个`tuple`的成员数量相等时才可以进行比较。使用`tuple`的相等或不等运算符时，每对成员必须支持`==`运算符；使用`tuple`的关系运算符时，每对成员必须支持`<`运算符。
由于`tuple`定义了`<`和`==`运算符，因此`tuple`序列可以被传递给算法，无序容器的关键字也可以使用`tuple`类型。
如果你打算改动 tuple 内的一个既有值:
```c++
// 提取 tuple 的元素值，将某些变量值设给它们
std::tuple <int, float, std::string> t(77, 1.1, "more light"); 
int i;
float f; 
std::string s;
std::make_tuple(std::ref(i), std::ref(f), std::ref(s)) = t;

// tie 可以建立一个内含 reference 的 tuple：
std::tie(i, f, s) = t; // assigns values of t to i, f, and s
// 这里的 tie(i, f, s) 会以 i、f 和 s 的 reference 建立起一个 tuple， 因此上述赋值操作其实就是将 t 内的元素分别赋值为 i、f 和 s

// ignore 允许忽略 tuple 的某些元素，也就是可以用它来局部提取 tuple 的元素值：
std::tie(i, std::ignore, s) = t; // assigns first and third value of t to i and s 
```
