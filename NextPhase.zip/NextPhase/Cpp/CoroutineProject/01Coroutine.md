# Thread
`C++11` 提供的 `thread` 类也是基于 `pthread` 实现的，但 `C++11` 里面没有提供 `RWMutex`，`Spinlock` 等，在高并发场景，这些对象是经常需要用到的，因此所以选择自己封装 `pthread`。
`sylar` 的线程类只支持 `void(void)` 类型的入口函数，不支持给线程传参数，但实际使用时可以结合 `std::bind` 来绑定参数，这样就相当于支持任何类型和数量的参数。每个线程都有两个线程局部变量，一个用于存储当前线程的 `Thread` 指针，另一个存储线程名称，通过 `Thread::GetThis()` 可以拿到当前线程的指针。
`sylar` 的线程类可以保证在构造完成之后线程函数一定已经处于运行状态，这是通过一个信号量来实现的，构造函数在创建线程后会一直阻塞，直到线程函数运行并且通知信号量，构造函数才会返回，而构造函数一旦返回，就说明线程函数已经在执行。
基于 `pthread` 实现以下线程同步类：
- `Semaphore`: 计数信号量，基于 `sem_t` 实现  
- `Mutex`: 互斥锁，基于 `pthread_mutex_t` 实现  
- `RWMutex`: 读写锁，基于 `pthread_rwlock_t` 实现  
- `Spinlock`: 自旋锁，基于 `pthread_spinlock_t` 实现  
- `CASLock`: 原子锁，基于 `std::atomic_flag` 实现
# Coroutine
创建协程是把一个函数包装成一个协程对象，然后再用协程的方式运行这个函数。
协程调度是创建一个调度协程，通过调度协程把这些协程对象一个一个消化掉，协程可以在被调度时继续向调度器添加新的调度任务。
`IO` 协程调度是在调度协程时，如果发现这个协程在等待 `IO` 就绪，那就先让这个协程让出执行权，等对应的 `IO` 就绪后再重新恢复这个协程的运行。
所谓定时器，就是给调度协程预设一个协程对象，达到定时时间后恢复预设的协程对象。
## Design
### Symmetric And Asymmetric Coroutines
`sylar` 使用非对称协程模型。
对称协程指的是任何⼀个协程都是相互独⽴且平等的，协程可以不受限制地将控制权交给任何其他协程。⾮对称协程，是指协程之间存在类似堆栈的调用方与被调用方关系，协程让出调度权的⽬标只能是它的调⽤者。
对称协程更灵活，⾮对称协程实现更简单。在对称协程中，⼦协程可以直接和⼦协程切换，也就是说每个协程不仅要运⾏⾃⼰的⼊⼝函数代码，还要负责选出下⼀个合适的协程进⾏切换，相当于每个协程都要充当调度器的⻆⾊，这样程序设计起来会⽐较麻烦，并且程序的控制流也会变得复杂和难以管理。⽽在⾮对称协程中，可以使用专⻔的调度器来负责调度协程，每个协程只需要运⾏⾃⼰的⼊⼝函数，然后挂起或结束时将运⾏权交回给调度器，由调度器来选出下⼀个要执⾏的协程即可。如果子协程可以和子协程切换，那就相当于变相赋予子协程调度的权利，这在非对称协程里是不允许的。
### Design
`sylar` 借助线程局部变量 `thread_local` 来实现协程模块，因为协程是在线程里运行的，不同线程的协程相互不影响，每个线程都要独自处理当前线程的协程切换问题。线程局部变量与全局变量类似，不同之处在于声明的线程局部变量在每个线程都独有一份，而全局变量是全部线程共享一份。
对于每个线程的协程上下文，`sylar` 设计两个线程局部变量 `t_fiber` 和 `t_thread_fiber` 来存储上下文信息 。
`sylar` 只使用 `swapcontext` 来做协程切换，这意味着两个线程局部变量必须至少有一个是用来保存线程主协程的上下文的，如果这两个线程局部变量存储的都是子协程的上下文，就无法恢复主协程的上下文。
如果将线程的局部变量设置成一个类似链表的数据结构，那理论上应该也可以实现对称协程，也就是子协程可以直接和子协程切换，但代码复杂度上肯定会增加不少，因为要考虑多线程和公平调度的问题。`sylar` 的非对称协程代码实现简单，并且在后面实现协程调度时可以做到公平调度，缺点是子协程只能和线程主协程切换，意味着子协程无法创建并运行新的子协程，并且在后面实现协程调度时，完成一次子协程调度需要额外多切换一次上下文。
### Coroutine State
这里在 `sylar` 的基础上进行简化，对每个协程，只设计 3 种状态，分别是 `READY` 代表就绪态，`RUNNING` 代表运行态，`TERM` 代表运行结束。
与 `sylar` 版本的实现相比，去掉 `INIT` 状态，`HOLD` 状态，和 `EXCEPT` 状态。`sylar` 的 `INIT` 状态是协程对象刚创建时的状态，这个状态可以直接归到 READY 状态里，sylar 的 `HOLD` 状态和 `READY` 状态与协程调度有关，`READY` 状态的协程会被调度器自动重新调度，而 `HOLD` 状态的协程需要显式地再次将协程加入调度，这两个状态也可以归到 `READY` 状态里。而 `EXCEPT` 状态，表示协程入口函数执行时出现异常的状态，不区分协程是异常结束还是正常结束，只要结束就是 `TERM` 状态。
状态简化后，唯一的缺陷是无法区分一个 `READY` 状态的协程对象是刚创建，还是已经运行到一半被挂起，这在重置协程对象时有影响。重置协程时，如果协程对象只是刚创建但一次都没运行过，那应该是允许重置的，但如果协程的状态是运行到一半被挂起，那应该不允许重置。虽然可以把 `INIT` 状态加上以区分 `READY` 状态，但也可以让协程只有在 `TERM` 状态下才允许重置，从而实现简化。
## Implement Of The Coroutine
### Ucontext_t Interface
协程模块基于 `ucontext_t` 实现，关于 `ucontext_t` 的定义和相关的接口如下：
```cpp
// 上下文结构体定义
// 这个结构体是平台相关的，因为不同平台的寄存器不一样
// 下面列出的是所有平台都至少会包含的4个成员
typedef struct ucontext_t {
    // 当前上下文结束后，下一个激活的上下文对象的指针，只在当前上下文是由makecontext创建时有效
    struct ucontext_t *uc_link;
    // 当前上下文的信号屏蔽掩码
    sigset_t          uc_sigmask;
    // 当前上下文使用的栈内存空间，只在当前上下文是由makecontext创建时有效
    stack_t           uc_stack;
    // 平台相关的上下文具体内容，包含寄存器的值
    mcontext_t        uc_mcontext;
    ...
} ucontext_t;
 
// 获取当前的上下文
int getcontext(ucontext_t *ucp);
 
// 恢复ucp指向的上下文，这个函数不会返回，而是会跳转到ucp上下文对应的函数中执行，相当于变相调用了函数
int setcontext(const ucontext_t *ucp);
 
// 修改由getcontext获取到的上下文指针ucp，将其与一个函数func进行绑定，支持指定func运行时的参数，
// 在调用makecontext之前，必须手动给ucp分配一段内存空间，存储在ucp->uc_stack中，这段内存空间将作为func函数运行时的栈空间，
// 同时也可以指定ucp->uc_link，表示函数运行结束后恢复uc_link指向的上下文，
// 如果不赋值uc_link，那func函数结束时必须调用setcontext或swapcontext以重新指定一个有效的上下文，否则程序就跑飞了
// makecontext执行完后，ucp就与函数func绑定，调用setcontext或swapcontext激活ucp时，func就会被运行
void makecontext(ucontext_t *ucp, void (*func)(), int argc, ...);
 
// 恢复ucp指向的上下文，同时将当前的上下文存储到oucp中，
// 和setcontext一样，swapcontext也不会返回，而是会跳转到ucp上下文对应的函数中执行，相当于调用了函数
// swapcontext是sylar非对称协程实现的关键，线程主协程和子协程用这个接口进行上下文切换
int swapcontext(ucontext_t *oucp, const ucontext_t *ucp);
```
### Class Interface
```cpp
class Fiber : public std::enable_shared_from_this<Fiber> {
public:
    typedef std::shared_ptr<Fiber> ptr;

    /**
     * @brief 协程状态
     */
    enum State {
        /// 就绪态，刚创建或者yield之后的状态
        READY,
        /// 运行态，resume之后的状态
        RUNNING,
        /// 结束态，协程的回调函数执行完之后为TERM状态
        TERM
    };

private:
    /**
     * @brief 构造函数
     * @attention 无参构造函数只用于创建线程的第一个协程，也就是线程主函数对应的协程，
     * 这个协程只能由GetThis()方法调用，所以定义成私有方法
     */
    Fiber();

public:
    /**
     * @brief 构造函数，用于创建用户协程
     * @param[in] cb 协程入口函数
     * @param[in] stacksize 栈大小
     * @param[in] run_in_scheduler 本协程是否参与调度器调度，只有主协程和调度器协程不参与调度为false，其他为true。默认为true
     */
    Fiber(std::function<void()> cb, size_t stacksize = 0, bool run_in_scheduler = true);

    /**
     * @brief 析构函数
     */
    ~Fiber();

    /**
     * @brief 重置协程状态和入口函数，复用栈空间，不重新创建栈
     * @param[in] cb 
     */
    void reset(std::function<void()> cb);

    /**
     * @brief 将当前协程切到到执行状态
     * @details 当前协程和正在运行的协程进行交换，前者状态变为RUNNING，后者状态变为READY
     */
    void resume();

    /**
     * @brief 当前协程让出执行权
     * @details 当前协程与上次resume时退到后台的协程进行交换，前者状态变为READY，后者状态变为RUNNING
     */
    void yield();

    /**
     * @brief 获取协程ID
     */
    uint64_t getId() const { return m_id; }

    /**
     * @brief 获取协程状态
     */
    State getState() const { return m_state; }

public:
    /**
     * @brief 设置当前正在运行的协程，即设置线程局部变量t_fiber的值
     */
    static void SetThis(Fiber *f);

    /**
     * @brief 返回当前线程正在执行的协程
     * @details 如果当前线程还未创建协程，则创建线程的第一个协程，
     * 且该协程为当前线程的主协程，其他协程都通过这个协程来调度，其他协程结束时，
     * 都要切回到主协程，由主协程重新选择新的协程进行resume
     * @attention 线程如果要创建协程，那么应先执行一下Fiber::GetThis()，以初始化主协程
     */
    static Fiber::ptr GetThis();

    /**
     * @brief 获取总协程数
     */
    static uint64_t TotalFibers();

    /**
     * @brief 协程入口函数
     */
    static void MainFunc();

    /**
     * @brief 获取当前协程id
     */
    static uint64_t GetFiberId();

private:
    /// 协程id
    uint64_t m_id        = 0;
    /// 协程栈大小
    uint32_t m_stacksize = 0;
    /// 协程状态
    State m_state        = READY;
    /// 协程上下文
    ucontext_t m_ctx;
    /// 协程栈地址
    void *m_stack = nullptr;
    /// 协程入口函数
    std::function<void()> m_cb;
    /// 本协程是否参与调度器调度
    bool m_runInScheduler;
};
```
此外，定义两个全局静态变量，用于生成协程 `id` 和统计当前的协程数，如下：
```cpp
/// 全局静态变量，用于生成协程id
/// 通过全局静态变量 s_fiber_id 的自增来生成协程 id
/// 每创建一个新协程，s_fiber_id 作为新协程的 id，然后自增。
static std::atomic<uint64_t> s_fiber_id{0};
/// 全局静态变量，用于统计当前的协程数
static std::atomic<uint64_t> s_fiber_count{0};
```
对于每个线程，`sylar` 设计以下两个线程局部变量用于保存协程上下文信息：
```cpp
/// 线程局部变量，当前线程正在运行的协程
static thread_local Fiber *t_fiber = nullptr;
/// 线程局部变量，当前线程的主协程，切换到这个协程，就相当于切换到了主线程中运行，智能指针形式
static thread_local Fiber::ptr t_thread_fiber = nullptr;
```
这两个线程局部变量保存的协程上下文对协程的实现至关重要，它们的用途如下：
- `t_fiber`：保存当前正在运行的协程指针，必须时刻指向当前正在运行的协程对象，
- `t_thread_fiber`：保存线程主协程指针，智能指针形式，当子协程 `resume` 时，通过 `swapcontext` 将主协程的上下文保存到 `t_thread_fiber` 的 `ucontext_t` 成员中，同时激活子协程的 `ucontext_t` 上下文。当子协程挂起时，从 `t_thread_fiber` 中取得主协程的上下文并恢复运行。
协程模块初始化时，`t_fiber` 和 `t_thread_fiber` 指向线程主协程对象。
由于 `t_fiber` 和 `t_thread_fiber` 一个是原始指针一个是智能指针，混用时要注意智能指针的引用计数问题，不恰当的混用可能导致协程对象已经运行结束，但未析构问题。
### Ctor
`Fiber` 类提供两个构造函数。
无参构造函数用于初始化主协程的状态，被定义成私有方法，不允许在类外部调用，只通过 `GetThis()` 方法调用构造主协程。线程主协程代表线程入口函数或是 `main` 函数所在的协程，这两种函数都不是以协程的手段创建的，所以它们只有 `ucontext_t` 上下文，但没有入口函数，也没有分配栈空间。
带参构造函数用于构造子协程，初始化子协程的 `ucontext_t` 上下文和栈空间，要求必须传入协程的入口函数，以及可选的协程栈大小。
```cpp
Fiber::Fiber() {
    SetThis(this); // 调用无参构造函数的协程就是当前正在运行的协程，即主协程
    m_state = RUNNING;

    if (getcontext(&m_ctx)) {
        assert(false, "getcontext");
    }

    ++s_fiber_count;
    m_id = s_fiber_id++; // 协程id从0开始，用完加1
}

Fiber::Fiber(std::function<void()> cb, size_t stacksize, bool run_in_scheduler)
    : m_id(s_fiber_id++)
    , m_cb(cb)
    , m_runInScheduler(run_in_scheduler) {
    ++s_fiber_count;
    m_stacksize = stacksize ? stacksize : g_fiber_stack_size->getValue();
    m_stack     = StackAllocator::Alloc(m_stacksize);

    if (getcontext(&m_ctx)) {
        SYLAR_ASSERT2(false, "getcontext");
    }
    
    // 协程函数结束时会调用 swapcontext 以重新指定一个有效的上下文
    // 因此不赋值 uc_link
    m_ctx.uc_link          = nullptr;
    m_ctx.uc_stack.ss_sp   = m_stack;
    m_ctx.uc_stack.ss_size = m_stacksize;

    makecontext(&m_ctx, &Fiber::MainFunc, 0); // 切换到m_ctx就会执行MainFunc
}

Fiber::~Fiber() {
    --s_fiber_count;
    if (m_stack) {
        // 有栈，说明是子协程，需要确保子协程一定是结束状态
        SYLAR_ASSERT(m_state == TERM);
        StackAllocator::Dealloc(m_stack, m_stacksize);
    } else { // 线程的主协程析构时需要特殊处理，因为主协程没有分配栈和cb
        // 没有栈，说明是线程的主协程
        SYLAR_ASSERT(!m_cb);              // 主协程没有cb
        SYLAR_ASSERT(m_state == RUNNING); // 主协程一定是执行状态

        Fiber *cur = t_fiber; // 当前协程就是自己
        if (cur == this) {
            SetThis(nullptr);
        }
    }
}
```
### SetThis/GetThis
`GetThis()` 方法返回当前线程正在执行的协程，如果当前线程还未创建协程，则调用无参构造函数创建线程的的主协程，因为 `GetThis()` 兼具创建主协程的功能，在使用协程之前必须显式调用一次。
`SetThis()` 方法设置当前线程此时正在运行的协程。
```cpp
void Fiber::SetThis(Fiber *f) {
    t_fiber = f;
}

Fiber::ptr Fiber::GetThis() {
    if (t_fiber != nullptr) {
        return t_fiber->shared_from_this();
    }

    const Fiber::ptr mainFiber(new Fiber());
    SYLAR_ASSERT(t_fiber == mainFiber.get());
    t_thread_fiber = mainFiber;
    return t_fiber->shared_from_this();
}

uint64_t Fiber::GetFiberId() {
    if (t_fiber) {
        return t_fiber->getId();
    }
    return 0;
}
```
### Resume/Yield
在实现协程调度之前，子协程不能直接 `resume` 另一个子协程，如果子协程在其内部执行另一个协程的 `resume`，`swapcontext` 会把子协程的上下文保存到 `t_thread_fiber` 中，导致 `t_thread_fiber` 不再指向 `main` 函数的上下文，因此只能由 `main` 的主协程调度子协程。
在非对称协程中实现协程调度之后，根据协程的运行环境确定是和线程主协程进行交换还是和调度协程进行交换，并根据三个线程局部变量切换到指定的协程上下文：
- 如果协程不参与调度器调度，`resume` 的执行环境一定位于线程主协程里，所以 `swapcontext` 把主协程的上下文保存到 `t_thread_fiber->m_ctx` 中，同时恢复子协程的上下文。如果协程参与调度器调度，那么应该和调度线程的调度协程进行 `swap`，而不是线程主协程。
- 如果协程不参与调度器调度，`yield` 的执行环境一定位于线程子协程里，所以 `swapcontext` 把子协程的上下文保存到协程自己的 `m_ctx` 中，同时从 `t_thread_fiber` 恢复主协程的上下文。如果协程参与调度器调度，那么应该和调度线程的调度协程进行 `swap`，而不是线程主协程。
```cpp
void Fiber::resume() {
    SYLAR_ASSERT(m_state != TERM && m_state != RUNNING);
    SetThis(this); // 设置当前正在运行的协程，即调用对象
    m_state = RUNNING;

    if (m_runInScheduler) {
        if (swapcontext(&(Scheduler::GetMainFiber()->m_ctx), &m_ctx)) {
            SYLAR_ASSERT2(false, "swapcontext");
        }
    } else {
        if (swapcontext(&(t_thread_fiber->m_ctx), &m_ctx)) {
            SYLAR_ASSERT2(false, "swapcontext");
        }
    }
}

void Fiber::yield() {
    /// 协程运行完之后会自动yield一次，用于回到主协程，此时状态已为结束状态
    SYLAR_ASSERT(m_state == RUNNING || m_state == TERM);
    SetThis(t_thread_fiber.get());
    if (m_state != TERM) m_state = READY;

    if (m_runInScheduler) {
        if (swapcontext(&m_ctx, &(Scheduler::GetMainFiber()->m_ctx))) {
            SYLAR_ASSERT2(false, "swapcontext");
        }
    } else {
        if (swapcontext(&m_ctx, &(t_thread_fiber->m_ctx))) {
            SYLAR_ASSERT2(false, "swapcontext");
        }
    }
}
```
### MainFunc
`sylar` 在用户传入的协程入口函数上进行一次封装，通过封装协程入口函数，可以实现协程在结束自动执行 `yield` 的操作。
```cpp
/**
 * @brief  协程入口函数
 * @note 这里没有处理协程函数出现异常的情况，同样是为简化状态管理，并且个人认为协程的异常不应该由框架处理，应该由开发者自行处理
 */
void Fiber::MainFunc() {
    Fiber::ptr cur = GetThis(); // GetThis()中shared_from_this()方法让引用计数加1
    SYLAR_ASSERT(cur);

    cur->m_cb(); // 这里真正执行协程的入口函数

    // 协程执行结束后重置状态
    cur->m_cb    = nullptr;
    cur->m_state = TERM;
    
    auto raw_ptr = cur.get(); 
    cur.reset(); // 使智能指针不再指向执行结束的协程，即引用计数减 1
    // 若其它地方再没有调用 GetThis() 获得此协程，该协程将会自动销毁

    // yield中会重新指定一个有效的上下文，因此上述 uc_link 不需要赋值
    raw_ptr->yield(); // 协程结束时yield，以回到主协程
}
```
### Reset
重置协程就是重复利用已结束的协程，复用其栈空间，创建新协程，实现如下：
```cpp
/**
 * 这里为简化状态管理，强制只有TERM状态的协程才可以重置，但其实刚创建好但没执行过的协程也应该允许重置的
 */
void Fiber::reset(std::function<void()> cb) {
    SYLAR_ASSERT(m_stack);
    SYLAR_ASSERT(m_state == TERM);
    m_cb = cb;
    if (getcontext(&m_ctx)) {
        SYLAR_ASSERT2(false, "getcontext");
    }
    // 同样，不赋值，协程函数结束时会调用 swapcontext 以重新指定一个有效的上下文
    m_ctx.uc_link          = nullptr; 
    m_ctx.uc_stack.ss_sp   = m_stack;
    m_ctx.uc_stack.ss_size = m_stacksize;

    makecontext(&m_ctx, &Fiber::MainFunc, 0);
    m_state = READY;
}
```
# Coroutines Scheduling
## Design
对于每个协程，都需要用户手动调用协程的 `resume` 方法将协程运行起来，然后等协程运行结束并返回，再运行下一个协程。这种运行协程的方式相当于用户在充当调度器，引入协程调度后，可以创建一个协程调度器，将需要调度的协程传递给调度器，由调度器选择调度线程负责调度，调度线程调度时会创建调度协程用于调度任务。
从某种程度来看，协程调度其实非常简单，简单到用下面的代码就可以实现一个调度器，这个调度器可以添加调度任务，运行调度任务，并且还是完全公平调度的，先添加的任务先执行，后添加的任务后执行。
```cpp
class Scheduler {
public:
    /**
     * @brief 添加协程调度任务
     */
    void schedule(sylar::Fiber::ptr task) {
        m_tasks.push_back(task);
    }
 
    /**
     * @brief 执行调度任务
     */
    void run() {
        sylar::Fiber::ptr task;
        auto it = m_tasks.begin();
 
        while(it != m_tasks.end()) {
            task = *it;
            m_tasks.erase(it++);
            task->resume();
        }
    }
private:
    /// 任务队列
    std::list<sylar::Fiber::ptr> m_tasks;
};
 
void test_fiber(int i) {
    std::cout << "hello world " << i << std::endl;
}
 
int main() {
    /// 初始化当前线程的主协程
    sylar::Fiber::GetThis();
 
    /// 创建调度器
    Scheduler sc;
 
    /// 添加调度任务
    for(auto i = 0; i < 10; i++) {
        sylar::Fiber::ptr fiber(new sylar::Fiber(
            std::bind(test_fiber, i)
        ));
        sc.schedule(fiber);
    }
 
    /// 执行调度任务
    sc.run();
 
    return 0;
}
```
## Implement
### Scheduler Class Interface
一个线程同一时刻只能运行一个协程，因此需要多线程并行运行多个协程，调度器内部需要维护一个任务队列和一个调度线程池。开始调度后，所有调度线程的调度协程按顺序从任务队列里取任务执行，并且调度线程可以调度器所在的线程 `caller` 线程。当全部任务都执行完后，线程池停止调度，等新的任务进来。当添加新任务时，通知线程池有新的任务，线程池重新开始运行调度。停止调度时，各调度线程退出，调度器停止工作。
综上，`sylar` 的协程调度模块支持多线程，支持使用 `caller` 线程进行调度，支持添加函数或协程作为调度对象，并且支持将函数或协程绑定到一个具体的线程上执行。
```cpp
class Scheduler {
public:
    typedef std::shared_ptr<Scheduler> ptr;
    typedef Mutex MutexType;

    /**
     * @brief 创建调度器
     * @param[in] threads 线程数  疑问？？什么线程数量，好像是不包含call_main线程
     * @param[in] use_caller 是否将当前线程也作为调度线程
     * @param[in] name 名称
     */
    Scheduler(size_t threads = 1, bool use_caller = true, const std::string &name = "Scheduler");

    /**
     * @brief 析构函数
     */
    virtual ~Scheduler();

    /**
     * @brief 获取调度器名称
     */
    const std::string &getName() const { return m_name; }

    /**
     * @brief 获取当前线程调度器指针
     */
    static Scheduler *GetThis();

    /**
     * @brief 获取当前线程的主协程
     */
    static Fiber *GetMainFiber();

    /**
     * @brief 添加调度任务
     * @tparam FiberOrCb 调度任务类型，可以是协程对象或函数指针
     * @param[] fc 协程对象或指针
     * @param[] thread 指定运行该任务的线程号，-1表示任意线程
     */
    template <class FiberOrCb>
    void schedule(FiberOrCb fc, int thread = -1) {
        bool need_tickle = false;
        {
            MutexType::Lock lock(m_mutex);
            need_tickle = scheduleNoLock(fc, thread);
        }

        if (need_tickle) {
            tickle(); // 唤醒idle协程
        }
    }

    /**
     * @brief 启动调度器的其他工作线程，并没有真正的开始调度
     */
    void start();

    /**
     * @brief 停止调度器，等所有调度任务都执行完了再返回
     */
    void stop();

protected:
    /**
     * @brief 通知协程调度器有任务了
     */
    virtual void tickle();

    /**
     * @brief 协程调度函数,真正的开始调度（死循环）
     *
     */
        void run();

    /**
     * @brief 无任务调度时执行idle协程
     */
    virtual void idle();

    /**
     * @brief 返回是否可以停止
     * todo：感觉这个函数是否没有必要？因为在运行到这里的时候m_stopping变量一定为false
     */
    virtual bool stopping();

    /**
     * @brief 设置当前的协程调度器，将当前类设置为当前线程的协程调度器
     */
    void setThis();

    /**
     * @brief 返回是否有空闲线程
     * @details 当调度协程进入idle时空闲线程数加1，从idle协程返回时空闲线程数减1
     */
    bool hasIdleThreads() { return m_idleThreadCount > 0; }

private:
    /**
     * @brief 添加调度任务，无锁
     * @tparam FiberOrCb 调度任务类型，可以是协程对象或函数指针
     * @param[] fc 协程对象或指针
     * @param[] thread 指定运行该任务的线程号，-1表示任意线程
     */
    template <class FiberOrCb>
    bool scheduleNoLock(FiberOrCb fc, int thread) {
        const bool need_tickle = m_tasks.empty();
        ScheduleTask task(fc, thread);
        if (task.fiber || task.cb) {
            m_tasks.push_back(task);
        }
        return need_tickle;
    }

private:
    struct ScheduleTask {
        Fiber::ptr fiber;
        std::function<void()> cb;
        int thread;

        ScheduleTask(Fiber::ptr f, int thr) {
            fiber  = f;
            thread = thr;
        }
        ScheduleTask(Fiber::ptr *f, int thr) {
            fiber.swap(*f);
            thread = thr;
        }
        ScheduleTask(std::function<void()> f, int thr) {
            cb     = f;
            thread = thr;
        }
        ScheduleTask() { thread = -1; }

        //调度任务类的变量全部置为无效的
        void reset() {
            fiber  = nullptr;
            cb     = nullptr;
            thread = -1;
        }
    };

private:
    /// 协程调度器名称
    std::string m_name;
    /// 互斥锁
    MutexType m_mutex;
    /// 线程池
    std::vector<Thread::ptr> m_threads;
    /// 任务队列
    std::list<ScheduleTask> m_tasks;
    /// 线程池的线程ID数组
    std::vector<int> m_threadIds;
    /// 工作线程数量，不包含use_caller的主线程
    size_t m_threadCount = 0;
    /// 活跃线程数
    std::atomic<size_t> m_activeThreadCount = {0};
    /// idle线程数
    std::atomic<size_t> m_idleThreadCount = {0};

    /// 是否use caller
    bool m_useCaller;
    /// use_caller为true时，调度器所在线程的caller协程
    Fiber::ptr m_rootFiber;
    /// use_caller为true时，调度器所在线程的id , 其实就是caller线程
    int m_rootThread = 0;

    /// 是否正在停止
    bool m_stopping = false;
};
```
此外，定义协程调度模块的线程局部变量：
```cpp
/// 当前线程的调度器，同一个调度器下的所有线程指同同一个调度器实例
static thread_local Scheduler *t_scheduler = nullptr;
/// 当前线程的调度协程，每个线程都独有一份，包括 caller 线程
/// 加上 Fiber 模块的 t_fiber 和 t_thread_fiber，每个线程可以记录三个协程的上下文信息
static thread_local Fiber *t_scheduler_fiber = nullptr;
```
调度器对象会在线程作用域结束后被销毁，因此用 `t_scheduler` 记录当前线程的调度器，从而使某个线程运行结束时可以正确销毁自己所用的调度器，因为线程可以共享一个调度器，也可以自己创建新的调度器，一个线程不能销毁不是自己所共享的调度器。
### ScheduleTask
对于协程调度器来说，协程和函数都可以作为调度任务，只需要将函数包装成协程即可。因此任务类型可以是协程/函数二选一，并且可指定调度线程。
### Ctor
为支持使用 `caller` 线程进行调度，当 `use_caller` 参数为 `true` 时，表示使用 `caller` 线程作为调度线程。构造函数支持传入所需要的调度线程数，若选择使用 `caller` 线程作为调度线程，则线程数减 1，在初始化用于 `caller` 线程调度的调度协程。
```cpp
Scheduler::Scheduler(size_t threads, bool use_caller, const std::string &name) {
    SYLAR_ASSERT(threads > 0);

    m_useCaller = use_caller;
    m_name      = name;
    m_threadCount = threads;
    
    if (use_caller) {
        --threads;
        // GetThis() 兼具创建主协程的功能，在使用协程之前必须显式调用一次
        cafba::Fiber::GetThis();
        SYLAR_ASSERT(GetThis() == nullptr);
        t_scheduler = this; // 设置自己所共享的调度器

        // 创建 caller 线程的调度协程
        m_rootFiber.reset(new Fiber(std::bind(&Scheduler::run, this), 0, false));
        t_scheduler_fiber = m_rootFiber.get();
        
        cafba::Thread::SetName(m_name);
        m_rootThread      = cafba::GetThreadId(); // caller 线程 ID
        m_threadIds.push_back(m_rootThread);      // 在线程池中记录 ID
    } else {
        m_rootThread = -1;  // -1 表示不使用 caller 线程 
    }
}

Scheduler::~Scheduler() {
    SYLAR_LOG_DEBUG(g_logger) << "Scheduler::~Scheduler()";
    SYLAR_ASSERT(m_stopping);
    if (GetThis() == this) t_scheduler = nullptr;
}
```
### Schedule
`schedule` 只用于添加调度任务，支持传入协程或函数，并且支持一个线程号参数，表示是否将这个协程或函数绑定到一个具体的线程上执行。在多线程环境中，多个线程可能会同时调度任务，如果不加锁，可能会导致数据竞争，所以需要互斥锁确保在任何时刻只有一个线程可以执行 `scheduleNoLock` 中的代码。
若当前任务队列为空，那么在添加任务之后，要调用一次 `tickle` 方法通知线程池有新任务到来。但只有 `IO` 调度器的 `Tickle/Idle` 才有实际作用，普通调度器只是忙等待直到队列有任务。
```cpp
/**
 * @brief 添加调度任务
 * @tparam FiberOrCb 调度任务类型，可以是协程对象或函数指针
 * @param[] fc 协程对象或指针
 * @param[] thread 指定运行该任务的线程号，-1表示任意线程
 */
template <class FiberOrCb>
void schedule(FiberOrCb fc, int thread = -1) {
    bool need_tickle = false;
    {
        MutexType::Lock lock(m_mutex);
        need_tickle = scheduleNoLock(fc, thread);
    }

    if (need_tickle) tickle(); // 唤醒idle协程
}

template <class FiberOrCb>
bool scheduleNoLock(FiberOrCb fc, int thread) {
    const bool need_tickle = m_tasks.empty();
    ScheduleTask task(fc, thread);
    if (task.fiber || task.cb) m_tasks.push_back(task);
    return need_tickle;
}
```
### Start
`start` 方法调用后会创建调度线程池，线程数量由初始化时的线程数和 `use_caller` 确定。调度线程一旦创建，就会执行 `run` 函数从任务队列里取任务执行。
当初始化时指定线程数为 `1` 且 `use_caller` 为 `true` 时，不需要创建新线程用于调度，只由 `caller` 线程的调度协程来负责调度协程，`caller` 线程也不进入线程池，因此 `caller` 线程的调度逻辑与线程池中的线程不一样，由 `stop` 方法负责。
```cpp
void Scheduler::start() {
    MutexType::Lock lock(m_mutex);
    if (m_stopping) return; // 调度器处于停止状态
    SYLAR_ASSERT(m_threads.empty());
    m_threads.resize(m_threadCount);
    for (size_t i = 0; i < m_threadCount; i++) {
        m_threads[i].reset(new Thread(std::bind(&Scheduler::run, this),
                                      m_name + "_" + std::to_string(i)));
        m_threadIds.push_back(m_threads[i]->getId());
    }
}
```
### Run
调度协程负责从调度器的任务队列中取任务执行，取出的任务即子协程，这里调度协程和子协程的切换模型即非对称模型，每个子协程执行完后都必须返回调度协程，再由调度协程重新从任务队列中取新的子协程并执行。
当调度器没有协程可调度时，调度协程应该有一些同步手段，比如调度协程阻塞在一个 `idle` 协程上，等待新任务加入后退出 `idle` 协程，恢复调度。然而这种方案是无法实现的，因为每个线程同一时间只能有一个协程在执行，如果调度协程阻塞在 `idle` 协程上，那么除非 `idle` 协程自行让出执行权，否则其他的协程都得不到执行。
为解决这个问题，`sylar` 采取忙等待的措施，调度协程会不停地检测任务队列，若没有任务，则则调度协程会切换到 `idle` 协程，这个 `idle` 协程什么也不做直接 `yield` 处于 `READY` 状态，在忙等待期间若依然没有任务调度协程又会将 `idle` 协程重新 `resume`，相当于 `idle` 啥也不做直接返回，因此 `Scheduler` 的 `tickle` 函数也什么也不做，不需要通知调度线程是否有新任务。
等有新任务进来时，`idle` 协程的反复 `resume/yield` 才会退出，并回到调度协程重新开始下一轮调度，只有当调度器检测到停止标志时，`idle` 协程才会真正结束，调度协程也会检测到 `idle` 协程状态为 `TERM`，并且随之退出整个调度协程。
这个问题在 `sylar` 框架内无解，只有一种方法可以规避掉，那就是设置 `autostop` 标志，这个标志会使得调度器在调度完所有任务后自动退出。在后续的 `IO` 调度中，上面的问题会得到一定的改善，并且 `tickle` 和 `idle` 可以实现得更加巧妙一些，以应对 `IO` 事件。
调度协程的切换情况可以看成以下两种情况的组合：
1. 线程数为 1，`use_caller=true`，对应只使用 `main` 函数线程进行协程调度的情况。
2. 线程数为 1，`use_caller=false`，对应额外创建一个线程进行协程调度、`main` 函数线程不参与调度的情况。
对于情况一，此时没有额外的线程进行协程调度，只能用 `main` 函数所在的线程来进行调度，而 `main` 函数线程要运行的协程有 `main` 函数对应的主协程、调度协程、待调度的任务协程。
在 `main` 函数线程里这三类协程运行的顺序为：
1. `main` 函数主协程运行，创建调度器，向调度器添加一些调度任务。
2. 开始协程调度，`main` 函数主协程让出执行权，切换到调度协程，调度协程从任务队列里按顺序执行所有的任务。每次执行一个任务，调度协程都要让出执行权，再切到该任务的协程里去执行，任务执行结束后，还要再切回调度协程，继续下一个任务的调度。
3. 所有任务都执行完后，调度协程让出执行权并切回 `main` 函数主协程，以保证程序能顺利结束。
因此在 `caller` 线程中，调度协程并不是 `caller` 线程的主协程，而是相当于 `caller` 线程的子协程。
在非对称协程里，子协程只能和线程主协程切换，而不能和另一个子协程切换，调度协程和任务协程都是子协程意味着调度协程不能直接和任务协程切换，一旦切换就无法回到主线程 `mian` 的主协程。
无法切回的根本原因是每个线程只有两个线程局部变量用于保存当前的协程上下文信息，线程任何时候都最多只能知道两个协程的上下文，其中一个是当前正在运行协程的上下文，另一个是线程主协程的上下文，如果调度协程和任务协程调用 `swapcontext` 切换，那这两个上下文都会变成子协程的上下文，线程主协程的上下文丢失后自然无法返回，这也是之前的实现中只能线程主协程去充当调度协程的原因。
为此需要再给每个线程增加一个线程局部变量用于保存调度协程的上下文，这样每个线程可以同时保存三个协程的上下文，一个是当前正在执行的协程上下文，另一个是线程主协程的上下文，最后一个是调度协程的上下文，协程就可以根据自己的身份来选择和每次和哪个协程进行交换：
1. 给协程类增加一个 `bool` 类型的成员 `m_runInScheduler`，用于记录该协程是否通过调度器来运行。创建协程时，根据协程的身份指定对应的协程类型，只有由调度器调度的协程即任务协程 `m_runInScheduler` 值为 `true`，线程主协程和线程的调度协程的 `m_runInScheduler` 都为 `false`，调度器只负责切换任务协程。
2. `resume` 协程时，如果如果这个协程的 `m_runInScheduler` 值为 `true`，表示这个协程参与调度器调度，那它应该和调度协程上下文进行切换，同理，在协程 `yield` 时，也应该恢复调度协程的上下文，表示从任务协程切换回调度协程。如果协程的 `m_runInScheduler` 值为 `false`，表示这个协程不参与调度器调度，那么在 `resume` 协程时，直接和线程主协程切换即可，`yield` 也直接恢复线程主协程的上下文即可。
对于情况二，此时因为有单独的线程用于协程调度，因此只需要调度协程作为这个调度线程的入口函数，从任务队列里取任务执行即可，因此在非 `caller` 线程里，调度协程就是调度线程的主协程。`main` 函数作为主线程没有调度协程，只需要向调度器添加任务，然后在适当的时机停止调度器即可，当调度器停止时，`main` 函数要等待调度线程结束后再退出。
上述部分的逻辑体现在 `resume/yield` 与 `GetMainFiber` 代码中。
```cpp
void Scheduler::run() {
    setThis(); // 设置当前线程的调度器
    set_hook_enable(true); // 非调度线程不能使用 hook，因此只在此处调用
    // 若当前运行的线程不是 caller 线程，则需要设置其调度协程
    // caller 线程的调度协程在创建调度器时已经设置
    if (cafba::GetThreadId() != m_rootThread) {
        // 设置当前线程的调度协程为当前正在运行的协程，若没有，GetThis 将会创建
        t_scheduler_fiber = cafba::Fiber::GetThis().get();
    }
    
    Fiber::ptr idle_fiber(new Fiber(std::bind(&Scheduler::idle, this)));
    Fiber::ptr cb_fiber; // 将普通函数封装为任务协程
 
    ScheduleTask task;
    while (true) { // 忙等待
        task.reset();
        bool tickle_me = false; // 是否tickle其他线程进行任务调度
        {
            MutexType::Lock lock(m_mutex);
            auto it = m_tasks.begin();
            while (it != m_tasks.end()) { // 遍历所有调度任务
                // 若已经通过 schedule 指定调度线程但并不是当前运行的线程
                // 则标记一下跳过这个任务，标记 tickle_me 表示需要通知其他线程进行调度
                if (it->thread != -1 && it->thread != cafba::GetThreadId()) {
                    ++it;
                    tickle_me = true;
                    continue;
                }
 
                // 找到一个未指定调度线程的任务，或是指定并是当前运行的线程的任务
                // 则准备开始调度，将其从任务队列中剔除，活动线程数加 1
                SYLAR_ASSERT(it->fiber || it->cb);
                if (it->fiber) SYLAR_ASSERT(it->fiber->getState() == Fiber::READY);
                task = *it;
                m_tasks.erase(it++);
                ++m_activeThreadCount;
                break;
            }
            // 若当前线程拿完一个任务后，任务队列还有剩余，那么 tickle 一下其他线程
            tickle_me |= (it != m_tasks.end());
        }
 
        if (tickle_me) tickle();
 
        if (task.fiber) { // resume任务协程，resume 返回时协程或执行完或yield，都代表任务执行结束
            task.fiber->resume();
            --m_activeThreadCount;
            task.reset();
        } else if (task.cb) { // 如果是普通函数，封装为协程再进行
            if (cb_fiber) cb_fiber->reset(task.cb);
            else cb_fiber.reset(new Fiber(task.cb));
            task.reset();
            cb_fiber->resume();
            --m_activeThreadCount;
            cb_fiber.reset();
        } else { // 进到这个分支情况一定是任务队列为空，调度idle协程即可
            if (idle_fiber->getState() == Fiber::TERM) {
                // 如果调度器没有调度任务，那么idle协程会不停地resume/yield，不会结束
                // 如果idle协程结束，那一定是调度器停止
                break;
            }
            ++m_idleThreadCount;
            idle_fiber->resume();
            --m_idleThreadCount;
        }
    }
}
```
### Stop
调度器的停止行为要分两种情况：
- `use_caller=false`，由于没有使用 `caller` 线程进行调度，因此只需要等待各个调度线程的调度协程退出。
- `use_caller=true`，表示 `caller` 线程也参与调度，在调度器停止前，让 `caller` 线程的调度协程再运行一次，让 `caller` 线程完成调度工作后再退出，这意味着如果调度器只使用 `caller` 线程进行调度，那么所有的调度任务要在调度器停止时才会被调度，因此 `stop` 方法负责 `caller` 线程的调度协程，这就是与线程池中的线程调度不一样的地方。
当只有 `main` 函数线程参与调度时，即 `main` 函数中定义调度器并且只使用 `main` 函数线程执行调度任务，可以认为是主线程先攒下一波协程，然后切到调度协程开始调度这些协程，每个协程在运行时也可以继续创建新的协程并加入调度，等所有的协程都调度完，调度协程进 `idle` 状态，这个状态下调度器执行忙等待。
这意味着主线程 `main` 函数一旦开启协程调度，之后的代码都执行不到。对于这个问题，`sylar` 把调度器的开始点放在 `stop` 方法中，保证可以执行到之前的代码，因为用于停止调度器的 `stop` 方法一定是最后调用的。`IOManager` 也是类似，除可以调用 `stop` 方法外，`IOManager` 类的析构函数也有一个 `stop` 方法，保证所有的任务都会被调度到。
但如果额外创建线程，那么，在添加完调度任务之后任务马上就可以在另一个线程中调度执行，因此如果只使用 `caller` 线程进行调度，那所有的任务协程都在 `stop` 之后排队调度，如果有额外线程，那任务协程在刚添加到任务队列时就可以得到调度。
此外只有所有的任务都完成调度时，调度器才可以退出，如果有一个任务没有执行完，那调度器就不能退出。
```cpp
bool Scheduler::stopping() {
    MutexType::Lock lock(m_mutex);
    return m_stopping && m_tasks.empty() && m_activeThreadCount == 0;
}

void Scheduler::stop() {
    // 第一次调用 stop 时 stopping() 一定为 false，从而让 caller 线程的调度协程再运行一次
    if (stopping()) return; 
    m_stopping = true; // 设置m_stopping标志，该标志表示正在停止
    
    // 检测是否使用 caller 线程进行调度，如果使用 caller 线程进行调度
    // 那要保证 stop 方法是由 caller 线程发起的
    if (m_useCaller) {
        SYLAR_ASSERT(GetThis() == this);
    } else {
        SYLAR_ASSERT(GetThis() != this);
    }

    // 通知其他调度线程的调度协程退出调度
    for (size_t i = 0; i < m_threadCount; i++) tickle();
    // 通知当前线程的调度协程退出调度
    if (m_rootFiber) tickle();

    // 如果使用 caller 线程进行调度，那再执行一次 caller 线程的调度协程
    // 等 caller 线程的调度协程返回
    if (m_rootFiber) m_rootFiber->resume();

    // 等待所有线程调度结束
    std::vector<Thread::ptr> thrs;
    {
        MutexType::Lock lock(m_mutex);
        thrs.swap(m_threads);
    }
    for (auto &i : thrs) i->join();
}
```
### SetThis/GetThis
```cpp
void Scheduler::setThis() {
    t_scheduler = this;
}

Scheduler *Scheduler::GetThis() {
    return t_scheduler;      // 返回当前线程共享的调度器
}

Fiber *Scheduler::GetMainFiber() {
    return t_scheduler_fiber; // 返回当前线程的调度协程
}
```
### Tickle/Idle
只有 `IO` 调度器的 `Tickle/Idle` 才有实际作用，普通调度器只是忙等待直到队列有任务。
```cpp
void Scheduler::tickle() {

}

void Scheduler::idle() {
    while (!stopping()) {
        sylar::Fiber::GetThis()->yield();
    }
}
```
### Yield
如果任务协程执行过程中主动调用 `yield` 让出执行权，一种处理方法是调度器在检测到协程从 `resume` 返回时，如果状态仍为 `READY`，那么就把协程重新放入任务队列，使其可以再次被调度，保证一个协程可以执行结束。更好的方法是调度器直接认为这个任务已经调度完毕，不再将其加入任务队列，不由调度器负责处理这部分，而是让任务协程 `yield` 之前，先把自己再放入当前调度器的任务队列里，再执行 `yield`，确保自己还会再被调度。
```cpp
// 演示协程主动yield情况下应该如何操作
void test_fiber1() {
    sylar::Scheduler::GetThis()->schedule(sylar::Fiber::GetThis());
    sylar::Fiber::GetThis()->yield();
}
```
这里规定协程在主动执行 `yield` 前，必须先将自己重新添加到调度器的任务队列中。如果协程不顾后果地执行 `yield`，会导致直接返回调度器继续下一个任务的调度，最后的后果就是协程将永远无法再被执行，也就是所说的逃逸状态。
`sylar` 的处理方法比较折衷一些，定义两种 `yield` 操作，一种是 `yield to ready`，这种 `yield` 调度器会再次将协程加入任务队列并等待调度，另一种是 `yield to hold`，这种 `yield` 调度器不会再将协程加入任务队列，但在整个 `sylar` 框架内一次都没用到。因此协程在 `yield` 之前必须自己先将自己加入到协程的调度队列中，否则协程就处于逃逸状态。
### Exception
类比一下线程，不会在线程外面处理线程抛出的异常，所以协程抛出的异常也不处理，直接让程序按默认的处理方式来处理即可，协程应该自己处理掉自己的异常，而不是让调度器来帮忙。
`sylar` 的协程调度器处理协程抛出的异常，并且给异常结束的协程设置了一个 EXCEPT 状态，这其实并不好。


