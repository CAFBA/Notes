`sylar` 的定时器采用最小堆设计，所有定时器根据绝对的超时时间点进行排序，每次取出离当前时间最近的一个超时时间点，计算出超时需要等待的时间，然后等待超时。超时时间到后，获取当前的绝对时间点，然后把最小堆里超时时间点小于这个时间点的定时器都收集起来，执行它们的回调函数。
在注册定时事件时，一般提供的是相对时间，比如相对当前时间 3 秒后执行。`sylar` 会根据传入的相对时间和当前的绝对时间计算出定时器超时时的绝对时间点，然后根据这个绝对时间点对定时器进行最小堆排序。
## Timer Class Interface
```cpp
class Timer : public std::enable_shared_from_this<Timer> {
friend class TimerManager;
public:
    /// 定时器的智能指针类型
    typedef std::shared_ptr<Timer> ptr;

    bool cancel(); // 取消定时器

    bool refresh(); // 刷新设置定时器的执行时间

    // from_now 是否从当前时间开始计算
    bool reset(uint64_t ms, bool from_now); // 重置定时器时间
private:
    // ms 定时器执行间隔时间 recurring 是否循环 manager 定时器管理器
    Timer(uint64_t ms, std::function<void()> cb,
          bool recurring, TimerManager* manager);
          
    Timer(uint64_t next); // next 为执行的时间戳(毫秒)
private:
    /// 是否循环定时器
    bool m_recurring = false;
    /// 执行周期/间隔
    uint64_t m_ms = 0;
    /// 精确的执行时间/绝对超时时间
    uint64_t m_next = 0;
    /// 回调函数
    std::function<void()> m_cb;
    /// 定时器管理器
    TimerManager* m_manager = nullptr;
private:
    struct Comparator {
        // 比较定时器的智能指针的大小(按执行时间排序)
        bool operator()(const Timer::ptr& lhs, const Timer::ptr& rhs) const;
    };
};
```
### Ctor
`Timer` 的构造函数被定义成私有方式，只能通过 `TimerManager` 类来创建 `Timer` 对象。第一个构造函数传入的是相对超时时间，即定时器执行间隔时间，内部要先进行转换，根据当前时间把相对时间转化成绝对时间，转换由函数 `GetElapsedMS` 进行，该函数返回值一个 `uint64_t` 类型的整数，表示自调用时间点以来的毫秒数。
```cpp
uint64_t GetElapsedMS() {
    // 定义 timespec 结构体变量 ts，用于存储时间
    // 字段 tv_sec 表示秒，tv_nsec 表示纳秒
    struct timespec ts = {0};
    // 调用 clock_gettime 函数获取当前时间，存储在 ts 中
    // CLOCK_MONOTONIC_RAW 是时钟标识符，表示单调时钟，不受系统时间的更改和调整的影响
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return ts.tv_sec * 1000 + ts.tv_nsec / 1000000; // 计算并返回自某个固定时间点以来的毫秒数
}

Timer::Timer(uint64_t ms, std::function<void()> cb,
             bool recurring, TimerManager *manager)
    : m_recurring(recurring)
    , m_ms(ms) // ms 是定时器执行间隔时间
    , m_cb(cb)
    , m_manager(manager) {
    // 绝对时间 = 当前时间 + 相对时间
    m_next = cafba::GetElapsedMS() + m_ms;
}

// next 是执行时间的时间戳(毫秒)
Timer::Timer(uint64_t next) {
    : m_next(next) 
}
```
### Cancel
```cpp
bool Timer::cancel() {
    TimerManager::RWMutexType::WriteLock lock(m_manager->m_mutex);
    if (m_cb) {
        m_cb    = nullptr;
        auto it = m_manager->m_timers.find(shared_from_this());
        m_manager->m_timers.erase(it);
        return true;
    }
    return false;
}
```
### Refresh
```cpp
bool Timer::refresh() {
    TimerManager::RWMutexType::WriteLock lock(m_manager->m_mutex);
    
    if (!m_cb) return false;
    
    auto it = m_manager->m_timers.find(shared_from_this());
    
    if (it == m_manager->m_timers.end()) return false;
    
    m_manager->m_timers.erase(it);
    m_next = sylar::GetElapsedMS() + m_ms;
    m_manager->m_timers.insert(shared_from_this());
    return true;
}
```
### Reset
```cpp
bool Timer::reset(uint64_t ms, bool from_now) {
    if (ms == m_ms && !from_now) {
        return true;
    }
    TimerManager::RWMutexType::WriteLock lock(m_manager->m_mutex);
    if (!m_cb) {
        return false;
    }
    auto it = m_manager->m_timers.find(shared_from_this());
    if (it == m_manager->m_timers.end()) {
        return false;
    }
    m_manager->m_timers.erase(it);
    uint64_t start = 0;
    if (from_now) {
        start = sylar::GetElapsedMS();
    } else {
        start = m_next - m_ms;
    }
    m_ms   = ms;
    m_next = start + m_ms;
    m_manager->addTimer(shared_from_this(), lock);
    return true;
}
```
### Comparator
仿函数 `Comparator`，用于比较两个 `Timer` 对象，比较的依据是绝对超时时间。
```cpp
bool Timer::Comparator::operator()(const Timer::ptr &lhs, const Timer::ptr &rhs) const {
    if (!lhs && !rhs) {
        return false;
    }
    if (!lhs) {
        return true;
    }
    if (!rhs) {
        return false;
    }
    if (lhs->m_next < rhs->m_next) {
        return true;
    }
    if (rhs->m_next < lhs->m_next) {
        return false;
    }
    return lhs.get() < rhs.get();
}
```
## TimerManager Class Interface
```cpp
class TimerManager { // 定时器管理器
friend class Timer;
public:
    /// 读写锁类型
    typedef RWMutex RWMutexType;

    TimerManager();
    
    virtual ~TimerManager();

    // 添加定时器 ms 定时器执行间隔时间 recurring 是否循环定时器
    Timer::ptr addTimer(uint64_t ms, std::function<void()> cb
                        ,bool recurring = false);

    // weak_cond 条件
    Timer::ptr addConditionTimer(uint64_t ms, std::function<void()> cb
                        ,std::weak_ptr<void> weak_cond
                        ,bool recurring = false);

    // 返回最近一个定时器还有多少时间会超时
    uint64_t getNextTimer();

    // 获取需要执行的定时器的回调函数列表
    void listExpiredCb(std::vector<std::function<void()> >& cbs);

    bool hasTimer(); // 是否有定时器
protected:
    // 当有新的定时器插入到定时器的首部，执行该函数
    virtual void onTimerInsertedAtFront() = 0;

    // 将定时器添加到管理器中
    void addTimer(Timer::ptr val, RWMutexType::WriteLock& lock);
private:
    bool IsClockRollover(uint64_t now_ms);
private:
    /// Mutex
    RWMutexType m_mutex;
    /// 定时器集合，对其的读写访问都需要加锁
    std::set<Timer::ptr, Timer::Comparator> m_timers;
    // 是否触发onTimerInsertedAtFront
    // 当有新的定时器插入堆头时触发 onTimerInsertedAtFront
    bool m_shouldTriggerAtFrontFuncFlag = true;
    /// 上次执行时间
    uint64_t m_previouseTime = 0;
};
```
### Ctor
```cpp
TimerManager::TimerManager() {
    m_previouseTime = cafba::GetElapsedMS();
}

TimerManager::~TimerManager() {}
```
### AddTimer
```cpp
// 用于创建定时器并加锁添加
Timer::ptr TimerManager::addTimer(uint64_t ms, std::function<void()> cb, bool recurring) {
    Timer::ptr timer(new Timer(ms, cb, recurring, this));
    RWMutexType::WriteLock lock(m_mutex);
    addTimer(timer, lock);
    return timer;
}

void TimerManager::addTimer(Timer::ptr val, RWMutexType::WriteLock &lock) {
    const auto it            = m_timers.insert(val).first;
    const bool insertAtFront = (it == m_timers.begin()) && m_shouldTriggerAtFrontFuncFlag;
    // 若添加后的定时器位于堆头，调用 onTimerInsertedAtFront 提醒一次
    // 不需要反复提醒，因此提醒一次后置为 false，除非再次调用 getNextTimer 才有必要
    if (insertAtFront) m_shouldTriggerAtFrontFuncFlag = false;
    lock.unlock();

    if (insertAtFront == true) onTimerInsertedAtFront();
}
```
### GetNextTimer
由于在 `IO` 线程调度的 `idle` 实现中，会调用 `getNextTimer` 获得最近定时器作为 `epoll` 超时时间，所以只有在调用 `getNextTimer` 后才可能需要调用 `onTimerInsertedAtFront` 提醒 `epoll` 更新超时时间，一般不需要对新加入的定时器位于堆头进行提醒。
```cpp
uint64_t TimerManager::getNextTimer() { // 返回最近一个定时器还有多少时间会超时
    RWMutexType::ReadLock lock(m_mutex); // 读需要加锁
    m_shouldTriggerAtFrontFuncFlag = true;
    if (m_timers.empty()) return ~0ull; // 全 1 表示没有定时器

    const Timer::ptr &next = *m_timers.begin();
    uint64_t now_ms        = cafba::GetElapsedMS();
    if (now_ms >= next->m_next) return 0; // 当前时间大于绝对超时时间
    else return next->m_next - now_ms;    // 未超过，返回还有多少时间间隔会超时
}
```
### IsClockRollover
检查当前时间戳 `now_ms` 是否小于之前记录的时间戳 `m_previouseTime`。如果 `now_ms` 小于 `m_previouseTime`，那么可能发生回滚。此外，还需要检查 `now_ms` 是否小于 `m_previouseTime` 减去一小时的毫秒数（`60 * 60 * 1000` 毫秒），以确保时间戳没有回滚超过一小时。如果上述两个条件都满足，那么将 `rollover` 设置为 `true`，表示发生回滚。
```cpp
// 检查一个给定的时间戳 now_ms 是否发生了回滚
// 在计算机系统中，时间戳可能会因为系统时钟调整而回滚
bool TimerManager::IsClockRollover(uint64_t now_ms) {
    bool rollover = false; // 标记是否发生回滚
    if (now_ms < m_previouseTime &&
        now_ms < (m_previouseTime - 60 * 60 * 1000)) {
        rollover = true;
    }
    // 无论是否发生回滚，都更新 m_previouseTime 为当前时间戳 now_ms
    // 以便下次调用 IsClockRollover 时使用
    m_previouseTime = now_ms;
    return rollover;
}
```
### ListExpiredCb
```cpp
void TimerManager::listExpiredCb(std::vector<std::function<void()>> &cbs) {
    const uint64_t now_ms = cafba::GetElapsedMS();
    std::vector<Timer::ptr> expired;
    {
        RWMutexType::ReadLock lock(m_mutex);
        if (m_timers.empty()) return; // 读需要加锁
    }
    RWMutexType::WriteLock lock(m_mutex);
    if (m_timers.empty()) return;
    
    bool rollover = false;
    if (SYLAR_UNLIKELY(IsClockRollover(now_ms))) rollover = true;
    // 若堆头定时器未回滚并且绝对超时时间大于当前时间，则未超时，返回即可
    if (!rollover && ((*m_timers.begin())->m_next > now_ms)) return;

    // 若发生回滚，就触发所有的定时器事件
    // 否则触发大于等于当前时间的定时器之前的所有定时器
    // 这些定时器都已经超时，需要从定时器队列中去除并加入超时定时器队列
    const Timer::ptr now_timer(new Timer(now_ms));
    auto it = rollover ? m_timers.end() : m_timers.lower_bound(now_timer); 
    while (it != m_timers.end() && (*it)->m_next == now_ms) ++it;
    expired.insert(expired.begin(), m_timers.begin(), it); 
    m_timers.erase(m_timers.begin(), it);

    // 通过超时队列得到需要执行的回调函数队列
    cbs.reserve(expired.size());
    for (auto &timer : expired) {
        cbs.push_back(timer->m_cb);
        if (timer->m_recurring) { // 该定时器可复用
            timer->m_next = now_ms + timer->m_ms;
            m_timers.insert(timer);
        } 
        else timer->m_cb = nullptr; // 不可复用
    }
}
```
### HasTimer
```cpp
bool TimerManager::hasTimer() {
    RWMutexType::ReadLock lock(m_mutex);
    return !m_timers.empty();
}
```
### AddConditionTimer
```cpp
static void OnTimer(std::weak_ptr<void> weak_cond, std::function<void()> cb) {
    const std::shared_ptr<void> tmp = weak_cond.lock();
    if (tmp != nullptr) cb();
}

// 在创建定时器时绑定一个变量，在定时器触发时判断一下该变量是否仍然有效，如果变量无效，就取消触发
Timer::ptr TimerManager::addConditionTimer(uint64_t ms, std::function<void()> cb, 
                               std::weak_ptr<void> weak_cond, bool recurring) {
    return addTimer(ms, std::bind(&OnTimer, weak_cond, cb), recurring);
}
```