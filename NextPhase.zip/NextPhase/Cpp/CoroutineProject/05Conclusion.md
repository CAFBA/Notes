# Conclusion
## Thread
协程虽然被称为轻量级线程，但在单线程内，协程并不能并发执行，只能是一个协程结束或挂起后，再执行另一个协程，而线程则是可以真正并发执行的。因为单线程下协程并不是并发执行，而是顺序执行的，所以不要在协程里使用线程级别的锁来做协程同步，如果一个协程在持有锁之后让出执行，那么同线程的其他任何协程一旦尝试再次持有这个锁，整个线程就会锁死，这和单线程环境下，连续两次对同一个锁进行加锁导致的死锁道理完全一样。
在多线程环境中，多个线程可能会同时访问容器，如果不加锁，可能会导致数据竞争，所以需要互斥锁确保在任何时刻只有一个线程可以访问。
- `Schedule` 中向任务队列添加调度任务。
- `Timer` 中访问定时器管理器中的定时器集合，修改/添加/删除定时器。
- `Hook` 中访问文件句柄管理类中的文件句柄集合。
- `IO` 调度器中修改/添加/删除事件时访问 `socket` 事件上下文的容器，在 `Idle` 中访问 `epoll` 中触发的所有事件，需要对这些事件进行修改。
## Coroutine
`sylar` 使用非对称协程模型。如果将线程的局部变量设置成一个类似链表的数据结构，那理论上应该也可以实现对称协程，也就是子协程可以直接和子协程切换，但代码复杂度上肯定会增加不少，因为要考虑多线程和公平调度的问题。`sylar` 的非对称协程代码实现简单，并且在后面实现协程调度时可以做到公平调度，缺点是子协程只能和线程主协程切换，意味着子协程无法创建并运行新的子协程，并且在后面实现协程调度时，完成一次子协程调度需要额外多切换一次上下文。
协程上下文信息与协程切换基于 `ucontext_t` 实现，使用 `swapcontext` 来做协程切换，对每个协程，只设计 3 种状态，分别是 `READY` 代表就绪态，`RUNNING` 代表运行态，`TERM` 代表运行结束。设计三个线程局部变量来存储当前运行协程 `t_fiber`，线程主协程 `t_thread_fiber`，调度协程 `t_scheduler_fiber` 的上下文信息，据此切换到指定的协程上下文。
线程主协程由代表 `GetThis()` 方法调用无参构造函数创建，线程入口函数或是 `main` 函数所在的协程，这两种函数都不是以协程的手段创建的，所以它们只有 `ucontext_t` 上下文，但没有入口函数，也没有分配栈空间，其它协程均需要初始化 `ucontext_t` 上下文和栈空间，要求必须传入协程的入口函数，以及可选的协程栈大小。
在实现协程调度之前，子协程不能直接 `resume` 另一个子协程，如果子协程在其内部执行另一个协程的 `resume`，`swapcontext` 会把子协程的上下文保存到 `t_thread_fiber` 中，导致 `t_thread_fiber` 不再指向 `main` 函数的上下文，因此只能由 `main` 的主协程调度子协程。
此外，为提高内存利用率，可以借鉴 `libco` 使用共享栈，同时提供重置协程的接口，重复利用已结束的协程，复用其栈空间，创建新协程。
## Timer
`sylar` 的定时器采用最小堆设计，所有定时器根据绝对的超时时间点进行排序，每次取出离当前时间最近的一个超时时间点，计算出超时需要等待的时间，然后等待超时。超时时间到后，获取当前的绝对时间点，然后把最小堆里超时时间点小于这个时间点的定时器都收集起来，执行它们的回调函数。
在注册定时事件时，一般提供的是相对时间，比如相对当前时间 3 秒后执行，而 `sylar` 会根据传入的相对超时时间和当前的绝对时间计算出定时器超时时的绝对时间点，转换由函数 `GetElapsedMS` 进行，其中，调用 `clock_gettime` 使用 `CLOCK_MONOTONIC_RAW` 单调时钟，不受系统时间的更改和调整的影响，然后根据这个绝对时间点对定时器进行最小堆排序。此外，还提供检查时间回滚的函数，保证定时的准确性。
由于在 `IO` 线程调度的 `idle` 实现中，会调用 `getNextTimer` 获得最近定时器作为 `epoll` 超时时间，所以只有在调用 `getNextTimer` 后才可能需要调用 `onTimerInsertedAtFront` 提醒 `epoll` 更新超时时间，一般不需要对新加入的定时器位于堆头反复提醒，因此提醒一次后置为 false，除非再次调用 `getNextTimer` 才有必要。
此外，支持在创建定时器时绑定一个变量，在定时器触发时判断一下该变量是否仍然有效，如果变量无效，就不调用回调函数，这主要用于封装 `hook` 。由于阻塞调用超时前返回会取消定时器，此时不需要调用回调函数，因此需要 `weak_ptr` 作为条件变量，若阻塞调用超时前返回，`shared_ptr` 会被销毁，将不会调用回调函数。
## IOManager
### Scheduler
对于每个协程，都需要用户手动调用协程的 `resume` 方法将协程运行起来，然后等协程运行结束并返回，再运行下一个协程。这种运行协程的方式相当于用户在充当调度器，引入协程调度后，调度器内部维护一个任务队列和一个调度线程池，利用多线程并行运行多个协程。
开始调度后，所有调度线程的调度协程按顺序从任务队列里取任务执行，并且调度线程可以调度器所在的线程 `caller` 线程。当全部任务都执行完后，线程池停止调度，等新的任务进来。当添加新任务时，通知线程池有新的任务，线程池重新开始运行调度。停止调度时，各调度线程退出，调度器停止工作。
综上，`sylar` 的协程调度模块支持多线程，支持使用 `caller` 线程进行调度，支持添加函数或协程作为调度对象，并且支持将函数或协程绑定到一个具体的线程上执行。

调度协程负责从调度器的任务队列中取任务执行，取出的任务即子协程，这里调度协程和子协程的切换模型即非对称模型，每个子协程执行完后都必须返回调度协程，再由调度协程重新从任务队列中取新的子协程并执行。
非对称模型支持使用 `caller` 线程进行调度，会出现两个问题：
1. 当只使用 `caller` 线程进行调度时不需要创建新线程用于调度，只由 `caller` 线程的调度协程来负责调度协程，`caller` 线程也不进入线程池，因此 `caller` 线程的调度逻辑与线程池中的线程不一样，在调度器停止前，让 `caller` 线程的调度协程再运行一次，让 `caller` 线程完成调度工作后再退出，这意味着如果调度器只使用 `caller` 线程进行调度，那么所有的调度任务要在调度器停止时才会被调度。
2. 在 `caller` 线程中，没有单独的线程用于协程调度，不能用 `main` 函数的主协程作为调度协程，调度协程并不是 `caller` 线程的主协程，而是相当于 `caller` 线程的子协程。在非对称协程里，子协程只能和线程主协程切换，而不能和另一个子协程切换，调度协程和任务协程都是子协程意味着调度协程不能直接和任务协程切换，一旦切换就无法回到主线程 `mian` 的主协程。
因此：
1. 通过 `bool` 类型的成员 `m_runInScheduler`，记录该协程是否通过调度器来运行。创建协程时，根据协程的身份指定对应的协程类型，只有由调度器调度的协程即任务协程 `m_runInScheduler` 值为 `true`，线程主协程和线程的调度协程的 `m_runInScheduler` 都为 `false`，调度器只负责切换任务协程。
2. `resume` 协程时，如果如果这个协程的 `m_runInScheduler` 值为 `true`，表示这个协程参与调度器调度，那它应该和调度协程上下文进行切换，同理，在协程 `yield` 时，也应该恢复调度协程的上下文，表示从任务协程切换回调度协程。如果协程的 `m_runInScheduler` 值为 `false`，表示这个协程不参与调度器调度，那么在 `resume` 协程时，直接和线程主协程切换即可，`yield` 也直接恢复线程主协程的上下文即可。


当调度器没有协程可调度时，调度协程应该有一些同步手段，比如调度协程阻塞在一个 `idle` 协程上，等待新任务加入后退出 `idle` 协程，恢复调度。然而这种方案是无法实现的，因为每个线程同一时间只能有一个协程在执行，如果调度协程阻塞在 `idle` 协程上，那么除非 `idle` 协程自行让出执行权，否则其他的协程都得不到执行。
为解决这个问题，`sylar` 采取忙等待的措施，调度协程会不停地检测任务队列，若没有任务，则则调度协程会切换到 `idle` 协程，这个 `idle` 协程什么也不做直接 `yield` 处于 `READY` 状态，在忙等待期间若依然没有任务调度协程又会将 `idle` 协程重新 `resume`，相当于 `idle` 啥也不做直接返回，因此 `Scheduler` 的 `tickle` 函数也什么也不做，不需要通知调度线程是否有新任务。
等有新任务进来时，`idle` 协程的反复 `resume/yield` 才会退出，并回到调度协程重新开始下一轮调度，只有当调度器检测到停止标志时，`idle` 协程才会真正结束，调度协程也会检测到 `idle` 协程状态为 `TERM`，并且随之退出整个调度协程。


如果任务协程执行过程中主动调用 `yield` 让出执行权，一种处理方法是调度器在检测到协程从 `resume` 返回时，如果状态仍为 `READY`，那么就把协程重新放入任务队列，使其可以再次被调度，保证一个协程可以执行结束。更好的方法是调度器直接认为这个任务已经调度完毕，不再将其加入任务队列，不由调度器负责处理这部分，而是让任务协程 `yield` 之前，先把自己再放入当前调度器的任务队列里，再执行 `yield`，确保自己还会再被调度。
```cpp
// 演示协程主动yield情况下应该如何操作
void test_fiber1() {
    sylar::Scheduler::GetThis()->schedule(sylar::Fiber::GetThis());
    sylar::Fiber::GetThis()->yield();
}
```
这里规定协程在主动执行 `yield` 前，必须先将自己重新添加到调度器的任务队列中。如果协程不顾后果地执行 `yield`，会导致直接返回调度器继续下一个任务的调度，最后的后果就是协程将永远无法再被执行，也就是所说的逃逸状态。
### IO
`sylar` 的 `IO` 协程调度模块基于 `epoll` 实现，直接继承协程调度器，增加 `IO` 事件调度的功能，支持为描述符注册事件的回调函数，对每个 `fd`，`sylar` 支持两类事件，一类是可读事件，对应 `EPOLLIN`，一类是可写事件，对应 `EPOLLOUT`。事件枚举值直接继承自 `epoll`，对于 `epoll` 其他事件进行归类，分别对应到 `EPOLLIN` 和 `EPOLLOUT` 中，也就是所有的事件都可以表示为可读或可写事件，甚至有的事件还可以同时表示可读及可写事件，比如 `EPOLLERR` 事件发生时，`fd` 将同时触发可读和可写事件。
对于 `IO` 协程调度来说，每次调度都包含一个三元组信息，分别是描述符-事件类型-回调函数，调度器记录全部需要调度的三元组信息，其中描述符和事件类型用于 `epoll_wait`，回调函数用于协程调度。这个三元组信息通过 `FdContext` 结构体来存储，在执行 `epoll_wait` 时通过 `epoll_event` 的私有数据指针 `data.ptr` 来保存 `FdContext` 结构体信息。

对于忙等待问题，可以设置 `autostop` 标志，这个标志会使得调度器在调度完所有任务后自动退出，而对于 `IO` 事件，则可以使用 `IO` 调度器。
为防止 `IO` 事件不触发导致 `IO` 协程调度一直阻塞在 `epoll_wait` 上，需要设置超时时间。超时时间用当前定时器的最小超时时间来代替，这就意味着需要保证最小超时时间的准确性。因此当 `TimerManager` 检测到新添加的定时器的超时时间比当前最小的定时器还要小时，将会调用 `onTimerInsertedAtFront()` 方法，其内部调用 `tickle` 通过写 `pipe` 使 `pipe` 的读描述符触发可读事件，使 `epoll_wait` 返回，获取新添加的最小定时器的超时时间，从而更新当前的 `epoll_wait` 超时，否则新添加的定时器的执行时间将不准确。
在 `idle` 中会 `epoll_wait` 所有注册的 `fd`，当有事件触发时从 `epoll_wait` 返回，通过 `data.ptr` 中获得 `fd` 的上下文信息，并且将 `fd` 的回调函数并加入调度器的任务队列，回调函数在 `idle` 协程退出后，由调度器在下一轮调度时执行。此外，`epoll_wait` 返回后，需要将所有超时的定时器回调函数加入调度器的任务队列。
## ApacheBench
```
ab -n 100 -c 10 http://test.com/
```

```cpp
#include "sylar.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include <fcntl.h>
#include <iostream>
#include <stack>

static int sock_listen_fd = -1;
void test_accept();
void error(char* msg)
{
 perror(msg);
 printf("erreur...\n");
 exit(1);
}
void watch_io_read() {
 sylarr::IOManager::GetThis()->
 addEvent(sock_listen_fd, sylarr::IOManager::READ, test_accept);
}
void test_accept() {
 struct sockaddr_in addr; //maybe sockaddr_un;
 memset( &addr,0,sizeof(addr) );
 socklen_t len = sizeof(addr);
 int fd = accept(sock_listen_fd, (struct sockaddr*)&addr, &len);
 if (fd < 0) {
 std::cout << "fd = "<< fd << "accept false" << std::endl;
 } else {
 fcntl(fd, F_SETFL, O_NONBLOCK);
 sylarr::IOManager::GetThis()->
 addEvent(fd, sylarr::IOManager::READ, [fd](){
 char buffer[1024];
 memset(buffer, 0, sizeof(buffer));
 while (true) {
 int ret = recv(fd, buffer, sizeof(buffer), 0);
 if (ret > 0) {
 ret = send(fd, buffer, ret, 0);
 }
 if (ret <= 0) {
 if (errno == EAGAIN) continue;
 close(fd);
break;
 }
 }

 });

 }
 sylarr::IOManager::GetThis()->schedule(watch_io_read);
 }
void test_iomanager() {
 int portno = 8080;
 struct sockaddr_in server_addr, client_addr;
 socklen_t client_len = sizeof(client_addr);
 // setup socket
 sock_listen_fd = socket(AF_INET, SOCK_STREAM, 0);
 if (sock_listen_fd < 0) {
 error("Error creating socket..\n");
 }
 int yes = 1;
 // lose the pesky "address already in use" error message
 setsockopt(sock_listen_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
 memset((char *)&server_addr, 0, sizeof(server_addr));
 server_addr.sin_family = AF_INET;
 server_addr.sin_port = htons(portno);
 server_addr.sin_addr.s_addr = INADDR_ANY;
 // bind socket and listen for connections
 if (bind(sock_listen_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
 error("Error binding socket..\n");
 if (listen(sock_listen_fd, 1024) < 0) {
 error("Error listening..\n");
 }
 printf("epoll echo server listening for connections on port: %d\n", portno);
 fcntl(sock_listen_fd, F_SETFL, O_NONBLOCK);
 sylarr::IOManager iom;
 iom.addEvent(sock_listen_fd, sylarr::IOManager::READ, test_accept);
}
int main(int argc, char *argv[]) {
 test_iomanager();
 return 0;
}
```


```cpp


#include "co_routine.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/time.h>

#include <stack>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#ifdef __FreeBSD__
#include <cstring>
#include <sys/types.h>
#include <sys/wait.h>
#endif
using namespace std;
struct task_t
{
    stCoRoutine_t *co;
    int fd;
};
static stack<task_t*> g_readwrite;
static int g_listen_fd = -1;
static int SetNonBlock(int iSock)
{
    int iFlags;
    iFlags = fcntl(iSock, F_GETFL, 0);
    iFlags |= O_NONBLOCK;
    iFlags |= O_NDELAY;
    int ret = fcntl(iSock, F_SETFL, iFlags);
    return ret;
}
static void *readwrite_routine( void *arg )
{
    co_enable_hook_sys();
    task_t *co = (task_t*)arg;
    char buf[ 1024 * 16 ];
    for(;;)
    {
        if( -1 == co->fd )
        {
            // push进去
            g_readwrite.push( co );
            // 切出
            co_yield_ct();
            continue;
        }
        int fd = co->fd;
        co->fd = -1;
        for(;;)
        {
            // 将该fd的可读事件，注册到epoll中
            // co_accept⾥⾯libco并没有将其设置为 O_NONBLOCK
            // 是⽤户主动设置的 O_NONBLOCK
            // 所以read函数不⾛hook逻辑，需要⾃⾏进⾏poll切出
            struct pollfd pf = { 0 };
            pf.fd = fd;
            pf.events = (POLLIN|POLLERR|POLLHUP);

            co_poll( co_get_epoll_ct(),&pf,1,1000);
            // 当超时或者可读事件到达时，进⾏read。所以read不⼀定成功，有可能是超时造成的
            int ret = read( fd,buf,sizeof(buf) );
            // 读多少就写多少
            if( ret > 0 )
            {
                ret = write( fd,buf,ret );
            }
            if( ret <= 0 )
            {
                // accept_routine->SetNonBlock(fd) cause EAGAIN, we should continue
                if (errno == EAGAIN)
                    continue;
                close( fd );
                break;
            }
        }
    }
    return 0;
}
int co_accept(int fd, struct sockaddr *addr, socklen_t *len );
static void *accept_routine( void * )
{
    co_enable_hook_sys();
    printf("accept_routine\n");
    fflush(stdout);
    for(;;)
    {
        //printf("pid %ld g_readwrite.size %ld\n",getpid(),g_readwrite.size());
        if( g_readwrite.empty() )
        {
            printf("empty\n"); //sleep
            struct pollfd pf = { 0 };
            pf.fd = -1;
            // sleep 1秒，等待有空余的协程
            poll( &pf,1,1000);
            continue;
        }
        struct sockaddr_in addr; //maybe sockaddr_un;
        memset( &addr,0,sizeof(addr) );
        socklen_t len = sizeof(addr);
        // accept
        int fd = co_accept(g_listen_fd, (struct sockaddr *)&addr, &len);
        if( fd < 0 )
        {
            // 意思是，如果accept失败了，没办法，暂时切出去
            struct pollfd pf = { 0 };
            pf.fd = g_listen_fd;
            pf.events = (POLLIN|POLLERR|POLLHUP);
            co_poll( co_get_epoll_ct(),&pf,1,1000 );
            continue;
        }
        if( g_readwrite.empty() )
        {
            close( fd );
            continue;
        }
        // 这⾥需要⼿动将其变成⾮阻塞的
        SetNonBlock( fd );
        task_t *co = g_readwrite.top();
        co->fd = fd;
        g_readwrite.pop();
        co_resume( co->co );
    }
    return 0;
}

static void SetAddr(const char *pszIP,const unsigned short shPort,struct sockaddr_in
&addr)
{
    bzero(&addr,sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(shPort);
    int nIP = 0;
    if( !pszIP || '\0' == *pszIP
        || 0 == strcmp(pszIP,"0") || 0 == strcmp(pszIP,"0.0.0.0")
        || 0 == strcmp(pszIP,"*")
            )
    {
        nIP = htonl(INADDR_ANY);
    }
    else
    {
        nIP = inet_addr(pszIP);
    }
    addr.sin_addr.s_addr = nIP;
}
static int CreateTcpSocket(const unsigned short shPort /* = 0 */,const char *pszIP /* =
"*" */,bool bReuse /* = false */)
{
    int fd = socket(AF_INET,SOCK_STREAM, IPPROTO_TCP);
    if( fd >= 0 )
    {
        if(shPort != 0)
        {
            if(bReuse)
            {
                int nReuseAddr = 1;
                setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&nReuseAddr,sizeof(nReuseAddr));
            }
            struct sockaddr_in addr ;
            SetAddr(pszIP,shPort,addr);
            int ret = bind(fd,(struct sockaddr*)&addr,sizeof(addr));
            if( ret != 0)
            {
                close(fd);
                return -1;
            }
        }
    }
    return fd;
}

int main(int argc,char *argv[])
{
    if(argc<5){
        printf("Usage:\n"
               "example_echosvr [IP] [PORT] [TASK_COUNT] [PROCESS_COUNT]\n"
               "example_echosvr [IP] [PORT] [TASK_COUNT] [PROCESS_COUNT] -d #
        daemonize mode\n");
        return -1;
    }
    const char *ip = argv[1];
    int port = atoi( argv[2] );
    int cnt = atoi( argv[3] ); // task_count 协程数
    int proccnt = atoi( argv[4] ); // 进程数
    bool deamonize = argc >= 6 && strcmp(argv[5], "-d") == 0;
    g_listen_fd = CreateTcpSocket( port,ip,true );
    listen( g_listen_fd,1024 );
    if(g_listen_fd==-1){
        printf("Port %d is in use\n", port);
        return -1;
    }
    printf("listen %d %s:%d\n",g_listen_fd,ip,port);
    SetNonBlock( g_listen_fd );
    for(int k=0;k<proccnt;k++)
    {
        pid_t pid = fork();
        if( pid > 0 )
        {
            continue;
        }
        else if( pid < 0 )
        {
            break;
        }
        for(int i=0;i<cnt;i++)
        {
            task_t * task = (task_t*)calloc( 1,sizeof(task_t) );
            task->fd = -1;
            // 创建⼀个协程
            co_create( &(task->co),NULL,readwrite_routine,task );
            // 启动协程
            co_resume( task->co );
        }
        // 启动listen协程
        stCoRoutine_t *accept_co = NULL;
        co_create( &accept_co,NULL,accept_routine,0 );
        // 启动协程
        co_resume( accept_co );
        // 启动事件循环
        co_eventloop( co_get_epoll_ct(),0,0 );
        exit(0);
    }
    if(!deamonize) wait(NULL);
    return 0;
}
```


```cpp
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <event2/event.h>
#define PORT 8888
// 回声处理函数
void echo_read_cb(evutil_socket_t fd, short events, void *arg) {
    char buf[1024];
    int len;
    len = recv(fd, buf, sizeof(buf)-1, 0);
    if (len <= 0) {
        // 发⽣错误或连接关闭，关闭连接并释放事件资源
        close(fd);
        event_free((struct event*)arg);
        return;
    }
    buf[len] = '\0';
    printf("接收到消息：%s\n", buf);
    // 发送回声消息给客户端
    send(fd, buf, len, 0);
}
// 接受连接回调函数
void accept_conn_cb(evutil_socket_t listener, short event, void *arg) {
    struct event_base *base = (struct event_base*)arg;
    struct sockaddr_storage ss;
    socklen_t slen = sizeof(ss);
    int fd = accept(listener, (struct sockaddr*)&ss, &slen);
    if (fd < 0) {
        perror("accept");
    } else if (fd > FD_SETSIZE) {
        close(fd);
    } else {
        // 创建⼀个新的事件结构体
        struct event *ev = event_new(NULL, -1, 0, NULL, NULL);
        // 将新的事件添加到事件循环中
        event_assign(ev, base, fd, EV_READ|EV_PERSIST, echo_read_cb, (void*)ev);
        event_add(ev, NULL);
    }
}
int main() {
    struct event_base *base;
    struct event listener;
    struct sockaddr_in sin;
    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = htonl(INADDR_ANY);
    sin.sin_port = htons(PORT);
    // 初始化Libevent库
    base = event_base_new();
    // 创建⼀个监听事件
    listener = *event_new(base, -1, EV_READ|EV_PERSIST, accept_conn_cb, (void*)base);
    // 将监听事件绑定到指定的地址和端⼝
    if (event_add(&listener, NULL) == -1) {
        perror("event_add");
        return -1;
    }
    // 开始事件循环
    event_base_dispatch(base);
    return 0;
}
```

```cpp

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/epoll.h>
#define MAX_EVENTS 10
#define PORT 8888
int main() {
    int listen_fd, conn_fd, epoll_fd, event_count;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    struct epoll_event events[MAX_EVENTS], event;
    // 创建监听套接字
    if ((listen_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        return -1;
    }
    // 设置服务器地址和端⼝
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;
    // 绑定监听套接字到服务器地址和端⼝
    if (bind(listen_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("bind");
        return -1;
    }
    // 监听连接
    if (listen(listen_fd, 5) == -1) {
        perror("listen");
        return -1;
    }
    // 创建 epoll 实例
    if ((epoll_fd = epoll_create1(0)) == -1) {
        perror("epoll_create1");
        return -1;
    }
    // 添加监听套接字到 epoll 实例中
    event.events = EPOLLIN;
    event.data.fd = listen_fd;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen_fd, &event) == -1) {
        perror("epoll_ctl");
        return -1;
    }
    while (1) {
        // 等待事件发⽣
        event_count = epoll_wait(epoll_fd, events, MAX_EVENTS, -1);
        if (event_count == -1) {
            perror("epoll_wait");
            return -1;
        }
        // 处理事件
        for (int i = 0; i < event_count; i++) {
            if (events[i].data.fd == listen_fd) {
                // 有新连接到达
                conn_fd = accept(listen_fd, (struct sockaddr*)&client_addr, &addr_len);
                if (conn_fd == -1) {
                    perror("accept");
                    continue;
                }
                // 将新连接的套接字添加到 epoll 实例中
                event.events = EPOLLIN;
                event.data.fd = conn_fd;
                if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, conn_fd, &event) == -1) {
                    perror("epoll_ctl");
                    return -1;
                }
            } else {
                // 有数据可读
                char buf[1024];
                int len = read(events[i].data.fd, buf, sizeof(buf) - 1);
                if (len <= 0) {
                    // 发⽣错误或连接关闭，关闭连接
                    close(events[i].data.fd);
                } else {
                    buf[len] = '\0';
                    printf("接收到消息：%s\n", buf);
                    // 发送回声消息给客户端
                    write(events[i].data.fd, buf, len);
                }
            }
        }
    }
    // 关闭监听套接字和 epoll 实例
    close(listen_fd);
    close(epoll_fd);
    return 0;
}
```

：单线程下本项⽬相⽐于于原⽣epoll⼏乎没有性能损失，在⼤流量、多 线程、IO密集条件，使⽤本项⽬编写的⽹络服务器相⽐于其他的⽹络服务库具有明显的的性能优势，经分析本项⽬ 的性能瓶颈存在于服务器运⾏时协程的创建、切换、析构，同时协程独⽴栈的设计也使得本项⽬占⽤更多的内存。