每个协程都拥有一个独立的栈帧, 协程切换时会保存当前协程栈中的所有数据, 并加载新的栈帧对象。这样做的优点是协程调度可以在内存中的任意位置、任意时刻进行，但是随着并发量的增加, 协程的数目越来越多, 当前内存中的协程栈越来越多, 内存瓶颈开始显现，且内存切换本身也是不小的开销(寄存器恢复、数据拷贝)。所以，`stackful coroutine` 一般有栈大小的限制，`libco` 是 `128K`。
共享栈将协程划分为协程组，同一个协程组中的协程共享同一块内存，在协程切换的时候将当前内存中的数据保存到即将被挂起的协程的 `buffer` 中, 并将新调度协程 `buffer` 中的数据拷贝到共享栈中，从而减少内存开销，同时运行协程又没有栈大小的限制。共享栈的缺点是，协程调度产生的局部变量都在共享栈上，一旦新的协程运行后共享栈中的数据就会被覆盖，先前协程的局部变量也就不再有效, 进而无法实现参数传递、嵌套调用等高级协程交互。
## Design
`libco` 定义 `stShareStack_t` 存储一组共享栈，并记录这组共享栈的大小与个数，每个共享栈由 `stStackMem_t` 结构体表示，记录共享栈的栈顶栈底以及当前使用该共享栈的协程。
在表示协程的结构体 `stCoRoutine_t` 中，用 `cIsShareStack` 标志是否启用共享栈，用 `save_buffer` 保存当前被挂起协程的栈数据，为区分独立栈与共享栈，定义 `stCoRoutineAttr_t`，若其中 `stShareStack_t` 类型的成员非空，则说明使用共享栈，当使用 `co_create` 创建协程时，会根据 `stCoRoutineAttr_t` 决定是否创建共享栈。
每个线程都有一份 `stCoRoutineEnv_t` 对象表示协程的运行环境，成员 `pCallStack` 维护该线程的所有协程的调用栈，在线程第一次创建协程时被自动创建，同时也会创建主协程，并将指向主协程的指针放到 `pCallStack[0]` 里，当采用共享栈模式时，会维护共享栈的栈顶与栈底，并用 `pending_co` 与 `occupy_co` 成员表示即将被挂起的协程与将要执行的协程，用于保存与恢复共享栈数据。
在协程切换时，会将共享栈的数据保存到 `occupy_co` 的 `save_buffer` 中，将 pending_c 的 `save_buffer` 中的数据拷贝到共享栈中。
## stShareStack_t
```cpp
// 由于堆是由低地址向高地址增长，但栈是由高地址向低地址增长
// 所以 stack_bp + stack_size 是栈底，stack_buffer 是栈顶
struct stStackMem_t // 共享栈的结构体，每个共享栈的内存所在
{
	stCoRoutine_t* occupy_co; // 当前正在使用该共享栈的协程
	int stack_size;   // 栈的大小
	char* stack_bp;   // stack_buffer + stack_size 栈底
	char* stack_buffer; // 共享栈的内存，栈顶
};

struct stShareStack_t // 所有共享栈的结构体
{
	unsigned int alloc_idx; // 目前正在使用的共享栈的 index
	int stack_size; // 共享栈的大小，这里的大小指的是一个 stStackMem_t* 的大小
	int count;      // 共享栈的个数
	stStackMem_t** stack_array; // 存储所有共享栈的数组，元素是 stStackMem_t*
};
```
## Alloc
```cpp
stShareStack_t* co_alloc_sharestack(int count, int stack_size)
{
	stShareStack_t* share_stack = (stShareStack_t*)malloc(sizeof(stShareStack_t));
	share_stack->alloc_idx = 0;
	share_stack->stack_size = stack_size; 

	// alloc stack array
	share_stack->count = count;
	stStackMem_t** stack_array = (stStackMem_t**)calloc(count, sizeof(stStackMem_t*)); 
	for (int i = 0; i < count; i++)
    	//co_alloc_stackmem用于分配每个共享栈内存
		stack_array[i] = co_alloc_stackmem(stack_size); 
	share_stack->stack_array = stack_array;
	return share_stack;
}

stStackMem_t* co_alloc_stackmem(unsigned int stack_size)
{
	stStackMem_t* stack_mem = (stStackMem_t*)malloc(sizeof(stStackMem_t));
	stack_mem->occupy_co= NULL; // 当前没有协程使用该共享栈
	stack_mem->stack_size = stack_size;
	stack_mem->stack_buffer = (char*)malloc(stack_size); // 栈顶，低内存空间
	stack_mem->stack_bp = stack_mem->stack_buffer + stack_size; // 栈底，高地址空间
	return stack_mem;
}
```
`malloc` 申请后空间的值是随机的，并没有进行初始化，而 `calloc` 在申请后，对空间逐一进行初始化，并设置值为 0。
## stCoRoutine_t
```cpp
// 协程结构体
struct stCoRoutine_t
{
	stCoRoutineEnv_t *env;  // 协程所在的运行环境，可以理解为，该协程所属的协程管理器
	
	pfn_co_routine_t pfn; // 协程所对应的函数
	void *arg;   // 函数参数
	coctx_t ctx; // 协程上下文，包括寄存器和栈
 
	char cStart;          // 是否已经开始运行
	char cEnd;            // 是否已经结束
	char cIsMain;         // 是否是主协程
	char cEnableSysHook;  // 是否要打开钩子标识，默认是关闭的
	char cIsShareStack;   // 是否要采用共享栈

	void *pvEnv;

	stStackMem_t* stack_mem; // 栈内存
	
	char* stack_sp; // 协程在共享栈中已经使用的栈顶
	
	unsigned int save_size; // save_buffer的长度
	char* save_buffer; // 当协程挂起时，栈的内容会栈暂存到save_buffer中

	stCoSpec_t aSpec[1024]; 
};

typedef void *(*pfn_co_routine_t)(void *); //协程函数类型

struct stCoRoutineAttr_t
{
	int stack_size; // 如果是共享栈模式，则不用指定。如果不是共享栈模式，则必需指定
	stShareStack_t* share_stack;
	stCoRoutineAttr_t()
	{
		// 默认是128k
		stack_size = 128 * 1024; 
		// 默认不是共享栈
		share_stack = NULL;
	}
}__attribute__ ((packed));

// 线程所管理的协程的运行环境，一个线程只有一个这个属性
struct stCoRoutineEnv_t
{
	// 这里实际上维护的是个调用栈
	// 最后一位是当前运行的协程，前一位是当前协程的父协程(即，resume该协程的协程)
	// 可以看出来，libco只能支持128层协程的嵌套调用
	stCoRoutine_t *pCallStack[ 128 ]; 

	int iCallStackSize; // 当前调用栈长度

	stCoEpoll_t *pEpoll;  // 主要是epoll，作为协程的调度器

	// 当采用共享栈模式时，用于共享栈数据的保存与恢复
	stCoRoutine_t* pending_co;  
	stCoRoutine_t* occupy_co;
};
```
## Create
接下来是协程创建的具体过程，需要重点关注共享栈的分配：
```cpp
/**
* 创建一个协程对象
* 
* @param ppco - (output) 协程的地址，未初始化，需要在此函数中将其申请内存空间以及初始化工作
* @param attr - (input) 协程属性，目前主要是共享栈 
* @param pfn - (input) 协程所运行的函数
* @param arg - (input) 协程运行函数的参数
*/
int co_create( stCoRoutine_t **ppco, const stCoRoutineAttr_t *attr,
              pfn_co_routine_t pfn, void *arg )
{
	// 查找当前线程的管理环境
	if( !co_get_curr_thread_env() ) 
	{
		// 如果找不到，则初始化协程
		co_init_curr_thread_env();
	}

	// 根据协程的运行环境，来创建一个协程
	stCoRoutine_t *co = co_create_env( co_get_curr_thread_env(), attr, pfn,arg );

	*ppco = co;
	return 0;
}

/**
* 根据协程管理器env, 新建一个协程
* 
* @param env - (input) 协程所在线程的环境
* @param attr - (input) 协程属性，目前主要是共享栈 
* @param pfn - (input) 协程所运行的函数
* @param arg - (input) 协程运行函数的参数
*/
struct stCoRoutine_t *co_create_env( stCoRoutineEnv_t * env, const stCoRoutineAttr_t* attr,
		pfn_co_routine_t pfn, void *arg )
{
	// 初始化属性。并且给默认值
	stCoRoutineAttr_t at;
	if( attr )
	{
		memcpy( &at,attr,sizeof(at) );
	}


	if( at.stack_size <= 0 )
	{
		at.stack_size = 128 * 1024; // 默认的为128k
	}
	else if( at.stack_size > 1024 * 1024 * 8 )
	{
		at.stack_size = 1024 * 1024 * 8;
	}

	if( at.stack_size & 0xFFF ) 
	{
		at.stack_size &= ~0xFFF;
		at.stack_size += 0x1000;
	}

	stCoRoutine_t *lp = (stCoRoutine_t*)malloc( sizeof(stCoRoutine_t) );
	
	memset( lp,0,(long)(sizeof(stCoRoutine_t))); 

	lp->env = env;
	lp->pfn = pfn;
	lp->arg = arg;

	stStackMem_t* stack_mem = NULL;
	if( at.share_stack )
	{
		// 如果采用了共享栈模式，则获取到其中一个共享栈的内存
		stack_mem = co_get_stackmem( at.share_stack); 
		at.stack_size = at.share_stack->stack_size;
	}
	else
	{
		// 如果没有采用共享栈，则分配内存
		stack_mem = co_alloc_stackmem(at.stack_size);
	}

	lp->stack_mem = stack_mem;

	// 设置该协程的context
	lp->ctx.ss_sp = stack_mem->stack_buffer; // 栈地址
	lp->ctx.ss_size = at.stack_size; // 栈大小

	lp->cStart = 0;
	lp->cEnd = 0;
	lp->cIsMain = 0;
	lp->cEnableSysHook = 0;	// 默认不开启hook
	lp->cIsShareStack = at.share_stack != NULL;

	// 仅在共享栈的时候有意义
	lp->save_size = 0;
	lp->save_buffer = NULL;

	return lp;
}

/*
* 在共享栈中，获取协程的栈内存
*/
static stStackMem_t* co_get_stackmem(stShareStack_t* share_stack)
{
	if (!share_stack)
	{
		return NULL;
	}

	// 轮询的使用shared_stack
	int idx = share_stack->alloc_idx % share_stack->count;
	share_stack->alloc_idx++;

	return share_stack->stack_array[idx];
}

```
## Swap
```cpp
// 1. 将当前的运行上下文保存到curr中
// 2. 将当前的运行上下文替换为pending_co中的上下文
void co_swap(stCoRoutine_t* curr, stCoRoutine_t* pending_co)
{
 	stCoRoutineEnv_t* env = co_get_curr_thread_env();

	//get curr stack sp
	//c变量的作用是为了找到目前的栈顶，因为c变量是最后一个放入栈中的内容。
	char c;
	curr->stack_sp= &c;

	if (!pending_co->cIsShareStack)
	{  
		// 如果没有采用共享栈，清空pending_co和occupy_co
		env->pending_co = NULL;
		env->occupy_co = NULL;
	}
	else 
	{   
		// 如果采用了共享栈
		env->pending_co = pending_co; 
		
		// get last occupy co on the same stack mem
		// occupy_co指的是，和pending_co共同使用一个共享栈的协程
		// 把它取出来是为先把occupy_co的内存保存起来
		stCoRoutine_t* occupy_co = pending_co->stack_mem->occupy_co;
		
		// set pending co to occupy thest stack mem;
		// 将该共享栈的占用者改为pending_co
		pending_co->stack_mem->occupy_co = pending_co;

		env->occupy_co = occupy_co;
		
		if (occupy_co && occupy_co != pending_co)
		{  
			// 如果上一个使用协程不为空, 则需要把它的栈内容保存起来
			save_stack_buffer(occupy_co);
		}
	}

	// swap context
	coctx_swap(&(curr->ctx),&(pending_co->ctx) );

	// 上一步coctx_swap会进入到pending_co的协程环境中运行
	// 到这一步，已经yield回此协程，才会执行下面的语句
	// 而yield回此协程之前，env->pending_co会被上一层协程设置为此协程
	// 因此将之前保存起来的栈内容，恢复到运行栈上，可以顺利执行，

	//stack buffer may be overwrite, so get again;
	stCoRoutineEnv_t* curr_env = co_get_curr_thread_env();
	stCoRoutine_t* update_occupy_co =  curr_env->occupy_co;
	stCoRoutine_t* update_pending_co = curr_env->pending_co;
	
	// 将栈的内容恢复，如果不是共享栈的话，每个协程都有自己独立的栈空间，则不用恢复。
	if (update_occupy_co && update_pending_co && update_occupy_co != update_pending_co)
	{
		// resume stack buffer
		if (update_pending_co->save_buffer && update_pending_co->save_size > 0)
		{
			// 将之前保存起来的栈内容，恢复到运行栈上
			memcpy(update_pending_co->stack_sp, update_pending_co->save_buffer, update_pending_co->save_size);
		}
	}
}

// 将原本占用共享栈的协程的内存保存起来。
void save_stack_buffer(stCoRoutine_t* occupy_co)
{
	///copy out
	stStackMem_t* stack_mem = occupy_co->stack_mem;
	// 计算出栈的大小
	int len = stack_mem->stack_bp - occupy_co->stack_sp;

	if (occupy_co->save_buffer)
	{
		free(occupy_co->save_buffer), occupy_co->save_buffer = NULL;
	}

	occupy_co->save_buffer = (char*)malloc(len); //malloc buf;
	occupy_co->save_size = len;

	// 将当前运行栈的内容，拷贝到save_buffer中
	memcpy(occupy_co->save_buffer, occupy_co->stack_sp, len);
}
```