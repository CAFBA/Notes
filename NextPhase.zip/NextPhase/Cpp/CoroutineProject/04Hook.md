# Hook
## Hook
`hook` 是对系统调用 `API` 的封装，将其封装成一个与原始的系统调用 `API` 同名的接口，应用在调用这个接口时，会先执行封装中的操作，再执行原始的系统调用 `API`。`hook` 技术可以使应用程序在执行系统调用之前进行一些隐藏的操作，比如可以对系统提供 `malloc()` 和 `free()` 进行 `hook`，在真正进行内存分配和释放之前，统计内存的引用计数，以排查内存泄露问题。通过 `hook` 模块，可以使一些不具异步功能的 `API`，展现出异步的性能。
### Feature
`hook` 的目的是在不重新编写代码的情况下，把 `socket IO` 相关的 `API` 都转成异步，以提高性能。`hook` 和 `IO` 协程调度是密切相关的，如果不使用 `IO` 协程调度器，那 `hook` 没有任何意义，考虑 `IOManager` 要在一个线程上按顺序调度以下协程：
- 协程 1：`sleep(2)` 睡眠两秒后返回。
- 协程 2：在 `scoket fd1` 上 `send 100k` 数据。
- 协程 3：在 `socket fd2` 上 `recv` 直到数据接收成功。
在未 `hook` 的情况下，`IOManager` 要调度上面的协程，流程是下面这样的：
1. 调度协程 1，协程阻塞在 `sleep` 上，等 2 秒后返回，这两秒内调度线程是被协程 1 占用的，其他协程无法在当前线程上调度。
2. 调度协徎 2，协程阻塞 `send 100k` 数据上，但如果 `fd` 迟迟不可写，那 `send` 会阻塞直到套接字可写，同样，在阻塞期间，其他协程也无法在当前线程上调度。
3. 调度协程 3，协程阻塞在 `recv` 上，这个操作要直到 `recv` 超时或是有数据时才返回，期间调度器也无法调度其他协程。
上面的调度流程最终总结起来就是，协程只能按顺序调度，一旦有一个协程阻塞，那整个调度线程也被阻塞，其他的协程都无法在当前线程上执行。因此需要实现 hook，使得调用上述时变为以下流程：
1. 调度协程 1，检测到协程 `sleep`，先添加一个 `2` 秒的定时器，定时器回调函数为 `resume` 本协程，然后当前协程 `yield`，等定时器超时。
2. 因为上一步协程 1 已经 `yield`，所以协徎 `2` 并不需要等 `2` 秒后才可以执行，而是立刻可以执行。同样，调度器检测到协程 `send`，由于不知道 `fd` 是不是马上可写，所以先在 `IOManager` 上给 `fd` 注册一个写事件，回调函数为 `resume` 当前协程并执行 `send`，然后当前协程 `yield`，等可写事件发生。
3. 上一步协徎 2 也已经 `yield`，可以马上调度协程 3。类似地，给 `fd` 注册一个读事件，回调函数为 `resume` 当前协程并执行 `recv`，然后本协程 `yield`，等事件发生。
4. 等 2 秒超时后，执行定时器回调函数，将协程1 `resume` 以便继续执行。
5. 等协程 2 的 `fd` 可写，一旦可写，调用写事件回调函数将协程 2 `resume` 继续执行 `send`。
6. 等协程 3 的 `fd` 可读，一旦可读，调用回调函数将协程 3 `resume` 继续执行 `recv`。
上面的 4、5、6 都是异步的，调度线程并不会阻塞，`IOManager` 仍然可以调度其他的任务，只在相关的事件发生后，再继续执行对应的任务即可。并且，由于 `hook` 的函数签名与原函数一样，所以对调用方也很方便，只需要以同步的方式编写代码，实现的效果却是异步执行的，效率很高。
因此在 `IO` 协程调度中对相关的系统调用进行 `hook`，提供阻塞调用的异步实现，使得调度线程不会浪费在阻塞等待中。
`hook` 的重点是在替换 `API` 的底层实现的同时完全模拟其原本的行为，因为调用方是不知道 `hook` 的细节的，在调用被 `hook` 的 `API` 时，如果其行为与原本的行为不一致，就会给调用方造成困惑。比如，所有的 `socket fd` 在进行 `IO` 调度时都会被设置成 `NONBLOCK` 模式，如果用户未显式地对 fd 设置 `NONBLOCK`，那就要处理 `fcntl`，不要对用户暴露 `fd` 已经是 `NONBLOCK` 的事实，这点也说明除 `IO` 相关的函数要进行 `hook` 外，对 `fcntl`， `setsockopt` 等功能函数也要进行 `hook`，才能保证 `API` 的一致性。
### Implement
`hook` 的实现机制就是通过动态库的全局符号介入功能，用自定义的接口来替换掉同名的系统调用接口。由于系统调用接口基本上是由 `C` 标准函数库 `libc` 提供的，所以这里要做的事情就是用自定义的动态库来覆盖掉 `libc` 中的同名符号。

```cpp main.c
#include <unistd.h>
#include <string.h>
 
int main() {
    write(STDOUT_FILENO, "hello world\n", strlen("hello world\n")); // 调用系统调用write写标准输出文件描述符
    return 0;
}

// gcc编译生成可执行文件时会默认链接libc库，所以不需要显式指定链接参数
// 这点可以在编译时给 gcc 增加一个 "-v" 参数，将整个编译流程详细地打印出来进行验证：
# gcc -v main.c
```
基于动态链接的 `hook` 有两种方式，第一种是外挂式 `hook`，也称为非侵入式 `hook`，通过优先加载自定义动态库来实现对后加载的动态库进行 `hook`，这种 `hook` 方式不需要重新编译代码。下面在不重新编译代码的情况下，用自定义的动态库来替换掉可执行程序 `a.out` 中的 `write` 实现，新建 `hook.c`，将 `hook.c` 编译成动态库，通过设置 `LD_PRELOAD` 环境变量，将 `libhoook.so` 设置成优先加载，从而覆盖掉 `libc` 中的 `write` 函数，如下：
```cpp
#include <unistd.h>
#include <sys/syscall.h>
#include <string.h>
 
ssize_t write(int fd, const void *buf, size_t count) {
    syscall(SYS_write, STDOUT_FILENO, "12345\n", strlen("12345\n"));
}

gcc -fPIC -shared hook.c -o libhook.so
# LD_PRELOAD="./libhook.so"
```
`LD_PRELOAD` 环境变量指定系统在运行 `main.out` 之前，优先把 `libhook.so` 加载到程序的进程空间，使得在 `main.out` 运行之前，其全局符号表中就已经有一个 `write` 符号，这样在后续加载 `libc` 共享库时，由于全局符号介入机制，`libc` 中的 `write` 符号不会再被加入全局符号表，所以全局符号表中的 `write` 就变成自己的实现。
第二种方式的 `hook` 是侵入式的，需要修改原本调用 `write` 的代码或重新编译一次以指定动态库加载顺序。
下面修改代码将 `write` 函数的实现放在 `main.c` 里，那么编译时全局符号表里先出现的必然是 `main.c` 中的 `write` 符号：
```cpp
#include <unistd.h>
#include <string.h>
#include <sys/syscall.h>
 
ssize_t write(int fd, const void *buf, size_t count) {
    syscall(SYS_write, STDOUT_FILENO, "12345\n", strlen("12345\n"));
}

int main() {
    write(STDOUT_FILENO, "hello world\n", strlen("hello world\n")); // 这里调用的是上面的write实现
    return 0;
}
```
如果不修改代码，那么需要重新编译一次，通过编译参数将自定义的动态库放在 `libc` 之前进行链接。默认情况下 `gcc` 总会链接一次 `libc`，并且 `libc` 的位置也总在命令行所有参数后面：
```cpp
// -Wl,-rpath=. 用于指定运行时的动态库搜索路径，避免找不到动态库的问题
# gcc main.c -L. -lhook -Wl,-rpath=.

// 可以通过 ldd 命令来查看查看可执行程序的依赖的共享库
# ldd main.out
        linux-vdso.so.1 (0x00007ffe615f9000)
        libhook.so => ./libhook.so (0x00007fab4bae3000)
        libc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x00007fab4b8e9000)
        /lib64/ld-linux-x86-64.so.2 (0x00007fab4baef000)
```
由于显式指定链接 `libhook.s`，链接位置比 `libc` 要靠前，所以运行时会先加载 `libhook.so`，从而实现全局符号介入。
此外，大部分情况下，系统调用提供的功能都是无可替代的，虽然可以用 `hook` 的方式将其替换成自己的实现，但是最终要实现的功能，还是得由原始的系统调用接口来完成，因此需要找回已经被全局符号介入机制覆盖的系统调用接口。
以 `malloc` 和 `free`为例，具体的实现方式应该是先调用自定义的 `malloc` 和 `free`实现，在分配和释放内存之前，记录下内存地址，然后再调用标准库里的 `malloc` 和 `free`，以真正实现内存申请和释放。
上面的过程涉及到查找后加载的动态库里被覆盖的符号地址问题，程序运行时，依赖的动态库无论是先加载还是后加载，最终都会被加载到程序的进程空间中，也就是说，那些因为加载顺序靠后而被覆盖的符号，实际上是被隐藏，还是存在于程序的进程空间中的，可以通过 `Linux` 的 `dlsym` 找回被覆盖的符号：
```cpp
#define _GNU_SOURCE
#include <dlfcn.h>
 
void *dlsym(void *handle, const char *symbol);
```
在链接时需要指定 `-ldl` 参数。使用 `dlsym` 找回被覆盖的符号时，第一个参数固定为 `RTLD_NEXT`，第二个参数为符号的名称：
```cpp
#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
 
typedef void* (*malloc_func_t)(size_t size);
typedef void (*free_func_t)(void *ptr);
 
// 这两个指针用于保存libc中的malloc和free的地址
malloc_func_t sys_malloc = NULL;
free_func_t sys_free = NULL;
 
// 重定义malloc和free，在这里重定义会导致libc中的同名符号被覆盖
// 这里不能调用带缓冲的printf接口，否则会出段错误
void *malloc(size_t size) {
    // 先调用标准库里的 malloc 申请内存，再记录内存分配信息
    void *ptr = sys_malloc(size);
    fprintf(stderr, "malloc: ptr=%p, length=%ld\n", ptr, size);
    return ptr;
}
void free(void *ptr) {
    // 打印内存释放信息，再调用标准库里的 free 释放内存
    fprintf(stderr, "free: ptr=%p\n", ptr);
    sys_free(ptr);
}
 
int main() {
    // 通过 dlsym 找到标准库中的 malloc 和 free 的符号地址
    sys_malloc = dlsym(RTLD_NEXT, "malloc");
    assert(dlerror() == NULL);
    sys_free = dlsym(RTLD_NEXT, "free");
    assert(dlerror() == NULL);
 
    char *ptrs[5];
 
    for(int i = 0; i < 5; i++) {
        ptrs[i] = malloc(100 + i);
        memset(ptrs[i], 0, 100 + i);
    }
     
    for(int i = 0; i < 5; i++) free(ptrs[i]);
    return 0;
}
```
## Sylar Hook
`sylar` 的 `hook` 功能以线程为单位，可自由设置当前线程是否使用 `hook`。默认情况下，协程调度器的调度线程会开启 `hook`，而其他线程则不会开启。
`sylar` 对以下函数进行 `hook`，并只对 `socket fd` 进行 `hook`，如果操作的不是 `socket fd`，那会直接调用系统原本的 `API`，而不是 `hook` 之后的 `API`：
```cpp
sleep usleep nanosleep 
socket connect accept 
read readv recv recvfrom recvmsg
write writev
send sendto sendmsg
close
fcntl ioctl
getsockopt setsockopt
```
除此外，`sylar` 还增加了一个 `connect_with_timeout` 接口用于实现带超时的 `connect`。
### Coroutine
关于 `hook` 模块和 `IO` 协程调度的整合。一共有三类接口需要 hook，如下：
1. `sleep` 延时系列接口，包括 `sleep/usleep/nanosleep`。对于这些接口的 `hook`，只需要给 `IO` 协程调度器注册一个定时事件，在定时事件触发后再继续执行当前协程即可，当前协程在注册完定时事件后即可 `yield` 让出执行权。
2. `socket IO` 系列接口，包括 `read/write/recv/send/connect/accept` 等，这类接口的 `hook` 首先需要判断操作的 `fd` 是否是 `socket fd`，以及用户是否显式地对该 `fd` 设置过非阻塞模式，如果不是 `socket fd` 或是用户显式设置过非阻塞模式，那么就不需要 `hook`，直接调用操作系统的 `IO` 接口即可。如果需要 `hook`，那么首先在 `IO` 协程调度器上注册对应的读写事件，等事件发生后再继续执行当前协程，当前协程在注册完 `IO` 事件即可 `yield` 让出执行权。
3. `socket/fcntl/ioctl/close` 等接口，这类接口主要处理的是边缘情况，比如分配 `fd` 上下文，处理超时及用户显式设置非阻塞问题。
### Singleton
```cpp
 // T 为类型 X 为创造多个实例对应的Tag N 为同一个 Tag 创造多个实例的索引
template<class T, class X = void, int N = 0>
class Singleton { // 单例模式封装类
public:
    static T* GetInstance() { // 返回单例裸指针
        static T v;
        return &v;
    }
};

template<class T, class X = void, int N = 0>
class SingletonPtr { // 单例模式智能指针封装类
public:
    static std::shared_ptr<T> GetInstance() { // 返回单例智能指针
        static std::shared_ptr<T> v(new T);
        return v;
    }
};
```
### FdManager Interface
`FdCtx` 类记录 `socket fd` 上下文信息，，并在用户态记录 `fd` 的读写超时和非阻塞信息，其中非阻塞包括用户显式设置的非阻塞和 `hook` 内部设置的非阻塞，区分这两种非阻塞可以有效应对用户对 `fd` 设置/获取 `NONBLOCK` 模式的情形。
用户层面的非阻塞标志是应用程序级别的设置，用于控制应用程序如何处理 `I/O` 操作。当设置用户层面的非阻塞标志后，如果一个非阻塞操作无法立即完成，应用程序可以选择立即返回一个错误（如 `EAGAIN` 或 `EWOULDBLOCK`），或者选择等待直到操作可以继续。
用户层面的非阻塞标志通常用于配合 `epoll` 实现异步 `I/O` 或事件驱动的编程模型，其中应用程序需要在 `I/O` 操作不可用时立即返回，而不是阻塞等待。
系统层面的非阻塞标志是操作系统级别的设置，用于控制内核如何处理 `I/O` 操作。当设置系统层面的非阻塞标志后，内核在执行 `I/O` 操作时不会阻塞，而是立即返回一个错误，表示操作当前不可用。
系统层面的非阻塞标志通常用于实现同步 `I/O` 或轮询驱动的编程模型，其中应用程序需要定期检查 `I/O` 操作的状态，以确定何时可以继续操作。
为管理所有的 `socket fd`，`sylar` 设计 `FdManager` 单例类来记录所有分配过的 `fd` 的上下文。
```cpp
/**
 * @brief 文件句柄上下文类
 * @details 管理文件句柄类型(是否socket)
 *          是否阻塞,是否关闭,读/写超时时间
 */
class FdCtx : public std::enable_shared_from_this<FdCtx> {
public:
    typedef std::shared_ptr<FdCtx> ptr;

    explicit FdCtx(int fd); // 通过文件句柄构造FdCtx
 
    ~FdCtx();

    bool isInit() const { return m_isInit;} // 是否初始化完成

    bool isSocket() const { return m_isSocket;} // 是否socket

    bool isClose() const { return m_isClosed;} // 是否已关闭
    
    // 设置用户显式设置的非阻塞
    void setUserNonblock(bool v) { m_userNonblock = v;} 

    // 获取用户显式设置的非阻塞
    bool getUserNonblock() const { return m_userNonblock;} 

    // 设置系统非阻塞
    void setSysNonblock(bool v) { m_sysNonblock = v;}

    // 获取系统非阻塞
    bool getSysNonblock() const { return m_sysNonblock;}

    // 设置超时时间 
    // type 类型SO_RCVTIMEO(读超时), SO_SNDTIMEO(写超时) v 时间毫秒
    void setTimeout(int type, uint64_t v);

    // 获取超时时间
    uint64_t getTimeout(int type);
private:
    bool init();
private: // 将 bool 变量声明为位字段
    /// 是否初始化
    bool m_isInit: 1;
    /// 是否socket
    bool m_isSocket: 1;
    /// 是否hook非阻塞
    bool m_sysNonblock: 1;
    /// 是否用户主动设置非阻塞
    bool m_userNonblock: 1;
    /// 是否关闭
    bool m_isClosed: 1;
    /// 文件句柄
    int m_fd;
    /// 读超时时间毫秒
    uint64_t m_recvTimeout;
    /// 写超时时间毫秒
    uint64_t m_sendTimeout;
};

class FdManager { // 文件句柄管理类
public:
    typedef RWMutex RWMutexType;
    
    FdManager();
    
    // 获取/创建文件句柄类FdCtx，返回对应文件句柄类FdCtx::ptr
    // auto_create 表示 fd 不存在是是否自动创建
    FdCtx::ptr get(int fd, bool auto_create = false); 

    void del(int fd); // 删除文件句柄类
private:
    /// 读写锁
    RWMutexType m_mutex;
    /// 文件句柄集合
    // FdManager 类对 FdCtx 的寻址采用和 IOManager 中对 FdContext 的寻址一样的寻址方式
    // 直接用 fd 作为数组下标进行寻址
    std::vector<FdCtx::ptr> m_datas;
};

/// 文件句柄单例
typedef Singleton<FdManager> FdMgr;
```
### FdManager Implement
```cpp
FdCtx::FdCtx(int fd)
    :m_isInit(false)
    ,m_isSocket(false)
    ,m_sysNonblock(false)
    ,m_userNonblock(false)
    ,m_isClosed(false)
    ,m_fd(fd)
    ,m_recvTimeout(-1)
    ,m_sendTimeout(-1) {
    init();
}

FdCtx::~FdCtx() {
}

bool FdCtx::init() {
    if(m_isInit) return true;
    m_recvTimeout = -1;
    m_sendTimeout = -1;

    struct stat fd_stat{}; // 存储文件描述符的状态信息
    
    // 调用 fstat 获取文件描述符 m_fd 的状态信息
    // 如果调用失败返回-1，则将 m_isInit 设置为 false
    // 表示初始化失败，并且不是一个套接字
    if(-1 == fstat(m_fd, &fd_stat)) {
        m_isInit = false;
        m_isSocket = false;
    } else {
        m_isInit = true;
        // 检查文件描述符是否指向一个套接字
        // S_ISSOCK 是一个宏，用于检查 st_mode 字段是否表示一个套接字
        m_isSocket = S_ISSOCK(fd_stat.st_mode);
    }

    if(m_isSocket) {
        const int flags = fcntl_f(m_fd, F_GETFL, 0);
        // 检查文件描述符是否设置为阻塞模式
        if(!(flags & O_NONBLOCK)) {
            // 如果为阻塞模式，则将其设置为非阻塞模式
            fcntl_f(m_fd, F_SETFL, flags | O_NONBLOCK);  
        }
        m_sysNonblock = true; // hook 非阻塞
    } else {
        m_sysNonblock = false;
    }

    m_userNonblock = false; // 用户没有显式地设置非阻塞模式
    m_isClosed = false;
    return m_isInit;
}

void FdCtx::setTimeout(int type, uint64_t v) {
    if(type == SO_RCVTIMEO) { // 设置接收超时
        m_recvTimeout = v;
    } else {
        m_sendTimeout = v;    // 设置发送超时
    }
}

uint64_t FdCtx::getTimeout(int type) {
    if(type == SO_RCVTIMEO) {
        return m_recvTimeout;
    } else {
        return m_sendTimeout;
    }
}

FdManager::FdManager() {
    m_datas.resize(64);
}

FdCtx::ptr FdManager::get(int fd, bool auto_create) {
    if(fd == -1) { // 表示无效的文件描述符
        return nullptr;
    }
    RWMutexType::ReadLock lock(m_mutex);
    if((int)m_datas.size() <= fd) { // 若空间不够存储
        if(auto_create == false) 
            return nullptr; // 并且不需要创建则直接返回
    } else {
        if(m_datas[fd] && !auto_create) {
            return m_datas[fd]; // 若已经存在则直接返回，否则不返回，下面进行创建
        }
    }
    lock.unlock();
    
    // 创建时先扩容再放进去，然后返回智能指针
    RWMutexType::WriteLock lock2(m_mutex);
    FdCtx::ptr ctx(new FdCtx(fd));
    if(fd >= (int)m_datas.size()) {
        m_datas.resize(fd * 1.5);
    }
    m_datas[fd] = ctx;
    return ctx;
}

void FdManager::del(int fd) {
    RWMutexType::WriteLock lock(m_mutex);
    if((int)m_datas.size() <= fd) return;
    m_datas[fd].reset(); // 引用计数减 1
}
```
### Hook
宏 `HOOK_FU` 用于生成一系列函数调用，接受一个参数 `XX`，这参数 `XX` 又是一个宏，用于 `dlsym` 获取各个被 `hook` 的接口的原始地址和 `hook` 接口类型定义。
```cpp
#define HOOK_FUN(XX) \
    XX(sleep)        \
    XX(usleep)       \
    XX(nanosleep)    \
    XX(socket)       \
    XX(connect)      \
    XX(accept)       \
    XX(read)         \
    XX(readv)        \
    XX(recv)         \
    XX(recvfrom)     \
    XX(recvmsg)      \
    XX(write)        \
    XX(writev)       \
    XX(send)         \
    XX(sendto)       \
    XX(sendmsg)      \
    XX(close)        \
    XX(fcntl)        \
    XX(ioctl)        \
    XX(getsockopt)   \
    XX(setsockopt)

// hook_init() 会在一个静态对象的构造函数中调用
// 这表示在 main 函数运行之前就会获取各个符号的地址并保存在全局变量中
void hook_init() {
    static bool is_inited = false;
    if (is_inited) return;
    // 通过 dlsym 获取各个被 hook 的接口的原始地址
#define XX(name) name##_f = (name##_fun)dlsym(RTLD_NEXT, #name); // 获取运行时候的地址
    HOOK_FUN(XX);
#undef XX

    // ...
    // sleep_f = (sleep_fun)dlsym(RTLD_NEXT, "sleep"); \
    // usleep_f = (usleep_fun)dlsym(RTLD_NEXT, "usleep"); \
    // ...
    // setsocketopt_f = (setsocketopt_fun)dlsym(RTLD_NEXT, "setsocketopt");
}
```
`hook` 接口要存放到 `extern "C"` 作用域下，指定函数按照 `C` 语言的方式进行编译和链接。它的作用是为解决 `C++` 中函数名重载的问题，使得 `C++` 代码可以和 `C` 语言代码进行互操作。
```cpp
extern "C" {   
    //sleep
    typedef unsigned int (*sleep_fun)(unsigned int seconds);
    extern sleep_fun sleep_f;
    
    typedef int (*usleep_fun)(useconds_t usec);
    extern usleep_fun usleep_f;
    
    typedef int (*nanosleep_fun)(const struct timespec *req, struct timespec *rem);
    extern nanosleep_fun nanosleep_f;
    
    //socket
    typedef int (*socket_fun)(int domain, int type, int protocol);
    extern socket_fun socket_f;
    
    typedef int (*connect_fun)(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
    extern connect_fun connect_f;
    
    typedef int (*accept_fun)(int s, struct sockaddr *addr, socklen_t *addrlen);
    extern accept_fun accept_f;
    
    //read
    typedef ssize_t (*read_fun)(int fd, void *buf, size_t count);
    extern read_fun read_f;
    
    typedef ssize_t (*readv_fun)(int fd, const struct iovec *iov, int iovcnt);
    extern readv_fun readv_f;
    
    typedef ssize_t (*recv_fun)(int sockfd, void *buf, size_t len, int flags);
    extern recv_fun recv_f;
    
    typedef ssize_t (*recvfrom_fun)(int sockfd, void *buf, size_t len, int flags, struct sockaddr *src_addr, socklen_t *addrlen);
    extern recvfrom_fun recvfrom_f;
    
    typedef ssize_t (*recvmsg_fun)(int sockfd, struct msghdr *msg, int flags);
    extern recvmsg_fun recvmsg_f;
    
    //write
    typedef ssize_t (*write_fun)(int fd, const void *buf, size_t count);
    extern write_fun write_f;
    
    typedef ssize_t (*writev_fun)(int fd, const struct iovec *iov, int iovcnt);
    extern writev_fun writev_f;
    
    typedef ssize_t (*send_fun)(int s, const void *msg, size_t len, int flags);
    extern send_fun send_f;
    
    typedef ssize_t (*sendto_fun)(int s, const void *msg, size_t len, int flags, const struct sockaddr *to, socklen_t tolen);
    extern sendto_fun sendto_f;
    
    typedef ssize_t (*sendmsg_fun)(int s, const struct msghdr *msg, int flags);
    extern sendmsg_fun sendmsg_f;
    
    typedef int (*close_fun)(int fd);
    extern close_fun close_f;
    
    typedef int (*fcntl_fun)(int fd, int cmd, ... /* arg */ );
    extern fcntl_fun fcntl_f;
    
    typedef int (*ioctl_fun)(int d, unsigned long int request, ...);
    extern ioctl_fun ioctl_f;
    
    typedef int (*getsockopt_fun)(int sockfd, int level, int optname, void *optval, socklen_t *optlen);
    extern getsockopt_fun getsockopt_f;
    
    typedef int (*setsockopt_fun)(int sockfd, int level, int optname, const void *optval, socklen_t optlen);
    extern setsockopt_fun setsockopt_f;
    
    extern int connect_with_timeout(int fd, const struct sockaddr* addr, socklen_t addrlen, uint64_t timeout_ms);
}
```
各个接口的 `hook` 实现部分和通过宏定义的全局变量要放在 `extern "C"` 中，指定函数按照 `C` 语言的方式进行编译和链接，以防止 `C++` 编译器对符号名称添加修饰。
```cpp
extern "C" {
    #define XX(name) name##_fun name##_f = nullptr;
        HOOK_FUN(XX);
    #undef XX
    ... // 接口实现部分
}

// 展开后如下，通过宏定义全局变量，再通过 hook_init 进行赋值，保存符号地址
extern "C" {
    sleep_fun sleep_f = nullptr; \
    usleep_fun usleep_f = nullptr; \
    ...
    setsocketopt_fun setsocket_f = nullptr;
};
```
####  `_HookIniter`
```cpp
static uint64_t s_connect_timeout = -1;
struct _HookIniter {
    _HookIniter() {
        hook_init(); // 放在静态对象的构造函数中，表明在 main 函数运行之前就会调用这个
    }
};

static _HookIniter s_hook_initer;
```
####  `t_hook_enable`
线程局部变量 `t_hook_enable`，用于表示当前线程是否启用 `hook`，使用线程局部变量表示 `hook` 模块是线程粒度的，各个线程可单独启用或关闭 `hook`。
```cpp
static thread_local bool t_hook_enable = false;

bool is_hook_enable() { // 当前线程是否hook
    return t_hook_enable;
}

void set_hook_enable(bool flag) { // 设置当前线程的hook状态
    t_hook_enable = flag;
}
```
### Sleep
因为 `connect` 是 `io` 事件，与 `fd` 有关，所以 `connect_with_timeout` 监听可写事件以 `resume`，而 `sleep` 与 `fd`  无关，需要添加定时器，通过超时触发回调函数，回调函数为 `schedule`，向任务队列添加当前 `sleep` 协程从而 `resume`。
由于定时器模块只支持毫秒级定时，所以被 `hook` 后的 `nanosleep()` 实际精度只能达到毫秒级，而不是纳秒级。
```cpp
unsigned int sleep(unsigned int seconds) {
    if(!cafba::t_hook_enable) return sleep_f(seconds);
 
    cafba::Fiber::ptr fiber = cafba::Fiber::GetThis();
    cafba::IOManager* iom = cafba::IOManager::GetThis();
    iom->addTimer(seconds * 1000, 
    std::bind(
    (void(cafba::Scheduler::*)(cafba::Fiber::ptr, int thread)) &cafba::IOManager::schedule
            ,iom, fiber, -1)
            );
    cafba::Fiber::GetThis()->yield();
    return 0;
}

int usleep(useconds_t usec) {
    if (!cafba::t_hook_enable) return usleep_f(usec);
    
    cafba::Fiber::ptr fiber = cafba::Fiber::GetThis();
    cafba::IOManager *iom   = cafba::IOManager::GetThis();
    iom->addTimer(usec / 1000, std::bind((void(cafba::Scheduler::*)(cafba::Fiber::ptr, int thread)) & cafba::IOManager::schedule, iom, fiber, -1));
    cafba::Fiber::GetThis()->yield();
    return 0;
}

int nanosleep(const struct timespec *req, struct timespec *rem) {
    if (!cafba::t_hook_enable) return nanosleep_f(req, rem);

    int timeout_ms          = req->tv_sec * 1000 + req->tv_nsec / 1000 / 1000;
    cafba::Fiber::ptr fiber = cafba::Fiber::GetThis();
    cafba::IOManager *iom   = cafba::IOManager::GetThis();
    iom->addTimer(timeout_ms, std::bind((void(sylar::Scheduler::*)(cafba::Fiber::ptr, int thread)) & sylar::IOManager::schedule, iom, fiber, -1));
    cafba::Fiber::GetThis()->yield();
    return 0;
}
```
### Socket
`socket` 用于创建套接字，封装为 `hook` 需要在拿到 `fd` 后将其添加到 `FdManager` 中
`setsocketopt` 要特殊处理 `SO_RECVTIMEO` 和 `SO_SNDTIMEO`，在应用层记录套接字的读写超时，方便协程调度器获取。
```cpp
int socket(int domain, int type, int protocol) {
    if(!cafba::t_hook_enable) {return socket_f(domain, type, protocol);
    int fd = socket_f(domain, type, protocol);
    if(fd == -1) return fd;
    cafba::FdMgr::GetInstance()->get(fd, true);
    return fd;
}

int getsockopt(int sockfd, int level, int optname, void *optval, socklen_t *optlen) {
    return getsockopt_f(sockfd, level, optname, optval, optlen);
}

// optval 指向包含新选项值的缓冲区的指针，此处的选项值是时间
int setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen) {
    if(!cafba::t_hook_enable) 
        return setsockopt_f(sockfd, level, optname, optval, optlen);
    // 检查 level 是否为 SOL_SOCKET，对于TCP/IP套接字，通常使用 SOL_SOCKET 来指定选项位于套接字层级
    if(level == SOL_SOCKET) {
        if(optname == SO_RCVTIMEO || optname == SO_SNDTIMEO) {
            cafba::FdCtx::ptr ctx = cafba::FdMgr::GetInstance()->get(sockfd);
            if(ctx) {
                const timeval* v = (const timeval*)optval;
                ctx->setTimeout(optname, v->tv_sec * 1000 + v->tv_usec / 1000);
            }
        }
    }
    return setsockopt_f(sockfd, level, optname, optval, optlen);
}
```
### Connect
由于 `connect` 有默认的超时，所以只需要实现 `connect_with_timeout`。
`connect_with_timeout` 是对 `connect` 系统调用的封装，并添加超时机制，用于在给定的文件描述符上建立一个到远程地址的连接，并允许设置一个超时时间。
等待超时或套接字可写时，如果先超时，则条件变量 `winfo` 仍然有效，通过 `winfo` 来设置超时标志并触发 `WRITE` 事件，协程从 `yield` 点返回，返回之后通过超时标志设置 `errno` 并返回 -1，如果在未超时之前套接字就可写，那么直接取消定时器并返回成功。
取消定时器会导致定时器回调被强制执行一次，但这并不会导致问题，因为只有当前协程结束后，定时器回调才会在接下来被调度，由于定时器回调被执行时 `connect_with_timeout` 协程已经执行完，所以理所当然地条件变量也被释放了，所以实际上定时器回调函数什么也没做。
```cpp
struct timer_info {
    int cancelled = 0;
};

int connect_with_timeout(int fd, const struct sockaddr* addr, socklen_t addrlen, uint64_t timeout_ms) {
    if(!cafba::t_hook_enable) return connect_f(fd, addr, addrlen);
    
    // 获取与文件描述符 fd 关联的文件描述符上下文 FdCtx
    cafba::FdCtx::ptr ctx = cafba::FdMgr::GetInstance()->get(fd);

    // 如果上下文不存在或已经关闭，则设置 errno 为 EBADF 并返回 -1
    if(!ctx || ctx->isClose()) {
        errno = EBADF;
        return -1;
    }
    
    // 检查上下文是否表示一个套接字。如果不是，则直接调用 connect_f 函数进行连接
    if(!ctx->isSocket()) {
        return connect_f(fd, addr, addrlen);
    }
    
    // 检查上下文是否设置用户非阻塞模式。如果是，则直接调用 connect_f 函数进行连接。
    if(ctx->getUserNonblock()) {
        return connect_f(fd, addr, addrlen);
    }

    // 调用 connect_f 尝试建立连接。如果连接立即建立成功，则返回 0
    int n = connect_f(fd, addr, addrlen);
    if(n == 0) {
        return 0;
    } else if(n != -1 || errno != EINPROGRESS) {
        return n;
    }
    // 如果连接正在进行中，connect_f 返回 -1 且 errno 为 EINPROGRESS，则执行后续的超时处理
    
    cafba::IOManager* iom = cafba::IOManager::GetThis();
    cafba::Timer::ptr timer; 

    // tinfo 用于记录超时标志
    std::shared_ptr<timer_info> tinfo(new timer_info);
    std::weak_ptr<timer_info> winfo(tinfo);

    if(timeout_ms != (uint64_t)-1) { // 用户设置超时时间
        // 使用 IO 协程调度添加定时器，将在指定的超时时间 timeout_ms 后触发
        // 只有在 tinfo 存在的情况下才能调用回调函数
        // 回调函数设置超时标志并取消对文件描述符 fd 的 WRITE 事件
        timer = iom->addConditionTimer(timeout_ms, [winfo, fd, iom]() {
                auto t = winfo.lock();
                if(!t || t->cancelled) return;
                t->cancelled = ETIMEDOUT;
                iom->cancelEvent(fd, cafba::IOManager::WRITE);
        }, winfo);
    }

    // 将文件描述符 fd 添加到 I/O 管理器的事件监听中，监听 WRITE 事件，直到连接成功
    // 触发的回调函数为默认参数 nullptr，当使用该参数时，执行的回调相当于是回到当时的协程
    int rt = iom->addEvent(fd, cafba::IOManager::WRITE);
    if(rt == 0) { // 若添加成功，则可以 yield，从而实现异步 I/O
        sylar::Fiber::GetThis()->yield();
        // 此时有两种可能：连接成功事件触发但已经超时，连接成功事件触发并没有超时
        // 如果定时器存在，则在协程被 resume 后取消定时器，因为 resume 后不需要定时
        if(timer) timer->cancel();
        if(tinfo->cancelled) { // 若挂起期间已经超时，则设置 errno 并返回 -1 表示连接超时
            errno = tinfo->cancelled;
            return -1;
        }
    } else { 
        if(timer) timer->cancel(); // 添加失败，就不需要定时器
    }

    // 若连接没有超时，则检查套接字的错误状态
    // getsockopt 用于获取套接字选项，这里获取 SO_ERROR 选项来获取套接字的错误状态
    int error = 0;
    socklen_t len = sizeof(int);
    if(-1 == getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &len)) return -1;
    if(!error) return 0;
    else {
        errno = error;
        return -1;
    }
}
```
### IO
`IO` 的超时处理与 `connect` 逻辑一样。
```cpp
// OriginFun 是原始的 I/O 函数类型，Args 是可变参数类型，表示传递给 OriginFun 的参数
template <typename OriginFun, typename... Args>
static ssize_t do_io(int fd, OriginFun fun, const char *hook_fun_name,
                     uint32_t event, int timeout_so, Args &&...args) {
    if (!cafba::t_hook_enable) {
        return fun(fd, std::forward<Args>(args)...);
    }

    cafba::FdCtx::ptr ctx = cafba::FdMgr::GetInstance()->get(fd);
    if (!ctx) {
        return fun(fd, std::forward<Args>(args)...);
    }

    if (ctx->isClose()) {
        errno = EBADF;
        return -1;
    }
    // 不是 socket fd 或用户设置的是非阻塞模式都直接执行系统调用
    if (!ctx->isSocket() || ctx->getUserNonblock()) {
        return fun(fd, std::forward<Args>(args)...); 
    }

    uint64_t to = ctx->getTimeout(timeout_so); // 获取超时时间
    std::shared_ptr<timer_info> tinfo(new timer_info);

retry:
    ssize_t n = fun(fd, std::forward<Args>(args)...);
    // EINTR 表示被信号中断
    // 可以选择重试或忽略信号
    while (n == -1 && errno == EINTR) { // 1.重启；2.忽略信号；3.
        n = fun(fd, std::forward<Args>(args)...);
    }
    // EAGAIN 表示资源暂时不可用，进行超时处理的逻辑，与 Connet 类似
    if (n == -1 && errno == EAGAIN) {
        cafba::IOManager *iom = cafba::IOManager::GetThis();
        cafba::Timer::ptr timer;
        std::weak_ptr<timer_info> winfo(tinfo);

        if (to != (uint64_t)-1) {
            timer = iom->addConditionTimer(to, [winfo, fd, iom, event]() {
                auto t = winfo.lock();
                if(!t || t->cancelled) return;
                t->cancelled = ETIMEDOUT;
                iom->cancelEvent(fd, (cafba::IOManager::Event)(event)); }, winfo);
        }

        const int rt = iom->addEvent(fd, (cafba::IOManager::Event)(event));
        if(rt == 0) { // 若添加成功，则可以 yield，从而实现异步 I/O
            sylar::Fiber::GetThis()->yield();
            // 此时有两种可能：事件触发但已经超时，事件触发并没有超时
            // 如果定时器存在，则在协程被 resume 后取消定时器，因为 resume 后不需要定时
            if(timer) timer->cancel();
            if(tinfo->cancelled) { // 若挂起期间已经超时，则设置 errno 并返回 -1 表示连接超时
                errno = tinfo->cancelled;
                return -1;
            }
            goto retry;
        } else { 
            if(timer) timer->cancel(); // 添加失败，就不需要定时器
            return -1;
        }
    }

    return n;
}

ssize_t read(int fd, void *buf, size_t count) {
    return do_io(fd, read_f, "read", sylar::IOManager::READ, SO_RCVTIMEO, buf, count);
}

ssize_t readv(int fd, const struct iovec *iov, int iovcnt) {
    return do_io(fd, readv_f, "readv", sylar::IOManager::READ, SO_RCVTIMEO, iov, iovcnt);
}

ssize_t recv(int sockfd, void *buf, size_t len, int flags) {
    return do_io(sockfd, recv_f, "recv", sylar::IOManager::READ, SO_RCVTIMEO, buf, len, flags);
}

ssize_t recvfrom(int sockfd, void *buf, size_t len, int flags, struct sockaddr *src_addr, socklen_t *addrlen) {
    return do_io(sockfd, recvfrom_f, "recvfrom", sylar::IOManager::READ, SO_RCVTIMEO, buf, len, flags, src_addr, addrlen);
}

ssize_t recvmsg(int sockfd, struct msghdr *msg, int flags) {
    return do_io(sockfd, recvmsg_f, "recvmsg", sylar::IOManager::READ, SO_RCVTIMEO, msg, flags);
}

ssize_t write(int fd, const void *buf, size_t count) {
    return do_io(fd, write_f, "write", sylar::IOManager::WRITE, SO_SNDTIMEO, buf, count);
}

ssize_t writev(int fd, const struct iovec *iov, int iovcnt) {
    return do_io(fd, writev_f, "writev", sylar::IOManager::WRITE, SO_SNDTIMEO, iov, iovcnt);
}

ssize_t send(int s, const void *msg, size_t len, int flags) {
    return do_io(s, send_f, "send", sylar::IOManager::WRITE, SO_SNDTIMEO, msg, len, flags);
}

ssize_t sendto(int s, const void *msg, size_t len, int flags, const struct sockaddr *to, socklen_t tolen) {
    return do_io(s, sendto_f, "sendto", sylar::IOManager::WRITE, SO_SNDTIMEO, msg, len, flags, to, tolen);
}

ssize_t sendmsg(int s, const struct msghdr *msg, int flags) {
    return do_io(s, sendmsg_f, "sendmsg", sylar::IOManager::WRITE, SO_SNDTIMEO, msg, flags);
}
```
### Close
```cpp
int close(int fd) {
    if (!cafba::t_hook_enable) {
        return close_f(fd);
    }

    cafba::FdCtx::ptr ctx = cafba::FdMgr::GetInstance()->get(fd);
    if (ctx) {
        auto iom = cafba::IOManager::GetThis();
        // 取消掉 fd 上的全部事件，从而让 fd 的读写事件回调都执行一次
        if (iom) iom->cancelAll(fd);
        cafba::FdMgr::GetInstance()->del(fd); // 删除 fd 的上下文
    }
    return close_f(fd);
}
```
### Fcntl
`fcntl` 的 `O_NONBLOCK` 标志要特殊处理，因为所有参与协程调度的 `fd` 都会被设置成非阻塞模式，所以要在应用层维护好用户设置的非阻塞标志。
```cpp
int fcntl(int fd, int cmd, ... /* arg */) {
    va_list va; // 获取可变参数列表
    va_start(va, cmd); // 初始化 va_list 变量 va，使其指向第一个可变参数
    switch (cmd) {
    case F_SETFL: { // 设置文件状态标志
        int arg = va_arg(va, int); // 从可变参数列表中获取一个整数参数，即文件状态标志
        va_end(va);
        cafba::FdCtx::ptr ctx = cafba::FdMgr::GetInstance()->get(fd);
        if (!ctx || ctx->isClose() || !ctx->isSocket()) 
            return fcntl_f(fd, cmd, arg);
        // 调用 setUserNonblock 方法来设置用户层面的非阻塞标志
        ctx->setUserNonblock(arg & O_NONBLOCK);
        // 根据文件描述符上下文的系统非阻塞标志，调整文件状态标志
        if (ctx->getSysNonblock()) {
            arg |= O_NONBLOCK;
        } else {
            arg &= ~O_NONBLOCK;
        }
        return fcntl_f(fd, cmd, arg);
    } break;
    case F_GETFL: {
        va_end(va);
        int arg               = fcntl_f(fd, cmd);
        sylar::FdCtx::ptr ctx = sylar::FdMgr::GetInstance()->get(fd);
        if (!ctx || ctx->isClose() || !ctx->isSocket()) {
            return arg;
        }
        if (ctx->getUserNonblock()) {
            return arg | O_NONBLOCK;
        } else {
            return arg & ~O_NONBLOCK;
        }
    } break;
    case F_DUPFD:
    case F_DUPFD_CLOEXEC:
    case F_SETFD:
    case F_SETOWN:
    case F_SETSIG:
    case F_SETLEASE:
    case F_NOTIFY:
#ifdef F_SETPIPE_SZ
    case F_SETPIPE_SZ:
#endif
    {
        int arg = va_arg(va, int);
        va_end(va);
        return fcntl_f(fd, cmd, arg);
    } break;
    case F_GETFD:
    case F_GETOWN:
    case F_GETSIG:
    case F_GETLEASE:
#ifdef F_GETPIPE_SZ
    case F_GETPIPE_SZ:
#endif
    {
        va_end(va);
        return fcntl_f(fd, cmd);
    } break;
    case F_SETLK:
    case F_SETLKW:
    case F_GETLK: { // 获取文件锁的状态
        // 从可变参数列表中获取一个 struct flock * 类型的参数
        // 该参数指向一个 flock 结构体，用于存储或检索文件锁的信息
        struct flock *arg = va_arg(va, struct flock *);
        va_end(va);
        return fcntl_f(fd, cmd, arg);
    } break;
    // 获取或设置文件锁的拥有者
    // 这两个命令通常用于进程间通信，允许一个进程获取文件锁，并指定另一个进程来处理锁的释放
    case F_GETOWN_EX:
    case F_SETOWN_EX: {
        struct f_owner_exlock *arg = va_arg(va, struct f_owner_exlock *);
        va_end(va);
        return fcntl_f(fd, cmd, arg);
    } break;
    default:
        va_end(va);
        return fcntl_f(fd, cmd);
    }
}
```
### Ioctl
`ioctl` 同样要特殊处理 `FIONBIO` 命令用于设置非阻塞。
`O_NONBLOCK` 是通过 `fcntl` 系统调用来设置的，它直接作用于文件描述符本身，是 `POSIX` 标准的一部分，因此在所有遵循 POSIX 标准的系统上都可用。
`FIONBIO` 是通过 `ioctl` 系统调用来设置的，它通常用于套接字，是特定于 `BSD` 的，因此在一些非 `BSD` 系统上不可用。
```cpp
int ioctl(int d, unsigned long int request, ...) {
    va_list va;
    va_start(va, request);
    void *arg = va_arg(va, void *);
    va_end(va);
    // FIONBIO 用于设置或获取文件描述符的非阻塞模式
    if (FIONBIO == request) {
        // 将 arg 转换为 int 类型，并使用双重逻辑非运算符 !! 将其转换为布尔值
        // 如果 arg 指向的整数值为 0，则 user_nonblock 为 false 否则为 true
        bool user_nonblock    = !!*(int *)arg;
        sylar::FdCtx::ptr ctx = sylar::FdMgr::GetInstance()->get(d);
        if (!ctx || ctx->isClose() || !ctx->isSocket()) 
            return ioctl_f(d, request, arg);
        ctx->setUserNonblock(user_nonblock);
    }
    return ioctl_f(d, request, arg);
}
```
