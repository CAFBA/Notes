# IOManager
在前面的协程调度模块中，调度器对协程的调度是无条件执行的，在调度器已经启动调度的情况下，任务一旦添加成功，就会排队等待调度器执行。调度器不支持删除调度任务，并且调度器在正常退出之前一定会执行完全部的调度任务，所以在某种程度上可以认为，把一个协程添加到调度器的任务队列，就相当于调用协程的 `resume` 方法。
服务器通常需要处理大量来自客户端的 `socket fd`，使用 `IO` 事件调度可以将开发者从判断 `socket fd` 是否可读或可写的工作中解放出来，使得程序员只需要关心 `socket fd IO` 操作。很多的库都可以实现类似的工作，比如 `libevent`，`libuv`，`libev` 等，这些库被称为异步事件库或异步 `IO` 库。这些事件库的实现原理基本类似，都是先将套接字设置成非阻塞状态，然后将套接字与回调函数绑定，接下来进入一个基于 `IO` 多路复用的事件循环，等待事件发生，然后调用对应的回调函数。
## Design
`sylar` 的 `IO` 协程调度模块基于 `epoll` 实现，直接继承协程调度器，增加 `IO` 事件调度的功能，支持为描述符注册事件的回调函数，对每个 `fd`，`sylar` 支持两类事件，一类是可读事件，对应 `EPOLLIN`，一类是可写事件，对应 `EPOLLOUT`。事件枚举值直接继承自 `epoll`，对于 `epoll` 其他事件进行归类，分别对应到 `EPOLLIN` 和 `EPOLLOUT` 中，也就是所有的事件都可以表示为可读或可写事件，甚至有的事件还可以同时表示可读及可写事件，比如 `EPOLLERR` 事件发生时，`fd` 将同时触发可读和可写事件。
对于 `IO` 协程调度来说，每次调度都包含一个三元组信息，分别是描述符-事件类型-回调函数，调度器记录全部需要调度的三元组信息，其中描述符和事件类型用于 `epoll_wait`，回调函数用于协程调度。这个三元组信息通过 `FdContext` 结构体来存储，在执行 `epoll_wait` 时通过 `epoll_event` 的私有数据指针 `data.ptr` 来保存 `FdContext` 结构体信息。
此外，`IO` 协程调度器支持取消事件，如果某个 `fd` 的可读或可写事件都被取消，那这个 `fd` 会从调度器的 `epoll_wait` 中删除。
## IOManager Class Interface
```cpp
class IOManager : public Scheduler, public TimerManager {
public:
    typedef std::shared_ptr<IOManager> ptr;
    typedef RWMutex RWMutexType;

    enum Event {
        /// 无事件
        NONE = 0x0,
        /// 读事件(EPOLLIN)
        READ = EPOLL_EVENTS::EPOLLIN,
        /// 写事件(EPOLLOUT)
        WRITE = EPOLL_EVENTS::EPOLLOUT,
    };

private:
    struct FdContext {
        typedef Mutex MutexType;
        struct EventContext {
            /// 执行事件回调的调度器
            Scheduler *scheduler = nullptr;
            /// 事件回调协程
            Fiber::ptr fiber;
            /// 事件回调函数
            std::function<void()> cb;
        };

        /**
         * @brief 获取事件上下文类
         * @param[in] event 事件类型
         * @return 返回对应事件的上下文
         */
        EventContext &getEventContext(Event event);

        /**
         * @brief 重置事件上下文
         * @param[in, out] ctx 待重置的事件上下文对象
         */
        void resetEventContext(EventContext &ctx);

        /**
         * @brief 触发事件
         * @details 根据事件类型调用对应上下文结构中的调度器去调度回调协程或回调函数
         * @param[in] event 事件类型
         */
        void triggerEvent(Event event);

        /// 读事件上下文
        EventContext read;
        /// 写事件上下文
        EventContext write;
        /// 事件关联的句柄
        int fd = 0;
        /// 该fd添加了哪些事件的回调函数，或者说该fd关心哪些事件
        Event events = Event::NONE;
        /// 事件的Mutex
        MutexType mutex;
    };

public:
    IOManager(size_t threads = 1, bool use_caller = true, const std::string &name = "IOManager");

    ~IOManager();
    
    int addEvent(int fd, Event event, std::function<void()> cb = nullptr);

    bool delEvent(int fd, Event event);

    bool cancelEvent(int fd, Event event);

    bool cancelAll(int fd);

    static IOManager *GetThis();
protected:

    void tickle() override;

    bool stopping() override;

    void idle() override;

    bool stopping(uint64_t& timeout);

    void onTimerInsertedAtFront() override;

    void contextResize(size_t size);

private:
    /// epoll 文件句柄
    int m_epfd = 0;
    /// pipe 文件句柄，fd[0]读端，fd[1]写端
    int m_tickleFds[2];
    /// 当前等待执行的IO事件数量
    std::atomic<size_t> m_pendingEventCount = {0};
    /// IOManager的Mutex
    RWMutexType m_mutex;
    /// socket事件上下文的容器，索引为 FdContext 的成员 fd
    std::vector<FdContext *> m_fdContexts;
};
```
## FdContext
`FdContext` 对描述符-事件类型-回调函数三元组的定义，即 `fd` 上下文，每个 `socket fd` 都对应一个 `FdContext`，包括 `fd` 的值，事件类型，以及事件上下文。
由于 `sylar` 对 `fd` 事件进行简化，只有可读和可写两种事件，每种事件的回调函数可以不一样，所以 `fd` 的读或写事件都有一个事件上下文，保存对应的回调函数以及执行回调函数的调度器。
```cpp
struct FdContext { // socket fd上下文类
    typedef Mutex MutexType;
    struct EventContext { // 事件上下文类
        /// 执行事件回调的调度器
        Scheduler *scheduler = nullptr;
        /// 事件回调协程
        Fiber::ptr fiber;
        /// 事件回调函数
        std::function<void()> cb;
    };
 
    EventContext& getEventContext(Event event);

    void resetEventContext(EventContext &ctx);
 
    void triggerEvent(Event event);

    /// 读事件上下文
    EventContext read;
    /// 写事件上下文
    EventContext write;
    /// 事件关联的句柄，也是 FdContext 数组的下标
    int fd = 0;
    /// fd添加的事件类型
    Event events = NONE;
    /// 事件的Mutex
    MutexType mutex;
};
```
读写事件的定义直接继承 `epoll` 的枚举值：
```cpp
enum Event {
    /// 无事件
    NONE = 0x0,
    /// 读事件(EPOLLIN)
    READ = 0x1,
    /// 写事件(EPOLLOUT)
    WRITE = 0x4,
};

IOManager *IOManager::GetThis() {
    // 基类向派生类的显示转换
    return dynamic_cast<IOManager *>(Scheduler::GetThis());
}
```
## Event
```cpp
IOManager::FdContext::EventContext &IOManager::FdContext::getEventContext(IOManager::Event event) {
    switch (event) {
        case IOManager::READ:
            return read;
        case IOManager::WRITE:
            return write;
        default:
            SYLAR_ASSERT2(false, "getContext");
    }
    throw std::invalid_argument("getContext invalid event");
}

void IOManager::FdContext::resetEventContext(EventContext &ctx) {
    ctx.scheduler = nullptr;
    ctx.fiber.reset();
    ctx.cb = nullptr;
}

void IOManager::FdContext::triggerEvent(const IOManager::Event event) {
    SYLAR_ASSERT(events & event); // 待触发的事件必须已被注册过
    // 注册的 IO 事件是一次性的，如果想持续关注某个 socket fd 的读写事件
    // 那么每次触发事件之后都要重新添加
    EventContext &ctx = getEventContext(event);
    if (ctx.cb) { // 触发事件，调度对应的协程
        ctx.scheduler->schedule(ctx.cb);
    } else {
        ctx.scheduler->schedule(ctx.fiber);
    }
    events = (Event)(events & ~event); // 触发后清除该事件
    resetEventContext(ctx);
}
```
## Ctor
```cpp
/**
 * @brief 重置socket句柄上下文的容器大小
 * @param[in] size 容量大小
 */
void IOManager::contextResize(size_t size) {
    m_fdContexts.resize(size);

    for (size_t i = 0; i < m_fdContexts.size(); ++i) {
        if (m_fdContexts[i] == nullptr) {
            m_fdContexts[i]     = new FdContext();
            m_fdContexts[i]->fd = i;
        }
    }
}

IOManager::IOManager(size_t threads, bool use_caller, const std::string &name)
    : Scheduler(threads, use_caller, name) {
    m_epfd = epoll_create(5000); // 创建 epoll 实例
    SYLAR_ASSERT(m_epfd > 0);

    int rt = pipe(m_tickleFds); // 创建 pipe 文件句柄，fd[0] 读端，fd[1] 写端
    SYLAR_ASSERT(!rt);

    // 注册 pipe 读句柄的可读事件，用于 tickle
    epoll_event event;
    memset(&event, 0, sizeof(epoll_event));
    event.events  = EPOLLIN | EPOLLET;
    event.data.fd = m_tickleFds[0]; // 通过 epoll_event.data.fd 保存描述符

    // 非阻塞方式，配合边缘触发
    rt = fcntl(m_tickleFds[0], F_SETFL, O_NONBLOCK);
    SYLAR_ASSERT(!rt);
    
    // 将管道的读描述符加入 epoll 多路复用，如果管道可读，idle 中的 epoll_wait 会返回
    rt = epoll_ctl(m_epfd, EPOLL_CTL_ADD, m_tickleFds[0], &event);
    SYLAR_ASSERT(!rt);

    contextResize(32);

    start(); // 开启 Schedluer，也就是说 IOManager 创建即可调度协程
}

// 析构要等 Scheduler 调度完所有的任务，然后再关闭 epoll 句柄和 pipe 句柄
// 最后然后释放所有的 FdContext
IOManager::~IOManager() {
    stop();
    close(m_epfd);
    close(m_tickleFds[0]);
    close(m_tickleFds[1]);

    for (size_t i = 0; i < m_fdContexts.size(); ++i) {
        if (m_fdContexts[i]) delete m_fdContexts[i];
    }
}
```
## Tickle/Idle
为防止 `IO` 事件不触发导致 `IO` 协程调度一直阻塞在 `epoll_wait` 上，需要设置超时时间。超时时间用当前定时器的最小超时时间来代替，这就意味着需要保证最小超时时间的准确性。因此当 `TimerManager` 检测到新添加的定时器的超时时间比当前最小的定时器还要小时，将会调用 `onTimerInsertedAtFront()` 方法，其内部调用 `tickle` 通过写 `pipe` 使 `pipe` 的读描述符触发可读事件，使 `epoll_wait` 返回，获取新添加的最小定时器的超时时间，从而更新当前的 `epoll_wait` 超时，否则新添加的定时器的执行时间将不准确。
在 `idle` 中会 `epoll_wait` 所有注册的 `fd`，当有事件触发时从 `epoll_wait` 返回，通过 `data.ptr` 中获得 `fd` 的上下文信息，并且将 `fd` 的回调函数并加入调度器的任务队列，回调函数在 `idle` 协程退出后，由调度器在下一轮调度时执行。此外，`epoll_wait` 返回后，需要将所有超时的定时器回调函数加入调度器的任务队列。
```cpp
void IOManager::tickle() {
    // 如果当前没有空闲调度线程，即没有调度线程处理于idle状态，就没必要发通知
    if (!hasIdleThreads()) return;
    const int rt = write(m_tickleFds[1], "T", 1); 
    SYLAR_ASSERT(rt == 1);
}

void IOManager::onTimerInsertedAtFront() {
    tickle();
}

void IOManager::idle() {
    // 一次epoll_wait最多检测256个就绪事件，如果超过，就会在下轮epoll_wati继续处理
    constexpr uint64_t MAX_EVNETS = 256;
    epoll_event *events           = new epoll_event[MAX_EVNETS]();
    std::shared_ptr<epoll_event> shared_events(events, [](epoll_event *ptr) {
        delete[] ptr; // lambda
    });

    while (true) {
        uint64_t next_timeout = 0;
        // 获取下一个定时器的超时时间，顺便判断调度器是否停止
        if (SYLAR_UNLIKELY(stopping(next_timeout))) break;

        // 阻塞在 epoll_wait 上，等待事件发生或定时器超时
        int rt{};
        do {
            // 默认超时时间5秒，如果下一个定时器的超时时间大于5秒，仍以5秒来计算超时
            // 避免定时器超时时间太大时，epoll_wait一直阻塞
            static constexpr int MAX_TIMEOUT = 5000; 
            if (next_timeout != ~0ull) { // ~0ull 是全1，表示没有下一个定时器的触发时间
                next_timeout = std::min((int)next_timeout, MAX_TIMEOUT);
            } else {
                next_timeout = MAX_TIMEOUT;
            }
            // 阻塞在epoll_wait上，等待事件发生，当超时时会返回 0
            rt = epoll_wait(m_epfd, events, MAX_EVNETS, (int)next_timeout);
            // 在 epoll_wait 被信号中断的情况下，rt 会是-1，并且errno会被设置为 EINTR
            if (rt < 0 && errno == EINTR) continue;
            break; // 超时或有事件触发会跳出循环
        } while (true);

        // 收集所有已超时的定时器，添加到任务队列
        std::vector<std::function<void()>> cbs;
        listExpiredCb(cbs);
        if (!cbs.empty()) {
            for (const auto &cb : cbs) schedule(cb);
            cbs.clear();
        }

        // 遍历所有发生的事件，根据epoll_event的私有指针找到对应的FdContext，进行事件处理
        for (int i = 0; i < rt; ++i) {
            epoll_event &event = events[i];
            if (event.data.fd == m_tickleFds[0]) { 
                // 用于模拟 IO 事件的管道读事件，只需要把管道里的内容读完即可
                uint8_t dummy[256];
                while (read(m_tickleFds[0], dummy, sizeof(dummy)) > 0);
                continue;
            }
            // 通过epoll_event的私有指针获取FdContext
            FdContext* fd_ctx = (FdContext *)event.data.ptr;
            FdContext::MutexType::Lock lock(fd_ctx->mutex);
            // EPOLLERR: 出错，比如读写端已经关闭的pipe EPOLLHUP: 套接字对端关闭
            // 若发生这两种事件之一，则应该同时触发fd的读和写事件，否则有可能出现注册的事件永远执行不到的情况
            // 因此在触发的事件类型中添加读写事件
            if (event.events & (EPOLLERR | EPOLLHUP)) 
                event.events |= (EPOLLIN | EPOLLOUT) & fd_ctx->events;
            int real_events = Event::NONE;
            if (event.events & EPOLLIN) real_events |= Event::READ;
            if (event.events & EPOLLOUT) real_events |= Event::WRITE;

            // 说明触发的事件是不关注的事件，虽然没有关注这些事件，但是仍然有可能触发epoll，当触发这些事件的时候，选择跳过
            if ((fd_ctx->events & real_events) == Event::NONE) continue;

            // 去掉已经发生的事件，将剩下的事件重新加入epoll_wait
            // 因为协程都是一次性的，事件触发一次之后就不再触发
            const int leftEvents = (fd_ctx->events & ~real_events);
            int op          = leftEvents > 0 ? EPOLL_CTL_MOD : EPOLL_CTL_DEL; //todo : 也可以使用EPOLLONESHOT来代替这个
            event.events    = EPOLLET | leftEvents;
            // 重新加入epoll_wait
            const int rt2 = epoll_ctl(m_epfd, op, fd_ctx->fd, &event);

            // 处理已经发生的事件，也就是让调度器调度指定的函数或协程
            if (real_events & READ) {
                fd_ctx->triggerEvent(READ);
                --m_pendingEventCount;
            }
            if (real_events & WRITE) {
                fd_ctx->triggerEvent(WRITE);
                --m_pendingEventCount;
            }
        }

        // 处理完发生的事件后 idle 协程 yield，返回Scheduler::run重新检查是否有新任务要调度
        // triggerEvent实际也只是把对应的fiber重新加入调度，要执行的话还要等idle协程退出
        Fiber::ptr cur = Fiber::GetThis();
        const auto rawPtr   = cur.get();
        cur.reset();

        rawPtr->yield();
    } // end while(true)
}
```
## Stop
```cpp
bool IOManager::stopping() {
    uint64_t timeout = 0;
    return stopping(timeout);
}

bool IOManager::stopping(uint64_t &timeout) {
    // 对于IOManager而言，必须等所有待调度的IO事件都执行完才可以退出
    // 增加定时器功能后，还应该保证没有剩余的定时器待触发
    timeout = getNextTimer();
    return timeout == ~0ull && m_pendingEventCount == 0 && Scheduler::stopping();
}
```
## AddEvent
```cpp
int IOManager::addEvent(int fd, Event event, std::function<void()> cb) {
    // 找到fd对应的FdContext，如果不存在，那就分配一个
    FdContext *fd_ctx = nullptr;
    RWMutexType::ReadLock lock(m_mutex);
    if ((int)m_fdContexts.size() > fd) {
        fd_ctx = m_fdContexts[fd];
        lock.unlock();
    } else {
        lock.unlock();
        RWMutexType::WriteLock lock2(m_mutex); // todo：待搞清楚这里为什么要扩容？ 可用的fd与缩影也没必要意义对应把感觉
        contextResize(fd * 1.5);               // 扩容
        fd_ctx = m_fdContexts[fd];
    }

    // 同一个fd不允许重复添加相同的事件
    FdContext::MutexType::Lock lock2(fd_ctx->mutex);
    if (SYLAR_UNLIKELY(fd_ctx->events & event)) {
        SYLAR_LOG_ERROR(g_logger) << "addEvent assert fd=" << fd
                                  << " event=" << (EPOLL_EVENTS)event
                                  << " fd_ctx.event=" << (EPOLL_EVENTS)fd_ctx->events;
        SYLAR_ASSERT(!(fd_ctx->events & event));
    }

    // 将新的事件加入epoll_wait，使用epoll_event的私有指针存储FdContext的位置
    int op = fd_ctx->events > Event::NONE ? EPOLL_CTL_MOD : EPOLL_CTL_ADD;
    epoll_event epevent;
    epevent.events   = EPOLLET | fd_ctx->events | event;
    epevent.data.ptr = fd_ctx;

    const int rt = epoll_ctl(m_epfd, op, fd, &epevent);
    if (rt != 0) {
        SYLAR_LOG_ERROR(g_logger) << "epoll_ctl(" << m_epfd << ", "
                                  << (EpollCtlOp)op << ", " << fd << ", " << (EPOLL_EVENTS)epevent.events << "):"
                                  << rt << " (" << errno << ") (" << strerror(errno) << ") fd_ctx->events="
                                  << (EPOLL_EVENTS)fd_ctx->events;
        return -1;
    }

    // 待执行IO事件数加1
    ++m_pendingEventCount; // maybe bug： idle函数中触发事件的时候，读写分别都会使得m_pendingEventCount-1，但是这里添加事件（具体读写为止），只+1，可能有
                           //   还是说这里只会添加读写任务其中一项

    // 找到这个fd的event事件对应的EventContext，对其中的scheduler, cb, fiber进行赋值
    fd_ctx->events                     = (Event)(fd_ctx->events | event);
    FdContext::EventContext &event_ctx = fd_ctx->getEventContext(event); // todo：是不是可以确保传入的只有读写中的一个，因为这里event如果同时有读写会出问题
    SYLAR_ASSERT(!event_ctx.scheduler && !event_ctx.fiber && !event_ctx.cb);

    // 赋值scheduler和回调函数，如果回调函数为空，则把当前协程当成回调执行体
    event_ctx.scheduler = Scheduler::GetThis();
    if (cb) {
        event_ctx.cb.swap(cb);
    } else {
        // 什么时候会传入一个空的回调呢，可以看下经典使用：connect_with_timeout的回调函数为空，即回到当时的协程
        event_ctx.fiber = Fiber::GetThis(); // 默认把当前协程作为回调函数
        SYLAR_ASSERT2(event_ctx.fiber->getState() == Fiber::RUNNING, "state=" << event_ctx.fiber->getState());
    }
    return 0;
}
```
## DelEvent
```cpp
bool IOManager::delEvent(int fd, Event event) {
    // 找到fd对应的FdContext
    RWMutexType::ReadLock lock(m_mutex);
    if ((int)m_fdContexts.size() <= fd) {
        return false;
    }
    FdContext *fd_ctx = m_fdContexts[fd];
    lock.unlock();

    FdContext::MutexType::Lock lock2(fd_ctx->mutex);
    if (SYLAR_UNLIKELY((fd_ctx->events & event) == Event::NONE)) {
        return false; // 该事件没注册监听，自然没法删除
    }

    // 清除指定的事件，表示不关心这个事件了，如果清除之后结果为0，则从epoll_wait中删除该文件描述符
    const Event reserveEvents = (Event)(fd_ctx->events & ~event); // 还要保留的事件
    int op                    = reserveEvents != Event::NONE ? EPOLL_CTL_MOD : EPOLL_CTL_DEL;
    epoll_event epevent;
    epevent.events   = EPOLLET | reserveEvents;
    epevent.data.ptr = fd_ctx;

    const int rt = epoll_ctl(m_epfd, op, fd, &epevent);
    if (rt) {
        SYLAR_LOG_ERROR(g_logger) << "epoll_ctl(" << m_epfd << ", "
                                  << (EpollCtlOp)op << ", " << fd << ", " << (EPOLL_EVENTS)epevent.events << "):"
                                  << rt << " (" << errno << ") (" << strerror(errno) << ")";
        return false;
    }

    // 待执行事件数减1
    --m_pendingEventCount; // todo：后面同样要看看为什么只减一个事件
    // 重置该fd对应的event事件上下文
    fd_ctx->events                     = reserveEvents;
    FdContext::EventContext &event_ctx = fd_ctx->getEventContext(event); //todo：与addEvent同样对称的问题
    fd_ctx->resetEventContext(event_ctx);
    return true;
}
```
## CancelEvent
```cpp
bool IOManager::cancelEvent(const  int fd, Event event) {
    // 找到fd对应的FdContext
    RWMutexType::ReadLock lock(m_mutex);
    if ((int)m_fdContexts.size() <= fd) {
        return false;
    }
    FdContext *fd_ctx = m_fdContexts[fd];
    lock.unlock();

    FdContext::MutexType::Lock lock2(fd_ctx->mutex);
    if (SYLAR_UNLIKELY(!(fd_ctx->events & event))) {
        return false;
    }

    // 删除事件
    const Event new_events = (Event)(fd_ctx->events & ~event);
    int op           = new_events ? EPOLL_CTL_MOD : EPOLL_CTL_DEL;
    epoll_event epevent;
    epevent.events   = EPOLLET | new_events;
    epevent.data.ptr = fd_ctx;

    int rt = epoll_ctl(m_epfd, op, fd, &epevent);
    if (rt) {
        SYLAR_LOG_ERROR(g_logger) << "epoll_ctl(" << m_epfd << ", "
                                  << (EpollCtlOp)op << ", " << fd << ", " << (EPOLL_EVENTS)epevent.events << "):"
                                  << rt << " (" << errno << ") (" << strerror(errno) << ")";
        return false;
    }

    // 删除之前触发一次事件
    fd_ctx->triggerEvent(event);
    // 活跃事件数减1
    --m_pendingEventCount;
    return true;
}
```
## CancelAll
```cpp
bool IOManager::cancelAll(int fd) {
    // 找到fd对应的FdContext
    RWMutexType::ReadLock lock(m_mutex);
    if ((int)m_fdContexts.size() <= fd) {
        return false;
    }
    FdContext *fd_ctx = m_fdContexts[fd];
    lock.unlock();

    FdContext::MutexType::Lock lock2(fd_ctx->mutex);
    if (!fd_ctx->events) {
        return false;
    }

    // 删除全部事件
    int op = EPOLL_CTL_DEL;
    epoll_event epevent;
    epevent.events   = 0;
    epevent.data.ptr = fd_ctx;

    const int rt = epoll_ctl(m_epfd, op, fd, &epevent);
    if (rt) {
        SYLAR_LOG_ERROR(g_logger) << "epoll_ctl(" << m_epfd << ", "
                                  << (EpollCtlOp)op << ", " << fd << ", " << (EPOLL_EVENTS)epevent.events << "):"
                                  << rt << " (" << errno << ") (" << strerror(errno) << ")";
        return false;
    }

    // 触发全部已注册的事件
    if (fd_ctx->events & READ) {
        fd_ctx->triggerEvent(READ);
        --m_pendingEventCount;
    }
    if (fd_ctx->events & WRITE) {
        fd_ctx->triggerEvent(WRITE);
        --m_pendingEventCount;
    }

    SYLAR_ASSERT(fd_ctx->events == Event::NONE);
    return true;
}
```
## Conclusion
`epoll` 是线程安全的，即使调度器有多个调度线程，它们也可以共用同一个 `epoll` 实例，而不用担心互斥。由于空闲时所有线程都阻塞的 `epoll_wait` 上，所以也不用担心 `CPU` 占用问题。
`addEvent` 是一次性的，比如注册一个读事件，当 `fd` 可读时会触发该事件，但触发完之后，这次注册的事件就失效了，后面 `fd` 再次可读时，并不会继续执行该事件回调，如果要持续触发事件的回调，那每次事件处理完都要手动再 `addEvent`。这样在应对 `fd` 的 `WRITE` 事件时会比较好处理，因为fd可写是常态，如果注册一次就一直有效，那么可写事件就必须在执行完之后就删除掉。
`cancelEvent` 和 `cancelAll` 都会触发一次事件，但 `delEvent` 不会。
`sylar` 直接使用 `fd` 的值作为 `FdContext` 数组的下标，这样可以快速找到一个 `fd` 对应的 `FdContext`。由于关闭的 `fd` 会被重复利用，所以这里也不用担心 `FdContext` 数组膨胀太快或是利用率低的问题。
`IO` 协程调度器的退出，不但所有协程要完成调度，所有 `IO` 事件也要完成调度。
`sylar` 的 `IO` 协程调度器应该配合非阻塞 `IO` 来使用，如果使用阻塞模式，可能会阻塞进程。