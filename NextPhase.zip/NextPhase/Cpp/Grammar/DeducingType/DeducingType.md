# 型别推导
## 模板型别推导
```c++
template<typename T>
// ParamType 指的是形参类型，expr 指的是实参
void f(ParamType param);
f(expr);                        //从expr中推导T和ParamType
```
### ParamType 是个指针或引用，但不是个万能引用
1. `expr` 具有引用型别，先将引用部分忽略。 
2. 忽略后，用 `expr` 的型别替换 `T` 型别，`Param` 是 `T&`。
```c++
template<typename T>
void f(T& param); 			// ParamType 是引用
int X = 27; 				// x 的型别是 int
const int cx = x; 			// ex 的型别是 const int 
const int& rx = x; 			// rx 的型别为 const int 的引用
f(x); 						// T 的型别是 int. param 的型别是 int&
f(cx); 						// T 的型别是 const int, param 的型别是 const int& 
f(rx); 						// T 的型别是 const int, param 的型别是 const int&

template<typename T>
void f(T* param);               // ParamType 现在是指针

int x = 27;                     // 同之前一样
const int *px = &x;             // px是指向作为const int的x的指针

f(&x);                          // T是int，param的类型是int*
f(px);                          // T是const int，param的类型是const int*
```
### ParamType 是个万能引用
只有当实参被用来实例化通用引用形参时，下述推导才会发生：
- 如果 `expr` 是个左值，`T` 和 `Param` 都会被推导为 `T&`（[[MoveSemantics#引用折叠]]）。这是在模板型别推导中，`T` 被推导为引用型别的唯一情形。
- 如果 `expr` 是个右值，则按第一种情况推导，`T` 是非引用类型，`Param` 是 `T&&`。
```c++
template<typename T> 
void f(T&& param); // ParamType 现在是万能引用
int x = 27; 
const int cx = x; 
const int& rx = x;
f(x); // x  是个左值，所以T的型别是 int&, param 型别也是 int&
f(cx);// cx 是个左值，所以T的型别是 const int&, param 型别也是 const int& 
f(rx);// rx 是个左值，所以T的型别是 const int&, param 型别也是 const int& 
f(27);// 27 是个右值，所以T的型别是 int, param 型别是 int&&
```
### ParamType 既非指针也非引用
这意味着，无论传入的是什么，param 都会是它的一个副本，也即一个全新对象：
1. 若 expr 具有引用型别，则忽略其引用部分。 
2. 忽略后，若 expr 是个 const 对象，也忽略之。若其是个 volatile 对象，同忽略之。
```c++
template<typename T> 
void f(T param); // param 现在是按值传递
int x = 27;
const int cx = x; 
const int& rx = x; 
f(x); // T 和 param 型别是 int
f(rx);// T 和 param 型别是 int
f(cx);// T 和 param 型别是 int
```
在类型推导中，指针指向的数据的常量性将会被保留，但是当拷贝ptr来创造一个新指针param时，ptr自身的常量性将会被忽略。
```c++
const char* const ptr = "Fun with pointers";     // ptr是一个常量指针，指向常量对象 
f(ptr);                                          // 型别是 const char* 
```
在**模板型别推导过程中，数组或函数型别的实参会退化成对应的指针**，除非它们被用来初始化引用
```c++
const char name[] = "J. P. Briggs";     // name的类型是const char[13]
const char* ptrToName = name;           // 数组退化为指针

template<typename T>
void f(T param);                        // 传值形参的模板
f(name);                                // name是一个数组，但是T被推导为const char*

template<typename T>
void f(T& param);                       // 传引用形参的模板
f(name);                                // T被推导为const char[13]，f的形参的类型则为const char(&)[13]
```
### Conclusion
`T&&`，则根据 expr 是左值还是右值分别判断。
否则，用忽略引用的 expr 型别替换 T 型别，再确定 ParamTypye。
## auto 型别推导
```c++
ParamType var = expr;
```
auto 型别推导与模板型别推导只有两点不同，除此之外按照模板型别推导进行：
1. 在 auto 语义下，其表现为值语义，即通过移动、拷贝构造，会丢失cv属性。因此若 expr 为引用类型，则会丢失引用性，同样也会丢失对应的cv属性。如果想保留引用语义与cv属性，那么需要显式指定 auto&。
2. auto 会假定用大括号括起的初始化表达式代表 std::initializer_list，但模板型别推导却不会。
```c++
// 类似模板型别推导
int x = 27;        
const int cx = x;  

auto&& uref1 = x;   // x 的型别是 int, 万能引用推导左值为 int&, 所以 uref1 的型别是 int&
auto&& uref2 = cx;  // cx 的型别是 const int, 万能引用推导左值为 int&, 所以 uref2 的型别是 const int& 
auto&& uref3 = 27;  // 27 的型别是 int, 万能引用推导右值则替换，所以 uref3 的型别是 int&&

const char name[] = "R. N. Briggs" ; // name 的型别是 canst char[13]
auto arr1 = name;   // arr1 的型别是 const char* 
auto& arr2 = name;  // arr2 的型别是 const char(&)[13] 

void someFunc(int, double); // someFunc 是个函数，型别是 void(int, double) 
auto funcl = someFunc;      // func1 的型别是 void (*)(int, double) 
auto& func2 = someFunc;     // func2 的型别是 void (&)(int, double) 

// 区别1
Foo& lrfoo = foo;
const Foo& clrfoo = foo; 
Foo&& rrfoo = Foo{}; 
auto v6 = 1rfoo;   // FOO 
auto v7 = clrfoo;  // Foo 
auto v8 =rrfoo;    // Foo

// 区别2
auto xl = 27; // 型别是 int, 值是 27
auto x2(27);  // 型别是 int, 值是 27
auto x3 = { 27 }; // 型别是 std::initializer_list<int> 值是{27}  
auto x4{ 27 };    // 型别是 std::initializer_list<int> 值是{27}  
auto x5 = { 1, 2, 3.0 }; // 错误！推导不出 std::initializer_list<T> 中的T

template<typename T> 
void f(std::initializer_list<T> initlist); 
f({ 11, 23, 9 }); // T 的型别推导为 int，从而initlist的型别 std::initializer_list<int>

template<typename T> 
void f(T param); 
f({ 11, 23, 9 }); // 错误，无法推导T的型别

``````
### 推导返回值
C++14 允许使用 auto 来说明函数返回值需要推导，而且 C++14 中的 lambda 也会在形参声明中用到 auto 。然而，这些 auto 用法是在使用模板型别推导而非 auto 型别推导。所以，带有 auto 返回值的函数若要返回一个大括号括起的初始化表达式，是通不过编译的：
```c++
auto createlnitlist() { 
	return { 1, 2, 3 }; //错误 无法为{ 1, 2, 3} 完成型别推导
}

std::vector<int> v; 
auto resetV = [&v](const auto& newValue) { v = newValue; } ; // c++14 

resetV({ 1, 2, 3 }) ; // 错误！无法为{ 1, 2, 3} 完成型别推导
```
### 推导错误的情况
不可见的代理类可能会使 auto 从表达式中推导出错误的类型
```c++
std::vector<bool> features(const Widget& w);

Widget w;
bool highPriority = features(w)[5];     //显式的声明highPriority的类型
auto highPriority = features(w)[5];     //推导highPriority的类型

processWidget(w, highPriority);         //未定义行为！
```
使用auto后highPriority不再是bool类型。虽然从概念上来说`std::vector<bool>`意味着存放bool，但是`std::vector<bool>`的`operator[]`不会返回容器中元素的引用，取而代之它返回一个`std::vector<bool>::reference`的对象（一个嵌套于`std::vector<bool>`中的类）。
`std::vector<bool>::reference`之所以存在是因为`std::vector<bool>`规定了使用一个打包形式表示它的`bool`，每个`bool`占一个*bit*。那给`std::vector`的`operator[]`带来了问题，因为`std::vector<T>`的`operator[]`应当返回一个`T&`，但是C++禁止对`bits`的引用。无法返回一个`bool&`，`std::vector<bool>`的`operator[]`返回一个行为类似于`bool&`的对象。
要想成功扮演这个角色，`bool&`适用的上下文`std::vector<bool>::reference`也必须一样能适用。在`std::vector<bool>::reference`的特性中，使这个原则可行的特性是一个可以向bool的隐式转化。
```cpp
bool highPriority = features(w)[5];     //显式的声明highPriority的类型
```
这里，features返回一个`std::vector<bool>`对象后再调用`operator[]`，`operator[]`将会返回一个`std::vector<bool>::reference`对象，然后再通过隐式转换赋值给bool变量highPriority。highPriority因此表示的是features返回的`std::vector<bool>`中的第五个*bit*，这也正如我们所期待的那样。
然后再对照一下当使用`auto`时发生了什么：
```cpp
auto highPriority = features(w)[5];     //推导highPriority的类型
```
同样的，features返回一个`std::vector<bool>`对象，再调用`operator[]`，`operator[]`将会返回一个`std::vector<bool>::reference`对象，但是现在这里有一点变化了，auto推导highPriority的类型为`std::vector<bool>::reference`，但是highPriority对象没有第五*bit*的值。
区别就在这里：二者都调用features获得临时对象，这个临时对象调用`operator[]`得到`std::vector<bool>::reference`对象，但声明为auto者会通过`std::vector<bool>::reference`的具体实现来得到[5]，这个具体实现会存在指针行为，由于这个临时对象会被销毁，因此这个指针将会悬置，而声明为bool者会进行隐式转换将其转换为bool来得到[5]，这样就避免了指针行为。
一旦看到auto推导了代理类的类型而不是被代理的类型，解决方案并不需要抛弃auto。auto本身没什么问题，问题是auto不会推导出你想要的类型。解决方案是强制使用一个不同的类型推导形式，这种方法通常称之为显式类型初始器惯用法。
```c++
auto highPriority = static_cast<bool>(features(w)[5]);
```
## decltype 型别推导
```c++
struct Point {
    int x = 0; 
    int y = 0; 
};
Point pt;
Point* pPt = &pt;
const Point* cpPt = &pt;
Point& lrPt = pt; 
Point&& rrPt = {};
```
根据 `C++` 标准，`decltype` 特性提供两种使用场景：
1. 若实参为无括号的标识表达式或无括号的类成员访问表达式，即单个变量名字（表达式仅有一个名字），则只推导出该名字的声明型别。
```c++
using T1 = decltype(pt);   // Point 
using T2 = decltype(pPt);  // Point*
using T3 = decltype(cpPt); // const Point* 
using T4 = decltype(lrPt); // Point&
using T5 = decltype(rrPt); // Point&& 
using T6 = decltype (Point{10, 10}.x); // int

int x = 0;
decltype(x)     x1;        // 推导为int，x1是int
decltype(x)&    x2 = x;    // 推导为int，x2是int&，引用必须赋值
decltype(x)*    x3;        // 推导为int，x3是int*
decltype(&x)    x4;        // 推导为int*，x4是int*
decltype(&x)*   x5;        // 推导为int*，x5是int**
decltype(x2)    x6 = x2;   // 推导为int&，x6是int&，引用必须赋值   
```
2. 若实参是带括号的其他类型为 `T` 的任何表达式：
- 若表达式的值类别为左值，则推导出 `T&`。
```c++
// 左值（带一个引用）
using T1 = decltype((pt)); // Point&，表达式(pt)是左值
using T2 = decltype((pPt)); // Point* & 
using T3 = decltype((cpPt)); // const Point* & 
using T4 = decltype((lrPt));// Point&
using T5 = decltype((rrPt));// Point& 
using T6 = decltype((rrPt.x)); // int&
using T7 = decltype((pt.x));//int& 
using T8 = decltype((++pt.x));//int& ++pt.x作为表达式来说其结果也是左值
```
- 若表达式的值类别为纯右值，则推导出`T`。
```c++
// 纯右值（不带引用）
using T9 = decltype((pt.x++));//int 对于后置自增操作pt.x++来说，其结果为右值
using T10 = decltype((Point{1,2})); // Point 
using T11 = decltype((5));//int
```
- 若表达式的值类别为将亡值，则推导出`T&&`。
```c++
// 将亡值（带两个引用）
using T12 = decltype((Point{10,10}.x)); // int&& 
// 通过静态类型转换，std::move将一个左值表达式转化成将亡值。
using T13 = decltype((std::move(pt)));// Point&&
using T14 = decltype((static_cast<Poinnt&&>(pt) ));//Point&&
```
简而言之，前者获取标识符定义时的类型，后者获取作为表达式时的值类别。
此外，在定义类的时候 auto 禁用，但decltype可以搭配别名任意定义类型，再应用到成员变量、成员函数上，变通地实现 auto 的功能。
C++之所以提供这两种方式，是因为每一个标识符的定义与使用，都面临着两种场合：
- 标识符被定义时的类型
- 整体作为表达式使用时的值类别
C++编译时有两个经常使用的非求值上下文：sizeof与decltype。前者获取表达式类型的大小，后者获取表达式的类型。编译器不会为该表达式进行代码生成，两者都不会对操作数进行运算，即sizeof(x++)与decltype(x++)不会导致x的值自增。
### decltype(auto)
auto表现为值语义而丢失引用性与cv属性。若指明了const属性，则导致结果始终为const；若想要采用引用方式，需显式指定auto&或auto&&，而这又导致了只能表现为引用语义。对于想要精确遵从等号右边类型的场景，尤其是在泛型编程场景下不够通用。
decltype不仅能够得到标识符定义时的类型，还可以得到整体作为表达式使用时的值类别，因此如果通过圆括号来区分这两种场景，总是能够准确捕捉等号右边表达式的类型。
```c++
Point pt;
decltype(pt) v1 = pt;   // Point，遵循pt定义时的类型
decltype((pt)) v2 = pt; // Point&，遵循 pt 作为表达式使用的值类别 
decltype(1+2+3+4) v3 = 1+2+3+4; // int
```
上述形式等号左右两边的表达式有所重复，这是件很烦琐的事情，因此C++14引入了decltype(auto)来代替这种场景，其中的auto为占位符，代表了等号右边的表达式，因此只需要写一遍即可：
```c++
decltype(auto) v1 = pt;      // Point，无括号遵循pt定义时的类型
decltype(auto) v2 = (pt);    // Point&，有括号遵循pt作为表达式使用的值类别
decltype(auto) v3 = 1+2+3+4;  // int
```
另一种场景是用于函数返回值的类型推导，考虑如下两个版本的查找函数lookup：
```c++
string lookup1();
string& lookup2();
```
若想要精确返回lookup函数的返回值，需要记得函数定义时的类型，以确定是否需要保留其类型的引用性：
```c++
// 注意返回类型应写成 string，结果为值语义
string look_up_a_string_1() { return lookup1(); }
// 注意返回类型应写成 string&，结果为引用语义，从而保留引用性
string& look_up_a_string_2() { return lookup2(); }
```
这时候decltype(auto)派上用场，其能精确地捕捉类型，从而决定是值语义还是引用语义，因此上述代码可以写成如下形式
```c++
decltype(auto) look_up_a_string_1() { return lookup1(); }
decltype(auto) look_up_a_string_2() { return lookup2(); }
```
如果说std::forward通过完美转发函数的入参类型从而保留其引用性，那么与之对应的**decltype(auto)可以完美转发函数的返回类型，同时还能保留值语义或引用语义**。虽然decltype(auto)非常灵活，但是也必须注意返回变量的生命周期，否则很容易造成悬挂引用：
```c++
// 注意都调用lookup1
decltype(auto) look_up_a_string_1() { auto str = lookup1(); return str; }
decltype(auto) look_up_a_string_2() { auto str = lookup1(); return (str); }
```
上述代码两者都是将结果存储到局部变量str中，而且str的类型都是string。第一个版本不带括号，返回类型是str定义时的类型string，一切正常；第二个版本带括号，返回类型是str整体作为表达式使用的左值，因此decltype(auto)的结果是个左值引用string&的局部变量，从而导致悬挂引用。
### 尾序返回值
C++11 中，decltype 主要用途在于声明那些返回值型别依赖于形参型别的函数模板。尾序返回值的好处在于，在指定返回值型别时可以使用函数形参。
```c++
template<typename Container, typename Index> 
auto authAndAccess(Container& c, Index i) -> decltype(c[i]) {
	authenticateUser(); 
	return c[i]; 
}
```
C++11 允许对单表达式的 lambda 式的返回值型别实施推导，而 C++14 则将这个允许范围扩张到了 lambda 式和一切函数，包括那些多表达式的。对于 authAndAccess 这种情况来说，这就意味着**在 C++14 中可以去掉返回值型别尾序语法，而只保留前 auto** 。在那样的声明形式中，auto 说明编译器会依据函数实现来实施函数返回值的型别推导。
函数返回类型中使用`auto`，编译器**实际上是使用的模板类型推导的那套规则**。而在上例中，这样就会留下隐患。大多数含有型别T的对象的容器的 `operator[]` 会返回 T&，但是模板型别推导过程中，初始化表达的引用性会被忽略。考虑下，这会对客户代码产生怎样的影响：
```c++
template<typename Container, typename Index> 
auto authAndAccess(Container& c, Index i) {
	authenticateUser(); 
	return c[i]; // 初始化表达的引用性会被忽略
}

std::deque<int> d; 
authAndAccess(d, 5) = 10; // 验证用户, 返回d[5], 然后将其赋值为10。这段代码无法通过编详。
```
decltype(auto) 和 auto 一样，它会从其初始化表达式出发来推导型别，但是它的型别推导使用的是 decltype 的规则。使用 auto 不能通用地根据表达式类型来决定返回值的类型，需要在写下 auto 时就决定写下的是个引用类型还是值类型。不过，decltype(expr) 既可以是值类型，也可以是引用类型：
```c++
template<typename Container, typename Index> 
decltype(auto) authAndAccess(Container& c, Index i ) {
	authenticateUser(); 
	return c[i]; 
}
```
此外，容器的传递方式是对非常量的左值引用，因为返回容器的某个元素的引用，就意味着允许客户对容器进行修改。不过这也意味着无法向该函数传递右值容器。右值是不能绑定到左值引用的（除非是对常量的左值引用，与本例情况不符）。
一个右值容器，是一个临时对象，通常会在`authAndAccess`调用结束被销毁，这意味着`authAndAccess`返回的引用将会成为一个悬置的引用。但是使用向`authAndAccess`传递一个临时变量也并不是没有意义，有时候用户可能只是想简单的获得临时容器中的一个元素的拷贝，比如这样：
```c++
std::deque<std::string> makeStringDeque(); // 工厂函数，是一个临时对象
//制作 makeStringDeque 返回的 deque 的第 5 个元素的副本
auto s = authAndAccess(makeStringDeque(), 5);// 无法向该函数传递右值容器
```
因此需要修订 authAndAccess 的声明，以同时接受左值和右值。重载是个办法（一个重载版本声明一个左值引用形参，另一个重载版本声明一个右一值引用形参），但这么来就需要维护两个函数。
避免这个后果的个方法是让 authAndAccess **采用一种既能够绑定到左值也能够绑定到右值的引用形参**：
```c++
template<typename Container, typename Index> 
decltype(auto) authAndAccess(Container&& c, Index i ) {
	authenticateUser();
	return std::forward<Containen(c)[i]; // 对万能引用要应用std::forward
}
// c++11
template<typename Container, typename Index>    //最终的C++11版本
auto authAndAccess(Container&& c, Index i) -> decltype(std::forward<Container>(c)[i])
{
    authenticateUser();
    return std::forward<Container>(c)[i];
}
```
