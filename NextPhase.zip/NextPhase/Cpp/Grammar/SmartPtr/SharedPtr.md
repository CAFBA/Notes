# SharedPtr
一个通过`std::shared_ptr`访问的对象其生命周期由指向它的有共享所有权（*shared ownership*）的指针们来管理。没有特定的`std::shared_ptr`拥有该对象。相反，所有指向它的`std::shared_ptr`都能相互合作确保在它不再使用的那个点进行析构。
`std::shared_ptr`通过引用计数（*reference count*）来确保它是否是最后一个指向某种资源的指针，引用计数关联资源并跟踪有多少`std::shared_ptr`指向该资源。
`std::shared_ptr`构造函数通常递增引用计数值，析构函数递减值，拷贝赋值运算符做前面这两个工作。从另一个`std::shared_ptr`移动构造新`std::shared_ptr`会将原来的`std::shared_ptr`设置为null，那意味着老的`std::shared_ptr`不再指向资源，同时新的`std::shared_ptr`指向资源。这样的结果就是不需要修改引用计数值。
`std::shared_ptr`构造函数只是通常递增指向对象的引用计数，原因是从另一个`std::shared_ptr`移动构造新`std::shared_ptr`会将原来的`std::shared_ptr`设置为null，那意味着老的`std::shared_ptr`不再指向资源，同时新的`std::shared_ptr`指向资源。这样的结果就是不需要修改引用计数值。因此移动`std::shared_ptr`会比拷贝它要快：拷贝要求递增引用计数值，移动不需要。移动赋值运算符同理，所以移动构造比拷贝构造快，移动赋值运算符也比拷贝赋值运算符快。
引用计数暗示着性能问题：
- **`std::shared_ptr`大小是原始指针的两倍**，因为它内部包含一个指向资源的原始指针，还包含一个指向资源的引用计数值的原始指针。
- **引用计数的内存必须动态分配**。概念上，引用计数与所指对象关联起来，但是实际上被指向的对象不知道这件事情（不知道有一个关联到自己的计数值）。因此它们没有办法存放一个引用计数值。（一个好消息是任何对象——甚至是内置类型的——都可以由`std::shared_ptr`管理）std::make_shared创建std::shared_ptr可以避免引用计数的动态分配，但是还存在一些std::make_shared`不能使用的场景，这时候引用计数就会动态分配。
- **递增递减引用计数必须是原子性的**，因为多个reader、writer可能在不同的线程。比如，指向某种资源的`std::shared_ptr`可能在一个线程执行析构（于是递减指向的对象的引用计数），在另一个不同的线程，`std::shared_ptr`指向相同的对象，但是执行的却是拷贝操作（因此递增了同一个引用计数）。原子操作通常比非原子操作要慢，所以即使引用计数通常只有一个*word*大小，也应该假定读写它们是存在开销的。
## API
```cpp
// 因为 shared_ptr 的构造函数是 explicit 的，不能将一个内置指针隐式转换为一个智能指针，因此必须使用直接初始化形式。
shared_ptr<int> p1 = new int(1024);    // error: must use direct initialization
shared_ptr<int> p2(new int(1024));     // ok: uses direct initialization

make_shared<T>(arg); // 在动态内存中分配一个对象并初始化它，返回指向此对象的shared_ptr
shared_ptr<T>p(q);  // q 为 shared_ptr：递增 q，之后拷贝 q 到 p，q 中的指针必须可以转换为 T*
p = q;				// 递减 p 的引用计数，若变为 0 则释放原本指向的资源，递增 q 的引用计数
p = unique();		// 若引用计数为 1 返回 true，否则 false
p.use_count();		// 返回引用计数（性能不好）

// 关于 p = q
shared_ptr<int> q(new int(10));
shared_ptr<int> p(new int(20));
cout << q.use_count() << endl;
cout << p.use_count() << endl;
int *temp = p.get();
p = q;
cout << *temp << endl; // 非法访问内存

shared_ptr<T>p(u);    // p 从 u 接管对象所有权，将 u 置空、
// q 为内置指针：接管内置指针所有权，设置删除器为可调用对象 d，q 必须指向 new 分配的内存
// q 为shared_ptr：p 为 q 的拷贝，设置 p 删除器为可调用对象 d
shared_ptr<T>p(q, d); 

// 若 *this 已占有对象，且它是最后一个占有该对象的 shared_ptr ，则通过所占有的删除器销毁对象。之后以 ptr 所指向对象替换被管理对象
p.reset(q, d);			  // 若传递内置参数 q，则令 p 指向 q，并设置删除器用于删除 q，若没有传递则将 p 置空（引用计数为 0）
```
## Use
### Raw
引用计数的智能指针解决很多内存管理的问题，例如双重释放。例如，假设有如下两个指向同一内存的原始指针：
```cpp
Simple* mySimple1 { new Simple{} };
Simple* mySimple2 { mySimple1 }; // Make a copy of the pointer.

// 释放两个原始指针会导致双重释放
delete mySimple2;
delete mySimple1;

// 通过使用引用计数的智能指针 shared_ptr, 可以避免这种问题
auto smartPtr1 { make_shared() }; 
auto smartPtr2 { smartPtr1 }; // Make a copy of the pointer.
```
所有这些只有在没有原始指针的情况下才能正常工作：
```cpp
Simple* mySimple { new Simple{} };
// 创建两个指向原始指针的 sharedjtr 实例
// 当被销毁时，两个智能指针都会试图释放同一个对象
shared_ptr<Simple> smartPtr1 { mySimple };
shared_ptr<Simple> smartPtr2 { mySimple };
```
因此不要混合使用内置指针和智能指针，当将 `shared_ptr` 绑定到内置指针后，资源管理就应该交由 `shared_ptr` 负责，也不应该再使用内置指针访问 `shared_ptr` 指向的内存：
```c++
// ptr is created and initialized when process is called
void process(shared_ptr<int> ptr) {
    // use ptr
}   // ptr goes out of scope and is destroyed

int *x(new int(1024));   // dangerous: x is a plain pointer, not a smart pointer
process(x);     // error: cannot convert int* to shared_ptr<int>
// 传递内置指针显式构造的临时的 shared_ptr
process(shared_ptr<int>(x));    // legal, but the memory will be deleted!
int j = *x;     // undefined: x is a dangling pointer!


```
在上面的调用中，将一个临时 `shared_ptr` 传递给 `process`。当这个调用所在的表达式结束时，这个临时对象被销毁。销毁这个临时变量会递减引用计数，此时引用计数就变为 0。因此，当临时对象被销毁时，它所指向的内存会被释放。 但 `x` 继续指向已经释放的内存，从而变成一个空悬指针。如果试图使用 `x` 的值，其行为是未定义的。 
```c++
// 传递 shared_ptr 局部变量而不是临时变量
shared_ptr<int> p(new int(42));   // reference count is 1
process(p);     // copying p increments its count; in process the reference count is 2
int i = *p;     // ok: reference count is 1
```
### Get
智能指针的 `get` 函数返回一个内置指针，指向智能指针管理的对象，主要用于向不能使用智能指针的代码传递内置指针，但永远不要使用 `get` 初始化另一个智能指针或为智能指针赋值，`get` 用来将指针的访问权限传递给代码，只有在确定代码不会 `delete` 指针的情况下，才能使用 `get`，也不要 `delete` `get` 返回的指针。
```c++
shared_ptr<int> p(new int(42));    // reference count is 1
int *q = p.get();   // ok: but don't use q in any way that might delete its pointer
{   // new block
    // undefined: two independent shared_ptrs point to the same memory
    shared_ptr<int>(q);
} // block ends, q is destroyed, and the memory to which q points is freed
int foo = *p;   // undefined; the memory to which p points was freed
```
`p` 和 `q` 指向相同的内存。由于它们是相互独立创建的，因此各自的引用计数都是 1。当 `q` 所在的程序块结束时，`q` 被销毁，这会导致 `q` 指向的内存被释放，从而 `p` 变成一个空悬指针，意味着当试图使用 `p` 时，将发生未定义的行为。而且，当 `p` 被销毁时，这块内存会被第二次 `delete`。
### Reset
可以用 `reset` 函数将新的指针赋予`shared_ptr`。与赋值类似，`reset` 会更新引用计数，如果需要的话，还会释放内存空间。`reset` 经常与 `unique` 一起使用，来控制多个 `shared_ptr` 共享的对象。
```c++
p = new int(1024); // 错误：不能将一个之间指针赋予 
shared_ptrp.reset(new int(1024)); // 正确：通过 reset 赋予，p 指向一个新对象
```
在改变底层对象之前，检查自己是否是当前对象仅有的用户。如果不是，在改变之前要制作一份新的拷贝：
```c++
if (!p.unique()) p.reset(new string(*p));   // we aren't alone; allocate a new copy
*p += newVal;   // now that we know we're the only pointer, okay to change this object
```
### Alias
`shared_ptr` 支持别名。这允许一个 `shared_ptr` 与另一个 `shared_ptr` 共享一个指针(`owned pointer`)，但指向不同的对象(`stored pointer`)。例如，这可用于使用一个 `shared_ptr` 拥有一个对象本身的同时，指向该对象的成员。例如：
```cpp
class Foo
{
    public:
    Foo(int value) : m_data { value } { }
    int m_data;
};
auto foo { make_shared<Foo>(42) };
auto aliasing { shared_ptr<int> { foo, &foo->m_data } };
```
仅当 `foo` 和 `aliasing` 都销毁时，才销毁 `Foo` 对象。`owned pointer` 用于引用计数，对指针解引用或调用它的 `get` 时，将返回 `stored pointer`。
### Passing
仅当涉及所有权转移或所有权共享时，接受指针作为其参数之一的函数才应接受智能指针。要共享`shared_ptr` 的所有权，只需要接受按值传递的 `shared_ptr` 作为参数。类似地，要转移 `unique_ptr` 的所有权，只需要接受按值传递的 `unique_ptr` 作为参数，后者需要使用移动语义。
### Ret
标准智能指针可以简单有效地从函数中按值返回：
```cpp
unique_ptr<Simple> create()
{
    auto ptr { make_unique<Simple>() };
    // Do something with ptr...
    return ptr;
}
```
## Deletor
类似`std::unique_ptr`，`std::shared_ptr`使用`delete`作为资源的默认销毁机制，但是它也支持自定义的删除器。这种支持有别于`std::unique_ptr`。**对于`std::unique_ptr`来说，删除器类型是智能指针类型的一部分**。对于`std::shared_ptr`则不是：
```CPP
auto loggingDel = [](Widget *pw) {                     
                      makeLogEntry(pw);
                      delete pw;
                  };

std::unique_ptr<Widget, decltype(loggingDel)> upw(new Widget, loggingDel);  //删除器类型是指针类型的一部分
std::shared_ptr<Widget> spw(new Widget, loggingDel);               //删除器类型不是指针类型的一部分
```
`std::shared_ptr`的设计更为灵活。考虑有两个`std::shared_ptr<Widget>`，每个自带不同的删除器（比如通过*lambda*表达式自定义删除器）：
```CPP
auto customDeleter1 = [](Widget *pw) { … };     //自定义删除器，
auto customDeleter2 = [](Widget *pw) { … };     //每种类型不同
std::shared_ptr<Widget> pw1(new Widget, customDeleter1);
std::shared_ptr<Widget> pw2(new Widget, customDeleter2);
```
因为`pw1`和`pw2`有相同的类型，所以它们都可以放到存放那个类型的对象的容器中：
```CPP
std::vector<std::shared_ptr<Widget>> vpw{ pw1, pw2 }; 
```
它们也能相互赋值，也可以传入一个形参为`std::shared_ptr<Widget>`的函数。但是自定义删除器类型不同的`std::unique_ptr`就不行，因为`std::unique_ptr`把删除器视作类型的一部分。
## 控制块
另一个不同于`std::unique_ptr`的地方是，指定自定义删除器不会改变`std::shared_ptr`对象的大小。不管删除器是什么，一个`std::shared_ptr`对象都是两个指针大小。因为那部分内存不是`std::shared_ptr`对象的一部分，引用计数是另一个更大的数据结构的一部分，那个数据结构通常叫做**控制块**（*control block*）。
每个`std::shared_ptr`管理的对象都有个相应的控制块。控制块除了包含引用计数值外还有一个自定义删除器的拷贝，当然前提是存在自定义删除器。如果用户还指定了自定义分配器，控制块也会包含一个分配器的拷贝。控制块可能还包含一些额外的数据，一个次级引用计数*weak count*：
![image-20230131131612863](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230131131612863.png)
通常，对于一个创建指向对象的`std::shared_ptr`的函数来说不可能知道是否有其他`std::shared_ptr`早已指向那个对象，所以控制块的创建会遵循下面几条规则：
- **`std::make_shared`总是创建一个控制块**。它创建一个要指向的新对象，所以可以肯定`std::make_shared`调用时对象不存在其他控制块。
- **当从独占指针（即`std::unique_ptr`或者`std::auto_ptr`）上构造出`std::shared_ptr`时会创建控制块**。独占指针没有使用控制块，所以指针指向的对象没有关联控制块。（作为构造的一部分，`std::shared_ptr`侵占独占指针所指向的对象的独占权，所以独占指针被设置为null）
- **当从原始指针上构造出`std::shared_ptr`时会创建控制块**。如果你想从一个早已存在控制块的对象上创建`std::shared_ptr`，你将假定传递一个`std::shared_ptr`或者`std::weak_ptr`作为构造函数实参，而不是原始指针。用`std::shared_ptr`或者`std::weak_ptr`作为构造函数实参创建`std::shared_ptr`不会创建新控制块，因为它可以依赖传递来的智能指针指向控制块。
这些规则造成的后果就是从原始指针上构造超过一个`std::shared_ptr`就会让你走上未定义行为的快车道，因为指向的对象有多个控制块关联。多个控制块意味着多个引用计数值，多个引用计数值意味着对象将会被销毁多次（每个引用计数一次）。那意味着像下面的代码是有问题的，很有问题，问题很大：
```cpp
auto pw = new Widget;                           //pw是原始指针
std::shared_ptr<Widget> spw1(pw, loggingDel);   //为*pw创建控制块
std::shared_ptr<Widget> spw2(pw, loggingDel);   //为*pw创建第二个控制块
```
传给`spw1`的构造函数一个原始指针，它会为指向的对象创建一个控制块（因此有个引用计数值）。这种情况下，指向的对象是`*pw`（即`pw`指向的对象）。就其本身而言没什么问题，但是将同样的原始指针传递给`spw2`的构造函数会再次为`*pw`创建一个控制块（所以也有个引用计数值）。因此`*pw`有两个引用计数值，每一个最后都会变成零，然后最终导致`*pw`销毁两次。第二个销毁会产生未定义行为。
`std::shared_ptr`给我们上了两堂课。第一，避免传给`std::shared_ptr`构造函数原始指针。通常替代方案是使用`std::make_shared`，不过上面例子中，我们使用了自定义删除器，用`std::make_shared`就没办法做到。第二，如果你必须传给`std::shared_ptr`构造函数原始指针，直接传`new`出来的结果，不要传指针变量：
```cpp
std::shared_ptr<Widget> spw1(new Widget, loggingDel);
// 相应的，创建spw2也会很自然的用spw1作为初始化参数
std::shared_ptr<Widget> spw2(spw1);         //spw2使用spw1一样的控制块
```
如果上面代码第一部分这样重写：
```cpp
std::shared_ptr<Widget> spw1(new Widget,    //直接使用new的结果
                             loggingDel);
```
会少了很多从原始指针上构造第二个`std::shared_ptr`的诱惑。相应的，创建`spw2`也会很自然的用`spw1`作为初始化参数（即用`std::shared_ptr`拷贝构造函数），那就没什么问题了：
```CPP
std::shared_ptr<Widget> spw2(spw1);         //spw2使用spw1一样的控制块
```

控制块通常只占几个*word*大小，自定义删除器和分配器可能会让它变大一点。通常控制块的实现比你想的更复杂一些。它使用继承，甚至里面还有一个虚函数（用来确保指向的对象被正确销毁）。这意味着使用`std::shared_ptr`还会招致控制块使用虚函数带来的成本。
如果独占资源可行或者**可能**可行，用`std::unique_ptr`是一个更好的选择。它的性能表现更接近于原始指针，并且从`std::unique_ptr`升级到`std::shared_ptr`也很容易，因为`std::shared_ptr`可以从`std::unique_ptr`上创建。
反之不行。当你的资源由`std::shared_ptr`管理，现在又想修改资源生命周期管理方式是没有办法的。即使引用计数为一，你也不能重新修改资源所有权，改用`std::unique_ptr`管理它。资源和指向它的`std::shared_ptr`的签订的所有权协议是“除非死亡否则永不分开”。不能分离，不能废除，没有特许。
`std::shared_ptr`不能处理的另一个东西是数组。和`std::unique_ptr`不同的是，`std::shared_ptr`的API设计之初就是针对单个对象的，没有办法`std::shared_ptr<T[]>`。一方面，`std::shared_ptr`没有提供`operator[]`，所以数组索引操作需要借助怪异的指针算术。另一方面，`std::shared_ptr`支持转换为指向基类的指针，这对于单个对象来说有效，但是当用于数组类型时相当于在类型系统上开洞。
## This
使用 `this` 指针作为 `shared_ptr` 构造函数实参的时候可能导致创建多个控制块。
```c++
class Widget {
public:
    void process();
};

std::vector<std::shared_ptr<Widget>> processedWidgets;

void Widget::process() {
    processedWidgets.emplace_back(this);  //处理Widget然后将它加到已处理过的Widget
}       
```
上面的代码可以通过编译，但是向`std::shared_ptr`的容器传递一个原始指针（`this`），`std::shared_ptr`会由此为指向的`Widget`（`*this`）创建一个控制块。那看起来没什么问题，直到你意识到如果成员函数外面早已存在指向那个`Widget`对象的指针，它是未定义行为。
`std::shared_ptr`API已有处理这种情况的设施。它的名字可能是C++标准库中最奇怪的一个：`std::enable_shared_from_this`。如果你想创建一个用`std::shared_ptr`管理的类，这个类能够用`this`指针安全地创建一个`std::shared_ptr`，`std::enable_shared_from_this`就可作为基类的模板类。在例子中，`Widget`将会继承自`std::enable_shared_from_this`：
```cpp
class Widget: public std::enable_shared_from_this<Widget> {
public:
    void process();
};
```
`std::enable_shared_from_this`是一个基类模板。它的模板参数总是某个继承自它的类，所以`Widget`继承自`std::enable_shared_from_this<Widget>`。如果某类型继承自一个由该类型（作为模板类型参数）进行模板化得到的基类这个东西让你心脏有点遭不住，别去想它就好了。代码完全合法，而且它背后的设计模式就是奇异递归模板模式（*The Curiously Recurring Template Pattern*（*CRTP*））。
`std::enable_shared_from_this`定义了一个成员函数，成员函数会创建指向当前对象的`std::shared_ptr`却不创建多余控制块。这个成员函数就是`shared_from_this`，无论在哪当你想**在成员函数中使用`std::shared_ptr`指向`this`所指对象时都请使用它**。这里有个`Widget::process`的安全实现：
```cpp
void Widget::process() {
    //和之前一样，处理Widget，把指向当前对象的std::shared_ptr加入processedWidgets
    processedWidgets.emplace_back(shared_from_this());
}
```
从内部来说，`shared_from_this`查找当前对象控制块，然后创建一个新的`std::shared_ptr`关联这个控制块。设计的依据是当前对象已经存在一个关联的控制块。要想符合设计依据的情况，必须已经存在一个指向当前对象的`std::shared_ptr`（比如调用`shared_from_this`的成员函数外面已经存在一个`std::shared_ptr`）。如果没有`std::shared_ptr`指向当前对象（即当前对象没有关联控制块），行为是未定义的，`shared_from_this`通常抛出一个异常。
要想防止客户端在存在一个指向对象的`std::shared_ptr`前先调用含有`shared_from_this`的成员函数，继承自`std::enable_shared_from_this`的类通常将它们的构造函数声明为`private`，并且让客户端通过返回`std::shared_ptr`的工厂函数创建对象。以`Widget`为例，代码可以是这样：
```cpp
class Widget: public std::enable_shared_from_this<Widget> {
public:
    template<typename... Ts> //完美转发参数给private构造函数的工厂函数
    static std::shared_ptr<Widget> create(Ts&&... params);
    void process();     //和前面一样
private:
    …                   //构造函数
};
```
## enable_shared_from_this
`enable_shared_from_this` 派生的类允许对象调用方法，以安全地返回指向自己的 `shared_ptr` 或 `weak_ptr`。如果没有这个基类，返回有效的 `shared_ptr` 或 `weak_ptr` 的一种方法是将 `weak_ptr` 作为成员添加至类中，并返回它的副本或返回由它构造的 `shared_ptr`。
`enable_shared_from_this` 类给派生类添加以下两个方法：
- `shared_from_this` 返回一个 `shared_ptr`，它共享对象的所有权。
- `weak_from_this` 返回一个 `weak_ptr`，它跟踪对象的所有权。
```cpp
class Foo : public enable_shared_from_this<Foo>
{
public:
    shared_ptr<Foo> getPointer() {
        return shared_from_this();
    }
};
int main()
{
    auto ptr1 { make_shared<Foo>() };
    auto ptr2 { ptr1->getPointer() };
}
```
仅当对象的指针已经存储在 `shared_ptr` 时，才能使用对象上的 `shared_from_this()`。否则，将会抛出 `bad_weak_ptr` 异常。
在本例中，在 `main()` 中使用 `make_shared()` 创建一个名为 `ptr1` 的 `shared_ptr`(其中包含Foo实例)。创建这个 `shared_ptr` 后，将允许它调用 `Foo` 实例上的 `shared_from_this`，另一方面，调用 `weak_from_this()` 总是允许的，但当对象的指针还未存储在 `shared_ptr` 时，将会返回一个空的 `weak_ptr`。
下面的实现是完全错误的：
```cpp
class Foo
{
public:
    shared_ptr<Foo> getPointer() {
        return shared_ptr<Foo>(this);
    }
};
```
如果像前面那样为 `main` 使用相同的代码，`Foo` 的该实现将导致双重释放。有两个完全独立的 `shared_ptr`，`ptr1` 和 `ptr2` 指向同一对象，在离开作用域时，它们都会尝试释放该对象。
## Code
引用计数接口：
```c++
class shared_count {
public:
    shared_count() noexcept : count_(1) {};
    void add_count() noexcept { ++count_; };
    long reduce_count() noexcept {
        --count_;
        return count_;
    }
    long get_count() const noexcept { return count_; }
private:
    long count_;
};
```
对于使用 swap 实现的赋值运算符有两种选择：
1. 提供左值引用与右值引用两种版本，因为是按引用传递，因此不会调用拷贝构造或移动构造而产生副本，这会出现释放同一内存两次的情况。
2. 只提供按值传递的版本，根据传入的实参构造形参时，如果实参是左值，就调用拷贝构造，如果是右值，就调用移动构造，这两种情况都会产生副本，当函数结束后，析构的是被拷贝的副本，不会出现异常与释放同一内存两次的情况，见[[Class#Copying]]。
对于实现，需要明确：
- **模板形式的拷贝构造与移动构造不被编译器看作拷贝构造与移动构造**，因而不能自动触发阻止缺省版本的生成或删除拷贝构造函数的行为。因为成员模板不影响语言规则，声明成员模板泛化拷贝构造函数时，还需要声明正常的拷贝构造函数，否则编译器依然会声明缺省的拷贝构造。
- 非同类型的赋值或拷贝情况下，会寻找一个可行的转换，此时泛型的拷贝构造函数实际是一个转换构造函数，转换后的结果是一个右值。
若不提供非泛型的拷贝构造，而同类型的情况下并不会调用泛型拷贝构造，而是调用缺省的拷贝构造，因此需要提供非泛型的拷贝构造，用以同类型的拷贝，并提供泛型的拷贝构造，用以非同类型的转换，同时，禁止编译器生成默认的移动构造，从而只需要泛型的移动构造，不会因为同类型情况下不调用泛型拷贝构造的情况。
综上，类型不同之间肯定会调用拷贝构造用以转换，由于转换后是右值，因此会再调用移动构造，但由于在某些情况下，编译器可以消除不必要的复制/移动操作。因此会出现下述第二种省去调用移动构造的情况：
1. 若提供非泛型的移动构造，非同类型的 =，先调用泛型拷贝构造作为转换构造转换为同类型的右值智能指针，之后进入 =，即非泛型情况下，省略了不必要的移动操作。
2. 若不提供非泛型的移动构造，非同类型的 =，先调用泛型拷贝构造作为转换构造转换为同类型的右值智能指针，之后便会调用泛型的移动构造，再进入 =。
```c++
template <typename T>
class smart_ptr {
public:
    template <typename U>
    friend class smart_ptr;

    explicit smart_ptr(T* ptr = nullptr): ptr_(ptr) {
        if (ptr) shared_count_ = new shared_count();
    }
    
    // 析构函数
    // 析构函数在看到 ptr_非空时（此时根据代码逻辑，shared_count 也必然非空），
    // 需要对引用数减一，并在引用数降到零时彻底删除对象和共享计数。
    ~smart_ptr() {
        if (ptr_ && !shared_count_->reduce_count()) {
            delete ptr_;
            delete shared_count_;
        }
    }
    // 正常的拷贝构造函数
    // 若没有提供自己的拷贝构造、拷贝赋值（非模板泛型版本），则编译器会生成缺省的拷贝构造、拷贝赋值。
    // 在指针非空时把引用数加一，并复制共享计数的指针
    smart_ptr(const smart_ptr& other) {
        ptr_ = other.ptr_;
        if (ptr_) {
            other.shared_count_->add_count();
            shared_count_ = other.shared_count_;
        }
    }
    
    // 正常的移动构造函数，可以不提供，提供后可消除不必要的移动
    smart_ptr(smart_ptr&& other) noexcept {
        ptr_ = other.ptr_;
        if (ptr_) {
            shared_count_ = other.shared_count_;
            other.ptr_ = nullptr;
        }
    }
    
    // 拷贝构造函数，由于是泛型的拷贝构造，因此编译器会生成缺省的拷贝构造
    template <typename U>
    smart_ptr(const smart_ptr<U>& other) noexcept {
        ptr_ = other.ptr_;
        if (ptr_) {
            other.shared_count_->add_count();
            shared_count_ = other.shared_count_;
        }
    }
    
    // 移动构造函数，由于是泛型的移动构造，并不会禁止编译器生成缺省的拷贝构造
    // 不需要调整引用数，直接把 other.ptr_ 置为空，认为 other 不再指向该共享对象即可
    template <typename U>
    smart_ptr(smart_ptr<U>&& other) noexcept
    {
        ptr_ = other.ptr_;
        if (ptr_) {
            shared_count_ = other.shared_count_;
            other.ptr_ = nullptr;
        }
    }
    // 构造函数2，用于实现类型强制转换
    // 允许在对智能指针内部的指针对象赋值时，使用一个现有的智能指针的共享计数
    template <typename U>
    smart_ptr(const smart_ptr<U>& other, T* ptr) noexcept {
        ptr_ = ptr;
        if (ptr_) {
            other.shared_count_->add_count();
            shared_count_ = other.shared_count_;
        }
    }
    
    // 赋值操作
    // 递减 this 的引用计数，若变为 0，则释放原本指向的资源；若拷贝构造则递增 rhs 的引用计数
    // 通过 swap 同时完成了上述两个操作：交换后 this 将经由析构函数递减引用计数为 0 从而释放；若拷贝构造会先递增 rhs 之后交换
    smart_ptr& operator=(smart_ptr rhs) noexcept {
        rhs.swap(*this);
        return *this;
    }

    T* get() const noexcept {
        return ptr_;
    }
    
    long use_count() const noexcept {
        if (ptr_) return shared_count_->get_count();
        else return 0;
        
    }
    
    void swap(smart_ptr& rhs) noexcept {
        using std::swap;
        swap(ptr_, rhs.ptr_);
        swap(shared_count_, rhs.shared_count_);
    }

    T& operator*() const noexcept {
        return *ptr_;
    }
    T* operator->() const noexcept {
        return ptr_;
    }
    operator bool() const noexcept {
        return ptr_;
    }

private:
    T* ptr_;
    shared_count* shared_count_;
};
```

```c++
// swap全局函数，调用成员函数 swap 来实现交换
template<class T>
void swap(shared_ptr<T>& lhs, smart_ptr<T>& rhs) noexcept {
    lhs.swap(rhs);
}
// 指针类型转换
template <typename T, typename U>
shared_ptr<T> static_pointer_cast(const smart_ptr<U>& other) noexcept {
    T* ptr = static_cast<T*>(other.get());
    return smart_ptr<T>(other, ptr);
}
template <typename T, typename U>
shared_ptr<T> reinterpret_pointer_cast(const smart_ptr<U>& other) noexcept {
    T* ptr = reinterpret_cast<T*>(other.get());
    return smart_ptr<T>(other, ptr);
}
template <typename T, typename U>
shared_ptr<T> const_pointer_cast(const smart_ptr<U>& other) noexcept {
    T* ptr = const_cast<T*>(other.get());
    return smart_ptr<T>(other, ptr);
}
template <typename T, typename U>
shared_ptr<T> dynamic_pointer_cast(const smart_ptr<U>& other) noexcept {
    T* ptr = dynamic_cast<T*>(other.get());
    return smart_ptr<T>(other, ptr);
}
```

```cpp
class shape {
public:
    virtual ~shape() = default;
};
class circle : public shape {
public:
    ~circle() override { puts("~circle()"); }
};

int main() {
    smart_ptr<circle> ptr1(new circle());
    smart_ptr<shape> ptr2;
    ptr2 = ptr1;

    // 同类型测试
    smart_ptr<shape> ptr3(new shape());
    smart_ptr<shape> ptr4;
    ptr4 = ptr3;

    smart_ptr<int> ptr5(new int());
    smart_ptr<int> ptr6;
    ptr6 = ptr5;

    smart_ptr<int> ptr7(new int());
    smart_ptr<int> ptr8;
    ptr8 = std::move(ptr7);
}
```
## Dereferencing Operators
```cpp
T& operator*() const { return *ptr_;};
```
返回值是reference形式。如果返回的是对象（而不是对象的引用），虽然编译器允许你这么做，但会出现以下问题：ptr_ 不需非得指向类型为T的对象不可；它也可以指向一个T派生类型的对象。在这种情况下返回对象（而非对象的引用），那么函数便是返回一个错误类型的对象！这涉及所谓的切割问题。
这么一来，以该对象调用虚函数，将不会调用被指之物的动态类型相应函数。smart painter 也就因此没有在本质上适当地支持虚函数，这样的指针又哪能多么的智能呢？此外，返回reference，效率比较高，因为其中不需构造临时对象
```c++
T* operator->() const { return ptr_; };
```
考虑editTuple函数，其中用到一个smart pointer-to-Tuple ：
```c++
void editTuple(DBPtr<Tuple>& pt) {
	LogEntry<Tuple> entry(* pt); 
	do {
		pt -> displayEditDialog(); 
	} while (pt -> isValid() == false); 
}
//其中的语句：
pt -> displayEditDialog(); 
//会被编译器解释为：
(pt.operator->()) -> displayEditDialog();
```
这意味不论operator->返回什么，在该回传值身上施行->操作符都必须是合法的。因此operator->只可能返回两种东西：一个普通指针，或是一个重载了 operator->的类。大部分时候会想要返回一个普通指针，这可以运作良好。由于此函数返回一个指针，所以通过 operator-> 调用虚函数，会有应有的表现。
```c++
template<class T>
T* SmartPtr<T>::operator->() const {
	return pointee;
}
```