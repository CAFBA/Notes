# UniquePtr
`unique_ptr` 体现专有所有权语义。一个非空 `unique_ptr` 始终拥有其指向的内容。
移动一个 `unique_ptr` 将所有权从源指针转移到目的指针（源指针被设为null）。拷贝一个`unique_ptr` 是不允许的，因为如果能拷贝一个 `unique_ptr`，会得到指向相同内容的两个` unique_ptr`，每个都认为自己拥有（并且应当最后销毁）资源，销毁时就会出现重复销毁。
因此，`unique_ptr` 是一种只可移动类型。当析构时，一个非空 `unique_ptr`销毁它指向的资源。默认情况下，资源析构通过对 `unique_ptr` 里原始指针调用 `delete` 来实现。
```cpp
class Foo
{
    public:
    Foo(unique_ptr<int> data) : m_data { move(data) } { }
    private:
    unique_ptr<int> m_data;
};

auto myIntSmartPtr { make_unique<int>(42) };
Foo f { move(myIntSmartPtr) };
```
不能拷贝 `unique_ptr` 的规则有一个例外，可以拷贝或赋值一个即将被销毁的` unique_ptr`（移动构造、移动赋值）：
```c++
unique_ptr<int> clone(int p) {
    unique_ptr<int> ret(new int (p));
    return ret;
}
```
## API
```c++
unique_ptr<T> u1;         // 指向类型T的空unique_ptr，使用 delete 释放
unique_ptr<T, D> u2;      // 使用可调用对象 D 释放
unique_ptr<T, D> u3(d);   // 使用类型为 D 的对象 d 释放
u = nullptr;			  // 释放 u 指向的对象，u 置空
u.release();			  // u 放弃对指针的控制权，返回指针，将 u 置空
u.reset(q);				  // 接受一个可选的指针参数，重新设置 unique_ptr 保存的指针，如果 unique_ptr 不为空，则它原来指向的对象会被释放。
u.reset();				  // 释放 u 指向的对象
u.reset(nullptr);		  // 释放 u 指向的对象并将 u 置空

unique_ptr<int> p1(new int(42)); // 尝试将原始指针（比如new创建）赋值给std::unique_ptr通不过编译，因为是一种从原始指针到智能指针的隐式转换
// make_unique函数在动态内存中分配一个对象并初始化它，返回指向此对象的unique_ptr
unique_ptr<int> p2 = make_unique<int>(42);
unique_ptr<string> p2(p1.release());    // release makes p1 null
unique_ptr<string> p3(new string("Trex"));
p2.reset(p3.release()); // reset deletes the memory to which p2 had pointed

// release 返回的指针通常被用来初始化另一个智能指针或给智能指针赋值。如果没有用另一个智能指针保存 release返回的指针，程序就要负责资源的释放。
p2.release();   // WRONG: p2 won't free the memory and we've lost the pointer
auto p = p2.release();   // ok, but we must remember to delete(p)

// 传入的删除器是可调用对象的类型，而不是可调用对象本身
unique_ptr<int, function<void (int *)>> ptr1(new int[10], [](int *p) { 
    cout << "call deletor" << endl;  
    delete []p;
});
```
## 使用场景
`std::unique_ptr`的常见用法是作为继承层次结构中对象的工厂函数返回类型。假设有一个投资类型（比如股票、债券、房地产等）的继承结构，使用基类`Investment`。
```cpp
class Investment { … };
class Stock: public Investment { … };
class Bond: public Investment { … };
class RealEstate: public Investment { … };
```
![item18_fig1](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/item18_fig1.png)
这种继承关系的工厂函数在堆上分配一个对象然后返回指针，调用方在不需要的时候有责任销毁对象。这使用场景完美匹配`std::unique_ptr`，因为调用者对工厂返回的资源负责（即对该资源的专有所有权），并且`std::unique_ptr`在自己被销毁时会自动销毁指向的内容。`Investment`继承关系的工厂函数可以这样声明：
```cpp
template<typename... Ts>            //返回指向对象的std::unique_ptr，
std::unique_ptr<Investment>         //对象使用给定实参创建
makeInvestment(Ts&&... params);
```
调用者应该在单独的作用域中使用返回的`std::unique_ptr`智能指针：
```cpp
{
    …
    auto pInvestment =                  //pInvestment是
        makeInvestment( arguments );    //std::unique_ptr<Investment>类型
    …
}                                       //销毁 *pInvestment
```
但是也可以在所有权转移的场景中使用它，比如将工厂返回的`std::unique_ptr`移入容器中，然后将容器元素移入一个对象的数据成员中，然后对象过后被销毁。发生这种情况时，这个对象的`std::unique_ptr`数据成员也被销毁，并且智能指针数据成员的析构将导致从工厂返回的资源被销毁。如果所有权链由于异常或者其他非典型控制流出现中断（比如提前从函数return或者循环中的`break`），则拥有托管资源的`std::unique_ptr`将保证指向内容的析构函数被调用，销毁对应资源。这个规则也有些例外，大多数情况发生于不正常的程序终止。
默认情况下，销毁将通过`delete`进行，但是在构造过程中，`std::unique_ptr`对象可以设置**自定义删除器**，当资源需要销毁时可调用的函数对象。如果通过`makeInvestment`创建的对象不应仅仅被`delete`，而应该先写一条日志，`makeInvestment`可以以如下方式实现：
```c++
auto delInvmt = [](Investment* pInvestment) {                                   
                    makeLogEntry(pInvestment);
                    delete pInvestment; 
                };

template<typename... Ts>
std::unique_ptr<Investment, decltype(delInvmt)>     //更改后的返回类型
makeInvestment(Ts&&... params) {
    std::unique_ptr<Investment, decltype(delInvmt)> pInv(nullptr, delInvmt); //应返回的指针
    if (/*一个Stock对象应被创建*/) {
        pInv.reset(new Stock(std::forward<Ts>(params)...));
    }
    else if ( /*一个Bond对象应被创建*/ ) {     
        pInv.reset(new Bond(std::forward<Ts>(params)...));   
    }   
    else if ( /*一个RealEstate对象应被创建*/ ) {     
        pInv.reset(new RealEstate(std::forward<Ts>(params)...));   
    }   
    return pInv;
}
```
从使用者角度，`makeInvestment`接口很棒：
- `delInvmt`是从`makeInvestment`返回的对象的自定义的删除器。所有的自定义的删除行为接受要销毁对象的原始指针，然后执行所有必要行为实现销毁操作。在上面情况中，操作包括调用`makeLogEntry`然后应用`delete`。使用*lambda*创建`delInvmt`是方便的，而且，正如稍后看到的，比编写常规的函数更有效。
- 当使用自定义删除器时，删除器类型必须作为第二个类型实参传给`std::unique_ptr`。在上面情况中，就是`delInvmt`的类型，这就是为什么`makeInvestment`返回类型是`std::unique_ptr<Investment, decltype(delInvmt)>`。
- `makeInvestment`的基本策略是创建一个空的`std::unique_ptr`，然后指向一个合适类型的对象，然后返回。为了将自定义删除器`delInvmt`与`pInv`关联，我们把`delInvmt`作为`pInv`构造函数的第二个实参。
- 尝试将原始指针（比如`new`创建）赋值给`std::unique_ptr`通不过编译，因为是一种从原始指针到智能指针的隐式转换。这种隐式转换会出问题，所以C++11的智能指针禁止这个行为。这就是通过`reset`来让`pInv`接管通过`new`创建的对象的所有权的原因。
- 使用`new`时，使用`std::forward`把传给`makeInvestment`的实参完美转发出去。这使调用者提供的所有信息可用于正在创建的对象的构造函数。
- 自定义删除器的一个形参，类型是`Investment*`，不管在`makeInvestment`内部创建的对象的真实类型（如`Stock`，`Bond`，或`RealEstate`）是什么，它最终在*lambda*表达式中，作为`Investment*`对象被删除。这意味着通过基类指针删除派生类实例，为此，基类`Investment`必须有虚析构函数：
  ```cpp
  class Investment {
  public:
      …
      virtual ~Investment();          //关键设计部分！
      …
  };
  ```
在C++14中，函数的返回类型推导存在，意味着`makeInvestment`可以以更简单，更封装的方式实现：
```cpp
template<typename... Ts>
auto makeInvestment(Ts&&... params)                 //C++14
{
    auto delInvmt = [](Investment* pInvestment)     //现在在
                    {                               //makeInvestment里
                        makeLogEntry(pInvestment);
                        delete pInvestment; 
                    };

    std::unique_ptr<Investment, decltype(delInvmt)> //同之前一样
        pInv(nullptr, delInvmt);
    if ( … )                                        //同之前一样
    {
        pInv.reset(new Stock(std::forward<Ts>(params)...));
    }
    else if ( … )                                   //同之前一样
    {     
        pInv.reset(new Bond(std::forward<Ts>(params)...));   
    }   
    else if ( … )                                   //同之前一样
    {     
        pInv.reset(new RealEstate(std::forward<Ts>(params)...));   
    }   
    return pInv;                                    //同之前一样
}
```
默认情况下 `unique_ptr `用 `delete` 释放其指向的对象。`unique_ptr`的删除器同样可以重载，但 `unique_ptr` 管理删除器的方式与 `shared_ptr` 不同：**重载一个 `unique_ptr `中的删除器会影响到 `unique_ptr` 类型以及如何构造（或reset）该类型的对象。因此定义使用删除器的 `unique_ptr` 必须在尖括号中提供删除器类型**。
当使用默认删除器时（如`delete`），可以合理假设`std::unique_ptr`对象和原始指针大小相同。当自定义删除器时，情况可能不再如此。函数指针形式的删除器，通常会使`std::unique_ptr`的从一个字（*word*）大小增加到两个。对于函数对象形式的删除器来说，变化的大小取决于函数对象中存储的状态多少，**无状态函数（stateless function）对象（比如不捕获变量的*lambda*表达式）对大小没有影响，这意味当自定义删除器可以实现为函数或者*lambda*时，尽量使用*lambda***：
```c++
auto delInvmt1 = [](Investment* pInvestment)        //无状态lambda的
                 {                                  //自定义删除器
                     makeLogEntry(pInvestment);
                     delete pInvestment; 
                 };

template<typename... Ts>                            //返回类型大小是
std::unique_ptr<Investment, decltype(delInvmt1)>    //Investment*的大小
makeInvestment(Ts&&... args);

void delInvmt2(Investment* pInvestment)             //函数形式的
{                                                   //自定义删除器
    makeLogEntry(pInvestment);
    delete pInvestment;
}
template<typename... Ts>                            //返回类型大小是
std::unique_ptr<Investment, void (*)(Investment*)>  //Investment*的指针
makeInvestment(Ts&&... params);                     //加至少一个函数指针的大小
```
`std::unique_ptr`可以轻松高效的转换为`std::shared_ptr`：
```cpp
std::shared_ptr<Investment> sp =            //将std::unique_ptr
    makeInvestment(arguments);              //转为std::shared_ptr
```
这就是`std::unique_ptr`非常适合用作工厂函数返回类型的原因的关键部分。 工厂函数无法知道调用者是否要对它们返回的对象使用专有所有权语义，或者共享所有权（即`std::shared_ptr`）是否更合适。 通过返回`std::unique_ptr`，工厂为调用者提供了最有效的智能指针，但它们并不妨碍调用者用其更灵活的兄弟替换它。
## Code
```c++
template <class T>
class unique_ptr {
public:
    explicit unique_ptr(T* ptr = nullptr): ptr_(ptr){}

    ~unique_ptr(){ delete ptr_; }

    T* get() const { return ptr_; };

    T& operator*() const { return *ptr_;};
    T* operator->() const { return ptr_; };
    operator bool() const { return ptr_; };

    template<class U>
    unique_ptr(unique_ptr<U>&& other) noexcept {
        ptr_ = other.release();
    }

    unique_ptr& operator=(unique_ptr rhs) {
        rhs.swap(*this);
        return *this;
    }

    T* release() {
        T* ptr = ptr_;
        ptr_ = nullptr;
        return ptr;
    }

    void swap(unique_ptr& rhs) {
        using std::swap;
        swap(ptr_, rhs.ptr_);
    }
private:
    T* ptr_;
};
```

```cpp
// 测试类
class shape {
public:
    virtual ~shape() = default;
};
class circle : public shape {
public:
    ~circle() { puts("~circle()"); }
};

int main() {
    unique_ptr<circle> ptr1(new circle());
    unique_ptr<shape> ptr2;
    ptr2 = std::move(ptr1);
}
```