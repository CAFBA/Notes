## Noexcept
### Optimization
`noexcept` 函数较之于 `non-noexcept` 函数更容易优化。考虑一个函数 `f`，它保证调用者永远不会收到一个异常。两种表达方式如下：
```cpp
int f(int x) throw();   //C++98风格，没有来自f的异常
int f(int x) noexcept;  //C++11风格，没有来自f的异常
```
如果在运行时，`f` 出现一个异常，那么就和 `f` 的异常说明冲突了。在 `C++98` 的异常说明中，调用栈会展开至 `f` 的调用者，在一些与这地方不相关的动作后，程序被终止。`C++11` 异常说明的运行时行为有些不同：调用栈只是**可能**在程序终止前展开。
展开调用栈和可能展开调用栈两者对于代码生成有非常大的影响。在一个 `noexcept` 函数中，当异常可能传播到函数外时，优化器不需要保证运行时栈处于可展开状态，也不需要保证当异常离开 `noexcept` 函数时，`noexcept` 函数中的对象按照构造的反序析构。而标注 `throw()` 异常声明的函数缺少这样的优化灵活性，没加异常声明的函数也一样：
```cpp
RetType function(params) noexcept;  //极尽所能优化
RetType function(params) throw();   //较少优化
RetType function(params);           //较少优化
```
大多数函数是异常中立的（可能抛也可能不抛异常）而不是 `noexcept` 的，这些函数自己不抛异常，但是它们内部的调用可能抛出。此时，异常中立函数允许那些抛出异常的函数在调用链上更进一步直到遇到异常处理程序，而不是就地终止。异常中立函数决不应该声明为 `noexcept`，因为它们可能在当前这个函数内不处理异常，但是又不立即终止程序，而是让调用这个函数的函数处理异常，因此大多数函数缺少 `noexcept` 设计。
然而，一些函数很自然的不应该抛异常，尤其是使 `swap` 和移动操作 `noexcept` 有重大意义，只要可能就应该将它们实现为 `noexcept`。
### Move And Swap
交换高层次数据结构是否 `noexcept` 取决于它的构成部分的那些低层次数据结构是否 `noexcept`，这说明只要可以就提供 `noexcept swap` 函数。
当新元素添加到 `vector`，`vector` 的大小等于它的容量。这时候 `vector` 会分配一个新的更大块的内存用于存放其中元素，然后将元素从老内存区移动到新内存区，然后析构老内存区里的对象。在 `C++98` 中，移动是通过复制老内存区的每一个元素到新内存区完成的，然后老内存区的每个元素发生析构。这种方法使得 `push_back` 可以提供很强的异常安全保证：如果在复制元素期间抛出异常， `vector` 状态保持不变，因为老内存元素析构必须建立在它们已经成功复制到新内存的前提下。
在 `C++11` 中，一个很自然的优化就是将上述复制操作替换为移动操作。但是这会破坏 `push_back` 的异常安全保证。如果 `n` 个元素已经从老内存移动到了新内存区，但异常在移动第 `n+1` 个元素时抛出，那么 `push_back` 操作就不能完成。但是原始的 `vector` 已经被修改：有 `n` 个元素已经移动走了。恢复 `vector` 至原始状态也不太可能，因为从新内存移动到老内存本身又可能引发异常。
这是个很严重的问题，因为老代码可能依赖于 `push_back` 提供的强烈的异常安全保证。因此， `C++11` 版本的实现不能简单的将 `push_back` 里面的复制操作替换为移动操作，除非知晓移动操作绝不抛异常，这时复制替换为移动就是安全的，唯一的副作用就是性能得到提升。
### Memory
在 `C++98`，允许内存释放函数`operator delete` 和 `operator delete[]` 和析构函数抛出异常是糟糕的代码设计，`C++11` 将这种作风升级为语言规则。默认情况下，内存释放函数和析构函数——不管是用户定义的还是编译器生成的——都是隐式 `noexcept`，因此它们不需要声明 `noexcept`。
析构函数非隐式 `noexcept` 的情况仅当类的数据成员（包括继承的成员还有继承成员内的数据成员）明确声明它的析构函数可能抛出异常（如声明 `noexcept(false)`）。这种析构函数不常见，标准库里面没有。如果一个对象的析构函数可能被标准库使用（比如在容器内或者被传给一个算法），析构函数又可能抛异常，那么程序的行为是未定义的。
## 智能指针和异常
如果使用智能指针，即使程序块过早结束，智能指针类也能确保在内存不再需要时将其释放。
函数的退出有两种可能，正常处理结束或者发生了异常，无论哪种情况，局部对象都会被销毁。在上面的程序中，sp是一个shared_ptr，因此sp销毁时会检查引用计数。在此例中，sp是指向这块内存的唯一指针，因此内存会被释放掉。 
```c++
void f()
{
    shared_ptr<int> sp(new int(42));    // allocate a new object
    // code that throws an exception that is not caught inside f
} // shared_ptr freed automatically when the function ends
```
与之相对的，当发生异常时，直接管理的内存是不会自动释放的。如果使用内置指针管理内存，且在new之后在对应的delete之前发生了异常，则内存不会被释放：
```c++
void f()
{
    int *ip = new int(42);    // dynamically allocate a new object
    // code that throws an exception that is not caught inside f
    delete ip;     // free the memory before exiting
}
```
如果在new和delete之间发生异常，且异常未在f中被捕获，则内存就永远不会被释放了。在函数f之外没有指针指向这块内存，因此就无法释放它了。
默认情况下`shared_ptr`假定其指向动态内存，使用`delete`释放对象。创建`shared_ptr`时可以传递一个（可选）指向删除函数的指针参数，用来代替`delete`。
```c++
struct destination;    // represents what we are connecting to
struct connection;     // information needed to use the connection
connection connect(destination*);   // open the connection
void disconnect(connection);    // close the given connection
void end_connection(connection *p)
{
    disconnect(*p);
}

void f(destination &d /* other parameters */)
{
    connection c = connect(&d);
    shared_ptr<connection> p(&c, end_connection);
    // use the connection
    // when f exits, even if by an exception, the connection will be properly closed
}
```
当p被销毁时，它不会对自己保存的指针执行delete，而是调用end_connection。接下来，end_connection会调用disconnect，从而确保连接被关闭。如果f正常退出，那么p的销毁会作为结束处理的一部分。如果发生了异常，p同样会被销毁，从而连接被关闭。
智能指针规范：
- 不使用相同的内置指针值初始化或`reset`多个智能指针。
- 不释放`get`返回的指针。
- 不使用`get`初始化或`reset`另一个智能指针。
- 使用`get`返回的指针时，如果最后一个对应的智能指针被销毁，指针就无效了。
- 使用`shared_ptr`管理并非`new`分配的资源时，应该传递删除函数。
## 智能指针和动态数组
`unique_ptr`可以直接管理动态数组，定义时需要在对象类型后添加一对空方括号`[]`。类型说明符中的方括号指出up指向一个int数组而不是一个int。由于up指向一个数组，当up销毁它管理的指针时，会自动使用delete[]。
```c++
// up points to an array of ten uninitialized ints
unique_ptr<int[]> up(new int[10]);
up.release();   // automatically uses delete[] to destroy its pointer
```
当一个 unique_ptr指向一个数组时，不能使用点和箭头成员运算符。毕竟unique_ptr指向的是一个数组而不是单个对象，因此这些运算符是无意义的。另一方面，当一个unique_ptr指向一个数组时，可以使用下标运算符来访问数组中的元素
与`unique_ptr`不同，`shared_ptr`不直接支持动态数组管理。如果想用`shared_ptr`管理动态数组，必须提供自定义的删除器。
```c++
// to use a shared_ptr we must supply a deleter
shared_ptr<int> sp(new int[10], [](int *p) { delete[] p; });
sp.reset();    // uses the lambda we supplied that uses delete[] to free the array
```
`shared_ptr`未定义下标运算符，智能指针类型也不支持指针算术运算。因此如果想访问`shared_ptr`管理的数组元素，必须先用`get`获取内置指针，再用内置指针进行访问。
```c++
// shared_ptrs don't have subscript operator and don't support pointer arithmetic
for (size_t i = 0; i != 10; ++i)
    *(sp.get() + i) = i;    // use get to get a built-in pointer
```
