# MoveSemantics
## The Value Class of The Expression
![img](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/18b692072537d4ce179d3857a8a0133c.png)
**lvalue**：有标识符、可以取地址的表达式，比如变量、函数或数据成员的名字、返回左值引用的表达式，如 ++x、x = 1、cout << ' '、字符串字面量如 "hello world"。
**prvalue**：没有标识符、不可以取地址的表达式，一般也称之为临时对象。比如返回非引用类型的表达式，如 x++、x + 1、 `make_shared<int>(42)` ，函数返回非引用类型、除字符串字面量之外的字面量，如 42、true。
**xvalue**：对于表达式static_cast<int&&>(value)、move(ptr1)来说，它可以被右值引用绑定，且具备左值的运行时多态性质，对于这种既具有左值的特征，同时又能初始化右值引用的情况，在C++11中将其归为将亡值。
```c++
template <typename U>
smart_ptr(const smart_ptr<U>& other) noexcept {
    ptr_ = other.ptr_;
    if (ptr_) {
        other.shared_count_->add_count();
        shared_count_ = other.shared_count_;
    }
}
// 根据定义，此处的 other 是个变量的名字，变量有标识符、有地址，所以它还是一个左值——虽然它的类型是右值引用
// 拿这个 other 去调用函数时，它匹配的也会是左值引用。也就是说，类型是右值引用的变量是一个左值
template <typename U>
smart_ptr(smart_ptr<U>&& other) noexcept {
    ptr_ = other.ptr_;
    if (ptr_) {
        shared_count_ = other.shared_count_;
        other.ptr_ = nullptr;
    }
}

smart_ptr<shape> ptr1 { new circle() };// new circle() 是一个纯右值，调用上述第一个函数
smart_ptr<shape> ptr2 = move(ptr1); // move(ptr1) 的结果是指向 ptr1 的一个右值引用，调用上述第二个函数
```
xvalue 和 prvalue 不同之处在于 C++ 对临时对象有特殊的生命周期延长规则：**如果一个 prvalue 被绑定到一个引用上，它的生命周期则会延长到跟这个引用变量一样长**。如果由于某种原因，prvalue 在绑定到引用以前已经变成了 xvalue，那生命期就不会延长。也就是说这条规则对 xvalue 无效。
下述是对延长规则的验证：
```c++
#include <stdio.h>
class shape {
public:
    virtual ~shape() {}
};
class circle : public shape {
public:
    circle() { puts("circle()"); }
    ~circle() { puts("~circle()"); }
};
class triangle : public shape {
public:
    triangle() { puts("triangle()"); }
    ~triangle() { puts("~triangle()"); }
};
class result {
public:
    result() { puts("result()"); }
    ~result() { puts("~result()"); }
};
result process_shape(const shape& shape1, const shape& shape2) {
    puts("process_shape()");
    return result();
}

// 生成临时对象 circle(), triangle()，执行完成并生成结果对象后被销毁，现在函数返回临时对象后，prvalue 就被销毁（此处有三个 prvalue）
process_shape(circle(), triangle());
// prvalue 被绑定到引用，延长到和引用一样的生命周期，现在直到程序执行结束，引用 r 被销毁后，三个 prvalue 才会被销毁
result&& r = process_shape(circle(), triangle()); 
// xrvalue 就不会起作用
// 此处仍然有一个有效的变量 r，但它指向的对象已经不存在了
// 对 r 的解引用是一个未定义行为。由于 r 指向的是栈空间，通常不会立即导致程序崩溃，而会在某些复杂的组合条件下才会引致问题
result&& r = move(process_shape(circle(), triangle()));
```
![image-20221213182038762](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221213182038762.png)
## Ref
引用变量必须在创建时被初始化，不允许在类定义之外声明一个引用而不对其进行初始化，类的数据成员可以是引用。引用不能不指向其他变量而存在，并且不可以更改引用指向的变量。因此，引用数据成员不能在类构造函数的函数体内部进行初始化，必须在构造函数初始化器中进行初始化。
引用始终指向它初始化时的那个变量，一旦创建便无法更改。如果在声明引用时将变量赋值给引用，之后将其它变量赋值给这个引用，则引用所指向的变量会更改为赋值的变量的值。原来的引用不会改为指向新的变量。
获取引用的值，实际上是获取了与引用绑定的对象的值。同理，以引用作为初始值，实际上是以与引用绑定的对象作为初始值。
```cpp
int x { 3 }, y { 4 };
int& xRef { x };
xRef = y; // Changes value of x to 4. Doesn't make xRef refer to y.
// 可以尝试使用 y 的地址对 xRef 赋值来规避此限制
xRef = &y; // DOES NOT COMPILE!
```
`y` 的地址是一个指针，但是 `xRef` 被声明为一个对 `int` 的引用，而不是对指针的引用。因此，一旦将引用初始化为引用特定变量，就无法将引用更改为引用另一个变量。只能更改引用所指向的变量的值。
### LvalueRef
**非常左值引用只能绑定左值**，因为右值不能取地址，意味着不能修改，如果允许非常左值引用绑定右值，如T&，那就能通过引用修改右值了，这与右值不可修改相矛盾。
右值可以绑定到常左值引用，因为常左值引用能够保证不修改右值，并且会生成正确类型的临时变量。当常左值引用绑定右值时，与右值引用的汇编指令相同：先产生临时量，将临时量地址放到寄存器，再将这个地址放到定义引用变量的指针当中，区别在于 `b` 是指向常量的指针，不能通过 `b` 修改：
```c++
const int &b = 20; 
int &&c = 20;  
// 上述均等价于下述
int temp = 20; // 创建临时变量
const int& b = temp;
```
因此对于 `const&`，初始值/实参为以下情况时，会生成正确类型的临时变量，使用转换后的初始值/实参来初始化：
- 实参类型正确，但不是左值
- 实参类型不正确，但可以转换为正确的类型
```cpp
double dval = 2.14;
const int &ri = dval;
// 编译器把上述代码变成如下形式
int temp = dval; // 创建临时变量
const int &ri = temp;
```
### RvalueRef
右值引用就是必须绑定到右值的引用。
变量表达式都是左值，所以不能将一个右值引用绑定到一个变量上，即使**这个变量的类型是右值引用也不行**，因为右值引用变量本身是一个左值，只能用左值引用来引用它。虽然不能将一个右值引用直接绑定到一个左值上，但可以显式地将一个左值转换为对应的右值引用类型。
### UniversalRef
`T&&` 在源码中只有一种表现形式，但具有两种不同的意思：
第一种意思是右值引用，只绑定到右值上，并且主要的存在原因就是为了识别可以移动操作的对象。
另一种意思是既可以是右值引用，也可以是左值引用，即**通用引用**（*universal references*）。二重性使既可以绑定到右值上，也可以绑定到左值上，如果它被右值初始化，就会对应地成为右值引用；如果它被左值初始化，就会成为左值引用。
此外，还可以绑定到 `const` 或者 `non-const`的对象上，也可以绑定到 `volatile` 或者 `non-volatile` 的对象上，甚至可以绑定到既 `const` 又 `volatile` 的对象上，可以绑定到几乎任何东西。
```c++
void f(Widget&& param);             //右值引用
Widget&& var1 = Widget();           //右值引用

template<typename T>
void f(vector<T>&& param);     //右值引用
```
对于通用引用的判断，总结如下：
当 `T` 作为函数或方法模板的一个模板参数时，`T&&` 是通用引用。如果一个类方法有个 `T&&` 参数，但 `T` 是类的模板参数而不是方法本身的参数，那么 `T&&` 就不是一个通用引用，而是右值引用。 这是因为当编译器开始用一个 `T&&` 参数处理那个方法时，类模板参数 `T` 已经被解析为一个具体类型。
当 `T` 作为模板形参并且 `T` 需要被推导得知时，`T&&` 就是通用引用。
当一个对象被声明为 `auto&&` 时，这个对象就是通用引用。
通用引用声明必须为 `T&&`，但不意味着引用声明为 `T&&` 的一定为通用引用，因为可能不会发生类型推导，前提条件是**必须发生类型推导**。如果类型声明的形式不是标准的 `type&&` 或类型推导没有发生，那么 `type&&` 代表一个右值引用。
#### Function Template Parameter and Auto
在两种情况下会出现通用引用。最常见的一种是函数模板形参：
```cpp
template<typename T>
void f(T&& param);                  //param是一个通用引用
```
第二种情况是`auto&&`声明符：
```cpp
auto&& var2 = var1;                 //var2是一个通用引用
```
这两种情况的共同之处就是都存在**类型推导**（*type deduction*）。在模板`f`的内部，`param`的类型需要被推导，而在变量`var2`的声明中，`var2`的类型也需要被推导。同以下的例子相比较，下面的例子不带有类型推导。**如果`T&&`不带有类型推导，那么就是一个右值引用**：
```c++
void f(Widget&& param);         //没有类型推导，param是一个右值引用
Widget&& var1 = Widget();       //没有类型推导，var1是一个右值引用
```
因为通用引用是引用，所以它们必须被初始化。**一个通用引用的初始值决定它是代表右值引用还是左值引用**。如果初始值是一个右值，那么通用引用就会是对应的右值引用，如果初始值是一个左值，那么通用引用就会是一个左值引用。对那些是函数形参的通用引用来说，初始值在调用函数的时候被提供：
```cpp
template<typename T>
void f(T&& param);              //param是一个通用引用

Widget w;
f(w);                           //传递给函数f一个左值；param的类型将会是Widget&，也即左值引用

f(move(w));                //传递给f一个右值；param的类型会是Widget&&，即右值引用
```
#### Correct Ref Statement
对一个通用引用而言，类型推导是必要的，但是它还不够。**引用声明的形式必须正确，并且该形式是被限制的**。它**必须恰好为`T&&`**：
```cpp
template <typename T>
void f(vector<T>&& param);     //param是一个右值引用
```
当函数`f`被调用的时候，类型`T`会被推导（除非调用者显式地指定它）。但是`param`的类型声明并不是`T&&`，而是一个`vector<T>&&`。这排除了`param`是一个通用引用的可能性。`param`因此是一个右值引用——当你向函数`f`传递一个左值时:
```cpp
vector<int> v;
f(v);                           //错误！不能将左值绑定到右值引用
```
即使一个简单的`const`修饰符的出现，也足以使一个引用失去成为通用引用的资格:
```cpp
template <typename T>
void f(const T&& param);        //param是一个右值引用
```
#### Special Cases Inside The Template
函数模板形参类型为`T&&`，不一定是一个通用引用，因为**在模板内部并不保证一定会发生类型推导**。考虑如下`push_back`成员函数，来自`vector`：
```cpp
template<class T, class Allocator = allocator<T>>   //来自C++标准
class vector {
public:
    void push_back(T&& x);
    …
}
```
`push_back`函数的形参当然有一个通用引用的正确形式，然而，在这里并没有发生类型推导。因为`push_back`在有一个特定的`vector`实例之前不可能存在，而实例化`vector`时的类型已经决定了`push_back`的声明。也就是说，
```cpp
vector<Widget> v;
```
将会导致`vector`模板被实例化为以下代码：
```cpp
class vector<Widget, allocator<Widget>> {
public:
    void push_back(Widget&& x);             //右值引用
    …
};
```
因此函数`push_back`不包含任何类型推导，`push_back`对于`vector<T>`而言总是声明了一个类型为rvalue-reference-to-`T`的形参。
作为对比，`vector`内的概念上相似的成员函数`emplace_back`，却确实包含类型推导:
```cpp
template<class T, class Allocator = allocator<T>>   //依旧来自C++标准
class vector {
public:
    template <class... Args>
    void emplace_back(Args&&... args);
    …
};
```
类型参数`Args`是独立于`vector`的类型参数`T`的，所以`Args`会在每次`emplace_back`被调用的时候被推导。
虽然函数`emplace_back`的类型参数被命名为`Args`，但是它仍然是一个通用引用，通用引用的格式必须是`T&&`，但使用的名字`T`并不是必要的。如下模板接受一个通用引用，因为形式（`type&&`）是正确的，并且`param`的类型将会被推导。
```cpp
template<typename MyTemplateType>           //param是通用引用
void someFunc(MyTemplateType&& param);
```
#### Certainty of Auto&&
**类型声明为`auto&&`的变量是通用引用**，因为会发生类型推导，并且它们具有正确形式`T&&`。`auto`类型的通用引用不如函数模板形参中的通用引用常见，但是它们在C++11中常常突然出现。而它们在C++14中出现得更多，因为**C++14的*lambda*表达式可以声明`auto&&`类型的形参**。
如果想写一个C++14标准的*lambda*表达式，来记录任意函数调用的时间开销：
```c++
auto timeFuncInvocation =
    [](auto&& func, auto&&... params)           //C++14
    {
        start timer;
        forward<decltype(func)>(func)(     //对params调用func
            forward<delctype(params)>(params)...
        );
        stop timer and record elapsed time;
    };
```
*lambda*表达式中声明的`auto&&`类型的形参：
`func`是一个通用引用，可以被绑定到任何可调用对象，无论左值还是右值。
`params`是0个或者多个通用引用（即它是个通用引用*parameter pack*），它可以绑定到任意数目、任意类型的对象上。
> 多亏了`auto`类型的通用引用，函数`timeFuncInvocation`可以对**近乎任意**（pretty much any）函数进行计时。
> (如果你想知道任意（any）和近乎任意（pretty much any）的区别，翻到[Item30](https://github.com/kelthuzadx/EffectiveModernCppChinese/blob/master/5.RRefMovSemPerfForw/item30.md))。
## 移动
移动的高效在于右值标明了这个对象马上就没人用了，允许移动构造函数通过调整指针把内容全部移走，编译器做的事情只是区分左值和右值，到底怎么减少复制，那就是看移动构造函数怎么写了。主要的优化点就是知道右值占用的堆上空间可以被取走，写移动构造函数和类似函数的人只需要保证被移动的对象处于一个可析构的状态即可。
不抛出异常的移动构造函数和移动赋值运算符必须标记为`noexcept`。一个移动操作不抛出异常，这是因为两个相互关联的事实：首先，虽然移动操作通常不抛出异常，但抛出异常也是允许的；其次，标准库容器能对异常发生时其自身的行为提供保障。例如，vector保证，如果调用push_back时发生异常，vector自身不会发生改变。
移动一个对象通常会改变它的值。如果重新分配过程使用了移动构造函数，且在移动了部分而不是全部元素后抛出了一个异常，就会产生问题。旧空间中的移动源元素已经被改变了，而新空间中未构造的元素可能尚不存在。在此情况下，vector将不能满足自身保持不变的要求。 
另一方面，如果vector使用了拷贝构造函数且发生了异常，它可以很容易地满足要求。在此情况下，当在新内存中构造元素时，旧元素保持不变。如果此时发生了异常，vector可以释放新分配的（但还未成功构造的）内存并返回。vector原有的元素仍然存在。 
为了避免这种潜在问题，除非vector知道元素类型的移动构造函数不会抛出异常，否则在重新分配内存的过程中，它就必须使用拷贝构造函数而不是移动构造函数。如果希望在vector重新分配内存这类情况下对自定义类型的对象进行移动而不是拷贝，就必须显式地告诉标准库移动构造函数可以安全使用。通过将移动构造函数（及移动赋值运算符）标记为noexcept来做到这一点。
C++ 里的对象缺省都是值语义。在下面这样的代码里：
```c++
class A {
  B b_;
  C c_;
};
```
从实际内存布局的角度，很多语言——如 Java 和 Python——会在 A 对象里放 B 和 C 的指针（虽然这些语言里本身没有指针的概念）。而 C++ 则会直接把 B 和 C 对象放在 A 的内存空间里。这种行为既是优点也是缺点。说它是优点，是因为它保证了内存访问的局域性，而局域性在现代处理器架构上是绝对具有性能优势的。说它是缺点，是因为复制对象的开销大大增加：在 Java 类语言里复制的是指针，在 C++ 里是完整的对象。这就是为什么 C++ 需要移动语义这一优化，而 Java 类语言里则根本不需要这个概念。
### 右值移动，左值拷贝
区分移动和拷贝的重载函数通常有一个版本接受一个`const T&`参数，另一个版本接受一个`T&&`参数（`T`为类型）。
```c++
void push_back(const X&);   // copy: binds to any kind of X
void push_back(X&&);        // move: binds only to modifiable rvalues of type X
```
> 一般来说，不需要为函数操作定义接受一个const X&&或是一个X&参数的版本。当希望从实参窃取数据时，通常传递一个右值引用。为了达到这一目的，实参不能是const的。类似的，从一个对象进行拷贝的操作不应该改变该对象。因此，通常不需要定义一个接受一个X&参数的版本。

如果一个类有可用的拷贝构造函数而没有移动构造函数，则其对象是通过拷贝构造函数来移动的，即使调用`move`函数时也是如此。拷贝赋值运算符和移动赋值运算符的情况类似。
```c++
class Foo
{
public:
    Foo() = default;
    Foo(const Foo&);    // copy constructor
    // other members, but Foo does not define a move constructor
};
Foo x;
Foo y(x);   // copy constructor; x is an lvalue
// Foo的拷贝构造函数是可行的，因为可以将一个Foo&& 转换为一个const Foo&。
Foo z(move(x));    // copy constructor, because there is no move constructor
```
使用非引用参数的单一赋值运算符可以实现拷贝赋值和移动赋值两种功能。依赖于实参的类型，左值被拷贝，右值被移动。
```c++
// assignment operator is both the move- and copy-assignment operator
HasPtr& operator=(HasPtr rhs) {
    swap(*this, rhs);
    return *this;
}
hp = hp2;   // hp2 is an lvalue; copy constructor used to copy hp2
hp = move(hp2);    // move constructor moves hp2
```
在第一个赋值中，右侧运算对象是一个左值，因此移动构造函数是不可行的。rhs将使用拷贝构造函数来初始化。拷贝构造函数将分配一个新string，并拷贝hp2指向的string。在第二个赋值中，调用move将一个右值引用绑定到hp上。在此情况下，拷贝构造函数和移动构造函数都是可行的。但是，由于实参是一个右值引用，移动构造函数是精确匹配的。移动构造函数从hp2拷贝指针，而不会分配任何内存。 
> 建议将五个拷贝控制成员当成一个整体来对待。如果一个类需要任何一个拷贝操作，它就应该定义所有五个操作。
### 移动迭代器
C++11标准库定义了移动迭代器适配器。一个移动迭代器通过改变给定迭代器的解引用运算符的行为来适配此迭代器。移动迭代器的解引用运算符返回一个右值引用。调用`make_move_iterator`函数能将一个普通迭代器转换成移动迭代器。原迭代器的所有其他操作在移动迭代器中都照常工作。
##  Reference Collapsing
对于下述模板函数：
```cpp
template<typename T>
void func(T&& param);
```
当左值实参被传入时，`T`被推导为左值引用。当右值被传入时，`T`被推导为非引用。因此：
```cpp
Widget widgetFactory();     //返回右值的函数
Widget w;                   //一个变量（左值）
func(w);                    //用左值调用func；T被推导为Widget&
func(widgetFactory());      //用右值调用func；T被推导为Widget
```
上面的两种`func`调用中，`Widget`被传入，因为一个是左值，一个是右值，模板形参`T`被推导为不同的类型，这决定通用引用成为左值还是右值，也是`forward`的工作基础。
考虑用左值调用上述模板：
```cpp
auto& & rx = x;             // 错误！不能声明引用的引用
func(w);                    // 用左值调用func，T被推导为Widget&

// 如果用T推导出来的类型Widget&初始化模板，会得到引用的引用
void func(Widget& && param);
```
但是编译器没有报错，因为虽然禁止声明引用的引用，但是**编译器**会在特定的上下文中产生这些，模板实例化就是其中一种情况。当编译器生成引用的引用时，引用折叠指导下一步发生什么。
存在两种类型的引用（左值和右值），所以有四种可能的引用组合（左值 + 左值，左值 + 右值，右值 + 右值，右值 + 左值）。如果一个上下文中允许引用的引用存在（比如，模板的实例化），引用根据规则**折叠**为单个引用：**有左值引用折叠结果就是左值引用，否则就是右值引用**。
```c++
// 引用折叠：Widget&替换进模板func会产生对左值引用的右值引用，折叠为左值引用。
void func(Widget& param);
```
综上：如果任一引用为左值引用，则结果为左值引用。否则（即，如果引用都是右值引用），结果为右值引用。
引用折叠是`forward`工作的一种关键机制。`forward`应用在通用引用参数上，所以经常能看到这样使用：
```c++
 template<typename T>  
 void f(T&& fParam)  
 {  
     …                                   //做些工作  
     someFunc(forward<T>(fParam));  //转发fParam到someFunc  
 }
```
因为`fParam`是通用引用，类型参数`T`的类型根据`f`被传入实参（即用来实例化`fParam`的表达式）是左值还是右值来编码。`forward`的作用是当且仅当传给`f`的实参为右值时，即`T`为非引用类型，才将`fParam`（左值）转化为一个右值。
引用折叠发生在四种情况下：模板实例化，`auto&&`类型推导，`typedef`与别名声明的创建和使用，`decltype`：
```c++
Widget widgetFactory();     // 返回右值的函数
Widget w;                   // 一个变量（左值）

// w是左值，万能引用推导左值w为Widget&
auto&& w1 = w;     // 把Widget&代回w1声明中的auto里，产生了引用的引用
Widget& && w1 = w; // 结果就是w1是一个左值引用

// widgetFactory()是右值，万能引用推导出非引用类型Widget
auto&& w2 = widgetFactory();    // 把Widget代入auto得到
Widget&& w2 = widgetFactory();  // w2是个右值引用
```
如果，在创建或者评估`typedef`过程中出现了引用的引用，则引用折叠就会起作用：
```c++
template<typename T>
class Widget {
public:
    typedef T&& RvalueRefToT;
};
// 假设使用左值引用实例化Widget
Widget<int&> w;
// Widget模板中把T替换为int&得到
typedef int& && RvalueRefToT; 
```
当使用左值引用类型实例化Widget时，RvalueRefToT是左值引用的typedef
如果在分析`decltype`期间，出现了引用的引用，引用折叠规则就会起作用。
## Move
`move` 和 `forward` 仅仅是执行转换的函数模板，在运行期什么也不做。`move` 无条件的将它的实参转换为右值，而 `forward` 只在特定情况满足时下进行转换。
```cpp
// 若实参为左值，则 T 与 T&&（paramType） 会被推导为左值引用；
template<typename T>                            //在std命名空间
typename remove_reference<T>::type&&
move(T&& param) { 
    // 若实参为右值，则 T 会被推导为非引用类型，返回的 T&& 将会是右值引用
    // 若实参为左值，则 T 会被推导为左值引用，返回的 T&& 将会是左值引用
    // remove_reference 应用到类型 T 上，确保 && 被正确的应用到了一个不是引用的类型上
    using ReturnType = typename remove_reference<T>::type&&;
    return static_cast<ReturnType>(param);
}

template<typename T>
decltype(auto) move(T&& param) {         //C++14，仍然在std命名空间
    using ReturnType = remove_referece_t<T>&&;
    return static_cast<ReturnType>(param);
}
```
该函数返回类型的 `&&` 部分表明 `move` 函数返回的是一个右值引用，但是，如果类型 `T` 恰好是一个左值引用，那么 `T&&` 将会成为一个左值引用。为避免如此，`remove_reference` 应用到类型 `T` 上，因此确保 `&&` 被正确的应用到一个不是引用的类型上。这保证 `move` 返回的真的是右值引用，因为函数返回的右值引用是右值。因此，`move` 将它的实参转换为一个右值，这就是它的全部作用。
`move` 的工作过程：
```c++
string s1("hi!"), s2;
s2 = move(string("bye!"));     // ok: moving from an rvalue
s2 = move(s1);     // ok: but after the assigment s1 has indeterminate value
```
在 `move(string("bye!"))` 中传递的是右值，推断出的 `T` 类型为 `string`，函数参数 `param` 的类型为 `string&&`。
`remove_reference` 用 `string` 进行实例化，`remove_reference<string>` 的 `type` 成员是`string`，`move`的返回类型是 `string&&`。
在 `move(s1)` 中传递的是左值，推断出的 `T` 类型为 `string&`，函数参数 `param` 的类型为  `string& &&`，会折叠成 `string&`。
`remove_reference` 用 `string&` 进行实例化，`remove_reference<string&>` 的 `type` 成员是 `string`，`move` 的返回类型是 `string&&`。
事实上，右值只不过**经常**是移动操作的候选者。假设你有一个类，它用来表示一段注解：
```cpp
class Annotation {
public:
    explicit Annotation(const string text);
};
```
当复制 `text` 到一个数据成员的时候，为避免一次复制操作的代价，把 `move` 应用到 `text` 上，因此产生一个右值：
```cpp
class Annotation {
public:
    explicit Annotation(const string text)
    : value(move(text))  // 移动text到value里；这段代码执行起来并不是看起来那样
    { … }                       
private:
    string value;
};
```
这段代码将数据成员 `value` 设置为 `text` 的值，但 `text` 并不是被移动到`value`，而是被**拷贝**。诚然，`text` 通过 `move` 被转换到右值，但是 `text` 被声明为 `const string`，所以在转换之前，`text` 是一个左值的 `const string`，而转换的结果是一个右值的 `const string`，但是纵观全程，`const` 属性一直保留。
当编译器决定哪一个 `string` 的构造函数被调用时，考虑它的作用，将会有两种可能性：
```cpp
class string {                  //string事实上是
public:                         //basic_string<char>的类型别名
    string(const string& rhs);  //拷贝构造函数
    string(string&& rhs);       //移动构造函数
};
```
在类 `Annotation` 的构造函数的成员初始化列表中，`move(text)` 的结果是一个 `const string` 的右值。这个右值不能被传递给 `string` 的移动构造函数，因为移动构造函数只接受一个指向 `non-const` 的 `string` 的右值引用。然而，该右值却可以被传递给 `string` 的拷贝构造函数，因为 `lvalue-reference-to-const` 允许被绑定到一个 `const` 右值上。因此，`string` 在成员初始化的过程中调用了**拷贝**构造函数，即使 `text` 已经被转换成了右值。
这样是为确保维持 `const` 属性的正确性，从一个对象中移动出某个值通常代表着修改该对象，所以语言不允许 `const` 对象被传递给可以修改他们的函数（例如移动构造函数）。
从这个例子中，可以总结出两点。第一，不要在希望能移动对象的时候，声明他们为 `const`。对 `const` 对象的移动请求会悄无声息的被转化为拷贝操作。第二点，`move` 不仅不移动任何东西，而且它也不保证它执行转换的对象可以被移动。关于 `move`，能确保的唯一一件事就是将它应用到一个对象上，能够得到一个右值。
## Forward
`forward` 是有条件的转换。最常见的情景是一个模板函数，接收一个通用引用形参，并将它传递给另外的函数：
```cpp
void process(const Widget& lvalArg);        //处理左值
void process(Widget&& rvalArg);             //处理右值

template<typename T>                        //用以转发param到process的模板
void logAndProcess(T&& param) {
    auto now = chrono::system_clock::now(); //获取现在时间
    makeLogEntry("Calling 'process'", now);
    // 若没有forward，因为函数形参是左值，总会调用process(const Widget& lvalArg)
    // 因此需要forward，使得其参数 param 绑定到右值时，将其转换为右值
    process(forward<T>(param));
}

Widget w;

logAndProcess(w);               // 用左值调用
logAndProcess(move(w));    // 用右值调用，此时 param 是绑定到右值的右值引用
```
在 `logAndProcess` 函数的内部，形参 `param` 被传递给函数 `process`。当使用左值来调用 `logAndProcess` 时，自然期望该左值被当作左值转发给 `process` 函数，而当使用右值来调用 `logAndProcess` 函数时，期望 `process` 函数的右值重载版本被调用。
但是 `param` 如所有的其他函数形参一样，是一个左值。每次在函数 `logAndProcess` 内部对函数 `process` 的调用，都会因此调用函数 `process` 的左值重载版本。为防如此，需要一种机制：当且仅当传递给函数 `logAndProcess` 的用以初始化 `param` 的实参是一个右值时，`param` 会被转换为一个右值。
因此 `forward` 是一个有条件的转换：**只有当它的参数绑定到一个右值时，才将参数转换为右值，否则什么也不做**。即通用引用使用右值初始化时，才将其强制转换为右值，因此 `forward` 用于传递通用引用形参给其他函数。
下述是 `forward` 的实现：
```cpp
template<typename T>                                //在std命名空间
T&& forward(typename remove_reference<T>::type& param) {
    return static_cast<T&&>(param);
}

template<typename T>                        //C++14 仍然在std命名空间  
T&& forward(remove_reference_t<T>& param)  
{  
  return static_cast<T&&>(param);
}
```
假设传入到 `process` 的实参是 `Widget` 的左值类型，`T` 被推导为 `Widget&`，然后调用 `forward` 将实例化为 `forward<Widget&>`。`Widget&` 带入到上面的 `forward` 的实现中：
```cpp
Widget& && forward(typename remove_reference<Widget&>::type& param)
{ return static_cast<Widget& &&>(param); }
```
`remove_reference<Widget&>::type` 这个 *type trait* 产生 `Widget`，所以 `forward` 成为：
```cpp
Widget& && forward(Widget& param)
{ return static_cast<Widget& &&>(param); }
```
根据引用折叠规则，返回值和强制转换可以化简，最终版本的 `forward` 调用就是：
```cpp
Widget& forward(Widget& param)
{ return static_cast<Widget&>(param); }
```
当左值实参被传入到函数模板 `f` 时，`forward` 被实例化为接受和返回左值引用。内部的转换不做任何事，因为 `param` 的类型已经是`Widget&`，所以转换没有影响。左值实参传入 `forward` 会返回左值引用。通过定义，左值引用就是左值，因此将左值传递给 `forward` 会返回左值，就像期待的那样。
假设传入到 `process` 的实参是 `Widget` 的右值类型，`T` 被推导为 `Widget`。`process` 内部的 `forward` 调用因此为 `forward<Widget>`，`forward` 实现中把 `T` 换为 `Widget` 得到：
```cpp
Widget&& forward(typename remove_reference<Widget>::type& param)
{ return static_cast<Widget&&>(param); }
```
将 `remove_reference` 引用到非引用类型 `Widget` 上还是相同的类型，所以 `forward` 变成：
```cpp
Widget&& forward(Widget& param)
{ return static_cast<Widget&&>(param); }
```
这里没有引用的引用，所以不需要引用折叠，这就是 `forward` 的最终实例化版本。**从函数返回的右值引用被定义为右值**，因此在这种情况下，`forward` 会将左值形参 `param` 转换为右值。最终结果是，传递给 `logAndProcess` 的右值参数将作为右值转发给 `process`，正是想要的结果。
更重要的是，**`move` 的使用代表着无条件向右值的转换，而使用 `forward` 只对绑定了右值的引用进行到右值转换**。这是两种完全不同的动作。前者是典型地为了移动操作，而后者只是传递（亦为转发）一个对象到另外一个函数，保留它原有的左值属性或右值属性。
## Move On Rvalue Ref Forward On Universal Ref
`move` 的吸引力在于它的便利性：减少了出错的可能性，增加了代码的清晰程度。考虑一个类统计有多少次移动构造函数被调用，只需要一个 `static` 的计数器，它会在移动构造的时候自增。假设在这个类中，唯一一个非静态的数据成员是 `string`，一种经典的移动构造函数可以被实现如下：
```c++
class Widget {  
public:  
    Widget(Widget&& rhs)  
    : s(move(rhs.s))  
    { ++moveCtorCalls; }  
private:  
    static size_t moveCtorCalls;  
    string s;  
};
```
如果要用 `forward` 来达成同样的效果，代码可能会看起来像：
```c++
class Widget{  
public:  
 Widget(Widget&& rhs)                    //不自然，不合理的实现  
 : s(forward<string>(rhs.s))  
 { ++moveCtorCalls; }  
}
```
`move` 只需要一个函数实参 `rhs.s`，而 `forward` 不但需要一个函数实参 `rhs.s`，还需要一个模板类型实参 `string`。其次，传递给 `forward` 的模板类型应当是一个 `non-reference`，因为惯例是传递的实参应该是一个右值，它根绝传递错误类型的可能性，例如传递引用类型 `string&` 可能导致数据成员 `s` 被复制而不是被移动构造。
可以在右值引用上使用 `forward` 表现出适当的行为，但是代码较长，容易出错，所以应该避免在右值引用上使用 `forward`。更糟的是在通用引用上使用 `move`，这可能会意外改变左值，比如局部变量：
```cpp
class Widget {
public:
    template<typename T>
    void setName(T&& newName)       //通用引用可以编译，
    { name = move(newName); }  //但是代码太太太差了！
private:
    string name;
    shared_ptr<SomeDataStructure> p;
};

string getWidgetName();        //工厂函数

Widget w;

auto n = getWidgetName();           //n是局部变量

w.setName(n);                       //把n移动进w！

…                                   //现在n的值未知
```
上面的例子，局部变量 `n` 被传递给 `w.setName`，调用方可能认为这是对 `n` 的只读操作，但是因为 `setName` 内部使用 `move` 无条件将传递的引用形参转换为右值，`n` 的值被移动进 `w.name`，调用 `setName` 返回时 `n` 最终变为未定义的值。
或许 `setName` 不应该将其形参声明为通用引用，此类引用不能使用`const`，但是 `setName` 肯定不应该修改其形参。因此如果为 `const` 左值和为右值分别重载 `setName` 可以避免整个问题，比如这样：
```cpp
class Widget {
public:
    void setName(const string& newName)    //用const左值设置
    { name = newName; }
    
    void setName(string&& newName)         //用右值设置
    { name = move(newName); }
};
```
这样的话，当然可以工作，但是有缺点。首先编写和维护的代码更多；其次，效率下降。比如，考虑如下场景：
```cpp
w.setName("Adela Novak");
```
使用通用引用的版本的 `setName`，字面字符串 `Adela Novak` 可以被传递给 `setName`，再传给 `w` 内部 `string` 的赋值运算符。`w` 的 `name` 的数据成员通过字面字符串直接赋值，没有临时 `string` 对象被创建，只会有调用接受 `const char*` 指针的 `string` 赋值运算符的开销。
但是，`setName` 重载版本，会有一个临时 `string` 对象被创建，`setName` 形参绑定到这个对象，然后这个临时 `string` 移动到 `w` 的数据成员中。一次 `setName` 的调用会包括 `string` 构造函数调用，`string` 赋值运算符调用，`string` 析构函数调用。这比调用接受 `const char*` 指针的`string` 赋值运算符开销昂贵许多。
但是，关于对左值和右值的重载函数最重要的问题不是源代码的数量，也不是代码的运行时性能。而是设计的可扩展性差。`Widget::setName` 有一个形参，因此需要两种重载实现，但是对于有更多形参的函数，每个都可能是左值或右值，重载函数的数量几何式增长：n个参数的话，就要实现2n种重载。这还不是最坏的。有的函数——实际上是函数模板——接受**无限制**个数的参数，每个参数都可以是左值或者右值：
```cpp
template<class T, class... Args>                //来自C++11标准
shared_ptr<T> make_shared(Args&&... args);

template<class T, class... Args>                //来自C++14标准
unique_ptr<T> make_unique(Args&&... args);
```
对于这种函数，对于左值和右值分别重载就不能考虑了：通用引用是仅有的实现方案。对这种函数，只能使用 `std::forward` 传递通用引用形参给其他函数。
### Last
在某些情况，可能需要在一个函数中多次使用绑定到右值引用或者通用引用的对象，并且确保在完成其他操作前，这个对象不会被移动。这时，只想在最后一次使用时，对右值引用使用 `move` 或者对通用引用使用 `forward`。比如：
```cpp
template<typename T>
void setSignText(T&& text)                  //text是通用引用
{
  sign.setText(text);                       //使用text但是不改变它
  
  auto now = 
      chrono::system_clock::now();     //获取现在的时间
  
  signHistory.add(now, 
                  forward<T>(text));   //有条件的转换为右值
}
```
这里，想要确保 `text` 的值不会被 `sign.setText` 改变，因为想要在 `signHistory.add` 中继续使用，因此 `forward` 只在最后使用。
对于 `move`，同样的思路（即最后一次用右值引用的时候再调用 `move`），但是需要注意，在有些稀少的情况下，需要调用 `move_if_noexcept` 代替 `move`。要了解何时以及为什么，参考[Item14](Noexcept.md)。
如果在**按值**返回的函数中，返回值绑定到右值引用或者通用引用上，需要对返回的引用使用`move`或者`forward`。
### ReturnValue
**对返回值绑定到右值引用的情况**，考虑两个矩阵相加的 `operator+` 函数，左侧的矩阵为右值（可以被用来保存求值之后的和）：
```cpp
Matrix                              //按值返回
operator+(Matrix&& lhs, const Matrix& rhs)
{
    lhs += rhs;
    return move(lhs);	        //移动lhs到返回值中
}
```
通过在 `return` 语句中将 `lhs` 转换为右值，`lhs` 可以移动到返回值的内存位置。如果省略 `move` 调用：
```cpp
Matrix                              //同之前一样
operator+(Matrix&& lhs, const Matrix& rhs)
{
    lhs += rhs;
    return lhs;                     //拷贝lhs到返回值中
}
```
`lhs` 是个左值的事实，会强制编译器拷贝它到返回值的内存空间。假定 `Matrix` 支持移动操作，并且比拷贝操作效率更高，在 `return` 语句中使用 `move` 的代码效率更高。
如果 `Matrix` 不支持移动操作，将其转换为右值不会变差，因为右值可以直接被 `Matrix` 的拷贝构造函数拷贝。就是这种情况，通过将 `move` 应用到按值返回的函数中要返回的右值引用上，不会损失什么，还可能获得收益。
**对返回值绑定到通用引用的情况**，考虑函数模板 `reduceAndCopy` 收到一个未规约对象 `Fraction`，将其规约，并返回一个规约后的副本。如果原始对象是右值，可以将其移动到返回值中，但是如果原始对象是左值，必须创建副本，因此如下代码：
```cpp
template<typename T>
Fraction                            //按值返回
reduceAndCopy(T&& frac)             //通用引用的形参
{
    frac.reduce();
    return forward<T>(frac);		//移动右值，或拷贝左值到返回值中
}
```
如果 `forward` 被忽略，`frac` 就被无条件复制到 `reduceAndCopy` 的返回值内存空间。
综上，在**按值**返回的函数中，返回值绑定到右值引用或者通用引用上，如果这个值需要保留，则绑定到通用引用并使用 `forward`，否则使用绑定到右值引用并使用 `move`。
## NRVO
`RVO` 的应用区分为命名的和未命名的（即临时的）局部对象，对命名对象的应用称为 `NRVO`，如果满足以下条件，编译器可能会在按值返回的函数中消除对局部对象的拷贝或移动：
- 局部对象与函数返回值的类型相同。
- 局部对象就是要返回的东西，或作为 `return` 语句的一部分而创建的临时对象
- 返回函数形参、对象的数据成员不会触发 `(N)RVO`。
- 通过条件运算符返回不会触发 `(N)RVO`。
通过下述表达式，产生一个 `Rational` 临时对象，而函数复制此临时对象，当做返回值。该表达式调用过程中，需要为函数内的临时对象的构造和析构，函数返回对象的构造和析构付出代价：
```c++
// 返回对象：一个有效率而且正确的做法。
inline const Rational operator*(const Rational& lhs, const Rational& rhs) {
	return Rational(lhs.numerator() * rhs.numerator(), lhs.denomínator() * rhs.denominator());
}
```
此时将触发 `(N)RVO`，将 `return` 表达式所定义的对象构造于变量 `c` 的内存内，从而消除 `operator*` 内的临时对象。如果编译器这么做，调用 `operator*` 时的临时对象总成本为 0，也就是说没有任何临时对象需要被产生出来。只需付出一个用以产生变量 `c` 的 `constructor` 代价。无法做得比这更好，因为 `c` 是一个命名对象，而命名对象是不能被消除的。
```c++
Rational a = 10;    // 调用端
Rational b(1, 2);
Rational c = a * b; // 构造于变量c的内存
```
而对于下述代码：
```cpp
Widget makeWidget() {                // makeWidget的拷贝版本
    Widget w;                        // 局部对象配置w
    return w;                        // 拷贝w到返回值中
}
```
如果想要优化代码，把拷贝变为移动：
```cpp
Widget makeWidget() {                // makeWidget的移动版本
    Widget w;
    return move(w);             // 移动w到返回值中（不要这样做）
}
```
此时编译器不会触发 `RVO` 消除这种移动，因为条件中规定，仅当返回值为局部对象时，才进行 `RVO`，但是 `makeWidget` 的移动版本不满足这条件，返回的已经不是局部对象 `w`，而是 `w` 的引用——`move(w)` 的结果。返回局部对象的引用不满足 `RVO` 的第二个条件，所以编译器必须移动 `w` 到函数返回值的位置。开发者试图对要返回的局部变量用 `move` 帮助编译器优化，反而限制了编译器的优化选项。
`C++` 标准关于 `RVO` 的部分表明，如果满足 `RVO` 的条件，但是编译器选择不执行拷贝消除，则返回的对象必须被视为右值。实际上，标准要求当 `RVO` 被允许时，或者实行拷贝消除，或者将`move` 隐式应用于返回的局部对象。因此，在 `makeWidget` 的“拷贝”版本中：
```cpp
Widget makeWidget() {                //同之前一样
    Widget w;
    return w;
}

// 对上述满足 RVO 的代码，或者消除拷贝，或者如下视作右值
Widget makeWidget() {
    Widget w;
    return move(w);            //把w看成右值，因为不执行拷贝消除
}
```
这种情况与按值返回函数形参的情况很像。形参没资格参与函数返回值的拷贝消除，但是如果作为返回值的话编译器会将其视作右值。结果就是，如果代码如下：
```cpp
Widget makeWidget(Widget w) {        //传值形参，与函数返回的类型相同
    return w;
}
```
编译器必须看成像下面这样写的代码：
```cpp
Widget makeWidget(Widget w) {
    return move(w);
}
```
这意味着，如果对从按值返回的函数返回来的局部对象使用 `move`，并不能帮助编译器，如果不能实行拷贝消除的话，他们必须把局部对象看做右值，而是阻碍其执行优化选项 `RVO`。在某些情况下，将 `move` 应用于局部变量可能是一件合理的事（即，把一个变量传给函数，并且知道不会再用这个变量），但是满足 `RVO` 的 `return` 语句或者返回一个传值形参并不在此列。
对比一下 RVO 的优化：
```c++
class Obj {
    public:
    Obj() { cout << "Obj()" << endl; }
    Obj(const Obj&) { cout << "Obj(const Obj&)" << endl; }
    Obj(Obj&&) { cout << "Obj(Obj&&)" << endl; }
};
Obj simple() {
    Obj obj;
    return obj; // 简单返回对象；一般有 NRVO，只有一次构造析构
}
Obj simple_with_move() {
    Obj obj; 
    return move(obj); // move 会禁止 NRVO，一次构造析构，一次移动构造的调用，否则只会有一次构造析构
}

Obj complicated(int n) {
    Obj obj1; // 满足RVO的条件，但是编译器选择不执行拷贝消除（因为有分支）
    Obj obj2;
    if (n % 2 == 0) return obj1;
    else return obj2; //返回值被视作右值，除了两次构造析构，还有一次分支的移动构造的调用
}
int main() {
    auto obj1 = simple();
    auto obj2 = simple_with_move();
    auto obj3 = complicated(42);
}
```
## Perfect Forwarding Failure Cases
**完美转发**（*perfect forwarding*）意味着不仅转发对象，还转发显著的特征：它们的类型，是左值还是右值，是`const`还是`volatile`。结合到会处理引用形参，这意味着将使用通用引用，因为通用引用形参被传入实参时才确定是左值还是右值。
假定有一些函数`f`，然后想编写一个转发给它的函数（事实上是一个函数模板）。需要的核心看起来像是这样：
```cpp
template<typename T>
void fwd(T&& param) {            //接受任何实参
    f(forward<T>(param));  //转发给f
}
```
从本质上说，转发函数是通用的。例如`fwd`模板，接受任何类型的实参，并转发得到的任何东西。这种通用性的逻辑扩展是，转发函数不仅是模板，而且是可变模板，因此可以接受任何数量的实参。`fwd`的可变形式如下：
```cpp
template<typename... Ts>
void fwd(Ts&&... params) {           //接受任何实参
    f(forward<Ts>(params)...); //转发给f
}
```
给定目标函数`f`和转发函数`fwd`，如果`f`使用某特定实参会执行某个操作，但是`fwd`使用相同的实参会执行不同的操作，完美转发就会失败。
```cpp
f( expression );        //调用f执行某个操作
fwd( expression );		//但调用fwd执行另一个操作，则fwd不能完美转发expression给f
```
导致这种失败的实参种类有很多。
### Curly Bracket Initializer
假定`f`这样声明：
```cpp
void f(const vector<int>& v);
```
在这个例子中，用花括号初始化调用`f`通过编译，
```cpp
f({ 1, 2, 3 });         //可以，“{1, 2, 3}”隐式转换为vector<int>
```
但是传递相同的列表初始化给fwd不能编译
```cpp
fwd({ 1, 2, 3 });       //错误！不能编译
```
这是因为这是完美转发失效的一种情况。
所有这种错误有相同的原因。在对`f`的直接调用（例如`f({ 1, 2, 3 })`），编译器看看调用地传入的实参，看看`f`声明的形参类型。它们把调用地的实参和声明的实参进行比较，看看是否匹配，并且必要时执行隐式转换操作使得调用成功。在上面的例子中，从`{ 1, 2, 3 }`生成了临时`vector<int>`对象，因此`f`的形参`v`会绑定到`vector<int>`对象上。
当通过调用函数模板`fwd`间接调用`f`时，编译器不再把调用地传入给`fwd`的实参和`f`的声明中形参类型进行比较。而是**推导**传入给`fwd`的实参类型，然后比较推导后的实参类型和`f`的形参声明类型。当下面情况任何一个发生时，完美转发就会失败：
- **编译器不能推导出`fwd`的一个或者多个形参类型**。这种情况下代码无法编译。
- **编译器推导“错”了`fwd`的一个或者多个形参类型**。在这里，“错误”可能意味着`fwd`的实例将无法使用推导出的类型进行编译，但是也可能意味着使用`fwd`的推导类型调用`f`，与用传给`fwd`的实参直接调用`f`表现出不一致的行为。这种不同行为的原因可能是因为`f`是个重载函数的名字，并且由于是“不正确的”类型推导，在`fwd`内部调用的`f`重载和直接调用的`f`重载不一样。
在上面的`fwd({ 1, 2, 3 })`例子中，问题在于，将花括号初始化传递给未声明为`initializer_list`的函数模板形参，编译器不准在对`fwd`的调用中推导表达式`{ 1, 2, 3 }`的类型，因为`fwd`的形参没有声明为`initializer_list`。
有趣的是，使用花括号初始化的`auto`的变量的类型推导是成功的。这种变量被视为`initializer_list`对象，在转发函数应推导出类型为`initializer_list`的情况，这提供了一种简单的解决方法——使用`auto`声明一个局部变量，然后将局部变量传进转发函数：
```cpp
auto il = { 1, 2, 3 };  //il的类型被推导为initializer_list<int>
fwd(il);                //可以，完美转发il给f
```
###  '0' Or 'NULL' As A Null Pointer
当你试图传递`0`或者`NULL`作为空指针给模板时，类型推导会出错，会把传来的实参推导为一个整型类型（典型情况为`int`）而不是指针类型。结果就是不管是`0`还是`NULL`都不能作为空指针被完美转发。解决方法非常简单，传一个`nullptr`而不是`0`或者`NULL`。
### Only Declared Integer Static Const Data Members
通常，无需在类中定义整型`static const`数据成员；声明就可以了。这是因为编译器会对此类成员实行**常量传播**（*const propagation*），因此消除了保留内存的需要。比如，考虑下面的代码：
```cpp
class Widget {
public:
    static const size_t MinVals = 28;  //MinVal的声明
};
…                                           //没有MinVals定义

vector<int> widgetData;
widgetData.reserve(Widget::MinVals);        //使用MinVals
```
这里，使用`MinVals`来确定`widgetData`的初始容量，即使`MinVals`缺少定义。编译器通过将值28放入所有提到`MinVals`的位置来补充缺少的定义（就像它们被要求的那样）。没有为`MinVals`的值留存储空间是没有问题的。如果要使用`MinVals`的地址（例如，有人创建了指向`MinVals`的指针），则`MinVals`需要存储（这样指针才有可指向的东西），尽管上面的代码仍然可以编译，但是链接时就会报错，直到为`MinVals`提供定义。
按照这个思路，想象下`f`（`fwd`要转发实参给它的那个函数）这样声明：
```cpp
void f(size_t val);
```
使用`MinVals`调用`f`是可以的，因为编译器直接将值28代替`MinVals`：
```cpp
f(Widget::MinVals);         //可以，视为“f(28)”
```
不过如果我们尝试通过`fwd`调用`f`，事情不会进展那么顺利：
```cpp
fwd(Widget::MinVals);       //错误！不应该链接
```
代码可以编译，但是不应该链接。如果这让你想到使用`MinVals`地址会发生的事，确实，底层的问题是一样的。
尽管代码中没有使用`MinVals`的地址，但是`fwd`的形参是通用引用，而引用，在编译器生成的代码中，通常被视作指针。在程序的二进制底层代码中（以及硬件中）指针和引用是一样的。在这个水平上，引用只是可以自动解引用的指针。在这种情况下，通过引用传递`MinVals`实际上与通过指针传递`MinVals`是一样的，因此，必须有内存使得指针可以指向。因此通过引用传递的整型`static const`数据成员，通常需要定义它们。
### Overloaded Function and Template Name
假定我们的函数`f`（我们想通过`fwd`完美转发实参给的那个函数）可以通过向其传递执行某些功能的函数来自定义其行为。假设这个函数接受和返回值都是`int`，`f`声明就像这样：
```cpp
void f(int (*pf)(int));             //pf = “process function”
```
值得注意的是，也可以使用更简单的非指针语法声明。这种声明就像这样，含义与上面是一样的：
```cpp
void f(int pf(int));                //与上面定义相同的f
```
无论哪种写法都可，现在假设我们有了一个重载函数，`processVal`：
```cpp
int processVal(int value);
int processVal(int value, int priority);
```
我们可以传递`processVal`给`f`，
```cpp
f(processVal);                      //可以
```
但是我们会发现一些吃惊的事情。`f`要求一个函数指针作为实参，但是`processVal`不是一个函数指针或者一个函数，它是同名的两个不同函数。但是，编译器可以知道它需要哪个：匹配上`f`的形参类型的那个。因此选择了仅带有一个`int`的`processVal`地址传递给`f`。
工作的基本机制是`f`的声明让编译器识别出哪个是需要的`processVal`。但是，`fwd`是一个函数模板，没有它可接受的类型的信息，使得编译器不可能决定出哪个函数应被传递：
```cpp
fwd(processVal);                    //错误！那个processVal？
```
单用`processVal`是没有类型信息的，所以就不能类型推导，完美转发失败。
如果我们试图使用函数模板而不是（或者也加上）重载函数的名字，同样的问题也会发生。一个函数模板不代表单独一个函数，它表示一个函数族：
```cpp
template<typename T>
T workOnVal(T param)                //处理值的模板
{ … }

fwd(workOnVal);                     //错误！哪个workOnVal实例？
```
要让像`fwd`的完美转发函数接受一个重载函数名或者模板名，方法是指定要转发的那个重载或者实例。比如，你可以创造与`f`相同形参类型的函数指针，通过`processVal`或者`workOnVal`实例化这个函数指针（这可以引导选择正确版本的`processVal`或者产生正确的`workOnVal`实例），然后传递指针给`fwd`：
```cpp
using ProcessFuncType =                         //写个类型定义；见条款9
    int (*)(int);

ProcessFuncType processValPtr = processVal;     //指定所需的processVal签名

fwd(processValPtr);                             //可以
fwd(static_cast<ProcessFuncType>(workOnVal));   //也可以
```
当然，这要求你知道`fwd`转发的函数指针的类型。没有理由去假定完美转发函数会记录着这些东西。毕竟，完美转发被设计为接受任何内容，所以如果没有文档告诉你要传递什么，你又从何而知这些东西呢？
### 位域
完美转发最后一种失败的情况是函数实参使用位域这种类型。为了更直观的解释，IPv4的头部有如下模型：（这假定的是位域是按从最低有效位（*least significant bit*，lsb）到最高有效位（*most significant bit*，msb）布局的。C++不保证这一点，但是编译器经常提供一种机制，允许程序员控制位域布局。）
```cpp
struct IPv4Header {
    uint32_t version:4,
                  IHL:4,
                  DSCP:6,
                  ECN:2,
                  totalLength:16;
    …
};
```
如果声明我们的函数`f`（转发函数`fwd`的目标）为接收一个`size_t`的形参，则使用`IPv4Header`对象的`totalLength`字段进行调用没有问题：
```cpp
void f(size_t sz);         //要调用的函数

IPv4Header h;
…
f(h.totalLength);               //可以
```
如果通过`fwd`转发`h.totalLength`给`f`呢，那就是一个不同的情况了：
```cpp
fwd(h.totalLength);             //错误！
```
问题在于`fwd`的形参是引用，而`h.totalLength`是non-`const`位域。听起来并不是那么糟糕，但是C++标准非常清楚地谴责了这种组合：non-`const`引用不应该绑定到位域。禁止的理由很充分。位域可能包含了机器字的任意部分（比如32位`int`的3-5位），但是这些东西无法直接寻址。我之前提到了在硬件层面引用和指针是一样的，所以没有办法创建一个指向任意*bit*的指针（C++规定你可以指向的最小单位是`char`），同样没有办法绑定引用到任意*bit*上。
一旦意识到接收位域实参的函数都将接收位域的**副本**，就可以轻松解决位域不能完美转发的问题。毕竟，没有函数可以绑定引用到位域，也没有函数可以接受指向位域的指针，因为不存在这种指针。位域可以传给的形参种类只有按值传递的形参，有趣的是，还有reference-to-`const`。在传值形参的情况中，被调用的函数接受了一个位域的副本；在传reference-to-`const`形参的情况中，标准要求这个引用实际上绑定到存放位域值的副本对象，这个对象是某种整型（比如`int`）。reference-to-`const`不直接绑定到位域，而是绑定位域值拷贝到的一个普通对象。
传递位域给完美转发的关键就是利用传给的函数接受的是一个副本的事实。你可以自己创建副本然后利用副本调用完美转发。在`IPv4Header`的例子中，可以如下写法：
```cpp
//拷贝位域值；参看条款6了解关于初始化形式的信息
auto length = static_cast<uint16_t>(h.totalLength);

fwd(length);                    //转发这个副本
```
## Assume
我们需要假定移动操作不存在，成本高，未被使用，因为很多类型不支持移动操作。即使显式支持移动操作，结果可能也没有你希望的那么好。比如，所有 `C++11` 的标准库容器都支持了移动操作，但是认为移动所有容器的开销都非常小是个错误。对于某些容器来说，压根就不存在开销小的方式来移动它所包含的内容。对另一些容器来说，容器的开销真正小的移动操作会有些容器元素不能满足的注意条件。
考虑一下 `array`，这是 `C++11` 中的新容器。与其他标准容器将内容存储在堆内存不同。存储具体数据在堆内存的容器，本身只保存了指向堆内存中容器内容的指针。这个指针的存在使得在常数时间移动整个容器成为可能，只需要从源容器拷贝保存指向容器内容的指针到目标容器，然后将源指针置为空指针就可以了：
```cpp
vector<Widget> vm1;

//把数据存进vw1
…

//把vw1移动到vw2。以常数时间运行。只有vw1和vw2中的指针被改变
auto vm2 = move(vm1);
```
![item29_fig1](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/item29_fig1.png)
但 `array` 没有这种指针实现，数据就保存在 `array` 对象中：
```cpp
array<Widget, 10000> aw1;

//把数据存进aw1
…

//把aw1移动到aw2。以线性时间运行。aw1中所有元素被移动到aw2
auto aw2 = move(aw1);
```
![item29_fig2](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/item29_fig2.png)
`aw1` 中的元素被**移动**到了 `aw2` 中。假定 `Widget` 类的移动操作比复制操作快，移动 `Widget` 的 `array` 就比复制要快。所以 `array` 确实支持移动操作。但是使用 `array` 的移动操作还是复制操作都将花费线性时间的开销，因为每个容器中的元素终归需要拷贝或移动一次，这与移动一个容器就像操作几个指针一样方便的含义相去甚远。
另一方面，`string` 提供了常数时间的移动操作和线性时间的复制操作。这听起来移动比复制快多了，但是可能不一定。许多字符串的实现采用了小字符串优化（*small string optimization*，SSO）。“小”字符串（比如长度小于15个字符的）存储在了 `string` 的缓冲区中，并没有存储在堆内存，移动这种存储的字符串并不必复制操作更快。`SSO` 的动机是大量证据表明，短字符串是大量应用使用的习惯。使用内存缓冲区存储而不分配堆内存空间，是为了更好的效率。然而这种内存管理的效率导致移动的效率并不必复制操作高。
即使对于支持快速移动操作的类型，某些看似可靠的移动操作最终也会导致复制。标准库中的某些容器操作提供了强大的异常安全保证，确保依赖那些保证的 C++98 的代码在升级到 `C++11` 且仅当移动操作不会抛出异常，从而可能替换操作时，不会不可运行。结果就是，即使类提供了更具效率的移动操作，而且即使移动操作更合适（比如源对象是右值），编译器仍可能被迫使用复制操作，因为移动操作没有声明 `noexcept`。
因此，存在几种情况，`C++11` 的移动语义并无优势：
- **没有移动操作**：要移动的对象没有提供移动操作，所以移动的写法也会变成复制操作。
- **移动不会更快**：要移动的对象提供的移动操作并不比复制速度更快。
- **移动不可用**：进行移动的上下文要求移动操作不会抛出异常，但是该操作没有被声明为 `noexcept`。
- **源对象是左值**：除了极少数的情况外（例如[[MoveSemantics#MoveOrForward]]，只有右值可以作为移动操作的来源。
