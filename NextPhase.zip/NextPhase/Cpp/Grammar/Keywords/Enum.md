# Enum
`enum` 提供创建符号常量的方式，这种方式可以代替 `const`。它允许定义新类型，但必须按严格的限制进行。
和类一样，每个枚举类型都定义一种新的类型，枚举属于字面值常量类型。可以在任何需要常量表达式的地方使用枚举成员。如：
- 定义枚举类型的 `constexpr `变量。
- 将枚举类型对象作为 `switch` 语句的表达式，而将枚举值作为` case` 标签。
- 将枚举类型作为非类型模板形参使用。
- 在类的定义中初始化枚举类型的静态数据成员。
`enum` 行为更像 `#define`：
- 取 `const` 地址合法，但取 `enum`，`#define` 是不合法的
- `enum` 和 `#define` 绝不会导致非必要的内存分配，但编译器可能会为 `const` 设定另外的存储空间。
## 初始化
```c++
enum spectrum {red, blue, violet, indigo};
```
`spectrum` 是枚举类型的名称，若只作为常量使用则可省略。若枚举类型的名称被省略，则只能在定义该枚举时一同定义它的对象。默认情况下，若没有显式提供初始值，则枚举名的枚举值从 0 开始，依次加 1，也可以直接为枚举成员指定特定的值，但必须为常量表达式。
初始化枚举对象或者给枚举对象赋值时，**必须使用该类型的一个枚举成员或者该类型的另一个对象**。即使某个整型值恰好与枚举成员的值相等，也不能用其初始化枚举对象。此外，**不限定作用域的枚举类型对象或枚举成员能自动转换成整型或浮点类型，但限定作用域的枚举类型是强类型，不能进行隐式转换**。
## 限域枚举
#cpp11
对于未限域 `enum`，枚举成员的作用域与枚举类型本身的作用域相同，枚举名的名字属于包含这个 `enum` 的作用域，这意味着作用域内不能含有相同名字的其他东西：
```cpp
enum Color { black, white, red };   //black, white, red在Color所在的作用域
auto white = false;                 //错误! white早已在这个作用域中声明
color eyes = black;                 //没问题，域内有black
```
对于 C++11 中的限域枚举 `enum class`，枚举成员的名字遵循常规作用域规则，并且在枚举类型的作用域外是不可访问的，不会导致枚举名泄漏：
```cpp
enum class Color { black, white, red }; //black, white, red限制在Color域内
auto white = false;                     //没问题，域内没有其他white
Color c = white;                        //错误，域中没有枚举名叫white
Color c = Color::white;                 //没问题
auto c = Color::white;                  //也没问题
```
## 强类型
在限域 `enum` 的作用域中，枚举名是强类型，而未限域 `enum` 中的枚举名是弱类型，会隐式转换为整型或浮点型。因此下面这种歪曲语义的做法也是完全有效的：
```cpp
// func返回x的质因子
std::vector<std::size_t> primeFactors(std::size_t x);              

enum Color { black, white, red };       // 未限域enum
Color c = red;
if (c < 14.5) { // Color与double比较 (!)
    auto factors = primeFactors(c); // 计算一个Color的质因子(!)
}
```
因此需要使用限域 `enum`，不存在任何隐式转换可以将枚举名转化为任何其他类型：
```cpp
enum class Color { black, white, red }; //Color现在是限域enum

Color c = Color::red;                   //和之前一样，只是多了一个域修饰符
if (c < 14.5) { //错误！不能比较Color和double
    auto factors = primeFactors(c); //错误！不能向参数为std::size_t的函数传递Color参数                      
}

if (static_cast<double>(c) < 14.5) {    //奇怪的代码，但是有效
    auto factors = primeFactors(static_cast<std::size_t>(c)); // 能通过编译
}
```
## 底层类型与前置声明
在 C++11 中，限域与非限域 `enum` 都可以被前置声明，也就是说，可以不指定枚举名直接声明，但是非限域 `enum` 只有在指定底层类型后才可以被前置声明。
```cpp
enum Color;         //错误！
enum class Color;   //没问题
enum Color: std::uint8_t;   //非限域enum前向声明底层类型为std::uint8_t
```
这是因为在 C++ 中所有的 `enum` 都有一个由编译器决定的整型的底层类型，例如
```cpp
// 编译器可能选择 char 作为底层类型，因为这里只需要表示三个值
enum Color { black, white, red }; 

// 编译器会选择一个比 char 大的整型类型来表示 Status
enum Status { good = 0,
              failed = 1,
              incomplete = 100,
              corrupt = 200,
              indeterminate = 0xFFFFFFFF
            };
```
限域 `enum` 的底层类型总是已知的，而对于非限域 `enum`，可以指定它，从而使得编译器在使用它之前需要知晓该 `enum` 的大小。默认情况下，限域枚举的底层类型是 `int`，非限域`enum`没有默认底层类型：
```cpp
enum class Status;                  //底层类型是int
```
如果默认的 `int` 不适用，可以重写它：
```cpp
enum class Status: std::uint32_t;   //Status的底层类型是std::uint32_t
```
不管怎样，编译器都知道限域 `enum` 中的枚举名占用多少字节。
要为非限域 `enum` 指定底层类型，可以同上，从而可以前向声明：
```cpp
enum Color: std::uint8_t;   //非限域enum前向声明底层类型为std::uint8_t
```
底层类型说明也可以放到 `enum` 定义处：
```cpp
enum class Status: std::uint32_t { good = 0, failed = 1 };
```
为高效使用内存，编译器通常在确保能包含所有枚举值的前提下为 `enum` 选择一个最小的底层类型。在一些情况下，编译器将会优化速度，舍弃大小，这种情况下它可能不会选择最小的底层类型，而是选择对优化大小有帮助的类型。为此，**C++98 只支持 `enum` 定义来列出所有枚举名，`enum `声明是不被允许的，这使得编译器能在使用之前为每一个 `enum` 选择一个底层类型**，在 C++11 中可以指定底层类型后，才可以声明非限域 `enum`。
不能前置声明 `enum` 最大的缺点是它可能增加编译依赖，`Status` 这种 `enum` 很有可能用于整个系统，因此系统中每个包含这个头文件的组件都会依赖它。如果引入一个新状态值，那么可能整个系统都得重新编译，即使只有一个子系统——或者只有一个函数——使用了新添加的枚举名。
```cpp
enum Status { good = 0,
              failed = 1,
              incomplete = 100,
              corrupt = 200,
              audited = 500,
              indeterminate = 0xFFFFFFFF
            };
```
C++11 中的前置声明 `enum` 可以解决这个问题。比如这里有一个完全有效的限域 `enum` 声明和一个以该限域 `enum` 作为形参的函数声明：
```cpp
enum class Status;                  //前置声明
void continueProcessing(Status s);  //使用前置声明enum
```
即使 `Status` 的定义发生改变，包含这些声明的头文件也不需要重新编译。而且如果 `Status` 有改动（比如添加一个 `audited` 枚举名），`continueProcessing` 的行为不受影响（比如因为`continueProcessing` 没有使用这个新添加的 `audited`），`continueProcessing`也不需要重新编译。
## 使用非限域的情况
限域 `enum` 避免命名空间污染而且不接受隐式类型转换，但至少有一种情况下非限域 `enum` 是很有用的，那就是牵扯到 C++11 的 `std::tuple` 的时候。比如在社交网站中，假设有一个 `tuple`保存用户的名字，email 地址，声望值：
```cpp
using UserInfo =                //类型别名，参见Item9
    std::tuple<std::string,     //名字
               std::string,     //email地址
               std::size_t> ;   //声望
```
虽然注释说明 `tuple` 各个字段对应的意思，但当在另一文件遇到下面的代码那之前的注释就不是那么有用了：
```cpp
UserInfo uInfo;                 //tuple对象
auto val = std::get<1>(uInfo);	//获取第一个字段
```
作为一个程序员，你有很多工作要持续跟进。你应该记住第一个字段代表用户的email地址吗？我认为不。可以使用非限域 `enum` 将名字和字段编号关联起来以避免上述需求：
```cpp
enum UserInfoFields { uiName, uiEmail, uiReputation };
UserInfo uInfo;                         // 同之前一样
auto val = std::get<uiEmail>(uInfo);    // 获取用户email字段的值
```
之所以它能正常工作是因为 `UserInfoFields` 中的枚举名隐式转换成 `std::size_t`，其中`std::size_t` 是 `std::get` 模板实参所需的。
对应的限域 `enum` 版本就很啰嗦：
```cpp
enum class UserInfoFields { uiName, uiEmail, uiReputation };
UserInfo uInfo;                         // 同之前一样
auto val =
    std::get<static_cast<std::size_t>(UserInfoFields::uiEmail)> (uInfo);
```
为避免这种冗长的表示，可以写一个函数传入枚举名并返回对应的 `std::size_t` 值，但`std::get` 是一个需要 `std::size_t` 模板实参的模板函数，因此将枚举名变换为`std::size_t` 值的函数必须**在编译期**产生这个结果，那必须是一个 `constexpr` 函数模板，因为它应该能用于任何 `enum`，如果想让它更一般化，还要泛化它的返回类型。
较之于返回 `std::size_t`，更应该返回枚举的底层类型。这可以通过 `std::underlying_type` 这个 *type trait* 获得，再加上 `noexcept` 修饰，因为知道它肯定不会产生异常。根据上述分析最终得到的 `toUType` 函数模板在编译期接受任意枚举名并返回它的值：
```cpp
template<typename E>
constexpr typename std::underlying_type<E>::type
    toUType(E enumerator) noexcept
{
    return
        static_cast<typename
                    std::underlying_type<E>::type>(enumerator);
}

template<typename E>                //C++14
constexpr std::underlying_type_t<E>
    toUType(E enumerator) noexcept
{
    return static_cast<std::underlying_type_t<E>>(enumerator);
}

template<typename E>                //C++14
constexpr auto
    toUType(E enumerator) noexcept
{
    return static_cast<std::underlying_type_t<E>>(enumerator);
}
```
`toUType` 现在允许这样访问 `tuple` 的字段：
```cpp
auto val = std::get<toUType(UserInfoFields::uiEmail)>(uInfo);
```
这仍然比使用非限域 `enum` 要写更多的代码，但同时它也避免命名空间污染，防止不经意间使用隐式转换。
**记住**
+ C++98的`enum`即非限域`enum`。
+ 限域`enum`的枚举名仅在`enum`内可见。要转换为其它类型只能使用*cast*。
+ 非限域/限域`enum`都支持底层类型说明语法，限域`enum`底层类型默认是`int`。非限域`enum`没有默认底层类型。
+ 限域`enum`总是可以前置声明。非限域`enum`仅当指定它们的底层类型时才能前置。
