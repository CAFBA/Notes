# CastOperator
如果想为一个不涉及继承机制的类型执行转型动作，可使用 `static_cast`，要改变常量性，则必须使用 `const_cast`，涉及继承机制的类型执行转型动作最好执行 `dynamic_cast`。
## const_cast
`const_cast` 运算符用于执行只有一种用途的类型转换，改变表达式中的常量性或变易性。提供该运算符的原因是，有时候可能需要这样一个值，它在大多数时候是常量，而有时又是可以修改的。在这种情况下，可以将这个值声明为 `const`，并在需要修改它的时候，使用 `const_cast`。
```c++
class Widget{...};
class SpecialWidget: public Widget{...}; 
void update(SpecialWidget *psw);

SpecialWidget sw; // sw 是个 non-const 对象
const SpecialWidget& csw = sw; // csw 是一个代表sw的reference，并视之为一个const对象

// 不能将const SpecialWidget*传给一个需要Special Widget*的函数
update(&csw);     

// &csw的常量性被去除，因此，csw（亦即sw）在此函数中可被更改
update (const_cast<SpecialWidget*>(&csw));

// 情况同上，但使用的是较难辨识的c旧式转型语法
update((SpecialWidget*)&csw);

Widget *pw = new SpecialWidget; 

// 错误！pw的类型是widget*，但update需要的却是SpecialWidget*
update(pw);

// const_cast 只能用来影响常量性或变易性，无法进行继承体系的向下转型动作
update(const_cast<SpecialWidget*>(pw));
```
`const_cast` 通过去除常量性，可以修改指向 `const` 的指针，但修改 `const` 值的结果是不确定的。如果对象本身不是一个常量，使用强制类型转换获得写权限是合法的行为。然而如果对象是一个常量，再使用 `const_cast` 执行写操作就会产生未定义的后果。
```c++
int a = 10;
cout << "a = " << a << endl;

// 指向const的指针
const int *p1 = &a;
// *p1 = 20;
// 去除常量性对其修改
int *p2 = const_cast<int*>(p1);
*p2 = 20;
cout << "a = " << a << endl; 
```
## static_cast
`static_cast` 用来强迫隐式转换，可以将 `non-const` 对象转为 `const` 对象，也可以将 `void*` 指针转为 `typed` 指针，将 `pointer-to-base` 转为 `pointer-to-derived`，但无法将 `const` 转为 `non-const`，这个只有 `const_cast` 才办得到。
`static_cast` 形式如下，仅当 `type_name` 可被隐式转换为 `expression` 所属的类型或`expression` 可被隐式转换为 `type_name` 所属的类型时，转换才是合法的，否则将出错。
```c++
// static_cast<type_name>(expression) 

int firstNumber, secondNumber; 
double result = ((double)firstNumber)/secondNumber; 
double result = static_cast<double>(firstNumber)/secondNumber; 
```
还可以使用 `static_cast` 执行显式转换，这是用户定义的构造函数或转换例程允许的。比如，如果类 `A` 有一个接受 `B` 类对象的构造函数，则可以使用 `static_cast` 将 `B` 对象转换为 `A` 对象。但是，在大多数情况下，需要这种行为时，编译器会自动执行转换。
因为在派生类对象中含有与其基类对应的组成部分，所以能把派生类的对象当作基类对象来使用，也能将基类的指针或引用绑定到派生类对象中的基类部分上。这种转换通常称为向上转换，编译器会隐式执行。
因为一个基类的对象可能是派生类对象的一部分，也可能不是，所以不存在从基类到派生类的隐式类型转换，即使一个基类指针或引用绑定在一个派生类对象上也不行，编译器在编译时无法确定某个特定的转换在运行时是否安全，因为编译器只能通过检查指针或引用的静态类型来判断转换是否合法。
```c++
Base b(10);
Derive d(20);
b = d; // derive->base 可以，但会发生切割
d = b; // base->derive 不可以，没有派生类部分

Base *pb = &d; // 将基类的指针或引用绑定到派生类对象，动态绑定
pb->show();   // "Base::show()"
pb->show(10); // "Base::show(int)"

Derive *pd = &b; // 不可以将派生类的指针或引用绑定到基类对象，合法内存只有基类部分，但指针类型是derive，因此就算强制向下转换，也会非法访问内存
// 默认只支持向上转换，不支持默认向下转换
```
`static_cast` 的安全性更高，编译器将拒绝执行不同数据类型的指针的静态类型转换，但如果要转换的两个指针指向的对象有继承关系，那么编译器允许静态类型转换。因此 `static_cast` 的另一个用途是在继承层次结构中执行向下强制转换，这些强制类型转换既可以使用指针也可以使用引用，但不能应用于普通对象。
但使用 `static_cast` 的强制类型转换不会执行运行时类型检查。它们允许将任何 `Base` 指针/引用转换为 `Derived` 指针/引用。即使在运行时，`Base` 实际上不是 `Derived` 也是如此。
```cpp
// 编译器允许通过 C 风格的类型转换将任意指针类型方便地转换为其他任意指针类型
Document* documentPtr { getDocument() };
char* myCharPtr { (char*)documentPtr };

// 但不允许 static_cast
Document* documentPtr { getDocument() };
char* myCharPtr { static_cast<char*>(documentPtr) }; // BUG! Won't compile

class Base{};
class Derived : public Base {};

Base* b { nullptr };
Derived* d { new Derived{} };
b = d; // Don't need a cast to go up the inheritance hierarchy.
// 前面的赋值语句向上转换使得 b 是派生类对象，因此下述强制向下转换正确进行
d = static_cast<Derived*>(b); // Need a cast to go down the hierarchy.

// the Base really isn’t a Derived at run time
Base* b { new Base{} }; 
// 运行时，b 不是派生类对象
Derived* d { static_cast<Derived*>(b) };
```
因此，如果在基类中含有一个或多个虚函数，可以使用 `dynamic_cast` 运算符执行向下强制转换将基类的指针或引用安全地转换成派生类的指针或引用，该转换的安全检查将在运行期间执行。同样，如果已知某个基类到派生类的转换是安全的，可以使用 `static_cast` 强制覆盖掉编译器的检查工作。
> 因为容器中不能保存不同类型的元素，所以不能把具有继承关系的多种类型的对象直接存储在容器中。如果想在容器中存储具有继承关系的对象，则应该存放基类的指针。当派生类对象被赋值给基类对象时，其中的派生类部分将被切掉，因此容器和存在继承关系的类型无法兼容。
## dynamic_cast
`dynamic_cast` 提供对继承层次结构中的强制转换的运行时检查，可以使用它强制转换指针或引用。`dynamic_cast` 将在运行时检查底层对象的运行时类型信息。运算符的形式如下：
```c++
dynamic_cast<type*>(e)
dynamic_cast<type&>(e)
dynamic_cast<type&&>(e)
```
其中 `type` 是一个类类型，并且该类型必须含有虚函数。在第一种形式中，`e` 必须是一个有效指针，在第二种形式中，`e` 必须是一个左值，在第三种形式中，`e` 不能是左值。在所有形式中，`e` 的类型必须符合以下条件之一：
- `e` 是 `type` 的公有派生类/公有基类。
- `e` 和 `type` 类型相同。
如果条件符合，则类型转换成功，否则转换失败。转换失败可能有两种结果：
- 如果转换目标是指针类型，则结果为空指针。
- 如果转换目标是引用类型，则抛出 `bad_cast` 异常。
> 在条件判断部分执行 `dynamic_cast` 可以确保类型转换和结果检查在同一条表达式中完成。
```cpp
Base* b;
Derived* d { new Derived{} };
b = d;
d = dynamic_cast<Derived*>(b);

Base base;
Derived derived;
Base& br { base };
try {
    Derived& dr { dynamic_cast<Derived&>(br) };
} catch (const bad_cast&) {
    cout << "Bad cast!" << endl;
}
```
可以使用 `static_cast` 或 `reinterpret_cast` 在继承层次结构上执行相同的强制转换。
与 `dynamic_cast` 的区别在于：`dynamic_cast` 执行运行时(动态)类型检查，而 `static_cast` 和 `reinterpret_cast` 则执行强制转换，即使转换的类型是错误的。
运行时的类型信息存储在对象的 `vtable` 中。因此，要使用 `dynamic_cast` 类中必须至少具有一个虚方法。如果类没有 `vtable`，尝试使用 `dynamic_cast` 会导致编译错误。
## reinterpret_cast
与 `static_cast()` 相比，`reinterpret_cast()` 的功能更强大，同时安全性也更低。可以使用它执行 C++ 类型规则中在技术上不允许的某些强制转换。比如，即使类型不相关，也可以将一种类型的引用强制转换对另一种类型的引用。同样，可以将指针类型强制转换为任何其他指针类型，即使它们与继承层次结构无关。
`void*` 类型的指针只是指向内存中的某个位置，没有类型信息与 `void*` 类型的指针相关联，因此将 `void*` 强制转换回正确类型的指针需要 `reinteipret_cast()`，而将指针强制转换为 `void*` 类型的指针可以隐式完成。
然而，并不是支持所有的类型转换。例如，可以将指针类型转换为足以存储指针表示的整型，但不能将指针转换为更小的整型或浮点型。另一个限制是，不能将函数指针转换为数据指针，反之亦然。
`reinterpret_cast` 的最常用用途是转换函数指针类型。假设有一个数组，存储的都是函数指针，有特定的类型：
```c++
typedef void (*FuncPtr)();
// FuncPtr 是个指针，指向某个函数。后者无须任何自变量，返回值为 void。

FuncPtr funcPtrArray[10]; // funcPtrArray 是个数组，内有10个FuncPtrs。
```
假设由于某种原因，希望将函数 `dosomething` 的一个指针放进 `funcPtrArray` 中，如果没有转型，不可能办到这一点，因为 `dosomething` 的类型与 `funcPtrArray` 所能接受的不同，`funcPtrArray` 内各函数指针所指函数的返回值是 `void`，但 `doSomething` 的返回值却是 `int`。
```c++
funcPtrArray[0] = &doSomething;
// 错误！类型不符

// 使用 reinterpret_cast，可以强迫编译器了解你的意图
funcPtrArray[0] = reinterpret_cast<FuncPtr>(&doSomething);
```
函数指针的转型动作，并不具移植性，`Cpp` 不保证所有的函数指针都能以此方式重新呈现，某些情况下这样的转型可能会导致不正确的结果，所以应该尽量避免将函数指针转型。
## bit_cast
#cpp20 
`bit_cast()` 是标准库中唯一的强制类型转换，其他强制转换是 C++ 语言本身的一部分。
`bit_cast()` 与 `reinterpret_cast()` 类似，但它会创建一个指定目标类型的新对象，并按位从源对象复制到此新象。它有效地将新对象的位解释为目标对象的位。`bit_cast()` 要求源对象和目标对象的大小相同，并且两者都是可复制的。
```cpp
float asFloat { 1.23f };
auto asUint { bit_cast<unsigned int>(asFloat) };
if (bit_cast<float>(asUint) == asFloat) 
    cout << "Roundtrip success." << endl;
```
`bit_cast()` 的一个用例是普通可复制类型的二进制 `I/O`。比如，可以将此类型的各个字节写入文件。当文件读回到内存时，可以使用 `bit_cast()` 正确地解释从文件中读取的字节。
> 普通可复制类型指的是组成对象的底层字节可以复制到一个数组中，当数组的数据随后被复制回对象时该对象将保持其原始值。 
## Code
如果编译器尚未支持这些新式转型动作，可以利用宏来仿真这些新语法。dynamic_cast没有什么简单方法可以模拟其行为，不过许多程序库提供一些函数用来执行继承体系下的安全转型动作。如果没有这些函数，而却必须执行这类转型，也可以使用旧式的C转型语法，但它们不可能告诉你转型是否成功。
```c++
#define static_cast(TYPE,EXPR)     ((TYPE)(EXPR)) 
#define const_cast(TYPE,EXPR)      ((TYPE)(EXPR)) 
#define reinterpret_cast(TYPE,EXPR) ((TYPE) (EXPR)) 

// 上述新语法的使用方式如下：
double result = static_cast(double, firstNumber) / secondNumber; 
update(const_cast(SpecialWidget*,&sw));
funcPtrArray[0] = reinterpret_cast(FuncPtr, &doSomething);

// 这个近似法并非执行真正的 dynamic_cast，所以它无法告诉你转型是否成功
#define dynamic_cast(TYPE,EXPR)  ((TYPE)(EXPR))
```