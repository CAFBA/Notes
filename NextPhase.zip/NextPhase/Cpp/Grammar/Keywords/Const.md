# Const
## const
在 C 中，用 `const` 修饰的变量，其本质上还是个变量，称之为常变量，只在编译期当作变量编译生成指令，在运行的时候没有用，**它不能再作为左值**，初始化后值不能被修改，但仅仅是语法上不能修改，并不意味着不能通过汇编或者通过指针修改其内存中的值。
在 C++ 中，用 `const` 修饰且被编译期可知值初始化的变量是常量，只被 `const` 修饰的依然是常变量，常量的初始化值与变量符号一一对应放在符号表中，所有出现 `const` 常量的地方，在编译期时都被符号表中的值替换。
在 C 语言中，C 编译器会为 `const` 修饰的变量分配空间，`const` 修饰的局部变量在栈上分配存储空间，全局变量在只读存储区中分配存储空间。而在 C++ 中编译器不会为 `const` 变量分配空间，只会将其对应起来存到符号表中，用到变量名的时候，直接将值替换。
但如果在编译的时候对 `const` 常量使用 `extern` 或取地址符 `&`，为兼容 C 语言，会为常量分配存储空间，但是却不会使用该存储空间中的值，这意味着依然无法通过指针来修改 `const` 修饰的变量值，编译器依然会直接替换，而不会去分配的存储空间的取值。
```c++
const int a = 20;
int array[a] = {}; // 实质是编译期常量初始化替换，不是因为 a 是常量

int b = 10;        // 变量的值在运行期才可知
const int a = b;   // 初始值不是立即数，是一个变量，因此 a 不是常量而是常变量
int array[b] = {}; // 现在就不存在替换的情况，因此会报错
```
`const` 关键字作用于其直接左侧的内容：
```cpp
int const* const ip { nullptr };
const int* const ip { nullptr }; // 等价
```
`const` 在 `*` 的左边，表示指向常量的指针，被指物是常量：
```c++
string name = "uncharted";
const string* ps1 = &name; // 指向常量的指针
*ps1 = "spiderman";        // 错误，被指物不允许修改
```
`const` 在 `*` 的右边，表示指针不能被修改，指针自身是常量，而指向的变量可以被修改：
```c++
string* const ps2 = &name;  // 指针自身是常量
*ps2 = "spiderman";         // 正确，被指物允许修改

// 引用同理
int info = 100;
int const &p = info;
int x = 200;
p = x;
```
对于复杂情况的判断，根据最右就近原则（去掉类型名）：
```c++
// non-const pointer, const data
const char* p = "kkk";

// const pointer, non-const data
char* const p = 'kkk'; 

// const pointer, const data
const char* const p = "kkk" 

const std::vector<int>::iterator iter = v.begin(); // T* const 
std::vector<int>::const_iterator iter = v.begin(); // const T*

int a = 10;
int *p = &a;  // p是指向变量a的指针
int **q = &p; // q是指向指针p的指针

const int **q; // const修饰**，即指向对象指向的对象，二级指针指向的指针，其指向的对象是常量
int *const *q; // const修饰*，即指向对象，二级指针指向的指针*q是常量
int **const q; // const修饰q，即本身
```
对于变量来说，非 `const` 变量与 `const` 变量可以互相转化，因为不会影响用于赋值的变量的常量性。但对于引用与指针类型，就需要从指向和引用后是否会改变所指对象/所引用对象的常量性角度思考。以下均讨论指向/引用类型的 `const` 性，不在乎自身的 `const` 性，因为自身的 `const` 性在类型转换中被忽略。
```c++
int x = 10;
int i = x;
const int ci = x;

int *p1 = &i;
const int *p2 = &i;  // 非const可以转换为const
int *p2 = &ci;       // 但const不可以转换为非const

const int &r = i;   // const引用绑定非const变量
int &r = ci;        // 但非const引用不能绑定const变量

// 当const与多级指针结合时，左右必须都有const
// 下面两行代码均错误
// 二级指针指向的指针，其指向的对象是常量地址
// 则*q指向的对象是常量地址，即 const int b = 10; *q = &b; 
// 而**q是常量地址内的内容，即 b
// 因此q的一级指针必须指向常量，否则相当于将常量地址赋值给非指向常量的指针
const int *&q = p1;
const int **q = &p1;
```
综上：
```c++
int* => const int*    对！非const对象可以转换为const对象
const int* => int *   错！const对象不可以转换为非const对象

int ** => const int** 错！存在内层const对象转换为非const对象的关系
const int** => int**  错！const对象不可以转换为非const对象

int** => int* const*  对！非const对象可以转换为const对象
int* const* => int**  错！const对象不可以转换为非const对象
```
# Volatile
当对象的值可能在程序的控制或检测之外被改变时（如子线程），应该将该对象声明为 `volatile`，关键字 `volatile` 的作用是告知编译器不要优化这样的对象，让编译器不要缓存多线程的共享变量。`volatile` 的确切含义与机器有关，要想让一个使用 `volatile` 的程序在移植到新机器或新编译器后仍然有效，通常需要对该程序进行一些修改。
`volatile` 的用法和 `const` 类似，都是对类型的额外修饰，二者相互之间并没有影响。`volatile` 和指针的关系类似 `const`，可以声明 `volatile` 指针、指向 `volatile` 对象的指针和指向 `volatile` 对象的 `volatile` 指针。
类可以将成员函数定义为 `volatile` 的，`volatile` 对象只能调用 `volatile` 成员函数。不能使用默认的拷贝/移动构造函数和赋值运算符初始化 `volatile` 对象或者给 `volatile` 对象赋值。默认的成员接受的形参类型是非 `volatile` 常量引用，不能把非 `volatile` 引用绑定到 `volatile` 对象上。
如果类需要拷贝、移动或赋值它的 `volatile` 对象，则必须自定义拷贝或移动操作。
```c++
class Foo {
public:
    Foo(const volatile Foo&); // copy from a volatile object
    // assign from a volatile object to a nonvolatile object
    Foo& operator=(volatile const Foo&);
    // assign from a volatile object to a volatile object
    Foo& operator=(volatile const Foo&) volatile;
    // remainder of class Foo
};
```
在 C 中由于是常变量会分配内存，因此通过指针对其进行修改是可以的：
```c
const int MAX_LEN  = 1024;

int* ptr = (int*)(&MAX_LEN);  
*ptr = 2048;                  // 在 C 中是可以直接生效的
cout << MAX_LEN << endl;      // 输出 2048
```
但在 C++ 中，对于没有 `volatile` 修饰的 `const` 常量来说，虽然用指针改了常量的值，但这个值在运行阶段根本没有用到，因为它在编译阶段就被优化掉了。
```c++
const volatile int MAX_LEN  = 1024;

int* ptr = (int*)(&MAX_LEN);
*ptr = 2048; // 若不使用volatile，是无法产生效果的，但实际是已经改了
cout << MAX_LEN << endl;      // 输出2048
```
在 C++ 里，表示变量的值可能会以难以察觉的方式被修改（比如操作系统信号、外界其他的代码），所以要禁止编译器做任何形式的优化，每次使用的时候都必须老老实实地去取值。`MAX_LEN` 虽然是个只读变量，但加上了 `volatile` 修饰，就表示它不稳定。编译器在生成二进制机器码的时候，不会再去做那些可能有副作用的优化，而是用最保守的方式去使用 MAX_LEN。
也就是说，编译器不会再把 `MAX_LEN` 替换为 1024，而是去内存里取值（而它已经通过指针被强制修改）。所以，这段代码最后输出的是 2048，而不是最初的 1024。
# constexpr
#Cpp11
从概念上来说，`constexpr`表明一个值不仅仅是常量，还是编译期可知的。但**当`constexpr`被用于函数的时候，不能假设`constexpr`函数的结果是`const`，也不能保证它们的返回值是在编译期可知的**。
所有`constexpr`对象都是`const`，但不是所有`const`对象都是`constexpr`。如果想编译器保证一个变量有一个值，这个值可以放到那些需要编译期常量的上下文的地方，需要的工具是`constexpr`而不是`const`。
```cpp
int sz;                             //non-constexpr变量
…
constexpr auto arraySize1 = sz;     //错误！sz的值在
                                    //编译期不可知
std::array<int, sz> data1;          //错误！一样的问题
constexpr auto arraySize2 = 10;     //没问题，10是
                                    //编译期可知常量
std::array<int, arraySize2> data2;  //没问题, arraySize2是constexpr
```
注意`const`不提供`constexpr`所能保证之事，因为`const`对象不需要在编译期初始化它的值，而`constexpr`被在编译期可知的值初始化。
 ```cpp
int sz;                            //和之前一样
…
const auto arraySize = sz;         //没问题，arraySize是sz的const复制
std::array<int, arraySize> data;   //错误，arraySize值在编译期不可知
 ```
## constexpr函数
涉及到`constexpr`函数时，如果实参是编译期常量，这些函数将产出编译期常量；如果实参是运行时才能知道的值，它们就将产出运行时值：
+ `constexpr`函数可以用于需求编译期常量的上下文。如果传给`constexpr`函数的实参在编译期可知，那么结果（返回值）将在编译期计算。
+ 当一个`constexpr`函数被一个或者多个编译期不可知值调用时，它就像普通函数一样，运行时计算它的结果。这意味着不需要两个函数，一个用于编译期计算，一个用于运行时计算。`constexpr`全做了。
假设需要一个方法在编译期计算3<sup>n</sup>：
```cpp
constexpr                                   //pow是绝不抛异常的
int pow(int base, int exp) noexcept         //constexpr函数
{
 …                                          //实现在下面
}
constexpr auto numConds = 5;                //条件的个数
std::array<int, pow(3, numConds)> results;  //结果有3^numConds个元素
```
`pow`前面的`constexpr`不表明`pow`返回一个`const`值，它只说了如果`base`和`exp`是编译期常量，`pow`的值可以被当成编译期常量使用。如果`base`或`exp`不是编译期常量，`pow`结果将会在运行时计算。这意味着`pow`不止可以用于像`std::array`的大小这种需要编译期常量的地方，它也可以用于运行时环境：
```cpp
auto base = readFromDB("base");     //运行时获取这些值
auto exp = readFromDB("exponent"); 
auto baseToExp = pow(base, exp);    //运行时调用pow函数
```
## 限制
因为`constexpr`函数必须能在编译期值调用的时候返回编译期结果，就必须对它的实现施加一些限制。这些限制在C++11和C++14标准间有所出入。
C++11中，`constexpr`函数的代码不超过一行语句：一个`return`。听起来很受限，但实际上有两个技巧可以扩展`constexpr`函数的表达能力。第一，使用三元运算符“`?:`”来代替`if`-`else`语句，第二，使用递归代替循环。因此`pow`可以像这样实现：
```cpp
constexpr int pow(int base, int exp) noexcept
{
    return (exp == 0 ? 1 : base * pow(base, exp - 1));
}
```
在C++14中，`constexpr`函数的限制变得非常宽松了，所以下面的函数实现成为了可能：
```cpp
constexpr int pow(int base, int exp) noexcept   //C++14
{
    auto result = 1;
    for (int i = 0; i < exp; ++i) result *= base;
    
    return result;
}
```
`constexpr`函数限制为只能获取和返回**字面值类型**，这基本上意味着那些有了值的类型能在编译期决定。**在C++11中，除了`void`外的所有内置类型，以及一些用户定义类型都可以是字面值类型，因为构造函数和其他成员函数可能是`constexpr`**：
```cpp
class Point {
public:
    constexpr Point(double xVal = 0, double yVal = 0) noexcept
    : x(xVal), y(yVal)
    {}

    constexpr double xValue() const noexcept { return x; } 
    constexpr double yValue() const noexcept { return y; }

    void setX(double newX) noexcept { x = newX; }
    void setY(double newY) noexcept { y = newY; }

private:
    double x, y;
};
```
`Point`的构造函数可被声明为`constexpr`，因为如果传入的参数在编译期可知，`Point`的数据成员也能在编译器可知。因此这样初始化的`Point`就能为`constexpr`：
```cpp
constexpr Point p1(9.4, 27.7);  //没问题，constexpr构造函数
                                //会在编译期“运行”
constexpr Point p2(28.8, 5.3);  //也没问题
```
类似的，`xValue`和`yValue`的*getter*（取值器）函数也能是`constexpr`，因为如果对一个编译期已知的`Point`对象（如一个`constexpr` `Point`对象）调用*getter*，数据成员`x`和`y`的值也能在编译期知道。这使得可以写一个`constexpr`函数，里面调用`Point`的*getter*并初始化`constexpr`的对象：
```cpp
constexpr
Point midpoint(const Point& p1, const Point& p2) noexcept
{
    return { (p1.xValue() + p2.xValue()) / 2,   //调用constexpr
             (p1.yValue() + p2.yValue()) / 2 }; //成员函数
}
constexpr auto mid = midpoint(p1, p2);      //使用constexpr函数的结果
                                            //初始化constexpr对象
```
它意味着`mid`对象通过调用构造函数，*getter*和非成员函数来进行初始化过程就能在只读内存中被创建出来！它也意味着可以在模板实参或者需要枚举名的值的表达式里面使用像`static_cast<int>(mid.xValue() * 10)`的表达式！
在C++11中，有两个限制使得`Point`的成员函数`setX`和`setY`不能声明为`constexpr`。第一，它们修改它们操作的对象的状态， 并且在C++11中，`constexpr`成员函数是隐式的`const`。第二，它们有`void`返回类型，`void`类型不是C++11中的字面值类型。这两个限制在C++14中放开了，所以C++14中`Point`的*setter*（赋值器）也能声明为`constexpr`：
```cpp
class Point {
public:
    …
    constexpr void setX(double newX) noexcept { x = newX; } //C++14
    constexpr void setY(double newY) noexcept { y = newY; } //C++14
    …
};
```
现在也能写这样的函数：
```cpp
//返回p相对于原点的镜像
constexpr Point reflection(const Point& p) noexcept
{
    Point result;                   //创建non-const Point
    result.setX(-p.xValue());       //设定它的x和y值
    result.setY(-p.yValue());
    return result;                  //返回它的副本
}
```
客户端代码可以这样写：
```cpp
constexpr Point p1(9.4, 27.7);          //和之前一样
constexpr Point p2(28.8, 5.3);
constexpr auto mid = midpoint(p1, p2);

constexpr auto reflectedMid =         //reflectedMid的值
    reflection(mid);                  //(-19.1, -16.5)在编译期可知
```
因此`constexpr`对象和`constexpr`函数可以使用的范围比non-`constexpr`对象和函数大得多。使用`constexpr`关键字可以最大化你的对象和函数可以使用的场景。
## 函数接口
`constexpr`是对象和函数接口的一部分。加上`constexpr`相当于宣称能被用在C++要求常量表达式的地方。如果声明一个对象或者函数是`constexpr`，客户端程序员就可能会在那些场景中使用它。
如果后面认为使用`constexpr`是一个错误并想移除它，可能造成大量客户端代码不能编译。尽可能的使用`constexpr`表示你需要长期坚持对某个对象或者函数施加这种限制。
## 常量表达式
常量表达式是指值不会改变并且在编译过程就能得到计算结果的表达式，字面值属于常量表达式，用常量表达式初始化的const对象也是常量表达式。算术类型、引用和指针都属于字面值类型。
一个对象（或表达式）是不是常量表达式由它的数据类型和初始值共同决定，例如
![image-20220923202453826](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220923202453826.png)
尽管指针和引用都能定义成constexpr，但它们的初始值却受到严格限制。**一个constexpr指针的初始值必须是nullptr或者0，或者是存储于某个固定地址中的对象。**
**函数体内定义的变量一般来说并非存放在固定地址中**，因此constexpr指针不能指向这样的变量。相反的，**定义于所有函数体之外的对象其地址固定不变**，能用来初始化constexpr指针。但也允许函数定义一类有效范围超出函数本身的变量，这类变量和定义在函数体之外的变量一样也有固定地址。因此，constexpr引用能绑定到这样的变量上，constexpr 指针也能指向这样的变量。
必须明确一点，在constexpr声明中如果定义了一个指针，限定符 constexpr 仅对指针有效，与指针所指的对象无关：
![image-20220923202935346](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220923202935346.png)
p和q的类型相差甚远，p是一个指向常量的指针，而q是一个常量指针。
与其他常量指针类似，constexpr指针既可以指向常量也可以指向一个非常量：
![image-20220923202959650](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220923202959650.png)
# consteval
#cpp20
`constexpr` 关键字指定函数可以在编译期执行，但不能保证一定在编译期执行。采用以下 `constexpr` 函数：
```cpp
constexpr double inchToMm(double inch) { return inch * 25.4; }
// 如果按以下方式调用，则会在需要时在编译期对函数求值
constexpr double const_inch { 6.0 };
constexpr double mm1 { inchToMm(const_inch) }; // at compile time
// 但以下调用不会
double dynamic_inch { 8.0 };
double mm2 { inchToMm(dynamic_inch) }; // at run time
```
如果确实希望保证始终在编译期对函数进行求值，则需要使用 C++20 的 `consteval` 关键字将函数 转换为立即函数。可以按照如下方式更改 `inchToMm` 函数：
```cpp
consteval double inchToMm(double inch) { return inch * 25.4; }
```
现在，对 `inchToMm` 的第一次调用仍然可以正常编译，并且可以在编译期进行求值。但是，第 二个调用现在会导致编译错误，因为无法在编译期对其进行求值。