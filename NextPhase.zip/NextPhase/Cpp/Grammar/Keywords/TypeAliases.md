# Typedef
## Struct
```c++
typedef struct tagPoint
{
    double x;
    double y;
    double z;
} Point;

Point oPoint1 = { 100，100，0 };
Point oPoint2;
```

```c++
typedef struct tagNode {
    char *pItem;
    pNode pNext;
} *pNode;
```
在上面的代码中，新结构建立的过程中遇到了 pNext 声明，其类型是 pNode。这里要特别注意的是，pNode 表示的是该结构体的新别名。于是问题出现了，**在结构体类型本身还没有建立完成的时候，编译器根本就不认识 pNode**，因为这个结构体类型的新别名还不存在，所以自然就会报错。因此，要做一些适当的调整，比如将结构体中的 pNext 声明修改成如下方式：
```c++
typedef struct tagNode {
    char *pItem;
    struct tagNode *pNext;
} *pNode;
```
在上面的代码中，同样使用 typedef 给一个还未完全声明的类型 tagNode 起了一个新别名。不过，虽然 C 语言编译器完全支持这种做法，但不推荐这样做。**建议还是使用如下规范定义方法：**
```c++
struct tagNode {
    char *pItem;
    struct tagNode *pNext;
};
typedef struct tagNode *pNode;
```
## Array
```c++
typedef int INT_ARRAY_100[100];
INT_ARRAY_100 arr;
```
## Pointer
```c++
typedef char* PCHAR;
PCHAR pa;

typedef char* PCHAR;
int strcmp(const PCHAR, const PCHAR);
// 在上面的代码中，const PCHAR 是否相当于 const char* 呢？
```
答案是否定的，原因很简单，typedef 是用来定义一种类型的新别名的，它不同于宏，不是简单的字符串替换。因此，**const PCHAR 中的 const 给予了整个指针本身常量性（因为const是对给定类型的修饰，给定的类型是char指针），也就是形成了常量指针** char* const（一个指向char的常量指针）。即它实际上相当于 char* const ，而不是 const char* （指向常量 char 的指针）。当然，要想让 const PCHAR 相当于 const char* 也很容易，如下面的代码所示：
```c++
typedef const char* PCHAR; 
int strcmp(PCHAR， PCHAR);
```
还需要特别注意的是，虽然 typedef 并不真正影响对象的存储特性，但**在语法上它还是一个存储类的关键字，就像 auto、extern、static 和 register 等关键字一样**。因此，像下面这种声明方式是不可行的：
```c++
typedef static int INT_STATIC;
```
不可行的原因是**不能声明多个存储类关键字，由于 typedef 已经占据了存储类关键字的位置，因此，在 typedef 声明中就不能够再使用 static 或任何其他存储类关键字了。**
## Function
```c++
typedef int (*healthCalcFunc) (const GameCharacter&);

// 比较复杂的变量声明中，typedef 的优势马上就体现出来了，如下面的示例代码所示：
int *(*a[5])(int, char*);

// PFun是我们创建的一个类型别名
typedef int *(*PFun)(int, char*);
// 使用定义的新类型来声明对象，等价于int*(*a[5])(int,char*);
PFun a[5];
```
## Define/Typedef
| 描述         | define                     | typedef                                                |
| ------------ | -------------------------- | ------------------------------------------------------ |
| 类型检查     | 无                         | 有                                                     |
| 作用时间     | 预编译期                   | 编译期                                                 |
| 是否分配内存 | 不分配内存，给出的是立即数 | 在静态存储区分配内存，在程序运行的期间只发生了一次拷贝 |
| 作用域       | 没有作用域的限制           | 只能在定义的作用域内使用                               |
# Type Aliases
#cpp11
当声明一个函数指针时别名声明更容易理解：
````cpp
//FP是一个指向函数的指针的同义词，它指向的函数带有
//int和const std::string&形参，不返回任何东西
typedef void (*FP)(int, const std::string&);    //typedef

//含义同上
using FP = void (*)(int, const std::string&);   //别名声明
````
此外，typedef不支持模板化，但是别名声明支持：
```c++
// C++98中只能把typedef嵌套进模板化的struct才能表达
template<typename T>                            //MyAllocList<T>是
struct MyAllocList {                            //std::list<T, MyAlloc<T>>
    typedef std::list<T, MyAlloc<T>> type;      //的同义词
};

MyAllocList<Widget>::type lw;                   //用户代码

// c++11别名声明
template<typename T>                            //MyAllocList<T>是
using MyAllocList = std::list<T, MyAlloc<T>>;   //std::list<T, MyAlloc<T>>的同义词

MyAllocList<Widget> lw;                         //用户代码
```
如果想使用在一个模板内使用`typedef`声明一个链表对象，而这个对象又使用了模板形参，就不得不在`typedef`前面加上`typename`：
````cpp
template<typename T>
class Widget {                              //Widget<T>含有一个
private:                                    //MyAllocLIst<T>对象
    typename MyAllocList<T>::type list;     //作为数据成员
    …
}; 
````
这里`MyAllocList<T>::type`使用了一个类型，这个类型依赖于模板参数`T`。因此`MyAllocList<T>::type`是一个依赖类型（*dependent type*），必须要在依赖类型名前加上`typename`。
如果使用别名声明定义一个`MyAllocList`，就不需要使用`typename`，同时省略麻烦的`::type`”后缀：
```c++
template<typename T>
class Widget {                              //Widget<T>含有一个
private:                                    //MyAllocLIst<T>对象
    typename MyAllocList<T>::type list;     //作为数据成员
}; 

template<typename T> 
class Widget {
private:
    MyAllocList<T> list;                    //没有 typename，没有::type
};
```
对你来说，`MyAllocList<T>`（使用了模板别名声明的版本）可能看起来和`MyAllocList<T>::type`（使用`typedef`的版本）一样都应该依赖模板参数`T`，但是你不是编译器。当编译器处理`Widget`模板时遇到`MyAllocList<T>`（使用模板别名声明的版本），它们知道`MyAllocList<T>`是一个类型名，因为`MyAllocList`是一个别名模板：它**一定**是一个类型名。因此`MyAllocList<T>`就是一个**非依赖类型**（*non-dependent type*），就不需要也不允许使用`typename`修饰符。
当编译器在`Widget`的模板中看到`MyAllocList<T>::type`（使用`typedef`的版本），它不能确定那是一个类型的名称。因为可能存在一个`MyAllocList`的它们没见到的特化版本，那个版本的`MyAllocList<T>::type`指代了一种不是类型的东西。那听起来很不可思议，但不要责备编译器穷尽考虑所有可能。
举个例子，一个误入歧途的人可能写出这样的代码：
````cpp
class Wine { … };

template<>                          //当T是Wine
class MyAllocList<Wine> {           //特化MyAllocList
private:  
    enum class WineType             
    { White, Red, Rose };           

    WineType type;                  //在这个类中，type是
    …                               //一个数据成员！
};
````
就像你看到的，`MyAllocList<Wine>::type`不是一个类型。如果`Widget`使用`Wine`实例化，在`Widget`模板中的`MyAllocList<Wine>::type`将会是一个数据成员，不是一个类型。在`Widget`模板内，`MyAllocList<T>::type`是否表示一个类型取决于`T`是什么，这就是为什么编译器会坚持要求你在前面加上`typename`。
同时，C++14提供了C++11所有type traits转换的别名声明版本
```c++
std::remove_const<T>::type          //C++11: const T → T 
std::remove_const_t<T>              //C++14 等价形式

std::remove_reference<T>::type      //C++11: T&/T&& → T 
std::remove_reference_t<T>          //C++14 等价形式

std::add_lvalue_reference<T>::type  //C++11: T → T& 
std::add_lvalue_reference_t<T>      //C++14 等价形式

template <class T> 
using remove_const_t = typename remove_const<T>::type;

template <class T> 
using remove_reference_t = typename remove_reference<T>::type;

template <class T> 
using add_lvalue_reference_t =
  typename add_lvalue_reference<T>::type; 
```