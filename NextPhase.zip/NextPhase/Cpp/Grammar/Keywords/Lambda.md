# Lambda
一个 `lambda` 表达式表示一个可调用的代码单元，可以将其理解为一个未命名的内联函数。一个 `lambda` 具有一个返回类型、一个参数列表和一个函数体：
```c++
[capture list] (parameter list) -> return type { function body } 
```
其中，`capture list` 是一个 `lambda` 所在函数中定义的局部变量的列表，与普通函数不同， `lambda` 必须使用尾置返回来指定返回类型。可以忽略参数列表和返回类型，但必须永远包含捕获列表和函数体：
```c++
auto func = [](int x) { cout << x * x << endl; };  
func(3);
```
如果忽略返回类型，`lambda` 根据函数体中的代码推断出返回类型，如果函数体只是一个 `return` 语句，则返回类型从返回的表达式的类型推断而来，否则，返回类型为 void。三元运算符可以推断出来，但与其作用相同的 `if` 判断不行。
```c++
// if判断必须使用返回类型
transform(vi.begin(), vi.end(), vi.begin(), [](int i) -> int { 
    if (i < 0) return -i; 
    else return i; 
});
```
- `lambda` 表达式就是一个表达式。下面是部分源代码。
  ```cpp
find_if(container.begin(), container.end(), 
             [](int val){ return 0 < val && val < 10; });  
  ```
- 闭包是 `lambda` 创建的运行时对象。依赖捕获模式，闭包持有被捕获数据的副本或者引用。在上面的 `find_if` 调用中，闭包是作为第三个实参在运行时传递给 `find_if` 的对象。
- 闭包类是从中实例化闭包的类。每个 `lambda` 都会使编译器生成唯一的闭包类。`lambda` 中的语句成为其闭包类的成员函数中的可执行指令。
## Capture
与一个普通函数调用类似，调用一个 `lambda` 时给定的实参被用来初始化 `lambda` 的形参。通常，实参和形参的类型必须匹配。但**与普通函数不同，`lambda` 不能有默认参数**。因此，一个 `lambda` 调用的实参数目永远与形参数目相等。一旦形参初始化完毕，就可以执行函数体了。
一个 `lambda` 可以出现在一个函数中，通过将局部变量包含在其捕获列表中来指出将会使用这些变量。捕获列表指引 `lambda` 在其内部包含访问局部变量所需的信息。`lambda` 以一对 `[]` 开始，可以在其中提供一个以逗号分隔的名字列表，这些名字都是它所在函数中定义的。
采用值捕获的前提是变量可以拷贝。与参数不同，被捕获的变量的值是在 `lambda` 创建时拷贝，而不是调用时拷贝。由于被捕获变量的值是在 `lambda` 创建时拷贝，因此随后对其修改不会影响到 `lambda` 捕获的对应值，但默认情况下，对于一个值被拷贝的变量，`lambda` 不允许改变其值。如果希望能改变一个被捕获的变量的值，就必须加上关键字 `mutable`：
```cpp
void fcn3() {
    size_t v1 = 42; // 局部变量
    auto f = [v1]() mutable { return ++v1; };  // f可以改变它所捕获的变量的值 
    v1 = 0; // 局部变量的v1
    auto j = f(); // j为43 ，此时是lambda拷贝的v1
}
```
如果采用引用方式捕获一个变量，就必须确保被引用的对象在 `lambda` 执行的时候是存在的。一个引用捕获的变量是否可以修改依赖于此引用，取决于指向的是一个 `const` 类型还是一个非 `const` 类型：
```c++
void fcn3() {
    size_t v1 = 42; // 局部变量
    auto f2 = [&v1]() { return ++v1; };  // f可以改变它所捕获的变量的值，引用指向的是非const
    v1 = 0; // 局部变量的v1
    auto j = f2(); // j为1，此时是局部变量的v1
}
```
函数可以直接返回一个可调用对象，或者返回一个类对象，该类含有可调用对象的数据成员。如果函数返回一个 `lambda`，则与函数不能返回一个局部变量的引用类似，此 `lambda` 也不能包含引用捕获，因为返回后的 `lambda` 执行时引用的局部变量将不再存在。
```c++
int count = 0;

// lambda对象被remove_if()算法在执行过程中复制了一份
// 于是存在两个lambda对象都移除第三元素，导致重复的行为
pos = remove_if(coll.begin(), coll.end(), 
                [&count](int) { return ++count == 3; }); 
                
// 以by reference方式传递实参，remove_if()内部所用的两个lambda对象共享同一状态
// 因此一如预期
pos = remove_if(coll.begin(), coll.end(), 
                [count](int) mutable { return ++count == 3; }); 
```
除显式列出使用的来自所在函数的变量，还可以让编译器根据 `lambda` 体中的代码来推断要使用哪些变量，即不列出变量名的隐式/默认捕获。`&` 告诉编译器采用捕获引用方式，`=` 则表示采用值捕获方式。
如果希望对一部分变量采用值捕获，对其他变量采用引用捕获，可以混合使用隐式捕获和显式捕获：
- 当混合使用隐式捕获和显式捕获时，捕获列表中的第一个元素必须是一个 `&` 或 `=`，指定默认捕获方式为引用或值。 
- 当混合使用隐式捕获和显式捕获时，显式捕获的变量必须使用与隐式捕获不同的方式。即，如果隐式捕获是引用方式，则显式捕获命名变量必须采用值方式，因此不能在其名字前使用 `&`。类似的，如果隐式捕获采用的是值方式，则显式捕获命名变量必须采用引用方式，即，在名字前使用 `&`。
```cpp
void biggies (vector<string> &words, vector<string>::size_type sz, ostream &os = cout, char c = '') {
    // os隐式捕获，引用捕获方式；c显式捕获，值捕获方式
    for_each(words.begin(), words.end(), [&, c](const string &s) { os << s << c; }); 
    // os显式捕获，引用捕获方式；c隐式捕获，值捕获方式
    for_each(words.begin(), words.end(), [=, &os](const string &s) { os << s << c; }); 
}
```
## Avoid Default Capture Modes
`C++11` 中有两种默认的捕获模式：按引用捕获和按值捕获。但默认按引用捕获模式可能会带来悬空引用的问题，而默认按值捕获模式可能会诱骗你让你以为能解决悬空引用的问题（实际上并没有），还会让你以为你的闭包是独立的（事实上也不是独立的）。
### Dangling Ref And Capture By Ref
按引用捕获会导致闭包中包含了对某个局部变量或者形参的引用，变量或形参只在定义 `lambda` 的作用域中可用。如果该 `lambda` 创建的闭包生命周期超过了局部变量或者形参的生命周期，那么闭包中的引用将会变成悬空引用。举个例子，假如有元素是过滤函数的一个容器，该函数接受一个 `int`，并返回一个 `bool`，该 `bool` 的结果表示传入的值是否满足过滤条件：
```c++
using FilterContainer = vector<function<bool(int)>>; 
FilterContainer filters;                    //过滤函数
```
可以添加一个过滤器，用来过滤掉 5 的倍数：
```c++
filters.emplace_back(          
	[](int value) { return value % 5 == 0; }
);
```
然而可能需要的是能够在运行期计算除数，即不能将 5 硬编码到 `lambda` 中。因此添加的过滤器逻辑将会是如下这样：
```c++
void addDivisorFilter()
{
    auto calc1 = computeSomeValue1();
    auto calc2 = computeSomeValue2();

    auto divisor = computeDivisor(calc1, calc2);

    filters.emplace_back(                               //危险！对divisor的引用
        [&](int value) { return value % divisor == 0; } //将会悬空！
    );
}
```
这个代码实现是一个定时炸弹。`lambda` 对局部变量 `divisor` 进行了引用，但该变量的生命周期会在 `addDivisorFilter` 返回时结束，刚好就是在语句 `filters.emplace_back` 返回之后。因此添加到 `filters` 的函数添加完，该函数就死亡了。使用这个过滤器会导致未定义行为，这是由它被创建那一刻起就决定了的。
现在，同样的问题也会出现在 `divisor` 的显式按引用捕获。
```c++
filters.emplace_back(
    [&divisor](int value) 			    //危险！对divisor的引用将会悬空！
    { return value % divisor == 0; }
);
```
但通过显式的捕获，能更容易看到 `lambda` 的可行性依赖于变量 `divisor` 的生命周期。另外，写下`divisor` 这个名字能够提醒要注意确保 `divisor` 的生命周期至少跟 `lambda` 闭包一样长。比起 `[&]` 传达的意思，显式捕获能让人更容易想起确保没有悬空变量。
可能会这样认为：如果知道一个闭包将会被马上使用并且不会被拷贝，那么在它的 `lambda` 被创建的环境中，将不会有持有的引用比局部变量和形参活得长的风险。例如，过滤 `lambda` 只会用做 `C++11` 中 `all_of` 的一个实参，返回满足条件的所有元素：
```c++
template<typename C>
void workWithContainer(const C& container)
{
    auto calc1 = computeSomeValue1();               //同上
    auto calc2 = computeSomeValue2();               //同上
    auto divisor = computeDivisor(calc1, calc2);    //同上

    using ContElemT = typename C::value_type;       //容器内元素的类型
    using begin;                               
    using end;

    if (all_of(                                //如果容器内所有值都为
            begin(container), end(container),       //除数的倍数
            [&](const ContElemT& value)
            { return value % divisor == 0; })
        ) {
        …                                           //它们...
    } else {
        …                                           //至少有一个不是的话...
    }
}

// C++14 支持了在 lambda 中使用 auto 来声明变量
if (all_of(begin(container), end(container),
			   [&](const auto& value)               // C++14
			   { return value % divisor == 0; }))	
```
的确如此，这是安全的做法，但这种安全是不确定的。如果发现 `lambda` 在其它上下文中很有用（例如作为一个函数被添加在 `filters` 容器中），然后拷贝粘贴到一个 `divisor` 变量已经死亡，但闭包生命周期还没结束的上下文中，又会回到悬空的使用上。
### This Pointer And Capture By Value
从长期来看，显式列出 `lambda` 依赖的局部变量和形参，是更加符合软件工程规范的做法。对上述问题的一个解决方法是，`divisor` 默认按值捕获进去，也就是说可以按照以下方式来添加 `lambda` 到`filters`： 
```c++
filters.emplace_back( 							    //现在divisor不会悬空了
    [=](int value) { return value % divisor == 0; }
);
```
这足以满足本实例的要求，但在通常情况下，按值捕获并不能完全解决悬空引用的问题。这里的问题是，如果按值捕获的是一个指针，将该指针拷贝到 `lambda` 对应的闭包里，但这样并不能避免 `lambda` 外 `delete` 这个指针的行为，从而导致副本指针变成悬空指针。
也许只有 `C++98` 的程序员才会用裸指针和 `delete` 语句。这也许是正确的，但却是不相关的，因为事实上的确会使用裸指针，也的确存在被 `delete` 的可能性。只不过在现代的 `C++` 编程风格中，不容易在源代码中显露出来而已。假设在一个 `Widget` 类，可以实现向过滤器的容器添加条目：
```c++
class Widget {
public:
    …                       //构造函数等
    void addFilter() const; //向filters添加条目
private:
    int divisor;            //在Widget的过滤器使用
};
```
这是 `Widget::addFilter` 的定义：
```c++
void Widget::addFilter() const
{
    filters.emplace_back(
        [=](int value) { return value % divisor == 0; }
    );
}	
```
这个做法看起来是安全的代码。`lambda` 依赖于 `divisor`，但默认的按值捕获确保 `divisor` 被拷贝进了 `lambda` 对应的所有闭包中，对吗？错误，完全错误。
捕获只能应用于 `lambda` 被创建时所在作用域里的 `non-static`局部变量（包括形参）。在 `Widget::addFilter` 的视线里，`divisor` 并不是一个局部变量，而是 `Widget` 类的一个成员变量。它不能被捕获。而如果默认捕获模式被删除，代码就不能编译了：
```c++
void Widget::addFilter() const
{
    filters.emplace_back(                               //错误！
        [](int value) { return value % divisor == 0; }  //divisor不可用
    ); 
} 
```
另外，如果尝试去显式地捕获 `divisor` 变量，也一样会编译失败，因为 `divisor` 不是一个局部变量或者形参。
```c++
void Widget::addFilter() const
{
    filters.emplace_back(
        [divisor](int value)                //错误！没有名为divisor局部变量可捕获
        { return value % divisor == 0; }
    );
}
```
所以如果默认按值捕获不能捕获 `divisor`，而不用默认按值捕获代码就不能编译，解释就是这里隐式使用了一个原始指针 `this`。每一个 `non-static` 成员函数都有一个 `this` 指针，每次使用一个类内的数据成员时都会使用到这个指针。例如，在任何 `Widget` 成员函数中，编译器会在内部将 `divisor` 替换成 `this->divisor`。在默认按值捕获的 `Widget::addFilter` 版本中：
```c++
void Widget::addFilter() const
{
    filters.emplace_back(
        [=](int value) { return value % divisor == 0; }
    );
}
```
真正被捕获的是 `Widget` 的 `this` 指针，而不是 `divisor`。编译器会将上面的代码看成以下的写法：
```c++
void Widget::addFilter() const
{
    auto currentObjectPtr = this;

    filters.emplace_back(
        [currentObjectPtr](int value)
        { return value % currentObjectPtr->divisor == 0; }
    );
}
```
因此默认按值捕获会导致闭包内含有 `Widget` 的 `this` 指针的拷贝，这会导致悬空指针。特别是考虑以下的代码，只使用智能指针：
```c++
using FilterContainer = vector<function<bool(int)>>; //跟之前一样
 
FilterContainer filters;                    //跟之前一样

void doSomeWork()
{
    auto pw = make_unique<Widget>();        //创建Widget
    pw->addFilter();                        //添加使用Widget::divisor的过滤器
}                                           //销毁Widget；filters现在持有悬空指针！
```
当调用 `doSomeWork` 时，就会创建一个过滤器，其生命周期依赖于由 `make_unique` 产生的 `Widget` 对象，即一个含有指向 `Widget` 的指针——`Widget` 的 `this` 指针——的过滤器。这个过滤器被添加到 `filters` 中，但当 `doSomeWork` 结束时，`Widget` 会由管理它的 `unique_ptr` 来销毁。从这时起，`filter` 会含有一个存着悬空指针的条目。
这个特定的问题可以通过给想捕获的数据成员做一个局部副本，然后捕获这个副本去解决：
```c++
void Widget::addFilter() const
{
    auto divisorCopy = divisor;                 //拷贝数据成员

    filters.emplace_back(
        [divisorCopy](int value)                //捕获副本
        { return value % divisorCopy == 0; }	//使用副本
    );
}
```
事实上如果采用这种方法，默认的按值捕获也是可行的：
```c++
void Widget::addFilter() const
{
    auto divisorCopy = divisor;                 //拷贝数据成员

    filters.emplace_back(
        [=](int value)                          //捕获副本
        { return value % divisorCopy == 0; }	//使用副本
    );
}
```
但为什么要冒险呢？当一开始你认为你捕获的是 `divisor` 的时候，默认捕获模式就是造成可能意外地捕获 `this` 的元凶。
在 `C++14` 中，一个更好的捕获成员变量的方式时使用通用的 `lambda` 捕获：
```c++
void Widget::addFilter() const
{
    filters.emplace_back(                   //C++14
        [divisor = divisor](int value)      //拷贝divisor到闭包
        { return value % divisor == 0; }	//使用这个副本
    );
}
```
这种通用的 `lambda` 捕获并没有默认的捕获模式，因此在C++14中，本条款的建议——避免使用默认捕获模式——仍然是成立的。
### Static Variable
使用默认的按值捕获还有另外的一个缺点，它们预示了相关的闭包是独立的并且不受外部数据变化的影响。一般来说，这是不对的。`lambda` 可能会依赖局部变量和形参（它们可能被捕获），还有**静态存储生命周期**的对象。这些对象定义在全局空间或者命名空间，或者在类、函数、文件中声明为`static`。这些对象也能在 `lambda` 里使用，但它们不能被捕获，但默认按值捕获可能会因此误导你，让你以为捕获了这些变量。参考下面版本的 `addDivisorFilter` 函数：
```c++
void addDivisorFilter()
{
    static auto calc1 = computeSomeValue1();    //现在是static
    static auto calc2 = computeSomeValue2();    //现在是static
    static auto divisor =                       //现在是static
    computeDivisor(calc1, calc2);

    filters.emplace_back(
        [=](int value)                          //什么也没捕获到！
        { return value % divisor == 0; }        //引用上面的static
    );

    ++divisor;                                  //调整divisor
}
```
随意地看了这份代码的读者可能看到 `[=]` ，就会认为 `lambda` 拷贝了所有使用的对象，因此这是独立的。但其实不独立。这个 `lambda` 没有使用任何的 `non-static` 局部变量，所以它没有捕获任何东西。然而 `lambda` 的代码引用了 `static` 变量 `divisor`，由于在每次调用 `addDivisorFilter` 的结尾，`divisor` 都会递增，因此通过这个函数添加到 `filters` 的所有 `lambda` 都会随着 `addDivisorFilter` 调用展示新的行为（分别对应新的 `divisor` 值）。这个 `lambda` 是通过引用捕获 `divisor`，这和默认的按值捕获表示的含义有着直接的矛盾。如果一开始就避免使用默认的按值捕获模式，就能解除代码的风险。
**请记住：**
+ 默认的按引用捕获可能会导致悬空引用。
+ 默认的按值捕获对于悬空指针很敏感（尤其是`this`指针），并且它会误导人产生 `lambda` 是独立的想法。
## Use Init Capture To Move Objects Into Closures
在某些场景下，按值捕获和按引用捕获都不是所想要的。如果有一个只能被移动的对象要进入到闭包里，使用 `C++11` 是无法实现的。如果要复制的对象复制开销非常高，但移动的成本却不高（例如标准库中的大多数容器），并且希望的是宁愿移动该对象到闭包而不是复制它，`C++11` 也无法实现这一目标。
### Move Objects Into Closures
`C++14` 引入了初始化捕获，支持将对象移动到闭包中，C++11 捕获形式能做的所有事它几乎可以做，甚至能完成更多功能。不能用初始化捕获表达的东西是默认捕获模式，但无论如何都应该远离默认捕获模式。使用初始化捕获可以指定：
1. 从 `lambda` 生成的闭包类中的数据成员名称；
2. 初始化该成员的表达式；
这是使用初始化捕获将 `unique_ptr` 移动到闭包中的方法：
```c++
class Widget {                          //一些有用的类型
public:
    bool isValidated() const;
    bool isProcessed() const;
    bool isArchived() const;
private:
    …
};

auto pw = make_unique<Widget>();   //创建Widget

…                                       //设置*pw

auto func = [pw = move(pw)]        //使用move(pw)初始化闭包数据成员
            { return pw->isValidated() && pw->isArchived(); };
```
`pw = move(pw)` 包含了初始化捕获的使用，`=` 的左侧是指定的闭包类中数据成员的名称，右侧则是初始化表达式。`=` 左侧的作用域不同于右侧的作用域，左侧的作用域是闭包类，右侧的作用域和 `lambda` 定义所在的作用域相同。在上面的示例中，`=` 左侧的名称 `pw` 表示闭包类中的数据成员，而右侧的名称 `pw` 表示在 `lambda` 上方声明的对象，即由调用 `make_unique` 去初始化的变量。因此， `pw = move(pw)` 的意思是在闭包中创建一个数据成员 `pw`，并用将 `move` 应用于局部变量 `pw` 的结果来初始化该数据成员。
在此示例中，注释设置 `*pw` 表示在由 `make_unique` 创建 `Widget` 之后，`lambda` 捕获到指向 `Widget` 的 `unique_ptr` 之前，该 `Widget` 以某种方式进行了修改。如果不需要进行修改，即如果 `make_unique` 创建的 `Widget` 处于适合被 `lambda` 捕获的状态，则不需要局部变量 `pw`，因为闭包类的数据成员可以通过 `make_unique` 直接初始化：
```c++
auto func = [pw = make_unique<Widget>()]   //使用调用make_unique得到的结果
            { return pw->isValidated()          //初始化闭包数据成员
                     && pw->isArchived(); };
```
这清楚地表明了，这个 `C++14` 的捕获概念是从 `C++11` 发展出来的，在 `C++11` 中，无法捕获表达式的结果。 因此，初始化捕获的另一个名称是通用 `lambda` 捕获。
`lambda` 表达式只是生成一个类和创建该类型对象的一种简单方式而已，如果使用的一个或多个编译器不支持 `C++14` 的初始捕获，那么可以自己手动实现。刚刚的示例代码可以用 `C++11` 重新编写：
```c++
class IsValAndArch {                            //“is validated and archived”
public:
    using DataType = unique_ptr<Widget>;
    
    explicit IsValAndArch(DataType&& ptr)      
    : pw(move(ptr)) {}
    
    bool operator()() const
    { return pw->isValidated() && pw->isArchived(); }
    
private:
    DataType pw;
};

auto func = IsValAndArch(make_unique<Widget>());
```
### Bind
如果坚持要使用 `lambda` 而不自己手动改实现，移动捕获可以在 `C++1`1 中这样模拟：
1. 将要捕获的对象移动到由 `bind` 产生的函数对象中；
2. 将被捕获的对象的引用赋予给 `lambda` 。
假设要创建一个本地的 `vector`，在其中放入一组适当的值，然后将其移动到闭包中。在 C++14 中，这很容易实现：
```c++
vector<double> data;               // 要移动进闭包的对象类型 vector<double>

…                                  // 填充data

// 该对象的名称 data 用于初始化捕获的初始化表达式 move(data)
auto func = [data = move(data)]    //C++14初始化捕获
            { /*使用data*/ };
```
`C++11` 的等效代码如下：
```c++
vector<double> data;                    // 同上
…                                       // 同上

// 尽管用于初始化 data 副本的表达式 move(data) 为右值，但 data 副本本身为左值
// 因此此处的形参是左值引用
auto func =
    bind(                              // C++11模拟初始化捕获
        [](const vector<double>& data) // 本行高亮
        { /*使用data*/ },
        move(data)                     // 本行高亮
    );
```
如 `lambda` 表达式一样，`bind` 产生函数对象。下述将由 `bind` 返回的函数对象称为 `bind` 对象。 `bind` 的第一个实参是可调用对象，后续实参表示要传递给该对象的值。
一个 `bind` 对象包含了传递给 `bind` 的所有实参的副本。对于每个左值实参，`bind` 对象中的对应对象都是复制构造的。对于每个右值，它都是移动构造的。在此示例中，第二个实参是一个右值，因此将 `data` 移动构造到绑定对象中。这种移动构造是模仿移动捕获的关键，因为将右值移动到 `bind` 对象是解决无法将右值移动到 `C++11` 闭包中的方法。
当调用 `bind` 对象即调用其函数调用运算符时，其存储的实参将传递到最初传递给 `bind` 的可调用对象。在此示例中，这意味着当调用 `func` 时，`func` 中所移动构造的 `data` 副本将作为实参传递给 `bind` 中的 `lambda` 。
该 `lambda` 与在 `C++14` 中使用的 `lambda` 相同，只是添加了一个形参 `data` 来对应伪移动捕获对象。此形参是对 `bind` 对象中 `data` 副本的左值引用。因此，`lambda` 将对绑定在对象内部的移动构造的 `data` 副本进行操作。
默认情况下，从 `lambda` 生成的闭包类中的 `operator()` 成员函数为 `const` 的。但是，`bind` 对象内部的移动构造的 `data` 副本不是 `const` 的，`data` 是作为实参传入而不是捕获的，因此，为了防止在 `lambda` 内修改该 `data` 副本，`lambda` 的形参应声明为 `reference-to-const`。 如果将 `lambda` 声明为 `mutable`，则闭包类中的 `operator()`将不会声明为 `const`，并且在 `lambda` 的形参声明中省略 `const` 也是合适的：
```c++
auto func =
    bind(                                  //C++11对mutable lambda
        [](vector<double>& data) mutable	//初始化捕获的模拟
        { /*使用data*/ },
        move(data)
    );
```
因为 `bind` 对象存储着传递给 `bind` 的所有实参的副本，所以在示例中，`bind` 对象包含由 `lambda` 生成的闭包副本，这是它的第一个实参。因此闭包的生命周期与 `bind` 对象的生命周期相同。 这很重要，因为这意味着只要存在闭包，包含伪移动捕获对象的 `bind` 对象也将存在。
综上，关于 `bind`：
* 无法移动构造一个对象到 `C++11` 闭包，但是可以将对象移动构造进 `C++11` 的 `bind` 对象。
* 在 `C++11` 中模拟移动捕获包括将对象移动构造进 `bind` 对象，然后通过传引用将移动构造的对象传递给 `lambda` 。
* 由于 `bind` 对象的生命周期与闭包对象的生命周期相同，因此可以将 `bind` 对象中的对象视为闭包中的对象。
作为使用 `bind` 模仿移动捕获的第二个示例，这是之前在闭包中创建 `unique_ptr` 的 `C++14` 代码：
```c++
auto func = [pw = make_unique<Widget>()]   //同之前一样
            { return pw->isValidated()          //在闭包中创建pw
                     && pw->isArchived(); };
```
这是 `C++11` 的模拟实现：
```c++
auto func = bind(
                [](const unique_ptr<Widget>& pw)
                { return pw->isValidated()
                         && pw->isArchived(); },
                make_unique<Widget>()
            );
```
**请记住：**
* 使用 `C++14` 的初始化捕获将对象移动到闭包中。
* 在 `C++11` 中，通过手写类或 `bind` 的方式来模拟初始化捕获。
##  Prefer Lambdas To `bind`
`C++11` 中的 `bind` 是 `C++98` 的 `bind1st` 和 `bind2nd` 的后续，但在 2005 年已经非正式成为了标准库的一部分。那时标准化委员采用了 `TR1` 的文档，其中包含了 `bind` 的规范。在 TR1 中，`bind`位于不同的命名空间，因此它是 `tr1::bind`，而不是 `bind`，接口细节也有所不同。
### Readability
优先 `lambda` 而不是 `bind` 的最重要原因是 `lambda` 更易读。例如，假设有一个设置警报器的函数：
```c++
//一个时间点的类型定义
using Time = chrono::steady_clock::time_point;

enum class Sound { Beep, Siren, Whistle };

//时间段的类型定义
using Duration = chrono::steady_clock::duration;

//在时间t，使用s声音响铃时长d
void setAlarm(Time t, Sound s, Duration d);
```
进一步假设，在程序的某个时刻，已经确定需要设置一个小时后响 30 秒的警报器。 但是，具体声音仍未确定。可以编写一个 `lambda` 来修改 `setAlarm` 的界面，以便仅需要指定声音：
```c++
//setSoundL 是个函数对象，允许指定一小时后响30秒的警报器的声音
auto setSoundL =
    [](Sound s) 
    {
        using namespace chrono; 
        
        setAlarm(steady_clock::now() + hours(1),    //一小时后响30秒的闹钟
                 s,                                 //译注：setAlarm三行高亮
                 seconds(30));
    };
// 通过使用标准后缀简化在 C++14 中的代码，其中标准后缀基于 C++11 对用户自定义常量的支持
auto setSoundL =
    [](Sound s)
    {
        using namespace chrono;
        using namespace literals;      //对于C++14后缀

        setAlarm(steady_clock::now() + 1h,	//C++14写法，但是含义同上
                 s,
                 30s);
    };
```
对 `setAlarm` 的调用是一个很正常的函数调用：传递给 `lambda` 的形参 `s` 又作为实参被传递给了 `setAlarm`。
下面是第一次编写对应的 `bind` 调用。这里存在一个后续会修复的错误，但正确的代码会更加复杂，即使是此简化版本也会凸显一些重要问题：
```c++
using namespace chrono;                //同上
using namespace literals;
using namespace placeholders;          //“_1”使用需要

auto setSoundB =                            //“B”代表“bind”
    bind(setAlarm,
              steady_clock::now() + 1h,     //不正确！见下
              _1,
              30s);
```
调用 `setSoundB` 会使用在对 `bind` 的调用中所指定的时间和持续时间来调用 `setAlarm`，调用`setSoundB` 时的第一个实参会被传递进 `setAlarm`，作为调用 `setAlarm` 的第二个实参。在对 `bind` 的调用中未标识此实参的类型，因此必须查阅 `setAlarm` 声明以确定将哪种实参传递给`setSoundB`。
但代码并不完全正确。
在 `lambda` 中，表达式 `steady_clock::now() + 1h` 显然是 `setAlarm`的实参。调用 `setAlarm` 时将对其进行计算，那么逻辑上是在调用 `setAlarm` 后一小时响铃。
但是，在 `bind` 调用中，将 `steady_clock::now() + 1h` 作为实参传递给了`bind`，而不是 `setAlarm`。这意味着将在调用 `bind` 时对表达式进行求值，并且该表达式产生的时间将存储在产生的 `bind` 对象中。结果，警报器将被设置为在调用 `bind` 后一小时发出声音，而不是在调用 `setAlarm` 一小时后发出。
要解决此问题，需要告诉 `bind` 推迟对表达式的求值，直到调用 `setAlarm` 为止，而这样做的方法是将对 `bind` 的第二个调用嵌套在第一个调用中：
```c++
auto setSoundB =
    bind(setAlarm,
              bind(plus<>(), bind(steady_clock::now), 1h),
              _1,
              30s);
```
 在 `C++14 `中，通常可以省略标准运算符模板的模板类型实参，因此无需在此处提供。`C++11` 没有提供此类功能，因此等效于 `lambda` 的 `C++11 bind` 为：
```c++
using namespace chrono;                //同上
using namespace placeholders;
auto setSoundB =
    bind(setAlarm,
              bind(plus<steady_clock::time_point>(),
                        bind(steady_clock::now),
                        hours(1)),
              _1,
              seconds(30));
```
### Overload
当 `setAlarm` 重载时，会出现一个新问题。假设有一个重载函数，其中第四个形参指定了音量：
```c++
enum class Volume { Normal, Loud, LoudPlusPlus };

void setAlarm(Time t, Sound s, Duration d, Volume v);
```
`lambda` 能继续像以前一样使用，因为根据重载规则选择了 `setAlarm` 的三实参版本：
```c++
auto setSoundL =                            //和之前一样
    [](Sound s)
    {
        using namespace chrono;
        setAlarm(steady_clock::now() + 1h,  //可以，调用三实参版本的setAlarm
                 s,
                 30s);
    };
```
然而，`bind` 的调用将会编译失败：
```c++
auto setSoundB =                            //错误！哪个setAlarm？
    bind(setAlarm,
              bind(plus<>(),
                        steady_clock::now(),
                        1h),
              _1,
              30s);
```
这里的问题是，编译器无法确定应将两个 `setAlarm` 函数中的哪一个传递给 `bind`，它们仅有的是一个函数名称，而这个单一个函数名称是有歧义的。要使对 `bind` 的调用能编译，必须将 `setAlarm` 强制转换为适当的函数指针类型：
```c++
using SetAlarm3ParamType = void(*)(Time t, Sound s, Duration d);

auto setSoundB =                                            //现在可以了
    bind(static_cast<SetAlarm3ParamType>(setAlarm),
              bind(plus<>(),
                        steady_clock::now(),
                        1h), 
              _1,
              30s);
```
但这在 `lambda` 和 `bind` 的使用上带来了另一个区别。 在 `setSoundL` 的函数调用操作符（即 `lambda` 的闭包类对应的函数调用操作符）内部，对 `setAlarm` 的调用是正常的函数调用，编译器可以按常规方式进行内联：
```c++
setSoundL(Sound::Siren);    // setAlarm函数体在这可以很好地内联
```
但是，对 `bind` 的调用是将函数指针传递给 `setAlarm`，这意味着在 `setSoundB` 的函数调用操作符（即绑定对象的函数调用操作符）内部，对 `setAlarm` 的调用是通过一个函数指针。 编译器不太可能通过函数指针内联函数，这意味着与通过 `setSoundL` 进行调用相比，通过 `setSoundB` 对 `setAlarm` 的调用，其函数不大可能被内联：
```c++
setSoundB(Sound::Siren); 	// setAlarm函数体在这不太可能内联
```
因此，使用 `lambda` 可能会比使用 `bind` 能生成更快的代码。
`setAlarm` 示例仅涉及一个简单的函数调用。如果想做更复杂的事情，使用 `lambda` 会更有利。例如，考虑以下 `C++14` 的 `lambda` 使用，它返回其实参是否在 `lowVal` 和 `highVal`之间的结果，其中 `lowVal` 和 `highVal` 是局部变量：
```c++
auto betweenL =
    [lowVal, highVal]
    (const auto& val)                           //C++14
    { return lowVal <= val && val <= highVal; };
```
使用 `bind` 可以表达相同的内容，但是该构造是一个通过晦涩难懂的代码来保证工作安全性的示例：
```c++
using namespace placeholders;              //同上
auto betweenB =
    bind(logical_and<>(),             //C++14
              bind(less_equal<>(), lowVal, _1),
              bind(less_equal<>(), _1, highVal));
```
在 `C++14 `中，通常可以省略标准运算符模板的模板类型实参，但在 `C++11` 中，必须指定要比较的类型，然后 `bind` 调用将如下所示：
```c++
auto betweenB =
    bind(logical_and<bool>(),         //C++11版本
              bind(less_equal<int>(), lowVal, _1),
              bind(less_equal<int>(), _1, highVal));
```
当然，在 `C++11` 中，`lambda` 也不能采用 `auto` 形参，因此它也必须指定一个类型：
```c++
auto betweenL =                                 //C++11版本
    [lowVal, highVal]
    (int val)
    { return lowVal <= val && val <= highVal; };
```
但无论哪种方式，`lambda` 版本不仅更短，而且更易于理解和维护。
### PassBy
`bind` 的行为是不透明的。假设有一个函数可以创建 `Widget` 的压缩副本，
```c++
enum class CompLevel { Low, Normal, High }; //压缩等级

Widget compress(const Widget& w,            //制作w的压缩副本
                CompLevel lev);
```
并且想创建一个函数对象，该函数对象允许指定 `Widget w` 的压缩级别。这种使用 `bind` 的话将创建一个这样的对象：
```c++
Widget w;
using namespace placeholders;
auto compressRateB = bind(compress, w, _1);
```
当将 `w` 传递给 `bind` 时，必须将其存储起来，以便以后进行压缩。它存储在对象 `compressRateB`中，但是它是通过值还是引用被存储的？之所以会有所不同，是因为如果在对 `bind` 的调用与对 `compressRateB` 的调用之间修改了 `w`，则按引用捕获的 `w` 将反映这个更改，而按值捕获则不会。
答案是它是按值捕获的，因为 `bind` 总是拷贝它的实参，但是调用者可以使用引用来存储实参，这要通过应用 `ref` 到实参上实现。`auto compressRateB = bind(compress, ref(w), _1);` 的结果就是 `compressRateB` 行为像是持有 `w` 的引用而非副本。
然而在 `lambda` 方法中，其中 `w` 是通过值还是通过引用捕获是显式的：
```c++
auto compressRateL =                //w是按值捕获，lev是按值传递
    [w](CompLevel lev)
    { return compress(w, lev); };
```
同样明确的是形参是如何传递给 `lambda` 的。在这里，很明显形参 `lev` 是通过值传递的。 因此：
```c++
compressRateL(CompLevel::High);     //实参按值传递
```
但是在对由 `bind` 生成的对象调用中，实参如何传递？
```c++
compressRateB(CompLevel::High);     //实参如何传递？
```
答案是传递给 `bind` 对象的所有实参都是通过引用传递的，因为此类对象的函数调用运算符使用完美转发。
### Why Should Use
与 `lambda` 相比，使用 `bind` 进行编码的代码可读性较低，表达能力较低，并且效率可能较低。 在 `C++14` 中，没有 `bind` 的合理用例。 但是在 `C++11` 中，可以在两个受约束的情况下证明使用 `bind` 是合理的：
+ **移动捕获**。`C++11` 的 `lambda` 不提供移动捕获，但是可以通过结合 `lambda` 和`bind`来模拟。 
+ **多态函数对象**。因为 `bind` 对象上的函数调用运算符使用完美转发，所以它可以接受任何类型的实参，除完美转发失败的情况。当要绑定带有模板化函数调用运算符的对象时，此功能很有用。例如这个类，
```c++
class PolyWidget {
public:
    template<typename T>
    void operator()(const T& param);
};
```
`bind` 可以如下绑定一个 `PolyWidget` 对象：
```c++
PolyWidget pw;
auto boundPW = bind(pw, _1);
```
`boundPW` 可以接受任意类型的对象：
```c++
boundPW(1930);              //传int给PolyWidget::operator()
boundPW(nullptr);           //传nullptr给PolyWidget::operator()
boundPW("Rosebud"); 		//传字面值给PolyWidget::operator()
```
这一点无法使用 `C++11` 的 `lambda` 做到。但是在 `C++14` 中，可以通过带有 `auto` 形参的 `lambda` 轻松实现：
```c++
auto boundPW = [pw](const auto& param)  //C++14 
               { pw(param); };
```
**请记住：**
+ 与使用`bind`相比， `lambda` 更易读，更具表达力并且可能更高效。
+ 只有在 `C++11` 中，`bind` 可能对实现移动捕获或绑定带有模板化函数调用运算符的对象时会很有用。
## LambdaOrBind
可以通过bind操作为函数对象绑定部分参数，lambda作为函数对象自然也能够通过这种方式来做，但在C++扩展lambda后，仅通过lambda也能实现同样的功能：
```c++
// auto plus5 = bind(plus<int>{}, 5, _1);
constexpr auto add5 = [add](auto x) { return add(x, 5); }; 
cout << add5 (2); // 7
```
add5的实现捕获了一个函数对象add，同时接受一个参数x，返回add(x, 5)的结果。捕获add对应于bind的第一个参数，形参x对应于占位符_1。
对于bind而言，虽然它提供了一种比较简洁的表现形式来对函数对象的参数进行部分绑定、重排，但也有对应的代价。由于它是库特性，编译器生成绑定版本的函数对象需要进行复杂的编译时计算来生成代码，运行结果也不是constexpr，这不利于编译器的优化；而lambda是语言的核心特性，这意味着编译器能够很简单的优化它们。
另外使用bind与其他高阶函数组合时，需要思考bind生成的函数对象与高阶函数要求的函数签名是否一致。例如copy_if高阶函数需要接受一个单参的谓词，而从bind无法直观看出来。考虑将所有大于4的数打印出来的代码，lambda可读性更佳：
```c++
copy_if(/*...*/, bind(greater<int>{}, _1, 4)); 
copy_if(/*...*/, [](int x) { return x > 4; });
```
lambda的捕获既可以通过值语义也可以通过引用语义传递，而bind的参数绑定为值语义，若需要传引用，需通过ref等函数将引用包裹为值语义进行再传递。考虑如下函数对象assign，将第二个参数赋值给第一个参数。
```c++
constexpr auto assign = [](int &x, int y) { x = y; }; 
int x = 0;
auto assignX = [assign, &x] (int y) { assign(x, y); }; 
assignX(5); // x == 5
```
assignX将按引用捕获x，因此调用将正确地赋值给x。而通过bind的方式，若不注意则会产生意外的结果。
```c++
int x = 0;
auto assignX = bind(assign, x, _1); 
assignX(5);  // x == 0，不符合预期！
// 若通过ref将引用以值语义形式传递给bind，从而得出正确结果
// bind(assign, ref(x), _1)
```
## Use `decltype` On `auto&&` Parameters To `forward` Them
`C++14` 中泛型 `lambda` 即在 `lambda` 的形参中可以使用 `auto` 关键字。这个特性的实现是非常直截了当的：即在闭包类中的 `operator()` 函数是一个函数模版。例如：
```c++
auto f = [](auto x){ return func(normalize(x)); };
```
对应的闭包类中的函数调用操作符看来就变成这样：
```c++
class SomeCompilerGeneratedClassName {
public:
    template<typename T>                //auto返回类型见条款3
    auto operator()(T x) const
    { return func(normalize(x)); }
    …                                   //其他闭包类功能
};
```
在这个样例中，`lambda` 对变量 `x` 做的唯一一件事就是把它转发给函数 `normalize`。如果函数 `normalize` 对待左值右值的方式不一样，这个 `lambda` 的实现方式就不大合适了，因为即使传递到 `lambda` 的实参是一个右值，`lambda` 传递进 `normalize` 的总是一个左值（形参 `x`）。
实现这个 `lambda` 的正确方式是把 `x` 完美转发给函数 `normalize`。这样做需要对代码做两处修改。首先，`x` 需要改成通用引用，其次，需要使用 `forward` 将 `x` 转发到函数 `normalize`。理论上，这都是小改动：
```c++
auto f = [](auto&& x)
         { return func(normalize(forward<???>(x))); };
```
在理论和实际之间存在一个问题：应该传递给 `forward` 的什么类型。一般来说，当在使用完美转发时，是在一个接受类型参数为 `T` 的模版函数里，所以可以写`forward<T>`。但在泛型 `lambda` 中，没有可用的类型参数 `T`。在 `lambda` 生成的闭包里，模版化的 `operator()` 函数中的确有一个 `T`，但在 `lambda` 里却无法直接使用它，所以也没什么用。
如果一个左值实参被传给通用引用的形参，那么形参类型会变成左值引用，传递的是右值，形参就会变成右值引用。这意味着在这个 `lambda` 中，可以通过检查形参 `x` 的类型来确定传递进来的实参是一个左值还是右值，`decltype` 就可以实现这样的效果。传递给 `lambda` 的是一个左值，`decltype(x)` 就能产生一个左值引用，如果传递的是一个右值，`decltype(x)` 就会产生右值引用。
在调用 `forward` 时，类型实参是左值引用则表明接受和返回左值引用，类型实参是非引用则表明接受和返回右值引用，见[[MoveSemantics#Forward]]。
在前面的 `lambda` 中，如果 `x` 绑定的是一个左值，`decltype(x)` 就能产生一个左值引用，这符合惯例。然而如果 `x` 绑定的是一个右值，`decltype(x)` 就会产生右值引用，而不是常规的非引用。
再看一下关于 `forward` 的C++14实现：
```c++
template<typename T>                        //在std命名空间
T&& forward(remove_reference_t<T>& param)
{
    return static_cast<T&&>(param);
}
```
如果用户完美转发一个 `Widget` 类型的右值，它会使用 `Widget` 类型（即非引用类型）来实例化 `forward`，然后产生以下的函数：
```c++
Widget&& forward(Widget& param)             //当T是Widget时的forward实例
{
    return static_cast<Widget&&>(param);
}
```
思考一下如果用户代码想要完美转发一个 `Widget` 类型的右值，但没有遵守规则将 `T` 指定为非引用类型，而是将 `T` 指定为右值引用，这会发生什么。也就是，思考将 `T` 换成 `Widget&&` 会如何。在 `forward` 实例化、应用了 `remove_reference_t` 后，引用折叠之前，`forward` 看起来像这样：
```c++
Widget&& && forward(Widget& param)          //当T是Widget&&时的forward实例
{                                           //（引用折叠之前）
    return static_cast<Widget&& &&>(param);
}
```
应用了引用折叠之后（右值引用的右值引用变成单个右值引用），代码会变成：
```c++
Widget&& forward(Widget& param)             //当T是Widget&&时的forward实例
{                                           //（引用折叠之后）
    return static_cast<Widget&&>(param);
}
```
对比这个实例和用 `Widget` 设置 `T` 去实例化产生的结果，它们完全相同。表明用右值引用类型和用非引用类型去初始化 `forward` 产生的相同的结果。
那是一个很好的消息，因为当传递给 `lambda` 形参 `x` 的是一个右值实参时，`decltype(x)` 可以产生一个右值引用。前面已经确认过，把一个左值传给 `lambda` 时，`decltype(x)` 会产生一个可以传给`forward` 的常规类型。而现在也验证了对于右值，把`decltype(x)` 产生的类型传递给`forward`是非传统的，不过它产生的实例化结果与传统类型相同。
所以无论是左值还是右值，把 `decltype(x)` 传递给 `forward` 都能得到想要的结果，因此 `lambda` 的完美转发可以写成：
```c++
auto f =
    [](auto&& param)
    {
        return
            func(normalize(forward<decltype(param)>(param)));
    };
```
再加上可变参数，就可以让 `lambda` 完美转发接受多个形参了，因为 `C++14` 中的 `lambda` 也可以是可变形参的：
```c++
auto f =
    [](auto&&... params)
    {
        return
            func(normalize(forward<decltype(params)>(params)...));
    };
```
**请记住：**
+ 对`auto&&`形参使用`decltype`以`forward`它们。
## Implementation of Lambad
当定义一个 `lambda` 时，编译器生成一个与 `lambda` 对应的新的类类型，将该 `lambda` 表达式翻译成一个未命名类的未命名对象。当向一个函数传递一个 `lambda` 时，同时定义了一个新类型和该类型的一个对象：传递的参数就是此编译器生成的类类型的未命名对象。类似的，当使用 `auto` 定义一个用 `lambda` 初始化的变量时，定义了一个从 `lambda` 生成的新类型的对象。
默认情况下，捕获将在对应的未命名类中生成数据变量与构造函数来存储捕获，数据成员在 `lambda` 对象创建时被初始化。对于无捕获的 `lambda` 而言，其生成的匿名类中拥有一个非虚的函数指针类型转换操作符，能够将 `lambda` 转换成函数指针：
```c++
// 将无捕获的泛型lambda赋给一个函数指针
// 编译器会把匿名类中的模板函数实例化成int版本，然后通过类型转换操作符转换成具体的函数指针
using IntAddFunc = int(*)(int, int); 
constexpr IntAddFunc iadd = [](auto a, auto b) { return a + b; };
```
默认情况下 `lambda` 不能改变它捕获的变量，在默认情况下，由 `lambda` 产生的类当中的函数调用运算符是一个 `const` 成员函数，如果 `lambda` 被声明为可变的，则调用运算符就不是 `const` 的了。
`lambda` 表达式产生的类不含默认构造函数、赋值运算符及默认析构函数，它是否含有默认的拷贝/移动构造函数则通常要视捕获的数据成员类型而定。在 `lambda` 表达式产生的类中含有一个重载的函数调用运算符：
```c++
template<typename T = void>
class TestLambda1 {
public:
    TestLambda1() {}
    constexpr void operator()(int a, int b) const {
        cout << a + b << endl;
    }
};

auto Lambda1 = [](int a, int b) { cout << a + b << endl; };
Lambda1(10, 20);
```
当一个 `lambda` 表达式通过值捕获变量时，`lambda` 产生的类必须为每个值捕获的变量建立对应的数据成员，同时创建构造函数，令其使用捕获的变量的值来初始化数据成员。
```c++
template<typename T = int>
class TestLambda2 {
public:
    explicit TestLambda2(int x, int y): _x(x), _y(y) {}
    void operator()()  {
        _x = _x + _y;
    }
private:
    int _x;
    int _y;
};

int x = 10, y = 20;
auto Lambda2 = [x, y]() mutable { x = x + y; };
Lambda2();
```
当一个 `lambda` 表达式通过引用捕获变量时，将由程序负责确保 `lambda` 执行时引用所引的对象确实存在。因此，编译器可以直接使用该引用而无须在 `lambda` 产生的类中将其存储为数据成员。
```c++
template<typename T = int>
class TestLambda3 {
public:
    explicit TestLambda3(int &x, int &y): _x(x), _y(y) {}
    void operator()() const {
        _x = _x + _y;
    }
private:
    int &_x;
    int &_y;
};

cout << x << y << endl;
auto Lambda3 = [&x, &y]()  { x = x + y; };
Lambda3();
cout << x << y;
```
## Generic Lambda And Template Functions
从 `C++17` 起 `lambda` 默认为 `constexpr`，因此能够被一个 `constexpr` 常量所存储，从 `C++14` 起 `lambda` 的形参支持 `auto`，表明类型由编译器根据实际调用传递的实参进行推断，即泛型 `lambda`，相当于简化了的模板函数。
```c++
auto f = [](const auto& x) { // 参数使用auto声明，泛型化
    return x + x;
};
cout << f(3) << endl;             // 参数类型是int
cout << f(0.618) << endl;         // 参数类型是double

string str = "matrix";
cout << f(str) << endl;          // 参数类型是string
```
```c++
constexpr IntAddFunc iadd = [](auto a, auto b) { return a + b; };
template<typename T> T add(T a, T b) { return a + b; }
```
区别在于模板函数隐含着要求两个形参类型一致，而泛型 `lambda` 版本由于两个形参类型声明为 `auto`，表明两个类型之间没有严格的一致性。在 `C++20` 中泛型 `lambda` 也支持以模板参数形式提供，这样就能保证两个形参类型一致:
```c++
constexpr auto add = []<typename>(T a, T b) { return a + b; };
```
另一个重要的区别在于模板函数只有实例化之后才能传递，而泛型 `lambda` 是个对象，因此可以按值传递，在调用时根据实际传参进行实例化模板函数 `operator()`，从而延迟了实例化的时机，大大提高了灵活性。标准库的一些算法通常要求对函数对象进行组合，此时泛型 `lambda` 将能通过编译，而模板函数不行。但当涉及状态时，lambda 并非总是较好的选择：
```c++
class Person {};
// 也可以使用lambda作为hash函数、排序准则或相等准则
auto hash = [](const Person& p){ };
auto eq = [](const Person& p1, Person& p2) { };
unordered_set<Person, decltype(hash), decltype(eq)> pset(10, hash, eq); 
```
此处必须使用 `decltype` 将 `lambda` 的类型传给 `unordered_set`，因为后者会建立属于它自己的一份实例。此外也必须传递一个 `hash` 函数和相等准则给构造函数，否则 `lambda` 构造函数会调用 `hash` 函数和相等准则的默认构造函数，而那对 `lambda` 而言是未定义的。基于这些不方便性，在这里，针对 `function object` 给出一个 `class`，也许可读性较高，甚至较便捷。
