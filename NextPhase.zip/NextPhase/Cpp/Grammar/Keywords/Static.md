## Static Variables
在 C 语言中，`static` 关键字有两个作用：
修饰变量：
- 修饰全局变量，使得该全局变量只能在本文件中访问，**不能直接**的跨文件访问。
- 修饰局部变量，使得该局部变量的声明周期得以延长，不会出作用域就销毁。
修饰函数：修饰函数使得该函数只能在本文件中访问，**不能直接**的跨文件访问。
如果局部静态变量没有显式的初始值，它将执行值初始化，内置类型的局部静态变量初始化为 0。
在 `C++` 中，`static` 关键字的最终目的是创建离开和进入作用域时都可保留值的局部变量。函数中 的静态变量就像只能在函数内部访问的全局变量。静态变量最常见的用法是记住某个函数是否执行了特定的初始化操作。比如，下面的代码就使用了这一技术：
```cpp
void performTask()
{
    static bool initialized { false };
    if (!initialized) {
        cout << "initializing" << endl;
        // Perform initialization.
        initialized = true;
    }
    // Perform the desired task.
}
```
但是，静态变量容易让人迷惑，在构建代码时通常有更好的方法，可以编写一个类，用构造函数执行所需的初始化操作。
## Static Data Members and Methods

## Static Linkage
`Cpp` 的每个源文件都是单独编译的，编译得到的目标文件会彼此链接。`Cpp` 源文件中的每个名称(包括函数和全局变量)都具有外部或内部的链接，外部链接意味着这个名称在其他源文件中也有效，内部/静态链接意味着在其他源文件中无效。默认情况下，函数和全局变量都具有外部链接，但可以在声明前面加上 `static` 关键字来指定内部/静态链接。
```cpp
// FirstFile.cpp
void f();
int main() {
    f();
}
// AnotherFile.cpp
import <iostream>;
void f();
void f() {
 std::cout << "f\n";
}
```
`AnotherFile` 文件提供函数的原型和定义，在两个不同的文件中为同一个函数编写原型是合法的。如果将原型放在头文件中，并且每个源文件中都用 `#include` 包含这个头文件，那么预处理器就会自动在每个源文件中给出函数原型。
过去使用头文件的原因是，它是更易于维护并保持同步原型的一个副本，但是从 `C++20` 开始，使用模块时建议不要使用头文件。这些源文件中都可以成功编译，并且程序链接也没有问题：因为 `f()` 具有外部链接，`main` 可以从其他文件调用它。
但是，假设对 `AnotherFile.cpp` 中的函数原型应用 `static` 关键字：
```cpp
import <iostream>;
static void f();
// 不需要在函数定义前重复 static
void f() {
    std::cout << "f\n";
}
```
现在，每个源文件都可以正确编译，但是链接时却会失败，这是因为函数具有内部/静态链接，从而使得 `FirstFile.cpp` 无法使用这个函数。
内部链接的另一种方式是使用匿名的名称空间，将变量或函数封装到一个没有名字的名称空间中，而不是使用 `static` 关键字，示例如下：
```cpp
import <iostream>;
namespace {
void f();
    void f() {
    std::cout << "f\n";
    }
}
```
在同一源文件中，可在声明匿名名称空间之后的任何位置访问名称空间中的成员，但不能在其他源文件中访问，这一语义与 `static` 关键字相同。
### Extern
`extern` 可以将它后面的名称指定为外部链接，例如，默认情况下，`const` 和 `typedef` 具有内部链接，可以使用 `extern` 使其变为外部链接。但是，当指定某个名称为 `extern` 时，编译器会将这条语句当作声明，而不是定义。对于变量，这意味着编译器不会为其分配空间，必须为这个变量提供单独的，而不是使用 `extern` 关键字的定义行。例如，下面是 `AnotherFile.cpp` 中的内容：
```cpp
extern int x;
int x { 3 };
// 或者，可以在 extern 语句中初始化x，然后将其作为声明和定义。
extern int x { 3 };
```
在这种情况下，`extern` 不是非常有用，因为默认情况下，`x` 具有外部链接。当另一个源文件 `FirstFile.cpp` 使用 `x` 时，才会真正用到 `extern`：
```cpp
import <iostream>;
extern int x;
int main() {
 std::cout << x << std::endl;
}
```
本例中 `FirstFile.cpp` 使用了 `extern` 声明，因此可以使用 `x`。编译器需要知道 `x` 的声明之后，才能在 `main` 中使用它。然而，如果在声明 `x` 时没有使用 `extern` 关键字，编译器会认为这是一个定义，并为 `x` 分配空间，从而导致链接失败(因为有两个全局作用域的 `x` 变量)。使用 `extern` 关键字，就可以在多个源文件中全局访问这个变量。
### Extern C
`Cpp` 有时需要调用使用其他语言编写的函数，最常见的是调用 `C` 语言函数。对于这些函数，编译器检查其调用的方式与处理普通 `Cpp` 函数的方式相同，但是生成的代码有所区别。
`Cpp` 无法直接调用 `C` 代码，因为二者生成符号的规则不同，`Cpp` 会报错无法解析的外部符号，可以通过 `extern` 告诉编译器按照 `C` 的规则生成符号，从而正确解析。`C` 也无法直接调用 `Cpp` 代码，同样地，在 `Cpp` 中通过 `extern` 告诉编译器按照 `C` 的规则生成符号，从而正确调用。
链接指示包含关键字 `extern`、字符串字面值常量和函数声明，其中的字符串字面值常量指出编写函数所用的语言。通过链接指示定义函数，可以令 `C++` 函数在其他语言编写的程序中可用，编译器会为该函数生成适合于指定语言的代码。
```c++
// the calc function can be called from C programs
extern "C" double calc(double dparm) { /* ... */ }
```
编写函数所使用的语言是函数类型的一部分，因此对于使用链接指示定义的函数来说，它的每个声明都必须使用相同的链接指示，而且指向这类函数的指针也必须使用与函数本身一样的链接指示。
```c++
// pf points to a C function that returns void and takes an int
extern "C" void (*pf)(int);

void (*pf1)(int);   // points to a C++ function

extern "C" void (*pf2)(int);    // points to a C function

// 指向C函数的指针与指向C++函数的指针是不同的类型，两者不能相互赋值或初始化
pf1 = pf2;   // error: pf1 and pf2 have different types
```
链接指示不仅对函数本身有效，对作为返回类型或形参类型的函数指针也有效。所以如果希望给 `C++` 函数传入指向 `C` 函数的指针，必须使用类型别名。
```c++
// f1 is a C function; its parameter is a pointer to a C function
extern "C" void f1(void(*)(int));
// FC is a pointer to a C function
extern "C" typedef void FC(int);
// f2 is a C++ function with a parameter that is a pointer to a C function
void f2(FC *);
```
链接指示与重载函数的相互作用依赖于目标语言，`C` 语言不支持函数重载，所以一个 `C` 链接指示只能用于说明一组重载函数中的某一个。
```c++
// error: two extern "C" functions with the same name
extern "C" void print(const char*);
extern "C" void print(int);
```
链接指示有单个形式和复合形式，其不能出现在类定义或函数定义的内部，同样的链接指示必须出现在函数的每个声明处。
```c++
// illustrative linkage directives that might appear in the C++ header <cstring>

// single-statement linkage directive
extern "C" size_t strlen(const char *);

// compound-statement linkage directive
extern "C" {
    int strcmp(const char*, const char*);
    char *strcat(char*, const char*);
}
```
复合形式的链接指示可以应用于整个头文件。当一个 `#include` 指示被放置在复合链接指示的花括号中时，头文件中的所有函数声明都会被认为是由链接指示的语言编写的。链接指示可以嵌套，因此如果头文件包含自带链接指示的函数，该函数不会受到影响。
```c++
// compound-statement linkage directive
extern "C" {
    #include <string.h>   // C functions that manipulate C-style strings
}
```
## Order of Initialization of Nonlocal Variables
在 `main` 开始之前，将初始化程序中的所有全局变量和静态类数据成员。对于给定源文件中的变量，将按照它们在源文件中出现的顺序进行初始化。
```cpp
class Demo {
public:
    static int x;
};
// Demo::x —定会在 y 之前初始化
int Demo::x { 3 };
int y { 4 };
```
然而，`Cpp` 没有提供规范，用以说明在不同源文件中初始化非局部变量的顺序。如果在某个源文件中有一个全局变量 `x`，在另一个源文件中有一个全局变量 `y`，无法知道哪个全局变量将首先初始化。 
通常，不需要关注这一规范的缺失，但如果某个全局变量或静态变量依赖于另一个变量，就可能引发问题。对象的初始化意味着调用构造函数，全局对象的构造函数可能会访问另一个全局对象，并假定另一个全局对象已经构建。如果这两个全局对象在不同的源文件中声明，就不能指望一个全局对象在另一个全局对象之前构建，也无法控制它们的初始化顺序。不同编译器可能有不同的初始化顺序，即使同一编译器的不同版本也可能如此，甚至在项目中添加另一个源文件也可能影响初始化顺序。
非局部变量的销毁顺序与其初始化顺序相反。对于不同源文件中的非局部变量，初始化的顺序是不确定的，这意味着其销毁的顺序也是不确定的。





```cpp

```

```cpp

```


```cpp

```


```cpp

```


```cpp

```


```cpp

```
