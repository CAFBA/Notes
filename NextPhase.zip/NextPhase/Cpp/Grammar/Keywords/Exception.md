# Exception
## Throwing a exception
在C++中，通过抛出（throwing）一条表达式来引发（raised）一个异常。被抛出的表达式类型和当前的调用链共同决定了应该使用哪段处理代码（handler）来处理该异常。被选中的处理代码是在调用链中与抛出对象类型匹配且距离最近的代码。
执行一个`throw`语句时，跟在`throw`后面的语句将不再执行。程序的控制权从`throw`转移到与之匹配的`catch`语句中。该`catch`可能是同一个函数中的局部`catch`，也可能位于直接或间接调用了发生异常的函数的另一个函数中。控制权的转移意味着两个问题：
- 沿着调用链的函数可能会提前退出。
- 一旦程序开始执行异常处理代码，则沿着调用链创建的对象会被销毁。
抛出异常后，程序暂停执行当前函数并立即寻找对应`catch`语句的过程叫做栈展开（stack unwinding）。栈展开沿着嵌套函数的调用链不断查找，直到找到了与异常匹配的`catch`语句为止。如果没有对应的`catch`语句，则退出主函数后查找过程结束。
- 如果找到了匹配的`catch`语句，则程序进入该子句并执行其中的代码。`catch`语句执行结束后，程序会转移到与`try`块关联的最后一个`catch`语句之后的位置继续执行。
- 如果没有找到匹配的`catch`语句，程序会调用标准库的`terminate`函数，终止运行。
在栈展开过程中，位于调用链上的语句块可能会提前退出，其中的局部对象也会被销毁。如果异常发生在构造函数或者数组及容器的元素初始化过程中，则当前的对象可能只构造了一部分，此时必须确保已构造的成员能被正确销毁。
如果一个块分配了资源，并且在执行资源释放代码前发生了异常，则资源不会被释放。
由于栈展开可能会调用析构函数，因此析构函数不应该抛出不能被它自身处理的异常。即，如果析构函数需要执行某个可能引发异常的操作，则该操作应该被放置在一个`try`语句块中，并在析构函数内部得到处理。实际编程中，析构函数仅仅是释放资源，不太可能引发异常。所有的标准库类型都能确保它们的析构函数不会引发异常。
编译器使用异常抛出表达式对异常对象（exception object）进行拷贝初始化，因此`throw`语句中的表达式必须具有完全类型。如果该表达式是类类型，则相应的类必须含有可访问的析构函数和拷贝/移动构造函数。如果该表达式是数组或函数类型，则表达式会被转换成对应的指针类型。
抛出一条表达式时，该表达式的静态编译类型决定了异常对象的类型。如果`throw`表达式解引用一个基类指针，而该指针实际指向派生类对象，则只有基类部分会被抛出。
抛出指针时必须确保在任何对应的处理代码中，指针指向的对象一定存在。
C++异常是对程序运行过程中发生的异常情况（例如被0除）的一种响应。
异常提供了将控制权从程序的一个部分传递到另一部分的途径。对异常的处理有3个组成部分：
- 引发异常
  throw关键字表示引发异常，紧随其后的值（例如字符串或对象）指出了异常的特征。throw语句实际上是跳转，即命令程序跳到另一条语句。
  执行throw语句类似于执行返回语句，因为它也将终止函数的执行；但throw不是将控制权返回给调用程序，而是导致程序沿函数调用序列后退，直到找到包含try块的函数。throw将程序控制权返回给main( )，在main( )中寻找与引发的异常类型匹配且位于try块的后面的异常处理程序
- 使用处理程序捕获异常
  catch关键字表示捕获异常。处理程序以关键字catch开头，随后是位于括号中的类型声明，它指出了异常处理程序要响应的异常类型；然后是一个用花括号括起的代码块，指出要采取的措施。
  关键字catch表明这是一个处理程序，而char\*s则表明该处理程序与字符串异常匹配。s与函数参数定义极其类似，因为匹配的引发将被赋给s。另外，当异常与该处理程序匹配时，程序将执行括号中的代码。
- 使用try块
  try块标识其中特定的异常可能被激活的代码块，它后面跟一个或多个catch块。try块是由关键字try指示的，关键字try的后面是一个由花括号括起的代码块，表明需要注意这些代码引发的异常。
  如果其中的某条语句导致异常被引发，则后面的catch块将对异常进行处理。执行完try块中的语句后，如果没有引发任何异常，则程序跳过try块后面的catch块，直接执行处理程序后面的第一条语句。
如果函数引发了异常，而没有try块或没有匹配的处理程序时，在默认情况下下，程序最终将调用abort( )函数，但可以修改这种行为。
Abort( )函数的原型位于头文件cstdlib（或stdlib.h）中，其典型实现是向标准错误流（即cerr使用的错误流）发送消息abnormal program termination（程序异常终止），然后终止程序。它还返回一个随实现而异的值，告诉操作系统（如果程序是由另一个程序调用的，则告诉父进程），处理失败。abort( )是否刷新文件缓冲区（用于存储读写到文件中的数据的内存区域）取决于实现。如果愿意，也可以使用exit( )，该函数刷新文件缓冲区，但不显示消息。
调用abort( )函数将直接终止程序，而不是先返回到main( )。一般而言，显示的程序异常中断消息随编译器而异
## Catching an Exception
`catch`语句（catch clause）中的异常声明（exception declaration）类似只包含一个形参的函数形参列表。声明的类型决定了处理代码所能捕获的异常类型。该类型必须是完全类型，可以是左值引用，但不能是右值引用。如果`catch`无须访问抛出的表达式，则可以忽略捕获形参的名字。
进入`catch`语句后，使用异常对象初始化异常声明中的参数。`catch`参数的特性和函数参数类似。
- 如果`catch`的参数类型是非引用类型，则该参数是异常对象的一个副本，改变参数不会影响异常对象本身。
- 如果`catch`的参数类型是引用类型，则该参数是异常对象的一个别名，改变参数就是改变异常对象本身。
- 在继承体系中，如果`catch`的参数类型是基类类型，则可以使用其派生类类型的异常对象对其初始化。
  - `catch`的参数是基类非引用类型时，异常对象会被切除一部分。
  - `catch`的参数是基类引用类型时，以常规方式绑定到异常对象。
异常声明的静态类型决定了`catch`语句所能执行的操作。如果`catch`的参数是基类类型，则无法使用派生类特有的成员。
通常情况下，如果`catch`接受的异常与某个继承体系有关，则最好将`catch`参数定义为引用类型。
查找异常处理代码时，最终结果是第一个与异常匹配的`catch`语句，但这未必是最佳匹配。因此，越特殊的`catch`越应该位于整个`catch`列表的前端。当程序使用具有继承关系的异常时，派生类异常的处理代码应该位于基类异常的处理代码之前。
异常和异常声明的匹配规则比函数参数严格，绝大多数类型转换都不能使用。
- 允许从非常量到常量的类型转换。
- 允许从派生类到基类的类型转换。
- 数组被转换成指向数组元素类型的指针，函数被转换成指向该函数类型的指针。
除此之外，包括标准算术类型转换和类类型转换在内的其他所有转换规则都不能在`catch`匹配过程中使用。
有时一个单独的`catch`语句不能完整处理某个异常。执行完一些校正操作后，当前的`catch`可能会让位于调用链上层的函数继续处理异常。一个`catch`语句通过重新抛出（rethrowing）的操作将异常传递给另一个`catch`语句。重新抛出是一条不包含表达式的`throw`语句。
```c++
throw;
```
空`throw`语句只能出现在`catch`或`catch`语句调用的函数之内。如果在异常处理代码之外的区域遇到了空`throw`语句，编译器将调用`terminate`函数。
重新抛出语句不指定新的表达式，而是将当前的异常对象沿着调用链向上传递。如果`catch`语句修改了其参数并重新抛出异常，则只有当`catch`异常声明是引用类型时，程序对参数所做的改变才会被保留并继续传播。
```c++
catch (my_error &eObj)
{   // specifier is a reference type
    eObj.status = errCodes::severeErr;  // modifies the exception
    object
    throw;   // the status member of the exception object is severeErr
}

catch (other_error eObj)
{   // specifier is a nonreference type
    eObj.status = errCodes::badErr;     // modifies the local copy only
    throw;   // the status member of the exception object is unchanged
}
```
使用省略号`...`作为异常声明可以一次性捕获所有异常，这种处理代码被称为捕获所有异常（catch-all）的处理代码，可以与任意类型的异常相匹配。
```c++
try
{
    // actions that cause an exception to be thrown
}
catch (...)
{
    // work to partially handle the exception
    throw;
}
```
`catch(…)`通常与重新抛出语句一起使用。
如果`catch(…)`与其他`catch`语句一起使用，则`catch(…)`必须位于最后，否则`catch(…)`后面的`catch`语句永远不会被匹配。
> 引发异常时编译器总是创建一个临时拷贝，即使异常规范和catch块中指定的是引用。
> 原因：如果try块中的函数中有自动变量抛出异常，这个变量将会不复存在，所以需要拷贝其副本，但catch捕捉时如果以by-value捕捉，又会拷贝一次
### Catch by pointer
理论上，将一个exception从抛出端搬移到捕捉端，必然是个缓慢的过程（ME15），而by pointer应该是最有效率的一种做法。因为throw by pointer是唯一在搬移异常相关信息时不需复制对象的一种做法。例如
```c++
class exception （ ... );//来自C++标准程序库的exception 继承体系（见条款12）。
void someFunction () {
	static exception ex;
	throw &ex;//抛出一个指针，指向 ex。
}
void doSomething () {
    try {
        someFunction ();//可能抛出一个 exception*
    }
    catch (exception *ex) {...}
    //捕捉到exception*, 没有任何对象被复制。
}
```
这看起来十分优雅整齐，但是它并不像你所看到得那么好。为了让这段代码能够运行，程序员必须有办法让exception objects在控制权离开那个抛出指针的函数之后依然存在。Global对象及static对象都没问题，但程序员很容易忘记这项约束。于是，他们常常写出这样的代码：
```c++
void someFunction () {
	exception ex;//局部的 exception object，将在此函数结束时被销毁。
	throw &ex;//抛出一个指针，指向即将被销毁的对象。
}
```
这是很糟糕的情况，因为catch子句所收到的指针，指向不复存在的对象。
另一种做法是抛出一个指针，指向一个新的heap object：
```c++
void someFunction () {
	throw new exception; 
	//抛出一个指针,指向一个新的heap-based object,并假设operator new本身不会抛出exception
}
```
这避免了我捕捉到一个指针，它却指向一个已不存在的对象问题。但是现在catch 子句的作者遭遇了一个更难缠的问题：他们应该删除他们获得的指针吗？如果 exception object 被分配于heap，他们必须删除，否则便会泄漏资源。如果exception object不是被分配于heap，他们就不必删除之，否则便会招致未受定义的程序行为。该怎么做才好呢？没有人知道该怎么做才好。
此外， catch-by-pointer和语言本身建立起来的惯例有所矛盾。4个标准的exceptions ：bad_alloc （当 operator new （条款8）无法满足内存需求时发出）、bad_cast （当对一个 reference施行dynamic_cast失败时发出，见条款2）bad_typeid（当 dynamic_cast 被实施于一个 null 指针时发出）、bad_exception（适用于未预期的异常情况，见条款14）——统统都是对象，不是对象指针。所以你**无论如何必须以by value或by reference的方式捕捉它们**
### Catch-by-value
catch-by-value可以消除上述exception是否需要删除及与标准的exception不一致等问题。然而在此情况下，每当exception objects被抛出，就得复制两次(ME12)。此外它也会引起切割问题，因为**derived class exception objects 被捕捉并被视为base class exceptions者，将失去其派生成分**。如此被切割过的对象其实就是base class objects: 它缺少 derived class data members，当虚函数在其上被调用时，会被解析为base class的虚函数（这和对象以by value方式传递给函数时所发生的事情一样—见E22）。
> 在值语义的情况下，派生类对象赋值给基类对象，派生类独有独有的数据会丢失。但是在指针、引用情况下，由于多态性，可以将派生类对象的指针赋值给基类指针，而不会导致对象切片

例如，考虑一个应用程序，采用exception class标准继承体系的一个扩充版本：
```c++
class exception (// 如上所述，这是标准的exception class.
	public：
		virtual const char * what () throw ();//返回此 exception的一份简要描述。
）；
class runtime_error: public exception {...}；//也是来自C++标准的exception 继承体系
class Validation_error:public runtime_error{//这是用户新增的一个 class
    public：
    	virtual const char * what () throw ();
    	//重新定义先前 class exception 内声明的函数。
}；
void someFunction () {//可能会抛出一个有效的 exception.	
	if (a validation test fails) throw Validation_error ();
}
void doSomething () {
	try {
		someFunction ()	//可能会抛出一个有效的exception。
	}
	catch (exception ex) {//捕捉标准继承体系内的所有exceptions （或其派生类）
		cerr << ex.what ();//调用的是 exception::what()而非validation_error::what()
	}
}
```
即使被抛出的exception属于Validation_error 类型，validation_error 重新定义了虚函数 what，被调用的what函数仍然是base class版。这种切割行为几乎不会是你所要的。
###  Catch-by-reference
catch-by-reference不需要蒙受我们所讨论的任何问题。它不像 catch-by-pointer，不会发生对象删除问题，因此也就不难捕捉标准的exception。它和 catch-by-value也不同，所以没有切割问题，而且exception objects 只会被复制一次。
如果使用 catch-by-reference重写上一个例子，结果如下：
```c++
void someFunction () {//可能会抛出一个有效的 exception.	
	if (a validation test fails) throw Validation_error ();
}
void doSomething () {
	try {
		someFunction ()	//可能会抛出一个有效的exception。
	}
	catch (exception& ex) {//改用 catch by reference 取代 catch by value.
		cerr << ex.what ();
		//现在调用的是 Validation_error::what()而非exception::what()
	}
}
```
抛出端没有任何改变， catch子句内的唯一改变是增加了一个&符号。然而这个微小的修改成就了一个极大的不同，因为catch语句块内所调用的虚函数，调用的是我们所期望的：validation_error中的函数会被调用—如果它们重新定义了exception内的虚函数的话。
引用还有另一个重要特征：基类引用可以指向派生类对象。假设有一组通过继承关联起来的异常类型，则在异常规范中只需列出一个基类引用，它将与任何派生类对象匹配。
假设有一个异常类层次结构，并要分别处理不同的异常类型，则使用基类引用将能够捕获任何异常对象；而使用派生类对象只能捕获它所属类及从这个类派生而来的类的对象。引发的异常对象将被第一个与之匹配的catch块捕获。这意味着catch块的排列顺序应该与派生顺序相反：
![image-20220415193801256](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220415193801256-16507561085204.png)
如果将bad_1 &处理程序放在最前面，它将捕获异常bad_1、bad_2和bad_3；通过按相反的顺序排列，bad_3异常将被bad_3 &处理程序所捕获。
> 如果有一个异常类继承层次结构，应这样排列catch块：将捕获位于层次结构最下面的异常类的catch语句放在最前面，将捕获基类异常的catch语句放在最后面。
> 如果知道一些可能会引发的异常，可以将上述捕获所有异常的catch块（即基类的catch块）放在最后面

如果catch by reference，你就可以避开对象删除问题，你也可以避开 exception objects的切割问题；你可以保留捕捉标准 exceptions的能力；你也约束了exception objects 需被复制的次数。所以什么才是你要的呢? Catch exceptions by reference! 
## Exception类
C++ 已经为处理异常设计了一个配套的异常类型体系，定义在标准库的 `<stdexcept>` 头文件里
在抛出异常的时候，最好不要直接用 throw 关键字，而是要封装成一个函数，这和不要直接用 new、delete 关键字是类似的道理——通过引入一个“中间层”来获得更多的可读性、安全性和灵活性。抛异常的函数不会有返回值，所以应该用属性做编译阶段优化：
```c++
[[noreturn]]                      // 属性标签
void raise(const char* msg)      // 函数封装throw，没有返回值
{
    throw my_exception(msg);     // 抛出异常，也可以有更多的逻辑
}

try {
    raise("error occured");     // 函数封装throw，抛出异常
}
catch(const exception& e)      // const &捕获异常，可以用基类
{
    cout << e.what() << endl;  // what()是exception的虚函数
}
```
## 异常的问题
- 异常违反了“你不用就不需要付出代价”的 C++ 原则。只要开启了异常，即使不使用异常你编译出的二进制代码通常也会膨胀。
- 异常比较隐蔽，不容易看出来哪些地方会发生异常和发生什么异常。
对避免异常带来的问题有几点建议：
- 写异常安全的代码，尤其在模板里。可能的话，提供强异常安全保证，在任何第三方代码发生异常的情况下，不改变对象的内容，也不产生任何资源泄漏。
- 如果你的代码可能抛出异常的话，在文档里明确声明可能发生的异常类型和发生条件。确保使用你的代码的人，能在不检查你的实现的情况下，了解需要准备处理哪些异常。
- 对于肯定不会抛出异常的代码，将其标为 noexcept。尤其是，移动构造函数、移动赋值运算符和 swap 函数一般需要保证不抛异常并标为 noexcept（析构函数通常不抛异常且自动默认为 noexcept，不需要标）。
## Function try block and ctor
所谓 function-try，就是把整个函数体视为一个大 try 块，而 catch 块放在后面，与函数体同级并列：
```c++
void some_function()
try                          // 函数名之后直接写try块
{
    ...
}
catch(...)                   // catch块与函数体同级并列
{
    ...
}
```
这样做的好处很明显，不仅能够捕获函数执行过程中所有可能产生的异常，而且少一级缩进层次，处理逻辑更清晰。
要想处理构造函数初始值列表抛出的异常，必须将构造函数写成函数`try`语句块（function try block）的形式。函数`try`语句块使得一组`catch`语句可以同时处理构造函数体和构造函数初始化过程中的异常。
```c++
template <typename T>
Blob<T>::Blob(std::initializer_list<T> il) try :
    data(std::make_shared<std::vector<T>>(il))
{
    /* empty body */
}
catch(const std::bad_alloc &e)
{
    handle_out_of_memory(e);
}
```
函数`try`语句块的`catch`语句会在结尾处隐式地重新抛出异常，通知上层函数对象构造失败。上层函数需要继续处理该异常。但在初始化构造函数参数时发生的异常不属于函数`try`语句块处理的范围。
## Noexcept
在C++11中，可以通过提供`noexcept`说明来指出某个函数不会抛出异常，指明某个函数不会抛出异常可以让调用者不必再考虑异常处理操作，并告诉编译器：这个函数不会抛出异常。编译器看到 noexcept，就得到了一个保证，就可以对函数做优化，不去加那些栈展开的额外代码，消除异常处理的成本。
```c++
void recoup(int) noexcept;  // won't throw
void alloc(int);            // might throw
```
`noexcept`说明的出现位置：
- 关键字`noexcept`位于函数的参数列表之后，尾置返回类型之前。
- 对于一个函数来说，**`noexcept`说明必须同时出现在该函数的所有声明和定义语句中**。
- 函数指针的声明和定义也可以指定`noexcept`。
- 在`typedef`或类型别名中不能使用`noexcept`。
- 在成员函数中，关键字`noexcept`位于`const`或引用限定符之后，`final`、`override`或虚函数的`=0`之前。
编译器并不会在编译时检查`noexcept`说明。如果一个函数在指定了`noexcept`的同时又含有`throw`语句或其他可能抛出异常的操作，仍然会通过编译（个别编译器可能会提出警告）。
```c++
// this function will compile, even though it clearly violates its exception specification
void f() noexcept   // promises not to throw any exception {
    throw exception();   // violates the exception specification
}
```
一旦`noexcept`函数抛出异常，程序会调用`terminate`函数终止运行（该过程是否执行栈展开未作规定）。因此`noexcept`可以用于两种情况：
- 确认函数不会抛出异常。
- 不知道该如何处理函数抛出的异常。
早期的C++版本设计了一套更详细的异常说明方案。函数可以使用一个关键字`throw`，后面跟上用括号包围的异常类型列表，用于指定函数可能抛出的异常类型。关键字`throw`出现的位置与C++11的`noexcept`相同。该方案在C++11中被取消。但**如果一个函数被声明为`throw()`的，则也说明该函数不会抛出异常**。
```c++
void recoup(int) noexcept;   // recoup doesn't throw
void recoup(int) throw();   // equivalent declaration
```
`noexcept`说明符接受一个可选的实参，该实参必须能转换为`bool`类型。如果实参为`true`，则函数不会抛出异常；如果实参为`false`，则函数可能抛出异常。
```c++
void recoup(int) noexcept(true);    // recoup won't throw
void alloc(int) noexcept(false);    // alloc can throw
```
`noexcept`运算符（noexcept operator）是一个一元运算符，**返回`bool`类型的右值常量表达式，表示给定的运算对象是否会抛出异常**。和`sizeof`类似，`noexcept`运算符也不会对运算对象求值。
```c++
noexcept(e)
```
当`e`调用的函数都含有`noexcept`说明且`e`本身不含有`throw`语句时，上述表达式返回`true`，否则返回`false`。
`noexcept`运算符通常在`noexcept`说明符的实参中使用。
```c++
void f() noexcept(noexcept(g()));   // f has same exception specifier as g
```
函数指针与该指针指向的函数必须具有一致的异常说明。如果某个函数指针是`noexcept`的，则该指针只能指向`noexcept`函数；如果显式或隐式地说明了函数指针可能抛出异常，则该指针可以指向任何函数。
```c++
// both recoup and pf1 promise not to throw
void (*pf1)(int) noexcept = recoup;
// ok: recoup won't throw; it doesn't matter that pf2 might
void (*pf2)(int) = recoup;
pf1 = alloc;    // error: alloc might throw but pf1 said it wouldn't
pf2 = alloc;    // ok: both pf2 and alloc might throw
```
如果一个虚函数是`noexcept`的，则后续派生出来的虚函数必须也是`noexcept`的。如果基类的虚函数允许抛出异常，则派生类的对应函数既可以允许，也可以禁止抛出异常。
> 只有析构函数默认有 noexcept 声明（前提是所有的基类和成员变量的析构函数都 noexcept）。构造函数函数如果不是 default 声明的话，仍需手工标 noexcept。
```c++
class Base {
public:
    virtual double f1(double) noexcept;   // doesn't throw
    virtual int f2() noexcept(false);   // can throw
    virtual void f3();   // can throw
};

class Derived : public Base
{
public:
    double f1(double);   // error: Base::f1 promises not to throw
    int f2() noexcept(false);   // ok: same specification as Base::f2
    void f3() noexcept;   // ok: Derived f3 is more restrictive
};
```
## 栈解退
假设try块没有直接调用引发异常的函数，而是调用了对引发异常的函数进行调用的函数，则程序流程将从引发异常的函数跳到包含try块和处理程序的函数
C++通常通过将信息放在栈中来处理函数调用，将调用函数的指令的地址（返回地址）放到栈中，当被调用的函数执行完毕后，程序将使用该地址来确定从哪里开始继续执行。函数调用将函数参数放到栈中。在栈中，这些函数参数被视为自动变量。如果被调用的函数创建了新的自动变量，则这些变量也将被添加到栈中。如果被调用的函数调用了另一个函数，则后者的信息将被添加到栈中，依此类推。当函数结束时，程序流程将跳到该函数被调用时存储的地址处，同时栈顶的元素被释放。
因此，函数通常都返回到调用它的函数，依此类推，同时每个函数都在结束时释放其自动变量。如果自动变量是类对象，则类的析构函数（如果有的话）将被调用。
现在假设**函数由于出现异常（而不是由于返回）而终止，则程序也将释放栈中的内存，但不会在释放栈的第一个返回地址后停止，而是继续释放栈，直到找到一个位于try块中的返回地址。随后，控制权将转到块尾的异常处理程序，而不是函数调用后面的第一条语句。这个过程被称为栈解退**。
**函数返回仅仅处理该函数放在栈中的对象，而throw语句则处理try块和throw之间整个函数调用序列放在栈中的对象**。因此**对于栈中的自动类对象，类的析构函数将被调用**。如果没有栈解退这种特性，则引发异常后，对于中间函数调用放在栈中的自动类对象，其析构函数将不会被调用。
![image-20220415185545422](D:\BaiduSyncdisk\Resource\Picture\image-20220415185545422-16507561004952.png)
> 上图中一旦抛出异常，函数内……的内容都不会触发
> 直接会执行catch的内容，之后紧接执行catch后的第一条语句

main函数调用mean函数，mean函数调用的hmean函数和gmean函数抛出异常，则返回到调用抛出异常函数的mean函数处，看是否有处理异常的try-catch组合，而mean函数有处理hmean函数的组合，处理后又抛出异常，则再返回到调用抛出异常函数（这时候抛出异常的函数为mean函数）的main函数处。但gmean函数没有这种组合，则继续返回一级，即到main函数，看是否有这种组合，结果main函数有这种组合
```c++
double hmean(double a, double b) {
	if(a == -b)
		throw bad_hmean(a, b);
	return 2.0 * a * b / (a + b);
}
double gmean(double a, double b) {
	if(a < 0 || b < 0)
		throw bad_gmean(a, b);
	return sqrt(a * b);
}
double mean(double a, double b) {
	double am, hm, gm;
	am = (a + b) / 2.0;
	try	{
		hm = hmean(a, b);
		gm = gmean(a, b);
	}
	catch(bad_hmean &bh) {
		bh.mesg();
		cout << "1) expception" << endl;
		throw;
	}
	return (am + hm + gm) / 3.0;
}

int main(){
	double x, y, z;
	while(cin >> x >> y) {
		try {
			z = mean(x, y);
			cout << "The mean mean of " << x << " and " << y << " is " << z << endl;
		}
		catch(bad_hmean &bh) {
			bh.mesg();
			cout << "2) exception" << endl;
			cout << "Enter a new pair of arguments:";
			continue;
		}
		catch(bad_gmean &bg) {
			cout << bg.mesg();
			cout << "Value used: " << bg.v1 << ", " << bg.v2 << endl;
			cout << "Sorry, quit now" << endl;
			break;
		}
	}
	return 0;
}
```
## 异常与资源泄漏
### 在Destructors阻止资源泄漏
举个例子，你正在为小动物收养保护中心（一个专门为小狗小猫寻找收养家庭的组织）编写一个软件。收养中心每天都会产生一个文件，其中有它所安排的当天收养个案。你的工作就是写一个程序，读这些文件，然后为每一个收养个案做适当处理。
合理的想法是定义一个抽象基类ALA ，再从中派生出针对小狗和小猫的具体类。其中有个虚函数 processAdoption，负责因动物种类而异的必要处理动作。
```c++
class ALA {
	public:
		virtual void processAdoption() = 0; 
};
class Puppy: public ALA{ 
	public:
		virtual void processAdoption(); 
};

class Kitten:public ALA{ 
	public:
		virtual void processAdoption(); 
};

ALA *readALA(istream& s);
//读取文件内容，并视文件内容产生一个 Puppy object 或一个Kitten object。
//从s读取动物信息，然后返回一个指针，指向一个新分配的对象，有着适当的类型（Puppy或Kitten）。

void processAdoptions(istream& dataSource) {
	while (datasource){//如果还有数据， 
        ALA *pa = readALA(dataSource);//取出下一只动物，
        pa->processAdoption();//处理收养对象
        delete pa;//每当readALA被调用，便产生一个新的heap object，删除 readALA 返回的对象。
    }
}
```
现在请考虑：如果pa->processAdoption抛出一个exception，会发生什么事情。processAdoptions无法捕捉它，所以这个 exception 会传播到processAdoptions的调用端。processAdoptions 函数内位于pa->processAdoption之后的所有语句都会被跳过，不再执行，这也意味pa不会被删除。结果呢，只要pa->processAdoption抛出一个exception， processAdoptions便发生一次资源泄漏。
要避免这一点，很简单：
```c++
void processAdoptions(istream& dataSource) {
	while(dataSource){
		ALA *pa = readALA(dataSource); 
		try{
			pa->processAdoption(); 
		}
		catch(...){//捕捉所有的 exceptions。 
			delete pa;//当 exception 被抛出，避免资源泄漏。
			throw;//将 exception 传播给调用端。 
		}
		delete pa;//如果没有 exception 被抛出，也要避免资源泄漏。
	}
}
```
但你的程序因而被 try 语句块和 catch 语句块搞得乱七八糟。更重要的是，你被迫重复撰写其实可被正常路线和异常路线共享的清理代码(本例指的是 delete 动作)。这对程序的维护造成困扰，撰写时很烦人，感觉也不理想。不论我们是以正常方式或异常方式（抛出一个 exception）离开  processAdoptions  函 数，我们都需要删除pa，那么何不集中于一处做这件事情呢？
其实不必大费周章，只要我们能够将一定得执行的清理代码移到processAdoptions 函数的某个局部对象的 destructor 内即可。因为**局部对象总是会在函数结束时被析构，不论函数如何结束（唯一例外是你调用  longjmp  而结束。 longjmp 的这个缺点正是C＋＋支持 exceptions的最初的主要原因）**。于是，我们真正感兴趣的是，如何把 delete 动作从  processAdoptions  函数移到函数内某个局部对象的 destructor 内。
解决办法就是，以一个类似指针的对象取代指针 pa。如此一来，当这个类似指针的对象被（自动）销毁，我们可以令其 destructor 调用 delete。行为类似指针（但动作更多）的对象我们称为 smart pointers，我们只要求它在被销毁（由于即将离开其scope）之前删除它所指的对象，就可以了
每个 auto_ptr  的 constructor 都要求获得一个指向 heap object 的指针；其 destructor 会将该 heap object 删除。如果只显示这些基本功能， auto_ptr  看起来像这样：
```c++
template<class T> class auto_ptr{ 
	public:
		auto_ptr(T *p = 0):ptr(p){}//存储对象。 
		~auto_ptr() { delete ptr;}//删除对象。 
	private:
		T *ptr;// 原始指针（指向对象）。
};
```
考虑图形界面（GUI）应用软件中的某个函数，它必须产生一个窗口以显示某些信息：
```c++
void displayInfo(const Information& info) {
	WINDOW_HANDLE w(createWindow());
	display info in window corresponding to w; 
	destroyWindow(w);
}
```
许多窗口系统都有C 语言接口，运行诸如 createWindow 和 destroyWindow 这类函数，取得或释放窗口（被视为一种资源）。如果在信息显示于w的过程中发生exception，w所持有的那个窗口将会遗失，其他动态分配的任何资源也会遗失。解决之道和先前一样，设计一个 class，令其 constructor 和 destructor 分别取得资源和释放资源：
```c++
class WindowHandle{
	public:
		WindowHandle (WINDOW_HANDLE handle): w(handle){} 
		~WindowHandle() { destroyWindow(w); }
		operator WINDOW_HANDLE() { return w; }
	private:
		WINDOW_HANDLE w;
	//以下函数被声明为 private，用以阻止产生多个 WINDOW＿HANDLE。条款28讨论了一个更弹性的做法。
        WindowHandle(const WindowHandle&);
        WindowHandle& operator=(const WindowHandle&); 
};

//有了这个 WindowHandle class，我们可以重写 displayInfo 如下：
void displayInfo(const Information& info) {
	WindowHandle w(createWindow());
	display info in window corresponding to w; 
}
```
现在即使 displayInfo 函数内抛出 exception，createWindow 所产生的窗口还是会被销毁。
只要坚持这个规则，把资源封装在对象内，通常便可以在 exceptions 出现时避免泄漏资源。
但如果 exception 是在你正取得资源的过程中抛出的，例如在一个正在抓取资源的 class constructor 内，会发生什么事呢？如果 exception 是在此类资源的自动析构过程中抛出的，又会发生什么事呢？此情况下 constructors 和destructors 是否需要特殊设计？是的，它们需要，你可以在条款10和条款11中学到这些技术。
### 在Constructors 阻止资源泄漏
想象你正在开发一个多媒体通信簿软件。这个软件可以放置包括人名、地址、电话号码等文字，以及一张个人相片和一段个人声音（或许是其姓名的发音）。
每一个 BookEntry 都必须有姓名数据，所以它必须成为一个constructor 自变量（见ME3），但是其他字段—个人地址及相片文件和声音文件—都可有可无。
BookEntry constructor 和 destructor 可以直截了当地这么设计：
```c++
//类的数据成员如下
//string name, address;
//Image *theImage;
//AudioClip *theAudioclip;
BookEntry::BookEntry(const string& name,const string& address, 
					const string& imageFileName,
					const string& audioClipFileName) 
			:theName (name), theAddress (address) ,theImage(0), theAudioClip(0) {
				if (imageFileName != "") {
					theImage = new Image(imageFileName); 
				}
				if (audioclipFileName != "") {
					theAudioClip = new AudioClip(audioClipFileName); 
				}
}

BookEntry::~BookEntry() {
	delete theImage; 
	delete theAudioClip; 
}
```
其中 constructor 先将指针 theImage 和 theAudioClip 初始化为 null；如果对应的自变量不是空字符串，再让它们指向真正的对象。destructor 负责删除上述两个指针，确保 BookEntry object 不会造成资源泄漏问题。由于C＋＋保证删除 null指针是安全的，所以 BookEntry destructor 不必在删除指针之前先检查它们是否真正指向某些东西。
每件事看起来都很好，正常情况下每件事也的确很好，但是在不正常的情况下在 exception 出现的情况下—事情一点也不好。
当程序执行 BookEntry constructor 的以下部分，如果有个 exception 被抛出， 会发生什么事？
```c++
if (audioClipFileName != ""){
	theAudioClip = new AudioClip(audioClipFileName); 
}
```
> exception 的发生可能是由于operator new（见ME8）无法分配足够的内存给一个 AudioClip object 使用，也可能是因为 AudioClip constructor 本身抛出一个 exception。不论原因为何，只要是在 BookEntry constructor 内抛出，就会被传播到正在产生 BookEntry object 的那一端。

现在，如果在产生原本准备让 theAudioclip 指向的对象时，发生了一个exception，控制权因而移出 BookEntry constructor 之外，谁来删除 theImage 已经指向的那个对象呢？明显的答案是由 BookEntry destructor 来执行，但是这个明显的答案是个错误答案。BookEntry 的destructor 绝不会被调用，绝对不会。
**C＋＋只会析构已构造完成的对象，对象只有在其 constructor 执行完毕才算是完全构造妥当**。所以如果程序打算产生一个局部性的  BookEntry object b ，而 exception 在b的构造过程中被抛出，b 的 destructor 就不会被调用。
```c++
void testBookEntryClass() {
	BookEntry b("Addison-Wesley Publishing Company",
	"One Jacob Way, Reading, MA 01867"); 
}
```
如果你尝试更深入地参与，将b分配于 heap 中，并在 exccption 出现时调用delete:
```c++
void testBookEntryclass() {
	BookEntry *pb = 0; 
	try{
		pb = new BookEntry("Addison-Wesley Publishing Company",
			"One Jacob Way, Reading, MA 01867"); 
	}
	catch(...){//捕捉所有的 exceptions。 
		delete pb;//当 exception 被抛出，删除 pb。 
		throw;//将 exception 传给调用者。 
	}
	delete pb;//正常情况下删除 pb。
}
```
你会发现 BookEntry constructor 所分配的 Image object 还是泄漏了。因为除非 new 动作成功，否则上述那个 assignment（赋值）动作并不会施加于pb身上。如果 BookEntry constructor 抛出一个 exception，pb 将成为 null 指针，此时在 catch 语句块中删除它，除了让你感觉比较爽之外，别无其他作用。以 smart pointerclass auto＿ptr＜BookEntry＞（见ME9）取代原始的 BookEntry＊，也不会让情况好转，因为除非 new 动作成功，否则对pb的赋值动作还是不会进行。
> 面对尚未完全构造好的对象，为什么C＋拒绝调用其 destructor呢？它可不是为了让你痛苦而做成这样的设计的。是的，这是有理由的。如果那么做，许多时候会是一件没有意义的事，甚至是一件有害的事。如果 destructor 被调用于一个尚未完全构造好的对象身上，这个destructor 如何知道该做些什么事呢？它唯一能够知道的机会就是：被加到对象内的那些数据身上附带有某种指示，指示constructor 进行到什么程度。那么 destructor就可以检查这些数据并（或许能够）理解应该如何应对。如此繁重的簿记工作会降低 constructors的速度，使每一个对象变得更庞大。C＋＋避免这样的额外开销，但你必须付出仅部分构造完成的对象不会被自动销毁的代价（条款E13有另一个效率与程序行为之间的类似取舍决定）。

**由于C＋＋不自动清理那些构造期间抛出 exceptions的对象，所以你必须设计你的 constructors，使它们在那种情况下亦能自我清理**。通常这只需将所有可能的exceptions 捕捉起来，执行某种清理工作，然后重新抛出 exception，使它继续传播出去即可。这个策略可以这样纳入 BookEntry constructor：
```c++
BookEntry::BookEntry(const string& name,const string& address, 
					const string& imageFileName,
					const string& audioClipFileName) 
			:theName (name), theAddress (address) ,theImage(0), theAudioClip(0) 
{
			try {
				if (imageFileName != "") {
					theImage = new Image(imageFileName); 
				}
				if (audioclipfilename != "") {
					theAudioClip = new AudioClip(audioClipFileName); 
				}
			}
			catch(...) {
				delete theImage;
				delete theAudioclip;
				throw;
			}
}
```
不需要担心 BookEntry 的  non-pointer data members 。Data members 会在class constructor 被调用之前就先初始化好（因为此处使用了 member initialization list，成员初值链表），所以当BookEntry constructor 函数本体开始执行，该对象的 theName，theAddress 和thePhones 等 data members 都已完全构造好了。所以当 BookEntry object 被销毁，其所内含的这些 data members 就像构造完全的对象一样，也会被自动销毁，无须你插手。当然，如果这些对象的 constructors 调用其他函数，而那些函数可能抛出 exceptions，那么这些 constructors 就必须负责捕捉 exceptions，并在继续传播它们之前先执行任何必要的清理工作。
你可能已经注意到，BookEntry 的catch 语句块内的动作和 BookEntry的 destructor 内的动作相同。我们一向不遗余力地希望消除重复代码，这里也是一样的，所以最好是把共享代码抽出放进一个 private 辅助函数内，然后让 constructor 和destructor 都调用它：
```c++
class BookEntry{ 
	public:
		...
	private:
		...
		void cleanup();//共同的清理（clean up）动作放在这里。
};
void BookEntry::cleanup() {
	delete theImage; 
	delete theAudioclip; 
}

BookEntry::BookEntry(const string& name,const string& address, 
					const string& imageFileName,
					const string& audioClipFileName) 
			:theName (name), theAddress (address) ,theImage(0), theAudioClip(0) 
{
			try {
				if (imageFileName != "") {
					theImage = new Image(imageFileName); 
				}
				if (audioclipfilename != "") {
					theAudioClip = new AudioClip(audioClipFileName); 
				}
			}
			catch (...) { 
				cleanup();
				throw;
			}
}

BookEntry::~BookEntry() {
	cleanup();
}
```
让我们稍加变化，让 theImage 和theAudioClip 都变成常量指针：
```c++
class BookEntry { 
	public:
		...
	private:
		Image * const theImage;
	    AudioClip * const theAudioclip;//这些指针都是 const。
};
```
**这样的指针必须通过 BookEntry constructors 的成员初值链表加以初始化，因为再没有其他方法可以给予 const 指针一个值（见条款E12）**。一个常见的做法就是像下面这样给予theImage 和theAudioClip 初值：
```c++
BookEntry::BookEntry(const string& name,
 					const string& address, 
 					const string& imageFileName,
 					const string& audioClipFileName)
:theName(name), theAddress (address),
 theImage(imageFileName != "" ? new Image(imageFileName) : 0),
 theAudioC1ip(audioClipFileName != "" ? new AudioClip(audioClipFileName) : 0) {}
```
但这却导致我们最初极力想消除的问题：如果在 theAudioClip 初始化期间发生exception，theImage 所指对象并不会被销毁。此外，我们也无法借此在 constructor 内加上 try/catch 语句块来解决此问题，因为 try 和 catch 都是语句（statements），而 member initialization lists 只接受表达式（expressions）。这就是为什么我们必须使用 ?: 操作符取代  if-then-else  语法来为 theImage 和theAudioClip 设定初值的原因。
尽管如此，欲在exceptions 传播至 constructor 外之前执行清理工作，唯一的机会就是捕捉那些exceptions。所以既然我们无法将try和catch放到一个member initialization list之中，势必得将它们放到其他某处。一个可能的地点就是放到某些private member functions 内，让 theImage 和theAudioclip 在其中获得初值：
```c++
class BookEntry{
	public:
		//与前同。 
	private:
		//data members 与前同。 
		Image * initImage(const string& imageFileName); 
		AudioClip * initAudioClip(const string& audioClipFileName); 
};

BookEntry::BookEntry(const string& name,
					 const string& address, 
					 const string& imageFileName,
					 const string& audioClipFileName) 
:theName(name), theAddress (address), theImage(initImage(imageFileName)),
 theAudioClip(initAudioClip(audioClipFileName)) 
 
//theImage 首先被初始化，如果它初始化失败，其成员Image会调用自己的析构函数处理那个临时对象，所以即使初始化失败亦无须担心资源泄漏问题。
//因此本函数不必处理任何 exceptions。

Image * BookEntry::initImage(const string& imageFileName) {
	if (imageFileName != "") return new Image(imageileame); 
	else return 0;
}

//theAudioClip第二个被初始化，所以如果在它初始化期间有exception被抛出，控制权因而移出constructor之外将不会有人删除theImage已经指向的那个对象
//注意，正是因为已经指向，所以不会有人删除，那么必须确定将 theImage 的资源释放掉。这就是为什么本函数使用 try...catch的原因。
AudioClip * BookEntry::initAudioClip(const string& audioClipFileName) {
	try{
		if (audioClipFileName != ""){
			return new AudioClip(audioCclipFileName); 
		}
		else return 0; 
	}
	catch(...){ 
        delete theImage; 
        throw;
    } 
}
```
这是个完美的结局，它解决了使我们左支右绌疲于奔命的问题。缺点是：概念上应该由 constructor 完成的动作现在却散布于数个函数中，造成维护上的困扰。
一个更好的解答是，接受条款9的忠告，将theImage 和 theAudioClip 所指对象视为资源，交给局部对象来管理。这个办法立足所依据的事实是，不论theImage 和 theAudioclip 都是指向动态分配而得的对象，当指针本身停止活动，那些对象都应该被删除。这正是 auto_ptr class（见条款9）的设计目的。以我们可以将 theImage 和theAudioclip 的原始指针类型改为 auto_ptr： 
```c++
class BookEntry{
	public:
		//与前同。 
	private:
		const auto_ptr<Image> theImage;//const 与 auto_ptr 的关系是什么
		const auto_ptr<AudioClip> theAudioclip;
};

//这么做便可以让 BookEntry constructor在异常出现时免于资源泄漏的恐惧
//也让我们得以利用 member initialization list 将 theImage 和 theAudioclip 初始化： 
BookEntry::BookEntry   (const string& name,
 					   const string& address, 
 					   const string& imageFileName,
 					   const string& audioClipFileName)
:theName(name), theAddress (address),
 theImage(imageFileName != "" ? new Image(imageFileName) : 0),
 theAudioC1ip(audioClipFileName != "" ? new AudioClip(audioClipFileName) : 0) {}
```
在此设计中，如果 theAudioClip 初始化期间有任何 exception 被抛出， theImage 已经是完整构造好的对象，所以它会被自动销毁，就像 theName，theAddress 和thePhones 一样。此外，由于 theImage 和 theAudioClip 如今都是对象，当其宿主BookEntry 被销毁，它们亦将被自动销毁。因此不再需要以手动方式删除它们所指的对象。这会大幅简化 BookEntry destructor：
```c
BookEntry::~BookEntry(){}//不需要做什么事！意味你可以完全摆脱 BookEntry destructor。
```
结论是：如果你以 auto_ptr 对象来取代 pointer class members，你便对你的 constructors 做了强化工事，免除了exceptions 出现时发生资源泄漏的危机，不再需要在 destructors 内亲自动手释放资源，并允许 const member pointers 得以和 non-const member pointers有着一样优雅的处理方式。
### 禁止异常流出Destructors之外
两种情况下destructor会被调用。
第一种情况是当对象在正常状态下被销毁，也就是当它离开了它的生存空间或是被明确地删除；
第二种情况是当对象被exception处理机制。也就是exception传播过程中的stack unwinding机制一一销毁。
是的，当destructor被调用时，可能（也可能不）有一个exception正在作用之中。
> 在destructor区分这些状态的办法： uncaught_exception ，如果某个 exception 在正作用中而尚未被捕捉的话，它会返回true

于是，你必须在保守的假设下（假设当时有个 exception正作用中）撰写你的destructors。因为如果控制权基于exception的因素离开destructor，而此时正有另一个exception处于作用状态，C++ 会调用terminate 函数。此函数的作为正如其名：将你的程序结束掉，它会立刻动手，甚至不等局部对象被销毁。
举个例子。考虑一个用来监视在线计算的活动一也就是从你登录开始直到退出为止的所有行为的Session class。每个Session object都会记录其构造和析构的日期和时间：
```c++
class Session { 
	public：
		Session (); 
		~Session (); 
	private：
		static void logCreation (Session *objAddr); 
		static void logDestruction (Session *objAddr); 
}；
//函数1ogcreation和logpestruction 分别用来记录对象的构造和析构。我们可能因此预期Session destructor 写成这样： 
Session::~Session (){ logDestruction (this); }
```
这看起来很好，但是考虑一下如果logDestruction抛出一个exception，会发生什么事。这个exception并不会被Session destructor捕捉，所以它会传播到destructor的调用端，但是万一 destructor 本是因其他某 exception而被调用的， terminate 函数便会被自动调用，于是你的程序便走上了黄泉路。
这往往不是你希望发生的。是的，它可能造成Session object的析构无法被记录下来，甚至可能带来更大的不便，但难道它可怕到必须让程序停止执行吗？
你必须阻止logDestruction所抛出的exception传出 Session destructor之外，而唯一的办法就是使用try/catch语句块。下面是个天真的想法：
```c++
Session::~Session() {
	try { logDestruction (this); }
	catch (...) {
	cerr << "Unable to log destruction of Session object " << "at address "
		 << this << ".In";
	}
}
```
这恐怕不比我们原先的设计安全。如果catch语句块内对 operator<< 的调用导致一个exception被抛出，我们便回到了原始点——一个即将跨出Session destructor的 exception。当然我们可以在catch语句块内再放一个try语句块，但这样的行为似乎太过极端。
取代的办法是：如果logDestruction抛出一个 exception，我们便把记录Session析构的任务忘它个一干二净：
```c++
Session::~Session() {
	try { logDestruction (this); }
	catch (...) {}
}
```
这里的catch语句块看起来什么都没做，但是外表容易骗人。这个语句块阻止了logDestruction所出的exceptions传出 Session destructor之外，那也是它唯一的任务。我们现在可以放轻松了：如果一个Session object因为栈展开（stack unwinding）而被销毁， terminate 并不会被调用。
exceptions传出 destructors 之外，之所以不好，还有第二个理由。如果exception A destructor 内抛出，而且没有在当地被捕捉，那个destructor便是执行不全（仅执行到抛出 exception的那一点为止）。如果destructor执行不全，就是没有完成它应该完成的每一件事情。考虑下面这个Session class修改版，其对象诞生于一个数据库事务之时，结束于此事务结束之后：
```c++
Session::Session () {
	logCreation (this); 
	startTransaction ();
}
Session::~Session () {
	logDestruction (this); 
	endTransaction ();
}
```
在这里，如果 logDestruction 出一 exception，在 Session constructor 内开始其生命的那个事务绝对不会结束。本例之中我们或许可以重新安排Session destructor内的函数调用顺序，以消除问题。但如果 endTransaction也抛出exception，那么我们除了回到 try/catch 的怀抱之外，别无选择。
因此，有两个好理由支持我们全力阻止 exceptions传出 destructors之外
第一，它可以避免terminate 函数在exception传播过程的栈展开（stack—unwinding）机制中被调用；
第二，它可以协助确保destructors完成其应该完成的所有事情
### Exception specifications
exception specifications 还是有吸引力的。它让代码更容易被理解，因为它明确指出一个函数可以抛出什么样的 exceptions，但它不只是一个漂亮的注释而已。编译器有时候能够在编译期间侦测到与 exception specifications不一致的行为。如果函数抛出了一个并未列于其 exception specification 的 exception，这个错误会在运行时期被检验出来，于是特殊函数 unexpected 会被自动调用。可以说，exception specifications 不但是一种文档式的辅助，也是一种实践式的机制，用来规范 exception的运用。它确实满吸引人的。
然而，unexpected的默认行为是调用terminate，而terminate的默认行为是调用abort，所以程序如果违反exception specification，默认结果就是程序被中止。局部变量不会获得销毁的机会，因为 abort 会使程序停摆，没机会执行此类清理工作。一个未获尊重的 exception specification 就像大洪水一般，会带来毁灭。最好永远不要发生这种事情。
不幸的是，很容易就能写出一个函数让这可怕的事情发生。因为编译器只会对exception specifications 做局部性检验。它们所没有检验的-同时也是C＋＋明定不准拒绝的是调用某个函数而该函数可能违反调用端函数本身的 exception specification（有些比较严谨的编译器会对此发出警告）。
考虑以下的 f1 函数声明，它没有 exception specification。此函数可以抛出任何一种 exception：
```c++
extern void f1(); //可以抛出任何东西。
```
再考虑函数 f2，它通过它的 exception specification 声称，只抛出类型为 int的 exceptions:
```c++
void f2() throw(int);
```
在C＋＋中，f2 调用 f1绝对合法，即使 f1 可能抛出一个 exception 而该 exception 违反了 f2 的 exception specification
这种弹性是必要的。如果带有 exception specifications 的新代码和缺乏 exception specifications的旧代码要整合在一起的话，这种弹性就有必要。
由于编译器心甘情愿地让你调用可能违反当前函数本身的 exception specification的函数，并且由于如此的调用行为可能导致程序被迫中止，所以如何才能将这种不一致性降到最低，是很重要的思考。一个好方法就是避免将 exception specifications 放在需要类型自变量的templates 身上。
考虑下面这个 template， 它看起来好像绝不会抛出任何 exceptions：
```c++
//一个不良的 template 设计，因为它带有 exception specifications。 
template<class T>
bool operator==(const T& lhs, const T& rhs) throw() {
	return &lhs == &rhs; 
}
```
上述 template 有一个 exception specification，指明被此 template 所产生出来的函数不会抛出任何exceptions。但其实那并非绝对为真，因为有可能 operator＆（取址操作符—见条款E45）已经被某些类型重载。如果真是这样，operator== 内部调用 operator＆ 时便有可能由 operator＆ 抛出一个 exception。果真如此，上述的 exception specification 便遭违反，导致迈向 unexpected 之路。
这只是个特殊例子。更一般化的问题是，没有任何方法可以知道一个 template的类型参数可能抛出什么 exceptions。所以千万不要为 template 提供意味深长的exception specification，因为 templates 几乎必然会以某种方式使用其类型参数。结论是：**不应该将 templates 和  exception specifications  混合使用。**
避免踏上 unexpected之路的第二个技术是：**如果A函数内调用了B函数，而B函数无  exception specifications ，那么A函数本身也不要设定  exception specifications 。**
这是很简单的常识，但是有一种情况很容易被忘记，就是当允许用户注册所谓的 callback（回调）函数时：
```c++
//函数指针类型。用于窗口系统的 callback（回调）函数
typedef void (*CallBackPtr) (int eventXLocation,
							int eventYLocation, void*dataToPassBack); 
//窗口系统内的 class，用来放置用户注册的 callback 函数。
class CallBack{
	public:
		CallBack(CallBackPtr fPtr, void *dataToPassBack)
		:func(fPtr), data(dataToPassBack){}
		void makeCallBack(int eventXLocation,int eventYLocation) const throw(); 		private:
		CallBackPtr func;//callback 发生时所要调用的函数。
		void *data;//用来传给 cal1back 函数的数据
};

//为了实现callback，我们调用已经注册的函数，
//并以“event 的发生坐标”和“经过注册的数据”作为自变量。
void CallBack::makeCal1Back(int eventXLocation,int eventYLocation) const throw() {
	func(eventXLocation, eventYLocation, data); 
}
```
此处makeCal1Back函数内部对func的调用，有可能违反exception specification， 因为没有任何方法可以知道 func可能抛出什么样的 exceptions。
如果在 CallBackPtr typedef 中加上exception specification，就可以消除这个问题： 
```c++
typedef void (*CallBackPtr) (int eventXLocation,
							int eventYLocation, void*dataToPassBack) throw();
```
有了这个 typedef，现在如果注册一个 callback 函数而后者无法保证不抛出任何东西，便会出现错误：
```c++
//一个不带有 exception specification 的callback 函数。 
void callBackFcn1(int eventXLocation, int eventYLocation,void *dataToPassBack); 
void *callBackData;
CallBack c1(callBackFcn1, callBackData);
//错误！因为 callBackFcn1 可能会抛出 exception。

//一个带有 exception specification的callback 函数。 
void callBackFcn2(int eventXLocation, int eventYLocation, 
				  void *dataToPassBack) throw(); 
CallBack c2(callBackFcn2, callBackData);
//没问题，因为 cal1BackFcn2 满足 exception specification。
```
避免踏上 unexpected 之路的第三个技术是：处理系统可能抛出的exceptions。其中最常见的就是 bad＿alloc ，那是在内存分配失败时由 operator new 和operator new［］抛出的（见条款8）。如果你在函数内使用 new operator，你必须有心理准备：这个函数可能会遭遇  bad＿alloc exception 。
虽说杜渐防微，预防胜于治疗，但有时候预防很困难，治疗反倒简单。也就是说，有时候，直接处理非预期的 exceptions，反而比事先预防来得简单得多。举个例子，如果你所写的软件大量运用 exception specifications，但你被迫调用程序库提供的函数，而后者没有使用 exception specifications，那么你想要阻止非预期的 exceptions 发生，就是件不切实际的事，因为那非得改变程序库源代码不可。
如果阻止非预期的 exceptions 发生是件不切实际的事，你可以利用一个事实：C＋＋允许你以不同类型的 exceptions 取代非预期的 exceptions。
举个例子，假设你希望所有非预期的 exceptions 都以 UnexpectedException objects取而代之， 可以这么做：
```c++
class UnexpectedException {};
//所有非预期的 exception objects 都将被取代为此类的 objects。

void convertUnexpected() {如果有一个非预期的被抛出，便调用此函数。
	throw UnexpectedException();
}

//并以 convertUnexpected 取代默认的 unexpected 函数： 
set_unexpected(convertUnexpected);
```
一旦完成这些布署，任何非预期的 exception 便会导致 convertunexpected 被调用，于是非预期的 exception 被一个新的、类型为 UnexpectedException的 exception 取而代之。那么，只要被违反的 exception specification 内含有 UnexpectedException，exception的传播便会继续下去，好似 exception specification 获得满足似的。但如果 exception specification 未包含 UnexpectedException， terminate会被调用，犹如从未取代 unexpected一样。
将非预期的 exceptions 转换为一个已知类型的另一个做法就是，依赖以下事实：
如果非预期函数的替代者重新抛出当前的（current）exception，该 exception 会被标准类型  bad＿exception  取而代之。
以下代码就会发生这样的事情：
```c++
void convertUnexpected() { //如果非预期的 exception 被抛出，此函数便被调用
	throw;//它只是重新抛出当前的 exception。
}
set_unexpected(convertUnexpected);
//安装 convertUnexpected，作为 unexpected 函数的替代品。
```
如果你做了上述安排，并且每一个 exception specifications 都含有  bad＿exception （或其基类，也就是标准类 exception），你就再也不必担心程序会在遇上非预期的 exception 时中止执行。任何非预期的 exception 都会被一个 bad＿exception 取代，而该 exception 会取代原来的 exception 继续传播下去。
现在你了解到了，exception specifications 可能带来许多麻烦。是的，编译器只为它执行局部性检验，在templates 中使用它会有问题，它们很容易被不经意地违反，而且当它们被违反，默认情况下会导致程序草草中止。
Exception specifications 还有另一个缺点，那就是它们会造成当一个较高层次的调用者已经准备好要处理发生的 exception 时，unexpected 函数却被调用的现象。例如，考虑以下这一段几乎是从条款11逐字抄录过来的代码：
```c++
class Session {
	public:
		~Session();
    private:
		static void logDestruction(Session *objAddr) throw(); 
};

Session::~Session() {
	try{
		logDestruction(this); 
	}
	catch(...){ } 
}
```
其中的 Session destructor 调用 1ogDestruction 以记录有个 Session object 正被销毁的事实，并以 catch（...）明确指出它要捕捉任何可能被1ogDestruction 抛出的 exceptions。
然而 1ogDestruction 带有一个 exception specification，保证不抛出任何 exceptions。现在假设某些被1ogDestruction 调用的函数抛出一个exception，而1ogDestruction 没有拦下它。这或许不会发生，但我们也了解，要写出这类违反 exception specifications 的代码，一点都不困难。当这个非预期的 exception 传播到达 1ogDestruction，函数 unexpected 会被调用，默认情况下会导致程序的中止。
这是正确的行为，毫无疑问，但这是 Session destructor的作者真正想要的行为吗？那位作者费尽苦心地处理所有可能的 exceptions，所以如果在中止程序之前没有给 Session destructor内的catch 语句块一个机会，似乎并不公平。如果 1ogDestruction 没有设定 exception specification，这个我有意愿捕捉它，只要你给我机会的剧情就不会上演。阻止它的办法之一就是，将unexpected 函数取而代之。
## 抛出exception与传递参数或调用虚函数之间的差异
函数参数的声明语法，和catch子句的声明语法，简直如出一辙：
```c++
class Widget { ... };//某个class，细节不重要。
void fl (Widget w);//所有这些函数需要的参数
catch (Widget w)
```
你可能会因而假设从抛出端传递一个exception到catch子句，基本上和从函数调用端传递一个自变量到函数参数是一样的。是的，其中有相同之处，但是也有重大的不同点。
让我们从相同点开始谈起。
函数参数和exceptions的传递方式有3种： by value ， by reference ，  by pointer. 然而视你所传递的是参数或 exceptions，发生的事情可能完全不同。原因是当你调用一个函数，控制权最终会回到调用端（除非函数失败以至于无法返回），但是当你抛出一个 exception，控制权不会再回到抛出端。
试看以下函数，不但传递一个widget作为参数，也抛出一个 widget exception：
```c++
//此函数从一个 stream 中读取一个widget
istream operator>> (istream& s, Widget& w); 
void passAndThrowwidget (){
	Widget localWidget; 
	cin >> localWidget;//将 localWidget 传给 operator>> 
	throw localWidget;//将localWidget抛出成为一个 exception. 
}
```
当localwidget被交到  operator>> 函数手中，并没有发生复制（copying）行为，而是 operator>> 内的 reference w 被绑定于localwidget身上。此时，对w所做的任何事情，其实是施加于localwidget身上的。
这和将localwidget当做一个 exception的情况不同。不论被捕捉的exception是以 by value 或 by reference 方式传递（不可能以 by pointer 方式传递——那将造成类型不吻合），都会发生localWidget的复制行为，而交到catch子句手上的正是那个副本。
一定是这样的，因为此情况下一旦控制权离开 passAndThrowWidget， localwidget便离开了其生存空间（scope），于是localWidget destructor会被调用。如果此时是以1ocalwidget 本身传递给一个catch子句的，此子句收到的将是一个被析构的Widget，一个已经仙逝的widget。这具尸体曾经负载一个Widget，但现在已经不是了，没有作用了。这便是为什么C++ 特别要声明，一个对象被抛出作为exception时，总是会发生复制
即使被抛出的对象并没有瓦解的危险，复制行为还是会发生。例如，假设passAndThrowwidget localWidget 明 static:
```c++
void passAndThrowwidget (){
	static Widget localWidget； // 如今它是 static，会存在直到程序结束。
	cin >> localWidget;
	throw localwidget;
}
```
当上述函数抛出 exception，还是会产生一个1ocalwidget副本。意味着即使此 exception 以 by reference 方式被捕捉， catch 端还是不可能修改localwidget，只能修改 localWidget 的副本。exception objects 必定会造成复制行为这一事实也解释了传递参数和抛出exception之间的另一个不同：后者常常比前者慢(见条款15)
当对象被复制当做一个 exception，复制行为是由对象的copy constructor执行的。这个copy constructor 相应于该对象的静态类型而非动态类型。例如，考虑下面这个稍加修改的passAndThrowwidget函数：
```c++
class Widget {};
class SpecialWidget: public widget {....}; 
void passAndThrowwidget (){
	Specialwidget localSpecialwidget;
	Widget& rw = localSpecialWidget；//rw代表一个Specialwidget
	throw rw；//抛出一个类型为Widget的exception
}
```
这里抛出的是一个Widget exception—虽然rw实际代表的是一个 Specialwidget。这是因为rw的静态类型是widget而非Specialwidget。 rw虽然实际上代表一个SpecialWidget，你的编译器却不关心这个事实，它们关心的是rw的静态类型。此行为模式可能不是你想要的，但它和其他所有C++复制对象的情况一致。
> 复制动作永远是以对象的静态类型为本（但条款25展示一个技术，让你以对象的动态类型为本，进行复制）

exceptions对象是其他对象的副本这个事实，会对你如何在catch语句块内传播exceptions带来冲击。考虑以下两个 catch语句块，乍见之下似乎做了相同的事情：
```c++
catch (Widget& w) {// 捕捉 widget exceptions.
    ... //处理 exception。
    throw; // 重新抛出此exception，使它能继续传播。
}
catch (Widget& w) {//捕捉widget exceptions.
	... // 处理 exception。
	throw w； //传播被捕捉的exception的一个副本。
}
```
这两个 catch 语句块之间唯一的差异就是，前者重新抛出当前的exception，后者抛出的是当前exception的副本。如果暂且排除额外的复制行为所带来的性能成本因素，两种做法有差别吗？
第一语句块重新抛出当前的exception，不论其类型为何。更明确地说如果最初抛出的exception 的类型是SpecialWidget，第一语句块会传播一个SpecialWidgetexception—虽然w的静态类型是widget。这是因为当此exception被重新抛出时，并没有发生复制行为。
第二catch语句块则抛出一个新的exception，其类型总是widget，因为那是w的静态类型。一般而言，你必须使用以下语句： throw 才能重新抛出当前的exception，其间没有机会让你改变被传播的exception的类型。此外，它也比较有效率，因为不需要产生新的exception object。
让我们检验3种catch子句，它们都有能力捕捉被passAndThrowwidget抛出的widget exception：
```c++
catch (Widget w)//以by value 的方式捕捉。
catch (Widget& w)//以by reference 的方式捕捉。
catch（const widget& w）// 以 by reference—to—const 的方式捕捉
```
我们立刻就注意到了参数传递和exception 传播之间的另一个区别。
一个被抛出的对象（如先前所解释，必为临时对象）可以简单地用 by reference 的方式捕捉，不需要以 by reference-to-const 的方式捕捉。函数调用过程中将一个临时对象传递给一个  non-const reference 参数是不允许的（见条款19），但对exceptions则属合法。
然而让我们忽略这个差异，回到复制exception objects的主题。
我们知道，如果以 by value 方式传递函数自变量，便是对被传递的对象做一个副本，此副本存储于对应的函数参数中。如果以 by value 方式传递 exception，亦发生相同的事情。因此，当我们声明一个 catch子句，预期得付出被抛出物的两个副本的构造代价，其中一个构造动作用于任何exceptions都会产生的临时对象身上，另一个构造动作用于将临时对象复制到w。
类似道理，当我们以 by reference 方式捕捉一个 exception，预期得付出被抛出物的单一副本的构造代价。这里的副本便是指临时对象。由于以by reference方式传递函数参数时并不会发生复制行为，所以抛出exception和传递函数参数相比，前者会多构造一个被抛出物的副本（并于稍后析构)
我们尚未讨论以 by pointer 方式出exceptions，但 throw by pointer 事实上相当于pass by pointer，两者都传递指针副本。必须特别注意的是，千万不要抛出一个指向局部对象的指针，因为该局部对象会在exception传离其scope （控制权同时也离开该scope）时被销毁，因此catch子句会获得一个指向已被销毁的对象的指针。这正是义务性复制（copy）规则的设计要避免的情况。
自变量传递与exception传播两动作有着互异的做法，其中一个不同就是对象从调用端或抛出端被搬移到参数或catch子句时的做法（如上所述）；
第二个不同则是调用者或抛出者和被调用者或捕捉者之间所存在的类型吻合（type match）规则。试考虑标准程序库的数学函数
```c++
double sqrt (double);
int i；
double sqrtofi = sqrt (i);
```
其中没有什么值得大惊小怪的。C++允许隐式转换，将int转为double，所以在调用 sqrt 的过程中， i 会被默默地转换为一个 double，而 sqrt 的结果将应该double。一般而言，如此的转换并不发生于exceptions与catch子句相匹配的过程中。下面这段代码：
```c++
void f (int value) {
	try {
		if (someFunction ()) {//如果 someFunction （）返回 true，就抛出一个int。
			throw value;
		}
	}
	catch (double d) {
		// 在这里处理类型为 double 的exceptions。
	}
}
```
try 语句块中抛出的 int exception 绝不会被用来捕捉 double exception 的 catch 子句捕捉到。后者只能捕捉类型确确实实为double的 exceptions ，其间不会有类型转换的行为发生**。所以，如果 int exception 被捕捉，它一定是被某些其他（也许是外围的） catch 子句捕捉的（它们的捕捉类型一定是int或int&，或许再加上const或volatile 之类的限定词）
exceptions 与 catch 子句相匹配的过程中，仅有两种转换可以发生。
第一种是继承架构中的类转换。一个针对 base class exceptions 而编写的 catch 子句，可以处理类型为 derived class 的 exceptions。
![image-20220527121319596](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220527121319596.png)
此所谓的继承架构中的 exception 转换规则可适用于 by value ，  by reference 及 by pointer  3 种形式：
```c++
catch (runtime_error)
catch （const runtime_error&）
catch (runtime_error&)
// 可捕捉类型为runtime_error，range_error 或 overflow_error的错误。

catch (runtime_error*)
catch （const runtime_error*）
// 可捕捉类型为runtime_error*，range_error* overflow_error*的错误。
```
第二个允许发生的转换是从一个有型指针转为无型指针，所以一个针对 const void * 指针而设计的catch子句，可捕捉任何指针类型的exception：
```c++
catch (const void*)//可捕捉任何指针类型的exception。
```
传递参数和传播exception的最后一个不同是，catch子句总是依出现顺序做匹配尝试。因此，当try语句块中分别有针对 base class 而设计和针对 derived class  设计的 catch ,  derived class exception  仍有可能被针对  base class 而设计的 catch 子句处理掉。例如：
```c++
try {
	...
}
catch (logic_error& ex) {
	//此语句块将捕捉所有的logic_error exceptions, 甚至包括其derived types
}
catch (invalid_argument& ex) {
	//此语句块绝不会执行起来，因为所有的 invalid_argumentexceptions都会被上述子句捕捉。
}
```
请将此行为拿来和调用虚函数时所发生的事情比对。
当你调用一个虚函数，被调用的函数是调用者（某个对象）的动态类型中的函数。可以说，虚函数采用所谓的 best fit （最佳吻合）策略，而exception处理机制遵循所谓的 first fit （最先吻合）策略。如果针对 derived class 而设计的catch子句出现在针对 base class 而设计的catch 子句之后，编译器可能会给你一个警告——有些更严厉的编译器甚至会发出错误消息，因为这样的代码在C++中通常是不正确的。但是你的最佳行动纲领就是先发制人：绝不要将针对 base class 而设计的catch子句放在针对 derived class 而设计的catch子句之前。上述代码应该重新安排如下：
```c++
try {...}
catch (invalid_argument& ex) {
	// 这里处理 invalid_argument exceptions.
}
catch (logic_error& ex) {
	//这里用来处理其他所有的logic_errors.
}
```
因此我们可以说，**传递对象到函数去**，或是**以对象调用虚函数**和**将对象抛出成为一个 exception**之间，有3个主要的差异。
第一， exception objects 总是会被复制，如果以 by value 方式捕捉，它们甚至被复制两次。至于传递给函数参数的对象则不一定得复制。
第二， 被抛出成为exceptions的对象，其被允许的类型转换动作，比被传递到函数去的对象少。
第三， catch子句以其出现于源代码的顺序被编译器检验比对，其中第一个匹配成功者便执行；而当我们以某对象调用一个虚函数，被选中执行的是那个与对象类型最佳吻合的函数，不论它是不是源代码所列的第一个。
### Conclusion
**当你调用一个函数，控制权最终会回到调用端（除非函数失败以至于无法返回），但是当你抛出一个 exception，控制权不会再回到抛出端**。
```c++
class Widget { ... };
//此函数从一个 stream 中读取一个widget
istream operator>> (istream& s, Widget& w); 
void passAndThrowwidget (){
	Widget localWidget; 
	cin >> localWidget;//将 localWidget 传给 operator>> 
	throw localWidget;//将localWidget抛出成为一个 exception. 
}
```
函数参数和 exceptions 的传递
**第一个差别：**
以 by reference 方式将 localWidget 传给 operator>> ，并不会发生复制行为
将 localwidget 当做一个 exception，不论被捕捉的 exception 是以 by value 或 by reference 方式传递，都会发生 localWidget 的复制行为，而交到 catch 子句手上的正是那个副本。
因为一旦控制权离开  passAndThrowWidget，localwidget 便离开了其生存空间，于是 localWidget destructor 会被调用，如果此时是以 1ocalwidget  本身传递给一个 catch 子句的，此子句收到的将是一个被析构的 Widget 
因此**一个对象被抛出作为 exception 时，总是会发生复制**，而且**即使被抛出的对象并没有瓦解的危险，即被抛出的为 static 对象，复制行为还是会发生**，这就意味着**即使此 exception 以 by reference 方式被捕捉，catch 端还是不可能修改 localwidget ，只能修改 localWidget 的副本**。
基于**复制动作永远是以对象的静态类型为本**，所以**当对象被复制当做一个 exception，复制行为是由对象的 copy constructor 执行的，且复制的是该对象的静态类型而非动态类型**，
```c++
class Widget {};
class SpecialWidget: public widget {....}; 
void passAndThrowwidget (){
	Specialwidget localSpecialwidget;
	Widget& rw = localSpecialWidget；//rw代表一个Specialwidget
	throw rw；//抛出一个类型为Widget的exception
}
```
**第二个差别：**
一个被抛出的对象（如先前所解释，必为临时对象）可以简单地用 by reference 的方式捕捉，不需要以 by reference-to-const 的方式捕捉。
函数调用过程中将一个临时对象传递给一个  non-const reference 参数是不允许的（见ME19），但对 exceptions 则属合法。
**第三个差别：**
> 如果以 by value 方式传递函数自变量，便是对被传递的对象做一个副本，此副本存储于对应的函数参数中

当我们以 by value 方式捕捉一个  exception ，预期得付出被抛出物的两个副本的构造代价，其中一个构造动作用于任何 exceptions 都会产生的临时对象身上，另一个构造动作用于将临时对象复制到 w 。
当我们以 by reference 方式捕捉一个  exception ，预期得付出被抛出物的单一副本的构造代价。这里的副本便是指临时对象。由于以 by reference 方式传递函数参数时并不会发生复制行为，所以抛出 exception 和传递函数参数相比，前者会多构造一个被抛出物的副本（并于稍后析构)
throw by pointer  事实上相当于 pass by pointer ，两者都传递指针副本。必须特别注意的是，千万不要抛出一个指向局部对象的指针，因为该局部对象会在 exception 传离其 scope  （控制权同时也离开该 scope ）时被销毁，因此 catch 子句会获得一个指向已被销毁的对象的指针。这正是义务性复制规则的设计要避免的情况。
**类型吻合（type match）规则：**
被抛出成为 exceptions 的对象，其被允许的类型转换动作，比被传递到函数去的对象少
exceptions 与 catch 子句相匹配的过程中，仅有两种转换可以发生。
第一种是继承架构中的类转换。一个针对 base class exceptions 而编写的  catch  子句，可以处理类型为 derived class 的  exceptions 
第二个允许发生的转换是从一个有型指针转为无型指针，所以一个针对 const void * 指针而设计的 catch 子句，可捕捉任何指针类型的 exception ： catch (const void*) 
**First fit :**
catch 子句以其出现于源代码的顺序被编译器检验比对，其中第一个匹配成功者便执行，如果针对 derived class 而设计的 catch 子句出现在针对 base class 而设计的 catch  子句之后，编译器可能会给你一个警告
绝不要将针对 base class 而设计的catch子句放在针对 derived class 而设计的 catch 子句之前
**throw的不同**：
```c++
catch (Widget& w) {// 捕捉 widget exceptions.
    ... //处理 exception。
    throw; // 重新抛出此exception，使它能继续传播。
}
catch (Widget& w) {//捕捉widget exceptions.
	... // 处理 exception。
	throw w； //传播被捕捉的exception的一个副本。
}
```
这两个  catch  语句块之间唯一的差异就是，前者重新抛出当前的 exception ，后者抛出的是当前 exception 的副本。
第一语句块重新抛出当前的 exception ，不论其类型为何。更明确地说如果最初抛出的 exception  的类型是 SpecialWidget ，第一语句块会传播一个 SpecialWidget exception —虽然 w 的静态类型是 widget 。这是因为当此 exception 被重新抛出时，并没有发生复制行为。
第二语句块则抛出一个新的 exception ，其类型总是 widget ，因为那是 w 的静态类型。一般而言，你必须使用以下语句： throw ，才能重新抛出当前的 exception ，其间没有机会让你改变被传播的 exception 的类型。此外，它也比较有效率，因为不需要产生新的 exception object 。
