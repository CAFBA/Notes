# Run-Time Type Identification
运行时类型识别的功能由两个运算符实现：
- `typeid`运算符，用于返回表达式的类型。
- `dynamic_cast`运算符，用于将基类的指针或引用安全地转换为派生类的指针或引用。
RTTI运算符适用于以下情况：想通过基类对象的指针或引用执行某个派生类操作，并且该操作不是虚函数。
## The dynamic_cast Operator
`dynamic_cast`运算符的形式如下：
```c
dynamic_cast<type*>(e)
dynamic_cast<type&>(e)
dynamic_cast<type&&>(e)
```
其中`type`是一个类类型，并且通常情况下该类型应该含有虚函数。在第一种形式中，`e`必须是一个有效指针；在第二种形式中，`e`必须是一个左值；在第三种形式中，`e`不能是左值。在所有形式中，`e`的类型必须符合以下条件之一：
- `e`是`type`的公有派生类。
- `e`是`type`的公有基类。
- `e`和`type`类型相同。
如果条件符合，则类型转换成功，否则转换失败。转换失败可能有两种结果：
- 如果`dynamic_cast`语句的转换目标是指针类型，则结果为0。
- 如果`dynamic_cast`语句的转换目标是引用类型，则抛出`bad_cast`异常（定义在头文件`typeinfo`中）。
> 在条件判断部分执行`dynamic_cast`可以确保类型转换和结果检查在同一条表达式中完成。
> 可以对一个空指针执行`dynamic_cast`，结果是所需类型的空指针。
## The typeid Operator
中文 344 英文 432
`typeid`表达式的形式是`typeid(e)`，其中`e`可以是任意表达式或类型名称。`typeid`的结果是一个指向常量对象的引用，该对象的类型是标准库`type_info`（定义在头文件`typeinfo`中）或`type_info`的公有派生类型。
对于传入 `typeid` 的 `expression` 或 `type`，其中的顶层`const`会被忽略：
- 若 `type` 是引用，则`typeid`返回该引用所指对象的类型。
- 若 `type` 是数组或函数，不会执行向指针的标准类型转换。
- 若 `type` 是指针，返回的结果是该指针的静态类型。
- 若 `expression` 是左值表达式且不属于类类型或者是一个不包含任何虚函数的类，`typeid`不对表达式求值，直接返回其静态类型。
- 若 `expression` 是左值表达式且含有虚函数，则对`typeid`的表达式求值，得到表达式的动态类型。
- 对于`typeid(*p)`，如果指针`p`所指向的类型不包含虚函数，则`p`可以是一个无效指针。否则`*p`会在运行期间求值，此时`p`必须是一个有效指针。如果`p`是空指针，`typeid(*p)`会抛出`bad_typeid`异常。
通常情况下，`typeid`用于比较两条表达式的类型是否相同，或者比较一条表达式的类型是否与指定类型相同。
```c
Derived *dp = new Derived;
Base *bp = dp;   // both pointers point to a Derived object
// compare the type of two objects at run time
if (typeid(*bp) == typeid(*dp))
{
    // bp and dp point to objects of the same type
}
// test whether the run-time type is a specific type
if (typeid(*bp) == typeid(Derived))
{
    // bp actually points to a Derived
}
```
`type_info`类的精确定义会根据编译器的不同而略有差异。但是C++规定`type_info`必须定义在头文件`typeinfo`中，并且至少提供以下操作：
![19-1](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/19-1.png)
`type_info`类一般是作为一个基类出现，所以它还应该提供一个公有虚析构函数。当编译器希望提供额外的类型信息时，通常在`type_info`的派生类中完成。
`type_info`类没有默认构造函数，而且它的拷贝和移动构造函数以及赋值运算符都被定义为删除的。**创建`type_info`对象的唯一方式就是使用`typeid`运算符**。对于某种给定类型来说，`name`成员的返回值因编译器而异并且不一定与在程序中使用的名字一致。对于`name`返回值的唯一要求就是类型不同则返回的字符串必须有所区别。
## Using RTTI
使用RTTI可以为具有继承关系的类实现相等运算符。
相等运算符的形参是基类的引用。
```cpp
class Base {
    friend bool operator==(const Base&, const Base&);
protected:
    virtual bool equal(const Base&) const;
};

class Derived: public Base {
protected:
    bool equal(const Base&) const;
    // data and other implementation members of Derived
};
```
使用`typeid`检查两个运算对象的类型是否一致，类型一致才会继续判断每个数据成员的取值是否相同。
```cpp
bool operator==(const Base &lhs, const Base &rhs)
{
    // returns false if typeids are different; otherwise makes a virtual call to equal
    return typeid(lhs) == typeid(rhs) && lhs.equal(rhs);
}
```
每个类定义的`equal`函数负责比较类型自己的数据成员。`equal`函数的形参都是基类的引用，但是在比较之前需要先把运算对象转换成自己的类型。
```cpp
bool Derived::equal(const Base &rhs) const {
    auto r = dynamic_cast<const Derived&>(rhs);
    // do the work to compare two Derived objects and return the result
}

bool Base::equal(const Base &rhs) const {
// do whatever is required to compare to Base objects
}
```