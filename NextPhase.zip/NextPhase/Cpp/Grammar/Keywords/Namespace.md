# Namespaces
大型应用程序通常会使用多个独立开发的库，其中某些名字可能会相互冲突，多个库将名字放置在全局命名空间中会产生命名空间污染，因此使用命名空间分割全局命名空间，其中每个命名空间都是一个作用域。
## Use namespace
命名空间的定义包含两部分：关键字 `namespace` 和随后的命名空间名字。在命名空间名字后面是一系列由花括号包围的声明和定义，作用域后面不需要分号结束。
- 命名空间可以定义在全局作用域内，也可以定义在其他命名空间中，但是不能定义在函数或类的内部。
- 命名空间的定义可以是不连续的。如果之前没有名为 `nsp` 的命名空间定义，则会创建一个新的命名空间，否则会继续在已经存在的命名空间定义并为其添加新的成员声明。
- 通常情况下，`#include` 不应该出现在命名空间内部。否则头文件中的所有名字都会被定义为该命名空间的成员。
- 可以在命名空间的外部定义该命名空间的成员。命名空间对于名字的声明必须在作用域内，同时该名字的定义需要明确指出其所属的命名空间。模板特例化必须定义在原始模板所属的命名空间中。可以在命名空间内部添加模板特例化声明，而在外部对其进行定义。
- 全局作用域中定义的名字被隐式添加到全局命名空间中。全局命名空间以隐式方式声明，在所有程序中都存在。作用域运算符 `:: `可以用于全局命名空间的成员。因为全局命名空间是隐式声明的，所以它并没有名字。
- 内层命名空间声明的名字会隐藏外层命名空间的同名成员。在嵌套的命名空间中定义的名字只在内层命名空间中有效，外层命名空间中的代码在访问时需要在名字前添加限定符。
- C++11新增了内联命名空间。和一般的嵌套命名空间不同，内联命名空间中的名字可以被外层命名空间直接使用。定义内联命名空间的方式是在命名空间第一次定义的地方的 `namespace` 前添加关键字 `inline`。
- 可以为命名空间定义别名。别名必须出现在命名空间的定义之后。一个命名空间可以有多个别名，它们都与命名空间的原名等价。
```c++
namespace primer = cplusplus_primer;
```
下述代码是上述内容的示例：
```c++
int x = 100;

namespace other {
    int x = 10;
}

// 命名空间可以定义在全局作用域内，也可以定义在其他命名空间中，但是不能定义在函数或类的内部
namespace cafba {
    // 定义在某个命名空间中的名字可以被该命名空间内的其他成员直接访问，也可以被这些成员内嵌作用域中的任何单位访问
    int numOne = 10;
    int numTwo = 20;

    // namespace互相访问需要使用作用域运算符
    int numThree = other::x;
    int numFour = ::x;

    class widget {
        widget definition(const widget wid);
    };

    // 模板特例化
    template<class T>
    class kingdom {
        void show() { cout << numOne << endl; }
    };
    // 模板特例化必须定义在原始模板所属的命名空间中
    //可以在命名空间内部添加模板特例化声明，而在外部对其进行定义
    template<>
    class kingdom<int>;

    // 嵌套namespace
    // 内层命名空间声明的名字会隐藏外层命名空间的同名成员。
    // 在嵌套的命名空间中定义的名字只在内层命名空间中有效，外层命名空间中的代码在访问时需要在名字前添加限定符
    namespace cafbaKid {
        int kid = 1;
    }
    
    // inline namespace
    // 内联命名空间中的名字可以被外层命名空间直接使用
    // inline必须出现在该命名空间第一次定义的地方
    inline namespace InlineCafbaKid {
        int InlineKid = 2;
        int range = cafbaKid::kid; // 同级命名空间需要作用域运算符
    }
    namespace cafbaKidTwo {
        int range = InlineKid; // 内联就不需要
    }

    // 访问嵌套namespace,需要使用作用域运算符
    int numFive = cafbaKid::kid;
    // 访问inline namespace不需要
    int numSix = InlineKid;
}

namespace alpha = cafba;

// 可以在命名空间的外部定义该命名空间的成员。
// 命名空间对于名字的声明必须在作用域内，同时该名字的定义需要明确指出其所属的命名空间
cafba::widget cafba::widget::definition(const widget wid) { return wid; }

template<>
class cafba::kingdom<int> {
    void show() { cout << numTwo << endl; }
};
```
> 基本上，在内联名称空间中声明的所有内容都会自动在父名称空间中可用。
## Unnamed namespace
未命名的命名空间指关键字namespace后紧跟以花括号包围的一系列声明语句。**未命名的命名空间中定义的变量拥有静态生命周期：它们在第一次使用前创建，直到程序结束才销毁。**
因此在标准C++引入Unnamed namespace的概念之前，程序需要将名字声明为static使其拥有静态生命周期，现在可以使用未命名的命名空间。
- 一个未命名的命名空间可以在某个给定的文件内不连续，但是不能跨越多个文件，每个文件定义自己的未命名的命名空间。如果一个头文件定义了未命名的命名空间，则该命名空间中定义的名字在每个包含该头文件的文件中对应不同实体。
- 定义在未命名的命名空间中的名字可以直接使用，不能对其使用作用域运算符。
- **定义在未命名的命名空间中的名字的作用域与该命名空间所在的作用域相同**。如果未命名的命名空间定义在最外层作用域中，则该命名空间中的名字必须要与全局作用域中的名字有所区别。
```c++
int i; // global declaration for i
namespace
{
    int i;
}
// ambiguous: defined globally and in an unnested, unnamed namespace
i = 10;

namespace local
{
    namespace
    {
        int i;
    }
}
// ok: i defined in a nested unnamed namespace is distinct from global i
local::i = 42;
```
## Using declaration
一条using声明一次只引入命名空间的一个成员，并会与当前作用域的相同名称冲突。using声明的有效范围从using声明语句开始，一直到using声明所在的作用域结束为止。在此过程中，**外层作用域的同名实体会被隐藏，并且不允许当前作用域重新定义同名实体**。通过using声明引入的未加限定名字形式只能在using声明所在的作用域及其内层作用域中使用。
using声明可以出现在全局作用域、局部作用域、命名空间作用域和类的作用域中。在类的作用域中使用时，using声明只能指向基类成员。
```c++
namespace blip
{
  int i = 16, j = 15, k = 23;
}
int k = 100;
void manip()
{
  using blip::k;
  // int k = 97;         不允许当前作用域重新定义同名实体
  cout << k << endl;  // 23 using声明将会隐藏外层作用域的同名实体
  cout << ::k <<endl; // 100 指明后才能使用外层作用域的同名实体
}
```
和using声明不同，using指示使某个命名空间中的所有名字都可见。与using声明不同的是，**外层作用域的同名实体不会被隐藏，要想使用冲突的名字，就必须明确指出名字的版本**。但允许当前作用域重新定义同名实体，且会覆盖名称空间的同名实体。
using指示可以出现在全局作用域、局部作用域和命名空间作用域中，不能出现在类的作用域中。如果对std等命名空间使用了using指示而未做任何特殊控制的话，会重新引入多个库之间的名字冲突问题。
```c++
namespace blip
{
    int i = 16, j = 15, k = 23;
}
int j = 0;  // ok: j inside blip is hidden inside a namespace

void manip()
{
    using namespace blip; 
    ++i;    // sets blip::i to 17
  
    ++j;    // error ambiguous: global j or blip::j? 不会被隐藏，必须指明
    ++::j;  // ok: sets global j to 1
    ++blip::j;    // ok: sets blip::j to 16
  
    int k = 97;   // 这种冲突允许，当前作用域的同名实体将隐藏外层作用域
    ++k;          // sets local k to 98
}
```
相比于使用using指示，在程序中对命名空间中的每个成员分别**使用using声明效果更好**。
- 如果程序使用了多个不同的库，而这些库中的名字通过using指示变得可见，则全局命名空间污染问题将重新出现。
- using指示引发的二义性错误只有在使用了冲突名字的地方才会被发现。而using声明引发的二义性错误在声明处就能发现。
- 最主要的区别就是**using声明不允许当前作用域重新定义同名实体，但using指示允许，且会覆盖名称空间的同名实体**。
头文件如果在其顶层作用域中使用using声明或using指示，则**会将名字注入到包含该头文件的所有文件中**。通常，头文件只负责定义接口部分的名字，而不定义实现部分的名字。因此，头文件最多只能在它的函数或命名空间内使用using声明或using指示。
## Scope
对命名空间内部以及位于命名空间中的类，名字的查找都遵循**由内向外依次查找每个作用域**，当成员函数使用某个名字时，首先在该成员函数中查找，然后在类（包括基类）中查找，接着在外层作用域中查找。
命名空间中**名字的隐藏规则有一个例外**：传递给函数一个类类型的对象、指向类的引用或指针时，除了在常规作用域查找名字外，**还会查找实参类所属的命名空间**。该例外允许概念上作为类接口一部分的非成员函数无须单独的using声明就能被程序使用，这叫做参数依赖查找（ADL）。
在此例中，当编译器发现对operator>>的调用时，首先在当前作用域中寻找合适的函数，接着查找输出语句的外层作用域。随后，**因为>>表达式的形参是类类型的，所以编译器还会查找cin和s的类所属的命名空间**。也就是说，对于这个调用来说，编译器会查找定义了istream和string的命名空间std。当在std中查找时，编译器找到了string的输出运算符函数。
```c++
// operator>>函数定义在标准库string中，string又定义在命名空间std中。但是不用std限定符和using声明就可以调用operator>>。
std::string s;
std::cin >> s; // 调用 >> 函数，传递了s类对象，因此在实参s中查找，调用string版本的operator>>

// 若该规则不存在，则必须为>>运算符提供using声明
using std::operator>>;
// 或者显式使用std::operator>>
std::operator>>(std::cin, s);
```
如果一个未声明的类或函数第一次出现在友元声明中，则会被认定是离它最近的外层命名空间的成员。
## Overloading
using声明和using指示能将某些函数添加到候选函数集。
using声明语句声明的是一个名字，而非一个特定的函数。一个using声明包含重载函数的所有版本以确保不违反命名空间的接口，它会重载该声明语句所属作用域中已有的其他同名函数。
如果using声明出现在局部作用域中，则引入的名字会隐藏外层作用域的相关声明。但如果using声明所在的作用域中已经有一个函数与引入的函数同名且形参列表相同，则该using声明会引发错误。
```c++
using NS::print(int);   // error: cannot specify a parameter list
using NS::print;        // ok: using declarations specify names only
```
using指示声明的是一个命名空间，如果命名空间的某个函数与该命名空间所属作用域中的函数同名，则命名空间的函数会被添加到重载集合中。
与using声明不同，using指示引入一个与已有函数形参列表完全相同的函数并不会引发错误，但需要明确指出调用的是命名空间中的函数版本还是当前作用域中的版本。
```c++
namespace libs_R_us
{
    extern void print(int);
    extern void print(double);
}
void print(const std::string &);
using namespace libs_R_us;

// the candidates for calls to print at this point in the program are:
// print(int) from libs_R_us
// print(double) from libs_R_us
// print(const std::string &) declared explicitly

void fooBar(int ival)
{
    print("Value: ");   // calls global print(const string &)
    print(ival);        // calls libs_R_us::print(int)
}
```
