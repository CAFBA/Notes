# PassBy
## PassByRef
缺省情况下 `C++` 以 `by-value` 方式传递对象至函数。除非另外指定，否则函数参数都是以实际实参的副本为初值，而调用端所获得的亦是函数返回值的一个副本。这些副本系由对象的 `copy` 构造函数产出，这可能使得 `pass-by-value` 成为昂贵的操作。
```c++
class Person { 
	public:
		Person();			//为求简化，省略参数	
		virtual ~Person();	//条款7告诉你为什么它是 virtual	
		...
	private:
		string name; 
		string address;
};
class Student: public Person{ 
	public:
		Student();	//再次省略参数	
		~Student();
		...
	private:
		string schoolName;
		string schoolAddress;
};
//调用函数validateStudent，后者需要一个 Student实参(by-value)并返回它是否有效
bool validateStudent(Student s);//函数以by value 方式接受学生
```
`Student` 对象内有两个 `string` 对象，所以每次构造一个 `Student` 对象也就构造了两个 `string` 对象。此外`Student` 对象继承自 `Person` 对象，所以每次构造 `Student` 对象也必须构造出一个 `Person` 对象。一个 `Person` 对象又有两个 `string` 对象在其中，`因此每一次Person` 构造动作又需承担两个 `string` 构造动作。
最终结果是，以 `by-value` 方式传递一个 `Student` 对象会导致调用一次 `Student copy` 构造函数、一次 `Person copy` 构造函数、四次 `string copy` 构造函数。当函数内的那个 `Student` 复件被销毁，每一个构造函数调用动作都需要一个对应的析构函数调用动作。因此，以 `by-value` 方式传递一个 `Student` 对象，总体成本是六次构造函数和六次析构函数。
```cpp
bool validateStudent(const Student& s);
```
这种传递方式的效率高得多，没有任何构造函数或析构函数被调用，因为没有任何新对象被创建。引用传递避免将实参复制到函数，从而提供两个附加好处：
- 效率：复制大型的对象可能花费很长时间，引用传递只是将该对象的一个引用传给函数 
- 支持：不是所有的类都允许值传递 
引用传递的这些好处意味着，应该只在对于简单的内置类型，例如 `int` 和 `double`, 且无须修改实 参的时候使用值传递。如果需要将对象传递给函数，则更应该使用 `const` 引用传递而不是值传递，这样可以防止不必要的复制。如果函数需要修改对象，则通过对非 `const` 的引用将其传递。如果数据对象是数组，则使用指针，因为这是唯一的选择，并将指针声明为指向 `const` 的指针。
## PassByValue
### Copy The lvalue Move The Rvalue
有些函数的形参可以作为拷贝或移动操作的源对象。比如说，`addName`成员函数可以拷贝自己的形参到一个私有容器。为了提高效率，应该拷贝左值，移动右值。
```cpp
class Widget {
public:
    void addName(const string& newName)    //接受左值；拷贝它
    { names.push_back(newName); }

    void addName(string&& newName)         //接受右值；移动它
    { names.push_back(move(newName)); }    
    …
private:
    vector<string> names;
};
```
这是可行的，但是需要编写两个函数来做本质相同的事。另一种方法是使 `addName` 函数成为具有通用引用的函数模板：
```cpp
class Widget {
public:
    template<typename T>                            //接受左值和右值；
    void addName(T&& newName) {                     //拷贝左值，移动右值；
        names.push_back(forward<T>(newName));  //forward的使用见条款25
    }
};
```
这减少了源代码的维护工作，但是通用引用会导致其他复杂性。作为模板，`addName` 的实现必须放置在头文件中。在编译器展开的时候，可能会产生多个函数，因为不止为左值和右值实例化，也可能为 `string` 和可转换为 `string` 的类型分别实例化为多个函数（参考[[MoveSemantics#Move On Rvalue Ref Forward On Universal Ref]]中的 `setName`）。同时有些实参类型不能通过通用引用传递（参考[[MoveSemantics#Perfect Forwarding Failure Cases]]），而且如果传递了不合法的实参类型，编译器错误会令人生畏（参考[[UniversalRef#Alternatives To Overloading On Universal References]]）。
存在一种编写 `addName` 的方法，可以左值拷贝，右值移动，只用处理一个函数（源代码和目标代码中），且避免使用通用引用，那就是按值传递。
```cpp
class Widget {
public:
    void addName(string newName) {         //接受左值或右值；移动它
        names.push_back(move(newName));
    }
}
```
`move` 典型的应用场景是用在右值引用，但是在这里 `newName` 是与调用者传进来的对象相完全独立的一个对象，所以改变 `newName` 不会影响到调用者，而且这就是 `newName` 的最后一次使用，所以移动它不会影响函数内此后的其他代码。
只有一个 `addName` 函数的事实，解释了在源代码和目标代码中，我们怎样避免了代码重复。我们没有使用通用引用，不会导致头文件膨胀、奇怪的失败情况、或者令人困惑的编译错误消息。但是这种设计的效率如何？
在 `C++98` 中，可以肯定确实开销会大。无论调用者传入什么，形参 `newName` 都是由拷贝构造出来。但是在 `C++11` 中，只有在左值实参情况下，`addName` 被拷贝构造出来，对于右值，它会被移动构造。
```cpp
Widget w;
…
string name("Bart");
w.addName(name);            //使用左值调用addName
…
w.addName(name + "Jenne");  //使用右值调用addName（见下）
```
第一处调用 `addName`（当 `name` 被传递时），形参 `newName` 是使用左值被初始化。`newName` 因此是被拷贝构造，就像在 `C++98` 中一样。第二处调用，`newName` 使用 `string` 对象被初始化，这个`string` 对象是调用 `string` 的 `operator+` 得到的结果，这个对象是一个右值，因此 `newName` 是被移动构造的。
### Compare
但是要牢记一些警示，回顾一下考虑过的三个版本的 `addName`：
```cpp
class Widget {                                  //方法1：对左值和右值重载
public:
    void addName(const string& newName)
    { names.push_back(newName); } // rvalues
    void addName(string&& newName)
    { names.push_back(move(newName)); }
    …
private:
    vector<string> names;
};

class Widget {                                  //方法2：使用通用引用
public:
    template<typename T>
    void addName(T&& newName)
    { names.push_back(forward<T>(newName)); }
    …
};

class Widget {                                  //方法3：传值
public:
    void addName(string newName)
    { names.push_back(move(newName)); }
    …
};
```
仍然考虑这两种调用方式：
```cpp
Widget w;
…
string name("Bart");
w.addName(name);                                //传左值
…
w.addName(name + "Jenne");                      //传右值
```
现在分别考虑三种实现中，给 `Widget` 添加一个名字的两种调用方式，拷贝和移动操作的开销。此处忽略编译器对于移动和拷贝操作的优化，因为这些优化是与上下文和编译器有关的。
- **重载**：无论传递左值还是传递右值，调用都会绑定到一个叫 `newName` 的引用上。从拷贝和移动操作方面看，这个过程零开销。左值重载中，`newName` 拷贝到 `Widget::names` 中，右值重载中，移动进去。开销总结：左值一次拷贝，右值一次移动。
- **使用通用引用**：同重载一样，调用也绑定到 `addName` 这个引用上，没有开销。由于使用了`forward`，左值 `string` 实参会拷贝到 `Widget::names`，右值 `string` 实参移动进去。对 `string` 实参来说，开销同重载方式一样：左值一次拷贝，右值一次移动。
如果调用者传递的实参不是 `string` 类型，将会转发到 `string` 的构造函数，几乎也没有 `string` 拷贝或者移动操作。因此通用引用的方式有同样效率，所以这不影响本次分析，简单假定调用者总是传入 `string` 类型实参即可。
- **按值传递**：无论传递左值还是右值，都必须构造 `newName` 形参。如果传递的是左值，需要拷贝的开销，如果传递的是右值，需要移动的开销，而按引用方式不调用任何构造函数。在函数的实现中，`newName` 总是采用移动的方式到 `Widget::names`。开销总结：左值实参，一次拷贝一次移动，右值实参两次移动。对比按引用传递的方法，对于左值或者右值，均多出一次移动操作，因为没有按引用传递。
### Why
因此对于移动成本低且总是被拷贝的可拷贝形参，考虑按值传递，实际上四个原因：
1. 应该仅**考虑**使用传值方式，只需要编写一个函数，只会在目标代码中生成一个函数，避免了通用引用的种种问题。但是毕竟开销会比接受引用的两种实现方式高，而且下面还会讨论，还会存在一些目前并未讨论到的开销。
2. 仅考虑对**可拷贝形参**使用按值传递，不符合此条件的的形参必须有只可移动的类型的数据成员，因为函数总是会做副本，即传值时形参总是实参的一个副本，如果它们不可拷贝，副本就必须通过移动构造函数创建。传值方案比重载方案的优势在于，仅有一个函数要写。但是对于只可移动类型，没必要为左值实参提供重载，因为拷贝左值需要拷贝构造函数，只可移动类型的拷贝构造函数是禁用的。那意味着只需要支持右值实参，重载方案只需要一个重载函数：接受右值引用的函数。
考虑一个类：有个 `unique_ptr<string>` 的数据成员，对它有个赋值器。`unique_ptr` 是只可移动的类型，所以赋值器的重载方式只有一个函数：
```cpp
class Widget {
public:
   void setPtr(unique_ptr<string>&& ptr)
   { p = move(ptr); }

private:
   unique_ptr<string> p;
};
```
调用者可能会这样写：
```cpp
Widget w;
…
w.setPtr(make_unique<string>("Modern C++"));
```
这样，从 `make_unique` 返回的右值 `unique_ptr<string>` 通过右值引用被传给 `setPtr`，然后移动到数据成员 `p` 中。整体开销就是一次移动。
如果 `setPtr` 使用传值方式接受形参：
```cpp
class Widget {
public:
   void setPtr(unique_ptr<string> ptr)
   { p = move(ptr); }
};
```
同样的调用就会先移动构造 `ptr` 形参，然后 `ptr` 再移动赋值到数据成员 `p`，整体开销就是两次移动——是重载方法开销的两倍。
3. 按值传递应该仅考虑那些**移动开销小**的形参。当移动的开销较低，额外的一次移动才能被开发者接受，但是当移动的开销很大，执行不必要的移动就类似执行一个不必要的拷贝，而避免不必要的拷贝的重要性就是最开始 `C++98` 规则中避免传值的原因！
4. 应该只对**总是被拷贝**的形参考虑按值传递。假定在拷贝形参到 `names` 容器前，`addName` 需要检查新的名字的长度是否过长或者过短，如果是，就忽略增加名字的操作：
```cpp
class Widget {
public:
   void addName(string newName)
   {
       if ((newName.length() >= minLen) &&
           (newName.length() <= maxLen))
       {
           names.push_back(move(newName));
       }
   }
private:
    vector<string> names;
};
```
即使这个函数没有在 `names` 添加任何内容，但由于按值传递，依然存在构造和销毁 `newName` 的开销（指的是传值时形参总是实参的一个副本，不是函数实现中 `push_back` 的开销），而按引用传递会避免这笔开销。
即使编写的函数对可拷贝类型执行无条件的复制，且这个类型移动开销小，有时也可能不适合按值传递。这是因为函数拷贝一个形参存在两种方式：一种是通过构造函数（拷贝构造或者移动构造），还有一种是赋值（拷贝赋值或者移动赋值）。`addName` 使用构造函数，它的形参 `newName` 传递给 `vector::push_back`，在这个函数内部，`newName` 是通过拷贝构造在 `vector` 末尾创建一个新元素。对于使用构造函数拷贝形参的函数，之前的分析已经可以给出最终结论：按值传递对于左值和右值均增加了一次移动操作的开销。
### Assignment
当形参通过赋值操作进行拷贝时，分析起来更加复杂。比如，有一个表征密码的类，因为密码可能会被修改，提供赋值器函数 `changeTo`。用按值传递的策略，实现一个 `Password` 类如下：
```cpp
class Password {
public:
    explicit Password(string pwd)      //传值
    : text(move(pwd)) {}               //构造text
    void changeTo(string newPwd)       //传值
    { text = move(newPwd); }           //赋值text
    …
private:
    string text;                       //密码的text
};

string initPwd("Supercalifragilisticexpialidocious");
Password p(initPwd);
```
毫无疑问：`p.text` 被给定的密码构造，在构造函数用按值传递的方式增加了一次移动构造的开销，如果使用重载或者通用引用就会消除这个开销。
但是，该程序的用户可能对这个密码不太满意，因此采取等价于如下代码的一些动作：
```cpp
string newPassword = "Beware the Jabberwock";
p.changeTo(newPassword);
```
但此时 `changeTo` 使用赋值来拷贝形参 `newPwd`，可能导致函数的按值传递实现方案的开销大大增加。传递给 `changeTo` 的实参是一个左值 `newPassword`，所以 `newPwd` 形参被构造时，`string` 的拷贝构造函数会被调用，这个函数会分配新的存储空间给新密码。`newPwd` 会移动赋值到 `text`，这会导致 `text` 本来持有的内存被释放。所以 `changeTo` 存在两次动态内存管理的操作：一次是为新密码创建内存，一次是销毁旧密码的内存。
但是在这个例子中，旧密码比新密码长度更长，所以不需要分配新内存，销毁旧内存的操作。如果使用重载的方式，有可能两次动态内存管理操作得以避免：
```cpp
class Password {
public:
    void changeTo(string& newPwd)      //对左值的重载
    {   // 如果text.capacity() >= newPwd.size()，可能重用text的内存
        text = newPwd;
    }
private:
    string text;                       //同上
};
```
这种情况下，按值传递的开销包括了内存分配和内存销毁——可能会比 `string` 的移动操作高出几个数量级。但如果旧密码短于新密码，在赋值过程中就不可避免要销毁、分配内存，这种情况，按值传递跟按引用传递的效率是一样的。因此，基于赋值的形参拷贝操作开销取决于具体的实参的值，这种分析适用于在动态分配内存中存值的形参类型。不是所有类型都满足，但是很多——包括 `string` 和 `vector` 是这样。
这种潜在的开销增加仅在传递左值实参时才适用，因为执行内存分配和释放通常发生在真正的拷贝操作而不是不是移动中。对右值实参，移动几乎就足够了。
结论是，使用通过赋值拷贝一个形参进行按值传递的函数的额外开销，取决于传递的类型，左值和右值的比例，这个类型是否需要动态分配内存，以及，如果需要分配内存的话，赋值操作符的具体实现，还有赋值目标占的内存至少要跟赋值源占的内存一样大。对于 `string` 来说，开销还取决于实现是否使用了小字符串优化，如果是，那么要赋值的值是否匹配 `SSO` 缓冲区。
所以，除非已证明按值传递会为需要的形参类型产生可接受的执行效率，否则使用重载或者通用引用的实现方式。
### Slice
基类引用可以指向派生类对象，而无需进行强制类型转换，这种特征的一个实际结果是，可以定义一个接受基类引用作为参数的函数，调用该函数时，可以将基类对象作为参数，也可以将派生类对象作为参数。
当一个派生类对象以 `by-value` 方式传递并被视为一个基类对象，基类的 `copy` 构造函数会被调用，而造成此对象的行为像个派生类对象那些特化性质全被切割掉了，仅仅留下一个基类对象。
因此跟性能无关，按值传递会受到切片问题的影响：
```c++
class Window{ 
public:
    string name() const;
    virtual void display() const;	
};
class WindowWithScrol1Bars: public Window{ 
public:
    virtual void display() const;
};
    // by-value会导致传入的wwsb被构造成为一个Window对象，而造成wwsb之所以是个WindowWithScrol1Bars对象的所有特化信息都会被切除。
   void printNameAndDisplay(Window w){	
    cout << w.name(); // 不论传递过来的对象原本是什么类型，参数w就像一个Window对象，因为执行静态类型与动态类型一致
    w.display(); // 调用display调用的总是Window::display，绝不会是WindowWithScrol1Bars::display
}

WindowWithScrollBars wwsb; 
printNameAndDisplay(wwsb);
// 解决切割(slicing)问题的办法，就是以by-reference-to-const的方式传递w。
void printNameAndDisplay(const Windows& w){	
    cout << w.name(); // 按照动态类型调用
    w.display();
}

class Widget { … };                         //基类
class SpecialWidget: public Widget { … };   //派生类
void processWidget(Widget w);               //对任意类型的Widget的函数，包括派生类型
…                                           //遇到对象切片问题
SpecialWidget sw;
…
processWidget(sw);                          //processWidget看到的是Widget，
                                            //不是SpecialWidget！
```
通常，按值传递仍然会带来希望避免的性能下降，而且按值传递会导致切片问题。`C++11` 中新的功能是区分左值和右值实参，对于可拷贝类型的右值的移动语义，需要重载或者通用引用，尽管两者都有其缺陷。但对于可拷贝且移动开销小的类型，传递给总是会拷贝他们的一个函数，并且切片也不需要考虑，这时，按值传递就提供了一种简单的实现方式，效率接近传递引用的函数，但是避免了传引用方案的缺点。
到此为止，对于需要运行尽可能快的软件来说，按值传递可能不是一个好策略，因为避免即使开销很小的移动操作也非常重要。此外，有时并不能清楚知道会发生多少次移动操作。在 `Widget::addName` 例子中，按值传递仅多了一次移动操作，但是如果 `Widget::addName` 调用了`Widget::validateName`，这个函数也是按值传递。并假设`validateName`调用了第三个函数，也是按值传递……
可以看到这将会通向何方。在调用链中，每个函数都使用传值，因为只多了一次移动的开销，但是整个调用链总体就会产生无法忍受的开销，通过引用传递，调用链不会增加这种开销。
**请记住：**
- 对于可拷贝，移动开销低，而且无条件被拷贝的形参，按值传递效率基本与按引用传递效率一致，而且易于实现，还生成更少的目标代码。
- 按值传递会引起切片问题，所说不适合基类形参类型。
