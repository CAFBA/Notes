# Union
联合是一种特殊的类，一个联合可以有多个数据成员，，这些成员将会共享同一块内存空间，但是在任意时刻只有一个数据成员可以有值，且不能包含引用类型的成员。
给联合的某个成员赋值之后，其他成员会变为未定义状态，分配给联合对象的存储空间至少要能容纳它的最大数据成员。
联合可以定义包括构造函数和析构函数在内的成员函数，但是由于联合既不能继承自其他类，也不能作为基类使用，所以在联合中不能含有虚函数。
```c++
// objects of type Token have a single member, which could be of any of the listed types
union Token
{
    // members are public by default
    char cval;
    int ival;
    double dval;
};
```
默认情况下，联合是未初始化的。可以像显式初始化聚合类一样显式初始化联合，提供的初始值会被用于初始化第一个成员。
```c++
Token first_token = { 'a' };   // initializes the cval member
last_token.cval = 'z';
pt->ival = 42;
```
下述联合包含两个成员，一个是 `unsigned short int` 类型的变量，其大小为 2 个字节，另一个是一个自定义结构，该自定义结构中包含 3 个 `unsigned int` 类型的变量，每个 `unsigned int` 类型的变量的大小并不是默认的 4 个字节，而是通过冒号操作符指定其大小，该大小的单位是比特。所以，联合 `u` 的大小是 4 个字节。
```c++
union U {
	unsigned short int aa;
 	struct {
 		unsigned int bb : 7;//(bit 0-6)
 		unsigned int cc : 6;//(bit 7-12)
 		unsigned int dd : 3;//(bit 13-15)
	}; 
} u;
```
`C++` 早期版本规定，在联合中不能含有定义了构造函数或拷贝控制成员的类类型成员。`C++11` 取消了该限制，但是如果联合的成员类型定义了自己的构造函数或拷贝控制成员，该联合的用法会比只含有内置类型成员的联合复杂得多。
- 当联合只包含内置类型的成员时，可以使用普通的赋值语句改变联合的值。但是如果想将联合的值改为类类型成员对应的值，或者将类类型成员的值改为一个其他值，则必须构造或析构该类类型的成员。
- 当联合只包含内置类型的成员时，编译器会按照成员顺序依次合成默认构造函数或拷贝控制成员。但是如果联合含有类类型成员，并且该类型自定义了默认构造函数或拷贝控制成员，则编译器会为该联合合成对应的版本并将其声明为删除的。
对于联合来说，构造或销毁类类型成员的操作非常复杂。通常情况下，可以把含有类类型成员的联合内嵌在另一个类中，这个类可以管理并控制与联合的类类型成员相关的状态转换。
## 非受限联合体
`C++11` 标准规定，任何非引用类型都可以成为联合体的数据成员，这种联合体也被称为非受限联合体。
### Non-Plain Old Data
`C++98` 不允许联合体的成员是非 POD 类型，但是 `C++11` 取消了这种限制。`POD` 类型一般具有以下几种特征（包括 `class`、`union` 和 `struct` 等）：
- 没有用户自定义的构造函数、析构函数、拷贝构造函数和移动构造函数，不包含虚函数和虚基类，不包含非 `POD` 类型的数据，所有兼容 `C` 语言的数据类型都是 `POD` 类型，`struct`、`union` 等不能违背这些规则。
- 非静态成员必须声明为 `public`，类中的第一个非静态成员的类型与其基类不同，例如：
```cpp
class B1{};
class B2 : B1 { B1 b; };
// class B2 的第一个非静态成员 b 是基类类型，所以它不是 POD 类型。
```
- 在类或者结构体继承时，满足以下两种情况之一：派生类中有非静态成员，且只有一个仅包含静态成员的基类；基类有非静态成员，而派生类没有非静态成员。
```c++
// 对于 B2，派生类 B2 中有非静态成员，且只有一个仅包含静态成员的基类 B1，所以它是 POD 类型
// 对于 B3，基类 B2 有非静态成员，而派生类 B3 没有非静态成员，所以它也是 POD 类型
class B1 { static int n; };
class B2 : B1 { int n1; };
class B3 : B2 { static int n2; };
```
### Static Member
`C++11` 取消了联合体不允许拥有静态成员的限制。例如：
```c++
union U {
    static int func() {
        int n = 3;
        return n;
    }
};
```
需要注意的是，静态成员变量只能在联合体内定义，却不能在联合体外使用，这使得该规则很没用。
### Assignment
`C++11` 规定，如果非受限联合体内有一个非 `POD` 的成员，而该成员拥有自定义的构造函数，那么这个非受限联合体的默认构造函数将被编译器删除，其他的特殊成员函数，例如默认拷贝构造函数、拷贝赋值操作符以及析构函数等，也将被删除。这条规则可能导致对象构造失败，请看下面的例子：
```c++
union U {
    string s;
    int n;
};

U u;   // 构造失败，因为 U 的构造函数被删除
```
在上面的例子中，因为 `string` 类拥有自定义的构造函数，所以 `U` 的构造函数被删除，定义 `U` 的类型变量 `u` 需要调用默认构造函数，所以 `u` 也就无法定义成功。可以使用 `placement new` 解决上面问题：
```c++
union U {
    string s;
    int n;
public:
    U() { new(&s) string; }
    ~U() { s.~string(); }
};

U u;
```
构造时，采用 `placement new` 将 `s` 构造在其地址 `&s` 上，这里 `placement new` 的唯一作用只是调用了一下 `string` 类的构造函数，在析构时还需要调用 `string` 类的析构函数。
## Anonymous Union
匿名联合是一个未命名的联合，并且在右花括号和分号之间没有任何声明。一旦定义了一个匿名联合，编译器就会自动地为该联合创建一个未命名的对象，在匿名联合的定义所在的作用域内，该联合的成员都是可以直接访问的，因此匿名联合不能包含 `protected` 和 `private` 成员，也不能定义成员函数。
```c++
union
{   // anonymous union
    char cval;
    int ival;
    double dval;
};  // defines an unnamed object, whose members we can access directly

cval = 'c';   // assigns a new value to the unnamed, anonymous union object
ival = 42;    // that object now holds the value 42
```
当非受限的匿名联合体运用于类的声明时，这样的类被称为枚举式类。示例如下：
```c++
class Student{
public:
    Student(bool g, int a): gender(g), age(a){}
    bool gender;
    int age;
};

class Singer {
public:
    enum Type { STUDENT, NATIVE, FOREIGENR };
    Singer(bool g, int a) : s(g, a) { t = STUDENT; }
    Singer(int i) : id(i) { t = NATIVE; }
    Singer(const char* n, int s) {
        int size = (s > 9) ? 9 : s;
        memcpy(name , n, size);
        name[s] = '\0';
        t = FOREIGENR;
    }
    ~Singer(){}
private:
    Type t;
    union {
        Student s;
        int id;
        char name[10];
    };
};

Singer(true, 13);
Singer(310217);
Singer("J Michael", 9);
```
上面的代码中使用了一个匿名非受限联合体，它作为类 `Singer` 的变长成员来使用，这样的变长成员给类的编写带来了更大的灵活性，这是 `C++98` 标准中无法达到的。
一个自由链表在同一时刻，具备且仅具备如下功能之一：
- 作为一个自由链表指针，指向下一个自由链表
- 自身作为一块可用内存，供用户使用
由于如上用途不可能同时出现，故将 `obj` 定义为 `union`，将 `free_list_lin` 和 `client_data` 共享同一块内存来节省内存，它不需要一个指针来特意指向真正分配给用户的内存, 而是直接在这个 `union` 中分配。
```c++
union TrieNode
{
    TrieNode *next; // free_list_link是指向下一个内存区域，也是指向下一个list
    char client_data[1]; // client_data，这个数组就是指本块内存
};

//假设这两个是要分配出去的内存
char mem[100] = { 0 };
char mem1[100] = { 0 };

union TrieNode *p = (union TrieNode *)mem; 
p->next = (union TrieNode *)mem1;

// mem 和client_data 两个指针值是一致的
cout <<"mem             = " << (void *)mem << endl;
cout <<"p->client_data = " << (void *)p->next << endl;
```
