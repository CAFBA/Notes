## 函数指针
函数指针指向的是函数而非对象。和其他指针一样，函数指针指向某种特定类型。函数的类型由它的返回类型和形参类型共同决定，与函数名无关。要想声明一个可以指向该函数的指针，只需要用指针替换函数名即可
```c++
bool lengthCompare(const string &, const string &);

// pf指向一个函数，该函数的参数是两个const string的引用，返回值是bool类型
bool (*pf)(const string &, const string &);

// 形参是函数指针的函数指针
void (* __set_malloc_handler(void (*__f)()))()
```
**当把函数名作为一个值使用时，该函数自动地转换成指针**：
```c++
pf = lengthCompare; // pf指向名为lengthCompare的函数 
pf = &lengthCompare; // 等价的赋值语句：取地址符是可选的
```
此外，还能直接使用指向函数的指针调用该函数，无须提前解引用指针：
```c++
bool b1 = pf("hello", "goodbye dbye"); // 调用lengthCompare 函数 
bool b2 = (*pf)("hello", "googoodbye"); // 一个等价的调用 
```
在指向不同函数类型的指针间不存在转换规则。但是和往常一样，可以为函数指针赋一个nullptr，表示该指针没有指向任何一个函数：
```c++
string::size_type sumLength(const string&, const string&); 
bool cstringCompare(const char*, const char*);

pf = 0;// 正确：pf不指向任何函数
pf = sumLength; // 错误：返回类型不匹配
pf = cstringCompare; // 错误：形参类型不匹配
pf = lengthCompare; // 正确：函数和指针的类型精确匹配
```
### 函数指针形参
和数组类似，虽然不能定义函数类型的形参，但是形参可以是指向函数的指针。此时，形参看起来是函数类型，实际上却是当成指针使用：
```c++
// 第三个形参是函数类型，它会自动地转换成指向函数的指针
void useBigger(const string &s1, const string &s2,
								bool pf(const string &, const string &)); 
// 等价的声明：显式地将形参定义成指向函数的指针
void useBigger(const string &s1, const string &s2,
								bool (*pf)(const string &, const string &));
```
可以直接把函数作为实参使用，此时它会自动转换成指针：
```c++
// 自动将函数lengthCompare转换成指向该函数的指针
useBigger(s1, s2, lengthCompare);
```
类型别名和decltype能简化使用函数指针的代码：
```c++
// Func和Func2是函数类型
typedef bool Func(const string&, const string&);  
typedef decltype(lengthCompare) Func2; 

using Func3 = bool(const string&, const string&);  
using Func4 = decltype(lengthCompare);  

// FuncP和FuncP2是指向函数的指针  
typedef bool (*FuncP)(const string&, const string&);  
typedef decltype(lengthCompare) *FuncP2;

using FuncP3 = bool(*)(const string&, const string&);  
using FuncP4 = decltype(lengthCompare)(*);
```
Func和Func2是函数类型，而FuncP和FuncP2是指针类型。需要注意的是，**decltype返回函数类型，此时不会将函数类型自动转换成指针类型**。因为decltype的结果是函数类型，所以只有在结果前面加上\*才能得到指针。
可以使用如下的形式重新声明useBigger：
```c++
// useBigger的等价声明，其中使用了类型别名
void useBigger(const string&, const string&, Func);
void useBigger(const string&, const string&, FuncP2);
```
这两个声明语句声明的是同一个函数，在第一条语句中，编译器自动地将Func表示的函数类型转换成指针。
### 返回指向函数的指针
和数组类似，虽然不能返回一个函数，但是能返回指向函数类型的指针，必须把返回类型写成指针形式，**编译器不会自动地将返回的函数当成对应的指针类型处理**。与往常一样，要想声明一个返回函数指针的函数，最简单的办法是使用类型别名：
```c++
using F = int(int*, int); // F是函数类型，不是指针
using PF = int(*)(int*, int); // PF 是指针类型
```
其中使用类型别名将F定义成函数类型，将PF定义成指向函数类型的指针。
必须显式地将返回类型指定为指针：
```c++
// 注意下述中的PF，F都用作返回类型！！！！！
PF f1(int);  // 正确：PF是指向函数的指针，f1返回指向函数的指针
F f1(int);   // 错误：F是函数类型，f1不能返回一个函数
F* f1(int);  // 正确：显式地指定返回类型是指向函数的指针

// 将auto和decltype用于函数指针类型
// 使用尾置返回类型的方式声明一个返回函数指针的函数
auto f1(int) -> int (*)(int*, int);
```
也能用下面的形式直接声明f1：
```c
int (*f1(int))(int*, int);
```
按照由内向外的顺序阅读这条声明语句：看到f1有形参列表，所以f1是个函数；f1前面有＊，所以f1返回一个指针；进一步观察发现，指针的类型本身也包含形参列表，因此指针指向函数，该函数的返回类型是int。
下述使用decltype推导返回类型：
```c++
string::size_type sumLength(const string&, const string&); 
string::size_type largerLength(const string&, const string&); 
// 根据其形参的取值，getFcn 函数返回指向sumLength或者largerLength的指针 
decltype(sumLength) *getFcn(const string &);
```
声明getFcn唯一需要注意的地方是，当将decltype作用于某个函数时，它返回函数类型而非指针类型。因此，显式地加上 `*` 以表明需要返回指针，而非函数本身。
> decltype 用于推导数组与函数时，不会自动将其转换为指针，均需要显示地加上\*表明。