## 临时对象的来源
临时对象通常发生于两种情况：
- 隐式类型转换被施行起来以求函数调用能够成功
- 当函数返回对象的时候
考虑一个函数，用来计算字符串中的某字符出现次数：
```cpp
// 返回 ch 在 str 中的出现个数。  
size_t countChar(const string& str, char ch);   
char buffer [MAX_STRING_LEN];  
char c;//读入一个char 和一个 string，利用 setw 避免在读入 string 时缓冲区满溢  
cin >> c >> setw(MAX_STRING_LEN) >> buffer;   
cout << "There are " << countChar(buffer, c)   
     << "occurrences of the character" << c << " in " << buffer << endl;
```
`countChar` 第一个实参是 `char` 数组，但是形参却是` const string＆`。编译器此时会产生一个类型为 `string` 的临时对象，以 `buffer` 作为自变量，调用 `string constructor`，于是 `countChar` 的 `str` 参数会被绑定于此 `string` 临时对象上。当 `countChar` 返回，此临时对象会被自动销毁。
只有当对象以 `by value` 传递或当对象被传递给一个 `reference-to-const` 参数时，这些转换才会发生。如果对象被传递给一个 reference-to-non-const 参数，并不会发生此类转换。考虑这个函数：
```cpp
void uppercasify(string& str);
char subtleBookPlug[] = "Effective C++";  
uppercasify(subtleBookPlug);
```
在上一个例子中，可以成功地将一个字符数组传递给 `countChar`，但是在这里，将一个字符数组交给 `uppercasify` 会导致调用失败，不再有任何临时对象被产生出来以成全此函数的调用。
因为如果编译器针对 `ref-to-non-const` 对象进行隐式类型转换产生一个临时对象，被传递给 `uppercasify` 的是此临时对象，被修改的将是临时对象而不是 `subtleBookPlug`，因此 `Cpp` 禁止为 `non-const ref` 参数产生临时对象，`ref-to-const` 则不需要承担此问题，因为 `const` 使其无法被改变。
```cpp
const Number operator+(const Number& lhs,const Number& rhs);
```
此函数的返回值是个临时对象，因为它没有名称：它就是函数的返回值，每当调用 `operator`，便需要为此对象付出构造和析构成本。
## 返回值
没有返回值的 `return` 语句只能用在返回类型是 `void` 的函数中。返回 `void` 的函数不要求非得有 `return` 语句，因为在这类函数的最后一句后面会隐式地执行 `return`。
调用一个返回引用的函数得到左值，其他返回类型产生临时对象，用以使用的是这个会于稍后销毁的临时对象，因此需要付出构造和析构成本。
`C++11` 新标准规定，函数可以返回花括号包围的值的列表。类似于其他返回结果，此处的列表也用来对函数返回的临时对象进行初始化。如果列表为空，执行值初始化。
如果函数的返回类型不是 `void`，那么它必须返回一个值。但是这条规则有个例外：允许 `main` 函数没有 `return` 语句直接结束。如果控制到达 `main` 函数的结尾处而且没有 `return` 语句，编译器将隐式地插入一条返回 0 的 `return` 语句。
### 返回对象
若不想付出对象的构造和析构成本，可以改而传递 `ref`，但是 `ref` 代表某个既有对象，它一定是某物的另一个名称。
```cpp
Rational a(1,2);// a=1/2 
Rational b(3,5);// b=3/5 
Rational c = a * b;// c应该是3/10
// 如果是按值传递，返回的将是 3/10 的临时副本，便是合理的
// 但如果按引用传递，必须原本就存在一个其值为 3/10 的Rational对象
// 如果 operator＊要返回一个reference指向如此数值，它必须自己创建那个Rational对象
```
当然不可能期望这样一个 `Rational` 对象在调用 `operator*` 之前就存在。也就是说，一个必须返回新对象的函数的正确写法是（重载赋值运算符返回的是旧对象）：
```cpp
inline const Rational operator*(const Rational& lhs, const Rational& rhs) {
	return Rational(lhs.n * rhs.n, lhs.d * rhs.d); 
}
```
在这种情况下，存在调用复制构造函数来创建被返回的对象的开销，然而这是无法避免的。
若非要使得对象在调用前存在，只能在 `stack` 空间或在 `heap` 空间创建：
```c++
const Rational& operator* (const Rational& lhs, const Rational& rhs) {
	Rational result(lhs.n * rhs.n, lhs.d * rhs.d); // 警告！糟糕的代码！ 
	return result;
}
```
这种做法必须用构造函数构造 `result`，但最初的目标是避免调用构造函数。更严重的是被返回的对象是被调用函数中的局部变量，在被调用函数执行完毕时，局部对象将调用其析构函数。因此，当控制权回到调用函数时，引用指向的对象将不再存在，这个版本将返回 `ref` 指向一个已经被销毁的对象。函数返回指针指向一个局部对象，也是一样。
```c++
const Rational& operator*(const Rational& lhs, const Rational& rhs) {
	 Rational* result = new Rational(lhs.n * rhs.n, lhs.d * rhs.d); 
	 return *result;
}
Rational w, x, y, z; 
w = x * y * z;
```
这种做法也必须付出一个构造函数调用代价，但同一个语句内调用了两次 `operator*`，因而两次使用 `new`，也就需要两次 `delete`。但却没有合理的办法让 `operator*` 使用者进行那些 `delete` 调用，因为没有合理的办法取得 `operator*` 返回的 `ref` 背后隐藏的那个指针，这绝对导致资源泄漏。
上述做法，都因为对 `operator*` 返回的结果调用构造函数而存在问题。最初目标是要避免如此的构造函数调用动作。那么如果让 `operator*` 返回的 `ref` 指向一个被定义于函数内部的 `static` 对象：
```c++
const Rational& operator* (const Rational& lhs, const Rational& rhs) {
	static Rational result; // static对象，此函数将返回其 reference
	result = ...; // 将lhs乘以rhs，并将结果置于result内
	return result;
}
```
那么下述 `if` 总是被核算为 `true`：
```c++
Rational a, b, c,d;
if((a * b) == (c * d)){...} // 当乘积相等时，做适当的相应动作
if (operator==(operator*(a, b), operator*(c, d)))
```
在 `operator==` 被调用前，先会调用两个 `operator*`，每一个都返回 `ref` 指向  `operator*` 内部定义的 `static` 对象。两次 `operator*` 调用的确各自改变 `static` 对象值，但由于它们返回的都是 `ref` ，因此调用端看到的永远是 `static` 对象的现值。
综上：
- 不要返回 `pointer` 或 `ref` 指向一个 `local stack` 对象
- 不要返回 `ref` 指向一个 `heap-allocated` 对象
- 不要返回 `pointer` 或 `ref` 指向一个 `local static` 对象而有可能同时需要多个这样的对象
### 返回引用
有些方法和函数如重载的赋值运算符可以返回对象，也可以返回指向对象的引用，在这种情况下，应首选引用，因为其效率更高。如果方法或函数要返回一个没有复制构造函数的类（如ostream类）的对象，它必须返回一个指向这种对象的引用。
```c++
string s1("ss");
string s2, s3;
s3 = s2 = s1;
// s2.operator=()的返回值被赋给s3，返回String对象或String对象的引用都是可行的，但通过使用引用，可避免该函数调用String的复制构造函数来创建一个新的String对象
// 在这个例子中，返回类型不是const，因为方法operator=()返回一个指向s2的引用，可以对其进行修改
cout << s1 << "is coming!";
// operator<<（cout, s1）的返回值成为一个用于显示字符串“is coming!”的对象。
// 返回类型必须是ostream &，而不能仅仅是ostream。
// 如果使用返回类型ostream，将要求调用ostream类的复制构造函数，而ostream没有公有的复制构造函数。
// 返回一个指向cout的引用不会带来任何问题，因为cout已经在调用函数的作用域内。
```
### 返回 const
```c++
// 上述重载后的运算符，复制构造函数将创建一个临时对象来表示返回值，表达式f1 + f2的结果为一个临时对象
net = f1 + f2;// 该临时对象被赋给net
f1 + f2 = net;// net被赋给该临时对象
// 程序计算f1和f2之和，将结果复制到临时返回对象中，再用net的内容覆盖临时对象的内容，然后将该临时对象丢弃。
cout << (f1 + f2 = net).magval() << endl;
```
如果担心这种行为可能引发的误用和滥用，有一种简单的解决方案：将返回类型声明为`const Vector`。例如，如果`Vector::operator+()`的返回类型被声明为`const Vector`，则语句1仍然合法，但语句2和语句3将是非法的。
### 返回数组指针
因为数组不能被拷贝，所以函数不能返回数组。不过，函数可以返回数组的指针或引用。虽然从语法上来说，要想定义一个返回数组的指针或引用的函数比较烦琐，但是有一些方法可以简化这一任务。
#### 使用类型别名
![image-20221008125522209](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221008125522209.png)
其中arrT是含有10个整数的数组的别名。因为无法返回数组，所以将返回类型定义成数组的指针。因此，func函数接受一个int实参， 返回一个指向包含10个整数的数组的指针。
#### 不使用类型别名
如果想定义一个返回数组指针的函数，则数组的维度必须跟在函数名字之后。然而，函数的形参列表也跟在函数名字后面且形参列表应该先于数组的维度。因此，返回数组指针的函数形式如下所示：
```c
Type (*function(parameter_list))[dimension]
```
必须有最外层的括号，否则将是指针的数组，而不是指向数组的指针。
```c
int (*func(int i))[10];
// func(int i)表示调用func函数时需要一个int类型的实参
// (*func(int i))表示对函数调用的结果执行解引用操作
// (*func(int i))[10]表示解引用func的调用将得到一个大小是 10 的数组。
// int (*func(int i))[10]表示数组中的元素是int类型。
```
#### 使用尾置返回类型
```c
auto func(int i) -> int(*)[10];
```
#### 使用decltype
不带括号的decltype能推导出标识符定义的类型，但并不负责把数组类型转换成对应的指针，所以decltype的结果是个数组，要想表示arrPtr返回指针还必须在函数声明时加一个\*符号。
```c
int odd[] = {1, 3};
int even[] = {0, 2};
decltype(odd) *arrptr(int i) { // 返回一个指向含有2个整数的数组的指针
    return (i % 2) ? &odd : &even;
}
```