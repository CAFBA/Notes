1. `endl` 会在流中插入新的一行，并且把当前缓冲区中的所有内容刷出滑槽。不建议过度地使用 `endl`，例如在循环中使用，因为这会影响程序的性能。另一方面，在流中插入 `\n` 也会插入新的一行，但**不会自动刷新缓冲区**。
2. 不使用 `.h` 后缀改用前缀 C 的头文件将所有内容放在 std 名称空间中，`.h` 后缀版本不使用名称空间。
3. 类模板 `std::numeric_limits` 提供一种获取数值极限信息的标准方式。对于一个整数，最小值(min)等于最低值(lowest)。然而对于浮点类型来说，最小值表示该类型能表示的最小正数，最低值表示该类型能表示的最小负数。
4. 每个函数都有一个预定义的局部变量 `__func__`，其中包含当前函数的名称。这个变量的一个用途是用于日志记录。
5. 如果指定数组的大小，而初始化列表包含的元素数量少于给定大小，则其余元素将值初始化。
6. 要获取基于桟的 C 风格数组的大小，可使用 `std::size` 函数，返回 `size_t` 类型。此外，也可以这样获取：
```cpp
size_t arraySize { sizeof(myArray) / sizeof(myArray[0]) };
```
7. 统一初始化可在构造函数初始化器中初始化类成员数组，还可用来初始化动态分配的数组：
```cpp
class MyClass
{
    public:
    MyClass() : m_array { 0, 1, 2, 3 } {}
    private:
    int m_array[4];
};

int* myArray = new int[] { 0, 1, 2, 3 };
```
8.  
```cpp
void test(int arg) {
  cout << arg << endl;
}

int main() {
  int x = 10;
  test(x + 10); // 按值传递的函数可使用多种类型的实参
}

// 但按引用传递具有限制，因为如果 arg 是一个变量的别名，则实参应该是该变量
// 而 x + 10 是个表达式而不是变量
void test(int& arg) {
  cout << arg << endl;
}
```
9. 字典序比较：
- 长度相同，则按照第一对相异字符比较的结果
- 长度不同，较短对象的每个字符都与较长对象对应位置上的字符相同，则较短对象小于较长对象。 
10. 对字符串 `vector` 使用 CTAD 时：
```cpp
vector names { "John", "Sam", "Joe" }; // error
vector names { "John"s, "Sam"s, "Joe"s };
```
推导出的类型将是 `vector<const char*>`，而不是 `vector<string>`。 如果需要一个 `vector<string>`，可以使用 `string` 字面量。
11. 如果一条表达式中已经有 `size()` 函数就不要再使用 `int`，这样可以避免混用 `int` `和unsigned` 可能带来的问题。
12. 当把 `string` 对象和字符字面值及字符串字面值混在一条语句中使用时，必须确保每个加法运算符的两侧的运算对象至少有一个是 `string`。
13. 定义在 `<utility>` 中的 `exchange` 可以用一个新的值替换原来的值，并返回原来的值：
```cpp
int a { 11 };
int b { 22 };
cout << format("Before exchange(): a = {}, b = {}", a, b) << endl;
int returnedValue { exchange(a, b) };
cout << format("After exchange(): a = {}, b = {}", a, b) << endl;
cout << format("exchange() returned: {}", returnedValue) << endl;
```
15. 考虑交换两个对象的 `swap` 函数模板，这是另一个使用移动语义提高性能的示例。下面的`swapCopy` 实现没有使用移动语义：
```cpp
template <typename T>
void swapCopy(T& a, T& b)
{
    T temp { a };
    a = b;
    b = temp;
}
```
这一实现首先将 `a` 复制到 `temp`，其次将 `b` 复制到 `a`，最后将 `temp` 复制到 `b`。如果类型 `T` 的复制开销很大，这个交换实现将严重影响性能。使用移动语义，`swap` 函数可避免所有复制：
```cpp
template <typename T>
void swapMove(T& a, T& b)
{
    T temp { std::move(a) };
    a = std::move(b);
    b = std::move(temp);
}
```
16. 不允许使用一个数组为另一个内置类型的数组赋初值，也不允许使用 `vector` 对象初始化数组。相反的，允许使用数组来初始化 `vector` 对象。要实现这一目的，只需指明要拷贝区域的首元素地址和尾后地址：
```c
int int_arr[] = {0,1,2,3,4,5};

// ivec有6个元素，分别是int arr中对应元素的副本
vector<int> ivec(begin(int_arr), end(int_arr)); 

// 用于初始化vector对象的值也可能仅是数组的一部分：
vector<int> subVec(int_arr + 1, int_arr + 4);
```
17. 如果类具有用户声明的析构函数，就不会生成拷贝构造函数和拷贝赋值运算符。基本上，一旦有用户声明的析构函数，`C++` 的 5 法则就会开始执行。在此类情况下，如果仍然需要编译器生成的拷贝构造函数、拷贝赋值运算符、移动构造函数和移动赋值运算符，可将它们显式设置为默认。
18. 与指针语义相比，使用值语义的缺点在于不能拥有空值，但 `std::optional` 可弥补这一点，它允许使用值语义，还能表示空值。
19. `unique_ptr` 和 `shared_ptr` 会禁用类型推导。给它们的构造函数传递 `T*`，这意味着，编译器必须选择推导 `<T>` 还是 `<T[]>`，这是一个可能出错的危险选择。因此需要使用 `make_unique` 和 `make_shared`。
20. 如果类模板方法的实现需要特定模板类型参数(例如 `T`)的默认值，可使用 `T{}` 语法。如果 `T` 是类类型，`T{}` 调用对象的默认构造函数，或者如果 `T` 是基本类型，则生成0。最好为类型尚不确定的变量提供合理的默认值。
