## Header Files
预处理指令 `#include` 的作用是包含文件。
- 如果文件名包含在尖括号中，则 `C++` 编译器将在存储标准头文件的主机系统的文件系统中查找
- 如果文件名包含在双引号中，则编译器将首先查找当前的工作目录或源代码目录或其他目录，这取决于编译器。如果没有在那里找到头文件，则将在标准位置查找。因此在包含自己的头文件时，应使用引号而不是尖括号。
- 不要将函数定义放到头文件中。如果在头文件包含一个函数定义，然后在其他两个文件中包含该头文件，则同一个程序中将包含同一个函数的两个定义，除非函数是内联的，否则这将出错。
- 结构与类声明不创建变量，而只是在源代码文件中声明结构变量时，告诉编译器如何创建该结构变量。模板声明不是将被编译的代码，它们指示编译器如何生成与源代码中的函数调用相匹配的函数定义。
- 被声明为 `const` 的数据和内联函数有特殊的链接属性，因此可以将其放在头文件中，而不会引起问题。
### Duplicate Definitions
重复定义的问题可以通过一种称为包含保护(也称为头文件保护)的机制来避免，但这种方法并不能防止编译器将文件包含两次，而只是让它忽略除第一次包含之外的所有内容。
```c++
#ifndef _XXX_
#define _XXX_
... // 头文件内容
#endif

#pragma once
```
### Circular Dependencies
避免头文件问题的另一个工具是前向声明。如果需要引用一个类，但不能包含它的头文件，则可以通过前向声明告诉编译器该类存在，而不需要通过 `#include` 提供正式的定义。当然，不能在代码中实际使用该类，因为编译器对它还一无所知，只知道已命名的类将在所有内容链接在一起后存在于内存中。但仍然可以在代码中，通过指针和引用来引用前向声明的类，还可以声明按值返回的此类前向声明的类，或者声明一个函数，该函数的参数按值传递，类型为前向声明的类。
比如，假设 `Logger` 类使用另一个名为 `Preferences` 的类来跟踪用户的设置。`Preferences` 类可能反过来使用 `Logger` 类，因此会具有循环依赖关系，在这种情况下，需要使用前向声明。在下面的代码中，`Logger` 头文件使用 `Preferences` 类的前向声明，因此可以在不包括其头文件的情况下，引用 `Preferences` 类。
```cpp
#pragma once
#include <string_view>
class Preferences; // forward declaration
class Logger
{
public:
    void setPreferences(const Preferences& prefs);
    void logError(string_view error);
};
```
建议尽可能在头文件中使用前向声明，而不是包含其他头文件，这么做可以减少编译和重新编译的时间，因为它打破了当前头文件对其他头文件的依赖。当然，实现文件还是需要包含正确的头文件，即已前向声明的类型头文件，否则，它将无法通过编译。
### Querying Existence of Headers
若要查询某个头文件是否存在：
```cpp
#if __has_include(<optional>)
 #include <optional>
#elif __has_include(<experimental/optional>)
 #include <experimental/optional>
#endif
```
## Preprocessor Macros
宏是 `C` 遗留下来的特性，非常类似于内联函数，但不执行类型检测。在调用宏时，预处理器会自动使用扩展式替换。预处理器并不会真正地应用函数调用语义，这一行为可能导致无法预测的结果。
因为宏的展开、替换发生在预处理阶段，不涉及函数调用、参数传递、指针寻址，没有任何运行期的效率损失，所以对于一些调用频繁的小代码片段来说，用宏来封装的效果比 `inline` 关键字要更好，因为它真的是源码级别的无条件内联。
```c++
#define ngx_tolower(c) ((c >= 'A' && c <= 'Z') ? (c | 0x20) : c)
#define ngx_toupper(c) ((c >= 'a' && c <= 'z') ? (c & ~0x20) : c)

#define ngx_memzero(buf, n) (void) memset(buf, 0, n)
```
其次，**宏是没有作用域概念的，永远是全局生效**。所以，对于一些用来简化代码、起临时作用的宏，最好是用完后尽快用 `#undef` 取消定义，避免冲突的风险。像下面这样：
```c++
#define CUBE(a) (a) * (a) * (a) // 定义一个简单的求立方的宏
cout << CUBE(10) << endl; // 使用宏简化代码
cout << CUBE(15) << endl; // 使用宏简化代码
#undef CUBE // 使用完毕后立即取消定义
```
另一种做法是**宏定义前先检查，如果之前有定义就先 `undef`，然后再重新定义**：
```c++
#ifdef AUTH_PWD // 检查是否已经有宏定义
#undef AUTH_PWD // 取消宏定义
#endif // 宏定义检查结束
#define AUTH_PWD "xxx" // 重新宏定义
```
用宏来代替直接定义名字空间：
```c++
#define BEGIN_NAMESPACE(x) namespace x {
#define END_NAMESPACE(x) }

BEGIN_NAMESPACE(my_own)

	... // functions and classes
	
END_NAMESPACE(my_own)
```
### Conditional compilation
利用 `#define` 定义出的各种宏，还可以在预处理阶段实现分支处理，通过判断宏的数值来产生不同的源码，改变源文件的形态，这就是条件编译。
```c++
#if __linux__ // 预处理检查宏是否存在
# define HAS_LINUX 1 // 宏定义，有缩进
#endif // 预处理条件语句结束

#if 0 // 0即禁用下面的代码，1则是启用
... // 任意的代码
#endif // 预处理结束
#if 1 // 1启用代码，用来强调下面代码的必要性
... // 任意的代码
#endif // 预处理结束
```
如果需要在 `C` 和 `C++` 中编译同一个源文件，可以在编译 `C++` 版本时使用预处理定义 `__cplusplus`，它标记 `C++` 语言的版本号。 
```c++
extern "C" { 
  void a_c_function(int a);
}

// 利用内置的宏判断，保证 C 与 C++ 都可以调用
#ifdef __cplusplus 
	extern "C" { // 如果是C++编译，导出 C 接口
#endif
	void a_c_function(int a); // 如果是 C 编译，会直接跳过 extern "C" { }
#ifdef __cplusplus 
	}
#endif

#if __cplusplus >= 201402 // 检查C++标准的版本号
	cout << "c++14 or later" << endl; // 201402就是C++14
#elif __cplusplus >= 201103 // 检查C++标准的版本号
	cout << "c++11 or before" << endl; // 201103是C++11
#else // __cplusplus < 201103 // 199711是C++98
# 	error "c++ is too old" // 太低则预处理报错
#endif // __cplusplus >= 201402 // 预处理语句结束


#if defined(__cpp_decltype_auto) // 检查是否支持decltype(auto)
	cout << "decltype(auto) enable" << endl;
#else
	cout << "decltype(auto) disable" << endl;
#endif 

#if __GNUC__ <= 4
	cout << "gcc is too old" << endl;
#else
	cout << "gcc is good enough" << endl;
#endif

#if defined(__SSE4_2__) && defined(__x86_64)
	cout << "we can do more optimization" << endl;
#endif

// GCC 可以使用命令查看
g++ -E -dM - < /dev/null
#define __GNUC__ 5
#define __unix__ 1
#define __x86_64__ 1
#define __UINT64_MAX__ 0xffffffffffffffffUL
```
### Why Shouldn’t Use
1. 对于 `#define MAX 1.653`，这将导致：
  - 错误信息会显示 `1.653` 而非 `MAX`，若 `MAX` 被定义在非自己所写的头文件中，肯定不知道 `1.653` 有何意义。
  - 宏定义会将所有的 `MAX` 替换为 `1.653`，这会导致编译器不知道 `MAX` 是什么（可能在编译器处理源码之前就被预处理器移走了），因此`MAX` 这个记号名称有可能不会进入记号表内。
  - 由于是浮点常量，预处理器盲目地将 `MAX` 替换为 `1.653` 会导致目标码出现多份 `1.653`。
  因此需要使用常量替换上述宏定义，这时候 `MAX` 作为语言常量，一定会进入记号表，并且会产生较小量的码。
2. 无法利用 `#define` 创建类内常量，因为 `#define` 不重视作用域，除非在某处 `#undef`，否则一旦定义，在其后的编译过程中一直有效，也就是说它并不提供任何封装性。
3. 形似函数的宏具有不会招致调用函数带来的额外开销，但会导致宏替换带来的麻烦，使用 `inline` 不仅避免麻烦，而且存在这种效率，更由于它作为函数遵守访问规则与作用域，比如类内的`private` 内联函数。
## Bit-fields
类可以将其非静态数据成员定义成位域，在一个位域中含有一定数量的二进制位。当程序需要向其他程序或硬件设备传递二进制数据时，通常会使用位域。
位域的声明形式是在成员名字之后紧跟一个冒号和一个常量表达式，该表达式用于指定成员所占的二进制位数。
位域的类型必须是整型或枚举类型。因为带符号位域的行为是由具体实现确定的，所以通常情况下使用无符号类型保存位域。位域类型的大小不能小于位域结构的总大小。
```c++
struct Descriptor
{
    // error: should use unsigned long long
    unsigned int LimitLow : 16;
    unsigned int BaseLow : 24;
    unsigned int Attribute : 16;
    unsigned int BaseHigh : 8;
}
```
定义位域时建议结合`#pragma pack`指令将结构体对齐值修改为1，防止数据结构错位。
```c++
// 保存原始对齐值，设置新对齐
#pragma pack(push, 1)
// 结构体定义……
// 恢复原始对齐值
#pragma pack(pop)
```
位域成员按定义顺序在内存中由低地址向高地址排列，具体布局与机器相关。
取地址符`&`不能作用于位域，因此任何指针都无法指向类的位域。
如果可能的话，类内部连续定义的位域会压缩在同一整数的相邻位，从而提供存储压缩。
访问位域的方式与访问类的其他数据成员的方式类似。操作超过1位的位域时，通常会使用内置的位运算符。
```c++
File &File::open(File::modes m)
{
    mode |= READ;   // set the READ bit by default
    // other processing
    if (m & WRITE)  // if opening READ and WRITE
        // processing to open the file in read/write mode
        return *this;
}
```
## Variable-Length Argument Lists
假设想编写一个快速调试的函数，如果设置了调试标记，这个函数向 `stderr` 输出字符串，但如果没有设置调试标记，就什么都不做，这个函数应该能接收任意数目和任意类型的参数并输出字符串：
```cpp
#include <cstdio>
#include <cstdarg>
bool debug { false };
void debugOut(const char* str, ...)
{
    va_list ap;
    if (debug) {
        va_start(ap, str);
        vfprintf(stderr, str, ap);
        va_end(ap);
    }
}

debug = true;
debugOut("int %d\n", 5);
debugOut("String %s and int %d\n", "hello", 5);
debugOut("Many ints: %d, %d, %d, %d, %d\n", 1, 2, 3, 4, 5);
```
`debugOut` 函数的原型包含一个具有类型和名称的参数 `str`，之后是省略号，这代表任意数目和类型的参数。如果要访问这些参数，必须使用 `<cstdarg>` 中定义的宏。声明一个 `va_list` 类型的变量，并调用 `va_start` 对其进行初始化，`va_start` 的第二个参数必须是参数列表中最右边的已命名变量。所有具有变参数列表的函数都至少需要一个已命名的参数。
`debugOut` 函数只是将列表传递给 `vfprintf`，`vfprintf` 的调用返回时，`debugOut` 调用 `va_end` 来终止对变长参数列表的访问。
### Accessing the Arguments
如果想要访问实际参数，那么可以使用 `va_arg`，它接收 `va_list` 作为第一个参数，以及需要解析的参数的类型作为第二个参数。但是，如果不提供显示的方法，就无法知道参数列表的结尾是什么。例如，可以将第一个参数作为参数个数的计数，或者当参数是一组指针时，可以要求最后一个指针是 `nullptr`。
下面的示例演示了这种技术，其中调用者在第一个已命名参数中指定所提供参数的数目，函数接收任意数目的 `int` 参数，并将其输出。
```cpp
void printInts(size_t num, ...)
{
    va_list ap;
    va_start(ap, num);
    for (size_t i { 0 }; i < num; ++i) {
        int temp { va_arg(ap, int) };
        cout << temp << " ";
    }
    va_end(ap);
    cout << endl;
}
```
### Why Shouldn’t Use
访问 `C` 风格的变长参数列表并不十分安全：
- 不知道参数的数目。在 `printInts` 中，必须信任调用者传递了与第一个参数指定的数目相等的参数，在 `debugOut` 中，必须相信调用者在字符数组之后传递的参数数目与字符数组中的格式代码一致。 
- 不知道参数的类型。`va_arg` 接收一种类型，用来解释当前的值。然而，可让 `va_arg` 将这个值解释为任意类型，因此无法验证正确的类型。
## C
### 为什么 C 不支持函数重载
编译器产生符号的规则不同：**C++代码产生的函数符号由函数名和参数列表组成，但C代码产生的函数符号只由函数名决定**。
### C/C++中的 const 的区别
- C++ 中 const 修饰的量可以不用初始化，当用变量初始化时会变为常变量，但 C 中必须初始化，**在 C 中不叫常量而叫常变量**
- 编译方式不同，**C 中 const 当作一个变量来编译生成指令**，但在 C++ 中所有出现 const 常量名字的地方，在编译期时都被常量的初始化替换
```c++
// .c
const int MAX_LEN  = 1024;

int* ptr = (int*)(&MAX_LEN); // 在 C 中是可以直接生效的
*ptr = 2048; 
cout << MAX_LEN << endl;      // 输出2048

// .cpp
const int a = 20;
int array[a] = {}; // 实质是编译期常量初始化替换，不是因为 a 是常量

const volatile int MAX_LEN  = 1024;

int* ptr = (int*)(&MAX_LEN); // 采用常量强制转换为非常量的手段修改其值
*ptr = 2048; // 若不使用volatile，是无法产生效果的，但实际是已经改了
cout << MAX_LEN << endl;      // 输出2048

int b = 10; // 变量的值在运行期才可知
const int a = b; // 因此现在 a 不是常量而是常变量，初始值不是立即数，是一个变量
int array[b] = {}; // 现在就不存在替换的情况，而类型上述修改操作也会像 C 一样直接生效
```
## Initialization
### Default
如果定义变量时没有指定初值，则变量被默认初始化。默认值取决于变量类型和变量定义的位置：
- 如果是**内置类型**的变量未被显式初始化，它的值由定义的位置决定：定义于任何函数体之外的变量被初始化为 0，定义在函数体内部的变量将不被初始化。一个未被初始化的内置类型变量的值是未定义的，如果试图拷贝或以其他形式访问此类值将引发错误。 
- 如果是**类类型**，则**每个类各自决定其初始化对象的方式。**
- 如果是**局部静态变量**，它将**执行值初始化**，内置类型的局部静态变量初始化为 0。
对于定义了自己的构造函数的类类型来说，要求值初始化是没有意义的；不管采用什么形式，对象都会通过默认构造函数来初始化。但对于内置类型，两种形式的差别就很大了；值初始化的内置类型对象有着良好定义的值，而默认初始化的对象的值则是未定义的。类似的，**对于类中那些依赖于编译器合成的默认构造函数的内置类型成员，如果它们未在类内被初始化，那么它们的值也是未定义的**。
> 初始化不是赋值，初始化的含义是创建变量时赋予其一个初始值，而赋值的含义是把对象的当前值擦除，而以一个新值来替代。
> 类内初始值的限制：或者放在花括号里，或者放在等号右边，记住不能使用圆括号。
### Copy/Direct
如果使用 = 初始化一个变量，实际上执行的是拷贝初始化，编译器把等号右侧的初始值拷贝到新创建的对象中去。与之相反，如果不使用等号，则执行的是直接初始化。
当初始值只有一个时，使用直接初始化或拷贝初始化都行。如果初始化要用到的值有多个，一般来说只能使用直接初始化的方式，对于用多个值进行初始化的情况，非要用拷贝初始化的方式来处理也不是不可以，不过需要显式地创建一个临时对象用于拷贝：
```c++
string s1 = "hiya";     // copy initialization
string s2("hiya");      // direct initialization
string s3(10, 'c');     // direct initialization
string s4 = string(10, 'c'); // copy initialization
```
如果提供了一个括号包围的初始值，就可以使用 auto。从初始值来推断想要分配的对象的类型。但是，由于编译器要用初始值的类型来推断要分配的类型，只有当括号中仅有单一初始值时才可以使用auto：
```c++
auto p1 = new auto(obj);      // p points to an object of the type of obj that object is initialized from obj
auto p2 = new auto{a, b, c};  // error: must use parentheses for the initializer
```
### Value
值初始化是一种初始化过程，通过空括号 `()` 或 `{}` 实现。内置类型初始化为 0，类类型由类的默认构造函数初始化。只有当类包含默认构造函数时，该类的对象才会被值初始化。
对于容器的初始化来说，如果只说明容器的大小而没有指定初始值的话，就会执行值初始化。此时编译器会生成一个值，而容器的元素被初始化为该值。
### 列表初始化
```c++
vector<int> v{1, 2, 3, 4, 5};
```
这是一个通用的、可以用于各种类的方法。从技术角度，编译器的魔法只是对 {1, 2, 3} 这样的表达式自动生成一个初始化列表，在这个例子里其类型是 initializer_list`<int>`。程序员只需要声明一个接受 initializer_list 的构造函数即可使用。从效率的角度，至少在动态对象的情况下，容器和数组也并无二致，都是通过拷贝（构造）进行初始化。
## NDEBUG
预处理变量 assert 的行为依赖于一个名为NDEBUG的预处理变量的状态。如果定义了NDEBUG，则assert什么也不做。默认状态下没有定义 NDEBUG，此时assert将执行运行时检查。 
可以使用一个#define语句定义NDEBUG，从而关闭调试状态。
除了用于assert外，也可以使用NDEBUG编写自己的条件调试代码。如果NDEBUG未定义，将执行#ifndef和#endif之间的代码；如果定义了NDEBUG，这些代码将被忽略掉：
![image-20221008235649381](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221008235649381.png)
编译器为每个函数都定义了`__func__`，它是const char的一个静态数组，用于存放函数的名字。 
除了C++编译器定义的`__func__`之外，预处理器还定义了另外4个对于程序调试很有用的名字： 
- `__FILE__` 存放文件名的字符串字面值。 
- `__LINE__` 存放当前行号的整型字面值。 
- `__TIME__` 存放文件编译时间的字符串字面值。 
- `__DATE__` 存放文件编译日期的字符串字面值。
## sizeof
sizeof 运算符返回一条表达式或一个类型名字所占的字节数。sizeof 运算符满足右结合律，其所得的值是一个 size_t 类型的常量表达式。运算符的运算对象有两种形式：type or expr，在第二种形式中，sizeof返回的是表达式结果类型的大小（但不计算表达式）。
![image-20220923201802679](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220923201802679.png)
这些例子中最有趣的一个是sizeof \*p。首先，因为sizeof满足右结合律并且与\*运算符的优先级一样，所以表达式按照从右向左的顺序组合。也就是说，它等价于sizeof（\*p）。其次，因为sizeof不会实际求运算对象的值，所以即使p是一个无效（即未初始化）的指针也不会有什么影响。**在sizeof的运算对象中解引用一个无效指针仍然是一种安全的行为，因为指针实际上并没有被真正使用。sizeof不需要真的解引用指针也能知道它所指对象的类型**。
> C++11新标准允许使用作用域运算符来获取类成员的大小。通常情况下只有通过类的对象才能访问到类的成员，但是sizeof运算符无须提供一个具体的对象，因为要想知道类成员的大小无须真的获取该成员。

**sizeof运算符的结果部分地依赖于其作用的类型：**
- 对char或者类型为char的表达式执行sizeof运算，结果得1。 
- 对引用类型执行sizeof运算得到被引用对象所占空间的大小。
- 对指针执行sizeof运算得到指针本身所占空间的大小。
- 对解引用指针执行sizeof运算得到指针指向的对象所占空间的大小，指针不需有效。
- 对数组执行sizeof运算得到整个数组所占空间的大小，等价于对数组中所有的元素各执行一次sizeof运算并将所得结果求和。注意，sizeof 运算不会把数组转换成指针来处理。
- 对string对象或vector对象执行sizeof运算只返回该类型固定部分的大小，不会计算对象中的元素占用了多少空间。 
因为执行sizeof运算能得到整个数组的大小，所以可以用数组的大小除以单个元素的大小得到数组中元素的个数：
![image-20220923202235934](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220923202235934.png)

## 字面量
### 自定义字面量
字面量（literal）是指在源代码中写出的固定常量，它们在 C++98 里只能是原生类型，如：
- "hello"，字符串字面量，类型是 const char[6]
- 1，整数字面量，类型是 int
- 0.0，浮点数字面量，类型是 double
- 3.14f，浮点数字面量，类型是 float
- 123456789ul，无符号长整数字面量，类型是 unsigned long
C++11 引入了自定义字面量，可以使用 operator"" 后缀来将用户提供的字面量转换成实际的类型。
要在自己的类里支持字面量也相当容易，唯一的限制是非标准的字面量后缀必须以下划线 _ 打头。比如，假如有下面的长度类：
```c++
struct length {
  double value;
  enum unit { metre, kilometre, millimetre, centimetre, inch, foot, yard, mile, };
  static constexpr double factors[] = {1.0,    1000.0,  1e-3, 1e-2,   0.0254,  0.3048, 0.9144, 1609.344};
  explicit length(double v, unit u = metre) { value = v * factors[u]; }
};

length operator+(length lhs, length rhs) {
  return length(lhs.value + rhs.value);
}
// 可以手写 length(1.0, length::metre) 这样的表达式，但估计大部分开发人员都不愿意这么做吧。
// 反过来，如果我们让开发人员这么写，大家应该还是基本乐意的：1.0_m + 10.0_cm
//要允许上面这个表达式，我们只需要提供下面的运算符即可：
length operator"" _m(long double v) {
  return length(v, length::metre);
}

length operator"" _cm(long double v) {
  return length(v, length::centimetre);
}
```
### 二进制字面量
C++ 里有 0x 前缀，可以让开发人员直接写出像 0xFF 这样的十六进制字面量。另外一个目前使用得稍少的前缀就是 0 后面直接跟 0–7 的数字，表示八进制的字面量
```c++
unsigned mask = 0b111000000;
```
不过，遗憾的是， I/O streams 里只有 dec、hex、oct 三个操纵器（manipulator），而没有 bin，因而输出一个二进制数不能像十进制、十六进制、八进制那么直接。一个间接方式是使用 bitset，但调用者需要手工指定二进制位数：
```c++
#include <bitset>
cout << bitset<9>(mask) << endl;
```
### 数字分隔符
C++14 开始，允许在数字型字面量中任意添加 ' 来使其更可读。具体怎么添加，完全由程序员根据实际情况进行约定。某些常见的情况可能会是：
```c++
unsigned mask = 0b111'000'000;
long r_earth_equatorial = 6'378'137;
double pi = 3.14159'26535'89793;
const unsigned magic = 0x44'42'47'4E;
```
### 原始字符串
使用前缀R标识，`"()"`为定界符
为了显示`"()"`  可以自定义定界符添加 +\*，即  `R " +* (    ) +* "`;
```C++
cout << R"(jadof;lghahg;aroi)";
cout << R"+*(   /n\n"(3oq2ptkg3lb()ikral;l{}jadof;lghahg;aroi)"   )+*";
```
## static_assert
assert 吧，用来断言一个表达式必定为真。比如说，数字必须是正数，指针必须非空、函数必须返回 true：
```c++
assert(i > 0 && "i must be greater than zero");
assert(p != nullptr);
assert(!str.empty());
```
当程序（也就是 CPU）运行到 assert 语句时，就会计算表达式的值，如果是 false，就会 输出错误消息，然后调用 abort() 终止程序的执行。assert 虽然是一个宏，但在预处理阶段不生效，而是在运行阶段才起作用，所以又叫“动态断言”
有了“动态断言”，那么相应的也就有“静态断言”，叫“static_assert”，不过它是一个专门的关键字，而不是宏。因为它只在编译时生效， 运行阶段看不见，所以是“静态”的，它是编译阶段里检测各种条件的“断言”，编译器看 到 static_assert 也会计算表达式的值，如果值是 false，就会报错，导致编译失败
```c++
template<int N>
struct fib
{
    static_assert(N >= 0, "N >= 0");
    static const int value = fib<N - 1>::value + fib<N - 2>::value;
};
```
static_assert 运行在编译阶段，只能看到编译时的常数和类型，看不 到运行时的变量、指针、内存数据等，是“静态”的，所以不要简单地把 assert 的习惯搬 过来用。 
比如，下面的代码想检查空指针，由于变量只能在运行阶段出现，而在编译阶段不存在，所 以静态断言无法处理。
```c++
char* p = nullptr;
static_assert(p == nullptr, "some error."); // 错误用法
```

## nullptr
`nullptr`的优点是它不是整型。它也不是一个指针类型，但是可以把它认为是所有类型的指针。`nullptr`的真正类型是`nullptr_t`，`nullptr_t`可以隐式转换为指向任何内置类型的指针，这也是为什么`nullptr`表现得像所有类型的指针。
**模板类型推导将`0`和`NULL`推导为一个错误的类型（即它们的实际类型，而不是作为空指针的隐含意义）**，这就导致在当你想要一个空指针时，它们的替代品`nullptr`很吸引人。使用`nullptr`，模板不会有什么特殊的转换。另外，使用`nullptr`不会让你受到同重载决议特殊对待`0`和`NULL`一样的待遇。当你想用一个空指针，使用`nullptr`，不用`0`或者`NULL`。
## 类型转换的标准库模板类
标准库在头文件`type_traits`中定义了类型转换模板，这些模板常用于模板元程序设计。其中每个模板都有一个名为`type`的公有类型成员，表示一个类型。此类型与模板自身的模板类型参数相关。如果不可能（或不必要）转换模板参数，则`type`成员就是模板参数类型本身。
使用`remove_reference`可以获得引用对象的元素类型，如果用一个引用类型实例化`remove_reference`，则`type`表示被引用的类型。
因为`type`是一个类的类型成员，所以在模板中必须使用关键字`typename`来告知编译器其表示一个类型。
`remove_reference<decltype(*beg)>::type` 将获得 `beg` 引用的元素的类型：`decltype(*beg)` 返回元素类型的引用类型。`remove_reference::type` 脱去引用，剩下元素类型本身。`type` 是一个类的成员，而该类依赖于一个模板参数。因此，必须在返回类型的声明中使用 `typename` 来告知编译器，`type` 表示一个类型：
```c++
// must use typename to use a type member of a template parameter
template <typename It>
auto fcn2(It beg, It end) -> typename remove_reference<decltype(*beg)>::type
{
    // process the range
    return *beg;  // return a copy of an element from the range
}
```
![image-20221014170542115](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221014170542115.png)
每个模板都有一个名为 `type` 的 `public` 成员，表示一个类型。此类型与模板自身的模板类型参数相关，其关系如模板名所示。如果不可能/不必要转换模板参数，则 `type` 成员就是模板参数类型本身。例如，如果 `T` 是一个指针类型，则 `remove_pointer::type` 是 `T` 指向的类型。如果 `T` 不是一个指针，则无须进行任何转换，从而 `type` 具有与 `T` 相同的类型。
## () and {}
括号表达式不允许内置类型间隐式的变窄转换。如果一个使用了括号初始化的表达式的值，不能保证由被初始化的对象的类型来表示，代码就不会通过编译：
```c++
double x, y, z;
int sum1{ x + y + z };          //错误！double的和可能不能表示为int

// 使用小括号和=的初始化不检查是否转换为变窄转换，因为由于历史遗留问题它们必须要兼容老旧代码
int sum2(x + y +z);             //可以（表达式的值被截为int）
int sum3 = x + y + z;           //同上
```
另一个值得注意的特性是括号表达式对于 `C++ `最令人头疼的解析问题有天生的免疫性。`C++` 规定任何能被决议为一个声明的东西必须被决议为声明。这个规则的副作用是：当想创建一个使用默认构造函数构造的对象，却不小心变成了函数声明。
```c++
Widget w1(10);                  //使用实参10调用Widget的一个构造函数
Widget w2();                    //最令人头疼的解析！声明一个函数w2，返回Widget
```
由于函数声明中形参列表不能使用花括号，所以使用花括号初始化表明想调用默认构造函数构造对象就没有问题：
```c++
Widget w3{};                    //调用没有参数的构造函数构造对象
```
如果有一个或者多个构造函数的声明一个 `initializer_list` 形参，使用括号初始化语法的调用更倾向于适用 `initializer_list` 重载函数。而且只要某个使用括号表达式的调用能适用接受 `initializer_list` 的构造函数，编译器就会使用它，只有当没办法把括号初始化中实参的类型转化为 `initializer_list` 时，编译器才会回到正常的函数决议流程中。
对于数值类型的 `vector` 来说使用花括号初始化和小括号初始化会造成巨大的不同
```cpp
vector<int> v1(10, 20);//使用非initializer_list构造函数创建一个包含10个元素的vector
vector<int> v2{10, 20};//使用initializer_list构造函数创建包含两个元素的vector
```

