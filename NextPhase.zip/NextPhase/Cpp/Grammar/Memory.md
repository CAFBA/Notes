# Memory
## Memory
局部变量是在栈上分配的自动变量，当程序流离开作用域(变量在这个作用域中声明)时，会自动释放 。使用 `new` 关键字时，内存分配在自由存储区中。下面的代码在栈上创建了一个变量 `ptr`, 然后在 自由存储区上分配内存，`ptr` 指向这块内存。
```cpp
int* ptr { new int };
```
变量 `ptr` 仍在栈上，即使它指向的是自由存储区中的内存。指针只是一个变量，可在栈或自由存储区中：
```cpp
int** handle { nullptr };
handle = new int*;
*handle = new int;
```
上面的代码首先声明一个指向整数指针的指针变量 `handle`。然后，动态分配足够的内存来保存一个指向整数的指针，并将指向这个新内存的指针保存在 `handle` 中。接下来，将另一块足以保存整数的动态内存的指针保存在 `*handle` 的内存位置。这个两级指针，其中一个指针 `handle` 保存在桟中，另一个指针` *handle` 保存在自由存储区中。
## New/Delete
由内置指针（而不是智能指针）管理的动态内存在被显式释放前一直都会存在，特别是当一个指针离开其作用域时，如果这个指针指向的是动态内存，那么内存将不会被自动释放。
`new` 在动态内存中为对象分配空间并返回一个指向该对象的指针，该指针存储所分配的内存地址，可以选择对对象进行初始化。在自由空间分配的内存是无名的，因此 `new` 无法为其分配的对象命名，而是返回一个指向该对象的指针。
```c++
int *p1 = new int(20); // 在堆上开辟一块内存
int *p2 = new int[20](); // 并初始化为 0 
int *p3 = new (nothrow) int; // 保证不抛出异常 
const int *p4 = new const int(20); // 在堆上开辟一个常量内存
int data = 0;
int *p5 = new (&data) int(20); // 在指定地址上划分一块内存，并初始化为20，现在data为20
```
`delete` 销毁给定的指针指向的对象，释放对应的内存。传递给 `delete` 的指针必须指向动态分配的内存，或者是一个空指针。**释放一块并非 `new` 分配的内存，或者将相同的指针值释放多次，其行为是未定义的**。
当 `delete` 一个指针后，指针值就变为无效。虽然指针已经无效，但在很多机器上指针仍然保存着已经释放的动态内存的地址。在 `delete` 之后，指针就变成了**空悬指针，指向一块曾经保存数据对象但现在已经无效的内存**。
如果需要保留指针，可以在 `delete` 之后将 `nullptr` 赋予指针，这样就清楚地指出指针不指向任何对象。但这只提供有限的保护：动态内存的一个基本问题是可能有多个指针指向相同的内存，`在delete` 内存之后重置指针的方法只对这个指针有效，对其他任何仍指向已释放的内存的指针是没有作用的。
```c++
int *p = new int(42); // p指向动态内存 
auto q = p; // p 和 q 指向相同的内存 
delete p; // p 和 q 均变为无效 
p = nullptr; // 指出 p 不再绑定到任何对象 
```
`New/Delete` 重载见 [[Overload#Memory Allocation And Deallocation Operators]]
### 动态数组
可以使用 `new[]` 分配对象数组，在方括号中指明要分配的对象数量（必须是整型，但不必是常量），`new[]` 返回指向第一个对象的指针。
```c++
// call get_size to determine how many ints to allocate
int *pia = new int[get_size()];   // pia points to the first of these ints
typedef int arrT[43];
int *p = new arrT;
```
虽然通常称 `new T[]` 分配的内存为动态数组，但**当用 `new` 分配一个数组时，并未得到一个数组类型的对象，而是得到一个数组元素类型的指针**。即使使用类型别名定义一个数组类型，`new` 也不会分配一个数组类型的对象。由于 `new` 分配的内存并不是数组类型，因此不能对动态数组调用 `begin` 和 `end`，也不能用范围 `for` 语句处理其中的元素。
使用 `delete[]` 释放动态数组，将会自动逆序析构数组中的对象，并释放这些对象的内存，即最后一个元素首先被销毁。当释放一个指向数组的指针时，空方括号对是必需的：它指示编译器此指针指向一个对象数组的第一个元素。
```c++
delete []p;       // p must point to a dynamically allocated object or be null
```
如果有一个指针数组，那么还需要逐个释放每个指针指向的对象，就像逐个分配对象一样：
```cpp
const size_t size { 4 };
Simple** mySimplePtrArray { new Simple*[size] };
// Allocate an object for each pointer.
for (size_t i { 0 }; i < size; i++) { mySimplePtrArray[i] = new Simple{}; }
// Use mySimplePtrArray...
// Delete each allocated object.
for (size_t i { 0 }; i < size; i++) {
    delete mySimplePtrArray[i];
    mySimplePtrArray[i] = nullptr;
}
// Delete the array itself.
delete [] mySimplePtrArray;
mySimplePtrArray = nullptr;
```
在编译时给数组分配内存称为静态联编，意味着数组是在编译时加入到程序中的，但使用 `new` 则只在运行阶段需要时创建，称为动态联编，意味着是在程序运行时创建的，其长度将在运行时设置。
### 多维动态数组
自由存储区上的数组和栈上的数组的工作方式不一样。多维数组的内存布局是不连续的，并且编译器并不自动分配子数组的内存，因此必须显式地分配每一个子数组。可以首先为自由存储区数组的第一个下标分配一个连续的数组，该数组的每个元素实际上是指向另一个数组的指针，另一个数组保存的是第二个下标维度的元素。
```cpp
char** allocateCharacterBoard(size_t xDimension, size_t yDimension)
{
    char** myArray { new char*[xDimension] }; // Allocate first dimension
    for (size_t i { 0 }; i < xDimension; i++) 
        myArray[i] = new char[yDimension]; // Allocate ith subarray
    return myArray;
}
```
要释放多维自由存储区数组的内存，`delete[]` 也不能自动清理子数组。释放数组 代码应该类似于分配数组的代码：
```cpp
void releaseCharacterBoard(char**& myArray, size_t xDimension)
{
    for (size_t i { 0 }; i < xDimension; i++) {
        delete [] myArray[i]; // Delete ith subarray
        myArray[i] = nullptr;
    }
    delete [] myArray; // Delete first dimension
    myArray = nullptr;
}
```
## Initialize
### New
默认情况下，**动态分配的对象是默认初始化的**，这意味着**内置类型或组合类型的对象的值将是未定义的**，而类类型对象将用默认构造函数进行初始化：
```c++
string *ps = new string;    // initialized to empty string
int *pi = new int;          // pi points to an uninitialized int
```
可以使用值初始化方式、构造方式或列表初始化方式初始化动态分配的对象。
```c++
int *pi = new int(1024);            // 值初始化
string *ps = new string(10, '9');   // 构造方式

vector<int> *pv = new vector<int>{0, 1, 2, 3, 4, 5, 6, 7, 8, 9}; // 列表初始化

string *ps1 = new string;     // default initialized to the empty string
string *ps = new string();    // value initialized to the empty string

int *pi1 = new int;      // default initialized; *pi1 is undefined
int *pi2 = new int();    // value initialized to 0; *pi2 is 0
```
对于定义构造函数的类类型来说，要求值初始化是没有意义的，不管采用什么形式，对象都会通过构造函数来初始化。但对于内置类型，两种形式的差别就很大。**值初始化的内置类型对象有着良好定义的值，而默认初始化的对象的值则是未定义的**。类似的，对于类中那些依赖于编译器合成的默认构造函数的内置类型成员，如果它们未在类内被初始化，那么它们的值也是未定义的。
可以用 `new` 分配 `const` 对象，返回指向 `const` 类型的指针。类似其他任何 `const` 对象，**一个动态分配的 `const` 对象必须进行初始化**。由于分配的对象是 `const` 的，`new` 返回的指针是一个指向 `const` 对象的指针。虽然一个 `const` 对象的值不能被改变，但它本身是可以被销毁的。如同任何其他动态对象一样，想要释放一个 `const` 动态对象，只要 `delete` 指向它的指针即可：
```c++
const int *pci = new const int(1024); 
delete pci;  // 正确：释放一个 const 对象
```
### New[]
可以对数组中的元素进行值初始化，方法是在大小后面跟一对空括号 `()`，还可以提供一个元素初始化器的花括号列表。如果初始化器数量大于元素数量，则 `new` 表达式失败，不会分配任何内存，并抛出 `bad_array_new_length` 异常。
```c++
int *pia = new int[10];     // block of ten uninitialized ints
int *pia2 = new int[10]();    // block of ten ints value initialized to 0
string *psa = new string[10];    // block of ten empty strings
string *psa2 = new string[10]();    // block of ten empty strings

// new[] 初始化数组指定特定值只能使用大括号
int *pia2 = new int[10]{0}    // block of ten ints value initialized to 0

// block of ten ints each initialized from the corresponding initializer
int *pia3 = new int[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
// block of ten strings; the first four are initialized from the given initializers
// remaining elements are value initialized
string *psa3 = new string[10] { "a", "an", "the", string(3,'x') };
```
动态分配一个空数组是合法的，此时 `new` 会返回一个合法的非空指针。对于零长度的数组来说，该指针类似尾后指针，不能解引用。
## 执行过程
`new` 和 `delete` 称作运算符表达式，`malloc` 和 `free` 是 `C` 的库函数。
```c++
void *malloc(unsigned int num_bytes);
void free(void *ptr);

int *q1 = (int&)malloc(sizeof(int) * 20);
free(q1);
int *q2 = new int(); // 并初始化为 0
delete q2;
```
`malloc` 函数接受一个表示待分配字节数的 `size_t` 参数，返回指向分配空间的 `void*`，或者返回空指针以表示分配失败，只开辟内存不调用构造函数。
使用 `new` 表达式时，实际执行三步操作：
- `new` 表达式调用名为 `operator new` 或 `operator new[]` 的标准库函数。该函数分配一块足够大、原始、未命名的内存空间以便存储特定类型的对象（或对象数组），若分配失败，抛出 `bad_alloc` 异常，不抛出异常的 `new` 版本它会返回 `nullptr`。
- 编译器调用对应的构造函数构造这些对象并初始化。
- 对象被分配了空间并构造完成，返回指向该对象的指针。
`free` 函数接受一个 `void*` 参数，它是 `malloc` 返回的指针的副本，`free` 将相关内存返回给系统，只释放内存不会调用析构函数，调用 `free(0)` 没有任何意义。
使用 `delete` 表达式时，实际执行两步操作：
- 对指针所指向的对象（或对象数组）执行对应的析构函数。
- 编译器调用名为 `operator delete` 或` operator delete[]` 的标准库函数释放内存空间。
```c++
int *mem = new int[10];
delete []mem;
```
使用 `New[]` 表达式时，先调用 `operator new[]` 分配内存，分配内存时会多分配对应类型的字节用于记录存储对象的个数，因此 `operator new[]` 返回的内存地址与 `new[]` 实际返回的内存地址之间相差对应类型的字节，即 `mem - 4` 与 `mem`，`mem` 是指向数组的第一个元素的指针，之后调用对象的构造函数。
使用 `Delete[]` 表达式时，先调用对象的析构函数，之后由于是 `delete[]` 形式，因此编译器调用 `operator delete[]`，会将 `mem` 的内存地址减去偏移量，从 `mem - 4` 开始释放内存。
因此对于内置类型，`new` 两种形式混用不会出现问题，而对于类类型，由于会调用类的构造与析构函数，因此需要多开辟一段内存记录对象的个数，如果混用两种形式，会导致释放内存时的起始地址存在偏差。
## Placement new
在 `C++` 的早期版本中，`allocator`类还不是标准库的一部分。如果程序想分开内存分配和初始化过程，需要直接调用`operator new`和`operator delete`函数。它们类似`allocator`类的`allocate`和`deallocate`成员，负责分配或释放内存空间，但不会构造或销毁对象。
与 `allocator` 不同的是，不能使用`allocator`类的`construct`函数在`operator new`分配的内存空间中构造对象，而应该使用定位`new`表达式构造。
```c++
new (place_address) type
new (place_address) type (initializers)
new (place_address) type [size]
new (place_address) type [size] { braced initializer list }
```
其中 `place_address` 是一个指针。`initializers` 是一个以逗号分隔的初始值列表，该列表用于构造新分配的对象。
当仅通过一个地址值调用定位 `new `时，它会使用 `operator new(size_t, void*)` 函数（用户无法重载的版本）。该函数不分配任何内存，直接返回指针形参。然后由 `new` 表达式负责在指定的地址初始化对象。
```c++
void *operator new(size_t, void*);   // this version may not be redefined
```
传递给 `construct` 函数的指针必须指向同一个 `allocator` 对象分配的空间，但是传递给定位`new` 的指针无须指向 `operator new` 分配的内存，甚至不需要指向动态内存。
默认情况下，如果 `new` 不能分配所要求的内存空间，会抛出 `bad_alloc` 异常。使用定位 `new` 可以阻止其抛出异常。定位 `new` 表达式允许程序向 `new` 传递额外参数。如果将 `nothrow` 传递给`new`，则 `new` 在分配失败后会返回空指针。`bad_alloc` 和 `nothrow` 都定义在头文件 `new` 中。
```c++
// if allocation fails, new returns a null pointer
int *p1 = new int;            // if allocation fails, new throws std::bad_alloc
int *p2 = new (nothrow) int;  // if allocation fails, new returns a null pointer
```
## allocator类
标准库allocator类定义在头文件memory中，它帮助我们将内存分配 和对象构造分离开来。它提供一种类型感知的内存分配方法，它分配的内存是原始的、未构造的。当一个allocator对象分配内存时，它会根据给定的对象类型来确定恰当的内存大小和对齐位置。
![image-20221011193127049](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221011193127049.png)
```c++
allocator<string> alloc;    // object that can allocate strings
auto const p = alloc.allocate(n);   // allocate n unconstructed strings
```
`allocator`分配的内存是未构造的，程序需要在此内存中构造对象。新标准库的`construct`函数接受一个指针和零或多个额外参数，在给定位置构造一个元素。额外参数用来初始化构造的对象，必须与对象类型相匹配。
```c++
auto q = p;     // q will point to one past the last constructed element
alloc.construct(q++);    // *q is the empty string
alloc.construct(q++, 10, 'c');  // *q is cccccccccc
alloc.construct(q++, "hi");     // *q is hi!
```
> 为了使用allocate返回的内存，必须用construct构造对象。使用未构造的内存，其行为是未定义的。

对象使用完后，必须对每个构造的元素调用`destroy`进行销毁。`destroy`函数接受一个指针，对指向的对象执行析构函数。
```c++
while (q != p)
    alloc.destroy(--q);  // free the strings we actually allocated
```
在循环开始处，q指向最后构造的元素之后的位置。在调用 destroy之前对q进行了递减操作。因此，第一次调用destroy时，q指向最后一个构造的元素。最后一步循环中destroy了第一个构造的元素， 随后q将与p相等，循环结束
一旦元素被销毁后，就可以重新使用这部分内存来保存其他 string，也可以将其归还给系统。`deallocate`函数用于释放`allocator`分配的内存空间。传递给`deallocate`的指针不能为空，它必须指向由`allocator`分配的内存。而且传递给`deallocate`的大小参数必须与调用`allocator`分配内存时提供的大小参数相一致。
```c++
alloc.deallocate(p, n);
```
标准库还为allocator类定义了两个伴随算法，可以在未初始化内存中创建对象。
![image-20221011193654025](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221011193654025.png)
假定有一个int的vector，希望将其内容拷贝到动态内存中。将分配一块比vector中元素所占用空间大一倍的动态内存，然后将原vector中的元素拷贝到前一半空间，对后一半空间用一个给定值进行填充：
```c++
auto p= alloc.allocate(vi.size() *2); // 分配比vi 中元素所占用空间大一倍的动态内存
auto q = uninitialized_copy(vi.begin(), vi.end(),p); // 通过拷贝vi中的元素来构造从p开始的元素
uninitialized_fill_n(q, vi.size(), 42); // 将剩余元素初始化为42
```
传递给`uninitialized_copy`的目的位置迭代器必须指向未构造的内存，与copy不同，它直接在给定位置构造元素。类似copy，uninitialized_copy返回（递增后的）目的位置迭代器。 
因此，一次uninitialized_copy调用会返回一个指针，指向最后一个构造的元素之后的位置。在本例中，将此指针保存在q中，然后将q传递给uninitialized_fill_n。此函数类似fill_n，接受一个指向目的位置的指针、一个计数和一个值。它会在目的位置指针指向的内存中创建给定数目个对象，用给定值对它们进行初始化。
## 重载 operator new 用于对象池
```c++
template<typename T>
class Queue {
public:
    explicit Queue() {
        _front = _rear = new QueueItem();
    }
    ~Queue() {
        QueueItem *cur = _front; // 记录当前节点
        while (cur != nullptr) {
            _front = _front->_next; // 遍历
            delete cur;             // 删除当前节点
            cur = _front;           // 更新当前节点
        }
    }
    void push(const T &val) {
        auto *item = new QueueItem(val);
        _rear->_next = item; // 添加到队尾
        _rear = item;        // 队尾现在是新添加的
    }
    void pop() {
        if (empty()) return;
        QueueItem *first = _front->_next; // 记录队头
        _front->_next = _front->_next->_next;     // 弹出队头
        if (_front->_next == nullptr) _rear = _front;
        delete first;                     // 释放之前的队头内存
    }
    T front() const {
        return _front->_next->_date;
    }
    bool empty() {
        return _front == _rear;
    }
private:
    struct QueueItem {
        T _date;
        QueueItem *_next;
        static QueueItem *_itemPool;
        static const int POOL_ITEM_SIZE = 10000;
        explicit QueueItem(T date = T()): _date(date), _next(nullptr) {}
        void* operator new(size_t size) {
            if (_itemPool == nullptr) {
                _itemPool = (QueueItem*) malloc(POOL_ITEM_SIZE * sizeof(QueueItem)); // 开辟内存作为对象池
                QueueItem *p = _itemPool; // 记录指向对象池第一个空闲块的指针
                for (;p < _itemPool + POOL_ITEM_SIZE - 1; p++) p->_next = p + 1; // 将内存块串成链表
                p->_next = nullptr; // 将尾内存块指向空
            }
            QueueItem *p = _itemPool; // 若已经有对象池，则从对象池中取出
            _itemPool = _itemPool->_next; // 遍历到下一个空闲块
            return p; // 返回内存
        }
        void operator delete(void *ptr) {
            auto *p = (QueueItem*) ptr; // 将归还的内存块作为第一个空闲块
            p->_next = _itemPool;       // 归还的内存块的下一个空闲块为原本的第一个空闲块
            _itemPool = p;              // 归还
        }
    };
    // 链式队列
    QueueItem *_front; // 虚拟头节点
    QueueItem *_rear;  // 尾节点，指向队尾元素
};

template<typename T>
typename Queue<T>::QueueItem *Queue<T>::QueueItem::_itemPool = nullptr;
```