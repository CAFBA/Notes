# STL Component

![image-20220518224224128](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220518224224128.png)

## Allocator

![image-20220522211505975](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522211505975.png)

![image-20220522211427025](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522211427025.png)

![image-20220522211514402](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522211514402.png)

## Traits

![image-20220522210228737](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522210228737.png)

![image-20220522210240147](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522210240147.png)

![image-20220522210340318](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522210340318.png)

![image-20220522215014321](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522215014321.png)

> 引例以`list`为例说明提问的五种类型，均来自于名为`list_iterator`这一对容器`list`的类迭代器，因此直接调用其成员便可以回答提问
>
> 现在需要的是一个泛化的，这就意味着不只是类迭代器，还有可能是普通的指针，普通的指针是无法调用成员去回答这些问题的，因此`traits`，作为一个中间介质，对类迭代器和非类迭代器进行区分
>
> 以上述为例，`vecotr<int>::iterator ite = vec.begin` 中的`int`说明是非迭代器指针，因此当`algorithm`向`iterator`提问，即`iterator_traits<I>::value_type`时，`iterator_traits`的`I::value_type`调用的将是其对普通指针的特化版本来告诉回答问题
>
> 若传入的不是`int`而是迭代器指针，那么需要注意的是`iterator_traits`中存在着`typename`，因此可以指明内含的类型I就指的是`int`

## Contanier

### List

![image-20220522200719482](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522200719482.png)

![image-20220522200728747](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522200728747.png)

![image-20220522200738899](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522200738899.png)

![image-20220522201119203](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522201119203.png)

> G2.9中只有一个list node指针，因此大小为字节4
>
> 这个指针是结构体类型，只在乎这个指针指向谁，而不在乎结构体内有什么，因此就只是指针大小4
>
> G4.9中由于继承的基类有两个指针，因此大小为字节8

### Vector

![image-20220522211549797](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522211549797.png)

![image-20220522211610412](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522211610412.png)

![image-20220522211619397](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522211619397.png)

![image-20220522215014321](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522215014321.png)

![image-20220522215429722](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522215429722.png)

![image-20220522215437142](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522215437142.png)

### Array

![image-20220522215455384](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522215455384.png)

![image-20220522215728917](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522215728917.png)

### deque

> 比对一个list类对象的大小只有4个字节，deque需要40个字节
>
> 因为list对象数据成员只有一个指针，但为什么它不需要迭代器数据成员但deque就需要呢

![image-20220522220343079](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522220343079.png)

![image-20220522221659735](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522221659735.png)

![image-20220522221718676](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522221718676.png)

![image-20220522221728802](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522221728802.png)

![image-20220522222257588](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522222257588.png)

![image-20220522222304900](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522222304900.png)

![image-20220522222316858](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522222316858.png)

![image-20220522222322974](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522222322974.png)

![image-20220522224306639](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220522224306639.png)

### queue、stack

![image-20220523142847224](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523142847224.png)

![image-20220523142855660](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523142855660.png)

![image-20220523143349482](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523143349482.png)

### Rb_tree

![image-20220523162204471](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523162204471.png)

![image-20220523162231869](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523162231869.png)

![image-20220523162244303](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523162244303.png)

### Set

![image-20220523174523826](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523174523826.png)

![image-20220523174534124](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523174534124.png)

### Map

![image-20220523181449220](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523181449220.png)

![image-20220523181501007](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523181501007.png)

![image-20220523181519430](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523181519430.png)

### hashtable

![image-20220523182716577](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523182716577.png)

![image-20220523182724532](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523182724532.png)

![image-20220523200129392](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523200129392.png)

![image-20220523200142473](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523200142473.png)

![image-20220523200217322](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523200217322.png)

![image-20220523201537851](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523201537851.png)

![image-20220523201703753](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220523201703753.png)

## Algorithm

![image-20220525093837108](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525093837108.png)

![image-20220525093845697](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525093845697.png)

![image-20220525093852031](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525093852031.png)

![image-20220525094248614](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525094248614.png)

![image-20220525095032766](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525095032766.png)

### accumulate

![image-20220525121407201](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525121407201.png)

### foreach

![image-20220525121413622](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525121413622.png)

### replace

![image-20220525124533066](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525124533066.png)

### count

![image-20220525124703815](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525124703815.png)

### sort

![image-20220525124807263](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525124807263.png)

### find

![image-20220525124750336](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525124750336.png)

### reserve

![image-20220525124909395](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525124909395.png)

### binary_search

![image-20220525124920265](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525124920265.png)

## Functors

![image-20220525132631750](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525132631750.png)

![image-20220525132657680](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525132657680.png)

> adapter问问题，functor则回答问题，为了能够回答问题，需要继承从而得到typedef	
>
> 即functor的可适配条件就是继承从而得到typedef回答问题

![image-20220525133011138](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525133011138.png)

## Adapters

### bind2nd

![image-20220525142351094](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525142351094.png)

### not1

![image-20220525142409142](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525142409142.png)

### bind

![image-20220525143352807](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525143352807.png)

### reverse_iterator

![image-20220525144153174](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525144153174.png)

### inserter

![image-20220525144208939](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525144208939.png)



### ostream_iterator

![image-20220525144226010](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525144226010.png)



### istream_iterator

![image-20220525144234230](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220525144234230.png)
