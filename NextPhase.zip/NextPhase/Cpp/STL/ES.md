# Container
## 1：谨慎选择容器类型
### Classification
`STL` 容器的一种分类方法：对连续内存容器和基于节点的容器的区分。
连续内存容器，或称为基于数组的容器，把它的元素存放在一块或多块（动态分配的）内存中，每块内存中存有多个元素。当有新元素插入或已有的元素被删除时，同一内存块中的其他元素要向前或向后移动，以便为新元素让出空间，或者填充被删除元素所留下的空隙。这种移动影响到效率（参见第 5 条、第 14 条）和异常安全性。标准的连续内存容器有 `vector`、`string`、`deque`。非标准的 `rope` 也是一个连续内存容器。
基于节点的容器在每一个动态分配的内存块中只存放一个元素。容器中元素的插入或删除只影响到指向节点的指针，而不影响节点本身的内容，所以当有插入或删除操作时，元素的值不需要移动。表示链表的容器，如 `list` 和 `slist`，是基于节点的；所有标准的关联容器也是如此（通常的实现方式是平衡树）。非标准的散列容器使用不同的基于节点的实现，在第 25 条将会看到这一点。
标准 `STL` 序列容器 ：`vector`、`string`、`deque` 和 `list`。
标准 `STL` 关联容器 ：`set`、`multiset`、`map` 和 `multimap`。
非标准序列容器 `slist` 和 `rope`：`slist` 是一个单向链表，`rope` 本质上是 `rope`。可以在第 50 条中找到对这些非标准（但通常可以使用）的容器的一个简要介绍。
非标准关联容器 `hash_set`、`hash_multiset`、`hash_map` 和 `hash_multimap`：在第25条中，分析了这些基于散列表的、标准关联容器的变体（它们通常是广泛可用的）。
`vector<char>` 作为 `string` 的替代：第 13 条讲述了在何种条件下这种替代是有意义的。
`vector` 作为标准关联容器的替代：正如第 23 条中所阐明的，有时 `vector` 在运行时间和空间上都要优于标准关联容器。
几种标准的非 `STL` 容器：数组、`bitset`、`valarray`、`stack`、`queue` 和 `priority_queue`。因为它们不是 `STL` 容器，所以在本书中很少提及，仅在第 16 条中提到了一种数组优于 `STL` 容器的情形，以及在第 18 条中解释为什么 `bitset` 比 `vector<bool>` 要好。值得记住的是，数组也可以被用于 `STL` 算法，因为指针可以被用作数组的迭代器。
### Choose
需要在容器的任意位置插入新元素 ：如果需要，就选择序列容器；关联容器是不行的。
你是否关心容器中的元素是排序的 ：如果不关心，则散列容器是一个可行的选择方案；否则，你要避免散列容器。
你选择的容器必须是标准 `C++` 的一部分吗 ：如果必须是，就排除了散列容器、 `slist` 和 `rope` 。
你需要哪种类型的迭代器 ：
- 随机访问迭代器：`vector`、`deque` 和 `string`，也可以考虑 `rope`（有关 `rope` 见第 50 条）
- 双向迭代器： `list` ，必须避免 `slist` 以及散列容器的一个常见实现（见第 25 条）
当发生元素的插入或删除操作时，避免移动容器中原来的元素是否很重要 ：如果是，就要避免连续内存的容器。
容器中数据的布局是否需要和C兼容 ：如果需要兼容，就只能选择 `vector`（见第 16 条）。
元素的查找速度是否是关键的考虑因素 ：如果是，就要考虑散列容器（见第 25 条）、排序的 `vector` （见第 23 条）和标准关联容器——或许这就是优先顺序。
如果容器内部使用了引用计数技术：如果是，就要避免使用 `string` ，因为许多 `string` 的实现都使用了引用计数。`rope` 也需要避免，因为权威的 `rope` 实现是基于引用计数的（见第 50 条）。需要某种表示字符串的方法，可以考虑 `vector<char>`。
对插入和删除操作，你需要事务语义吗 ：也就是说，在插入和删除操作失败时，需要回滚的能力吗？
- 如果需要，就要使用基于节点的容器。（使用连续内存的容器也可以获得事务语义，但是要付出性能上的代价，而且代码也显得不那么直截了当）
- 如果对多个元素的插入操作（即针对一个区间的形式——见第 5 条）需要事务语义，则你需要选择 `list` ，因为在标准容器中，只有 `list` 对多个元素的插入操作提供了事务语义。
你需要使迭代器、指针和引用变为无效的次数最少吗 ：
- 如果是这样，就要使用基于节点的容器，因为对这类容器的插入和删除操作从来不会使迭代器、指针和引用变为无效（除非它们指向了一个你正在删除的元素）。
- 而针对连续内存容器的插入和删除操作一般会使指向该容器的迭代器、指针和引用变为无效。
如果序列容器的迭代器是随机访问类型，而且只要没有删除操作发生，且插入操作只发生在容器的末尾，则指向数据的指针和引用就不会变为无效，这样的容器是否对你有帮助 ：`deque` 是你所希望的容器，当插入操作仅在容器末尾发生时，`deque` 的迭代器有可能会变为无效。`deque` 是唯一的、迭代器可能会变为无效而指针和引用不会变为无效的 `STL` 标准容。
## 2：不要试图编写独立于容器类型的代码
容器是泛化的，但是不能泛化容器，`STL` 容器是以泛化为基础的，每一个容器都有着对应独特的数据结构与算法，不能尝试泛化容器，创造出一个可以任意使用的容器，那种容器只能使用所有容器的交集部分，使得可提供的操作变得很少。
当改变容器类型时，不仅需要改正编译器诊断出的问题，还要检查使用该容器的所有代码，以便发现按照新类型的性能特点和它使迭代器、指针及引用无效的规则，代码要做出何种改动。
- 如果想从 `vector` 转到其他类型，要确保不再依赖于 `vector` 与 `C` 的布局兼容性，如果是从其他类型转到 `vector` ，要确保没有用它来存储 `bool` 类型的数据，而且为了支持 `vector`，不能使用 `push_front` 和 `pop_front`。
- `deque` 和 `list` 中没有 `reserve` 或 `capacity` 这样的操作（见第14条），`vector` 和 `deque` 没有/禁用 `splice` 和成员函数形式的 `sort`。
- 由于 `list` 的存在，意味着也要放弃 `operator[]`，而且要把操作限制在双向迭代器的能力范围之内。进一步，这意味着要放弃那些要求随机访问迭代器的操作，包括 `sort`、`stable_sort`、 `partial_sort` 和 `nth_element`。
- 当带有一个迭代器参数的 `erase` 作用于序列容器时，会返回一个新的迭代器，但当它作用于关联容器时则没有返回值。
通过对容器类型和其迭代器类型使用类型定义，可以封装容器：
```c++
class Widget{...};
typedef vector <Widget> WidgetContainer; 
typedef WidgetContainer::iterator WClterator; 

WidgetContainer cw;
Widget bestWidget;
WCIterator i = find(cw.begin(), cw.end(), bestWidget); 
```
这样就使得改变容器类型要容易得多，尤其当这种改变仅仅是增加一个自定义的分配器时，就显得更为方便（这一改变不影响使迭代器/指针/引用无效的规则）：
```c++
class Widget{...};
template<typename T> SpecialAllocator{...}; //为什么要声明成模板？见第10条
typedef vector <Widget, SpecialAllocator<Widget>> WidgetContainer;
typedef WidgetContainer::iterator WCIterator; 

WidgetContainer cw; // 仍可工作 
Widget bestWidget;
WCIterator i = find(cw.begin(), cw.end(), bestWidget);  // 仍可工作 
```
## 3：确保容器中的对象副本正确而高效
 `STL` 的工作方式：
- 当向容器中加入或取出对象时，存入容器与从容器中取出的是所指定的对象的副本，进去的是副本，出来的也是副本。
- 一旦一个对象被保存到容器中，它经常会进一步被复制。当对 `vector`、`string` 或 `deque` 进行元素的插入或删除操作、排序、翻转时，现有元素的位置通常会被移动/复制。
在存在继承关系的情况下，复制动作会导致 `slicing`。也就是说，如果创建了一个存放基类对象的容器，却向其中插入派生类的对象，那么在派生类对象通过基类的复制构造函数被复制进容器时，它所特有的部分即派生类中的信息将会丢失：
```c++
vector <Widget>vw; 
class SpecialWidget: puiblic Widget{...};

SpecialWidget sw; // sw作为基类对象被复制进vw中，
vw.push_back(sw); // 它的派生类特有部分在复制时被丢掉了
```
使复制动作高效、正确，并防止剥离问题发生的一个简单办法是使容器包含指针而不是对象。复制指针的速度非常快，并且复制构成指针的每一位，当它被复制时不会有任何剥离现象发生。
不幸的是，指针的容器也有其自身的一些令人头疼的、与 `STL` 相关的问题，可以参考第 7 条和第 33 条。如果想避开这些使人头疼的问题，同时又想避免效率、正确性和剥离这些问题，可以使用智能指针，请参阅第 7 条。
## 4：调用 `empty` 而不是检查 `size` 是否为0
`empty` 对所有的标准容器都是常数时间操作，而对一些 `list` 实现，`size` 耗费线性时间。而 `list` 不提供常数时间的 `size` 是因为 `list` 所独有的 `splice` 操作。考虑如下代码：
```c++
list<int> list1;
list<int> list2; 
// 把list2中从第一个含5的节点到最后一个含10的所有节点移动到list1的末尾。
list1.splice(list1.end(), list2, 
             find(list2.begin(), list2.end(), 5), 
             find(list2.rbegin(), list2.rend(), 10).base()
```
链接后的 `list1` 中的元素个数是它链接前的元素个数加上链接过来的元素个数。被链接过来的元素数量应该与两个 `find` 所定义的区间中的元素个数一样多。如果不遍历该区间来数一数，是没法知道的。问题就在这里。
如果 `size` 是常数时间操作，那么 `list` 的每个成员函数都必须更新它们所操作的链表的大小，当然也包括 `splice`，可是 `splice` 更新它所改变的链表的大小的唯一方式是计算所链接的元素的个数，而这会使 `splice` 不具有常数时间操作性能。
如果不要求 `splice` 更新它所改变的链表的大小，则 `splice` 可以成为常数时间操作，可是这时 `size` 会成为线性时间操作，需要遍历整个数据结构来得到元素个数。因此 `list` 或 `splice`，其中的一个可以成为常数时间操作，但不可能二者都是。
## 5：区间成员函数优先于与之对应的单元素成员函数
### Why
当处理标准序列容器时，为取得同样的结果，使用单元素的成员函数比使用区间成员函数需要更多地调用内存分配器，更频繁地复制对象或做冗余的操作。比如，假定要把一个 `int` 数组复制到一个 `vector` 的前端。使用 `vector` 的区间 `insert` 函数：
```c++
int data[numValues];
vector <int> v;
v.insert(v.begin(), data, data + numValues);
```
如果采用单元素版本的 `insert` 显式循环：
```c++
vector <int>::iterator insertLoc(v.begin()); 
for (int i = 0; i < numValues; ++i) {
    insertLoc = v.insert(insertLoc, data[i]);
    ++insertLoc;
}

// 当copy模板被实例化之后，基于copy的代码和使用显式循环的代码几乎是相同的:
copy(data, data + numValues, inserter(v, v.begin()))
```
如果在每次插入操作后不更新 `insertLoc`，会遇到两个问题。首先，第一次迭代后的所有循环迭代都将导致不可预料的行为，因为每次调用 `insert` 都会使 `insertLoc` 无效。其次，即使 `insertLoc` 仍然有效，插入总是发生在 `vector` 的最前面（即在 `v.begin()` 处），结果这组整数被以相反的顺序复制到 `v` 当中。
使用单元素版本的 `insert` 总共在三个方面影响效率，而如果使用区间版本的 `insert`，则这三种影响都不复存在：
1. 第一种影响是不必要的函数调用。把 `numValues` 个元素逐个插入到 `v` 中导致了对 `insert` 的 `numValues` 次调用。而使用区间形式的 `insert`，则只做了一次函数调用，节省了 `numValues-1` 次。
2. 在例子中，向 `v` 的前端插入 `numValues` 个元素，这意味着 `v` 中插入点之后的每个元素都要向后移动 `numValues` 个位置。如果插入前 `v` 中有 `n` 个元素，就会有 `n*numValues` 次移动（最后一个元素调用拷贝构造，其余调用拷贝赋值）。因此在通常情况下，把 `numValues` 个元素逐个插入到含有 `n` 个元素的 `vector<Widget>` 的前端将会有 `n*numValues` 次函数调用的代价：`(n－1)*numValues` 次调用 `Widget` 的赋值操作符和 `numValues` 次调用 `Widget` 的复制构造函数。与之对应，使用区间插入的方法，会把现有容器中的元素直接移动到它们最终的位置上，即只需付出每个元素移动一次的代价。总的代价包括 `n` 次移动、`numValues` 次调用该容器中元素类型的复制构造函数，以及调用该类型的赋值操作符。但当传入区间形式 `insert` 的是输入迭代器时，必须把元素一步步移动到其最终位置上，因而它的优势就丧失了。对于输出迭代器不会产生这个问题，因为输出迭代器不能用来标明一个区间。
3. 如果试图把一个元素插入到 `vector` 中，而它的内存已满，那么 `vector` 将分配具有更大容量的新内存，把它的元素从旧内存复制到新内存中，销毁旧内存中的元素，并释放旧内存。然后它把要插入的元素加入进来。与之对应，使用区间插入的方法，在开始插入前可以知道自己需要多少新内存（假定是前向迭代器），所以不必多次重新分配 `vector` 的内存。
刚才所做的分析是针对 `vector` 的，但该论证过程对 `string` 同样有效。对于 `deque` ，论证过程与之类似，但 `deque` 管理内存的方式与 `vector` 和 `string` 都不同，所以关于重复分配内存的论断不再适用。
在标准的序列容器中，`list` 使用区间形式而不是单元素形式的 `insert` 也有其效率上的优势。关于重复函数调用的论断当然继续生效，可是，由于链表工作的方式，复制和内存分配问题不再出现。取而代之的是新问题：对 `list` 中某些节点的 `next` 和 `prev` 指针的重复的、多余的赋值操作。
每当有元素加入到链表中时，含有这一元素的节点必须设定它的 `next` 和 `prev` 指针，新节点前面的节点必须设定自己的 `next` 指针，而新节点后面的节点则必须设定自己的 `prev` 指针：
![image-20230207185209197](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230207185209197.png)
每次有新节点在 `A` 前面插入时，`A` 会把其 `prev` 指针指向新指针。如果 `A` 前面插入 `numValues` 个指针，那么对所插入的节点的 `next` 指针会有 `numValues-1` 次多余的赋值，对 `A` 的 `prev` 指针也会有 `numValues-1` 次多余的赋值，总共就会有 `2*(numValues-1)` 次不必要的指针赋值。避免这一代价的答案是使用区间形式的 `insert`，因为这一函数知道最终将插入多少节点，可以避免不必要的指针赋值，只使用一次赋值将每个指针设为插入后的值。
### Function
在下面的函数原型中，参数类型 `iterator` 按其字面意义理解为容器的迭代器类型，即`container::iterator`，参数类型 `InputIterator` 表示任何类型的输入迭代器都是可接受的。
**区间创建** ：所有的标准容器都提供了如下形式的构造函数：
```c++
container::container(Inputlterator begin, Inputlterator end);
```
**区间插入** ：所有的标准序列容器都提供了如下形式的 `insert`：
```c++
void container::insert(iterator position, Inputlterator begin, Inputlterator end);
```
关联容器利用比较函数来决定元素该插入何处，它们提供一个省去 `position` 参数的函数原型：
```c++
void container::insert(Inputlterator begin, Inputlterator end);
```
尽管 push_fron`t` 和 `push_back` 不叫 `insert`，但当使用 `push_front` 或 `push_back` 的循环调用，或者 `front_inserter` 或 `back_inserter` 被作为参数传递给 `copy` 函数时，`insert` 是更好的选择，例如给定 `v1` 和 `v2` 两个矢量，使 `v1` 的内容和 `v2` 的后半部分相同：
```c++
v1.assign(v2.begin() + v2.size() / 2, v2.end());
```
区间成员函数是指使用两个迭代器参数来确定操作所执行区间:
```c++
vector<Widget> v1, v2;
v1.clear();
for(vector<Widget>::conset_iterator ci = v2.begin() + v2.size() / 2; 
    ci != v2.end(); ++ci) 
        v1.push_back(*ci); 

// 避免循环的一种方法是遵从第 43 条的建议，使用一个算法：
v1.clear();
copy(v2.begin() + v2.size() / 2, v2.end(), back_inserter(v1)); 

// 利用插入迭代器的方式来限定目标区间的 copy 调用，几乎都应该被替换为对区间成员函数的调用
v1.insert(v1.end(), v2.begin() + v2.size() / 2, v2.end())
```
**区间删除** ：所有的标准容器都提供了区间形式的删除操作，但对于序列和关联容器，其返回值有所不同。
序列容器提供了这样的形式：
```c++
iterator container::erase(iterator begin, iterator end);
```
而关联容器则提供了如下形式：
```c++
void container::erase(iterator begin, iterator end); 
```
关于 `insert` 的效率分析对 `erase` 也类似。对 `vector` 和 `string` 的论断中，有一条对 erase 不适用，那就是内存的反复分配。这是因为 `vector` 和 `string` 的内存会自动增长以容纳新元素，但当元素数目减少时内存却不会自动减少。第 17 条将指出怎样减少 `vector` 或 `string` 所占用的多余内存。
**区间赋值** ：所有的标准容器都提供了区间形式的 `assign`：
```c++
void container::assign(Inputlterator begin, Inputlterator end); 
```
## 6：C++ 编译器最烦人的分析机制
```c++
int g(double (*pf)());

// 围绕参数名的括号会被忽略，而独立的括号则表明参数列表的存在，说明存在一个函数指针参数
int g(double pf()); // pf 为隐式指针
int g(double ());   // 省参数名
```
对于默认构造函数的分析机制，使用花括号即可解决，但对于下述如下声明，会被视为函数，而不是`list<int>` 对象的初始化：
```c++
// 返回值是 list<int>
// 第一个参数 dataFile，类型为 istream_iterator<int>，两边括号会被忽略
// 第二个参数指向不带参数的函数的指针，该函数返回一个 istream_iterator<int>。
list<int> data(istream_iterator<int>(dataFile), istream_iterator<int>());
```
因此需要增加一对括号，强迫编译器：
```c++
list<int> data((istream_iterator<int>(dataFile)), istream_iterator<int>()); // 围绕参数名的括号被忽略
```
更好的方式是在对 `data` 的声明中避免使用匿名的 `istream_iterator` 对象（尽管使用匿名对象是一种趋势），而是给这些迭代器一个名称。下面的代码应该总是可以工作：
```c++
ifstream dataFile("ints.dat");
istream_iterator<int> dataBegin(dataFile); 
istream_iterator<int> dataEnd;
list<int> data(dataBegin, dataEnd); 
```
## 7：如果容器中包含通过 new 创建的指针，切记在容器对象析构前将指针 delete 掉
指针容器在自己被析构时会析构所包含的每个元素，但指针的析构函数不做任何事情！它当然也不会调用 `delete`。结果，下面的代码直接导致资源泄漏：
```c++
void doSomething() {
    vector <Widget*> vwp;
	for (int i = 0; i < SOME_MAGIC_NUMBER; ++i) vwp.push_back(new Widget);
}  
```
当 `vwp` 的作用域结束时，它的元素全部被析构，但这并没有改变通过 `new` 创建的对象没有被删除这一事实。通常，希望它们会被删除。如果是这样，做法非常简单：
```c++
void doSomething() {
    vector <Widget*> vwp;
	for (int i = 0; i < SOME_MAGIC_NUMBER; ++i) vwp.push_back(new Widget);
	... // 可能抛出异常
    for (vector<Widget*>::iterator i = vwp.begin(); i!= vwp.end(); ++i) delete *i; 
}  
```
一个问题是，新的 `for` 循环做的事情和 `for_each` 相同，但不如使用 `for_each` 看起来那么清楚。另一个问题是，这段代码不是异常安全的。如果在向 `vwp` 中填充指针和从中删除指针的两个过程中间有异常抛出的话，同样会有资源泄漏。
为了使用 `for_each`，需要把 `delete` 变成一个函数对象：
```c++
template<typename T> // 第40条解释为什么有这个继承
struct DeleteObject: public unary_function<const T*, void> { 
    void operator()(const T* ptr) const { delete ptr; }
}

for_each(vwp.begin(), vwp.end(), DeleteObject<Widget>()); // 显式指明 widget
```
但此处要显式地指明 `DeleteObject` 要删除的对象类型 `Widget`。`vwp` 是 `vector <Widget>`，`DeleteObject` 当然是要删除 `Widget` 类型的指针。这种多余不仅仅是烦人，它还可能导致很难追踪的错误。例如，假设有人很不明智地决定从 `string` 继承，而 `string` 没有虚析构函数：
```c++
void doSomething() {
    deque<Specialstring*> dssp;
    // 不确定的行为！通过基类的指针删除派生类对象，而基类又没有虚析构函数
    for_each(dssp.begin(), dssp.end(), DeleteObject<string>()); 
}
```
通过让编译器推断出传给 `DeleteObject::operator()` 的指针的类型，可以消除这个错误。所要做的只是把模板化从 `DeleteObject` 移到它的 `operator()` 中：
```c++
struct DeleteObject { 
    template<typename T>
    void operator()(const T* ptr) const { delete ptr; }
}
```
编译器通过模板型别推导推导出传给 `DeleteObject::operator()` 的指针类型，这种类型推断的缺点是舍弃使 `DeleteObject` 可配接的能力（见第 40 条）。
```c++
void doSomething() {
    deque<Specialstring*> dssp;
    ...
    for_each(dssp.begin(), dssp.end(), DeleteObject()); //确定的行为！推导为 widget
}```
但它仍然不是异常安全的。如果在 `Specialstring` 已经被创建而对 `for_each` 的调用还没有开始时有异常被抛出，则会有资源泄漏发生。使用 `shared_ptr`，本条款最初的例子可改写为：
```c++
void doSomething() {
    typedef shared_ptr<Widget> SPW;
    vector <SPW> vwp;
    for (int i = 0; i < SOME_MAGIC_NUMBER; ++i) vwp.push_back(SPW(new Widget));
	... // 使用vwp
}
```
## 9：慎重选择删除元素的方法
### Remove
假定有一个标准的 `STL` 容器，想删除其中所有值为 1963 的元素：
```cpp
Container<int> c;
```
完成这一任务的方式随容器类型而异；没有对所有容器类型都适用的方式。
如果有一个连续内存的容器 `vector`、`deque` 或 `string`，那么最好的办法是使用 `erase-remove` 惯用法（见第 32 条）：
```c++
// 当 c 是 vector、string 或 deque 时，erase-remove习惯用法是删特定值的元素的最好办法
c.erase(remove(c.begin(), c.end(), 1963), c.end()); 
```
对 `list`，这一办法同样适用。但正如第 44 条所指出的，`list` 的成员函数 `remove` 更加有效：
```c++
c.remove(1963); // 当 c 是 list 时，remove 成员函数是删除特定值的元素的最好办法
```
当 `c` 是标准关联容器 `set`、`multiset`、`map` 或 `multimap` 时，使用任何名为 `remove` 的操作都是完全错误的，这样的容器没有名为 `remove` 的成员函数，使用 `remove` 算法可能会覆盖容器的值（见第 32 条），同时可能会破坏容器。对于关联容器，解决问题的正确方法是调用 `erase`：
```c++
c.erase(1963); // 当 c 是标准关联容器时，erase 成员函数是删除特定值元素的最好办法
```
这样做不仅是正确的，而且是高效的，只需要对数时间开销。而且，关联容器的 `erase` 成员函数还有另外一个优点，即它是基于等价而不是相等的，这一区别的重要性将在第 19 条中解释。
###Remove_if
现在不再从 `c` 中删除所有等于特定值的元素，而是删除使下面的判别式（见第 39 条）返回 `true` 的每一个对象：
```c++
bool badValue(int x);
```
对于序列容器 `vector` 、 `string` 、 `deque` 和 `list` 换成调用 `remove_if` 就可以了：
```c++
// 当 c 是vector、string 或 deque
c.erase(remove_if(c.begin(), c.end(), badValue()), c.end());  
c.remove_if(badValue); // 当 c 是 list
```
对于标准关联容器，则没有这么直截了当。解决这一问题有两种办法，一种易于编码，另一种则效率更高。简单但效率稍低的办法是，利用 `remove_copy_if` 把需要的值复制到一个新容器中，然后把原来容器的内容和新容器的内容相互交换：
```c++
AssocContainer<int> c; // c 现在是一个标准关联容器
AssocContainer<int> goodValues; // 保存不被删除的值的临时容器
// 把不被删除的值从c复制到goodValues中
remove_copy_if(c.begin(), c.end(), inserter(goodValues, goodValues.end()), badValue); 
c.swap(goodValues); // 交换 c 和 goodValues 的内容 
```
也可以直接从原始的容器中删除元素，从而降低代价。但是，因为关联容器没有提供类似 `remove_if` 的成员函数，所以必须写一个循环来遍历 `c` 中的元素，并在遍历过程中删除元素：
```c++
AssocContainer<int> c;
for (AssocContainer<int>::iterator i = c.begin(); i !=c.end(); ++i) {
    if (badValue(*i)) c.erase(i);
}
```
可惜这会导致不确定的行为。当容器中的一个元素被删除时，指向该元素的所有迭代器都将变得无效。一旦 `c.erase(i)` 返回，`i` 就成为无效值，而在 `erase` 返回后，`i` 还要通过 `for` 循环部分被递增。为避免这个问题，要确保在调用 `erase` 之前，有一个迭代器指向 `c` 中的下一个元素。这样做的最简单的办法是，当调用时对 `i` 使用后缀递增：
```c++
AssocContainer<int> c;
for (AssocContainer<int>::iterator i = c.begin(); i !=c.end();) {
    if (badValue(*i)) c.erase(i++); // 旧 i 传给 erase，在 erase 执行前也递增了 i
    else ++i;
}
```
### Log
现在不仅要删除使 `badValue` 返回 `true` 的元素，还想在每次元素被删除时，都向一个日志文件中写一条信息。对于关联容器，这非常简单，因为它仅需要对刚才的循环做简单的修改：
```c++
ofstream logFile;
AssocContainer<int> c;
for (AssocContainer<int>::iterator i = c.begin(); i !=c.end();) {
    if (badValue(*i)) {
        logFile << "Erasing" << *i << "\n";
        c.erase(i++);
    }
    else ++i;
}
```
现在给带来麻烦的是 `vector` 、 `string` 和 `deque` 。不能再使用 `erase-remove` 习惯用法，因为没办法使 `erase` 或 `remove` 向日志文件中写信息。而且不能使用刚才为关联容器设计的循环，因为对 `vector` 、 `string` 和 `deque`，它会导致不确定的行为！
对这类容器，**调用 `erase` 不仅会使指向被删除元素的迭代器无效，也会使被删除元素之后的所有迭代器都无效**。在例子中，这包括 `i` 之后的所有迭代器，因此就算后缀递增，递增后的迭代器也是无效的。
对 `vector` 、 `string` 和 `deque` 要利用 `erase` 的返回值，一旦 `erase` 完成，它是指向紧随被删除元素的下一个元素的有效迭代器：
```c++
for (SeqContainer<int>::iterator i = c.begin(); i!=c.end();) {
    if (badValue(*i) {
        logFile << "Erasing" << *i << "\n";
        i = c.erase(i); // 把erase的返回值赋给i，使i的值保持有效
    }
    else++i;
}
```
这工作得很好，但仅对标准序列容器才如此。因为对于标准关联容器，`erase` 的返回类型是 `void`。对于这类容器，得使用将传给 `erase` 的迭代器进行后缀递增的技术。
### Conclusion
就遍历和删除来说，可以把 `list` 当作  `vector`、`string`、`deque` 来对待，也可以把它当作关联容器来对待。两种方式对 `list` 都适用，一般的惯例是对 `list` 采取和 `vector` 、 `string` 和 `deque`相同的方式。
要删除容器中有特定值的所有对象：
- 如果容器是 `vector` 、 `string` 或 `deque` ，则使用 `erase-remove` 惯用法。
- 如果容器是 `list` ，则使用 `list::remove`。
- 如果容器是一个标准关联容器，则使用它的 `erase` 成员函数。
要删除容器中满足特定判别式的所有对象：
- 如果容器是 `vector` 、 `string` 或 `deque` ，则使用 `erase-remove_if` 惯用法。
- 如果容器是 `list` ，则使用 `list::remove_if`。
- 如果容器是一个标准关联容器，则使用 `remove_copy_if` 和 `swap`，或者写一个循环来遍历容器中的元素，记住当把迭代器传给 `erase` 时，要对它进行后缀递增。
要在循环内部做某些除删除对象之外的操作：
- 如果容器是一个标准序列容器，则写一个循环来遍历容器中的元素，记住每次调用 `erase` 时，要用它的返回值更新迭代器。
- 如果容器是一个标准关联容器，则写一个循环来遍历容器中的元素，记住当把迭代器传给 `erase` 时，要对迭代器做后缀递增。
## 10：了解 allocator 的约定和限制
### Equivalence
分配器最初是作为内存模型的抽象而产生的，自然要为它所定义的内存模型中的指针和引用提供类型定义。在 `C++` 标准中，一个类型为 `T` 的对象，它的默认分配器 `allocator<T>` 提供了两个类型定义，分别为 `allocator<T>::pointer` 和 `allocator<T>::reference`，用户定义的分配器也应该提供这些类型定义。
`C++` 标准很明确地指出，允许库实现者假定每个分配器的指针类型等同于 `T*`，而分配器的引用类型就是 `T&`。因此库实现者可以忽略类型定义，而直接使用指针和引用！
分配器是对象，这意味着它可以有成员函数、嵌套类型和类型定义，但 `C++` 标准规定 `STL` 的实现可以假定所有属于同一种类型的分配器对象都是等价的，并且相互比较的结果总是相等的。看下面的代码：
```c++
template<typename T>
class SpecialAllocator{...}; // 用户定义的分配器模板
typedef SpecialAllocator<Widget> SAW;

list<Widget, SAW> L1;
list<Widget, SAW> L2; 

L1.splice(L1.begin(), L2); // 把L2的节点移动到L1前面
```
当 `list` 的元素从一个 `list` 链接到另一个时，并没复制任何东西。只有一些指针被调整，链接前在 `L2` 中的节点在链接后到了 `L1` 中。当 `L1` 被析构时，它必须析构自己的所有节点并释放它们的内存。因为它现在包含了最初由 `L2` 分配的节点，所以，`L1` 的分配器必须释放最初由 `L2` 的分配器分配的节点。
这就是 `C++` 标准允许 `STL` 的实现可以假定同一类型的分配器等价的原因。这样，一个分配器对象分配的内存就可以由另一个分配器对象安全地删除。如果没有这个假设，那么链接操作实现起来就要困难得多。毫无疑问，它们不会像现在这样高效。
`STL` 实现可以假定同一类型的分配器是等价的，这其实是一个非常苛刻的限制。这意味着可移植的分配器对象——即在不同的 `STL` 实现下都能正确工作的分配器不可以有状态。这意味着可移植的分配器不可以有任何非静态的数据成员，至少不能有会影响其行为的数据成员。例如，这意味着，不能让一个 `SpecialAllocator<int>` 从某一个堆分配，而另一个不同的 `SpecialAllocator<int>` 从另一个不同的堆分配。这样的两个分配器是不等价的，因而在有的 `STL` 实现中，同时使用这两个分配器会导致在运行时破坏数据结构。
### Operator new
分配器在分配原始内存这一点上就像 `new` 操作符，但它们的接口是不同的：
```c++
void* operator new(size_t bytes);
pointer allocator<T>::allocate(size_type numObjects); // pointer是个类型定义，它实际上总是T*
```
二者都带参数指明要分配多少内存。但是对于 `operator new`，该参数指明的是一定数量的字节，而对于 `allocator<T>::allocate`，它指明的则是内存中要容纳多少个 T 对象。比如，在一个 `sizeof(int)=4` 的平台上，如果要申请可容纳一个 `int` 的内存，那么传给 operator new 的值应该为 4，而传给 `allocator<T>::allocate` 的值在应是 1。
该参数的类型，对于 `operator new` 是 `size_t`，而对于 `allocate` 则是 `allocator<T>::size_type`。在这两种情况下，它都是一个无符号整数值，而在通常情况下，`allocator<T>:size_type` 是 `size_t` 的一个类型定义。
`operator new` 和 `allocator<T>::allocate` 的返回值也不同：
- `operator new` 返回`void*`，即指向未初始化内存。
- `allocator<T>::allocate` 则返回 `T*`，即 `pointer` 类型定义。
`STL` 中隐含着这样的期望：`allocator<T>::allocate` 的调用者最终会在返回的内存中构造一个或多个 T 对象，但是在 `vector::reserve`或 `string::reserve` 的情况下，这种构造可能根本就没有发生过（见第 14 条）。因此从 `allocator<T>::allocate` 返回的指针可能并没有指向 `T` 对象，因为 `T` 尚未被构造！
由于 `operator new` 和 `allocator<T>::allocate` 的不同约定，而且 `operator new` 和`allocator<T>::allocate` 返回值的区别反映关于未初始化内存的概念模型的一个转变，使得把编写自定义版本的 `operator new` 的经验应用到编写自定义的分配器上时，事情变得复杂了。
### Rebind
奇怪的是大多数标准容器从来没有单独调用过对应的分配器，即它们自己被实例化的分配器：
```c++
list<int> L;        // 从未要求 allocator<int> 分配内存！ 
set<Widget, SAW> s; // 并没有通过 SAW 分配内存！
```
这一奇怪的现象对于 `list` 和所有的标准关联容器都存在。这是因为，它们是基于节点的容器，即每当新的值被存入到容器中时，新的节点中的数据结构是被动态分配的。对于 `list` 的情形，容器节点是 `list` 节点。对于标准关联容器的情形，容器节点通常是树节点，因为标准关联容器通常被实现为平衡二叉搜索树。
考虑一下 `list<T>` 的一个可能实现：
```c++
template<typename T, typename Allocator = allocator<T>>
class list  {
private:	
    Allocator alloc;
    struct ListNode{
        T data;
        ListNode *prev;
        ListNode *next; 
    }; 
};
```
当新的节点加入到 `list` 中时，需要通过分配器获得内存，但并不是需要 `T` 的内存，需要的是包含 T 的 `ListNode` 的内存。这使得 `Allocator` 对象变得毫无用处，因为它不能为 `ListNode` 分配内存。现在可以理解为什么 `list` 从未要它的 `Allocator` 做任何内存分配，该分配器不能提供 `list` 所需要的内存分配功能。 `list` 所需要的是这样一种方式，即如何从它已有的分配器类型到达与 `ListNode` 相适应的分配器：
```c++
template <typename T>
class allocator {
public:
    template<typename U> 
    struct rebind{
        typedef allocator<U> other; 
    };
};
```
在实现 `list<T>` 的代码中，需要决定与 `T` 的分配器相对应的 `ListNode` 的分配器的类型。`T` 的分配器的类型是模板参数 `Allocator`。考虑到这些，相应的 `ListNode` 的分配器的类型是：
```c++
Allocator::rebind<ListNode>::other 
```
每个分配器模板 `A` 都要有一个被称为 `rebind` 的嵌套结构模板，`rebind` 带有唯一的类型参数 `U`，并且只定义了一个类型定义 `other`。`other` 仅仅是 `A<U>` 的名字，通过引用 `Allocator::rebind<ListNode>::other`, `list<T>` 就能从 `T` 对象的分配器 `Allocator` 得到相应的 `ListNode` 对象的分配器。
因此如果选择要编写分配器并且将它们同标准容器一起使用，那么，分配器必须提供 `rebind` 模板，因为标准容器假定它是存在的。
### Conclusion
- 提供类型定义 `pointer` 和 `reference`，始终让 `pointer` 为 `T*`，`reference` 为 `T&`。
- 不要让分配器拥有随对象而不同的状态，通常，分配器不应该有非静态的数据成员。
- 分配器的 allocate 成员函数的实参是要求内存的对象的个数，而不是所需的字节数，而且这些函数返回 `T*` 指针，即使尚未有 T 对象被构造出来。
- 一定要提供嵌套的 `rebind` 模板，因为标准容器依赖该模板。
## 11：理解自定义分配器的合理用法
假定有一些特殊过程，它们采用 `malloc` 和 `free` 内存模型来管理一个位于共享内存的堆：
```c++
void* mallocShared(size_t bytesNeeded); 
void* freeShared(void* ptr);
```
如果想把 `STL` 容器的内容放到这块共享内存中去，并进行使用：
```c++
template<typename T>
class SharedMemoryAllocator { 
public:
    pointer allocate(size_type numObjects, const void *localityHint = 0) {
        return static_cast<pointer>(mallocShared(numObjects * sizeof(T))); 
    }
    void deallocate(pointer ptrToMemory, size_type numObjects) {
        freeShared(ptrToMemory); 
    }
};

typedef vector<double, SharedMemoryAllocator<double>> SharedDoubleVec;

{ // 开始某个代码块
    SharedDoubleVec v; // 创建一个 vector，其元素位于共享内存中
}
```
`v` 在使用 `SharedMemoryAllocator`，所以 `v` 所分配的用来容纳其元素的内存将来自共享内存。而 `v` 自己只是普通的基于栈的对象，所以，像所有基于栈的对象一样，它将会被运行时系统放在任意可能的位置上，这个位置几乎不可能是共享内存。为了把 `v` 的内容和 `v` 自身都放到共享内存中：
```c++
// 因为 mallocShared 管理共享内存，因此从中分配出的内存均是共享内存
// 所以为了让 v 自身也在共享内存中，只需要使用 mallocShared 为 v 分配内存
// 不能使用 new 动态分配，因为标准的 malloc 分配的不是这片共享内存，因此需要使用 placement new
void *p = mallocShared(sizeof(SharedDoubleVec));
SharedDoubleVec *pv = new(p) SharedDoubleVec;
... // 通过 pv 使用对象
pv->~SharedDoubleVec(); // 析构共享内存中的对象
freeShared(p); // 释放最初分配的那一块共享内存
```
先获取一块共享内存，然后在其中构造一个 `vector`。当用完该 `vector` 之后，调用它的析构函数，然后释放它所占用的内存。除非确实需要一个位于共享内存中的容器，而不是仅把它的元素放到共享内存中，否则建议避免这种手工的分配/构造/析构/释放四步曲。
作为分配器用法的第二个例子，假设有两个堆类 `Heap1` 和 `Heap2`，每个类都有相应的静态成员函数来执行内存分配和释放操作：
```c++
class Heap1{
public:
    static void *alloc(size_t numBytes, const void *memoryBlockToBeNear); 
    static void dealloc(void *ptr);
};
class Heap2{...};
```
再假设想把一些 `STL` 容器的内容放在不同的堆中。首先编写一个分配器，它可以使用像 `Heap1` 和 `Heap2` 这样的类来完成实际的内存管理：
```c++
template<typename T, typename Heap>
class SpecificHeapAllocator{ 
public:
    pointer allocate(size_type numObjects, const void *localityHint=0) {
        return static_cast<pointer>(Heap::alloc(numObjects* sizeof(T), localityHint));
    }
    void deallocate(pointer ptrToMemory, size_type numObjects) {
        Heap::dealloc(ptrToMemory); 
    }
}; 
```
然后使用 `SpecificHeapAllocator` 把容器的元素聚集到一起：
```c++
vector<int, SpecificHeapAllocator<int, Heap1>> v; // v和s的元素都放在Heap1中
set<int, SpecificHeapAllocator<int, Heap1>> s;

list<Widget, SpecificHeapAllocator<Widget, Heap2>> L; // L和m的元素都放在Heap2中
map<int, string, less<int>, SpecificHeapAllocator<pair<const int, string>, Heap2>> m; 
```
因此，分配器在许多场合下都非常有用。只要遵守了同一类型的分配器必须是等价的这一限制要求，那么，当使用自定义的分配器来控制通用的内存管理策略的时候，或者在聚集成员关系的时候，或者在使用共享内存和其他特殊堆的时候，就不会陷入麻烦。
## 12：切勿对 `STL` 容器的线程安全性有不切实际的依赖
概括来说，对一个 `STL` 实现最多只能期望而不是所能依赖：
- 多个线程读是安全的。多个线程可以同时读同一个容器的内容，并且保证是正确的，在读的过程中，不能对容器有任何写入操作。
- 多个线程对不同的容器做写入操作是安全的，多个线程可以同时对不同的容器做写入操作。
考虑当一个库试图实现完全的容器线程安全性时可能采取的方式：
- 对容器成员函数的每次调用，都锁住容器直到调用结束。
- 在容器所返回的每个迭代器的生存期结束前，都锁住容器。
- 对于作用于容器的每个算法，都锁住该容器，直到算法结束。实际上这样做没有意义。因为，如同在第 32 条中解释的，算法无法知道它们所操作的容器。
现在考虑下面的代码。它在一个 `vector<int>` 中查找值为 5 的第一个元素，如果找到了，就把该元素置为 0。
```c++
vector <int> v;
vector <int>::iterator first5(find(v.begin(), v.end(), 5)); // 第1行 
if (first5 != v.end()) // 第2行
	*first5 = 0; // 第3行 
```
在一个多线程环境中，可能在第 1 行刚刚完成后，另一个不同的线程会更改 `v` 中的数据。如果这种更改真的发生了，那么第 2 行是否相等的检查将会变得没有意义，因为 `v` 的值将会与在第 1 行结束时不同。
事实上，这一检查会产生不确定的行为，因为另外一个线程可能会夹在第1行和第2行中间，使 `first5` 变得无效，这第二个线程或许会执行一个插入操作使得 `vector` 重新分配它的内存。这将会使 `vector` 所有的迭代器变得无效。关于重新分配的细节，请参见第 14 条。
类似地，第 3 行对 `*first5` 的赋值也是不安全的，因为另一个线程可能在第 2 行和第 3 行之间执行，该线程可能会使 `first5` 无效，例如可能会删除它所指向的元素。
上面所列出的加锁方式都不能防止这类问题的发生。第 1 行中对 `begin` 和 `end` 的调用都返回得太快了，所以不会有任何帮助，它们生成的迭代器的生存期直到该行结束，`find` 也在该行结束时返回。
上面的代码要做到线程安全，v 必须从第 1 行到第 3 行始终保持在锁住状态，很难想象一个 `STL` 实现能自动推断出这一点。考虑到同步原语通常会有较高的开销，这就更难想象了，一个 `STL` 实现如何既能够做到这一点，同时又不会对那些在第 1 行和第 3 行之间本来就不会有另外线程来访问 `v` 的程序造成显著的效率影响。
这样的考虑说明为什么不能指望任何 `STL` 实现来解决线程难题。相反，在这种情况下，必须手工做同步控制。面向对象的方案使用 `RAII` 是创建一个 `Lock` 类，在构造函数中获得一个互斥体，在析构函数中释放它，从而尽可能地减少 `getMutexFor` 调用没有相对应的 `releaseMutexFor` 调用的可能性：
```c++
template<typename Container>
class Lock{
public:
    Lock(const Container& container) :c(container) {
        getMutexFor(c);
    }
    ~Lock() {
        releaseMutexFor(c);
    }
private:
    const Container& C; 
};

vector <int> v;
{ // 创建新的代码块 
	Lock<vector<int>> lock(v);
    vector <int>::iterator first5(find(v.begin(), v.end(), 5));
    if (first5 !=v.end()){
		*first5 = 0; 
	}
} // 代码块结束，自动释放互斥体
```
因为 `Lock` 对象在其析构函数中释放容器的互斥体，所以当互斥体应该被释放时 `Lock` 就要被析构。为了做到这一点，创建一个新的代码块，在其中定义 `Lock`，当不再需要互斥体时就结束该代码块。。
而且 `C++ `保证，如果有异常被抛出，局部对象会被析构，所以，即便在使用 `Lock` 对象的过程中有异常抛出，`Lock` 仍会释放它所拥有的互斥体。如果依赖于手工调用 `getMutexFor` 和 `releaseMutexFor`，那么，当在调用 `getMutexFor` 之后而在调用 `releaseMutexFor` 之前有异常被抛出时，将永远也无法释放互斥体。
#  `Vector` And `String` 
## 13：`vector` 和 `string` 优先于动态分配的数组
当每次动态地分配一个数组时，都应该考虑用 `vector` 和 `string` 来代替。一般情况下，当 `T` 是字符类型时用 `string`，否则用 `vector` 。不过在一种特殊的情形下，`vector<char>` 可能是一种更为合理的选择。
如果还得继续支持旧的代码，而它们是基于数组的，使用 `vector` 和 `string` 仍然没有问题。第 16 条展示了把 `vector` 和 `string` 中的数据传递给期望接受数组的 `API` 是多么容易，所以，和旧代码的集成通常不是一个问题。
许多 `string` 实现在背后使用了引用计数技术（见第 15 条），这种策略可以消除不必要的内存分配和不必要的字符复制，从而可以提高很多应用程序的效率。事实上，通过引用计数来优化 `string` 是如此重要，所以，`C++` 标准委员会采取特殊的步骤以确保它是一个合法的实现。可惜，对于一个程序员来说是优化的东西，对另一个程序员则未必。如果在多线程环境中使用引用计数的 `string` ，由避免内存分配和字符复制所节省下来的时间还比不上花在背后同步控制上的时间。
为了确定是否在使用以引用计数方式实现的 `string` ，最简单的办法是查阅库文档。`string` 是`basic_string<char>`的类型定义，所以实际要检查的是 `basic_string` 模板，查看复制构造函数是否在某处增加了引用计数。
如果所使用的 `string` 是以引用计数方式来实现的，而又运行在多线程环境中，并认为 `string` 的引用计数实现会影响效率，那么，至少有三种可行的选择：
- 首先，检查库实现，看看是否有可能禁止引用计数，通常是通过改变某个预处理变量的值。这不会是可移植的做法，但考虑到所需做的工作并不多，因此这还是值得一试的。
- 其次，寻找或开发另一个不使用引用计数的 `string` 实现。
- 最后，考虑使用 `vector<char>` 而不是 `string`。`vector` 的实现不允许使用引用计数，所以不会发生隐藏的多线程性能问题。但如果你使用 `vector <char>`，那么就舍弃使用 `string` 的成员函数的机会，但大多数成员函数的功能可以通过 `STL` 算法来实现，所以当使用一种语法形式而不是另一种时，不会因此而被迫舍弃功能。
## 14：使用 reserve 来避免不必要的重新分配
对于 `vector` 和 `string`，增长过程是这样来实现的：每当需要更多空间时，就调用与 `realloc` 类似的操作。考虑到分配、释放、复制和析构步骤，这个过程会非常耗时。此外，每当这些步骤发生时， `vector` 或 `string` 中所有的指针、迭代器和引用都将变得无效。
`reserve` 成员函数能把重新分配的次数减少到最低限度，从而避免重新分配和指针/迭代器/引用失效带来的开销。在标准容器中，只有 `vector` 和 `string` 提供了所有这 4 个函数：
- `size()`：容器中有多少个元素。
- `capacity()`：容器利用已经分配的内存可以容纳多少个元素。这是容器所能容纳的元素总数，而不是它还能容纳多少个元素。如果想知道一个 `vector` 有多少未被使用的内存，就得从 `capacity()` 中减去 `size()`。如果 `size` 和 `capacity` 返回同样的值，就说明容器中不再有剩余空间了，因此下一个插入操作将导致重新分配过程。
- `resize(Container::size_type n)`：强迫容器改变到包含 `n` 个元素的状态。如果 `n` 比当前的 `size` 要小，则容器尾部的元素将会被析构。如果 `n` 比当前的 `size` 要大，则通过默认构造函数创建的新元素将被添加到容器的末尾。如果 `n` 比当前的容量要大，那么在添加元素之前，将先重新分配内存。
- `reserve(Container::size_type n)`：强迫容器把它的容量变为至少是 `n`，前提是 `n` 不小于当前的大小，这通常会导致重新分配，因为容量需要增加。如果 `n` 比当前的容量小，则 `vector` 忽略该调用，什么也不做，而 `string` 则可能把自己的容量减为 `size` 和 `n` 中的最大值，但是 `string` 的大小肯定保持不变。使用 `reserve` 从 `string` 中除去多余的容量通常不如使用 `swap` 技巧。`swap` 技巧是第 17 条的主题。
当一个元素需要被插入而容器的容量不够时，就会发生重新分配过程，包括原始内存的分配和释放，对象的复制和析构，迭代器、指针和引用的失效。因此，避免重新分配的关键在于，尽早地使用 `reserve`，把容器的容量设为足够大的值，最好是在容器刚被构造出来之后就使用 `reserve`。
size 和 capacity 之间的关系能够预知什么时候插入操作会导致 `vector` 或 `string` 执行重新分配的动作，进而又有可能预知什么时候一个插入操作会使容器中的迭代器、指针和引用失效。例如，考虑下面的代码：
```c++
string s;
if (s.size() < s.capacity()) s.push_back('x');
```
对 `push_back` 的调用不会使 `string` 中的迭代器、指针和引用无效，因为 `string` 的容量肯定大于它的大小。如果这里的操作不是 `push_back`，而是在 `string` 的任意位置上做一个 insert 操作，那么仍能保证在插入过程中不会发生重新分配，但是按照一般性的规则 `string` 的插入操作总是伴随着迭代器失效，则从插入点到 `string` 末尾的所有迭代器/指针/引用都将失效。
通常有两种方式来使用 `reserve` 以避免不必要的重新分配。第一种方式是，若能确切知道或大致预计容器中最终会有多少元素，则此时可使用 `reserve` 简单地预留适当大小的空间。第二种方式是，先预留足够大的空间，然后当把所有数据都加入以后，再去除多余的容量（具体参阅第 17 条）。
## 15：注意 `string` 实现的多样性
在有些 `string` 实现中， `string` 和 `char*` 指针的大小相同，尽管这样的 `string` 实现并不少见，但同样也可以找到其他一些 `string` 实现，其中的每个 `string` 的大小是前者的 7 倍。要想理解这个问题，就得知道一个 `string` 可能会存储哪些数据，以及它可能会把这些数据存储在什么地方。几乎每个 `string` 实现都包含如下信息：
- 字符串的大小，即它所包含的字符的个数。
- 用于存储该字符串中字符的内存的容量。
- 字符串的值，即构成该字符串的字符。
- 除此之外，一个 `string` 可能还包含：它的分配器的一份副本。
- 建立在引用计数基础上的 `string` 实现可能还包含：对值的引用计数。
不同的 `string` 实现以不同的方式来组织这些信息。
在实现 `A` 中，每个 `string` 对象包含其分配器的一份副本、该字符串的大小、它的容量，以及一个指针，该指针指向一块动态分配的内存，其中包含了引用计数和字符串的值。在该实现中，使用默认分配器的 `string` 对象其大小是一个指针的 4 倍。若使用了自定义的分配器，则 `string` 对象会更大一些，多出的部分取决于分配器对象的大小。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00092.jpg)
在实现 `B` 中， `string` 对象与指针大小相同，因为它只包含一个指向结构的指针，这里假定使用了默认的分配器。如果使用了自定义的分配器，则 `string` 对象的大小将会相应地加上分配器对象的大小。在该实现中，由于用到了优化，所以，使用默认分配器不需要多余的空间，而实现 A 中没有这种优化。
`B` 的 `string` 所指向的对象中包含了该字符串的大小、容量和引用计数，以及一个指向一块动态分配的内存的指针，该内存中存放字符串的值。该对象还包含一些与多线程环境下的同步控制相关的额外数据，标记为其他，用于实现同步控制的数据是指针大小的 6 倍。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00093.jpg)
而在实现 `C` 中，`string` 对象的大小总是与指针的相同，因为没有对单个对象的分配器支持，而该指针指向一块动态分配的内存，其中包含了与该字符串相关的一切数据：它的大小、容量、引用计数和值，该内存中也包含了一些与值的可共享性有关的数据。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00094.jpg)
实现 `D` 的 `string` 对象是指针大小的 7 倍，仍然假定使用的是默认的分配器。这一实现不使用引用计数，但是每个 `string` 内部包含一块内存，最大可容纳 15 个字符的字符串。因此，小的字符串可以完整地存放在该 `string` 对象中，这一特性通常被称为小字符串优化特性。当一个 `string` 的容量超过 15 时，该内存的起始部分被当作一个指向一块动态分配的内存的指针，而该 `string` 的值就放在这块内存中。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00095.jpg)
基于上述四种实现，下面的语句创建一个 `string` ：
```c++
string s("Perse");
```
在实现 `D` 中将不会导致任何动态分配，在实现 `A` 和实现 `C` 中将导致一次动态分配，而在实现 B 中会导致两次动态分配（一次是为 `string` 对象所指向的对象，另一次是为该对象所指向的字符缓冲区）。
实现 `B` 的数据结构中包含对多线程系统中同步控制的特别支持，这又意味着在不考虑动态分配次数的前提下，它可能比实现 `A` 或实现 `C` 更适合。实现 `D` 不需要对多线程的特殊支持，因为它没有使用引用计数。关于线程模型和引用计数的字符串之间的交互情况，见第 13 条。
在以引用计数为基础的设计方案中，`string` 对象之外的一切都可以被多个 `string` 所共享，而且实现 `B` 和实现 `C` 可以共享 `string` 的大小和容量，从而减少了每个对象存储这些数据的平均开销。第 13 条给出想将引用计数关闭的一种特殊情况，但其他的原因也可能会这样做。比如，只有当字符串被频繁复制时，引用计数才有用，而有些应用并不经常复制内存，这就不值得使用引用计数。
实现 `C` 不支持针对单个对象的分配器，这意味着只有它可以共享分配器：所有的 `string` 必须使用同一个分配器！在实现 `D` 中，所有的 `string` 都不共享任何数据。
综上所述
-  `string` 对象大小的范围可以是一个 `char*` 指针的大小的 1 到 7 倍。
- 创建一个新的字符串值可能需要零次、一次或两次动态分配内存。
- `string` 对象可能共享，也可能不共享其大小和容量信息。
- `string` 可能支持，也可能不支持针对单个对象的分配器。
- 不同的实现对字符内存的最小分配单位有不同的策略。
## 16：了解如何把 `vector` 和 `string` 数据传给旧的API
### To C API
```c++
vector<int> v;
```
为得到一个指向 `v` 中数据的指针，从而可把 `v` 中的数据作为数组来对待，那么使用 `&v[0]` 就可以， `v[0]` 是一个引用，是该矢量中的第一个元素，所以 `&v[0]` 是指向第一个元素的指针。`C++` 标准要求 `vector` 中的元素存储在连续的内存中，就像数组一样。所以，如果把 `v` 传给一个如下所示的 `C API`：
```c++
void doSomething(const int* pInts, size_t numInts);
if (!v.empty()) doSomething(&v[0], v.size());
```
可能会用 `v.begin()` 来代替`&v[0]`，因为 `begin` 返回 `vector` 的迭代器，而对于 `vector` 来说，迭代器实际上就是指针。但如条款 50 所言，当需要一个指向 `vector` 中的数据的指针时，不应该使用`begin`。如果为了某种原因决定用 `v.begin()`，应该使用 `&*v.begin()` ，因为这和 `&v[0]` 产生同样的指针。
这种得到容器中数据指针的方式对于 `vector` 是适用的，但对于 `string` 却是不可靠的。因为 `string` 中的数据不一定存储在连续的内存中，`string` 的内部表示不一定是以空字符结尾的。这也说明为什么在 `string` 中存在成员函数 `c_str`，该函数返回一个指向字符串的值的指针，而且该指针可用于 C：
```c++
void doSomething(const char* p);
doSomething(s.c_str());
```
即使字符串的长度是零，这样做也是可以的。在这种情况下，`c_str` 会返回一个指向空字符的指针。若字符串内部有空字符，`doSomething` 会把内部的第一个空字符当作结尾的空字符。此外，`string` 对象中包含空字符没关系，但是对基于 `char*` 的 `C API` 则不行。
再看一下 `doSomething` 的声明：
```c++
void doSomething(const int* pInts, size_t numInts);
void doSomething(const char* p);
```
在这两种情况下，要传入的指针都是指向 `const` 的指针。`vector` 或 `string` 的数据被传递给一个要读取，而不是改写这些数据的 `API`。到现在为止，这是最安全的方式。
对于 `string`，这也是唯一所能做的，因为 `c_str` 所产生的指针并不一定指向字符串数据的内部表示，它返回的指针可能是指向字符串数据的一个不可修改的副本，该副本已经被适当的格式化，以满足 `C API` 的要求。
对于 `vector` ，多一点灵活性。如果传递的 `C API` 会改变 `v` 中元素值，通常是没有问题的，但被调用的例程不能试图改变矢量中元素的个数。比如，不能试图在 `vector` 的未使用的容量中创建新元素。不然，`v` 的内部将会变得不一致，因为它从此无法知道自己的正确大小，`v.size()` 将产生不正确的结果。
有些矢量对它们的数据有额外的限制，如果把矢量传递给一个将改变该矢量中数据的 `API`，必须保证这些额外的限制还能被满足。例如，第 23 条解释用排序的矢量代替关联容器是可行的，但重要的是让这类矢量保持有序。如果要把排序的矢量传递给一个可能改变该矢量中数据的 `API`，那么你就要考虑当调用返回时，该矢量可能不再是排序的了。
### To Vector
如果想用来自 `C API` 中的元素初始化一个 `vector` ，那么可以利用 `vector` 和数组的内存布局兼容性，向 `API` 传入该矢量中元素的存储区域：
```c++
// C API：该函数以一个指向最多有arraySize个double类型数据的数组的指针为参数
// 并向该数组中写入数据，它返回已被写入的double数据的个数，这个数不会超过arraySize
size_t fillArray(double* pArray, size_t arraySize); // 无法用于 bool 类型数组
vector<double> vd(maxNumDoubles); // 创建大小为maxNumDoubles的 vector
vd.resize(fillArray(&vd[0], vd.size())); // 使用fillArray向vd中写入数据，然后把vd的大小改为 fillArray 所写入的元素的个数
```
这一技术只对 `vector` 有效，因为只有 `vector` 才保证和数组有同样的内存布局。但对于 `bool` 类型的元素不能这样做，`vector<bool>` 中并没有存储 `bool`，无法得到一个指向 `vector<bool>` 中所含元素类型的指针，见第 18 条。
不过，如果想用来自 `C API` 中的数据初始化一个 `string` ，也很容易就能做到。只要让 `API` 把数据放到一个 `vector<char>` 中，然后把数据从该矢量复制到相应字符串中：
```c++
// C API：该函数以一个指向最多有arraySize个char类型数据的数组的指针为参数，并向该数组中写入数据。
// 它返回已被写入的char数据的个数，这个数不会超过arraySize。
size_t fill(char* pArray, size_t arraySize);
vector <char> vc(maxNumChars); // 创建大小为maxNumChars的 vector 
size_t charsWritten = fill(&vc[0], vc.size(0)); // 使用fill向vc中写入数据 
string s(vc.begin(), vc.begin()+ charsWritten); // 通过区间构造函数，把数据从vc复制到s中
```
实际上，先让 `C API` 把数据写入到一个 `vector` 中，然后把数据复制到期望最终写入的 `STL` 容器中，这一思想总是可行的：
```c++
size_t fillArray(double *pArray, size_t arraySize); 
vector <double> vd(maxNumDoubles);
vd.resize(fillArray(&vd[0],vd.size()));
deque <double) d(vd.begin(), vd.end());
list <double> I(vd.begin(),vd.end());
set<double> s(vd.begin(), vd.end());
```
而且这意味着，除 `vector` 和 `string` 以外的其他 `STL` 容器也能把它们的数据传递给 `C API`，只需把每个容器的元素复制到一个 `vector` 中，然后传给该 `API`：
```c++
void doSomething（const int* pInts，size_t numInts);
set<int> intSet; // 存储要传给API的数据的set
vector <int> v(intSet.begin(),intSet.end()); // 把set的数据复制到 vector
if (!v.empty()) doSomething(&v[0], v.size()); // 把数据传给API
```
## 17：使用 swap 技巧除去多余的容量
为了避免矢量仍占用不再需要的内存，有一种方法能把它的容量从以前的最大值缩减到当前需要的数量，这种对容量的缩减通常被称为 `shrink-to-fit`：
```c++
class Contestant {...};
vector<Contestant> contestants;
vector<Contestant> (contestants).swap(contestants);
string(s).swap(s); // 同样的技巧对 string 也适用
```
表达式 `vector<Contestant>(contestants)` 创建一个临时的矢量，它是 `contestants` 的副本，由 `vector` 的复制构造函数来完成。然而，`vector` 的复制构造函数只为所复制的元素分配所需要的内存，所以这个临时矢量没有多余的容量。
然后把临时矢量中的数据和 `contestants` 中的数据做 `swap` 操作，在这之后，`contestants` 具有被去除之后的容量，即临时变量的容量，而临时变量的容量则变成原先 `contestants` 的容量。在语句结尾，临时矢量被析构，从而释放先前为 `contestants` 所占据的内存。
但这一技术并不保证一定能除去多余的容量。`STL` 的实现者可以自由地为 `vector` 和 `string` 保留多余的容量。所以，这种 `shrink-to-fit` 的方法实际上并不意味着使容量尽量小，它意味着使容量在该实现下变为最小。然而，如果不改用其他的 `STL` 实现的话，那么，这就是所能采取的最佳办法；所以，当想对 `vector` 或 `string` 进行 `shrink-to-fit` 操作时，考虑 `swap` 技巧。
`swap` 技巧的一种变化形式可以用来清除一个容器，并使其容量变为该实现下的最小值。只要与一个用默认构造函数创建的 `vector` 或 `string` 做交换就可以：
```c++
vector<Contestant> v; 
vector<Contestant>().swap(v); // 清除v并把它的容量变为最小

string s;
string().swap(s); // 清除s并把它的容量变为最小
```
在做 `swap` 的时候，不仅两个容器的内容被交换，同时它们的迭代器、指针和引用也将被交换，`string` 除外。在 `swap` 发生后，原先指向某容器中元素的迭代器、指针和引用依然有效，并指向同样的元素——但是，这些元素已经在另一个容器中。
## 18：避免使用 `vector<bool>`
作为一个 `STL` 容器，`vector<bool>` 只有两点不对。首先，它不是一个 `STL` 容器。其次，它并不存储 `bool`。除此以外，一切正常。
一个对象要成为 `STL` 容器，就必须满足 `C++` 标准的的所有条件。其中的一个条件是，取容器中一个元素的地址会产生一个指向容器中元素类型的指针。也就是说，如果 `Container<T>` 支持 `operator[]`，用 `operator[] `取得其中的一个元素，那么可以通过取它的地址得到一个指向该元素类型的指针。所以，如果 `vector<bool>` 是一个容器，那么下面这段代码必须可以被编译：
```c++
T *p = &c[0]; 

vector<bool> v;
bool *pb = &v[0]; // 用 operator[] 返回的变量地址初始化
```
但是它不能编译，因为 `vector<bool>` 并不真的储存 `bool`，为节省空间，`vector<bool>` 使用与位域一样的思想来表示它所存储的那些 `bool`，储存在 `vector` 中的每个 `bool` 仅占一个二进制位，实际上它只是假装存储这些 `bool`。
位域与 `bool` 相似，它只能表示两个可能的值，但是在 `bool` 和位域之间有一个很重要的区别：可以创建一个指向 `bool` 的指针，而指向单个位的指针则是不允许的，指向单个位的引用也是被禁止的。
这使得在设计 `vector<bool>` 的接口时产生了一个问题，因为 `vector<T>::operator[]` 的返回值应该是 `T&`。如果 `vector<bool>` 中所存储的确实是 `bool`，那么这就不是一个问题。但由于实际上并非如此，所以 `vector<bool>::operator[]` 需要返回一个指向单个位的引用，而这样的引用却不存在。
为克服这一困难，`vector<bool>::operator[]` 返回一个对象，这个对象表现得像是一个指向单个位的引用，即所谓的代理对象。抛开细节，`vector<bool>` 看起来像是这样：
```c++
template<typename Allocator> 
vector<bool, Allocator> { 
public:
    class reference {...}; // 用来为指向单个位的引用而产生代理的类
    reference operator[](size_type n); // 返回一个代理 
};

vector<bool> v;
// 表达式的右边是 vector<bool>::reference* 类型，而不是 bool* 类型
bool *pb = &v[0]; 
```
因为上面的代码不能编译，所以 `vector<bool>` 不满足对 `STL` 容器的要求。
当需要` vector<bool>`时，标准库提供两种选择，可以满足绝大多数情况下的需求。第一种是 `deque<bool>`，`deque<bool>` 是一个 `STL` 容器，而且它确实存储 `bool`。`deque` 几乎提供了 `vector` 所提供的一切，只是没有 `reserve` 和 `capacity`，但 `deque` 中元素的内存不是连续的，不能把 `deque<bool>` 中的数据传递给一个期望 `bool` 数组的 `C API`，而且对于 `vector<bool>`，也不能这么做，因为没有一种可移植的方法能够得到 `vector<bool>` 的数据。
第二种可以替代 `vector<bool>` 的选择是 `bitset`。`bitset` 不是 `STL` 容器，但它是标准 `C++` 库的一部分。与 `STL` 容器不同的是，它的大小（即元素的个数）在编译时就确定，所以它不支持插入和删除元素。而且，因为它不是一个 `STL` 容器，所以它不支持迭代器。但是与 `vector<bool>` 一样，只为所包含的每个值提供一位空间，提供 `vector<bool>` 特有的 `flip` 成员函数，以及其他一些特有的、对位的集合有意义的成员函数。
# Associative Container
## 19：理解 equality 和 equivalence 的区别
### Equality
在 `STL` 中，对两个对象进行比较，看它们的值是否相同。比如，当通过 `find` 在某个区间中寻找第一个等于某个值的元素时，`find` 必须能够比较两个对象，看一个对象的值是否等于另一个对象的值。与此类似，当试图把一个新元素插入到 `set` 中时，`set::insert` 必须能够确定该元素的值是否已经在该 `set` 中。
但不同的函数以不同的方式来判断两个值是否相同。`find` 对相同的定义是相等，是以 `operator==` 为基础的。`set::insert` 对相同的定义是等价，是以 `operator<` 为基础的。因为两个定义不同，所以，有可能用一个定义断定两个对象有相同的值，而用另一个定义则断定它们的值不相同。
在实际操作中，相等的概念是基于 `operator=` 的，如果表达式 `x=y `返回真，则 x 和 y 的值相等，但是 `x` 和 `y` 有相等的值并不一定意味着它们的所有数据成员都有相等的值。比如，可能有一个 `Widget` 类，它在内部记录着自己最近一次被访问的时间：
```c++
class Widget { 
private:
	TimeStamp lastAccessed; 
};
// 可能有一个针对 Widget 的 operator=，它忽略了 lastAccessed：
bool operator==(const Widget& lhs, const Widget& rhs) {}
```
在这种情况下，两个 `Widget` 即使有不同的 `lastAccessed` 域，它们也可以有相等的值。
### Equivalence
等价关系是根据被排序区间中对象值的相对顺序来判断的。排列顺序标准关联容器的一部分，如果从每个排列顺序来考虑等价关系，那么这将是非常有意义的。对于两个对象 `x` 和 `y`，如果按照关联容器 `c` 的排列顺序，每个都不在另一个的前面，那么称这两个对象按照 `c` 的排列顺序有等价的值。
举例来说，考虑 `set<Widget> s`。如果 `w1` 和 `w2` 在 s 的排列顺序中哪个也不在另一个的前面，那么，`w1` 和 `w2` 对于 `s` 而言有等价的值。`set<Widget>` 的默认比较函数是 `less<Widget>`，而在默认情况下 `less<Widget>` 只是调用针对 `Widget` 的`operator<`，所以，如果下面的表达式结果为真，则 `w1` 和 `w2` 对于 `operator<` 有等价的值：
```c++
!(w1 < w2); // w1 < w2不为真
&&
!(w2 < w1); // w2 < w1不为真
```
这里的含义是：如果两个值中的任何一个按照一定的排序准则都不在另一个的前面，那么这两个值按照这一准则就是等价的。
在一般情形下，一个关联容器的比较函数并不是 `operator<`，甚至也不是 `less`，它是用户定义的判别式。假如每个标准关联容器都通过 `key_comp` 成员函数使排序判别式可被外部使用，所以，如果下面的表达式为 `true`，则按照关联容器 `c` 的排序准则，两个对象 `x` 和 `y` 有等价的值：
```c++
!c.key_comp()(x, y) && !c.key_comp()(y, x); // 在c的排列顺序中，x在y之前不为真，y在x之前也不为真
```
考虑一个比较函数忽略字符串中字符的大小写时的 `set<string>`。第 35 条显示怎样实现一个函数 `ciStringCompare`，它进行不区分大小写的比较，而 `set` 需要一个比较函数的类型，而不是实际的函数，因此使用函数子类的 `operator()` 调用 `ciStringCompare`：
```c++
struct CiStringCompare: public binary_function<string, string, bool> { // 该基类的信息请参阅第 40 条
    bool operator()(const string& lhs, const  `string` & rhs) const {
        return ciStringCompare(lhs, rhs); // 关于ci `string` Compare是如何实现的，请参阅第35条
    }
};

set<string, CiStringCompare> ciss;
ciss.insert("Persephone"); // 一个新元素被插入到集合中
ciss.insert("persephone"); // 没有新元素被插入到集合中

// 如果用set的find成员函数来查找字符串 persephone，则该查找会成功：
if (ciss.find("persephone") != ciss.end()); // 该检查将成功 

// 但如果使用非成员的find算法，则查找将失败：
// 这解释了为什么应该遵循第 44 条中的建议，优先选用成员函数而不是与之对应的非成员函数
if (find(ciss.begin(), ciss.end(), "persephone") != ciss.end());
```
### Why
为什么标准关联容器是基于等价而不是相等的。
标准关联容器总是保持排列顺序的，所以每个容器必须有一个比较函数来决定保持怎样的顺序。等价的定义正是通过该比较函数而确定的，因此，标准关联容器的使用者要为所使用的每个容器指定一个比较函数用来决定如何排序。
如果该关联容器使用相等来决定两个对象是否有相同的值，那么每个关联容器除用于排序的比较函数外，还需要另一个比较函数来决定两个值是否相等。默认情况下，该比较函数应该是 `equal_to`，但 `equal_to` 从来没有被用作 `STL` 的默认比较函数。当 `STL` 中需要相等判断时，一般的惯例是直接调用`operator==`。比如，非成员函数 `find` 算法就是这么做的。
假定有一个类似于 `set` 的 `STL` 容器 `set2CF`，其含义为有两个比较函数的集合。第一个比较函数用来决定集合的排列顺序，第二个用来决定两个对象是否有相同的值。现在考虑这个 `set2CF`：
```c++
set2CF<string, CIStringCompare, equal_to<string>> s;
s.insert("Persephone");
s.insert("persephone");
```
这会带来以下问题：
- 无法确定二者会以什么顺序存放，排序函数并不能将它们分开，如果为了保持元素的确定顺序而忽略第二个 `insert` 调用，那么对 `find` 的调用将会失败，尽管忽略插入的原因是因为它是重复的值。
- 如果要把它们以任意方式插入，就会放弃以确定的方式遍历关联容器的元素的能力，对 `multiset` 和 `multimap`，就不能以确定的顺序遍历容器的元素，因为 `C++` 标准对于等价的值或键的相对顺序没有限制。
使用单一的比较函数，并把等价关系作为判定两个元素是否相同的依据，使得标准关联容器避免使用两个比较函数将带来的问题，尽管会带来成员的和非成员的 `find` 会返回不同的结果这种问题，但从长远来看，这样做避免在标准关联容器中混合使用相等和等价将会带来的混乱。
上述均是基于排序的关联容器，对于非标准的基于散列表的关联容器，有两种常见的设计，一种是基于相等的，而另一种则是基于等价的。
## 20：为包含指针的关联容器指定比较类型
对于下述代码：
```c++
set<string*> ssp;
ssp.insert(new string("Anteater"));
ssp.insert(new string("Wombat")); 
ssp.insert(new string("Lemur"));
ssp.insert(new string("Penguin"));

for (set<string*>::const_iterator i = ssp.begin(); i != ssp.end(); ++i)
	cout << *i << endl;
```
实际上看到的将是 4 个十六进制数，即指针的值。因为集合中包含的是指针，`*i` 不是 `string` ，而是 `string*`。如果换一种方式，使用 `copy` 算法：
```c++
copy(ssp.begin(), ssp.end(), ostream_iterator<string>(cout,"\n")); // 把ssp中的字符串复制到cout（但这不能通过编译）
```
这里的 `copy` 调用根本就不能编译。`ostream_iterator` 需要知道将要被打印的对象的类型，当你`string` 作为一个模板参数传入，编译器检测到该类型和 `ssp` 所存储的类型 `string*` 不一致，会拒绝编译这段代码。
如果把显式循环中的 `*i` 改为 `**i`，那么可能会得到想要的输出，但更大的可能是得不到。`ssp` 会按顺序保存它的内容，但因为它包含的是指针，所以会按照指针的值进行排序，而不是按字符串的值。`4` 个指针的值共有 `24` 种可能的排列方式，所以对要存储的指针会有 24 种可能的排列，因此看到这些字符串以字母顺序排列的可能性为 `1/24`。
如果想让 `string*` 在集合中按字符串的值排序，就不能使用默认的比较函数子类` less<string*>`，必须自己编写比较函数子类，该类的对象以 `string*` 为参数，并按照所指向的 `string` 的值进行排序。就像这样：
```c++
struct StringPtrLess: public binary_function<const string*, const string*, bool> {  // 采用该基类的原因见第40条
    bool operator()(const string* ps1, const string* ps2) const {
        return *ps1 < *ps2; 
	}
};
typedef set<string*, StringPtrLess> StringPtrSet; 
StringPtrSet ssp; // 创建一个包含字符串的集合，并用 StringPtrLess 定义的规则排序
for (StringPtrSet::const_iterator i = ssp.begin(); i!=ssp.end(); ++i)  
    cout << **i << endl // 打印出的是“Anteater”，“Lemur”，“Penguin”和“Wombat” 
```
之所以创建函数子类而不是为集合写一个比较函数：
```c++
// 将作为一个比较函数，用于按照字符串的值对 string* 指针进行排序
bool StringPtrLess(const string* ps1, const string* ps2) { 
	return *ps1 < *ps2;
}
set<string, StringPtrLess> ssp; // 试图使用 StringPtrLess 作为ssp的比较函数，这不能通过编译
```
`set` 模板的三个参数每个都是一个类型，但 `StringPtrLess` 不是一个类型，是一个函数。因此，每当创建包含指针的关联容器时，可能同时也要指定容器的比较类型。大多数情况下，这个比较类型只是解除指针的引用，并对所指向的对象进行比较。考虑到这种情况，最好为这样的比较函数子准备一个模板：
```c++
struct DereferenceLess{
    // 参数是按值传入的，因为期望它们是（或表现得像）指针
    template<typename PtrType> 
    bool operator()(PtrType pT1, PtrType pT2) const { 
        return *pT1 < *pT2;
    }
};
    
set<string*, DereferenceLess> ssp; // 与set<string, StringPtrLess>的行为相同
```
每当要创建包含指针的关联容器时，一定要记住默认情况下容器将会按照指针的值进行排序。本条款是关于包含指针的关联容器的，但它同样也适用于其他一些容器，这些容器中包含的对象与指针的行为相似，比如智能指针和迭代器。如果有一个包含智能指针或迭代器的容器，那么也要考虑为它指定一个比较类型。
对指针的解决方案同样也适用于那些类似指针的对象。就像 `DereferenceLess` 适合作为包含 `T*` 的关联容器的比较类型一样，对于容器中包含指向 `T` 对象的迭代器或智能指针的情形，`DereferenceLess` 也同样可用作比较类型。
## 21：总是让比较函数在等值情况下返回 false
对下面的 `insert` 调用，集合必须要确定 10 是否已经存在。为便于理解当集合这么做时会发生什么，我们把最初插入的 10 记做 `10A` ，而把现在试图插入的 10 记做 `10B` 。
```c++
set<int, less_equal<int>> s; // s用 <= 来排序
s.insert(10); // 插入10
s.insert(10); // 现在再插入10
```
集合遍历它的内部数据结构，以便确定在哪里插入 `10B` ，最终要检查 `10B` 是否与 `10A` 相同。对于关联容器，相同的定义是等价，见第 19 条，所以集合会测试 `10B` 是否与 `10A` 等价。在做这一测试时，会使用该集合的比较函数。因为此处指定函数 `less_equal` 作为集合的比较函数，`less_equal` 意味着 `operator<=`。因此，集合会检查下面的表达式是否为真：
```c++
!(10A <= 10B) && !(10B <= 10A); 
(true) && (!true);
false && false;

// 若相同值的两个副本返回 false 最终结果会是 true，即二者等价
```
结果是 `false`，`10A` 和 `10B` 不等价，从而不相同，因此，`10B` 将会被插入到容器中 `10A` 的旁边。从技术角度来看，这会导致不确定的行为，但更普遍的后果是，会导致集合中有 `10` 的两份副本，这意味着它不再是一个集合！通过使用 `less_equal` 作为比较类型，会破坏 `set` 容器！而且，任何一个比较函数，如果它对相等的值返回 `true`，则都会导致同样的结果，相等的值按照定义却是不等价的。
因此要保证对关联容器所使用的比较函数总是要对相等的值返回 `false`。然而违反这一规定是出奇地容易。比如，第 20 条描述为包含 `string*`  指针的容器编写一个比较函数，从而使得容器按照 `string` 的值而不是指针的值对其内容进行排序。该比较函数按照升序对容器中的元素进行排列，但假定需要一个比较函数来对这样的容器做降序排列。要做到这一点，最自然的方式是修改现有的代码，可能会这样做：
```cpp
struct StringPtrGreater: public binary_function<const string*, 
                            const string*, bool>{
    bool operator()(const string *ps1, const string *ps2) const { 
        return !(*ps1 < *ps2); // 将旧的测试简单取反，这并不对
        // return *ps2 < *ps1;  真正想要的比较类型实际上是这样的
    }
};
```
这里的思想是，通过对比较函数内部的测试取反来改变排列顺序，但把 `<` 取反得到的是 `>=`，而 `>=` 对于关联容器不是一个合法的比较函数，因为它对于相等的值将返回 `true`。
比较函数的返回值表明的是按照该函数定义的排列顺序，一个值是否在另一个之前，相等的值从来不会有前后顺序关系，所以，对于相等的值，比较函数应当始终返回 `false`。
对 `set` 和 `map` 是这样，因为这些容器不能包含重复的值。而对于 `multiset` 和 `multimap` 同样如此：
```c++
multiset<int, less_equal<int>>s; // s仍然用 <= 来排序
s.insert(10); // 插入10A 
s.insert(10); // 插入10B 
```
现在 `s` 中有两个 `10`，所以，如果对它做 `equal_range` 操作，则将得到一对迭代器，它们定义一个包含这两个值的区间。但 `equal_range` 并不指定一个包含相等值的区间，而是指定一个包含等价值的区间。在这个例子中，`s` 的比较函数说 `10A` 和 `10B` 不等价，所以它们不可能都在 `equal_range` 指定的区间中。
因此除非比较函数对相等的值总是返回 `false`，否则会破坏所有的标准关联容器，不管它们是否允许存储重复的值。从技术上来说，用于对关联容器排序的比较函数必须为它们所比较的对象定义一个严格的弱序化。对于传递给像 `sort` 这类算法（见第 31 条）的比较函数也有同样的限制。即，任何一个定义了严格的弱序化的函数必须对相同值的两个副本返回 `false`。
## 第22条：切勿直接修改 `set` 或 `multiset` 中的键
像所有的标准关联容器一样，`set` 和 `multiset` 按照一定的顺序来存放自己的元素，而这些容器的正确行为也是建立在其元素保持有序的基础之上的。如果把关联容器中一个元素的值改变，那么，新的值可能不在正确的位置上，这将会打破容器的有序性。如果有程序试图改变 `map` 和 `multimap` 中的键，它将不能通过编译：
```cpp
map<int, string> m; 
m.begin()->first = 10;  // 错！map 的键不能修改
multimap<int, string> mm;
mm.begin()->first = 20; // 错！multimap 的键同样不能修改
```
### Const Key
对于一个 `map<K,V>` 或 `multimap<K,V>` 类型的对象，其中的元素类型是 `pair<const K,V>`。除非使用强制类型转换，直接修改键的值对 `map` 或 `multimap` 是行不通的，但对 `set` 和 `multiset` 是可能的。对于 `set<T>` 或 `multiset<T>` 类型的对象，容器中元素的类型是 `T`，而不是 `const T`。因此，可以改变 `set` 和 `multiset` 中的元素，而无须任何强制类型转换。
假定有一个针对雇员的 `Employee` 类，每一个雇员有一个唯一的 `ID` 号，这个 `ID` 号是由 `idNumber` 函数返回的。为创建一个存放雇员信息的 `set` 容器，只用这个 ID 号来对集合进行排序是合理的：
```cpp
class Employee{
public:
    const string& name() const;
    void setName(const string& name);
    const string& title() const;
    void setTitle(const string& title);
    int idNumber() const;
};

struct IDNumberLess: public binary_function<Employee, Employee,bool> {
    bool operator()(const Employee& Ihs, const Employee& rhs) const {
        return lhs.idNumber() < rhs.idNumber();
    }
};

typedef set<Employee, IDNumberLess> EmpIDSet; 
EmplDSet se;
```
雇员的 ID 号是这个 `set` 中的元素的键，其他的雇员数据跟这个键绑在一起。可以把个别雇员的头衔改为某个有特定含义的值，就像下面这样：
```cpp
Employee selectedID;

EmpIDSet::iterator i = se.find(selectedID);
if (i != se.end()) i->setTitle("Corporate Deity");
```
因为在这里所做的是修改雇员中与集合的排序方式无关的部分，即雇员记录中不属于键的部分，所以这段代码不会破坏该集合。因此它是合法的，这也意味着 `set/multiset` 的元素不能为const。
本条款的目的是提醒，如果改变 `set` 或 `multiset` 中的元素，一定不要改变键部分——元素的这部分信息会影响容器的排序性，这项限制只适用于被包含对象的键部分，对于被包含元素的其他部分，则完全是开放的。
尽管 `set` 和 `multiset` 的元素不是 `const`， `STL` 实现也有办法防止它们被修改。比如，某个实现可能会使 `set<T>::iterator` 的 `operator*` 返回一个 `const T&`。也就是说，解除 `set` 迭代器的引用之后的结果是一个指向该集合中元素的 `const` 引用。在这样的实现下，没办法修改 `set` 或 `multiset` 的元素，因为所有访问元素的途径都在得到的元素前面增加了一个 `const`。因为标准的模棱两可，以及由此产生的不同理解，所以，试图修改 `set` 或 `multiset` 中元素的代码将是不可移植的。
综上：
- 如果不关心可移植性，想改变 `set` 或 `multiset` 中元素的值，并且你的 `STL` 实现允许这么做，则只需要注意不要改变元素中的键部分，即元素中能够影响容器有序性的部分。
- 如果重视可移植性，就要确保 `set` 和 `multiset` 中的元素不能被修改，至少不能未经过强制类型转换就修改。
### Cast Type Conversion
如果要强制类型转换，必须首先强制转换到一个引用类型：
```c++
EmplDSet::iterator i = se.find(selectedID);
// 有些 STL 实现将认为这一行不合法，因为 *i 为const
if(i != se.end()) i->setTitle("Corporate Deity"); 

// 为使它能够编译和正确执行，必须把 *i 的常量性质转换掉。下面是正确的做法：
if (i != se.end())  // 它将取得i所指的对象，并告诉编译器把类型转换的结果当作一个指向（非const的）Employee的引用，然后对该引用调用setTitle。
    const_cast<Employee&>(*i).setTitle("Corporate DDeity");

// 第二种方式
if (i != se.end())
    static_cast<Employee>(*i).setTitle("Corporate Deity"); // 把 *i 转换成 Employee 它与下面的方式是等价的：

if (i!=se.end()) // 同上，只是使用了C方式的类型转换
    ((Employee)(*i)).setTitle("Corporate Deity");
```
第二种方式的两种形式都能通过编译，因为它们是等价的，所以它们出错的原因也相同。在运行时，它们不会修改 `*i`。在这两种情况下，类型转换的结果是一个临时的匿名对象，它是 `*i` 的一个副本，`setTitle` 被作用在这个临时对象上，而不是 `*i `上。这两种语法形式都等价于：
```c++
if (i != se.end()){
    Employee tempCopy(*i); // 把 *i 复制到tempCopy
    tempCopy.setTitle("Corporate Deity");  // 修改tempCopy
}
```
通过强制转换到引用类型，避免创建新的对象。这样，类型转换的结果将会指向已有的对象，即 `i` 所指的那个对象。当 `setTitle` 被作用在该引用所指的对象上时，是在对 `*i `调用 `setTitle`，而这正是所期望的。
刚才所说的对于 `set` 和 `multiset` 没有任何问题，但 `map<K,V>` 或 `multimap<K,V>` 包含的是`pair<const K,V>` 类型的元素。这里的 `const` 意味着 `pair` 的第一个部分被定义成 `const`，而这又意味着如果试图把它的 `const` 属性强制转换掉，则结果将可能会改变键部分。
大多数强制类型转换都可以避免，包括考虑过的那个转换。如果想以一种总是可行而且安全的方式来修改这些容器中的元素，则可以分 5 个步骤来进行：
- 找到想修改的容器的元素，第 45 条介绍如何执行一次恰当的搜索来找到特定的元素。
- 为将要被修改的元素做一份副本。在 `map` 或 `multimap` 的情况下，不要把该副本的第一个部分声明为 `const`。毕竟，想要改变它。
- 修改该副本，使它具有期望它在容器中的值。
- 把该元素从容器中删除，通常是通过调用 `erase` 来进行的（见第 9 条）。
- 把新的值插入到容器中。如果按照容器的排列顺序，新元素的位置可能与被删除元素的位置相同或紧邻，则使用提示形式的 `insert`，以便把插入的效率从对数时间提高到常数时间。把从第 1 步得来的迭代器作为提示信息。
下面是同样的 `Employee` 例子，这次是用安全的、可移植的方式来编写的：
```cpp
EmpIDSet se;
EmpIDSet::iterator i = se.find(selectedID); // 第1步：找到待修改的元素
if(i != se.end()) {
    Employee e(*i);   // 第2步：复制该元素
    e.setTitle("Corporate Deity"); // 第3步：修改副本
    se.erase(i++);   // 第4步：删除该元素；递增迭代器以保持它的有效性（见第9条）
    se.insert(i, e); // 第5步：插入新元素；提示它的位置和原来的相同
}
```
关键是要记住，对 `set` 和 `multiset`，如果直接对容器中的元素做修改，那么要保证该容器仍然是排序的。
那为什么同样的逻辑不能用于 `map` 和 `multimap` 中的键？因为标准委员会认为，`map/multimap` 的键应该是 `const`，而 `set/multiset` 的值应该不是。
## 第23条：考虑用排序的 `vector` 替代关联容器
### Why
许多 `STL` 程序员，当需要一个可提供快速查找功能的数据结构时，会立刻想到标准关联容器，即 `set`、`multiset`、`map` 和 `multimap`。但它们并不总是适合的，如果查找速度真的很重要，那么考虑非标准的散列容器几乎总是值得的（见第 25 条）。通过适当的散列函数，散列容器几乎能提供常数时间的查找能力。对于许多应用，散列容器可能提供的常数时间查找能力优于标准关联容器的确定的对数时间查找能力。
很多应用程序使用其数据结构的过程可以明显地分为设置、查找、重组阶段，对以这种方式使用其数据结构的应用程序来说，`vector` 可能在时间空间方面比关联容器提供更好的性能。但并不是任何一个 `vector` 都能做到这一点，必须是排序的 `vector` 才可以，因为只有对排序的容器才能够正确地使用查找算法 `binary_search`、`lower_bound` 和 `equal_range` 等（见第 34 条）。
但是为什么通过排序的 `vector` 执行的二分搜索，比通过二叉查找树执行的二分搜索具有更好的性能？其中之一是大小的因素。假定需要一个容器来存储 `Widget` 对象，因为查找速度很重要，所以考虑使用一个 `Widget` 的关联容器或一个排序的 `vector<Widget>`。如果选择关联容器，一个关联容器中存储一个 `Widget` 所伴随的空间开销至少是 `3` 个指针和一个 `Widget`。
相反，如果把 `Widget` 存储在 `vector` 中，则不会有任何额外开销。虽然 `vector` 本身也有开销，在 `vector` 的末尾可能会有空闲的预留空间，但平均到每个 `vector` ，这些开销通常是 3 个指针或者 2 个指针加 1 个 `int`，而且如果有必要，结尾的空闲空间可以用 `swap` 技巧去除。即便多余的空间没有被去除掉，它对下面的分析也没有影响，因为在做查找时这块内存根本就不会被引用到。
绝大多数 `STL` 实现使用了自定义的内存管理器来做到这样的聚集效果，但是 `STL` 实现没有采取措施来提高这些树节点的引用局域性，那么，这些节点将会散布在全部地址空间中，这将会导致更多的页面错误。即便使用可提供聚集特性的自定义内存管理器，关联容器在页面错误这一点上也会有更多的问题，因为，与 `vector` 这样的内存连续容器不同，基于节点的容器要想保证在容器的遍历顺序中相邻的元素在物理内存中也是相邻的，将会更加困难。而在执行二分搜索时，这种内存组织方式恰好可以最大限度地减少页面错误。
因此，在排序的 `vector` 中存储数据可能比在标准关联容器中存储同样的数据要耗费更少的内存，而考虑到页面错误的因素，通过二分搜索法来查找一个排序的 `vector` 可能比查找一个标准关联容器要更快一些。
对于排序的 `vector` ，最不利的地方在于它必须保持有序！插入和删除操作对于 `vector` 来说是昂贵的，但对于关联容器却是廉价的。这就是为什么只有当数据结构的使用方式是：查找操作几乎从不跟插入和删除操作混在一起时，再考虑使用排序的 `vector` 而不是关联容器才是合理的。
```cpp
vector<Widget> vw; // 取代set<Widget>
... // 设置阶段：大量的插入，查找却很少

// 设置阶段结束。当模拟一个multiset时，可能会选用stable_sort，见第 31 条
sort(vw.begin(), vw.end()); 
Widget w; // 用于存放待查找值的对象
if (binary_search(vw.begin(), vw.end(), w)) ... // 开始查找阶段

vector<Widget>::iterator i = lower_bound(vw.begin(), vw.end(),w);
if (i!=vw.end() && !(w < *i))... // 对 !(w < *i) 测试的解释，见第19条

pair<vector<Widget>::iterator, vector<Widget>::iterator> 
        range = equal_range(vw.begin(), vw.end(), w);
 
if (range.first != range.second)...

sort(vw.begin(), vw.end()); // 结束查找阶段，开始重组阶段
```
### map
如果决定用一个 `vector` 来替换 `map` 或 `multimap`，那 `vector` 必须要存放 `pair` 对象。但如果声明了一个 `map<K,V>` 类型的对象，那么 `map` 中存储的对象类型是 `pair<const K,V>`。用 `vector` 来模仿 `map/multimap`，必须要省去 `const`，因为当对这个 `vector` 进行排序时，它的元素的值将通过赋值操作被移动，这意味着 `pair` 的两个部分都必须是可以被赋值的。
`map` 和 `multimap` 总是保持自己的元素是排序的，但它在排序时，只看元素的键部分，因此当对 `vector` 做排序时，需要为 `pair` 写一个自定义的比较函数，因为 `pair` 的 `operator<` 对 `pair` 的两部分都会检查。但用来做排序的比较函数需要两个 `pair` 对象作为参数，查找的时候只需要一个键值。所以，用于查找的比较函数必须带一个与键同类型的对象和一个 `pair` 对象作为参数。此外，由于不知道传进来的第一个参数是键还是 `pair`，所以需要两个用于查找的比较函数：一个假定键部分作为第一个参数传入，另一个假定 `pair` 先传入：
```cpp
typedef pair<string, int> Data;

class DataCompare { // 比较函数的类 
public:
    // 用于排序的比较函数
    bool operator()(const Data& lhs, const Data& rhs) const { // 用于排序的比较函数
        return keyLess(lhs.first, rhs.first);
    }
    // 用于查找的比较函数第 1 种形式
    bool operator()(const Data& lhs, const Data::first_type& k) const { 
        return keyLess(lhs.first, k);
    }
    // 用于查找的比较函数第 2 种形式
    bool operator()(const Data::first_type& k, const Data& rhs) const {
        return keyLess(k, rhs.first);
    } 
private:
    // 实际的比较函数
    book keyLess(const Data::first_type & k1, const Data::first_type& k2) const {
        return k1 < k2;
    }
};
```
在这个例子中，假定排序的 `vector` 在模仿 `map<string, int>`。`keyLess` 成员函数是为了保证不同的 `operator()` 函数的一致性。由于每个这样的比较函数都只是在比较两个键值，所以没有必要重复该逻辑，而是把测试部分放在 `keyLess` 内部，并让 `operator()` 返回keyLess的结果。但缺点是提供不同参数类型的 `operator()` 函数将使得这样的函数对象难以被配接，见第 40 条。
把排序的 `vector` 当作映射表来使用，其本质上就如同将它用作一个集合一样。唯一的区别是，需要用 `DataCompare` 对象作为比较函数：
```cpp
vector<Data> vd; // 取代map<string, int>

sort(vd.begin(), vd.end(),DataComparel());

string s;
if (binary_search(vd.begin(), vd.end(), s, DataCompare()))...

vector<Data>::iterator i = lower_bound(vd.begin(), vd.end(), s, DataCompare());
if (i != vd.end() && !DataCompare()(s, *i))

pair<vector<Data>::iterator, vector<Data>::iterator> 
    range = equal_range(vd.begin(), vd.end(), s, DataCompare());
if (range.first != range.second)...

sort(vd.begin(), vd.end(), DataCompare());
```
相比使用 `map` 的设计，它们通常会运行得更快而且使用更少的内存，前提是使用数据结构的方式符合本条款开始时候提到的三阶段模式，否则使用排序的 `vector` 而不是标准关联容器肯定是在浪费时间。
## 24：当效率至关重要时，在`map::operator[]`与`map::insert`之间做出选择
### Add
`map` 的 `operator[]` 函数与 `vector`、`deque` 和 `string` 的 `operator[]` 函数无关，与用于数组的内置 `operator[]` 也没有关系。`map::operator[]` 的设计目的是为了提供添加和更新的功能。对于表达式 `m[k]=v` 检查键 `k` 是否已经在 `map` 中，如果没有就被加入，并以 `v` 作为相应的值。如果已经在映射表中，则与之关联的值被更新为 `v`。
`operator[]` 返回一个引用，指向与 `k` 相关联的值对象，然后 `v` 被赋给该引用所指向的对象。如果键 `k` 已经有相关联的值，则该值被更新，但如果 `k` 还没有在映射表中，那就使用值类型的默认构造函数创建一个新的对象，然后 `operator[]` 就能返回一个指向该新对象的引用。
```c++
map<int, Widget> m
m[1] = 1.50;
```
表达式 `m[1]` 是 `m.operator[](1)`的缩写形式，这是对 `map::operator[]` 的调用，该函数必须返回一个指向 Widget 的引用。刚开始 `m` 中键 1 没有对应的值对，因此 `operator[]` 默认构造了一个 `Widget`，作为与键 1 相关联的值，然后返回一个指向该 `Widget` 的引用。最后，这个 `Widget` 作为赋值的目标，被赋予的值是 1.50。
换句话说，语句 `m[1] = 1.50;` 在功能上等同于：
```cpp
typedef map<int, Widget> IntWidgetMap;
// 用键值 1 和默认构造的值对象创建一个新的 map 条目
pair<IntWidgetMap::iterator, bool> 
    result = m.insert(IntWidgetMap::value_type(1, Widget()));
    
result.first->second = 1.50; // 为新构造的值对象赋值
```
这里先默认构造一个 `Widget`，然后再赋给它新的值。但如果换成对 `insert` 的调用：
```c++
// 直接使用所需要的值构造一个 Widget 比先默认构造一个 Widget 再赋值效率更高
m.insert(IntWidgetMap::value_type(1, 1.50));
```
这里的最终效果和前面的代码相同，但它通常会节省 `3` 个函数调用：一个用于创建默认构造的临时 `Widget` 对象，一个用于析构该临时对象，另一个是调用 `Widget` 的赋值操作符。
### Update
`operator[]` 的设计目的是为了提供添加和更新的功能，当作为添加操作时，`insert` 效率更高。当做更新操作时，恰好反过来：
```c++
m[k] = v; // 使用 operator［］把k的值更新为v 
m.insert(IntWidgetMap::value_type(k, v)).first->second = v; // 使用insert把k的值更新为v
```
`insert` 调用需要一个 `IntWidgetMap::value_type` 类型的参数，即 `pair<int,Widget>`，所以当调用 `insert` 时，必须构造和析构一个该类型的对象。这要付出一个 `pair` 构造函数和一个 `pair` 析构函数的代价。而这又会导致对 `Widget` 的构造和析构动作，因为 `pair<int,Widget>` 本身又包含一个 `Widget` 对象。而 `operator[]` 不使用 `pair` 对象，所以它不会构造和析构任何 `pair` 或 `Widget`。
得出结论：当向映射表中添加元素时，要优先选用 `insert`，而不是 `operator[]`，当更新已经在映射表中的元素的值时，要优先选择 `operator[]`。
### Conclusion
最好能提供一个函数，它兼具以上两种操作的优点，即在一个语法包内提供高效的添加和更新功能：
```c++
template<typename MapType, typename KeyArgType,typename ValueArgType>

typename MapType::iterator efficientAddOrUpdate(MapType& m,
                    const KeyArgType& k, const ValueArgType& v) 
{
    // 确定k在什么位置或应在什么位置
    typename MapType::iterator lb = m.lower_bound(k); 
    // 如果Ib指向的pair的键与k等价，则更新pair的值并返回指向该pair的迭代器
    if (lb != m.end() && !(m.key_comp()(k, lb->first))) {
        lb->second = v;
        return Ib;
    }
    else { // 把pair<k，v>添加到m中，并返回一个指向该新元素的迭代器
        typedef typename MapType::value_type MVT; 
        // 如果提示是正确的，则插入操作将耗费常数时间，而不是对数时间
        return m.insert(lb, MVT(k, v));
    }                    
}

// 如果k不在map m中，则高效地把 pair(k, v) 添加到 m 中
// 不然就高效地把与k相关联的值更新为v，返回一个迭代器，指向刚刚添加的或更新的pair
iterator affectedPair = efficientAddOrUpdate(m, k, v); 
```
`KeyArgType` 和 `ValueArgType` 不必是存储在映射表中的类型。只要它们能够转换成存储在映射表中的类型就可以。另一种选择是去掉类型参数 `KeyArgType` 和 `ValueArgType`，而用`MapType::key_type` 和 `MapType::mapped_type` 来代替。然而，如果这样做的话，在函数被调用时可能会导致不必要的类型转换。比如，再看一下本条款的例子中所用的映射表定义：
```c++
map<int, Widget>m;
class Widget {
    Widget& operator=(double weight); // Widget接受来自double的赋值
};

// 现在考虑对efficientAdd0rUpdate的调用：
efficientAddOrUpdate(m, 10, 1.5); 
```
假设这是一个更新操作，即 m 已经包含了一个键为 10 的元素。在这种情况下，上面的模板推断出 `ValueArgType` 是 `double`，因而函数体直接把 1.5 作为 `double` 赋给与键 10 相关联的 `Widget`。这是通过对 `Widget::operator=(double)` 的调用实现的。
而如果使用 `MapType::mapped_type` 作为 `efficientAddOrUpdate` 第三个参数的类型，那么，已经在调用时把 1.5 转换成一个 `Widget`，这样就为 `Widget` 的构造（以及随后的析构）付出了代价，而这本来是不必要的。
# Iterator
## 26：`iterator` 优先于 `const_iterator`、`reverse_iterator` `以及const_reverse_iterator`
 `STL` 中的所有标准容器都提供 `4` 种迭代器类型。对容器类 `container<T>` 而言，`iterator` 类型的功效相当于 `T*`，而 `const_iterator` 则相当于 `const T*`。对 `iterator` 或者 `const_iterator` 进行递增可以从容器的头部一直遍历到尾部。`reverse_iterator` 与 `const_reverse_iterator` 则是由容器的尾部反向遍历到容器头部。
 ### Why
`vector<T>` 容器中 `insert` 和 `erase` 函数的原型：
```c++
iterator insert(iterator position, const T& x); 
iterator erase(iterator position);
iterator erase(iterator rangeBegin, iterator rangeEnd); 
```
每个标准容器都提供类似的函数，只不过对于不同的容器类型，返回值有所不同。需要注意的是：这些函数仅接受 `iterator` 类型的参数，所以，`iterator` 与其他的迭代器有所不同。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00185.jpg)
如图所示，从 `iterator` 到 `const_iterator/reverse_iterator` 之间，或者从 `reverse_iterator` 到 `const_reverse_iterator` 之间都存在隐式转换。并且，通过调用 `reverse_iterator` 的 `base` 成员函数，可以将 `reverse_iterator` 转换为 `iterator`。类似地，`const_reverse_iterator` 也可以通过 `base` 成员函数被转换为 `const_iterator`。
从图中还可以看出，没有办法从 `const_iterator` 转换得到 `iterator`，也无法从 `const_reverse_iterator` 得到 `reverse_iterator`。因此 `const_iterator` 或 `const_reverse_iterator` 很难与容器的某些成员函数一起使用，这些成员函数要求 `iterator` 作为参数，却无法从常量类型的迭代器中直接得到 `iterator`。如果需要利用迭代器来指定插入或者删除元素的位置，则常量类型的迭代器往往是没有用处的。
这就是为什么应该尽可能使用 `iterator`，而避免使用 `const` 或者 `reverse` 型的迭代器：
- 有些版本的 `insert` 和 `erase` 函数要求使用 `iterator`。如果需要调用这些函数，必须使用 `iterator`，这个问题在 `C++11` 得到了解决。
- 要想隐式地将一个 `const_iterator` 转换成 `iterator` 是不可能的，第 27 条中讨论的技术并不普遍适用，而且效率也不能保证。
- 从 `reverse_iterator` 转换而来的 `iterator` 在使用之前可能需要相应的调整，第 28 条讨论为什么需要调整以及何时进行调整。
### C++11
在 `C++98` 中，标准库对 `const_iterator` 的支持不是很完整，插入以及删除操作的位置只能由 `iterator` 指定，`const_iterator` 是不被接受的。
下述代码中之所以 `find` 的调用会需要类型转换是因为在 `C++98` 没办法从 `non-const` 容器中获取 `const_iterator`。严格来说类型转换不是必须的，因为用其他方法获取 `const_iterator` 也是可以的（比如可以把 `values` 绑定到 `reference-to-const` 变量上，然后再用这个变量代替 `values`），但不管怎么说，从 `non-const` 容器中获取 `const_iterator` 的做法都有点别扭。而且代码也可能无法编译，因为没有一个可移植的从 `const_iterator` 到 `iterator` 的方法，即使使用 `static_cast` 也不行。
```cpp
typedef std::vector<int>::iterator IterT;               //typedef
typedef std::vector<int>::const_iterator ConstIterT;

std::vector<int> values;
…
ConstIterT ci =
    std::find(static_cast<ConstIterT>(values.begin()),  //cast
              static_cast<ConstIterT>(values.end()),    //cast
              1983);

values.insert(static_cast<IterT>(ci), 1998);    //可能无法通过编译，
                                                //原因见下
```
因此 `const_iterator` 在 `C++98` 中会有很多问题，但所有的这些都在 `C++11` 中改变了，容器的成员函数 `cbegin` 和 `cend` 产出 `const_iterator`，甚至对于 `non-const` 容器也可用，那些之前使用 `iterator` 指示位置（如 `insert` 和 `erase`）的 `STL` 成员函数也可以使用 `const_iterator`。使用 `C++11` `const_iterator` 重写 `C++98` 使用 `iterator` 的代码也稀松平常：
```cpp
std::vector<int> values;                                //和之前一样
…
auto it =                                               //使用cbegin
	std::find(values.cbegin(), values.cend(), 1983);//和cend
values.insert(it, 1998);
```
唯一一个 `C++11` 对于`const_iterator`支持不足的是 `C++11` 只添加了非成员函数 `begin` 和`end`，但是没有添加`cbegin`，`cend`，`rbegin`，`rend`，`crbegin`，`crend`。`C++14` 修订了这个疏漏。下面就是非成员函数 `cbegin` 的实现：
```c++
template <class C>
auto cbegin(const C& container)->decltype(begin(container))
{
    return begin(container);   // 解释见下
}
```
这个 `cbegin` 模板接受任何代表类似容器的数据结构的实参类型 `C`，并且通过 `reference-to-const` 形参 `container` 访问这个实参。如果 `C` 是一个普通的容器类型（如 `vector<int>`），`container` 将会引用一个 `const` 版本的容器（如 `const vector<int>&`）。对 `const` 容器调用非成员函数 `begin` 将得到 `const_iterator`，这个迭代器也是模板要返回的。用这种方法实现的好处是就算容器只提供 `begin` 成员函数不提供 `cbegin` 成员函数也没问题。
### Compare
对于 `iterator` 与 `reverse_iterator` 之间的选择，只需要看从头至尾的遍历，还是从尾至头的遍历，如果选择 `reverse_iterator`，也可以通过 `base` 函数将 `reverse_iterator` `转换为一个iterator`，可能会需要做一个偏移量调整，参见第 28 条。
对于 `iterator` 与 `const_iterator` 之间的选择，即便 `const_iterator` 同样可行，即便并不需要使用迭代器作为参数来调用容器类的任何成员函数，也更应该选择 `iterator`，其中一个理由涉及 `iterator` 与 `const_iterator` 之间的比较：
```cpp
typedef deque<int> IntDeque;
typedef IntDeque::iterator lter;
typedef IntDeque::const_iterator Constlter;

Iter i; 
Constlter ci;
if(i == ci)...
```
这应该不成问题，因为 `iterator` 在比较之前应该被隐式转换成 `const_iterator`，真正的比较应该在两个 `const_iterator` 之间进行。对于设计良好的 `STL` 实现而言，情况确实如此。但对于其他一些实现，这段代码甚至无法通过编译。原因在于，这些 `STL` 实现将 `const_iterator` 的`operator==` 作为一个成员函数而不是一个非成员函数：
```c++
if(ci == i) // 当上面的比较不能编译的时候，这是解决方法
```
不仅在进行相等比较的时候会发生这样的问题，只要在同一个表达式中混用 `iterator` 和 `const_iterator` 或 `reverse_iterator` 和 `const_reverse_iterator`，这样的问题就会出现。例如，当试图在两个随机访问迭代器之间进行减法操作时：
```c++
if(i - ci >= 3) // 如果i与ci之间至少有3个元素
```
如果迭代器的类型不同，完全正确的代码也可能会被拒绝：
```c++
if (ci + 3 <= i) // 当上面的if语句不能编译的时候，这是解决方法
```
而且，这样的变换并不总是正确的，`ci + 3` 也许不是一个有效的迭代器，它可能会超出容器的有效范围。而变换前的表达式中则不存在这样的问题。
避免这种问题的最简单办法是减少混用不同类型的迭代器的机会，尽量使用 `iterator` 来代替`const_iterator`。
## 27：使用 `distance` 和 `advance` 将容器的 `const_iterator` 转换成 `iterator`
### Why
从 `const_iterator` 到 `iterator` 之间不存在隐式转换。包含显式类型转换的代码也不能通过编译，因为 `iterator` 和 `const_iterator` 是完全不同的类。试图将一种类型转换为另一种类型是毫无意义的，`const_cast` 会被拒绝，`reinterpret_cast`、`static_cast` 甚至C语言风格的类型转换也不能胜任。
```cpp
typedef deque<int> IntDeque;
typedef IntDeque::iterator Iter;
typedef IntDeque::const_iterator Constlter; 
Constlter ci;

Iter i(ci); // 编译错误！从 const_cast 到 iterator 没有隐式转换途径
Iter i(const_cast<Iter>(ci)); // 仍然是编译错误！不能将 const_cast 强制转换为 iterator 
```
不过，对于 `vector` 和 `string` 容器来说，以上包含 `const_cast` 的代码也许能够通过编译。因为通常情况下，大多数 `STL` 实现都会利用指针作为 `vector` 和 `string` 容器的迭代器。对于这样的实现而言，`vector<T>::iterator` 和 `vector<T>::const_iterator` 通过类型定义为 `T*` 和`const T*`，`string::iterator` 和 `string::const_iterator` 则分别被定义为 `char*` 和`const char*`。因此，对于这样的实现，从 `const_iterator` 到 `iterator` 的 `const_cast` 转换被最终解释成从 `const T*` 到 `T*` 的转换，因而可以通过编译，而且结果也是正确的。
然而，即便在这样的 `STL` 实现中，`reverse_iterator` 和 `const_reverse_iterator` 仍然是真正的类，所以不能直接将 `const_reverse_iterator` 通过 `const_cast` 强制转换成 `reverse_iterator`。因此即使对于 `vector` 和 `string` 容器，将 `const` 迭代器强制转换成迭代器也是不可取的，因为这些代码的移植性将是一个问题。
### How
如果得到一个 `const_iterator` 并且可以访问它所在的容器，那么这里有一条安全的、可移植的途径能得到对应的 `iterator`，而且用不着涉及类型系统的强制转换：
```cpp
typedef deque<int> IntDeque;
typedef IntDeque::iterator Iter;
typedef IntDeque::const_iterator ConstIter; 

IntDeque d;
ConstIter ci;
Iter i(d.begin()); // 使i指向d的起始位置 
advance(i, distance(i, ci)); // 移动i，使它指向ci所指的位置
// 下面说明了为什么需要修改才能编译
```
为得到一个与 `const_iterator` 指向同一位置的 `iterator`，首先创建一个新的 `iterator` 指向容器的起始位置，然后取得 `const_iterator` 距离容器起始位置的偏移量，并将 `iterator` 向前移动相同的偏移量即可。这项任务是通过 `<iterator>` 中声明的两个函数模板来实现的：`distance` 用以取得两个指向同一容器的迭代器之间的距离，`advance` 则用于将一个迭代器移动指定的距离。如果 `i` 和 `ci` 指向同一个容器，则 `advance(i,distance(i,ci))` 会使 `i` 和 `ci` 指向容器中相同的位置。但它并不能通过编译。下述是 `distance` 的声明：
```c++
template<typename InputIterator>
typename iterator_traits<InputIterator>::difference_type 
distance(InputIterator first, InputIterator last);

advance(i, distance(i, ci)); // 移动i，使它指向ci所指的位置
```
当编译器看到一个 `distance` 调用的时候，必须根据该调用的参数来推断出 `InputIterator` 所代表的类型。此处 `i` 和 `ci` 分别是传递给 `distance` 函数的两个参数。`i` 的类型为 `Iter`，是 `deque<int>::iterator`。对于编译器而言，这意味着 `distance` 调用中的 `InputIterator` 是 `deque<int>::iterator`。
然而，`ci` 的类型是 `ConstIter`，是 `deque<int>::const_iterator`，这意味着 `InputIterator` 又是 `deque<int>::const_iterator` 类型。而要让 `InputIterator` 同时代表两种不同的类型是不可能的，所以 `distance` 调用会失败。要想让 `distance` 调用顺利地通过编译，需要排除这里的二义性。最简单的办法是显式地指明 `distance` 所使用的类型参数，从而避免让编译器来推断该类型参数：
```c++
advance(i, distance<ConstIter>(i, ci)); // 将i和ci都当作 const_iterator 计算出它们之间的距离，然后将i移动这段距离
```
这项技术的效率取决于所使用的迭代器。对于随机访问的迭代器而言，它是一个常数时间的操作，对于双向迭代，它是一个线性时间的操作。这种从 `const_iterator` 获得 `iterator` 的转换技术可能需要线性时间的代价，并且需要访问 `const_iterator` 所属的容器，否则可能就无法完成。
## 28：由 `reverse_iterator` 的 `base()` 成员函数所产生的 `iterator` 
下面这段代码把数值 1 到 5 放进一个 `vector` 中，然后将一个 `reverse_iterator` 指向数值 3，并且通过其 `base()` 函数初始化一个 `iterator`：
```cpp
vector<int> v;
v.reserve(5);
for(int i = 1; i <= 5; ++i) {
v.push_back(i);
vector<int>::reverse_iterator ri = find(v.rbegin(), v.rend(), 3); // 使ri指向3
vector<int>::iterator i(ri.base()); // 使 i 与 ri 的基相同
```
在执行了上述代码之后，该 `vector` 和相应迭代器的状态如下图所示：
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00197.jpg)
如图所示，在 `reverse_iterator` 与对应的由 `base()` 产生的 `iterator` 之间存在偏移，在 `rbegin()` 和 `rend()` 与对应的 `begin()` 和 `end()` 之间也存在偏移。
### Insert
对于上面的例子，如果希望在 `ri` 指定的位置上插入一个新的元素，那么就不能直接这样做，因为 `insert` 函数不接受 `reverse_iterator` 作为参数。如果要删除 `ri` 所指的元素，则也存在同样的问题。为执行插入或删除操作，必须首先通过 `base` 成员函数将 `reverse_iterator` 转换成 `iterator`，然后用 `iterator` 来完成插入或删除。
假设要在 `ri` 所指定的位置上插入一个新的值为 99 的元素到 `v` 中，在上图中 `ri` 遍历 `vector` 的顺序是自右向左，而 `insert` 操作会将新元素插入到其参数所指定位置的元素的前面。因此，插入操作之后，99 按照逆向的遍历顺序将会出现在 3 的前面。
在插入操作之前，`ri` 指向元素 `3`，而通过 `base()` 得到的 `i` 指向元素 4。考虑到 `insert` 与遍历方向的关系，直接使用 `i` 进行 `insert` 操作，其结果与用 `ri` 来指定插入位置得到的结果完全相同。因此，在一个 `reverse_iterator ri` 指定的位置上插入新元素，则只需在 `ri.base()` 位置处插入元素即可，对于插入操作而言，`ri` 和 `ri.base()` 是等价的，`ri.base()` 是真正与 `ri` 对应的 `iterator`。
### erase
如果要删除 `ri` 所指的元素，因为 `i` 与 `ri` 分别指向不同的位置，因此不能直接使用 `i`，而是改为删除 `i` 前面的元素。因此，如果要在一个 `reverse_iterator ri` 指定的位置上删除一个元素，则需要在 `ri.base()` 前面的位置上执行删除操作。对于删除操作而言，`ri` 和 `ri.base()` 是不等价的，`ri.base()` 不是与 `ri` 对应的 `iterator`。
```c++
vector <int> v;
...// 同上，插入1到5 
vector<int>::reverse_iterator ri = find(v.rbegin(), v.rend(), 3); 
// 试图删除 ri.base() 前面位置上的元素，对于 vector/string 往往编译通不过
v.erase(--ri.base()); 
```
这段代码并不存在设计问题，对于除 `vector` 和 `string` 之外的所有标准容器，这段代码都能够正常工作。但对于 `vector` 和 `string` 的许多实现，它无法通过编译。这是因为在这样的实现中，`iterator/const_iterator` 是以内置指针的方式来实现的，所以，`ri.base()` 的结果是一个指针。
`C` 和 `C++` 都规定从函数返回的指针不应该被修改，所以，如果 `STL` 的实现中 `string` 和 `vector` 的 `iterator` 是指针的话，那么，类似 `--ri.base()` 这样的表达式就无法通过编译。因此，出于通用性和可移植性的考虑，要想在一个 `reverse_iterator` 指定的位置上删除一个元素，应该避免直接修改 `base()` 的返回值。因此先递增 `reverse_iterator`，然后再调用 `base()` 函数：
```c++
v.erase((++ri).base());
```
因为这种方法对于所有的标准容器都是适用的，所以，当需要删除一个由 `reverse_iterator` 指定的元素时，应该首选这种技术。
## 29：对于逐个字符的输入考虑使用 `istreambuf_iterator`
假如想把一个文本文件的内容复制到一个 `string` 对象中，以下的代码看上去是一种合理的解决方案：
```c++
ifstream inputFile("interestingData.txt");
string fileData((istream_iterator<char>(inputFile)), istream_iterator<char>()); 
```
但这段代码并没有把文件中的空白字符复制到 `string` 对象中。因为 `istream_iterator` 使用 `operator>>` 函数来完成实际的读操作，而默认情况下 `operator>>` 函数会跳过空白字符。假定希望保留空白字符，那么所需要做的工作是改写这种默认行为，只要清除输入流的 `skipws` 标志即可：
```c++
ifstream inputFile("interestingData.txt");
inputFile.unsetf(ios::skipws); // 禁止忽略inputFile中的空格 
string fileData((istream_iterator<char>(inputFile)), istream_iterator<char>()); 
```
然而，整个复制过程远不及希望的那般快。`istream_iterator` 内部使用的 `operator>>` 函数实际上执行了格式化的输入，意味着每调用一次 `operator>>` 操作符，它都要执行许多附加的操作：一个内部的 `sentry` 对象的构造和析构，`sentry` 是在调用 `operator>>` 的过程中进行设置和清理行为的特殊 `iostream` 对象、检查那些可能会影响其行为的流标志，比如 `skipws`、检查所有可能发生的读取错误，如果遇到错误的话，还需要检查输入流的异常屏蔽标志以决定是否抛出相应的异常。
这些操作对于格式化的输入来说是非常重要的行为，但如果只是想从输入流中读出下一个字符的话，它们就显得有点多余。有一种更为有效的途径，那就是使用 `STL` 中的 `istreambuf_iterator`。
使用方法与 `istream_iterator` 大致相同，但是 `istream_iterator<char>` 对象使用 `operator>>` 从输入流中读取单个字符，而 `istreambuf_iterator<char>` 则直接从流的缓冲区中读取下一个字符，并且`istreambuf_iterator<char>` 对象从一个输入流 `istream s` 中读取下一个字符的操作是通过 `s.rdbuf()->sgetc()` 来完成的：
```c++
ifstream inputFile("interestingData.txt");
string fileData((istreambuf_iterator<char>(inputFile)), istreambuf_iterator<char>());
```
这一次用不着清除输入流的 `skipws` 标志，因为 istreambuf_iterator 不会跳过任何字符，它只是简单地取回流缓冲区中的下一个字符，而不管它们是什么字符。
如果需要从一个输入流中逐个读取字符，那么就不必使用格式化输入，如果关心的是读取流的时间开销，那么使用 `istreambuf_iterator` 可以获得明显的性能改善。对于非格式化的逐个字符输入过程，总是应该考虑使用 `istreambuf_iterator`。同样地，对于非格式化的逐个字符输出过程，也应该考虑使用 `ostreambuf_iterator`。
# Algorithm
## 30：确保目标区间足够大
### Insert
当有新的对象被加入进来的时候， `STL` 容器会自动扩充存储空间以容纳这些对象。但有时会出现问题：
```c++
int transmogrify(int x); // 该函数根据x生成一个新的值
vector<int> values; // 在values中存入一些值
vector<int> results;
transform(values.begin(), values.end(), results.end(), transmogrify); 
// 将transmogrify作用在values的每个对象上，并把返回值追加在results的末尾。 这段代码有一个错误！
```
在这个例子中，`transform` 对 `values` 的每个元素调用 `transmogrify`，并且将结果写到从 `results.end()` 开始的目标区间中。与其他使用目标区间的算法类似，`transform` 通过赋值操作将结果写到目标区间中。
于是，`transform` 首先以 `values[0]` 为参数调用 `transmogrify`，并将结果赋给 `*result.end()`。然后，再以 `values[1]` 为参数调用 `transmogrify`，并将结果赋给 `*(results.end()+1)`。但在 `*results.end()` 中并没有对象，`*(results.end()+1）`就更没有对象。这种 `transform` 调用是错误的，因为它导致了对无效对象的赋值操作。
上面的例子，会在算法执行过程中增大目标区间，因此需要使用插入型迭代器， 此处通过调用 `back_inserter` 生成一个迭代器来指定目标区间的起始位置，将 `transform` 的结果添加到 `results` 容器的末尾：
```c++
vector<int> results;
// 将transmogrify作用在values的每个对象上，并将返回值插入到results的末尾 
transform(values.begin(), values.end(), back_inserter(results), transmogrify);
```
在内部，`back_inserter` 返回的迭代器将使得 `push_back` 被调用，所以 `back_inserter` 可适用于所有提供 `push_back` 方法的容器。如果需要让一个算法在容器的头部而不是尾部插入对象，则可以使用 `front_inserter`。`front_inserter` 在内部利用 `push_front`，所以 `front_inserter` 仅适用于那些提供了 `push_front` 成员函数的容器（如 `deque` 和 `list` ）。
```c++
list<int> results;
// 将transform的结果以逆向顺序插入到results的头部 
transform(values.begin(), values.end(), front_inserter(results), transmogrity);
```
由于 `front_inserter` 将通过 `push_front` 来加入每个对象，所以这些对象在 `results` 中的顺序将会与在 `values` 中的顺序相反。这正是为什么 `front_inserter` 不如 `back_inserter` 常用的原因之一。此外，`vector` 并没有提供 `push_front` 方法。
如果希望 `transform` 把输出结果存放在 `results` 的前端，同时保留它们在 `values` 中原有的顺序，那么只需按相反顺序遍历 `values` 即可：
```c++
list<int> results;
// 将transform的结果插入到 results的头部，并保持对象的相对顺序
transform(values.rbegin(), values.rend(), front_inserter(results), transmogrify);

vector<int> values;
vector<int> results; // 同前，只是在调用transform之前，先在results中加入了一些数据
// 将transmogrify的结果插入到results 容器的中间位置上
transform(values.begin(), values.end(), inserter(results, results.begin() + results.size() / 2), transmogrify);
```
### Reserve
无论选择使用 `back_inserter`、`front_inserter` 还是 `inserter`，算法的结果都会被逐个地插入到目标区间中。第 5 条解释这种插入方式对于连续内存的容器 `vector`、`string` 和 `deque` 效率并不理想。但是，如果该算法执行的是插入操作，则第 5 条中建议的方案（使用区间成员函数）并不适用。在本例中，`transform` 总是逐个地将结果写到目标区间中，无法改变这种行为方式。
如果插入操作的目标容器是 `vector` 或者 `string` ，则可以遵从第 14 条的建议，预先调用 `reserve`，从而可以提高插入操作的性能。在每次执行插入操作的时候，仍然需要承受因移动元素而带来的开销，但这样做至少可以避免因重新分配容器内存而带来的开销。
当使用 `reserve` 提高一序列连续插入操作的效率的时候，`reserve` 只是增加容器的容量，而容器的大小并未改变。当一个算法需要向 `vector` 或者 `string` 中加入新元素的时候，即使已经调用`reserve`，也必须使用插入型的迭代器：
```c++
vector<int> values;
vector<int> results;
results.reserve(results.size() + values.size()); // 只是增加容器的容量，未初始化
transform(values.begin(), values.end(), results.end(), transmogrify); // 变换的结果会被写入到尚未初始化的内存，结果将是不确定的
```
由于赋值操作总是在两个对象之间而不是在一个对象与一个未初始化的内存块之间进行的，所以一般情况下，这段代码在运行时将会失败。即使凑巧能够完成赋值操作，`results` 也不会知道 `transform` 在它尚未使用的内存空间中创建新的对象。也就是说，`results` 容器的大小在 `transform` 调用的前后并不会改变，并且，它的 `end` 迭代器仍然指向 `transform` 被调用之前的位置。
由此可见，使用 `reserve` 但同时又不使用一个插入型的迭代器将会导致算法内部不确定的行为，并且破坏容器的数据一致性。只要同时使用 `reserve` 和插入型迭代器就可以正确地解决上述问题：
```c++
vector<int> values;
vector<int> results;
results.reserve(results.size() + values.size());
transform(values.begin(), values.end(), back_inserter(results), transmogrify);
```
### Resize
有时会选择覆盖容器中已有的元素，而不是插入新的元素。在这种情况下，就不需要插入型的迭代器了，但仍然要确保目标区间足以容纳算法的结果。假设希望 `transform` 覆盖 `results` 容器中已有的元素，那么就需要确保 `results` 中已有的元素至少和 `values` 中的元素一样多。否则，就必须使用 `resize` 来保证这一点：
```c++
vector<int> values; 
vector<int> results;
if (result.size() < values.size()) results.resize(values.size()); // 确保results至少和values一样大 
transform(values.begin(), values.end(), results.begin(), transmogrify); // 覆盖 results 中的前 values.size 个元素 
```
也可以先清空 `results`，然后按通常的方式使用一个插入型迭代器：
```c++
vector<int> values;
vector<int> results;
results.reserve(results.size() + values.size());
// 将变化的结果加入到results的尾部，同时避免内存的重新分配 
transform(values.begin(), values.end(), back_inserter(results), transmogrify);
```
无论何时，如果所使用的算法需要指定一个目标区间，那么必须确保目标区间足够大，或者确保它会随着算法的运行而增大。
## 31：了解各种与排序有关的选择
### Nth_element
`nth_element` 用于排序一个区间，它使得位置 n 上的元素正好是全排序情况下的第 `n` 个元素，当 `nth_element` 返回的时候，所有按全排序规则排在位置 `n` 之前的元素也都被排在位置 `n` 之前，而所有按全排序规则排在位置 `n` 之后的元素则都被排在位置 `n` 之后。
当只需要部分排序时，可以使用 `partial_sort`：
```c++
bool qualityCompare(const Widget& Ihs, const Widget&rhs) {
    // 返回lhs的质量是否好于rhs的质量的结果
} // 将质量最好的20个元素顺序放在widgets的前 20 个位置上 
partial_sort(widgets.begin(), widgets.begin() + 20, widgets.end(), qualityCompare);
```
当只需要不要求排序排序的部分时，使用 `nth_element`：
```c++
// 将最好的20个元素放在widgets的前部，但并不关心它们的具体排列顺序
nth_element(widgets.begin(), widgets.begin() + 19, widgets.end(), qualityCompare);
```
`partial_sort` 使用第 1 个和第 2 个迭代器参数指明一段需要排序的区间，例子中 `widgets.begin() + 20` 实际指向容器中第 21 个元素，而 `nth_element` 则使用第 2 个参数标识出容器中的某个特定位置，例子中的 `widgets.begin() + 19`  实际指向容器中的第 20 个元素。
在稳定的排序算法中，如果区间中的两个元素有等价的值，那么在排序之后，它们的相对位置不会发生变化。而非稳定的排序算法并不保证这一点。
`partial_sort`、`nth_element` 和 `sort` 都属于非稳定的排序算法，但是 `stable_sort` 可以提供稳定排序特性。`STL` 中没有与 `partial_sort` 和 `nth_element` 功能相同的稳定排序算法。
`nth_element` 除可以用来找到排名在前的 `n` 个元素以外，还可以用来找到一个区间的中间值，或者找到某个特定百分比上的值：
```c++
vector<Widget>::iterator begin(widgets.begin()); // 两个便捷变量，分别代表widgets的begin和end迭代器
vector<Widget>::iterator end(widgets.end());

vector<Widget>::iterator goalPosition = begin + widgets.size() / 2; 
nth_element(begin, goalPosition, end, qualityCompare); // 找到widgets的中间质量值

vector<Widget>::size_type goalOffset = 0.25 * widgets.size();
nth_element(begin, begin + goalOffset, end, qualityCompare); // 找到区间中具有75％质量的元素
```
### Partition
假设所需要的不是质量最好的 20 个 `Widget`，而是所有的一级品和二级品。`partition` 算法可以把所有满足某个特定条件的元素放在区间的前部。：
```c++
bool hasAcceptableQuality(const Widget& w) {} // 判断w的质量值是否为2或者更好
// 将满足条件所有元素移到前部，然后返回一个迭代器，指向第一个不满足条件的 Widget 
vector<Widget>::iterator goodEnd = partition(widgets.begin(), widgets.end(), hasAcceptableQuality);
```
在 `partition` 调用之后，所有的一级品和二级品都被放在从 `widgets.begin()` 到 `goodEnd` 之间的区间中，其余的低质量 `Widget` 则被放在从 `goodEnd` 到 `widgets.end()` 之间的区间中。如果对于相同质量级别的 `Widget`，保持它们在 `widgets` 中的相对位置关系非常重要，那么就可以使用 `stable_partition` 替代 `partition`。
### List
`sort`、`stable_sort`、`partial_sort` 和 `nth_element` 都要求随机访问迭代器，所以这些算法只能被应用于 `vector`、`string`、`deque` 和数组。而 `partition` 和 `stable_partition` 只要求双向迭代器就能完成工作。所以，对于所有的标准序列容器，都可以使用 `partition` 或者 `stable_partition`。对标准关联容器中的元素进行排序并没有实际意义，因为这样的容器总是使用比较函数来维护内部元素的有序性。
`list` 是唯一需要排序却无法使用这些排序算法的容器，为此，`list` 特别提供 sort 成员函数，并且是稳定排序的。但是，如果需要对 `list` 中的对象使用 `partial_sort` 或者 `nth_element` 算法的话，就只能通过间接途径来完成。
一种间接做法是，将 `list` 中的元素复制到一个提供随机访问迭代器的容器中，然后对该容器执行所期望的算法。另一种间接做法是，先创建一个 `list::iterator` 的容器，再对该容器执行相应的算法，然后通过其中的迭代器访问 `list` 的元素。第三种方法是利用一个包含迭代器的有序容器中的信息，通过反复地调用 `splice` 成员函数，将 `list` 中的元素调整到期望的目标位置。
### Conclusion
来总结一下所有这些排序选择：
- 如果需要对 `vector`、`string`、`deque` 或者数组中的元素执行一次完全排序，那么可以使用 `sort` 或者 `stable_sort`。
- 如果有一个 `vector`、`string`、`deque` 或者数组，并且只需要对等价性最前面的 `n` 个元素进行排序，那么可以使用 `partial_sort`。
- 如果有一个 `vector`、`string`、`deque` 或者数组，并且需要找到第 `n` 个位置上的元素，或者需要找到等价性最前面的 `n` 个元素但又不必对这 `n` 个元素进行排序，那么使用 `nth_element`。
- 如果需要将一个标准序列容器中的元素按照是否满足某个特定的条件区分开来，那么，使用`partition` 和 `stable_partition`。
- 如果数据在一个 `list` 中，仍然可以直接调用 `partition` 和 `stable_partition` 算法，可以用 `list::sort` 来替代 `sort` 和 `stable_sort` 算法。但是，如果需要获得 `partial_sort` 或 `nth_element` 算法的效果，那么可以有一些间接的途径来完成。
## 32：在 `remove` 这一类算法之后调用 `erase`
下面是 `remove` 的声明：
```c++
template<class Forwardlterator, class T>
Forwardlterator remove(Forwardlterator first, Forwardlteraotr last, const T& value);
```
`remove` 需要一对迭代器来指定所要进行操作的元素区间，它并不接受容器作为参数，所以并不知道这些元素被存放在哪个容器中，并且也不可能推断出是什么容器，因为无法从迭代器推知对应的容器类型。
因为从容器中删除元素的唯一方法是调用该容器的成员函数，而 `remove` 并不知道它操作的元素所在的容器，就不可能调用它的成员函数来完成真正的删除功能，所以 `remove` 不可能从容器中删除元素，因此用 `remove` 从容器中删除元素，容器中的元素数目不会因此而减少。
```c++
vector<int> v;
for(int i = 1; i <= 10; ++i) v.push_back(i);
cout << v.size();
v[3] = v[5] = v[9] = 99;
remove(v.begin(), v.end(), 99); // 删除所有值等于99的元素
cout << v.size(); // 仍然输出10！ 
```
实际上，`remove` 移动区间中的元素，其结果是，不用被删除的元素保持原来的相对顺序移到区间的前部，返回的一个迭代器指向最后一个不用被删除的元素之后的元素，这个返回值相当于该区间新的逻辑结尾。
如果将 `remove` 的返回值保存在一个新的迭代器对象 `newEnd` 中，那么，在 `remove` 调用之后，不用被删除的元素放在 `v` 的 `v.begin()` 和 `newEnd` 之间，需要被删除的元素放在 `newEnd` 和 `v.end()` 之间。`remove` 并没有改变区间中元素的顺序，它只是使所有要被删除的元素放在尾部，不用被删除的元素放在前部。尽管 `C++` 标准并没有强调，但一般情况下在新的逻辑结尾后面的元素仍然保留其旧的值。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00222.jpg)
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00224.jpg)
调用 `remove` 之后，`v` 的布局应该如下：
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00225.jpg)
通常来说，当调用 remove 以后，从区间中被删除的那些元素可能在也可能不在区间中。在内部，r  `remove` 遍历整个区间，用需要保留的元素的值覆盖掉那些要被删除的元素的值，这种覆盖是通过对那些需要被覆盖的元素的赋值来完成的，因此`v` 中两个原来的 `99` 值不见了，而另一个 `99` 还在。
为删除这些元素，只需调用区间形式的 erase，并将这迭代器传递给它。因为 `remove` 返回的迭代器正是新的逻辑结尾：
```c++
vector<int> v;
v.erase(remove(v.begin(), v.end(), 99), v.end()); // 真正删除所有值等于99的元素 
cout << v.size(); // 现在返回 7
```
`remove` 并不是唯一一个适用于这种情形的算法，其他还有两个属于 `remove` 类的算法：`remove_if`和 `unique`。
把 `remove` 返回的迭代器作为区间形式的 `erase` 的第一个实参是习惯用法。因此它们被合并起来融入到 `list` 的 `remove` 成员函数中。这是 `STL` 中唯一一个名为 `remove` 并且确实删除容器中元素的函数：
```c++
list<int> li; 
...// 加入一些值 
li.remove(99); // 加入一些值删除所有值为99的元素，因为是真正的删除，所以li的大小会改变
```
调用这个 `remove` 函数其实是 `STL` 中一个不一致的地方。在关联容器中类似的函数被称为 `erase`。照理来说，`list` 的 `remove` 也应该被称为 `erase`。然而它并没有被命名为 `erase`，所以只好习惯这种不一致。`unique` 与 `list` 的结合也与 `remove` 的情形类似。如同 `list::remove` 会真正删除元素一样， `list::unique` 也会真正删除元素。
## 33：对包含指针的容器使用 remove
假设现在获得一些动态分配的 `Widget`，其中每一个 `Widget` 可能已经被验证过了，然后把结果指针存放在一个矢量中：
```c++
class Widget {
public:
	bool isCertified() const;
};
vector<Widget*> v;
v.push_back(new Widget);
```
在对 `v` 做一些工作之后，决定剔除那些没有被验证过的 `Widget`：
```c++
// 第 43 条：应该尽量使用算法而不是编写显式的循环
// 删除那些指向未被验证过的Widget对象的指针
v.erase(remove_if(v.begin(), v.end(), 
                  not1(mem_fun(&Widget::isCertified))), v.end()); 
```
由于第 7 条中关于删除容器中的指针并不能删除该指针所指的对象的讨论，这的确值得担心。但对于本例来讲，在 `erase` 被调用之前，很可能已经造成资源泄漏了。首先要担心的是 `remove_if` 调用。假设在调用 `remove_if` 之前 `v` 的布局如下图所示，在图中已经标出那些未被验证过的 `Widget`。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00231.jpg)
在调用 `remove_if` 以后，`v` 往往应该如下图所示，图中也指明 `remove_if` 返回的迭代器。
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00232.jpg)
要被删除的指针，即指向未被验证的 `Widget B` 和 `Widget C` 的指针已经被那些不会被删除的指针覆盖。没有任何指针再指向 `Widget B` 和 `Widget C`，所以它们永远不会被删除，它们所占用的内存和其他资源永远不会被释放。一旦 `remove_if` 和 `erase` 都返回之后，则情形如下：
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00233.jpg)
这使得资源泄露的情况更加明显，因此当容器中存放的是指向动态分配的对象的指针的时候，应该避免使用 `remove` 和类似的算法 `remove_if` 和 `unique`。很多情况下 `partition` 算法是个不错的选择。
如果无法避免对这种容器使用 `remove`，那么一种可以消除该问题的做法是，在进行 `erase-remove` 习惯用法之前，先把那些指向未被验证过的 `Widget` 的指针删除并置成空，然后清除该容器中所有的空指针：
```c++
void delAndNullifyUncertified(Widget*& pWidget) { 
    If (!pWidget->isCertified()) { // 如果*pWidget是一个未被验证的Widget，则删除该指针并把它置成空
        delete pWidget;
        pWidget = nullptr;
    }
}
for_each(v.begin(), v.end(), delAndNullifyUncertified); // 将所有指向未被验证的Widget对象的指针删除并置成空
v.erase(remove(v.begin(), v.end(), static_cast<Widget*>(nullptr)), v.end()); // 删除v中的空指针；必须转换，这样才能正确推断出remove的第3个参数的类型
```
这种做法的前提是，不希望该矢量中保留任何空指针。如果希望它保留空指针的话，可能只好写循环来删除那些满足条件的指针。
如果容器中存放的不是普通指针，而是具有引用计数功能的智能指针，那么与 `remove` 相关的困难就不再存在。可以直接使用 `erase-remove` 习惯用法：
```c++
template<typename T> class RCSP{...};
typedef RCSP<Widget> RCSPW;

vector<RCSPW> v;
v.push_back(RCSPW(new Widget));
v.erase(remove_if(v.begin(), v.end(), not1(mem_fun(&Widget::isCertified))), v.end());
```
为使以上的代码能够工作，编译器必须能够把智能指针类型 `RCSP<Widget>` 隐式地转换为对应的内置指针类型 `Widget*`。这是因为，容器中存放的是智能指针，而被调用的成员函数 `Widget::isCertified` 必须通过内置指针才能进行。
无论如何处理那些存放动态分配的指针的容器，本条款的指导原则是一致的：对包含指针的容器使用 `remove` 类算法时需要特别警惕。如果你不留意这条警告的话，其后果就是资源泄漏。
## 34：要求使用排序的区间作为参数的算法
并非所有的算法都可以应用于任何区间。`remove` 算法要求单向迭代器并且要求可以通过这些迭代器向容器中的对象赋值。所以，它不能用于由输入迭代器指定的区间，也不适用于 `map` 或 `multimap`，同样不适用于某些 `set` 和 `mutliset` 的实现（见第22条）。同样地，很多排序算法要求随机访问迭代器，所以对于 `list` 的元素不可能调用这些算法。
有些算法要求排序的区间，即区间中的值是排过序的。有些算法既可以与排序的区间一起工作，也可以与未排序的区间一起工作，但是当它们作用在排序的区间上时，算法会更加有效：
```c
// 要求排序区间的 STL 算法：
binary_search lower_bound upper_bound equal_range 
set_union set_intersection set_difference set_symmetric_difference 
merge inplace_merge 
includes

// 并不一定要求排序的区间，通常情况下会与排序区间一起使用：
unique unique_copy
```
第一行中用于查找的算法要求排序的区间，因为它们用二分法查找数据，这些算法承诺对数时间的查找效率，但其前提条件是，必须提供已经按顺序排好的数据并且接受随机访问迭代器。如果所提供的迭代器不具备随机访问的能力，那么，尽管比较次数仍然是区间元素个数的对数，但它们的执行过程却需要线性时间。这是因为，由于缺少执行迭代器算术的能力，所以在查找过程中它们需要线性时间以便从区间的一处移动到另一处。
第二行的算法提供线性时间效率的集合操作，也要求排序的区间，满足这个条件，才能在线性时间内完成工作。
`merge` 和 `inplace_merge` 实际上实现合并和排序的联合操作：读入两个排序的区间，然后合并成一个新的排序区间，其中包含原来两个区间中的所有元素，只有源区间已经排过序，才具有线性时间的性能。
最后一个要求排序源区间的算法是 `includes`，它可用来判断一个区间中的所有对象是否都在另一个区间中，只有源区间已经排过序，才具有线性时间的性能。
`unique` 和 `unique_copy` 即使对于未排序的区间也有很好的行为，但如果想让 `unique` 删除区间中所有重复的元素，那么就必须保证所有相等的元素都是连续存放的，这正是排序操作所要达到的目标之一。在实践中，`unique` 通常用于删除一个区间中的所有重复值，所以，总是要确保传给 `unique` 的区间是排序的。此外，`unique` 使用与 `remove` 类似的办法来删除区间中的元素，而并非真正意义上的删除。
上述除 `unique` 和 `unique_copy` 以外的算法，均使用等价性来判断两个对象是否相同，这与标准的关联容器一致。而 `unique` 和 `unique_copy` 在默认情况下使用相等来判断两个对象是否相同，因此需给这些算法传递一个其他的预定义比较函数作为两个值等价的定义。
因为 `STL` 允许为排序操作选择特定的比较函数，所以，不同的区间可能有不同的排序方式。如果为一个传入比较函数参数的算法提供一个排序的区间，那么，一定要保证传递的比较函数与这个排序区间所用的比较函数有一致的行为。下面这个例子说明了不一致的情形：
```c++
vector <int> v;
sort(v.begin(), v.end(), greater<int>()); 
bool a5Exists = binary_search(v.begin(), v.end(), 5); ！
```
`binary_search` 默认情况下假设区间是用按升序排列，但这个例子中的矢量是按降序排列的。当调用 `binary_search` 的时候，区间的排序方式与算法期望的排序方式不一致的话，不可能得到正确的结果：
```c++
bool a5Exists = binary_search(v.begin(), v.end(), 5, greater<int>()); // 在数组中查找5，但假设这个区间是升序排列的！
```
## 35：通过 `mismatch` 或 `lexicographical_compare` 实现忽略大小写的字符串比较
### mismatch
当需要忽略大小写的字符串比较功能的时候，往往需要两个不同的调用接口：一个与 `strcmp` 很类似，返回一个负数、零或者正数，另一个与 `operator<` 很类似，返回 `true` 或者 `false`。下面的字符比较函数是一个简化的方案：
```c++
int ciCharCompare(char c1, char c2) {
    int Ic1 = tolower(static_cast<unsigned char>(c1));
    int Ic2 = tolower(static_cast<unsigned char>(c2));
    if (lc1 < lc2) return -1;
    if (lc1 > lc2) return 1; 
    return 0;
}
```
与 `strcmp` 不同的是，`ciCharCompare` 在比较之前把两个参数都转换为小写形式，这就使得该函数成为忽略大小写的比较函数。
如同 `<cctype>` 中的很多函数一样，`tolower` 的参数和返回值都是 `int`，但除非该 `int` 值是 `EOF`，否则它的值必须可以用 `unsigned char` 来表示。在 `C` 和` C++` 中，`char` 可能是有符号的，也可能是无符号的。当 `char` 有符号时，确保它的值可以用 `unsigned char` 来表达的唯一办法是，在调用 `tolower` 之前将它强制转换成一个 `unsigned char`。因此上述代码中使用 `static_cast` 并且用 `int` 而不是 `char` 来保存 `tolower` 的返回值。
`mismatch` 可以标识出两个区间中第一个对应值不相同的位置，如果两个字符串的长度不一样，那么必须把短的字符串作为第一个区间传入。因此，把实际的比较工作放到一个名为 `ciStringCompareImpl` 的函数中，并且让字符串比较函数 `ciStringCompare` 只是确保传入的实参有正确的顺序。
```c++
int ciStringCompareImpl(const string& s1, const string& s2) {
    typedef pair<string::const_iterator, string::const_iterator> PSCI;
    // mismatch返回一对迭代器，指向这两个区间中对应字符第一次比较失败的位置
    PSCI p = mismatch(s1.begin(), s1.end(), s2.begin(), not2(ptr_fun(ciCharCompare)));
    if(p.first == s1.end()) { // s1 在不匹配的位置没有字符
        if(p.second == s2.end()) return 0; // s2 在不匹配的位置也没有字符，说明二者相等
        else return -1;  // 否则 s1 比 s2 短
    }
    // 字符串之间的关系和这两个不匹配的字符之间的关系相同
    return ciCharCompare(*p.first, *p.second);
}

int ciStringCompare(const string& s1, const string& s2) {
    if (s1.size() <= s2.size()) return ciStringCompareImpl(s1, s2);
    // mismatch 假定 s1 一定小于 s2，因此交换顺序后对结果需要取反，因为实际上没有小于
    else return -ciStringCompareImpl(s2, s1);
}
```
`not2(ptr_fun(ciCharCompare))` 负责在两个字符匹配时返回 `true`，当判别式返回 `false` 时 `mismatch` 会停下。如果直接使用 `ciCharCompare` 作为 `mismatch` 的判别式，那么 `C++` 将会把它的返回值转换成 `bool`，`0` 转换成 `bool` 的等价值是 `false`，这和想要的结果完全相反，因此需要 `not2`。
### Lexicographical_compare
`lexicographical_compare` 是 `strcmp` 的一个泛化版本。不过 `strcmp` 只能与字符数组一起工作，而 `lexicographical_compare` 则可以与任何类型的值的区间一起工作。而且，`strcmp` 总是通过比较两个字符来判断它们的关系是相等、小于还是大于，而 `lexicographical_compare` 则可以接受一个判别式，由该判别式来决定两个值是否满足一个用户自定义的准则。
```c++
bool ciCharLess(char c1, char c2) { // 返回在忽略大小写的情况下，c1是否在c2之前
    return tolower(static_cast<unsigned char>(c1)) < tolower(static_cast<unsigned char>(c2)); // 第46条将说明为什么用函数对象更适合
}
bool ciStringCompare(const string& s1, const string& s2) {
    return lexicographical_compare(s1.begin(), s1.end(), s2.begin(), s2.end(), ciCharLess);
}
```
在上面的调用中，`lexicographical_compare` 根据 `ciCharLess` 的结果，找出 `s1` 和 `s2` 中字符不相同的第一个位置。
如果在某个位置上，`ciCharLess` 返回 `true`，则 `lexicographical_compare` 就得出结论，如果在这个位置上，第一个字符串中的字符比第二个字符串中相应的字符更靠前，则第一个字符串比第二个字符串靠前，即在它的前面。
如果在找到不同的值之前，第一个区间就已经结束，那么 `lexicographical_compare` 将返回`true`，一个前缀比任何一个以它为前缀的区间更靠前。
### Strcmpi
忽略大小写的字符串比较函数也普遍存在于标准 C 库的非标准扩展中，如果不考虑移植性、国际化支持，并且字符串中不会包含内嵌的空字符，那么实现一个忽略大小写的字符串比较函数最容易的方法根本就不需要使用 `STL` 。相反，可以把两个 `string` 转化成` const char*` 指针，然后调用 `strcmpi`：
```c++
int ciSstringCompare(const string& s1, const string& s2) {
    return stricmp(s1.c_str(), s2.c_str());
}
```
`strcmp/strcmpi` 通常是被优化过的，它们在长字符串的处理上一般要比通用算法 `mismatch` 和 `lexicographical_compare` 快得多。
## 36：`copy_if` 算法的正确实现
`STL` 中没有 `copy_if`，如果想简单地复制区间中满足某个判别式的所有元素，那就需要自己来实现，下述判断一个 `Widget` 是否有所破损，并把所有破损的 `Widget` 对象写到 `cerr` 中：
```c++
template<typename Inputlterator, typename OutputIterator, typename Predicate>
OutputIterator copy_if(InputIterator begin, InputIterator end, OutputIterator destBegin, Predicate p) {
    return remove_copy_if(begin, end, destBegin, not1(p));
}

bool isDefective(const Widget& w);
vector<Widget> widgets;
// 如果上面的实现是有效的，那么就可以用以下方法写出所有破损的 Widget：
copy_if(widgets.begin(), widgets.end(), 
        ostream_iterator<Widget>(cerr, "\n"), isDefective);
```
上面的做法是以这样的事实为基础的：虽然 `STL` 不允许复制所有使判别式条件为真的元素，但是它允许复制所有使判别式条件不为真的元素。因此，为实现 `copy_if`，只需在 `copy_if` 的判别式的前面加上 `not1`，然后把结果所得的判别式传递给 `remove_copy_if`。
但 `STL` 不会理解这样的代码，因为它会试图把 `not1` 应用到 `isDefective` 上，而第 41 条解释说明 `not1` 不能被直接应用到一个函数指针上，函数指针必须首先用 `ptr_fun` 进行转换。为调用 `copy_if` 的这个实现，传入的不仅是一个函数对象，而且还应该是一个可配接的函数对象。
虽然这很容易做到，但是要想成为 `STL` 算法，它不能给客户这样的负担。标准的 `STL` 算法从不要求它们的函数子必须是可配接的，因此要使用下面 `copy_if` 的正确实现：
```c++
template<typename InputIterator, typename OutputIterator, typename Predicate>
OutputIterator copy_if(InputIterator begin, InputIterator end, OutputIterator destBegin, Predicate p) {
    while (begin != end){
        if (p(*begin)) *destBegin++ = *begin; 
        ++begin;
    }
    return destBegin;
}
```
## 37：使用 `accumulate` 或者 `for_each` 进行区间统计
### accumulate
`accumulate` 有两种形式。第一种形式有两个迭代器和一个初始值，它返回该初始值加上由迭代器标识的区间中的值的总和：
```c++
list<double> ld;
// 因为0.0的类型是double，所以accumulate的内部使用一个double类型的变量来保存它所计算的总和，如果是 0，将使用int变量来保存它所计算的总和
double sum = accumulate(ld.begin(), ld.end(), 0.0); 
// accumulate 只要求输入迭代器，所以可以使用istream_iterator和istreambuf_iterator
cout << accumulate(istream_iterator<int>(cin), istream_iterator<int>(), 0);
```
另一种方式是带一个初始值和一个任意的统计函数：
```c++
// 两个参数，一个是到目前为止区间中的元素的统计值，另一个是区间的下一个元素
// 返回更新之后的总和值
string::size_type StringLengthSum(string::size_type sumSoFar, const string& s) {
    return sumSoFar + s.size();
}

set<string> ss; // 创建一个存放 string 的容器，然后加入字符串
// 对 ss 中的每个元素调用 StringLengthSum，然后把结果赋给 lengthSum，0 作为初始值 
string::size_type lengthSum = accumulate(ss.begin(), ss.end(), 
                        static_cast<string::size_type>(0),  StringLengthSum);

vector<float> vf;
// 使用标准的multiplies函数子类
float product = accumulate(vf.begin(), vf.end(), 1.Of, multiplies<float>()); 

// 计算出一个区间中所有点的平均值
struct Point{
    Point(double initX, double initY): x(initX), y(initY){} 
    double x,y;
}; 
```
传给 `accumulate` 的函数不允许有副作用，而下述的例子中修改 `numPoints`、`xSum`、`ySum` 的值会带来副作用，所以其结果是不可预测的：
```cpp
class PointAverage: public binary_function<Point, Point,Point> {
public:
    PointAverage(): xSum(0), ySum(0), numPoints(0) {}
    const Point operator()(const Point& avgSoFar, const Point& p) {
        ++numPoints; 
        xSum += p.x; 
        ySum += p.y;
        return Point(xSum / numPoints, ySum / numPoints);
    }
private:
    size_t numPoints; 
    double xSum; 
    double ySum; 
};

list<Point> lp;
Point avg = accumulate(Ip.begin(), Ip.end(), Point(0, 0), PointAverage());
```
### for_each
`for_each` 是另一个可被用来统计区间的算法，而且它不受 `accumulate` 的那些限制。`for_each` 也带两个参数：一个是区间，另一个是函数对象，但是传给 `for_each` 的这个函数只接收一个实参，即当前的区间元素，执行完毕后会返回这个函数的一份副本。重要的是，传给 `for_each` 的函数以及后来返回的函数可以有副作用。
`accumulate` 主要用于计算出一个区间的统计信息，而 `for_each` 用于对一个区间的每个元素做一个操作。此外，`accumulate` 直接返回统计结果，而 `for_each` 返回一个函数对象，必须从这个函数对象中提取出所要的统计信息，在 `C++` 中，这意味着必须在函数子类中加入一个成员函数，以便获得想要的统计信息：
```c++
class PointAverage: public unary_function<Point, void> {
public:
    PointAverage(): xSum(0), ySum(0), numPoints(0) {}
    const Point operator()(const Point& avgSoFar, const Point& p) {
        ++numPoints; 
        xSum += p.x; 
        ySum += p.y;
        return Point(xSum / numPoints, ySum / numPoints);
    }
    Point result()const {
        return Point(xSum / numPoints, ySum / numPoints); 
    }
private:
    size_t numPoints; 
    double xSum; 
    double ySum; 
};

list<Point> Ip;
Point avg = for_each(lp.begin(), Ip.end(), PointAverage()).result(); 
```
# Functor
## 38：遵循按值传递的原则来设计函数子类
无论是 C 还是 C++，都不允许将一个函数作为参数传递给另一个函数，相反，必须传递函数指针。标准库中的 `qsort` 函数就是这样一个例子，其函数声明如下：
```c++
void qsort(void* base, size_t nmemb, size_t size, int(*cmpfcn)(const void*, const void*));
```
通过 `cmpfcn` 传递的实参是一个函数指针，它的值被从调用者一端复制到 `qsort` 函数中，即 `cmpfcn` 采用按值传递的方式。`C` 和 `C++` 的标准库函数都遵循这一规则：函数指针是按值传递的。
在 `STL` 中，函数对象在函数之间来回传递的时候也是按值传递的。`for_each` 算法需要一个函数对象作为参数，同时其返回值也是一个函数对象，而且都是按值传递的，其声明如下：
```c++
template<class InputIterator, class Function> 
Function for_each(Inputlterator first, InputIterator last, Function f);
```
`for_each` 的调用者在调用点上可以显式地指明其模板参数的类型，使得以下代码就能够迫使 `for_each` 按引用方式传递参数和返回值：
```c++
class DoSomething: public unary_function<int, void> {
public:
    void operator()(int x){...} 
};
typedef deque<int>::iterator DequeIntIter;
deque<int> di;
DoSomething d;
for_each<DequeIntIter, DoSomething&>(di.begin(), di.end(), d); // 用类型参数调用
```
然而，`STL` 的使用者几乎从来不会做这样的事情，而且，如果将函数对象按引用来传递的话，有些 `STL` 算法的某些实现甚至根本不能通过编译。因而，接下来的讨论将假设函数对象总是按值方式来传递的。
由于函数对象往往会按值传递和返回，所以必须确保编写的函数对象在经过传递之后还能正常工作。这意味着函数对象必须尽可能地小，否则复制的开销会非常昂贵。其次，函数对象必须是单态的不是多态的，也就是说，它们不得使用虚函数。这是因为，如果参数的类型是基类类型，而实参是派生类对象，那么在传递过程中会产生剥离问题：在对象复制过程中，派生部分可能会被去掉，而仅保留了基类部分。
与普通的函数相比，函数对象的一大优点是，可以包含所需要的状态信息，因此需要能够像传递普通的函数指针那样方便地将这样的函数对象传递给 `STL` 算法。而且试图禁止多态的函数对象是不切实际的，`C++` 所支持的类继承体系以及动态绑定机制对于设计函数子类非常有用。
所以必须找到一种办法，既允许函数对象可以很大并且保留多态性，又可以与 `STL` 所采用的按值传递函数对象的习惯保持一致。有这样的办法，那就是：将所需的数据和虚函数从函数子类中分离出来，放到一个新的类中，然后在函数子类中包含一个指针，指向这个新类的对象。
例如，如果希望创建一个包含大量数据并且使用多态性的函数子类：
```c++
template<typename T>
class BPFC: public unary_function<T,void>{
private:
    Widget W;
    int x;
    ... // 包含大量数据，按值传递效率很低
public:
    virtual void operator()(const T& val) const; // 这是一个虚函数，所以存在剥离问题
};
```
那么就应该创建一个小巧的、单态的类，其中包含一个指针，指向另一个实现类，并且将所有的数据和虚函数都放在实现类中：
```c++
template<typename T>
class BPFCImpl: public unary_function<T, void>{
private: 
    Widget w;
    int x;
    ... // 原来BPFC中所有数据现在都放在这里 
    virtual ~BPFClmpl(); // 多态类需要虚析构函数
    virtual void operator()(const T& val) const;
    friend class BPFC<T>; // 允许BPFC访问内部数据
};

// 新的BPFC类
template<typename T> 
class BPFC: public unary_function<T, void>{
private:
	BPFCImpl<T> *pImpl; // BPFC唯一的数据成员
public:
    // 现在这是一个非虚函数，将调用转到BPFCImpl中
    void operator()(const T& val) const {  
        plmpl->operator()(val);
    } 
};
```
从 `STL` 的角度看，需要牢记在心的一点是，如果函数子类用到了这项技术，那么它必须以某种合理的方式来支持复制动作，即必须确保 `BPFC` 的复制构造函数正确地处理它所指向的 `BPFCImpl` 对象，这可以通过使用智能指针保证。
事实上，从本条款的意图来看，唯一需要谨慎处理的就是 `BPFC` 的复制构造函数，因为函数对象在 `STL` 中作为参数传递或者返回的时候总是按值方式被复制的。这意味着两件事情：第一，使它们小巧；第二，使它们成为单态的。
## 39：确保判别式是纯函数
一个判别式是一个返回值为 `bool` 类型或者可以隐式地转换为 `bool` 类型的函数。
一个纯函数是指返回值仅仅依赖于其参数的函数，在 C++ 中，纯函数所能访问的数据应该仅局限于参数以及常量。如果一个纯函数需要访问那些可能会在两次调用之间发生变化的数据，那么用相同的参数在不同的时刻调用该函数就有可能会得到不同的结果，这将与纯函数的定义相矛盾。
判别式类是一个函数子类，它的 `operator()` 函数是一个判别式。第 38 条中解释函数对象是按值传递的，所以应该设计出可被正确复制的函数子类。除此以外，对于用作判别式的函数对象，当它们被复制的时候还有另一个需要特别关注的地方：接受函数对象的 `STL` 算法可能会先创建函数对象的副本，然后存放起来，待以后再使用这些副本，而且，有些 `STL` 算法实现也确实利用这一特性，而这一特性的直接反映就是：要求判别式函数必须是纯函数。
考虑以下设计拙劣的判别式类，它简单地忽略传入的参数，并在第 3 次被调用的时候返回 `true`，其余的调用均返回 `false`：
```c++
class BadPredicate: public unary_function<Widget,bool>{
public:
    BadPredicate(): timesCalled(0) {}
    bool operator()(const Widget&) {
        return ++timesCalled == 3;
    }
private:
    size_t timesCalled; 
};

vector<Widget> vw;  // 创建容器，并添加一些Widget 
vw.erase(remove_if(vw.begin(), vw.end(), BadPredicate()), vw.end());
```
这段代码不仅删除 `vw` 容器中的第 3 个元素，而且同时还删除第 6 个，下述是 `remove_if` 的通用实现：
```c++
template<typename FwdIterator, typename Prediate>
FwdIterator remove_if(FwdIterator begin, FwdIterator end, Predicate p) {
    begin = find_if(begin, end, p);
    if (begin == end) return begin;
    else {
        Fwdlterator next = begin;
        return remove_copy_if(++next, end, begin, p); 
    }
}
```
判别式 `p` 首先被传递给 `find_if`，然后再传递给 `remove_copy_if`，在这两次传递过程中，`p` 都是被按值传递的，也就是说，是被复制到这两个算法中。
最初的 `remove_if` 调用创建一个匿名的 `BadPredicate` 对象，而且该对象内部的 `timesCalled` 成员被设置为 `0`，在 `remove_if` 中为 `p`。`p` 首先被复制到 `find_if` 中，所以 `find_if` 也会得到一个 `BadPredicate` 对象，而且其内部的 `timesCalled` 成员值为 0。
`find_if` 连续调用该判别式，直到它返回 `true` 为止，所以 `p` 会被连续调用 3 次，然后从 `find_if` 返回到 `remove_if`。`remove_if` 的代码继续执行，最终会调用 `remove_copy_if` 算法，并且将 `p` 的另一份副本作为一个判别式传递给它。
但是 `p` 的 `timesCalled` 成员仍然是 0，因为 `find_if` 从来没有调用过 `p`，它调用的只是 `p` 的一份副本。因此，当 `remove_copy_if` 第 3 次调用其判别式参数时，它仍然会返回 `true`。结果 `remove_if` 最终会从 `vw` 容器中删除两个 `Widget`，而是所期望的第 `3` 个元素。
最简单的解决途径就是在判别式类中，将 `operator()` 函数声明为 `const`：
```c++
class BadPredicate: public unary_function<Widget,bool> { 
public:
    bool operator()(const Widget&) const {
        return ++timesCalled == 3;
    }
};
```
即使是 `const` 成员函数，它也可以访问 `mutable` 数据成员、非 `const` 的局部 `static` 对象、非 `const` 的类 `static` 对象、名字空间域中的非 `const` 对象，以及非 `const` 的全局对象。一个精心设计的判别式类应该保证其 `operator()` 函数完全独立于所有这些变量。
所以，在判别式类中将 `operator()` 声明为 `const`，这对于判别式的正确行为是必要的，但还不足以完全解决问题。一个行为正常的判别式的 `operator()` 肯定是` const` 的，但它还应是一个纯函数。
`STL` 中凡是需要判别式函数的地方，就既可以接受一个真正的函数，也可以接受一个判别式类的对象。反之亦然，`STL` 中凡是可以接受一个判别式类对象的地方，也就可以接受一个判别式函数，可能需要通过 `ptr_fun` 加以修饰——见第41条。因此判别式类中的 operator() 函数应该是纯函数这项限制也同样适用于判别式函数。下面展示的函数是前面设计拙劣的函数子类的一个翻版：
```c++
bool anotherBadPredicate(const Widget&, const Widget&) {
    static int timesCalled = 0; // 切记不可如此！判别式应该是纯函数，而纯函数应该没有状态
    return ++timesCalled == 3;
}
```
## 40：若一个类是函数子类，则应使它可配接
假设有一个包含 `Widget` 对象指针的 `list` 容器，另有一个函数可用来判断某个 `Widget` 指针所指的对象是否足够有趣：
```c++
list<Widget*> widgetPtrs;
bool islnteresting(const Widget* pw); 

// 找到该 list 中第一个满足 isInteresting 条件的Widget指针：
list<Widget*>::iterator i = find_if(widgetPtrs.begin(), widgetPtrs.end(), islnteresting);
if (i != widgetPtrs.end()) // 处理第一个指向有趣的Widget的指针

// 如果想找到第一个不满足isInteresting()条件的Widget指针，以下这种显而易见的实现方法却不能通过编译：
list<Widget*>::iterator i = find_if(widgetPtrs.begin(), widgetPtrs.end(), not1(islnteresting));

// 正确的做法是，在应用not1之前，必须先将ptr_fun应用在isInteresting上：
list<Widget*>::iterator i = find_if(WidgetPtrs.begin(), widgetPtrs.end(), not1(ptr_fun(isInteresting)));
```
`IsInteresting` 作为一个基本的函数指针，它缺少 `not1` 所需要的类型定义，`ptr_fun` 完成一些类型定义的工作，因此需要应用 `ptr_fun` 之后再应用 `not1` 才可以工作。
4 个标准的函数配接器 `not1`、`not2`、`bind1st` 和 `bind2nd` 都要求一些特殊的类型定义，提供了这些必要的类型定义的函数对象被称为可配接的函数对象。这些特殊的类型定义是：`argument_type`、`first_argument_type`、`second_argument_type` 以及 `result_type`。不过，实际情况还没有这么简单，因为不同种类的函数子类所需提供的类型定义也不尽相同，它们是这些名字的不同子集。
提供这些类型定义最简便的办法是让函数子从特定的基类继承，或者更准确地说，从一个基结构继承。如果函数子类的 `operator()` 只有一个实参，那么它应该从 `std::unary_function` 继承，如果函数子类的 `operator()` 有两个实参，那么它应该从 `std::binary_function` 继承。
不过由于 `unary_function` 和 `binary_function` 是 `STL` 提供的模板，所以不能直接继承它们。相反，你必须继承它们所产生的结构，这就要求指定某些类型实参。对于 `unary_function`，必须指定函数子类 `operator()` 所带的参数的类型，以及返回类型，而对于 `binary_function`，必须指定 `operator()` 的第一个和第二个参数的类型，以及返回类型。
```c++
template<typename T>
class MeetsThreshold: public std::unary_function<Widget, bool> { 
	const T threshold; 
public:
    MeetsThreshold(const T& threshold);
    bool operator()(const Widget&) const; 
};

struct WidgetNameCompare: public std::binary_function<Widget, Widget, bool> {
    bool operator()(const Widget& lhs, const Widget& rhs) const;
};
```
MeetsThreshold 是一个类，而 WidgetNameCompare 是一个结构。这是因为 MeetsThreshold 包含了状态信息，而类是封装状态信息的一种逻辑方式，与此相反，WidgetNameCompare 并不包含状态信息，因而不需要任何私有成员。如果一个函数子类的所有成员都是公有的，那么通常会将其声明为结构而不是类，`STL` 中所有的无状态函数子类一般都被定义成结构。
虽然 operator() 的参数类型都是 const Widget&，但传递给 binary_function 的类型却是 Widget。一般情况下，传递给 unary_function 或 binary_function 的非指针类型需要去掉 const 和 & 部分。如果 operator() 带有指针参数，则规则又有所不同。
下面是 `WidgetNameCompare` 函数子类的另一个版本，这次以 `Widget*` 指针作为参数：
```c++
struct WidgetNameCompare: public std::binary_function<const Widget*, const Widget*, bool> {
    bool operator()(const Widget* lhs, const Widget* rhs) const;
};
```
这里，传给 `binary_function` 的类型与 `operator()` 所带的参数类型完全一致。对于以指针作为参数或返回类型的函数子类，一般的规则是，传给 `unary_function` 或 `binary_function` 的类型与 `operator()` 的参数和返回类型完全相同。
以 `unary_function` 和 `binary_function` 作为函数子的基类，提供了函数对象配接器所需要的类型定义，这样通过简单的继承，就产生了可配接的函数对象，例如：
```c++
 `list` <Widget> widgets; // 找到最后一个不符合阈值 10 的 widget
 `list` <Widget>::reverse_iterator i1 = find_if(widgets.rbegin(), widgets.rend(), not1(MeetsThreshold<int>(10)));

Widget w(...); // 找到按WidgetNameCompare定义的规则排序时，在w之前的第一个Widget对象
 `list` <Widget>::iterator i2 = find_if(widgets.begin(), widgets.end(), bind2nd(WidgetNameCompare(), w));
```
`STL` 函数对象是 `C++` 函数的一种抽象和建模形式，而每个 `C++` 函数只有一组确定的参数类型和一个返回类型。所以，`STL` 总是假设每个函数子类只有一个 `operator()` 成员函数，并且其参数和返回类型应该吻合 `unary_function` 或 `binary_function` 的模板参数。
## 41：`ptr_fun`、`mem_fun` 和 `mem_fun_ref` 的来由
```c++
f(x); // 语法 1：f为一个非成员函数 
x.f(); // 语法 2：f是成员函数，并且x是一个对象或对象的引用
p->f(); // 语法 3：f是成员函数，并且p是一个指向对象x的指针

// 现在假设有一个可用于测试Widget对象的函数：
void test(Widget& w); // 测试w，如果它不能通过测试，则将它标记为失败

// 假如test是Widget的成员函数，即Widget支持自测：
class Widget { 
public:
	void test(); // 执行自测，如果不通过，则把*this标记为失败
};

vector<Widget> vw; // vw存储widget 

// 为测试vw中的每一个Widget对象，自然可以用如下的方式来调用 for_each：
for_each(vw.begin(), vw.end(), test); // 调用 1 可以通过编译

// 在理想情况下，应该也可以用for_each在vw中的每个对象上调用Widget::test成员函数
for_each(vw.begin(), vw.end(), &Widget::test); // 调用 2 不能通过编译

// 如果真的很理想的话，那么对于一个存放Widget*指针的容器
// 应该也可以通过for_each来调用Widget::test
list<Widget*> lpw;
for_each(lpw.begin(), lpw.end(), &Widget::test); // 调用 3 不能通过编译
```
在调用 1 中，用一个对象来调用一个非成员函数，所以使用语法 1。在调用 2 中，必须使用语法 2，因为面对的是一个对象和一个成员函数。在调用 3 中，需要使用语法 3，因为在处理一个成员函数和一个对象指针。因此需要 3 个不同版本的 `for_each` 算法实现，然而只有一个 `for_each` 算法：
```c++
template<typename InputIterator, typename Function>
Function for_each(InputIterator begin, InputIterator end, Function f) {
    while (begin != end) f(*begin++);
}
```
上面的代码表明 `for_each` 的实现是基于使用语法 1 的，这是 `STL` 中一种很普遍的惯例：函数或者函数对象在被调用的时候，总是使用非成员函数的语法形式。这也说明为什么调用 1 能通过编译，而调用2、调用 3 却不行。这是因为 `STL` 的算法都硬性采用语法 1，而只有调用 1 与这种语法形式兼容。
因此 `mem_fun_ref` 和 `mem_fun` 被用来调整通过语法 2 或语法 3 被调用的成员函数，使之能够通过语法 1 被调用，它们是函数模板，针对它们所配接的成员函数的原型的不同，包括参数个数的不同以及常数属性的不同，有几种变化形式：
```c++
// 该 mem_fun_t 声明针对不带参数的非const成员函数，C是类，R是所指向的成员函数的返回类型
template<typename R, typename C> 
mem_fun_t<R, C> mem_fun(R(C::*pmf)()); 
```
`mem_fun` 带一个指向某个成员函数的指针参数 `pmf`，并且返回一个 `mem_fun_t` 类型的对象。 `mem_fun_t` 是一个函数子类，它拥有该成员函数的指针，并提供 `operator()` 函数，在 `operator()` 中调用通过参数传递进来的对象上的成员函数。例如：
```c++
list<Widget*> lpw;
for_each(lpw.begin(), lpw.end(), mem_fun(&Widget::test)); // 现在可以通过编译
```
`for_each` 接收到一个类型为 `mem_fun_t` 的对象，该对象中保存一个指向 `Widget::test` 的指针。对于 `lpw` 中的每一个 `Widget*` 指针，`for_each` 将会使用语法 1 来调用 `mem_fun_t` 对象，然后，该对象立即用语法 3 调用 `Widget*` 指针的 `Widget::test()`。
当通过一个 `Widget*` 指针来调用 `Widget::test` 的时候，语法 3 是必需的，而 `for_each` 使用的是语法 1，所以 `mem_fun` 的这种调整是必要的。因此，像 `mem_fun_t` 这样的类被称为函数对象适配器。`mem_fun_ref` 函数与此类似，它将语法 2 调整为语法 1，并产生一个类型为 `mem_fun_ref_t` 的配接器对象。
这些由 `mem_fun` 和 `mem_fun_ref` 产生的对象不仅使得 `STL` 组件可以通过同一种语法形式来调用所有的函数，而且它们还提供一些重要的类型定义，就像 `ptr_fun` 所产生的对象一样，但 `ptr_fun` 只用于提供类型定义而不进行语法转换。
```c++
for_each(vw.begin(), vw.end(), test); // 同上，调用 1 可以通过编译 
for_each(vw.begin(), vw.end(), ptr_fun(test)); // 与调用 1 的行为一样 

for_each(vw.begin(), vw.end(), &Widget::test); // 同上，调用 2 不能通过编译 
for_each(lpw.begin(), lpw.end(), &Widget::test); // 同上，调用 3 不能通过编译
```
调用 1 传入一个函数，所以没有必要为 `for_each` 调整语法形式，`for_each` 也不需要 `ptr_fun` 所引入的那些类型定义，所以当将 `test` 传给 `for_each` 的时候，并不需要使用 `ptr_fun`。不过，如果加上类型定义也无妨。
`mem_fun` 和 `mem_fun_ref` 的情形则截然不同。每次在将一个成员函数传递给一个 `STL` 组件的时候，就要使用它们。因为它们不仅仅引入一些类型定义，而且它们将针对成员函数的调用语法转换为 `STL` 组件所使用的调用语法。如果在传递成员函数指针的时候不使用它们，那么代码永远也无法通过编译。
## 42：确保 `less<T>` 与 `operator<` 具有相同的语义
```c++
// 假设Widget包含了一个重量值和一个最大速度值：
class Widget {
public:
    size_t weight() const;
    size_t maxSpeed()const; 
    // 通常情况下，按重量对Widget进行排序是最自然的方式，Widget的operator反映了这一点：
    bool operator<(const Widget& lhs, const Widget& rhs) {
        return lhs.weight() < rhs.weight();
    }
}；
```
但在某种特殊情况下，需要创建一个按照最大速度进行排序的 `multiset<Widget>` 容器，它的默认比较函数是 `less<Widget>`，而 `less<Widget>` 在默认情况下会调用 `operator<` 来完成工作。
为让 `multiset<Widget>` 按最大速度进行排序，一种显而易见的实现方式是：特化 `less<Widget>`，切断 `less<Widget>` 和 `operator<` 之间的关系，让它只考虑 `Widget` 的最大速度：
```c++
template<>
struct std::less<Widget> : public std::binary_function<Widget, Widget, bool> {
    bool operator()(const Widget& lhs, const Widget& rhs) const {
        return lhs.maxSpeed() < rhs.maxSpeed(); 
    }
};
```
这段代码并不仅仅是一个模板的特化而已，它特化的是一个位于 `std` 名字空间中的模板！作为一般性的规则，对 `std` 名字空间的组件进行修改确实是被禁止的。
大多数情况下应该有比特化 `std` 模板更好的选择，但是在偶尔的情形下，这样做也是合理的。例如，智能指针类的作者通常希望他们的类能够像 `C++` 内置指针一样进行排序，所以，针对智能指针类的 `std::less` 特化版本并不少见。例如，下面的例子就是 `Boost` 库的智能指针部分实现：
```c++
namespace std {
    template<typename T>
    struct less<shared_ptr<T>>: public binary_function<shared_ptr<T>, shared_ptr<T>, bool> {
        bool operator()(const shared_ptr<T>& a, const shared_ptr<T>&b) const {
            return less<T*>()(a.get(), b.get());
        }
    };
}
```
这没有什么不合理的，上面的 `less` 特化只是确保智能指针的排序行为与它们的内置指针的排序行为相同。然而，前面提到的针对 `Widget` 而特化 `std::less` 的做法却未必是个合理的选择。
应该尽量避免修改 `less` 的行为，因为这样做很可能会误导其他的程序员。如果使用 less，无论是显式地或是隐式地，都需要确保它与 `operator<` 具有相同的意义。如果希望以一种特殊的方式来排序对象，那么最好创建一个特殊的函数子类，它的名字不能是 `less`。
## 45：区分 `count/find/binary_search/lower_bound/upper_bound/equal_range`
假定有一对迭代器，它们指定一个被搜索的区间。在选择具体查找策略时，由迭代器指定的区间是否是排序的，这是一个至关重要的决定条件。
如果迭代器指定的区间是排序的，那么通过 `binary_search`、 `lower_bound`、`upper_bound` 和 `equal_range`，可以以对数时间运行。如果并不是排序的，那么选择范围将局限于 `count`、`count_if`、`find` 以及 `find_if`，而这些算法仅能提供线性时间的效率。
从未排序的区间到排序区间的转变也带来另一种变化：前者利用相等性来决定两个值是否相同，而后者使用等价性作为判断依据。count 和 find 使用相等性进行搜索，而 `binary_search`、`lower_bound`、 `upper_bound` 和 `equal_range` 则使用等价性。
### Count/Find
假设仅仅想知道一个 `list` 容器中是否存在某个特定的 `Widget` 对象值 `w`。
```c++
list<Widget> lw;
Widget w;

// 如果使用count，则代码如下，count返回零或者一个正整数
if (count(lw.begin(), lw.end(), w));
if (count(lw.begin(), lw.end(), w) != 0);

// 使用find的做法要稍微复杂一些，因为必须测试find的返回值是否等于链表的end迭代器：
if (find(lw.begin(), lw.end(), w) != lw.end());
```
从存在性测试的角度来看，`count` 的习惯用法相对要容易编码一些。但同时，在搜索成功的情况下，它的效率要差一些，因为 `find` 找到第一个匹配结果后马上就返回了，而 `count` 必须到达区间的末尾，以便找到所有的匹配。当不仅仅想知道一个值是否存在，而且也想知道哪一个对象具有这样的值的时候，需要 `find`。
### Binary_search
要想测试一个排序区间中是否存在某一个特定的值，你可以使用 `binary_search`。与标准 `C/C++` 函数库中的 `bsearch` 不同的是，`binary_search` 仅仅返回一个 `bool` 值：是否找到特定的值：
```c++
vector<Widget> vw;
sort(vw.begin(),vw.end());
Widget w;
if (binary_search(vw.begin(), vw.end(), w));
```
### Lower_bound/Equal_range
如果有一个排序的区间，要找到这个值在区间中的位置，可能会使用 `lower_bound/equal_range`。当使用 `lower_bound` 来查找某个特定值的时候，它会返回一个迭代器，如果找到的话指向一个等于该值的位置，否则指向第一个大于该值的位置，即适合于插入该值的位置。
与 `find` 一样，必须测试 `lower_bound` 的结果，以便判断它是否指向你要找的值。与 `find` 不一样的是，不能用 `end` 迭代器来测试 `lower_bound` 的返回值。相反，必须测试 `lower_bound` 所标识的对象，以便判断该对象是否具有想要找的值：
```c++
vector<Widget>::iterator i = lower_bound(vw.begin(), vw.end(), w); 
if(i != vw.end() && *i == w); // 确保i指向一个对象，并且确保该对象有正确的值
```
这是一个相等性测试，但 `lower_bound` 是用等价性来搜索的。在大多数情况下，等价性测试和相等性测试的结果是相同的，但是第 19 条说明相等性和等价性不相同的情形也是不难发现的。在这样的情况下，上述代码是错误的。所以，正确的做法是，必须检查 `lower_bound` 返回的迭代器所指的对象是否等价于要查找的值。
有一种更容易的办法：使用 `equal_range`。`equal_range` 返回一对迭代器：第一个迭代器等于 `lower_bound` 返回的迭代器，第二个迭代器等于 `upper_bound` 返回的迭代器。所以，`equal_range` 返回的这一对迭代器标识一个子区间，其中的值与所查找的值等价。
关于 `equal_range` 的返回值，如果返回的两个迭代器相同，则说明查找所得的对象区间为空，即没有找到这样的值：
```c++
typedef vector<Widget>::iterator VWlter;
typedef pare<VWIter, VWIter> VWlterPair;

vector<Widget> vw;
sort(vw.begin(), vw.end());

VWIterPair p = equal_range(vw.begin(), vw.end(), w);
// 如果equal_range返回非空区间，找到了特定值
// p.first指向第一个与w等价的对象，p.second指向最后一个与w等价的对象的下一个位置
if (p.first != p.second) 
else // 没有找到特定值，p.first和p.second都指向w的插入位置
```
这段代码只使用等价性，所以它总是正确的。
此外 `equal_range` 返回的迭代器之间的距离与这个区间中的对象数目是相等的，也就是原始区间中与被查找的值等价的对象数目。所以，对于排序区间而言，`equal_range` 不仅完成 `find` 的工作，同时也代替 `count`。例如，如果要在 `vw` 中找到与 `w` 等价的 `Widget` 对象的位置，并打印出有多少个这样的对象：
```c++
VWIterPair p = equal_range(vw.begin(), vw.end(), w);
cout << distance(p.first, p.second) << "elements in vw equivalent to w."; 
```
如果想在一个排序区间中插入一些对象，并且希望等价的对象仍然保持它们在插入时的顺序，那么可以使用 `upper_bound`。例如，有一个 `Person` 对象的排序 `list` ，其中的对象按照名字排序：
```c++
// 按名字排序，如果有名字等价，则按照插入顺序排列
lp.insert(upper_bound(lp.begin(), lp.end(), newPerson, PersonNameLess()), newPerson);
```
### Associative Container
到现在为止，只考虑用一对迭代器来指明查找区间的情形。通常情况下，拥有的是一个容器，而不是一个区间。在这种情况下，必须区分它是序列容器还是关联容器。对于标准的序列容器 `vector/string/deque/list`，可以按照本条款中给出的建议，用容器的 `begin` 和 `end` 迭代器来指明区间。
但对于标准关联容器 `set/multiset/map/multimap` 情形就不同了，因为它们提供一些用于查找的成员函数，而且这些成员函数往往比 `STL` 算法还要好。这些成员函数的名称一般都与对应的算法的名称相同，所以，在前面的讨论中建议选择算法的地方，针对关联容器的情形，只需选择同名的成员函数即可。
只有 `binary_search` 是个例外，因为在关联容器中并没有与之对应的成员函数。要在 set 或者 `map` 中测试一个值是否存在，可以按照成员关系测试的习惯用法来使用 `count`，而如果要在 `multiset` 和 `multimap` 中测试一个值是否存在，则一般情况下用 `find` 比用 `count` 好，因为 `find` 只要找到第一个期望的值就返回了，而 `count` 在最坏的情形下必须检查容器中的每一个对象。不过，如果要在关联容器中统计个数，则选择 `count` 更好。
### Compare
![alt](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/Image00330.jpg)
在针对排序区间的一栏中，`equal_range` 出现的次数异乎寻常的多。由于在查找过程中使用等价性测试非常重要，所以它的出现频率就很高。使用 `lower_bound` 和 `upper_bound`，很容易回退到相等性测试，而对于 `equal_range`，仅仅支持等价性测试则是非常自然的事情。在第二行针对排序区间的表格单元中，之所以选择 `equal_range` 而不是 `find` 只有一个理由：`equal_range` 按对数时间运行；而 `find` 按线性时间运行。
对于 `multiset` 和 `multimap`，当想寻找第一个具有特定值的对象时，`find` 和 `lower_bound` 都可以。对于 `set` 和 `map`，通常使用 `find`，对于  `multiset` 和 `multimap`，如果容器中有多个对象具有特定的值，则 `find` 并不保证一定标识出第一个具有此值的元素，它只是标识出其中的一个元素。如果真的想找到第一个具有特定值的对象，那么可以使用 `lower_bound`，然后如第 19 条中所述，必须手工执行等价性测试以确定已经找到想找的值。通过使用 `equal_range`，可以避免手工的等价性测试，但是调用 `equal_range` 的开销比调用 `lower_bound` 的更加昂贵。）
## 46：考虑使用函数对象而不是函数作为 `STL` 算法的参数。
### Inline
将函数对象传递给 `STL` 算法往往比传递实际的函数更加高效。如果比较下面两次 `sort` 调用的性能，使用 `greater<double>` 的 `sort` 调用比使用 `doubleGreater` 的 `sort` 调用快得多。
```c++
vector<double> V;
sort(v.begin(), v.end(), greater<double>());

inline bool doubleGreater(double d1, double d2) {
    return d1 > d2;
}

sort(v.begin(), v.end(), doubleGreater);
```
对这种行为的解释也非常简单：函数内联。如果一个函数对象的 `operator()` 函数已经被声明为内联的或通过 `inline` 显式地声明，或被定义在类定义的内部，即隐式内联，那么它的函数体将可以直接被编译器使用，而大多数编译器都在被调算法的模板实例化过程中将该函数内联进去。
在上面的例子中，函数 `greater<double>::operator()` 是一个内联函数，所以编译器在 `sort` 的实例化过程中将其内联展开。最终结果是，`sort` 中不包含函数调用，编译器就可以对这段不包含函数调用的代码进行优化，而这种优化在正常情况下是很难获得的。
在 C/C++ 中并不能真正地将一个函数作为参数传递给另一个函数。如果试图将一个函数作为参数进行传递，则编译器会隐式地将它转换成一个指向该函数的指针，并将该指针传递过去。因此，例子中下面的调用：
```c++
sort(v.begin(), v.end(), doubleGreater);
```
并不是将 `doubleGreater` 传递给 `sort`，相反，它传递的是一个指向 `doubleGreater` 的指针。当 `sort` 模板被实例化的时候，编译器生成的函数声明如下所示：
```c++
void sort(vector<double>::iterator first, vector<double>::iterator last, bool (*comp)(double, double));
```
由于参数 `comp` 只是一个指向函数的指针，所以在 `sort` 内部每次 `comp` 被用到的时候，编译器都会产生一个间接的函数调用，即通过指针发出的调用。**大多数编译器不会试图对通过函数指针执行的函数调用进行内联优化**，即使像本例中那样，函数已经被声明为 `inline`。
`C++` 必须先实例化函数模板和类模板，然后再调用相应的` operator()` 函数，相比之下，C 只是进行一次简单的函数调用。但是，`C++` 的所有这些额外负担都在编译期间消化殆尽。在运行时，sort 算法以内联方式调用它的比较函数，而 `qsort` 则通过一个指针来调用它的比较函数。所以最终的结果是，`sort` 算法运行得更快一些。
### Compile
此外，还有另一个与效率完全无关的理由使得函数对象在作为 `STL` 算法的参数时优先于普通函数。这就是，必须让程序正确地通过编译。由于种种原因， `STL` 平台可能会拒绝一些完全合法的代码。举例来说，下面的代码将一个集合中每个字符串对象的长度输出到 `cout` 中，代码是完全合法的，但是在一个被广泛使用的 `STL` 平台上却无法通过编译：
```c++
set<string> s;
transform(s.begin(), s.end(), 
          ostream_iterator<string::size_type>(cout,"\n"), 
          mem_fun_ref(&string::size));
```
问题的原因在于，这个特定的 `STL` 平台在处理 `const` 成员函数 `string::size` 的时候有一个错误。一种解决办法是用函数对象来取代相应的函数：
```c++
struct StringSize: public unary_function<string, string::size_type> {
     string::size_type operator()(const string& s) const {
        return s.size();
    }
};
transform(s.begin(), s.end(), 
          ostream_iterator<string::size_type>(cout, "\n"),  
          StringSize());
```
除此以外还有其他一些解决办法，但是以上的办法不仅能够通过编译，而且还使得编译器对 `string::size` 调用进行内联优化。而在原来的代码中，在 `mem_fun_ref(&string::size)` 被传递给 `transform` 算法的地方，这种优化根本不可能发生。因此创建函数子类，不仅避开编译器的缺陷，而且还提高程序的性能。
### Function Template
函数对象优先于函数的第三个理由是，这样做有助于避免一些微妙的、语言本身的缺陷。在偶然的情况下，有些看似合理的代码会被编译器以一些合法但又含糊不清的理由而拒绝。例如，当一个函数模板的实例化名称并不完全等同于一个函数的名称时，就可能会出现这样的问题。下面是一个例子：
```c++
template<typename FPType>
FPType average(FPType val1, FPType val2) {
    return (val1 + val2) /2;
}

template<typename InputIter1, typename InputIter2> 
void writeAverages(InputIter1 begin1, InputIter1 end1, InputIter2 begin2, ostream& s) {
    transform(begin1, end1, begin2, 
    ostream_iterator<typename iterator_traits<Inputlter1>::value_type>(s, "\n"), 
    			average<typename iterator_traits<InputIter1>::value_type>); // 错误？
}
```
许多编译器都可以接受这段代码，但是 C++ 标准却不认同这样的代码。原因在于，在理论上可能存在另一个名为 `average` 的函数模板，它也只带一个类型参数。
如果这样的话，表达式 `average<typename iterator_traits<InputIter1>::value_type>` 就会有二义性，因为编译器无法分辨到底应该实例化哪一个模板。在上面这个特殊的例子中并不存在二义性，但有些编译器会拒绝这段代码，而且 `C++` 标准也允许编译器这样做。只需使用一个函数对象来代替函数即可：
```c++
template<typename FPType>
struct Average: public binary_function<FPType, FPType, FPType> {
    FPType operator()(FPType val1, FPType val2) const {
        return average(val1, val2);
    }
};

template<typename InputIter1, typename InputIter2> 
void writeAverages(InputIter1 begin1, InputIter1 end1, InputIter2 begin2, ostream& s) {
    transform(begin1, end1, begin2, ostream_iterator<typename iterator_traits<Inputlter1>::value_type>(s, "\n"), 
              Average<typename iterator_traits<Inputlter1>::value_type>()); 
}
```
所有的 `C++` 编译器都应该接受这段修正过的代码，而且，`transform` 内部的 `Average::operator()` 调用也符合内联优化的条件，而前面代码中的 `average` 实例却无法内联优化，因为 `average` 是一个函数模板，不是函数对象。
## 47：避免产生 Write-Only 的代码
假定有一个 `vector<int>`，现在想删除其中所有其值小于 `x` 的元素，但在最后一个其值不小于 `y` 的元素之前的所有元素都应该保留下来：
```c++
vector<int> v;
int x,y;
v.erase(remove_if(find_if(v.rbegin(), v.rend(), bind2nd(greater_equal<int>(), y)).base(), 
                  v.end(), bind2nd(less<int>(), x)), v.end());

// 一种分解的做法
typedef vector<int>::iterator Veclntlter;
// 初始化rangeBegin，使它指向v中大于或等于y的最后一个元素之后的元素。
// 如果不存在这样的元素，则rangeBegin被初始化为v.begin()，如果最后这样的元素正好是v的最后一个元素，则rangeBegin被初始化为v.end()
Veclntlter rangeBegin = find_if(v.rbegin(), v.rend(), bind2nd(greater_equal<int>(), y)).base(); 
// 在从rangeBegin到 v.end() 的区间中，删除所有小于x的值
v.erase(remove_if(rangeBegin, v.end(), bind2nd(less<int>(), x)), v.end()); 
```
解决该问题的思路大抵如下：
- 通过以 `reverse_iterator` 作为参数调用 `find` 或者 `find_if`，找到容器中最后一个其值不小于 `y` 的元素。
- 使用 `erase-remove` 习惯用法删除区间中符合条件的元素。
将这两点结合起来，就会得到下面的伪代码：
```c++
v.erase(remove_if(find_if(v.rbegin(), v.rend(), something).base(), 
                  v.end(), something), v.end());
```
这就是为什么这种语句通常被称为直写型代码的原因。当你编写代码的时候，它看似非常直接和简捷，因为它是由某些基本想法，比如，`erase-remove` 习惯用法加上在 `find` 中使用 `reverse_iterator` 的概念自然而形成的。虽然很容易编写，但是难以阅读和理解。
