# Container
容器选择原则：
- 除非有合适的理由选择其他容器，否则应该使用`vector`。
- 如果程序有很多小的元素，且空间的额外开销很重要，则不要使用`list`或`forward_list`。
- 如果程序要求随机访问容器元素，则应该使用`vector`或`deque`。
- 如果程序需要在容器头尾位置插入/删除元素，但不会在中间位置操作，则应该使用`deque`。
- 如果程序只有在读取输入时才需要在容器中间位置插入元素，之后需要随机访问元素。则：
  - 先确定是否真的需要在容器中间位置插入元素。当处理输入数据时，可以先向`vector`追加数据，再调用标准库的`sort`函数重排元素，从而避免在中间位置添加元素。
  - 如果必须在中间位置插入元素，可以在输入阶段使用`list`。输入完成后将`list`中的内容拷贝到`vector`中。
- 不确定应该使用哪种容器时，可以先只使用`vector`和`list`的公共操作：使用迭代器，不使用下标操作，避免随机访问。这样在必要时选择`vector`或`list`都很方便。
## Sequence Container
### Array
array 包覆一个寻常的static C-style array并提供一个STL容器接口。观念上所谓array是指一系列元素，有着固定大小。因此你无法借由增加或移除元素而改变其大小，它只允许你替换元素值。它比寻常的array安全，而且效率并没有因此变差。
如果你需要一个有固定元素量的序列，class array＜＞将带来最佳效能，因为内存被分配于stack 中（如果可能的话），绝不会被重分配，而且你拥有随机访问能力。
array 是唯一一个无任何东西被指定为初值时，会被预初始化的容器。这意味着对于基础类型，初值可能不明确，而不是 0，可以提供一个空白初值列，这种情况下所有元素保证被初始化，于是对基础类型而言元素初值为 0。
```c++
c.max_size();
c.size();
c.at(idx);
c.front();
c.back();
c.data(); // &a[0]
```
> 注意，绝对不要以迭代器表现“第一元素的地址”。Class array 的迭代器的真实类型取决于实现，有可能与寻常的pointer完全不同。

Array提供tuple接口：
```c++
typedef std::array<std::string, 5> FiveStrings;
FiveStrings a = { "hello", "nico", "how", "are","you" }; 
std::tuple_size<FiveStrings>::value; //yields 5 
std::tuple_element<1, FiveStrings>::type; //yields std::string
std::get<1>(a); //vields std::string("nico"); 
```
### Vector
#### 初始化
```c++
vector<T> v1;      // v1是一个空vector，它潜在的元素是T类型的，执行默认初始化
vector<T> v2 (v1); // v2中包含有v1所有元素的副本
vector<T> v2 = v1;    // 等价于v2（v1），v2中包含有v1所有元素的副本
vector<T> v3(n, val);     // v3包含了n个重复的元素，每个元素的值都是val

// 如果vector对象的元素是内置类型，比如int，则元素初始值自动设为0。如果元素是某种类类型，比如string，则元素由类默认初始化
vector<T> v4(n);          // v4包含了n个重复地执行了值初始化的对象

vector<T> v5{a,b,c...};   // v5包含了初始值个数的元素，每个元素被赋予相应的初始值
vector<T> v5 = {a,b,c...};  // 等价于 v5{a,b,c...}
```
如果初始化时使用了花括号的形式但是提供的值又不能用来列表初始化，就要考虑用这样的值来构造vector对象了。
```c++
vector<string> v5{"hi"}; // 列表初始化：v5有一个元素 
vector<string> v6("hi"); // 错误：不能使用字符串字面值构建vector对象 
vector<string> v7{10};   // v7有10个默认初始化的元素
vector<string> v8{10, "hi"}; // v8有10个值为 "hi" 的元素
```
尽管在上面的例子中除了第二条语句之外都用了花括号，但其实只有v5是列表初始化。**要想列表初始化vector对象，花括号里的值必须与元素类型相同**。显然不能用int初始化string对象，所以v7和v8提供的值不能作为元素的初始值。确认无法执行列表初始化后，编译器会尝试用默认值初始化vector对象。
除了at()，没有任何成员函数会检查索引或迭代器是否有效。
既然vector的容量不会缩减，便可确定，即使删除元素，其reference、pointer和iterator也会继续有效，继续指向动作发生前的位置。然而插入动作却可能使reference、pointer和iterator失效（因为插入可能导致vector重新分配）。
#### 操作
```c++
c.size();   
c.empty(); 
c.clear();  
c.front()/back();    
c.at();
c.push_back()/pop_back();

// vector不能使用reserve缩减容量，实参如果小于当前vector的容量，不会引发任何效果。
c.reserve(); // 若容量不够，则进行扩大

// 一个不具强制力的要求，可以缩减容量以符合当前的元素个数，因此不能够期望之后的v.capacity==v.size会获得true
c.shrink_to_fit(); // 可能使reference、pointer和iterator失效
vector<T>(c).swap(c); // 两个vector交换内容后，两者的容量也会互换，此举保存元素消减容量

c.assign(n, elem);
c.assign(begin, end);
c.assign({...});
    
// 将元素数量改为 n，若 n 比原来小，删除多余信息，若 n 比原来大，则新增的部分均初始化为 elem，elem 未指定则默认构造函数完成
c.resize(n, elem);

//删除矢量中给定区间的元素。第一个迭代器指向区间的起始处，第二个迭代器位于区间终止处的后一个位置，返回下一元素的位置
c.erase(s.begin(), s.begin() + 2); // 删除第一个和第二个元素
c.erase(remove(c.begin(), c.end(), val), c.end());
pos = find(c.begin(), c.end(), val);
if (pos != c.end()) c.erase(pos); // 删除第一个

// insert 返回第一个新元素的位置
c.insert(pos, elem);
c.insert(pos, n, elem);
c.insert(pos, {...});
// 第一个迭代器参数指定了新元素的插入位置，第二个和第三个迭代器参数定义了被插入区间，该区间通常是另一个容器对象的一部分
s.insert(s.begin(), k.begin() + 1, k.end());

c.emplace(pos, val); // 返回第一个新元素的位置
c.emplace_back(pos, val);     // 无返回值

// 返回对区间去重后的末尾迭代器，unique用于去重前需要先排序，因为unique去重通过提取不连续数字实现
unique(a.begin(), a.end())                    

// unique 返回尾迭代器，必须要减去首迭代器，才能得到整数类型，即去重后数组长度
unique(a.begin(), a.end()) – a.begin();  

// 删除去重后的无用元素
s.erase(unique(a.begin(), a.end()) ，a.end())  
```
####  `vector<bool>`
C++标准库针对元素类型为bool的vector专门设计了一个特化版本，一般实现版本会为每个bool元素分配至少1 byte空间，而`vector<bool>`特化版的内部只使用1 bit存放一个元素，空间节省8倍。不过这里有个小麻烦：C++的最小可定址值乃是以byte为单位，所以上述的vector特化版必须对reference和iterator做特殊处理。
因此，`vector<bool>`无法满足其他vector的所有规定，例如`vector<bool>`::reference并不是个真正的 lvalue，`vector<bool>`::iterator也不是个真正的随机访问迭代器。所以某些 template 代码有可能适用于任何类型的 vector，唯独无法应付`vector<bool>`。
``vector<bool>``不仅是个特殊的bool版本，它还提供某些特殊的bit操作，可以利用它们更方便地操作bit或flag。由于`vector<bool>`的大小可动态改变，还可以把它当成可动态改变大小的 bit-field。因此可以任意添加或移除bit。如果需要大小固定的bitfield，应当使用bitset而不是`vector<bool>`。
```c++
c.flip();       // 对所有bool元素取反
c[idx].flip();  // 对 idx 位置的元素取反
c[idx] = val;
```
对一个`vector<bool>`，subscript操作符（及其他返回单一bit的操作符）的返回类型实际上是个辅助类，一旦你要求返回值为bool，便会触发一个自动类型转换函数，使得所有用于元素访问的函数，返回的都是reference类型。。
只有`vector<bool>`的non-const容器才会用到其内部的proxy类型reference。而用来处理元素的那些const成员函数，返回类型都是const_reference，那就是bool。
### Deque
Deque与vector相比，功能上的差异如下：
- 两端都能快速安插元素和移除元素。如果只从头、尾两个位置对 deque 进行增删操作的话，容器里的对象永远不需要移动。
- 访问元素时deque内部结构会多一个间接过程，所以元素的访问和迭代器的动作会稍稍慢一些。
- 容器里的元素只是部分连续的（因而没法提供 data 成员函数）。由于元素的存储大部分仍然连续，它的遍历性能是比较高的。
- 迭代器需要在不同区块间跳转，所以必须是个smart pointer，不能是寻常pointer。
- 在内存区块大小有限制的系统中，deque可以内含更多元素，因为它使用不止一块内存。因此deque的max_size()可能更大。
- deque不支持对容量和内存重新分配时机的控制。特别要注意的是，除了头尾两端，在任何地点安插或删除元素都将导致指向deque元素的任何pointer、reference和iterator失效。不过，deque的内存重分配优于vector，因为其内部结构显示，deque不必在内存重新分配时复制所有元素。
- Deque会释放不再使用的内存区块。Deque的内存大小是可缩减的，但要不要这么做，以及如何做，由实现决定。
Deque的各项操作只有以下两点和vector不同：
- deque 提供 push_front、emplace_front 和 pop_front 成员函数。
- deque 不提供 data、capacity 和 reserve 成员函数。
deque内部用来存放指向独立区块的所有pointer的空间，通常不会被缩小，如果用了shrink_to_fit函数就有可能真的被缩小。
> 元素的插入或删除可能导致内存重新分配，所以任何插入或删除动作都会使所有指向deque元素的pointer、reference和iterator失效。唯一例外是在头部或尾部插入元素，在那动作之后pointer和reference仍然有效（但iterator就没这么幸运）
### List
list在几个主要方面与array、vector或deque不同：
- 不支持随机访问。
- 任何位置上（不只两端）执行元素的安插和移除都非常快，始终都是常量时间内完成，因为无须移动任何其他元素。
- 插入和删除动作并不会造成指向其他元素的各个pointer、reference和iterator失效。
- 对于异常的处理方式是：要么操作成功，要么什么都不发生。
list提供deque的所有功能，还增加了适用于list的remove和remove_if算法特殊版本。
```c++
c.remove(val); // 删除所有等值元素，若要删除第一个则需要使用 find 
c.remove_if([](int i) { return i % 2 == 0 }); // 删除每一个判别式为 true 的元素

c.unique(); // 如果存在若干相邻而数值相同的元素，就移除重复元素，只留一个
c.unique(op); //如果存在若干相邻元素都使op的结果为true，则移除重复元素，只留一个

c.splice(pos, c2) // 将c2内的所有元素转移到c之内、迭代器pos之前
c.splice(pos, c2, c2pos) // 将c2内的c2pos所指元素转移到c内的pos所指位置（c和c2可相同）
c.splice(pos, c2, c2beg, c2end); //将c2beg, c2end的区间内所有元素转移到c内的pos之前

// 假设c和c2容器都包含op准则下的已排序元素，将c2的全部元素转移到c，并保证合并后的list仍为已排序
c.merge(c2);
// 假设c和c2容器都包含已排序元素，将c2的全部元素转移到c，并保证合并后的list在op准则下仍为已排序
c.merge(c2, op);

c.reverse(); // 将所有元素反序
```
### forward list
forward list是一个行为受限的list，不能走回头路。凡是list没提供的功能，它也都不提供。它的优点是内存用量较少，行动也略快速。
相较于list，forward list有以下约束：
- 只提供前向迭代器，而不是双向迭代器，因此它也不支持反向迭代器。
- 不提供成员函数size。
- 没有指向最末元素的锚点。基于这个原因，forward list不提供用以处理最末元素的成员函数如back、push_back和pop_back。
- 对于所有令元素被安插或删除于forward list的某特定位置上的成员函数，forward list提供特殊版本。原因是你必须传递第一个被处理元素的前一位置，因为你必须在那里指定一个新的后继元素；然而由于forward list不允许回头（至少常量时间内不行），因此对于这些成员函数，你必须传递前一元素的位置。基于这一差异，这些成员函数的名称都带有一个后缀_after。例如insert_after取代insert，将新元素插入第一实参所表示的元素之后；也就是说，它在那个位置上附加一个元素。
- forward list提供before_begin和cbefore_begin，它们会产出第一元素之前的一个虚拟元素的位置，可被用来让名称带有后缀_after的算法交换第一元素。
> 每次size被调用，要么就计算大小（线性复杂度），要么就由forward_list对象提供一个额外数据栏（field）记录大小，并令它在每一个会改变元素个数的操作函数中被更新。因此，如果你需要知道大小，要么就在forward_list提供的能力之外自行追踪它，要么就改用list。
```c++
// 不提供rbeign等，因为不支持反向迭代器
c.berfor_begin(); // 返回指向第一元素的前一位值
c.cberfor_begin();

// 结合 before_begin 它可确保涵盖第一元素
// 调用_after成员函数并传入end会导致不明确行为，因为如果要在尾端附加一个新元素，必须传入终端元素的位置
c.insert_after(c.berfor_begin(), {77});
```
查找：
```c++
forward_list<int> list = {1,2,3,4,5,97,98,99}; // find the position before the first even element
auto posBefore = list.before_begin();
for (auto pos = list.begin(); pos != list.end(); ++pos, ++posBefore) { 
    if(*pos % 2 == 0) break;
}
// 迭代器pos遍历list以求找到特定的某元素，而posBefore则总是指向pos的前一位置，以便能够返回正查找的那个元素的前一位置
list.insert_after(posBefore, 42);

// 对迭代器使用自C++11起提供的便捷函数next：
auto posBefore = list.before_begin();
for(;next(posBefore) != list.end(); ++posBefore) 
    if (*next(posBefore)% 2 == 0) break; 

// 找出拥有特定值或满足某特定条件的元素的前一位置：
template <typename InputIterator,typename Tp> 
inline InputIterator find_before (InputIterator first, InputIterator last, const Tp& val) {
    if (first == last) return first; // 为避免传begin导致不明确行为，这个算法首先检查区间的起点是否等于终点
    InputIterator next(first); 
    ++next;
    while (next!=last &&!(*next==val)) {
        ++next;
        ++first; 
    }
    return first; 
}
```
接合：
```c++
forward_list<int> l1 = {1,2,3,4,5}; 
forward_list<int> l2 = {97,98,99}; //find 3 in 11

auto pos1 = l1.before_begin();
for (auto pb1 = l1.begin(); pb1 != l1.end(); ++pb1, ++pos1)
    if(*pb1 == 3) break; // 查找第一个“数值为3的元素的前一位置

auto pos2 = l2.before_begin();
for (auto pb2 = l2.begin(); pb2 != l2.end(); ++pb2, ++pos2)
    if(*pb2 == 99) break; // 查找第一个“数值为99的元素的前一位置

// forward list l1内的第一个数值为3的元素被搬移到l2内的第一个数值为99的元素的前方
l2.splice_after(pos2, l1, pos1);
```
## Associative Container
存储在关联容器中的键一般应满足严格弱序关系（strict weak ordering），即
- 对于任何该类型的对象 x：!(x < x)（非自反）
- 对于任何该类型的对象 x 和 y：如果 x < y，则 !(y < x)（非对称）
- 对于任何该类型的对象 x、y 和 z：如果 x < y 并且 y < z，则 x < z（传递性）
- 对于任何该类型的对象 x、y 和 z：如果 x 和 y 不可比（!(x < y) 并且 !(y < x)）并且 y 和 z 不可比，则 x 和 z 不可比（不可比的传递性）
关联容器定义了类型别名来表示容器关键字和值的类型：
![11-3](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/11-3.png)
对于`set`类型，`key_type`和`value_type`是一样的。`set`中保存的值就是关键字。对于`map`类型，元素是关键字-值对。即每个元素是一个`pair`对象，包含一个关键字和一个关联的值。由于元素关键字不能改变，因此`pair`的关键字部分是`const`的。另外，只有`map`类型（`unordered_map`、`unordered_multimap`、`multimap`、`map`）才定义了`mapped_type`。
```c++
set<string>::value_type v1;        // v1 is a string
set<string>::key_type v2;          // v2 is a string
map<string, int>::value_type v3;   // v3 is a pair<const string, int>
map<string, int>::key_type v4;     // v4 is a string
map<string, int>::mapped_type v5;  // v5 is an int
```
解引用关联容器迭代器时，会得到一个类型为容器的`value_type`的引用。对`map`而言，`value_type`是`pair`类型，其`first`成员保存`const`的关键字，`second`成员保存值。虽然`set`同时定义了`iterator`和`const_iterator`类型，但两种迭代器都只允许只读访问`set`中的元素。
自动排序这一性质造成一个重要限制：对于 set 不能直接改变元素值，对于 map 不可以直接改变元素的 key，因为这会破坏正确次序。因此，要改变元素值，必须先删除旧元素，再插入新元素。要修改元素的key，必须先移除拥有该 key 的元素，然后插入拥有新 key/value 的元素。
```c++
// 如果一定得改变元素的key，只有一条路：以一个“value相同”的新元素替换掉旧元素。
col1["new_key"] = col1["old_key"]; //insert new element with value of old element 
co1l.erase("old_key"); //remove old element
```
从迭代器的观点看，对于 set 元素值是常量，对于 map 元素的 key 是常量，元素的 value 可以直接修改，前提是 value 并非常量。因此，set 元素是 const 的，map 元素的实质类型是 pair<const Key，T>，这个限制是为了确保不会因为变更元素的 key 而破坏已排好的元素次序。
> C++11保证，multiset和multimap的insert、emplace和erase成员函数都会保存等值元素间的相对次序，插入的元素会被放在既有的等值元素群的末尾。

insert 和 emplace，其返回类型不尽相同：
- 对于不包含重复关键字的容器，添加单一元素的`insert`和`emplace`版本返回一个`pair`，表示操作是否成功。`pair`的`first`成员是一个迭代器，指向具有给定关键字的元素；`second`成员是一个`bool`值。如果关键字已在容器中，则`insert`直接返回，`bool`值为`false`。如果关键字不存在，元素会被添加至容器中，`bool`值为`true`。
- 对于允许包含重复关键字的容器，添加单一元素的`insert`和`emplace`版本返回指向新元素的迭代器。
```c++
pair<iterator, bool> insert(const value_type& val);  
iterator insert(const_iterator posHint, const value_type& val); // posHint 是提示，指出查找起点用来提高效率

template <typename...Args>
pair<iterator, bool> emplace (Args&&... args); 
template <typename...Args> // posHint 是提示，指出查找起点用来提高效率
iterator emplace_hint (const_iterator posHint, Args&&... args);

c.insert(begin, end);
c.insert({...});
```
关联容器提供了`erase`操作。若它接受一个`key_type`参数，删除所有匹配给定关键字的元素（如果存在），返回实际删除的元素数量。对于不包含重复关键字的容器，`erase`的返回值总是1或0。若返回值为0，则表示想要删除的元素并不在容器中。若它接收迭代器参数，则返回一个迭代器指向其后继元素。
但在 C++11 之前，关联式容器的 erase 函数不返回任何东西（返回类型为void），这是为了效率。在一个关联式容器内查找元素并返回其后继者，可能会花不少时间，因为容器被实现为一个 binary tree，这会大幅增加上述事情的复杂度。
`lower_bound`和`upper_bound`操作都接受一个关键字，返回一个迭代器。如果关键字在容器中，`lower_bound`返回的迭代器会指向第一个匹配给定关键字的元素（>=），而`upper_bound`返回的迭代器则指向最后一个匹配元素之后的位置(>)。如果关键字不在`multimap`中，则`lower_bound`和`upper_bound`会返回相等的迭代器，指向一个不影响排序的关键字插入位置。因此用相同的关键字调用`lower_bound`和`upper_bound`会得到一个迭代器范围，表示所有具有该关键字的元素范围。
`equal_range`操作接受一个关键字，返回一个迭代器`pair`。若关键字存在，则第一个迭代器指向第一个匹配关键字的元素，第二个迭代器指向最后一个匹配元素之后的位置。若关键字不存在，则两个迭代器都指向一个不影响排序的关键字插入位置。


Map和multimap的元素类型Key和T必须满足以下两个条件：
- Key和value都必须是copyable或movable
- 对指定的排序准则而言，key必须是comparable
`map`下标运算符接受一个关键字，获取与此关键字相关联的值。如果关键字不在容器中，下标运算符会向容器中添加该关键字，并值初始化关联值。由于下标运算符可能向容器中添加元素，所以只能对非`const`的`map`使用下标操作。
对`map`进行下标操作时，返回的是`mapped_type`类型的对象；解引用`map`迭代器时，返回的是`value_type`类型的对象。
不可以指定一个不具 default 构造函数的 value 类型。这种元素安插方式比惯常的 map 安插方式慢，原因是新元素必须先使用 default 构造函数将value 初始化，而该初值马上又被真正的 valu e覆盖。
> 基础类型都有一个 default 构造函数，设立初值 0。

将 value 传入 map 或 multimap 内：
```c++
coll.insert({"otto", 22.3});
// 为了避免隐式类型转换，可以利用value_type明白传递正确类型。value_type是容器本身提供的类型定义：
std::map<std::string, float> coll;
coll.insert(std::map<std::string, float>::value_type("otto", 22.3));
coll.insert(decltype(coll)::value_type("otto", 22.3));

// 运用pair<>
std::map<std::string，float> coll；
coll.insert(std::pair<std::string, float>("otto", 22.3)); // use implicit conversion
coll.insert(std::pair<const std::string, float>("otto", 22.3)); // use no implicit conversion
// 上述第一个insert语句内的类型并不正确，所以会被转换成真正的元素类型。为了做到这一点，insert成员函数被定义为member template

// 运用make_pair：
std::map<std::string, float> coll;
coll.insert(std::make_pair("otto", 22.3)); // 此处也是利用member template insert执行必要的类型转换

// 使用emplace安插新元素，并且传值进去以便构建该新元素时，必须传递两列实参进去：一列为了key，另一列为了元素
std::map<std::string,std::complex<float>> m; 
m.emplace(std::piecewise_construct, std::make_tuple("he11o"), std::make_tuple(3.4, 7.8));
```
## Unordered Container
unordered 容器以一种随意顺序包含安插进去的所有元素。所以，相比于set和map，这里不需要排序准则；相比于sequence容器，没有语义可用来放元素到某个特定位置。
接口：
```c++
template<
    class Key,                          // 第一个模板参数是key类型
    class T,                            // 第二个模板参数是元素类型
    class Hash = std::hash<Key>,        // 计算散列值的函数对象
    class KeyEqual = std::equal_to<Key> // 相等比较函数
> class unordered_map; 
```
通常C++标准库并不指明所有实现细节，但unordered容器仍有若干被具体指明的性质，基于以下假设：
- 这些hash table使用chaining做法，于是一个hash code将被关联至一个linked list（open hashing或closed addressing）
- 上述那些linked list是单链或双链，取决于实现。C++standard只保证它们的iterator至少是forward iterator。
- 关于rehashing（重新散列），有各式各样的实现策略：
- - 传统做法是，在单一insert或erase动作出现时，有时会发生一次内部数据重新组织。
  - 所谓递进式做法是，渐进改变bucket或slot的数量，这对即时环境特别有用，因为在其中突然放大hash table的代价也许太高。
- 对于每个将被存放的value，hash function会把它映射至hash table内某个 bucket 中。每个 bucket 管理一个单向 linked list，内含所有会造成hash function产出相同数值的元素。
![image-20230225125908688](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230225125908688.png)
Unordered容器比起寻常的associative容器，也有若干缺点：
- 不提供operator>、<、<=和>=用以安排 order 这些容器的多重实例。然而提供了`==`和`!=`。
- 不提供lower_bound和upper_bound。
- 由于iterator只保证至少是个forward iterator，因此反向iterator包括rbegin、rend、crbegin和crend都不提供，不能够使用那种要求获得bidirectional iterator的算法。
- 由于元素的 key/value 具体关系到元素的位置——这里指的是bucket entry——不可以直接改动元素的 key/value。因此，很像associative容器那样，欲改动一个元素的value，你必须先移除拥有旧value的元素，然后安插一个拥有新value的新元素。这个接口反映出以下行为：
- - Unordered容器不提供直接元素访问操作
  - 通过iterator进行的间接访问有其束缚：从iterator的角度观之，元素的 key/value 是常量
  >上述中，key 指的是 map，value 指的是 set

可以指定若干会影响hash table行为的参数：
- 指定bucket的最小数量
- 提供自己的hash function
- 提供自己的等价准则（equivalence criterion）：它必须是个predicate（判断式），用来在bucket list的所有数据项中找出准确的元素。
- 指定一个最大负载系数（maximum load factor），一旦超过就会自动rehashing
- 可以强迫rehashing
但是不能够影响以下行为：
- 成长系数，那是自动rehashing时用来成长或缩小list of buckets的系数
- 最小负载系数，用来强制进行rehashing（当容器中的元素个数缩减）。
rehashing只可能发生在以下调用之后：insert、rehash、reserve或clear。这是以下保证的自然结果：erase绝不会造成指向元素的iterator、reference和pointer失效。因此，如果删除数百个元素，bucket的大小并不会改变。但如果在那之后安插一个元素，bucket的大小就有可能缩小。
在那些支持等价 key 的容器内，也就是说在 unordered multiset 和 multimap 内，带有等价 key 的元素将会被相邻排列。Rehashing以及其他可能于内部改变元素次序”的操作，都会维持带有等价key的元素的相对次序。
```c++
c.hash_function(); // 返回hash函数 
c.key_eq(); // 返回“相等性判断式”（equivalence predicate） 
c.bucket_count(); // 返回当前的bucket个数
c.max_bucket_count(); // 返回bucket的最大可能数量
c.load_factor(); // 返回当前的负载系数（load factor） 
c.max_load_factor(); // 返回当前的最大负载系数（maximum load factor） 
c.max_load_factor(val); // 设定最大负载系数（maximum load factor）为val 
c.rehash(bnum); // 将容器rehash，使其bucket个数至少为bnum 
c.reserve(num); // 将容器rehash，使其空间至少可拥有num个元素（始自C++11)
```
不可以指定最大负载系数成为类型的一部分，或是通过一个构造函数实参指定它。欲指定最大负载系数，必须在构建后立刻调用max_load_factor。
传递给max_load_factor的实参必须是个float。通常0.7～0.8是速度和内存消耗量之间一个不错的折中。注意，默认的最大负载系数是1.0，意思是通常碰撞会在rehash之前发生。基于此，如果很重视速度，应该总是明确地设置最大负载系数。
成员函数rehash和reserve也很重要提供rehash一个unordered容器（也就是改变bucket个数）的功能：
- rehash要求为hash table提供bucket的大小至少是传入的大小。以此接口必须考虑最大负载系数。如果最大负载系数是0.7而打算准备100个元素，必须将100除以0.7，以此计算只要没超过100个元素就一定不会引发rehashing的大小。也就是说，必须传入143给rehash以避免在最高达到100个元素的情况下出现进一步rehashing。
- 如果使用reserve，这一计算是内部进行的，所以可以仅仅传递hash table应该筹备的元素个数。
```c++
coll.rehash(100);//prepare for 100/max_load_factor()elements 
coll.reserve(100);//prepare for 100 elements (sinceC++11)
```
对于模板参数：
- 所有hash table都需要一个hash函数，把放进去的元素的value映射至某个相关的bucket。它的目标是，两个相等的value总是导致相同的bucket索引，而不同的value理应导致不同的bucket索引。
  对于任何范围的value，hash函数应该提供良好的hash value分布。hash函数必须是个函数，或function object，它接受一个元素类型下的value作为参数，并返回一个类型为std::size_t的value。因此，bucket的当前数量并未被考虑。将其返回值映射至合法的bucket索引范围内，是由容器内部完成。因此，目标是提供一个函数，可把不同的元素值均匀映射至区间`[0，size_t)`内。	
- 作为 unordered 容器类型的第三或第四template 参数，可以传递等价准则，那是个predicate（判断式），用以找出同一个bucket内的相等value。默认使用的是equal_to<>，它以`operator==`进行比较，因此可以为自己的类型提供`operator==`，也可以提供等价准则而不提供`operator==`
对于unordered set，从iterator的角度观之，所有元素都被视为const。对于unordered map，所有元素的key都被视为const。这是必要的，确保不会因为改变元素的value而危及元素位置。虽然元素之间无定序，但value会在当前hash函数的作用下决定其所属的bucket位置。基于这个因素，不可以为元素调用任何更易型算法。例如不可以调用算法remove，因为它的移除动作是以后继元素覆盖掉被移除元素。如果真想要在unordered set/multiset内移除元素，唯一可使用的是容器提供的成员函数。
![image-20230225151941295](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230225151941295.png)
