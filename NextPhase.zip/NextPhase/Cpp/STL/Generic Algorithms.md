# Generic Algorithms
## Overview
大多数算法都定义在头文件`algorithm`中，此外标准库还在头文件`numeric`中定义了一组数值泛型算法。一般情况下，这些算法并不直接操作容器，而是遍历由两个迭代器指定的元素范围进行操作。
`find`函数将范围中的每个元素与给定值进行比较，返回指向第一个等于给定值的元素的迭代器。如果无匹配元素，则返回其第二个参数来表示搜索失败。
```c++
int val = 42;   // value we'll look for
// result will denote the element we want if it's in vec, or vec.cend() if not
auto result = find(vec.cbegin(), vec.cend(), val);
// report the result
cout << "The value " << val
    << (result == vec.cend() ? " is not present" : " is present") << endl;
```
迭代器参数令算法不依赖于特定容器，但依赖于元素类型操作。
泛型算法本身不会执行容器操作，它们只会运行于迭代器之上，执行迭代器操作。算法可能改变容器中元素的值，或者在容器内移动元素，但不会改变底层容器的大小（当算法操作插入迭代器时，迭代器可以向容器中添加元素，但算法自身不会进行这种操作）。
大多数算法的形参模式是以下四种形式之一：
```c++
alg(beg, end, other args);
alg(beg, end, dest, other args);
alg(beg, end, beg2, other args);
alg(beg, end, beg2, end2, other args);
```
其中`alg`是算法名称，`beg`和`end`表示算法所操作的输入范围。几乎所有算法都接受一个输入范围，是否有其他参数依赖于算法操作。`dest`表示输出范围，`beg2`和`end2`表示第二个输入范围。
接受谓词参数的算法都有附加的`_if`后缀。
```c++
find(beg, end, val);       // find the first instance of val in the input range
find_if(beg, end, pred);   // find the first instance for which pred is true
```
将执行结果写入额外目的空间的算法都有`_copy`后缀。
```c++
reverse(beg, end);              // reverse the elements in the input range
reverse_copy(beg, end, dest);   // copy elements in reverse order into dest
```
## Read-Only Algorithms
### accumulate
`accumulate`函数（定义在头文件`numeric`中）用于计算一个序列的和。它接受三个参数，前两个参数指定需要求和的元素范围，第三个参数是和的初值（决定加法运算类型和返回值类型）。
```c++
// sum the elements in vec starting the summation with the value 0
int sum = accumulate(vec.cbegin(), vec.cend(), 0);
string sum = accumulate(v.cbegin(), v.cend(), string(""));
// error: no + on const char*
string sum = accumulate(v.cbegin(), v.cend(), "");
```
### equal
`equal`函数用于确定两个序列是否保存相同的值。它接受三个迭代器参数，前两个参数指定第一个序列范围，第三个参数指定第二个序列的首元素。`equal`函数假定第二个序列至少与第一个序列一样长。
```c++
// roster2 should have at least as many elements as roster1
equal(roster1.cbegin(), roster1.cend(), roster2.cbegin());
```
只接受单一迭代器表示第二个操作序列的算法都假定第二个序列至少与第一个序列一样长。
### random_shuffle
random_shuffle( )接受两个指定区间的迭代器参数，并随机排列该区间中的元素。与可用于任何容器类的for_each不同，该函数要求容器类允许随机访问，vector类可以做到这一点。
### for_each
for_each( )接受3个参数。前两个是定义容器中区间的迭代器，最后一个是指向函数的指针（更普遍地说，最后一个参数是一个函数对象）。
for_each( )函数将被指向的函数应用于容器区间中的各个元素。被指向的函数不能修改容器元素的值。可以用for_each( )函数来代替for循环。
```c++
vector<Review>::iterator pr;
for (pr = s.begin(); pr != s.end(); pr ++) Show(*pr);

for_each(s.begin(), s.end(), Show); 
for (auto x : s) Show(x);

vector<int> v = {3,5,1,7,10};   // vector容器

for(const auto& x : v) {        // range for循环
    cout << x << ",";
}

auto print = [](const auto& x)  // 定义一个lambda表达式
{
    cout << x << ",";
};
for_each(cbegin(v), cend(v), print);// for_each算法

for_each(                      // for_each算法，内部定义lambda表达式
    cbegin(v), cend(v),        // 获取常量迭代器
    [](const auto& x)          // 匿名lambda表达式
    {
        cout << x << ",";
    }
);
```
### generate
generate()接受一个区间（由前两个参数指定），并将每个元素设置为第三个参数返回的值，而第三个参数是一个不接受任何参数的函数对象。
### count_if
count_if()与generate( )一样，前两个参数应指定区间，而第三个参数应是一个返回true或false的函数对象。函数count_if()计算这样的元素数，即它使得指定的函数对象返回true。
### find_if
```c++
template<typename Iterator, typename Compare>
Iterator my_find_if(Iterator st, Iterator ed, Compare cmp) {
    for (; st != ed; st++) if (cmp(*st)) return st;
    return ed;
}
```
### lower_bound/upper_bound
`lower_bound`和 `upper_bound` 需要用在一个有序数组或容器中，如果是数组，则返回该位置的指针；如果是容器，则返回该位置的迭代器。
`lower_bound`用来寻找在数组或容器的［first，last）范围内第一个值大于等于 val 的元素的位置。
`upper_bound`用来寻找在数组或容器的［first，last）范围内第一个值大于 val 的元素的位置（可以找到某数最后一次出现的位置的后一个位置）。
如果数组或容器中没有需要寻找的元素，则均返回可以插入该元素的位置的指针或迭代器（即假设存在该元素时，该元素应当在的位置）。
```c++
//在有序 int 数组：
int I = lower_bound(a + 1, a + 1 + n , x ) - a;//查找大于 x 的最小整数的下标
int* I = lower_bound(a + 1, a + 1 + n , x ); //返回第一个大于等于 x 的元素的指针，因为返回的是指针，所以 int类型存储地址
int I = *lower_bound(a + 1, a + 1 + n , x ); //返回第一个大于等于 x 的值，因为返回的是指针，所以*取该地址下的值可以赋值给整形 y

//在有序 vector<int> ：
int y = upper_bound(a.begin(), a.end(), x)-a.begin();//查找大于 x 的最小整数的下标
int* y = upper_bound(a.begin(), a.end(), x); //返回第一个大于 x 的元素的指针，因为返回的是指针，所以 int*类型存储地址
int y = *upper_bound(a.begin(), a.end(), x);  //查找大于 x 的最大整数，假设一定存在，因为返回的是指针，所以*取该地址下的值可以赋值给整形 y
```
显然，如果只是想获得欲查元素的下标，就可以不使用临时指针，而直接令返回值减去数组首地址即可：
```c++
int a[10]={1, 2, 2, 3, 3, 3, 5, 5, 5, 5}; //注意数组下标从0开始//寻找3
printf ("&d, d\n", 
        lower bound (a, a + 10, 3) - a, 
        upper bound (a, a + 10, 3) — a);
return 0；
```
### next\_permutation()
next＿permutation 给出一个序列在全排列中的下一个序列。例如，当n＝3时的全排列为123 132 213. 231 312 321，这样231的下一个序列就是312。示例如下：
```c++
int a[10] = {1, 2,3};
do { 
    printf("%d%d%d\n", a[0], a[1], a[2]); 
} while(next_permutation(a, a + 3)); 
```
输出结果： 123 132 213 231 312 321
在上述代码中，使用循环是因为next＿permutation在已经到达全排列的最后一个时会返回 false，这样会方便退出循环。而使用do···while 语句而不使用while语句是因为序列123本 身也需要输出，如果使用while会直接跳到下一个序列再输出，这样结果会少一个123。
## Write Container Elements
### fill
`fill`函数接受两个迭代器参数表示序列范围，还接受一个值作为第三个参数，它将给定值赋予范围内的每个元素。
```c++
// reset each element to 0
fill(vec.begin(), vec.end(), 0);
```
`fill_n`函数接受单个迭代器参数、一个计数值和一个值，它将给定值赋予迭代器指向位置开始的指定个元素。
```c++
// reset all the elements of vec to 0
fill_n(vec.begin(), vec.size(), 0);
```
向目的位置迭代器写入数据的算法都假定目的位置足够大，能容纳要写入的元素。
### back_inserter
`back_inserter`函数（定义在头文件`iterator`中）接受一个指向容器的引用，返回与该容器绑定的插入迭代器。通过此迭代器赋值时，赋值运算符会调用`push_back`将一个具有给定值的元素添加到容器中。
插入迭代器是一种向容器内添加元素的迭代器。通过插入迭代器赋值时，一个与赋值号右侧值相等的元素会被添加到容器中。
```c++
vector<int> vec;    // empty vector
auto it = back_inserter(vec);   // assigning through it adds elements to vec
*it = 42;   // vec now has one element with value 42
// ok: back_inserter creates an insert iterator that adds elements to vec
fill_n(back_inserter(vec), 10, 0);  // appends ten elements to vec
```
### copy
`copy`函数接受三个迭代器参数，前两个参数指定输入序列，第三个参数指定目的序列的起始位置。它将输入序列中的元素拷贝到目的序列中，返回目的位置迭代器（递增后）的值。copy( )函数将覆盖目标容器中已有的数据，同时目标容器必须足够大，以便能够容纳被复制的元素。
```c++
int a1[] = { 0,1,2,3,4,5,6,7,8,9 };
int a2[sizeof(a1) / sizeof(*a1)];     // a2 has the same size as a1
// ret points just past the last element copied into a2
auto ret = copy(begin(a1), end(a1), a2);    // copy a1 into a2
```
### replace
`replace`函数接受四个参数，前两个迭代器参数指定输入序列，后两个参数指定要搜索的值和替换值。它将序列中所有等于第一个值的元素都替换为第二个值。
```c++
// replace any element with the value 0 with 42
replace(ilst.begin(), ilst.end(), 0, 42);
```
相对于`replace`，`replace_copy`函数可以保留原序列不变。它接受第三个迭代器参数，指定调整后序列的保存位置。
```c++
// use back_inserter to grow destination as needed
replace_copy(ilst.cbegin(), ilst.cend(), back_inserter(ivec), 0, 42);
```
很多算法都提供“copy”版本，这些版本不会将新元素放回输入序列，而是创建一个新序列保存结果。
### transform
```c++
// 通用的解除指针引用的函数子类，与 transform 和 ostream＿iterator 一起使用：
struct Dereference {
    template<typename T>
    const T& operator()(const T *ptr) const { // 当向该类型的函数子传入T*时，它们返回const T＆
        return *ptr; 
    }
};
// 通过解除指针引用，转换 ssp 中的每个元素，并把结果写到cout
transform(ssp.begin(), ssp.end(), ostream_iterator<string>(cout, "\n"), Dereference());
```
## Reorder Container Elements
常见问题对应的算法：
- 要求排序后仍然保持元素的相对顺序，应该用 stable_sort，它是稳定的；
- 选出前几名（TopN），应该用 partial_sort；
- 选出前几名，但不要求再排出名次（BestN），应该用 nth_element；
- 中位数（Median）、百分位数（Percentile），还是用 nth_element；
- 按照某种规则把元素划分成两组，用 partition；第一名和最后一名，用 minmax_element。
```c++
// top3
std::partial_sort(
    begin(v), next(begin(v), 3), end(v));  // 取前3名

// best3
std::nth_element(
    begin(v), next(begin(v), 3), end(v));  // 最好的3个

// Median
auto mid_iter =                            // 中位数的位置
    next(begin(v), v.size()/2);
std::nth_element( begin(v), mid_iter, end(v));// 排序得到中位数
cout << "median is " << *mid_iter << endl;
    
// partition
auto pos = std::partition(                // 找出所有大于9的数
    begin(v), end(v),
    [](const auto& x)                    // 定义一个lambda表达式
    {
        return x > 9;
    }
); 
for_each(begin(v), pos, print);         // 输出分组后的数据  

// min/max
auto value = std::minmax_element(        //找出第一名和倒数第一
    cbegin(v), cend(v)
);
```
在使用这些排序算法时，还要注意一点，它们对迭代器要求比较高，通常都是随机访问迭代器，所以最好在顺序容器 array/vector 上调用。
如果是 list 容器，应该调用成员函数 sort()，它对链表结构做了特别的优化。有序容器 set/map 本身就已经排好序了，直接对迭代器做运算就可以得到结果。而对无序容器，则不要调用排序算法，散列表结构的特殊性质，导致迭代器不满足要求、元素无法交换位置。
### sort
`sort`函数接受两个迭代器参数，指定排序范围。它利用元素类型的`<`运算符重新排列元素。另一种格式接受3个参数，前两个参数也是指定区间的迭代器，最后一个参数是指向要使用的函数的指针（函数对象）。
> 稳定排序函数`stable_sort`可以维持输入序列中相等元素的原有顺序。
```c++
void elimDups(vector<string> &words)
{
    // sort words alphabetically so we can find the duplicates
    sort(words.begin(), words.end());
    // unique reorders the input range so that each word appears once in the
    // front portion of the range and returns an iterator one past the unique range
    auto end_unique = unique(words.begin(), words.end());
    // erase uses a vector operation to remove the nonunique elements
    words.erase(end_unique, words.end());
}
```
### unique
`unique`函数重排输入序列，消除相邻的重复项，返回指向不重复值范围末尾的迭代器。
利用迭代器（或指针）的减法，可计算出去重后的元素个数：
```c++
int m = unique(a.begin(), a.end()) – a.begin();
int m = unique(a + 1, a + 1 + n) - (a + 1);
```
### nth\_element
```c++
nth_element(a+x,a+x+y,a+x+len);
```
执行之后数组 a 下标 x 到 x+y-1 的元素都小于 a\[x+y],下标 x+y+1 到 x+len-1 的元素都大于 a\[x+y]，但不保证数组有序。
此时 a\[x+y] 就是数组区间 x 到 x+len-1 中第 y 小的数,当然也可以自己定义 cmp 函数。