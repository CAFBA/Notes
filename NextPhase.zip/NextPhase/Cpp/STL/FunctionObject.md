# Function Object
## Function Object
### Sorting Criterion
```c++
class PersonSortCriterion {
  ...  
};
set<Person, PersonSortCriterion> coll;
```
coll 构造函数会自动产生 class PersonSortCriterion 的一个实例，所有元素都将以此为排序准则进行排序。排序准则 PersonSortCriterion 是个 class，所以可以把它当作 set 的 template 实参。如果以寻常函数担任排序准则，就无法做到这一点。
### Internal State
Function Object 能够行为像个函数同时又拥有多个状态：
```c++
class IntSequence {
private: 
    int value; 
public:
    IntSequence (int initialValue) : value(initialValue) {}
    int operator()() { return ++value; }
};

list<int> col1;
// 以 1 为初值创建一个Function Object来产生数值并以back_inserter的方式写入容器coll。
// generate_n()算法前后共 9 次运用 Function Object 写入元素值，而它也产生了数值 2～10
generate_n(back_inserter(coll), 9, IntSequence(1)); // generates values,starting with 1 

// 以 42 为初值的Function Object。generate()算法运用这些值改写了自第二个开始，至倒数第二个元素
generate(next(coll.begin()), prev(coll.end()), IntSequence(42)); //generates values,starting with 42
```
默认情况下 Function Object 是 passed by value，不是 passed by reference，因此算法并不会改变 Function Object 的状态。例如以下产生的两个 Function Object 都从 1 开始：
```c++
IntSequence seq(1);
generate_n(back_inserter(coll), 9, seq);
generate_n(back_inserter(coll), 9, seq);
```
将函数对象以 by value 传递的好处是，可以传递常量表达式或暂态表达式。如果不这么设计，就不可能传递IntSequence(1)，这是个暂态表达式。
至于缺点就是，无法改变 Function Object 的状态。算法当然可以改变 Function Object 的状态，但无法取得并处理其最终状态，因为算法所改变的只是 Function Object 的拷贝而已。然而有时候的确需要其最终状态，问题在于如何从一个算法中获得运算后的结果。
有三个办法可以从运用 Function Object 的算法中获取结果或反馈：
1. 在外部持有状态，并让 Function Object 指向它。
2. 以 by reference 方式传递Function Object。
3. 利用 for_each() 算法的返回值。
#### ByRef
为了以by reference方式传递Function Object，需要在调用算法时标示 Function Object 是 reference 类型。例如：
```c++
list<int> coll;
IntSequence seq(1); // integral sequence starting with 1 

// insert values from 1 to 4
// pass Function Object by reference 
// so that it will continue with 5
generate_n<back_insert_iterator<list<int>>, int, IntSequence&>(back_inserter(coll), 4, seq); // 2 3 4 5 

//insert values from 42 to 45
generate_n(back_inserter(coll), 4, IntSequence(42)); // 2 3 4 5 43 44 45 46

// continue with first sequence 
// pass Function Object by value 
// so that it will continue with 5 again 
generate_n (back_inserter(coll), 4, seq); // 2 3 4 5 43 44 45 46 6 7 8 9 

//continue with first sequence again 
generate_n (back_inserter(coll), 4, seq); // 2 3 4 5 43 44 45 46 6 7 8 9 6 7 8 9 
```
#### for_each()
for_each() 可以传回其Function Object，可以通过 for_each() 的返回值来获取 Function Object 的状态。下面是一个使用for_each()返回值的例子，用来处理一个序列的平均值：
```c++
class MeanValue {
private: 
    long num;
    long sum;
public:
    MeanValue(): num(0), sum(0){ }
    void operator()(int elem) { 
        sum += elem;
        ++num;
    }
    double value () {
        return static_cast<double>(sum) / static_cast<double>(num); 
    }
};

vector<int> coll = {1,2,3,4,5,6,7,8}; //process and print mean value
MeanValue mv = for_each(coll.begin(), coll.end(), MeanValue());
cout << "mean value:" << mv.value() << endl;
```
### Predicate
谓词是一个可调用的表达式，其返回结果是一个能用作条件的值。标准库算法使用的谓词分为一元谓词（unary predicate，接受一个参数）和二元谓词（binary predicate，接受两个参数）。接受谓词参数的算法会对输入序列中的元素调用谓词，因此元素类型必须能转换为谓词的参数类型。
```c++
// comparison function to be used to sort by word length
bool isShorter(const string &s1, const string &s2)
{
    return s1.size() < s2.size();
}

// sort on word length, shortest to longest
sort(words.begin(), words.end(), isShorter);
```
对 STL 而言并非所有返回 Boolean 值的函数都是合法的 predicate。这可能会导致出人意料的行为。试看下例：
```c++
class Nth{
private:
    int nth;
    int count;
public:
    Nth(int n): nth(n), count(0){ }
    bool operator()(int) { return ++count == nth; }
};

list<int> coll = {1,2,3,4,5,6,7,8,9,10};
list<int>::iterator pos;
pos = remove_if(coll.begin(), coll.end(), Nth(3));
coll.erase(pos, coll.end());

// 1,2,4,5,7,8,9,10
```
两个元素——也就是第3和第6个元素——被移除。因为该算法的常见做法会在其内部保留predicate的一份拷贝：
```c++
template<typename ForwIter, typename Predicate> 
ForwIter std::remove_if(ForwIter beg, ForwIter end, Predicate op) {
    beg = find_if(beg, end, op); // 这里一个 op 副本
    if (beg == end) return beg;
    else {
        ForwIter next = beg;
        return remove_copy_if(++next, end, beg, op); // 这里又有一个 op 副本
    }
}
```
这个算法使用 find_if() 查找应被移除的第一个元素。然而，接下来它将**使用传入的 predicate op 的拷贝去处理剩余元素**，这时原始状态下的 Nth 再次被使用，因而会移除剩余元素中的第 3 个元素，也就是整体的第 6 个元素。
这种行为不能说是一种错误，因为 C++standard 并未明定 predicate 是否可被算法复制一份拷贝。因此，为了获得C++标准库的保证行为，你传递的Function Object其行为不应该因被复制次数或被调用次数而异。也就是说，如果你以两个相同的实参调用同一个 unary predicate，该式应该总是返回相同结果。
换句话说，predicate 不应该因为被调用而改变自身状态；predicate 的拷贝应该和其正本有着相同状态。要达到这一点，**一定得保证不能因为函数调用而改变 predicate 的状态，应当将 operator() 声明为const成员函数。**
其实完全可以避免这种尴尬结果，让算法和 Nth 这样的 Function Object 一起正常运作，而且效率不打折扣。可以这么实现 remove_if()：
```c++
template<typename ForwIter, typename Predicate> 
ForwIter std::remove_if(ForwIter beg, ForwIter end, Predicate op) {
    while(beg != end && op(*beg) == 0) ++beg;
    if (beg == end) return beg;
    else {
        ForwIter next = beg;
        return remove_copy_if(++next, end, beg, op);
    }
}
```
> 如果采用lambda，可以让Function Object的每一个拷贝共享状态，这个问题就不会发生。
## Functional
成员指针不是一个可调用对象，不支持函数调用运算符。
```c++
auto fp = &string::empty;   // fp points to the string empty function
// error: must use .* or ->* to call a pointer to member
find_if(svec.begin(), svec.end(), fp);
```
可以使用两种方式从成员函数指针获取可调用对象。
使用标准库模板`function`，定义一个`function`对象时，必须指定该对象所能表示的函数类型（即可调用对象的返回值和形参列表），而且如果可调用对象是一个成员函数（而不是函数对象），则该函数类型的**第一个形参必须表示该成员函数是在哪个对象上执行的**。因为**成员函数有隐式参数 this 指针，调用时需要传入对象或对象指针**：
```cpp
function<bool (const string&)> fcn = &string::empty;
find_if(svec.begin(), svec.end(), fcn);

class myClass {
public:
    bool myFnc(int t, double y) {
        cout << "function" << endl;
        cout << t << y << endl;
        return true;
    }
};
// 根据指定的函数类型，通过对象和指针调用（传入 this）
myClass test;
function<bool (myClass, int, double)> ftn = &myClass::myFnc;
ftn(test, 10, 100.0); // 通过对象调用  
function<bool (myClass*, int, double)> ftn = &myClass::myFnc;
ftn(&test, 10, 100.0); // 通过指针调用
```
第二种方式见[[FunctionObject#mem_fn()]]
### Use
C++语言中有几种可调用的对象：函数、函数指针、lambda表达式、bind创建的对象以及重载了函数调用运算符的类。 
和其他对象一样，可调用的对象也有类型。例如，每个lambda有它自己唯一的（未命名）类类型；函数及函数指针的类型则由其返回值类型和实参类型决定。然而，两个不同类型的可调用对象却可能共享同一种调用形式。调用形式指明了调用返回的类型以及传递给调用的实参类型。
一种调用形式对应一个函数类型，例如 `int(int, int)` 是一个函数类型，它接受两个int、返回一个int：
```c++
// 普通函数
int add(int i, int j) { return i + j; } 
// lambda，其产生一个未命名的函数对象类
auto mod = [](int i, int j) { return i % j; }; 
// 函数对象类
struct divide {
	int operator()(int denominator, int divisor) { 
    	return denominator / divisor;
};
```
可能希望使用这些可调用对象构建一个简单的桌面计算器。为了实现这一目的，需要定义一个函数表用于存储指向这些可调用对象的指针。当程序需要执行某个特定的操作时，从表中查找该调用的函数。 
在C++语言中，函数表很容易通过map来实现。对于此例来说，使用一个表示运算符符号的string对象作为关键字；使用实现运算符的函数作为值。当需要求给定运算符的值时，先通过运算符索引map，然后调用找到的那个元素。 
假定所有函数都相互独立，并且只处理关于int的二元运算，则map可以定义成如下的形式：
```c++
// 构建从运算符到函数指针的映射关系，其中函数接受两个int、返回一个int
map<string, int(*)(int, int)> binops;	
```
可以按照下面的形式将add的指针添加到binops中：
```c++
// 正确：add是一个指向正确类型函数的指针
binops.insert({"+", add}); // ｛＂＋＂，add｝是一个pair
```
但是不能将mod或者divide存入binops：
```c++
binops.insert({"%", mod}); // 错误：mod不是一个函数指针
```
问题在于mod是个lambda表达式，而每个lambda有它自己的类类型，该类型与存储在binops中的值的类型不匹配。
可以使用一个名为function的新的标准库类型解决上述问题，function定义在functional头文件中function是一个模板，当创建一个具体的function类型时必须提供额外的信息。在此例中，所谓额外的信息是指该function类型能够表示的对象的调用形式。
```c++
function<T> f; // f是一个用来存储可调用对象的空function
function<T> f(nul1ptr); // 显式地构造一个空 function
function<T> f(obj); // 在f中存储可调用对象obj的副本
if (f) {} //将f作为条件：当f含有一个可调用对象时为真；否则为假
f(args) // 调用f中的对象，参数是args
    
// 定义为 function＜T＞的成员的类型
result_type // 该function类型的可调用对象返回的类型
argument_type // 当T有一个或两个实参时定义的类型。如果T只有一个实参，则 argument＿type 是该类型的同义词
// 如果T有两个实参，则 first_argument_type 和 second_argument_type 分别代表两个实参的类型
first_argument_type
second_argument_type
```
在这里声明了一个function类型，它可以表示接受两个int、返回一个int的可调用对象。因此，可以用这个新声明的类型表示任意一种桌面计算器用到的类型；
```c++
function<int(int, int)> f1 = add; // 函数指针 
function<int(int, int)> f2 = divide(); // 函数对象类的对象
function<int(int, int)> f3 = [](int i, int j) { return i * j; }; 
cout << f1(4, 2) << endl;
cout << f2(4, 2) << endl;
cout << f3(4, 2) << endl;

// 使用这个function类型可以重新定义map：
// 列举了可调用对象与二元运算符对应关系的表格
// 所有可调用对象都必须接受两个int、返回一个int，其中的元素可以是函数指针、函数对象或者lambda
map<string, function<int(int, int)>> binops; 
```
能把所有可调用对象，包括函数指针、lambda或者函数对象在内，都添加到这个map中：
```c++
map<string, function<int(int, int)>> binops = { 
  {"+", add}, // 函数指针 
  {"-", std::minus<int>()}, // 标准库函数对象 
  {"/", divide()}, // 用户定义的函数对象
  {"*", [](int i, int j) { return i * j; }}, // 未命名的lambda 
  {"%", mod} // 命名了的lambda对象
};
```
map中包含5个元素，尽管其中的可调用对象的类型各不相同，仍然能够把所有这些类型都存储在同一个function类型中。 一如往常，当索引map时将得到关联值的一个引用。如果索引binops，将得到function对象的引用。function类型重载了调用运算符，该运算符接受它自己的实参然后将其传递给存好的可调用对象：
```c++
binops["+"](10, 5);
binops["-"](10, 5);
```
依次调用了binops中存储的每个操作。在第一个调用中，获得的元素存放着一个指向add函数的指针，因此调用`binops["+"](10, 5)`实际上是使用该指针调用add，并传入10和5。在接下来的调用中，binops["-"]返回一个存放着std::minus类型对象的function，将执行该对象的调用运算符。
不能（直接）将重载函数的名字存入function类型的对象中：
```c++
int add(int i, int j) { return i + j; }
Sales_data add(const Sales data&, const Sales_data&); 
map<string, function<int(int, int)>> binops;
binops.insert( {"+", add} ); // 错误：哪个add？
```
解决上述二义性问题的一条途径是存储函数指针而非函数的名字：
```c++
int (*fp) (int, int) = add; // 指针所指的add是接受两个int的版本
binops.insert({"+", fp}); // 正确：fp指向一个正确的add版本
```
同样，也能使用lambda来消除二义性：
```c++
// 正确：使用lambda来指定我们希望使用的add版本
binops.insert({"+", [](int a, int b){ return add(a,b); }}); 
```
lambda内部的函数调用传入了两个int，因此该调用只能匹配接受两个int的add版本，而这也正是执行lambda时真正调用的函数。
### Code
```c++
void doOne() {
    cout << "case 1" << endl;
};
void doTwo(int x) {
    cout << x << endl;
};

template <class T>
class myFunction {

};

template<class Ret, class... Args>
class myFunction <Ret(Args...)> {
public:
    using FUNC = Ret (*) (Args...);

    explicit myFunction(FUNC func): _func(func) {}

    myFunction(myFunction& other): _func(other._func) {}

    myFunction(myFunction&& other) noexcept {
        other.swap(*this);
    }

    Ret operator() (Args...args) {
        return _func(args...);
    }

    myFunction& operator=(myFunction rhs) {
        rhs.swap(*this);
        return *this;
    }

    void swap(myFunction& rhs) noexcept
    {
        using std::swap;
        swap(_func, rhs._func);
    }
private:
    FUNC _func;
};

myFunction<void()> fcn1([]() { cout << "ONew" << endl; });
fcn1();
myFunction<void(int)> fcn2(doTwo);
fcn2(10);
myFunction<void(int)> fcn3(fcn2);
fcn3 = fcn2;
fcn3(100);
```
## Reference Wrapper
对于一个给定类型T，class std::reference_wrapper 提供 ref 用以隐式转换为 T&，一个 cref 用以隐式转换为 const T&，这往往允许 function template 得以操作 reference 而不需要另写特化版本。
```c++
template <typename> void foo (T val); // 经由调用 
int x;
foo (std::ref(x));  // T 变成int&，而经由调用 
int x;
foo (std::cref(x)); // T 变成了const int&
```
class reference_wrapper使你得以使用reference作为最高级对象（first-class object），例如作为array或STL容器的元素类型：
```c++
std::vector<MyClass&> co1l; //Error 
std::vector<std::reference_wrapper<MyClass>> coll; //OK 
```
## Function Adapter
Function Adapter 是指能够将不同的 Function Object（或是和某值或某寻常函数）结合起来的东西，它自身也是个 Function Object。
### Binding Arguments
`bind`函数定义在头文件`functional`中，相当于一个函数适配器，用来将参数绑定于可调用对象，返回的结果是绑定参数后的函数对象。一般形式如下：
```c++
auto newCallable = bind(callable, arg_list);
```
`newCallable`本身是一个可调用对象，`arg_list`是一个以逗号分隔的参数列表，对应给定的`callable`的参数。之后调用`newCallable`时，`newCallable`会再调用`callable`，并传递给它`arg_list`中的参数。
`arg_list`中可能包含占位符，占据传递给`newCallable`的参数的位置，非占位符则是绑定到该调用对象的参数。数值`n`表示生成的可调用对象中参数的位置：`_1`为`newCallable`的第一个参数，`_2`为`newCallable`的第二个参数，依次类推。这些名字都定义在命名空间`placeholders`中，它又定义在命名空间`std`中，因此使用时应该进行双重限定。
```c++
using std::placeholders::_1;
using namespace std::placeholders;
bool check_size(const string &s, string::size_type sz);

// check6 is a callable object that takes one argument of type string
// and calls check_size on its given string and the value 6
auto check6 = bind(check_size, _1, 6);
string s = "hello";
bool b1 = check6(s);    // check6(s) calls check_size(s, 6)

// Function Object内部调用plus<>（也就是operator+），以占位符 _1 作为第一参数/操作数，以 10 作为第二参数/操作数
// 占位符_1与实际传入的第一个实参对应。于是，对于传给此表达式的任何实参，这个Function Object会产出实参 +10 的结果值
auto plus10 = std::bind(std::plus<int>(), _1, 10);
std::cout << "+10:" << plus10(7) << std::endl; 
std::cout << std::bind(std::plus<int>(), _1, 10)(32) << std::endl;

auto plus10times2 = std::bind(std::multiplies<int>(), std::bind(std::plus<int>(), _1, 10), 2);
std::cout << "+10 *2:" << plus10times2(7) << std::endl; 

auto pow3 = std::bind(std::multiplies<int>(), std::bind(std::multiplies<int>(), _1, _1), _1);
std::cout << "x*x*x:" << pow3(7) << std::endl;

// 将除法的实参互换。它拿第二实参去除以第一实参，占位符_2与实际传入的第二个实参对应
auto inversDivide = std::bind(std::divides<double>(), _2, _1); 
std::cout <<"invdiv: "<< inversDivide(49, 7) << std::endl; // _1 == 49，_2 == 7，因此
```
`bind`函数可以调整给定可调用对象中的参数顺序。
```c++
// sort on word length, shortest to longest
sort(words.begin(), words.end(), isShorter);
// sort on word length, longest to shortest
sort(words.begin(), words.end(), bind(isShorter, _2, _1));
```
默认情况下，`bind`函数的非占位符参数被拷贝到`bind`返回的可调用对象中。如果希望传递给`bind`一个对象而又不拷贝它，则必须使用标准库的`ref`函数。`ref`函数返回一个对象，包含给定的引用，此对象是可以拷贝的。`cref`函数生成保存`const`引用的类。
```c++
ostream &print(ostream &os, const string &s, char c);
for_each(words.begin(), words.end(), bind(print, ref(os), _1, ' '));

void incr(int& i) {
	i++;
}
int i = 0;
bind(incr, i)(); // i = 0
bind(incr, ref(i))(); // i = 1
```
#### GlobalFunc
```c++
char myToupper(char c) {
    std::locale loc;
    return std::use_facet<std::ctype<char>>(loc).toupper(c);
}

string s("Internationalization");
string sub("Nation");
string::iterator pos;
// 使用search()算法检验sub是否为s的一个子字符串，大小写不计
pos = search(s.begin(), s.end(), sub.begin(), sub.end(), 
             bind(equal_to<char>(), bind(myToupper, _1), bind(myToupper, _2)));

pos = search(s.begin(), s.end(), sub.begin(), sub.end(), 
             [] (char c1, char c2) { return myToupper(c1) == myToupper(c2); });

void show(string s) {
    cout << s << endl;
}

function<void (string)> fcn = bind(show, _1);
fcn("hello");
```
#### MemberFunc
```c++
class Person {
private:
    string name;
public:
    Person (const string& n) : name(n) {}
    void print () const {
        cout << name << endl;
    }
    void print2 (const string& prefix) const {
        cout << prefix << name << endl;
    }
};

vector<Person> coll = { Person("Tick"), Person("Trick"), Person("Track") };
for_each(coll.begin(), coll.end(), bind(&Person::print, _1));
for_each(coll.begin(), coll.end(), bind(&Person::print2, _1, "Person: ")); // param1.print2("Person: ")
// bind 使用对象 Person("nico") 调用
bind(&Person::print2, _1, "This is: ")(Person("nico")); // Person("nico").print2("This is: ")

for_each(coll.begin(), coll.end(), [](const Person& p) { p.print(); }); 
for_each(coll.begin(), coll.end(), [](const Person& p) { p.print2("Person:"); }); 
```
调用 virtual 成员函数也没问题。如果 base class 的某个成员函数被绑定，而调用它的是个 derived class 对象，正确的 derived class virtual 函数会被调用。
```c++
class A {
public:
    int sum(int a, int b) {
        return a + b;
    }
};
    
A fcnCall;
// 调用时需要传入 this 参数
cout << bind(&A::sum, fcnCall, 10, 20)() << endl;
cout << bind(&A::sum, &fcnCall, 10, 20)() << endl;
// 使用占位符
cout << bind(&A::sum, &fcnCall, placeholders::_1, 20)(10) << endl;

// 经过 bind 绑定后的函数对象，在 function 中不再需要指定对象类型 
function<int (int, int)> fcn = bind(&A::sum, fcnCall, placeholders::_1, placeholders::_2);
cout << fcn(10, 20) << endl;
```
注意，也可以传递 pointer to object 甚至 smart pointer 给 bind()：
```c++
std::vector<Person*> cp;
std::for_each(cp.begin(), cp.end(), std::bind(&Person::print, std::placeholders::_1)); 

std::vector<std::shared_ptr<Person>> sp;
std::for_each(sp.begin(), sp.end(), std::bind(&Person::print, std::placeholders::_1)); 

class Person { 
public: 
    void setName (const std::string& n) { 
        name = n;
    } 
};
// 也可以调用具改动能力的成员函数
std::vector<Person> coll; 
std::for_each(coll.begin(), coll.end(), std::bind(&Person::setName, std::placeholders::_1, "Paul"));
```
也可以把 binder 用在自定义的 Function Object 身上：
```c++
template <typename T1, typename T2> // 第一实参和返回值拥有相同的类型 T1，指数则可以拥有不同的类型 T2。
struct fopow { // fopow<>() 只对 float 和 int 有意义
    T1 operator() (T1 base, T2 exp) const { 
        return std::pow(base, exp);
    }
};

vector<int> coll = {1,2,3,4,5,6,7,8,9}; 
transform(coll.begin(), coll.end(), ostream_iterator<float>(cout, ""), bind(fopow<float, int>(), 3, _1));
transform(coll.begin(), coll.end(), ostream_iterator<float>(cout, ""), bind(fopow<float, int>(), _1, 3));
```
也可以绑定至数据成员：
```c++
map<string, int> coll;

// 使用一个binary predicate对所有元素求和 
int sum = accumulate(coll.begin(), coll.end(), 0,
    // 把每次调用 predicate 所传入的第二实参绑定为元素的数据成员 second
                    bind(plus<int>(), _1, 
                     bind(&map<string, int>::value_type::second, _2)));
// 由于容器是个map，其对元素的value的访问权，必须这么做：
bind(&map<string，int>::value_type::second, _2);
```
### mem_fn()
对于成员函数，可以改用 mem_fn()，那就不再需要以占位符表示调用者（对象）：
```c++
std::for_each(coll.begin(), coll.end(), std::mem_fn(&Person::print));
```
`mem_fn`可以**让编译器推断成员的类型**。和`function`一样，`mem_fn`可以从成员指针生成可调用对象，但`mem_fn`可以根据成员指针的类型推断可调用对象的类型，无须显式指定。
```c++
find_if(svec.begin(), svec.end(), mem_fn(&string::empty));
// mem_fn 生成的可调用对象可以通过对象和指针调用。
myClass test;
auto f = mem_fn(&myClass::myFnc); // f takes a myClass or a myClass*
f(&test, 10, 100.0); // ok: passes a myClass object; f uses .* to call myFnc
f(test, 10, 100.0);  // ok: passes a pointer to myClass; f uses .-> to call myFnc
```
若有额外实参被传给成员函数，则**第一实参作为调用对象，其他实参当作成员函数的实参**：
```c++
std::mem_fn(&Person::print)(n);// calls n.print ()
std::mem_fn(&Person::print2)(n, "Person: "); // calls n.print2("Person: ")
```
然而，如果要为 Function Object 绑定额外实参，还是必须使用 bind()：
```c++
for_each(coll.begin(), coll.end(), std::bind(std::mem_fn(&Person::print2), std::placeholders::_1, "Person: "));
```
### not1()和not2()
not1() 和 not2() 几乎可被视为过时。唯一用途是令预定义的 Function Object 的意义相反，例如：
```c++
std::sort(coll.begin(), coll.end(), std::not2(std::less<int>())); // 这看起来比下面简便多了：
std::sort(coll.begin(), coll.end(), std::bind(std::logical_not<bool>(), std::bind(std::less<int>(), _1, _2))); 
```
然而真实世界中并没有not1()和not2()真正可发挥的剧本，因为可以轻松选用另一个预定义的 Function Object：
```c++
std::sort(coll.begin(), coll.end(), std::greater_equal<int>());
```
更重要的是，not2()搭配 less 其实是错误的。或许想的是改变排序准则，从升序改为降序，但 < 的反相是 >=。事实上，greater_equal 甚至会导致不明确行为，因为 sort() 要求一个 strict weak ordering，< 满足条件，>= 则不然，因为它违反必须是反对称的条件。
```c++
greater<int>(); // 要不就传递
bind(less<int>(), _2, _1); // 要不就交换实参次序
```
### Deprecated
bind1st用于将operator()的第一个形参变量绑定成一个确定的值
```c++
template<typename Compare, typename T>
class my_bind1st_ret {
public:
    explicit my_bind1st_ret(Compare cmp, T val): _cmp(cmp), _val(val) {}
    bool operator()(const T& second) {
        return _cmp(_val, second);
    }
private:
    Compare _cmp;
    T _val;
};

template<typename Compare, typename T>
my_bind1st_ret<Compare, T> my_bind1st(Compare cmp, const T& val) {
    // 封装用于模板类型推导
    return my_bind1st_ret<Compare, T>(cmp, val);
}
// a > b 绑定第一个参数为 50，则得到第一个小于 50 的数
auto it = my_find_if(vec.begin(), vec.end(), my_bind1st(greater<int>(), 50));
```
bind2nd用于将operator()的第二个形参变量绑定成一个确定的值
```c++
template<typename Compare, typename T>
class my_bind2nd_ret {
public:
    explicit my_bind2nd_ret(Compare cmp, T val): _cmp(cmp), _val(val) {}
    bool operator()(const T& first) {
        return _cmp(first, _val);
    }
private:
    Compare _cmp;
    T _val;
};

template<typename Compare, typename T>
my_bind2nd_ret<Compare, T> my_bind2nd(Compare cmp, const T& val) {
    // 封装用于模板类型推导
    return my_bind2nd_ret<Compare, T>(cmp, val);
}
// a > b 绑定第二个参数为 50，则得到第一个大于 50 的数
auto it = my_find_if(vec.begin(), vec.end(), my_bind2nd(greater<int>(), 50));
```
ptr_fun()用来调用寻常的 Function Object：
```c++
bool check(int elem);
// 调用下面的语句找出第一个不通过检验的元素：
std::find_if(coll.begin(), coll.end(), std::not1(std::ptr_fun(check)));
// strcmp() C函数被用来比较每个元素是否等于empty C-string。因此，调用find_if()会返回第一个非空字符串的元素位置。
std::find_if(coll.begin(), coll.end(), std::bind2nd(std::ptr_fun(std::strcmp), ""));
```
## Predefined
标准库定义了一组表示算术运算符、关系运算符和逻辑运算符的类，每个类分别定义了一个执行命名操作的调用运算符：

| 逻辑              | 关系                | 算术             |
| ----------------- | ------------------- | ---------------- |
| `logical_and<Type>` | `equal_to<Type>`      | `plus<Type>`       |
| `logical_or<Type>`  | `not_equal_to<Type>`  | `minus<Type>`      |
| `logical_not<Type>` | `greater<Type>`       | `multiplies<Type>` |
|                   | `greater_equal<Type>` | `divides<Type>`    |
|                   | `less<Type>`          | `modulus<Type>`    |
|                   | `less_equal<Type>`    | `negate<Type>`     |
需要特别注意的是，标准库规定其函数对象对于指针同样适用。比较两个无关指针将产生未定义的行为，然而可能会希望通过比较指针的内存地址来sort指针的vector。直接这么做将产生未定义的行为，因此可以使用一个标准库函数对象来实现该目的
```c++
vector<string *> nameTable; // 指针的vector
// 错误：nameTable 中的指针彼此之间没有关系，所以＜将产生未定义的行为
sort(nameTable.begin(), nameTable.end(), [](string *a, string *b) { return a < b; }); 
// 正确：标准库规定指针的less是定义良好的
sort(nameTable.begin(), nameTable.end(), less<string*>()); 
```
> 关联容器使用less对元素排序，因此我们可以定义一个指针的set或者在map中使用指针作为关键值而无须直接声明less。
![img](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/26089_514_2.jpg)
对对象排序或比较时，默认以less<>为比较准则，因此默认的排序操作总是产生升序。Unordered容器的默认相等性准则是equal_to<>。

