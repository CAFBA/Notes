# Iterator
解引用迭代器可获得迭代器所指的对象，如果该对象的类型恰好是类，就有可能希望进一步访问它的成员。
```c++
(*it).empty(); // 解引用it，然后调用结果对象的empty成员
*it.empty();   // 错误：试图访问it的名为empty的成员，但it是个迭代器，没有empty成员
```
箭头运算符把解引用和成员访问两个操作结合在一起，也就是说，it->mem和 (\*it).mem表达的意思相同。
## Iterator Category
![img](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/dd25c3f074fe0b792dddecfd15f74e5a.png)
- 输入迭代器/输出迭代器：支持`==`、`!=`、`++`、`*`、`->`，只能单次访问，用于单遍扫描算法。如果一个类型像输入迭代器，但 \*i 只能作为左值来写而不能读，那它就是个输出迭代器。
- 前向迭代器：可以读写序列中的元素。只能在序列中沿一个方向移动。支持所有输入和输出迭代器的操作，而且可以多次读写同一个元素。因此可以使用前向迭代器对序列进行多遍扫描。
- 双向迭代器：可以正向/反向读写序列中的元素。除了支持所有前向迭代器的操作之外，还支持前置和后置递减运算符`--`。除`forward_list`与`unordered`之外的其他标准库容器都提供符合双向迭代器要求的迭代器。
- 随机访问迭代器：可以在常量时间内访问序列中的任何元素。除支持所有双向迭代器的操作之外，还必须支持以下操作：
  - 用于比较两个迭代器相对位置的关系运算符`<`、`<=`、`>`、`>=`。
  - 迭代器和一个整数值的加减法运算`+`、`+=`、`-`、`-=`，计算结果是迭代器在序列中前进或后退给定整数个元素后的位置。
  - 用于两个迭代器上的减法运算符`-`，计算得到两个迭代器的距离。
  - 下标运算符`[]`。
- 连续迭代器：一个随机访问迭代器 i 和一个整数 n，在 \*i 可解引用且 i + n 是合法迭代器的前提下，额外满足 `*(addressdof(*i) + n) == *(i + n)`，即保证迭代器指向的对象在内存里是连续存放的。
### Output
Output迭代器允许一步一步前行并搭配write动作。因此可以一个一个元素地赋值，不能使用output迭代器对同一区间迭代两次，甚至不保证可以将一个value赋值两次而其迭代器却不累进。
Output迭代器无须比较操作，无法检验output迭代器是否有效，或写入是否成功，唯一可做的就是写入、写入、再写入。通常，一批写入动作是以一个由额外条件定义出的特定output迭代器作为结束。
一个典型的pure output迭代器例子是：将元素写至标准输出设备。如果采用两个output迭代器写至屏幕，第二个字将跟在第一个字后面，而不是覆盖第一个字。另一个典型例子是inserter，那是一种用来将value插入容器内的迭代器：如果赋值一个value，其实是将它插入容器。如果随后写入第二个value，并不会覆盖第一个value，而是插入进去。
Output迭代器由 ostream、inserter 提供。
### Input
Input迭代器只能一次一个以前行方向读取元素，按此顺序一个个返回元素值。Input迭代器只能读取元素一次，如果你复制input迭代器，并令原input迭代器和新产生的拷贝都向前读取，可能会遍历到不同的值。
所有迭代器都具备input迭代器的能力，而且往往更强。Pure input迭代器的典型例子就是从标准输入设备（往往是键盘）读取数据。同一个值不会被读取两次。一旦从input stream读入一个字，下次读取时就会返回另一个字。
对于input迭代器，操作符`==`和`!=`只用来检查某个迭代器是否等于一个*past-the-end*迭代器（指向最末元素之下一位置）。没有任何保证说，两个迭代器如果都不是*past-the-end*迭代器，且指向不同位置，它们的比较结果会不相等。
Input迭代器 istream 由提供。
### Forward
Forward 迭代器是一种 input 迭代器且在前进读取时提供额外保证。和input迭代器不同的是，两个forward迭代器如果指向同一元素，`operator==`会获得true，如果两者都递增，会再次指向同一个元素。
Forward迭代器由 forward_list、Unordered container 提供。
然而标准库也允许unordered容器的实现提供bidirectional迭代器，如果forward迭代器履行了output迭代器应有的条件，那么它就是一个mutable forward迭代器，既可用于读取，也可用于写入。
### Bidirectional
Bidirectional迭代器在forward迭代器的基础上增加了向后迭代能力。换言之，它支持递减操作符，可一步一步后退
Bidirectional迭代器由 List、Set、Map、Multi 提供。
### Random-Access
Random-access迭代器在bidirectional迭代器的基础上增加了随机访问能力。因此它必须提供*iterator*算术运算（和寻常pointer的算术运算相当）。也就是说，它能增减某个偏移量、计算距离，并运用诸如＜和＞等关系操作符进行比较。只有在面对random-access迭代器时，才能以operator<作为循环结束与否的判断准则。
一般而言可以递增或递减临时性迭代器，但对于array、vector和string就不行。这种奇怪问题的产生原因是，vector、array和 string 的迭代器通常被实现为寻常pointer，而C++并不允许修改任何基础类型的临时值，但对于struct和class则允许。因此，如果迭代器被实现为寻常pointer，则编译失败；如果被实现为 class，则编译成功。
```c++
std::vector<int> coll;
// 编译++coll.begin可能会失败，实际情况取决于平台。但如果换用deque取代vector，就可以通过编译
if (coll.size() > 1) std::sort(++col1.begin(), coll.end()); 
```
为保证可移植，C++11提供了next，所以应该这么写：
```c++
std::vector<int> coll;
std::sort(std::next(coll.begin()), col1.end()); 
// 在C++11之前，必须使用一个辅助对象：
std::vector<int>::iterator beg = coll.begin(); 
std::sort(++beg, coll.end());
```
Random-access迭代器由 array、vector、deque、string、array 提供。
## Iterator Function
C++标准库为迭代器提供了一些辅助函数：advance、next、prev、distance和iter_swap。前四者提供给所有迭代器一些原本只有random access迭代器才有的能力：前进（或后退）**多个**元素，及处理迭代器之间的距离，最后一个辅助函数允许交换两个迭代器的value。
迭代器和指针类似，也可以前进和后退，但你不能假设它一定支持“++”“--”操作符，最好也要用函数来操作。
```c++
array<int, 5> arr = {0,1,2,3,4};  // array静态数组容器

auto b = begin(arr);          // 全局函数获取迭代器，首端
auto e = end(arr);            // 全局函数获取迭代器，末端

assert(distance(b, e) == 5);  // 迭代器的距离

auto p = next(b);              // 获取“下一个”位置
assert(distance(b, p) == 1);    // 迭代器的距离
assert(distance(p, b) == -1);  // 反向计算迭代器的距离

advance(p, 2);                // 迭代器前进两个位置，指向元素'3'
assert(*p == 3);
assert(p == prev(e, 2));     // 是末端迭代器的前两个位置
```
### Advance
advance可将迭代器的位置增加，增加幅度由实参决定，也就是说它令迭代器一次前进（或后退）多个元素。advance 没有返回值，而 operator+= 会返回新位置，所以后者可作为一个更大表达式的一部分。
```c++
void advance(InputIterator& pos, Dist n); // 注意是引用形参
// 令名称为pos的input迭代器前进（或后退）n个元素。
// 对bidirectional迭代器和random-access迭代器而言，n可为负值，表示向后退。
// Dist是个template类型。通常它必须是个整数类型，因为会调用诸如＜、++、--等操作，还要和0做比较。
```
advance 并不检查迭代器是否超过序列的end（因为迭代器通常不知道其所操作的容器，因此无从检查）。所以，调用advance有可能导致不明确行为——因为对序列尾端调用 operator++ 是一种未被定义的行为。
此函数总能根据迭代器种类采用最佳方案，这归功于它使用了 iterator trait。对于random-access 迭代器，此函数只是简单地调用 pos+=n，因此具有常量复杂度。对于其他任何类型的迭代器，则调用++pos（或--pos，如果n为负值）n次。因此，对于其他任何类型的迭代器，本函数具有线性复杂度。
如果希望程序可以轻松更换容器和迭代器种类，应该使用advance而不是operator+=。不过必须意识到，这么做可能是拿效能来冒险，因为将advance应用于不提供random-access迭代器的容器中，不太容易感受效能变差（但正是由于运行期效能不佳，random-access迭代器才会想要提供operator+=）。
### Next/Prev
C++11提供了两个新增的辅助函数，允许前进/向退后移动迭代器的位置。next()并不检查是否会跨越序列的end()。因此调用者必须自行担保其结果有效。prev()并不检查是否会跨越序列的begin()。因此调用者必须自行担保其结果有效。
```c++
ForwardIterator next(ForwardIterator pos);
ForwardIterator next(ForwardIterator pos, Dist n);
// 导致forward迭代器pos前进1或n个位置
// 如果处理的是bidirectional和random-access迭代器，n可为负值，导致后退（回头）移动
// Dist是类型iterator_traits<ForwardIterator>::difference_type
// 其内部将对一个临时对象调用advance(pos，n)

BidirectionalIterator prev(BidirectionalIterator pos);
BidirectionalIterator prev(BidirectionalIterator pos, Dist n);
// 导致bidirectional迭代器pos后退1或n个位置，n可为负值，导致向前移动
// Dist是类型iterator_traits<BidirectionalIterator>::difference_type
// 其内部将对一个临时对象调用advance(pos, -n)
```
举个例子，这些辅助函数允许走过容器，只要检查了下一个元素：
```c++
auto pos = coll.begin();
// 不要忘记确保手上是个有效位置（在使用它之前）。基于这个原因，在检查下一个位置之前先检查pos是否等于coll.end
while(pos != coll.end() && std::next(pos) != coll.end()) ++pos; 

// 这么做特别有帮助，因为forward和bidirectional迭代器不提供operator+和operator-
// 如果没有它们，就需要一个临时对象的协助：
auto pos = coll.begin(); 
auto nextPos = pos; 
++nextPos;
while(pos != coll.end() && nextPos != coll.end()) {
    ++pos;
	++nextPos;
}
// 或者必须限制只使用random—access迭代器：
while(pos != coll.end() && pos + 1 != coll.end()) ++pos;
```
next()和prev()的第二个应用是避免诸如++coll.begin()这样的表达式需要去处理容器的第二元素。
next()的第三个应用是它能搭配forward_list和before_begin()。
### Distance
函数distance()用来处理两个迭代器之间的距离：
```c++
Dist distance(InputIterator pos1, InputIterator pos2);
// 返回两个input迭代器pos1和pos2之间的距离
// 两个迭代器必须指向同一个容器
// 如果不是random-access迭代器，则从pos1开始前进必须能够到达pos2，亦即pos2的位置必须与pos1相同或在其后
// 返回类型Dist是迭代器相应的difference类型：iterator_traits<InputIterator>::difference_type
```
这个函数能够根据迭代器种类采取最佳实现手法，这必须利用迭代器标志才得以达成。对于random-access迭代器，此函数仅仅是返回*pos2-pos1*，因此具备常量复杂度。对于其他迭代器种类，distance()会不断递增*pos1*，直到抵达*pos2*为止，然后返回递增次数，distance()具备线性复杂度。因此对于non-random-access迭代器而言distance()的效能并不好，应该避免使用。
### Iter_swap
这个简单的辅助函数用来交换两个迭代器所指的元素值。
```c++
void iter_swap (ForwardIterator1 pos1,ForwardIterator2 pos2);
// 交换迭代器pos1和pos2所指的值。
// 迭代器的类型不必相同，但其所指的两个值必须可以相互赋值
```
## Iterator Adapter
此类特殊迭代器使得算法能够以 reverse mode 或 insert mode 进行工作，也可以和 stream 搭配工作。
### Reverse
*Reverse*迭代器重新定义了递增运算和递减运算，使其行为正好颠倒。因此，如果使用这类迭代器，算法将以反向次序处理元素。所有标准容器都允许使用reverse迭代器来遍历元素。
- rbegin()返回反向迭代的第一元素位置，也就是真实之最末元素的位置。
- rend()返回反向迭代的最末元素的下一位置，也就是真实之第一元素的前一个位置。
![image-20230225174146362](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230225174146362.png)
可以将正常迭代器转化成reverse迭代器。当然，原本那个迭代器必须具有双向移动能力。注意，**转换前后的迭代器逻辑位置发生了变化**。考虑以下程序：
```c++
vector<int> coll ={1,2,3,4,5,6,7,8,9}; // find position of element with value 5
vector<int>::const_iterator pos;
pos = find(coll.cbegin(), coll.cend(), 5);
cout << "pos:" << *pos << endl; // 5

vector<int>::const_reverse_iterator rpos(pos); 
cout << "rpos:" << *rpos << endl; // 4
```
当把 pos 转换为 rpos，它们指向同一点，但它们所代表的意义（或说它们所代表的逻辑位置）不同了，pos为5，rpos则是4。
导致这个性质是因为区间的半开性。为了指出容器内所有元素，需要采用最末元素的下一位置。然而对reverse迭代器而言，这个位置位于第一元素之前，可能并不存在，因为容器并不要求其第一元素之前的位置合法。
reverse迭代器实际倒置了半开原则，即从原本的左闭右开变成了左开右闭。Reverse迭代器所定义的区间，并不包括起点，反倒是包括了终点。因此该迭代器所保持的是物理位置，但其 value（也就是其所指元素值）移到了前一个元素身上。
![image-20230225174542262](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20230225174542262.png)
如果有个区间，由一对（而非一个）迭代器定义出来，那么变换动作就非常简单了，所有元素仍然有效。考虑下面的例子：
```c++
deque<int> coll = {1, 2, 3, 4, 5, 6, 7, 8, 9};

deque<int>::const_iterator pos1;
pos1 = find (coll.cbegin(), coll.cend(), 2);

deque<int>::const_iterator pos2;
pos2 = find (coll.cbegin(), coll.cend(), 7);

// print all elements in range [pos1,pos2) 
// 迭代器pos1和pos2定义出一个半开区间，包括元素值2不包括元素值7
for_each(pos1, pos2, print); // 2, 3, 4, 5, 6

// convert iterators to reverse iterators
deque<int>::const_reverse_iterator rpos1(pos1); 
deque<int>::const_reverse_iterator rpos2(pos2);

// print all elements in range [pos1,pos2) in reverse order 
// 当把描述此区间的两个迭代器转化为reverse迭代器时，该区间仍然有效，可以被逆序处理
for_each(rpos2, rpos1, print); // 6, 5, 4, 3, 2
```
因此实际上：
```
rbegin() == container::reverse_iterator(end())
rend() == container::reverse_iterator(begin()) 
```
也可以将reverse迭代器转回正常迭代器。为了这么做，reverse迭代器提供了一个base()成员函数，通过base()进行转换，就好像从寻常的迭代器转换为reverse迭代器情况一样，物理位置维持不动，变化的是逻辑位置（也就是它所指的元素）。
### Inserter
插入器是一种迭代器适配器，用来将赋予新值动作转换为插入新值动作。它接受一个容器参数，生成一个插入迭代器。通过插入迭代器赋值时，该迭代器调用容器操作向给定容器的指定位置插入一个元素。所有insert迭代器都隶属于Output迭代器种类。
它们各自调用所属容器中不同的成员函数，所以 insert 迭代器初始化时一定要清楚指明所属的容器是哪一种。每一种 insert 迭代器都可以由一个对应的便捷函数加以生成和初始化。
![img](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/26089_483_2.jpg)
插入器有三种类型，区别在于元素插入的位置：
- `back_inserter`：创建一个调用`push_back`操作的迭代器。
- `front_inserter`：创建一个调用`push_front`操作的迭代器。
- `inserter`：创建一个调用`insert`操作的迭代器。此函数接受第二个参数，该参数必须是一个指向给定容器的迭代器，元素会被插入到该参数指向的元素之前。
```c++
list<int> lst = { 1,2,3,4 };
list<int> lst2, lst3;   // empty lists
// after copy completes, lst2 contains 4 3 2 1
copy(lst.cbegin(), lst.cend(), front_inserter(lst2));
// after copy completes, lst3 contains 1 2 3 4
copy(lst.cbegin(), lst.cend(), inserter(lst3, lst3.begin()));
```
通常，算法会将 value 赋值给 desination iterator，而 insert 迭代器可以把赋值动作转化为插入动作：
1. operator\*被实现为一个无作用的no-op，仅仅返回\*this。所以对insert迭代器来说，\*pos与pos等价。
2. 赋值动作被转化为插入动作，insert迭代器会调用容器的push_back()、push_front()或insert()成员函数。
所以，对于 insert 迭代器 pos，可以写 pos=value 也可以写 \*pos=value，两者都可以插入新值。当然，这里谈的是insert迭代器的实现细节，从概念上讲，正确的赋值式应该是`pos=*value`。
同样道理，递增操作符也被实现为一个no-op，也是仅仅返回一个`*this`。所以，无法改动 insert 迭代器的位置。
#### Back inserter
容器本身必须支持 insert 迭代器所调用的函数，否则这种 insert 迭代器就不可用。因此，back inserter 只能用在 vector、deque、list 和string 身上，front inserter 只能用在 deque 和 list 身上。
back inserter生成时，其初始化过程必须确知其所属容器，但也可以通过函数生成：
```c++
vector<int> coll;
back_insert_iterator<vector<int>> iter(coll); 
*iter = 1; 
iter++; //无作用
*iter = 2; 
*iter = 3;

back_inserter(coll) = 44; 
back_inserter(coll) = 55; 

coll.reserve(2 * col1.size());
copy(coll.begin(), coll.end(), back_inserter(coll));
```
> 注意，一定要在调用 copy() 之前确保有足够大的空间。因为 back inserter在插入元素时，可能会造成指向该vector的其他迭代器失效。因此，如果不保留足够空间，这个算法可能会形成源端迭代器失效状态。
#### Front Inserter
*Front inserter*，借由成员函数push_front()将一个value加于容器头部。由于push_front()只在deque、list和forward list有所实现，所以C++标准库中也就只有这些容器支持front inserter。
Front inserter生成时，其初始化过程必须确知其所属容器，但也可以通过函数生成：
```c++
list<int> coll;
front_insert_iterator<list<int>> iter(coll); 
*iter = 1;
*iter = 2;
*iter = 3;
// 3，2，1
front_inserter(coll) = 44; 
front_inserter(coll) = 55; 
// 55，44，3，2，1
copy(coll.begin(), coll.end(), front_inserter(coll)); // 1，2，3，44，55，55，44，3，2，1
```
> 注意，插入多个元素时，front inserter以逆序方式插入，这是因为它总是将下一个元素插入第一个元素的前面。
#### General Inserter
*General inserter*，根据两个实参完成初始化：容器，待插入位置。迭代器内部以待插入位置为实参调用成员函数insert()。便捷函数inserter()则提供了更方便的手段来产生general inserter并加以初始化。
General inserter对所有标准容器均适用，只有array和forward list除外，因为那些容器没有insert()成员函数。然而对associative和unordered容器而言，插入位置只是个提示，因为在这两种容器中元素的真正位置视其value而定。
插入动作完成后，general inserter获得刚被插入的那个元素的位置。相当于调用以下语句：
```c++
pos = container.insert(pos, value);
++pos;
```
这是为了确保该迭代器的位置始终有效。如果没有这一赋值动作，在deque、vector和string中，该general inserter本身可能会失效。因为每一次插入动作都会（或至少可能会）使指向容器的所有迭代器失效。
```c++
set<int> coll;
insert_iterator<set<int>> iter(coll,coll.begin()); 
*iter = 1; 
*iter = 2; 
*iter = 3;

inserter(coll, coll.end()) = 44;
inserter(coll, coll.end()) = 55;

list<int> coll2;
copy(coll.begin(), coll.end(), inserter(coll2, coll2.begin()));   // 1 2 3 44 55
copy(coll.begin(), coll.end(), inserter(coll2, next(coll2.begin())); // 1 1 2 3 44 55 2 3 44 55
```
如前所述，对于associative容器，general inserter的位置实参只不过是个提示，用来强化速度。如果使用不当反而可能导致较糟的效能。举个例子，如果逆序插入，这个提示就可能使程序变慢，因为它使程序总是从错误的位置开始查找插入点。
### Stream
*Stream*迭代器是一种迭代器适配器，借由它，可以把stream当成算法的来源端和目的端。`istream_iterator`从输入流读取数据，`ostream_iterator`向输出流写入数据。这些迭代器将流当作特定类型的元素序列处理。
#### Ostream_iterator
定义`ostream_iterator`对象时，必须将其绑定到一个指定的流，迭代器会把value写至该output stream。另一个实参可有可无，是个字符串，被用来作为各个元素值之间的分隔符。不允许定义空的或者表示尾后位置的`ostream_iterator`。
`*`和`++`运算符实际上不会对`ostream_iterator`对象做任何操作。但是建议代码写法与其他迭代器保持一致。
```c++
ostream_iterator<int, char>out_iter(cout, " ");

*out_iter++ = 15; //works like cout << 15 << " ";
//对于常规指针，这意味着将15赋给指针指向的位置，然后将指针加1。但对于该ostream_iterator，这意味着将15和由空格组成的字符串发送到cout管理的输出流中，并为下一个输出操作做好了准备。

copy(s.begin(), s.end(), out_iter);  
//将dice容器的整个区间复制到输出流中，即显示容器的内容

for (auto e : vec)
    *out_iter++ = e;    // the assignment writes this element to cout
cout << endl;
```
可以为任何定义了`<<`运算符的类型创建`istream_iterator`对象，为定义了`>>`运算符的类型创建`ostream_iterator`对象。
#### Istream_iterator
`istream_iterator`使用`>>`来读取流，因此`istream_iterator`要读取的类型必须定义了`>>`运算符。创建`istream_iterator`时，可以将其绑定到一个流。如果默认初始化，则创建的是尾后迭代器。
```c++
istream_iterator<int> int_it(cin);  // reads ints from cin
istream_iterator<int> int_eof;      // end iterator value
ifstream in("afile");
istream_iterator<string> str_it(in);   // reads strings from "afile"
```
对于一个绑定到流的迭代器，一旦其关联的流遇到文件尾或IO错误，迭代器的值就与尾后迭代器相等。只要有任何一次读取失败，所有`istream_iterator`都会变成end-of-stream迭代器。所以进行一次读取后，就应该将`istream_iterator`拿来和end-of-stream迭代器比较是否仍然有效。
```c++
istream_iterator<int> in_iter(cin);     // read ints from cin
istream_iterator<int> eof;      // istream ''end'' iterator
while (in_iter != eof)      // while there's valid input to read
    // postfix increment reads the stream and returns the old value of the iterator
    // we dereference that iterator to get the previous value read from the stream
    vec.push_back(*in_iter++);
```
可以直接使用流迭代器构造容器。
```c++
istream_iterator<int> in_iter(cin), eof;    // read ints from cin
vector<int> vec(in_iter, eof);      // construct vec from an iterator range
```
将`istream_iterator`绑定到一个流时，标准库并不保证迭代器立即从流读取数据。但可以保证在第一次解引用迭代器之前，从流中读取数据的操作已经完成了。
`istream_iterator`的构造函数会将 stream 打开，并往往会读取第一个值，否则一旦`operator*`在此迭代器初始化后被调用，就无法返回第一个元素了。所以，在确实需要用到`istream_iterator`之前，别过早定义它。不过某些实现版本可能会延缓第一次读取动作直到`operator*`首次被调用。
### Move
从C++11开始，提供了一个迭代器适配器，用来将任何对底层元素的处理转换为一个move操作。举个例子：
```c++
std::list<std::string> s;
std::vector<string> v1(s.begin(),s.end()); //copy strings into v1 
std::vector<string> v2(make_move_iterator(s.begin()), make_move_iterator(s.end())); //move strings into v2
```
这些迭代器的应用之一是，让算法以move取代copy，将元素从一个区间放到另一个区间。
一般而言，只有当算法将元素从某个来源区间迁移至某个目标区间，这种情况下在算法中使用move迭代器才有意义。此外，必须确保每个元素只被处理一次，否则，其内容将被移动一次以上，那会导致不明确的行为。
唯一保证元素只被读取或被处理一次的迭代器种类是input iterator。因此，通常只有当某算法有个来源端，其内要求 input iterator，并且有个目的端，其内使用 output iterator，这时候使用 move 迭代器才有意义。唯一例外是for_each()，它可处理被指明区间内的 moved element，把它们移动到一个新容器内。
## Iterator Trait
迭代器可以区分为不同类型，每个类型都代表特定的迭代器能力。如果能根据不同的迭代器种类将操作行为重载，将会很有用，甚至很必要。通过迭代器标志和特性可以实现这样的重载。C++标准库为每个迭代器种类提供了一个iterator tag，用来作为迭代器的 label：
![img](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/26089_495_1.jpg)
这里用到继承。所以可以说，任何forward迭代器都是一种 input 迭代器。然而请注意，forward 迭代器 tag 只派生自 input 迭代器 tag，和output 迭代器 tag 无关。事实上 forward 迭代器的某些特性的确不符合output迭代器的要求。
如果撰写泛型码，可能不只对迭代器种类感兴趣，可能还需要了解迭代器所指元素的类型。C++标准库提供了一种特殊的template结构来定义所谓的迭代器特性，该结构包含迭代器相关的所有信息，**为迭代器应具备的所有类型定义（包括迭代器种类、元素类型等）提供一致的接口**：
![img](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/26089_495_2.jpg)
在这个template中，T表示迭代器类型。有了它，就可以撰写任何运用迭代器种类或其元素类型的泛型码。例如以下表达式就可以取得迭代器类型为 T 的元素类型：
```c++
typename std::iterator_traits<T>::value_type;
```
这个trait结构有两个优点：
- 确保每一个迭代器都提供了所有必要的类型定义。
- 能够针对特定的迭代器实施特化
上述第二条适用于以寻常pointer作为迭代器时：

于是，针对指向 T 类型之寻常pointer，上述特化版本告诉我们，该类型具有random-access迭代器种类。
## Generic Function
借由iterator trait，可以撰写这样的泛型函数：根据迭代器而派生某种类型定义，或根据迭代器种类而采用不同的实现代码。某些算法内部需要一个以元素类型为类型的临时变量，这正是使用iterator trait的一个简单例子。这样的临时变量可以声明如下，其中T是迭代器类型：
```c++
typename std::iterator_traits<T>::value_type tmp;
```
另一个例子是将元素循环往复地移动：
```c++
template <typename ForwardIterator>
void shift_left(ForwardIterator beg, ForwardIterator end) {
    //temporary variable for first element 
    typedef typename std::iterator_traits<ForwardIterator>::value_type value_type; 
    if (beg != end){ 
        //save value of first element
        value_type tmp(*beg);
        //shift following values 
    }
}
```
如果希望针对不同的迭代器种类采取不同的实现方案，需要下面两个步骤：
让template函数将迭代器种类作为附加实参，调用另一个函数。例如：
```c++
template <typename Iterator>
inline void foo (Iterator beg, Iterator end) {
    foo(beg, end, std::iterator_traits<Iterator>::iterator_category()); 
}
```
针对不同的迭代器种类实现出上述调用的函数。注意，如果迭代器种类B为D之父类，而此处所谈函数针对B、D并无不同实现，那么只需针对B实现即可。
```c++
template <typename BiIterator>
void foo (BiIterator beg, BiIterator end, std::bidirectional_iterator_tag) {}

template <typename RaIterator>
void foo (RaIterator beg, RaIterator end, std::random_access_iterator_tag) {} 
```
其中，针对random-access迭代器而写的版本可以使用随机访问操作，针对bidirec-tional迭代器而写的版本则不可以。基于迭代器标志继承体系，可以写出一份实现代码但适用于多个迭代器种类。
以下根据两个步骤，实现出迭代器辅助函数distance()。此函数返回两个迭代器所指元素的位置间距。对于random-access迭代器，此函数仅仅使用operator-便可获得结果，对于其他任何种类的迭代器，此函数必须一步一步前进至区间终点，才有能力计算出结果并返回。
```c++
template <typename Iterator>
typename std::iterator_traits<Iterator>::difference_type distance (Iterator pos1, Iterator pos2) {
	return distance(pos1, pos2, std::iterator_traits<Iterator>::iterator_category()); 
}

// distance() for random-access iterators 
template <typename RaIterator>
typename std::iterator_traits<RaIterator>::difference_type 
distance (RaIterator posl, RaIterator pos2, std::random_access_iterator_tag) {
	return pos2 - pos1; 
}

//distance() for input, forward, and bidirectional iterators 
template <typename InIterator>
typename std::iterator_traits<InIterator>::difference_type 
distance (InIterator pos1, InIterator pos2, std::input_iterator_tag) {
    typename std::iterator_traits<InIterator>::difference_type d;
    for (d = 0; pos1 != pos2; ++pos1, ++d) {}
    return d; 
}
```
返回类型必须是迭代器的距离类型（difference type）。请注意第二版本使用input迭代器，所以该版本对forward迭代器、bidirectional迭代器都有效，因为这两种迭代器的标志是从input_iterator_tag派生出来的。
## User-Defined
![image-20220515171901726](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220515171901726.png)
User-Defined 必须让 iterator trait 能够处理这样的迭代器。两种办法可行：
- 提供必要的五种类型定义，就像iterator_traits结构所描述。
- 为 iterator_traits 结构提供一个特化版本。
```c++
class istream_line_reader {
public:
  class iterator {  // 实现 InputIterator
  public:
    typedef ptrdiff_t difference_type;
    typedef string value_type;
    typedef const value_type* pointer;
    typedef const value_type& reference;
    typedef input_iterator_tag
      iterator_category;
    …
  };
  …
};
```
- difference_type 是代表迭代器之间距离的类型，定义为 ptrdiff_t 只是种标准做法（指针间差值的类型），对这个类型没什么特别作用。
- value_type 是迭代器指向的对象的值类型，我们使用 string，表示迭代器指向的是字符串。
- pointer 是迭代器指向的对象的指针类型，这儿就平淡无奇地定义为 value_type 的常指针了（我们可不希望别人来更改指针指向的内容）。
- reference 是 value_type 的常引用。
- iterator_category 被定义为 input_iterator_tag，标识这个迭代器的类型是 input iterator（输入迭代器）。
C++标准库提供了一个特殊的基类，专门用来进行这一定义，只需这样指定类型：
```c++
class MyIterator: public std::iterator<std::bidirectional_iterator_tag, type, std::ptrdiff_t, type*, type&> { };
```
其中第一个template参数用来定义迭代器种类，第二个参数用来定义元素类型，第三参数用来定义difference类型，第四个参数用来定义pointer类型，第五个参数用来定义reference类型。末尾的三个参数有默认值ptrdiff_t、`type*`和type&，所以通常这样写就够了：
```c++
class MyIterator: public std::iterator<std::bidirectional_iterator_tag, type> { };
```
### Define input
作为一个真的只能读一次的输入迭代器，有个特殊的麻烦（前向迭代器或其衍生类型没有）：到底应该让 * 负责读取还是 ++ 负责读取。我们这儿采用常见、也较为简单的做法，让 ++ 负责读取，* 负责返回读取的内容。这样的话，这个 iterator 类需要有一个数据成员指向输入流，一个数据成员来存放读取的结果。根据这个思路，定义这个类的基本成员函数和数据成员：
```c++
class istream_line_reader {
public:
  class iterator {
    …
    iterator() noexcept
      : stream_(nullptr) {}
    explicit iterator(istream& is)
      : stream_(&is)
    {
      ++*this;
    }

    reference operator*() const noexcept
    {
      return line_;
    }
    pointer operator->() const noexcept
    {
      return &line_;
    }
    iterator& operator++()
    {
      getline(*stream_, line_);
      if (!*stream_) {
        stream_ = nullptr;
      }
      return *this;
    }
    iterator operator++(int)
    {
      iterator temp(*this);
      ++*this;
      return temp;
    }

  private:
    istream* stream_;
    string line_;
  };
  …
};
```
我们定义了默认构造函数，将 stream_ 清空；相应的，在带参数的构造函数里，我们根据传入的输入流来设置 `stream_`。我们也定义了 * 和 -> 运算符来取得迭代器指向的文本行的引用和指针，并用 ++ 来读取输入流的内容（后置 ++ 则以惯常方式使用前置 ++ 和拷贝构造来实现）。唯一“特别”点的地方，是我们在构造函数里调用了 ++，确保在构造后调用 * 运算符时可以读取内容，符合日常先使用 \*、再使用 ++ 的习惯。一旦文件读取到尾部（或出错），则 `stream_` 被清空，回到默认构造的情况。
对于迭代器之间的比较，我们则主要考虑文件有没有读到尾部的情况，简单定义为：
```c++
bool operator==(const iterator& rhs)
    const noexcept
{
    return stream_ == rhs.stream_;
}
bool operator!=(const iterator& rhs)
    const noexcept
{
    return !operator==(rhs);
}
```
有了这个 iterator 的定义后，istream_line_reader 的定义就简单得很了：
```c++
class istream_line_reader {
public:
  class iterator {…};
  istream_line_reader() noexcept
    : stream_(nullptr) {}
  explicit istream_line_reader(
    istream& is) noexcept
    : stream_(&is) {}
  iterator begin()
  {
    return iterator(*stream_);
  }
  iterator end() const noexcept
  {
    return iterator();
  }

private:
  istream* stream_;
};
```
也就是说，构造函数只是简单地把输入流的指针赋给 stream_ 成员变量。begin 成员函数则负责构造一个真正有意义的迭代器；end 成员函数则只是返回一个默认构造的迭代器而已。
### Define inserter
以下实例说明如何编写 insert 迭代器。这是一个 associative 和 unordered 容器的 insert 迭代器。它和C++标准库的insert迭代器不同，它不需要指明插入位置。
```c++
template <typename Container>
class asso_insert_iterator: public std::iterator<std::output_iterator_tag, typename Container::value_type> {
protected:
    Container& container;
public:
    explicit asso_insert_iterator(Container& c): container(c) { }
    
    //assignment operator inserts a value into the container 
    asso_insert_iterator<Container>& operator=(const typename Container::value_type& value) { 
        container.insert(value);
        return *this;
    }

    //dereferencing is a no-op that returns the iterator itself
    asso_insert_iterator<Container>& operator*() {
        return *this;
    }

    //increment operation is a no-op that returns the iterator itself 
    asso_insert_iterator<Container>& operator++() { 
        return *this;
    }

    asso_insert_iterator<Container>& operator++(int) { 
        return *this;
    } 
};

// 提供一个asso_inserter函数，用来简化迭代器的创建和初始化
template <typename Container>
inline asso_insert_iterator<Container> asso_inserter(Container& c) {
    return asso_insert_iterator<Container>(c); 
}
```
其中的 class asso_insert_iterator 派生自 class iterator。传给 iterator 的第一个实参 output_iterator_tag 指定了迭代器种类。第二实参是此迭代器所指的元素值类型，此处设为容器的 value_type。由于 output 迭代器只能用于写入某东西，因而此类型并非必需，可以传入void。然而像本例这样指明为 value type，将可适用于任何迭代器种类。
诞生之时，这一迭代器将容器存储于其成员container中。所有被赋予的值都借由insert()被插入到容器内。Operators\*和operater++只返回迭代器自身，无任何实际动作，但这么虚晃一招使得迭代器得以维护其控制权。如果下面这样的迭代器一般性接口被使用了：
```c++
*pos = value;
```
\*pos会返回\*this，新值被赋予其中。至于赋值动作则被转化为对容器成员函数 insert 的调用。
## Invalidate Iterators
向容器中添加或删除元素可能会使指向容器元素的指针、引用或迭代器失效。失效的指针、引用或迭代器不再表示任何元素，使用它们是一种严重的程序设计错误。
- 向容器中添加元素后：
	- 如果容器是`vector`或`string`类型，且存储空间被重新分配，则指向容器的迭代器、指针和引用都会失效。如果存储空间未重新分配，指向插入位置之前元素的迭代器、指针和引用仍然有效，但指向插入位置之后元素的迭代器、指针和引用都会失效。
	- 如果容器是`deque`类型，添加到除首尾之外的任何位置都会使迭代器、指针和引用失效。如果添加到首尾位置，则迭代器会失效，而指针和引用不会失效。
	- 如果容器是`list`或`forward_list`类型，指向容器的迭代器、指针和引用仍然有效。
- 从容器中删除元素后，指向被删除元素的迭代器、指针和引用失效：
	- 如果容器是`list`或`forward_list`类型，指向容器其他位置的迭代器、指针和引用仍然有效。
	- 如果容器是`deque`类型，删除除首尾之外的任何元素都会使迭代器、指针和引用失效。如果删除尾元素，则尾后迭代器失效，其他迭代器、指针和引用不受影响。如果删除首元素，这些也不会受影响。
	- 如果容器是`vector`或`string`类型，指向删除位置之前元素的迭代器、指针和引用仍然有效。但尾后迭代器总会失效。
因此必须保证在每次改变容器后都正确地重新定位迭代器。
```c++
std::map<std::string, float> coll;
for (auto pos = coll.begin(); pos !=coll.end(); ++pos){ 
    if (pos->second == value) coll.erase(pos); // pos 不再成为 coll 的一个有效迭代器，此后 ++ 是对无效迭代器进行的
}

// 解决
for (auto pos = coll.begin(); pos != coll.end();){ 
    if (pos->second == value) pos = coll.erase(pos); // erase 返回一个迭代器指向其后继元素，不需要 ++
    else ++pos; 
}
// 或
for (auto pos = coll.begin(); pos !=coll.end();) { 
    // pos++ 会将 pos 移向下一元素，但返回其原值（指向原位置）的一份拷贝。因此当 erase 被调用，pos 已经不再指向那个即将被移除的元素了。
    if (pos->second == value) coll.erase(pos++);
	else ++pos; 
}

for (auto pos = coll.begin(); pos !=coll.end(); ++pos){ 
    if (pos->second == value) coll.insert(pos, *pos - 1); // pos 不再成为 coll 的一个有效迭代器，此后 ++ 是对无效迭代器进行的
}

// 解决
for (auto pos = coll.begin(); pos != coll.end(); ++pos) { // insert 在 pos 位置前插入一个元素，并返回插入到的位置
    if (pos->second == value) pos++ = coll.insert(pos, *pos - 1); // 需要再次 ++ 遍历到原本的下一个元素
}
```
封装：
```c++
template<class T>
class Allocator {
    public:
    T *allocate(size_t size) {
        return (T *) malloc(size * sizeof(T));
    }

    void deallocate(void *p) {
        free(p);
    }

    void construct(T *p, const T &val) {
        new(p) T(val);
    }

    void destroy(T *p) {
        p->~T();
    }
};

template<typename T, typename Alloc = Allocator<T>>
class vector {
    public:

    class iterator {
    public:
        friend class vector<T, Alloc>;

        explicit iterator(vector<T, Alloc> *pVec, T *iteratorPtr = nullptr) : _pVec(pVec), _iteratorPtr(iteratorPtr) {
            // 每创建一个迭代器，都将其加入到容器的迭代器链表中
            auto *itb = new iterator_base(this, _pVec->_head._next);
            _pVec->_head._next = itb;
        }

        bool operator!=(const iterator &it) const {
            if (_pVec == nullptr || _pVec != it._pVec) throw invalid_argument("incompatible!=");
            return _iteratorPtr != it._iteratorPtr;
        }

        iterator& operator++() {
            if (_pVec == nullptr) throw invalid_argument("++incompatible");
            ++_iteratorPtr;
            return *this;
        }

        const iterator operator++(int) {
            if (_pVec == nullptr) throw invalid_argument("incompatible++");
            return iterator(_pVec, _iteratorPtr++);
        }

    private:
        T *_iteratorPtr; // 指向容器的某一元素
        vector<T, Alloc> *_pVec;  // 指向容器对象
    };

    // 只需要析构对象，而不释放内存。
    void pop_back() {
        if (empty()) return;
        verify(_last - 1, _last); // 使迭代器失效
        --_last;
        _allocator.destroy(_last);
    }

    iterator insert(iterator it, const T &val) {
        verify(it._iteratorPtr - 1, _last); // 使迭代器失效
        T *ptr = _last;
        // 插入时元素向后移动一位，析构前要保证那个位置已经构造完毕，因此先构造
        while (ptr > it._iteratorPtr) { // ptr是当前位置（尾后位置），从右到左开始
            _allocator.construct(ptr, *(ptr - 1)); // 将前一位置构造到当前位置
            _allocator.destroy(ptr - 1); // 析构前一位置
            ptr--;
        }
        _allocator.construct(ptr, val);
        _last++;
        return iterator(this, ptr);
    }

    iterator erase(iterator it) {
        verify(it._iteratorPtr - 1, _last);
        T *ptr = it._iteratorPtr;
        // 删除时元素向前移动一位，构造前要保证那个位置已经被析构，因此先析构后构造
        while (ptr < _last - 1) { // ptr是当前位置（要删除的位置），从左到右开始
            _allocator.destroy(ptr); // 析构当前位置
            _allocator.construct(ptr, *(ptr + 1)); // 将后一位置构造在当前位置
            ptr++;
        }
        _allocator.destroy(ptr);
        _last--;
        return iterator(this, it._iteratorPtr);
    }

    iterator begin() { return iterator(this, _first); }
    iterator end() { return iterator(this, _last); }

    void verify(T *start, T *end) {
        iterator_base *cur = &this->_head;
        while (cur->_next != nullptr) { // 遍历链表
            // 将范围内的迭代器失效
            if (cur->_next->_cur->_iteratorPtr >= start && cur->_next->_cur->_iteratorPtr <= end) {
                iterator_base *tmp = cur->_next;
                cur->_next = cur->_next->_next;
                tmp->_cur->_pVec = nullptr; // 迭代器失效，将iterator持有的容器指针置nullptr，迭代器不再指向原本的容器
                delete tmp;
            }
            else { // 没问题则继续遍历
                cur = cur->_next;
            }
        }
    }

    private:
    T *_first; // 指向第一个元素的位置
    T *_last; // 指向最后一个有效元素的后继位置
    T *_end; // 指向最后一个元素的后继位置
    Alloc _allocator;

    struct iterator_base {
        explicit iterator_base(iterator *cur = nullptr , iterator_base *next = nullptr): _cur(cur), _next(next) {}
        iterator *_cur;
        iterator_base *_next;
    } _head; // 链表记录容器使用的迭代器
};


int main() {
    default_random_engine engine(time(nullptr));
    uniform_int_distribution<int> u(0, 100);

    cafba::vector<int> vec(100);
    int cnt = 0;
    while(cnt++ < 10) vec.push_back(u(engine));

    for (auto i: vec) cout << i << " ";
    cout << endl;

    // insert测试
    for (auto it = vec.begin(); it != vec.end(); ++it) {
        if (*it % 2 == 0) vec.insert(it, (*it) - 1);
    }
    for (auto i: vec) cout << i << " ";

    // erase测试
    for (auto it = vec.begin(); it != vec.end(); ++it) {
        if (*it % 2 == 0) vec.erase(it);
    }
    for (auto i: vec) cout << i << " ";
}
```
