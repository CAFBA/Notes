# Class Template
## Grid
假设想要一个通用的棋盘类，可将其用作象棋棋盘、跳棋棋盘、井字游戏棋盘或其他任何二维的 棋盘。为让这个棋盘通用，这个棋盘应该能保存象棋棋子、跳棋棋子、井字游戏棋子或其他任何游戏 类型的棋子。
如果不使用模板，编写通用棋盘最好的方法是采用多态技术，保存通用的 `GamePiece` 对象。然后，可让每种游戏的棋子继承 `GamePiece` 类。例如，在象棋游戏中，`ChessPiece` 可以是 `GamePiece` 的派生类。通过多态技术，既能保存 `GamePiece` 的 `GameBoard`，也能保存 `ChessPiece`。
`GameBoard` 可以复制，所以 `GameBoard` 需要能复制 `GamePiece`。这个实现利用多态技术，因此一种解决方案是给 `GamePiece` 基类添加纯虚方法 `clone`，它的派生类必须实现 `clone` 并返回一个具体的 `GamePiece` 的副本。
```cpp
class GamePiece
{
public:
    virtual ~GamePiece() = default;
    virtual std::unique_ptr<GamePiece> clone() const = 0;
};

class ChessPiece : public GamePiece
{
public:
    std::unique_ptr<GamePiece> clone() const override {
    // Call the copy constructor to copy this instance
        return std::make_unique<ChessPiece>(*this);
    }
};
// GameBoard 的实现使用 unique_ptr 的 vector 的 vector 来存储 GamePiece
class GameBoard {
public:
    explicit GameBoard(size_t width = DefaultWidth, size_t height = DefaultHeight);
    GameBoard(const GameBoard& src); // copy constructor
    virtual ~GameBoard() = default; // virtual defaulted destructor
    GameBoard& operator=(const GameBoard& rhs); // assignment operator
    
    // Explicitly default a move constructor and assignment operator.
    GameBoard(GameBoard&& src) = default;
    GameBoard& operator=(GameBoard&& src) = default;
    
    std::unique_ptr<GamePiece>& at(size_t x, size_t y);
    const std::unique_ptr<GamePiece>& at(size_t x, size_t y) const;
    
    size_t getHeight() const { return m_height; }
    size_t getWidth() const { return m_width; }
    
    static const size_t DefaultWidth { 10 };
    static const size_t DefaultHeight { 10 };
    
    void swap(GameBoard& other) noexcept;
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::vector<std::vector<std::unique_ptr<GamePiece>>> m_cells;
    size_t m_width { 0 }, m_height { 0 };
};

void swap(GameBoard& first, GameBoard& second) noexcept;
```
`GameBoard` 作为一个二维数组的抽象，它应给出实际对象的索引，而不是给对象的副本，以提供数组访问语义。客户代码不应存储这个引用/索引供将来使用，因为它可能是无效的；相反，应该在使用返回的引用之前调用 `at`，`at` 返回指定位置的棋子的引用，而不是返回棋子的副本。 
```cpp
GameBoard::GameBoard(size_t width, size_t height)
 : m_width { width }, m_height { height } {
    m_cells.resize(m_width);
    for (auto& column : m_cells) {
        column.resize(m_height);
    }
}

GameBoard::GameBoard(const GameBoard& src)
 : GameBoard { src.m_width, src.m_height } {
for (size_t i { 0 }; i < m_width; i++) 
    for (size_t j { 0 }; j < m_height; j++) 
        if (src.m_cells[i][j])
            m_cells[i][j] = src.m_cells[i][j]->clone();
}

void GameBoard::verifyCoordinate(size_t x, size_t y) const {
    if (x >= m_width) 
        throw out_of_range { format("{} must be less than {}.", x, m_width) };
    if (y >= m_height) 
        throw out_of_range { format("{} must be less than {}.", y, m_height) };
}

void GameBoard::swap(GameBoard& other) noexcept {
    std::swap(m_width, other.m_width);
    std::swap(m_height, other.m_height);
    std::swap(m_cells, other.m_cells);
}
void swap(GameBoard& first, GameBoard& second) noexcept {
    first.swap(second);
}

GameBoard& GameBoard::operator=(const GameBoard& rhs) {
    // Copy-and-swap idiom
    GameBoard temp { rhs }; // Do all the work in a temporary instance.
    swap(temp); // Commit the work with only non-throwing operations.
    return *this;
}

const unique_ptr<GamePiece>& GameBoard::at(size_t x, size_t y) const {
    verifyCoordinate(x, y);
    return m_cells[x][y];
}

unique_ptr<GamePiece>& GameBoard::at(size_t x, size_t y) {
    return const_cast<unique_ptr<GamePiece>&>(as_const(*this).at(x, y));
}
```
前面定义的 `GameBoard` 类很好，但不够完善。第一个问题是无法使用 `GameBoard` 按值存储元素，它总是存储指针。另一个更重要的问题与类型安全相关。`GameBoard` 中的每个网格都存储 `unique_ptr<GamePiece>`。即使存储 `ChessPiece` ，当使用 `at` 请求某个网格时，也会得到 `unique_ptr<GamePiece>`。这意味着，只有将检索到的 `GamePiece` 向下转型为 `ChessPiece`, 才能使用 `ChessPiece` 的特定功能。
`GameBoard` 的另一个缺点是不能用来存储基本类型，如 int 或 double, 因为存储在网格中的类型必须派生自类 `GamePiece`。 因此，最好编写一个通用的 `Grid` 类，该类可用于存储 `ChessPiece`、`int` 和 `double` 等。可通过编写类模板来实现这一点，编写类模板可避免编写需要指定一种或多种类型的 类，客户通过指定要使用的类型对模板进行实例化。这称为泛型编程，其最大的优点是类型安全。类及其方法中使用的类型是具体的类型，而不是多态方案中的抽象基类类型。
类名从 `GameBoaid` 变为 `Grid`。这个 `Grid` 类还应该可以用于基本类型。因此，这里选用不带多态性的值语义来实现这个解决方案，而 `GameBoaid` 实现中使用了多态指针语义。`m_cells` 容器中存储的是真实的对象，而不是指针。与指针语义相比，使用值语义的缺点在于不能拥有真正的空网格，也就是说，网格始终要包含一些值，而使用指针语义，在空网格中可以存储 `nullptr`，`optional` 可弥补这一点，它允许使用值语义，同时允许表示空网格。
```cpp
template <typename T>
class Grid
{
public:
    // 在类模板自己的作用域内，可以直接使用模板名而不用提供模板实参
    explicit Grid(size_t width = DefaultWidth,size_t height = DefaultHeight);
    virtual ~Grid() = default;
    // Explicitly default a copy constructor and assignment operator.
    Grid(const Grid& src) = default;
    Grid& operator=(const Grid& rhs) = default;
    // Explicitly default a move constructor and assignment operator.
    Grid(Grid&& src) = default;
    Grid& operator=(Grid&& rhs) = default;
    std::optional<T>& at(size_t x, size_t y);
    const std::optional<T>& at(size_t x, size_t y) const;
    size_t getHeight() const { return m_height; }
    size_t getWidth() const { return m_width; }
    static const size_t DefaultWidth { 10 };
    static const size_t DefaultHeight { 10 };
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::vector<std::vector<std::optional<T>>> m_cells;
    size_t m_width { 0 }, m_height { 0 };
};
```
在前面的 `GameBoard` 类中，`m_cells` 数据成员是指针的 `vector` 的 `vector`, 这需要特定的复制代码，因此需要拷贝构造函数和赋值运算符。在 `Grid` 类中，`m_cells` 是可选值的 `vector` 的 `vector`, 所以编译器生成的拷贝构造函数和赋值运算符可以运行得很好。
类模板的成员函数具有和类模板相同的模板参数，因此定义在类模板外的成员函数必须以关键字`template` 开始，后跟类模板参数列表，并且在类模板作用域外，需要提供模板实参：
```cpp
template <typename T>
Grid<T>::Grid(size_t width, size_t height)
 : m_width { width }, m_height { height } 
{
    m_cells.resize(m_width);
    for (auto& column : m_cells)
    column.resize(m_height);
}

template <typename T>
void Grid<T>::verifyCoordinate(size_t x, size_t y) const
{
    if (x >= m_width) {
        throw std::out_of_range 
            std::format("{} must be less than {}.", x, m_width) };
    if (y >= m_height) 
        throw std::out_of_range 
            std::format("{} must be less than {}.", y, m_height) };
}

template <typename T>
const std::optional<T>& Grid<T>::at(size_t x, size_t y) const
{
    verifyCoordinate(x, y);
    return m_cells[x][y];
}
template <typename T>
std::optional<T>& Grid<T>::at(size_t x, size_t y)
{
    return const_cast<std::optional<T>&>(std::as_const(*this).at(x, y));
}
```
## How the Compiler Processes Templates
编译器遇到模板方法定义时，会进行语法检查，但是并不编译模板。编译器无法编译模板定义，因为它不知道要使用什么类型。如果在程序中没有将类模板实例化为任何类型，就不会编译类方法的定义。只有当模板的一个特定版本被实例化时，编译器才会生成代码，此时编译器需要掌握生成代码所需的信息，因此函数模板和类模板成员函数的定义通常放在头文件中。
### Selective Instantiation
编译器总是为类模板的所有虚方法生成代码，但对于非虚方法，编译器只会为那些实际为某种类型调用的非虚方法生成代码。
```cpp
Grid<int> myIntGrid; 
myIntGrid.at(0, 0) = 10;
```
编译器只会为 `int` 版本的 `Grid` 类生成无参构造函数、析构函数和非 `const at()` 方法的代码，不会为其他方法生成代码，编译器的以上行为称为选择性实例化。 
### Explicit template instantiation
因为模板在使用时才会进行实例化，所以相同的实例可能出现在多个对象文件中。当两个或多个独立编译的源文件使用相同的模板，并提供相同的模板参数时，每个文件中都会有该模板的一个实例。在大型程序中，多个文件实例化相同模板的额外开销可能非常严重。`C++11` 允许通过显式实例化与 `extern` 来避免这种开销。显式实例化的形式如下：
```c++
// declaration 是已经提供模板实参的模板
extern template declaration;    // instantiation declaration
template declaration;           // instantiation definition
template class Grid<int>;       // 显式实例化

Grid<int> myIntGrid;            // 隐式实例化
```
当编译器遇到 `extern` 模板声明时，它不会在本文件中生成实例化代码，对于一个给定的实例化版本，可能有多个 `extern` 声明，但必须只有一个定义。由于编译器在使用一个模板时自动对其实例化，因此 `extern` 声明必须出现在任何使用此实例化版本的代码之前：
```c++
// Application.cc
// these template types must be instantiated elsewhere in the program
extern template 
class Blob<string>;

extern template 
int compare(const int&, const int&);

Blob<string> sa1, sa2;    // instantiation will appear elsewhere

// Blob<int> and its initializer_list constructor instantiated and
// copy constructor instantiated in this file
Blob<int> a1 = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
Blob<int> a2(a1);

int i = compare(a1[0], a2[0]);    // instantiation will appear elsewhere
```
由于 `extern` 的存在，`compare` 和 `Blob` 将不在本文件中进行实例化，这些模板的定义必须出现在程序的其他文件中：
```c++
// templateBuild.cc
// instantiation file must provide a (nonextern) definition for every
// type and function that other files declare as extern
template int compare(const int&, const int&);
template class Blob<string>;// instantiates all members of the class template
```
当编译器遇到一个与声明相对的实例化定义时，它为其生成代码。因此，文件 `templateBuild.o` 将会包含 `compare` 的 `int` 实例化版本的定义和 `Blob` 类的定义。当编译此应用程序时，必须将 `templateBuild.o` 和 `Application.o` 链接到一起。
类模板中未使用的方法可能包含语法错误，这些错误不会被编译，因此在一些类模板方法中的错误会被忽略。通过显式的模板实例化，可以强制编译器为所有的方法与成员生成代码，包括虚方法和非虚方法。此外，用来显式实例化类模板的类型必须能用于模板的所有成员。
### Template Requirements on Types
在编写与类型无关的代码时，必须对这些类型有一些假设。如果在程序中试图用一种不支持模板使用的所有操作的类型对模板进行实例化，那么这段代码无法编译，而且错误消息几乎总是晦涩难懂。此外，就算要使用的类型不支持所有模板代码所需的操作， 也仍然可以利用选择性实例化使用某些方法，而避免使用另一些方法。 
`Cpp20` 引入概念，允许编写编译器可以解释和验证的模板参数需求。如果传递给实例化模板的模板实参不满足这些要求，编译器会生成更多可读的错误。
## Template Parameters
### Template Parameters and Scope Operators
模板参数遵循普通的作用域规则，会隐藏外层作用域中声明的相同名字，而且在模板内不能重用模板参数名。
```c++
typedef double A;
template <typename A, typename B>
void f(A a, B b)
{
    A tmp = a;   // tmp has same type as the template parameter A, not double
    double B;    // error: redeclares template parameter B
}
```
在非模板代码中，编译器知道类的定义。因此，它知道通过作用域运算符访问的名字是类型还是 `static` 成员。例如，如果 `string::size_type`，编译器有 `string` 的定义，从而知道 `size_type` 是一个类型。
对于模板代码就存在困难，模板中的代码使用作用域运算符 `::` 时，编译器无法确定其访问的名字是类型还是 `static` 成员。假定 `T` 是一个模板类型参数，当编译器遇到类似 `T::mem` 这样的代码时，它无从得知 `mem` 是一个类型成员还是一个 `static` 数据成员，直至实例化时才会知道，但为处理模板，编译器必须知道名字是否表示一个类型。
默认情况下，`Cpp` 假定模板中通过作用域运算符访问的名字是 `static` 成员。因此，如果需要使用一个模板类型参数的类型成员，就必须使用关键字 `typename` 显式地告知编译器该名字是一个类型。
```c++
template <typename T>
typename T::value_type top(const T& c)
{
    if (!c.empty())
        return c.back();
    else
        return typename T::value_type();
}
```
### Template Type Parameters
可声明任意数目的类型参数。例如，可给网格模板添加第二个类型参数，以表示这个网格构建于另一个模板化的类容器之上。通过另一个模板的类型参数，可以让用户指定底层容器是 `vector` 还是 `deque`，该实现使用容器的 `resize` 方法和容器的 `value_type` 类型别名，因此使用 `concept` 强制给定的容器支持这些。
```cpp
template <typename Container>
concept ContainerType = requires(Container c)
{
    c.resize(1);
    typename Container::value_type;
};

template <typename T, ContainerType Container>
class Grid
{
    ... 
    std::vector<Container> m_cells;
};

template <typename T, ContainerType Container>
typename Container::value_type&
 Grid<T, Container>::at(size_t x, size_t y)
{
    return const_cast<typename Container::value_type&>(
    std::as_const(*this).at(x, y));
}

template <typename T,
 ContainerType Container = std::vector<std::optional<T>>>
class Grid
{
    // Everything else is the same as before.
};

Grid<int, vector<optional<int>>> myIntVectorGrid;
Grid<int, deque<optional<int>>> myIntDequeGrid;
myIntVectorGrid.at(3, 4) = 5;
cout << myIntVectorGrid.at(3, 4).value_or(0) << endl;
myIntDequeGrid.at(1, 2) = 3;
cout << myIntDequeGrid.at(1, 2).value_or(0) << endl;
Grid<int, vector<optional<int>>> grid2 { myIntVectorGrid };
grid2 = myIntVectorGrid;

Grid<int, double> test; // WILL NOT COMPILE
```
### Template Template Parameters
如果想要接收模板作为模板参数，那么可以使用 `template template` 参数。指定 `template template` 参数，指定 `template template` 参数时，`template template` 参数的完整规范包括该模板的参数。 例如，`vector` 和 `deque` 等容器有一个模板参数列表：
```cpp
template <typename E, typename Allocator = std::allocator<E>>
class vector { /* Vector definition */ };
```
要把这样的容器传递为 `template template` 参数，只能复制并粘贴类模板的声明，并用参数名 `Container` 替代类名 `vector`，将它用作另一个模板声明的 `template template` 参数：
```cpp
template <typename T, template <typename E, 
typename Allocator = std::allocator<E>> class Container = std::vector>
class Grid
{
public:
    // Omitted code that is the same as before.
    std::optional<T>& at(size_t x, size_t y);
    const std::optional<T>& at(size_t x, size_t y) const;
    // Omitted code that is the same as before.
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::vector<Container<std::optional<T>>> m_cells;
    size_t m_width { 0 }, m_height { 0 };
};
```
第一个模板参数与以前一样：元素类型 `T`。第二个模板参数现在本身就是容器的模板，如 `vector` 或 `deque`。如前所述，这种模板类型必须接收两个参数：元素类型 `E` 和分配器类型。注意嵌套模板参数列表后面重复的单词 `class`，这个参数在 `Grid` 模板中的名称是 `Container`。默认值现为 `vector` 而不是 `vector<T>`，因为 `Container` 是模板而不是实际类型。在代码中不要使用 `Container` 本身，而必须把 `Container<std::optional<T>>` 指定为容器类型。
`template template` 参数更通用的语法规则是：
```cpp
template <..., template class ParameterName, ...>
template <..., template typename ParameterName, ...>
```
不需要更改方法定义，但必须更改模板行，例如:
```cpp
template <typename T,
 template <typename E, typename Allocator = std::allocator<E>> class Container>
void Grid<T, Container>::verifyCoordinate(size_t x, size_t y) const
{
 // Same implementation as before...
}

// 若没有 template template 参数，必须在 vector 中同时为 Grid 和 vector 指定元素类型
// Grid<int, vector<optional<int>>> myIntGrid;
Grid<int, vector> myGrid;
myGrid.at(1, 2) = 3;
cout << myGrid.at(1, 2).value_or(0) << endl;
Grid<int, vector> myGrid2 { myGrid };
Grid<int, deque> myDequeGrid;
```
### Non-type Template Parameters
非类型的模板参数需要用特定的类型名来指定，表示一个值而非一个类型，只能是整数类型、枚举类型、指针、引用、`nullptr`、`auto`。绑定到整型非类型参数的实参必须是一个常量表达式。绑定到指针或引用非类型参数的实参必须具有静态的生存期，不能用普通局部变量或动态对象作为指针或引用非类型参数的实参。从 `Cpp20` 开始，可允许浮点型(甚至类类型)的非类型的模板参数，但会有很多限制。
在 `Grid` 类模板中，可通过非类型模板参数指定网格的高度和宽度，而不是在构造函数中指定它们。在模板列表中指定非类型参数而不是在构造函数中指定的主要好处是在编译代码之前就己经知道这些参数的值。编译器为模板化的方法生成代码的方式是通过在编译之前替换模板参数。因此，在这个实现中，可使用普通的二维数组而不是动态分配大小的 `vector`：
```cpp
template <typename T, size_t WIDTH, size_t HEIGHT>
class Grid  {
public:
    Grid() = default;
    virtual ~Grid() = default;
    
    Grid(const Grid& src) = default;
    Grid& operator=(const Grid& rhs) = default;
    std::optional<T>& at(size_t x, size_t y);
    const std::optional<T>& at(size_t x, size_t y) const;
    
    size_t getHeight() const { return HEIGHT; }
    size_t getWidth() const { return WIDTH; }
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::optional<T> m_cells[WIDTH][HEIGHT];
};

template <typename T, size_t WIDTH, size_t HEIGHT>
const std::optional<T>& Grid<T, WIDTH, HEIGHT>::at(size_t x, size_t y) const
{
    verifyCoordinate(x, y);
    return m_cells[x][y];
}

template <typename T, size_t WIDTH, size_t HEIGHT>
std::optional<T>& Grid<T, WIDTH, HEIGHT>::at(size_t x, size_t y)
{
    return const_cast<std::optional<T>&>(std::as_const(*this).at(x, y));
}
```
但实际中的限制比想象中的要多，不能通过非常量的整数指定高度或宽度：
```cpp
size_t height { 10 };
Grid<int, 10, height> testGrid; // DOES NOT COMPILE

const size_t height { 10 };
Grid<int, 10, height> testGrid; // Compiles and works

constexpr size_t getHeight() { return 10; }
...
Grid<double, 2, getHeight()> myDoubleGrid; // Compiles and works
```
另一个限制可能更明显，既然宽度和高度都是模板参数，那么它们也是每种网格类型的一部分，这意味着 `Grid<int, 10, 10>` 和 `Grid<int, 10, 11>` 是两种不同类型。不能将一种类型的对象赋给另一种类型的对象，而且一种类型的变量不能传递给接收另一种类型的变量的函数或方法。
有时可能想让用户指定一个默认元素，用来初始化网格中的每个单元格。下面是实现这个目标的一种完全合理的方法，它使用 `T{}` 作为第二个模板参数的默认值，可使用 `T` 的初始值来初始化网格中的每个单元格：
```cpp
template <typename T, const T DEFAULT = T{}>
class Grid
{
 // Identical as before.
};

template <typename T, const T DEFAULT>
Grid<T, DEFAULT>::Grid(size_t width, size_t height)
 : m_width { width }, m_height { height }
{
    m_cells.resize(m_width);
    for (auto& column : m_cells) {
        column.resize(m_height);
        for (auto& element : column) 
            element = DEFAULT;
    }
}
```
其他的方法定义保持不变，只是必须向模板行添加第二个模板参数，所有 `Grid<T>` 实例要变为 `Grid<T, DEFAULT>` 完成这些修改后，可实例化一个 `int` 网格，并为所有元素设置初始值，初始值可以是任何整数。但是，假设尝试创建一个 `SpreasheetCell` 网格会导致编译错误，因为不能向非类型参数传递对象作为参数。
```cpp
Grid<int> myIntGrid; // Initial value is 0
Grid<int, 10> myIntGrid2; // Initial value is 10

SpreadsheetCell defaultCell;
Grid<SpreadsheetCell, defaultCell> mySpreadsheet; // WILL NOT COMPILE
```
允许用户指定网格初始元素值的一种更详尽方式是使用 `T` 引用作为非类型模板参数，从而可以为任何类型实例化这个类模板。然而，作为第二个模板参数传递的引用必须具有链接(外部链接或内部链接)。下面的示例使用内部链接的初始值声明 `int` 和 `SpreadsheetCell` 网络：
```cpp
export template <typename T, const T& DEFAULT>
class Grid
{
    // Everything else is the same as the previous example.
};

namespace {
    int defaultInt { 11 };
    SpreadsheetCell defaultCell { 1.2 };
}

int main()
{
    Grid<int, defaultInt> myIntGrid;
    Grid<SpreadsheetCell, defaultCell> mySpreadsheet;
}
```
### Default Values for Type Parameters
如果继续采用将高度和宽度作为模板参数的方式，就可能需要为高度和宽度提供默认值：
```cpp
template <typename T = int, size_t WIDTH = 10, size_t HEIGHT = 10>
```
只需要在类的定义中提供默认值，不需要在方法定义的模板规范中指定默认值。
模板参数列表中默认参数的规则与函数或方法是一样的，可以从右向左提供参数的默认值。如果一个类模板为其所有模板参数都提供了默认实参，当实例化时仍需要指定一组空尖括号：
```cpp
template <class T = int>
class Numbers
{ // by default T is int
public:
    Numbers(T v = 0): val(v) { }
    // various operations on numbers
private:
    T val;
};

Numbers<long double> lots_of_precision;
Numbers<> average_precision;    // empty <> says we want the default type

// 函数模板不需要 <>
// compare has a default template argument, less<T>
// and a default function argument, F()
template <typename T, typename F = less<T>>
int compare(const T &v1, const T &v2, F f = F()) {
    if (f(v1, v2)) return -1;
    if (f(v2, v1)) return 1;
    return 0;
}
```
### Class Template Argument Deduction
通过类模板实参推导，编译器可以自动从传递给类模板构造函数的实参推导出模板参数。
在使用模板类时，都必须指明模板类的模板参数后才能使用。初始化一个序对类型时，明显可以通过构造传递的两个值的类型得到 `pair<int, double>`，但是在 `C++17` 之前，尽管编译器知道这些类型，仍需显式指明模板类的模板参数：
```c++
std::vector<int> foo{1, 2};
std::pair<int, double> bar{1, 2.0};
```
标准库也发现了这一点，提供了一些辅助模板函数来解决这个问题。函数模板始终支持基于传递给函数模板的实参自动推导模板参数。因此，`make_pair` 能根据传递给它的值自动推导模板类型参数。 
`C++17` 起引入的 `CTAD` 就是为解决模板类需要显式指明模板参数的问题：
```c++
std::vector foo{1, 2};
std::pair bar{1, 2.0};
```
考虑用户实现一个模板类，最简单的情况下，只要模板类参数和构造函数能够对应得上，对于编译器来说没有什么歧义，构造的时候就能推导出类型。
```c++
template<typename T, typename U> 
struct Pair {
    Pair();
    Pair(T, U);
    //... 
};
Pair foo{1, 2};
```
在这个例子中，在构造 `Pair` 时编译器能够正确地通过模板参数推导出其构造函数的模板参数，同时将模板参数运用于最终的模板类上。然而当使用默认方式构造 `Pair{}` 时将触发编译错误，因为编译器无法得知这两个模板参数，`Pair{}` 也没有提供默认的模板参数。
当构造函数与模板类参数无法对应时，这时候需要程序员定义一些推导规则，编译器会优先考虑推导规则：
```c++
template<typename T, typename U> 
struct Pair {
    template<typename A, typename B> 
    Pair(A&&,B&&);
    //... 
};
Pair foo{1, 2}; // 编译错误！
```
这个例子与前面稍微不同，构造函数与模板类的模板参数不一致，编译器会认为 T 与U、A与B是不同的类型，因此无法通过构造函数得知最终的模板类参数。这时可以通过添加推导规则来解决这个问题。
在做模板参数推导时，推导规则拥有很高的优先级，编译器会优先考虑推导规则，之后才考虑通过构造函数来推导。
```c++
template<typename T, typename U> 
Pair(T, U) -> Pair(T, U);

SpreadsheetCell(const char*) -> SpreadsheetCelKstd::string>;

explicit TemplateName(Parameters) -> DeducedTemplate;
```
上述规则相当于告诉编译器，当通过诸如 `Pair(T, U)` 的方式构造程序时，自行推导出模板类 `Pair<T,U>` 。因此 `Pair{1, 2}` 会得到正确的 `Pair<int, int>` 类型。`CTAD` 特性与推导规则是非侵入式的，为已有的模板类添加推导规则并不会破坏已有的显式指明的代码。
## Method Templates
普通/模板类都可以包含本身是模板的方法，但不能用方法模板编写虚方法和析构函数。
考虑一个函数接收类型为 `Grid<double>` 的对象，则不能传入 `Grid<int>`。即使 `int` 可以强制转换为 `double`，也不能将类型为 `Grid<double>` 的对象赋给类型为 `Grid<int>` 对象，也不能从`Grid<double>` 的对象构造 `Grid<int>` 对象。下面两行代码都无法编译：
```cpp
myDoubleGrid = myIntGrid; // DOES NOT COMPILE
Grid<double> newDoubleGrid { myIntGrid }; // DOES NOT COMPILE
// 问题在于 Grid 模板的拷贝构造函数和赋值运算符如下所示:
Grid(const Grid<T>& src);
Grid<T>& operator=(const Grid<T>& rhs);
```
在 `Grid` 类中添加模板化的拷贝构造函数和赋值运算符，可生成一种将网格类型转换为另一种网格类型的方法，从而修复这个疏漏：
```cpp
template <typename T>
class Grid
{
public:
    template <typename E>
    Grid(const Grid<E>& src);
    template <typename E>
    Grid& operator=(const Grid<E>& rhs);
    void swap(Grid& other) noexcept;
};

template <typename T>
template <typename E>
Grid<T>::Grid(const Grid<E>& src)
 : Grid { src.getWidth(), src.getHeight() } {
    // The ctor-initializer of this constructor delegates first to the
    // non-copy constructor to allocate the proper amount of memory.
    for (size_t i { 0 }; i < m_width; i++) 
        for (size_t j { 0 }; j < m_height; j++) 
            m_cells[i][j] = src.at(i, j);
}
```
不能删除原始拷贝构造函数和拷贝赋值运算符。这个类在类型 `T` 上被模板化, 这个新的拷贝构造函数又在另一个不同的类型 `E` 上被模板化。如果 `E` 等于 `T`，那么编译器将不会调用这些新的模板化拷贝构造函数和模板化拷贝赋值运算符。
除了构造函数定义之前的额外模板参数行之外，注意必须通过公共的访问方法访问 `src` 中的元素。这是因为复制目标对象的类型为 `Grid<T>`，而复制来源对象的类型为 `Grid<E>`。这两者不是同一类型，因此必须使用公共方法。
模板化的赋值运算符接收 `const Grid<E>&` 作为参数，但返回 `Grid<T>&`：
```cpp
template <typename T>
void Grid<T>::swap(Grid& other) noexcept
{
    std::swap(m_width, other.m_width);
    std::swap(m_height, other.m_height);
    std::swap(m_cells, other.m_cells);
}

template <typename T>
template <typename E>
Grid<T>& Grid<T>::operator=(const Grid<E>& rhs)
{
    // Copy-and-swap idiom
    Grid<T> temp { rhs }; // Do all the work in a temporary instance.
    swap(temp); // Commit the work with only non-throwing operations.
    return *this;
}
```
`swap` 方法只能交换同类网格，但这是可行的，因为模板化的赋值运算符首先使用模板化的拷贝构造函数，将给定的 `Grid<E>` 转换为 `Grid<T>`，即 `temp`。此后使用 `swap` 方法，将 `Grid<T>` 类型的 `this` 替换临时的 `Grid<T>`。
为实例化一个类模板的方法模板，必须同时提供类和方法模板的实参。在哪个对象上调用方法模板，编译器就根据该对象的类型来推断类模板参数的实参。与普通函数模板相同，编译器通常根据传递给方法模板的函数实参来推断它的模板实参：
```c++
template <typename T>
class Blob {
    template <typename It>
    Blob(It b, It e);
};

template <typename T>   // type parameter for the class
template <typename It>  // type parameter for the constructor
Blob<T>::Blob(It b, It e): 
			data(std::make_shared<std::vector<T>>(b, e)) { }

int ia[] = {0,1,2,3,4,5,6};
vector<long> vi = {0,1,2,3,4,5,6,7,8,9}; 
list<const char*> w = {"now", "is", "the"} 
// 实例化 Blob<int>类及其接受两个int*参数的构造函数
Blob<int> a1(begin(ia), end(ia));
// 实例化Blob<int>类的接受两个vector<long>::iterator的构造函数 
Blob<int> a2(vi.begin(), vi.end());
// 实例化Blob<string>及其接受两个list<const char*>::iterator 参数的构造函数 
Blob<string> a3(w.begin(), w.end());
```
在之前用于 `HEIGHT` 和 `WIDTH` 整数模板参数的例子中[[ClassTemplate#Non-type Template Parameters]]，一个主要问题是高度和宽度成为类型的一部分。因为存在这个限制，所以不能将一个拥有某种高度和宽度的网格赋值给另一个拥有不同高度和宽度的网格。
不一定要把源对象完美地复制到目标对象，可从源数组中只复制那些能够放在目标数组中的元素；如果源数组在任何一个维度上都比目标数组小，那么可以用默认值填充目标数组。有赋值运算符和拷贝构造函数的方法模板后，可实现这个操作，从而允许对不同大小的网格进行赋值和复制。下面是类定义：
```cpp
template <typename T, size_t WIDTH = 10, size_t HEIGHT = 10>
class Grid
{
public:
    Grid() = default;
    virtual ~Grid() = default;

    Grid(const Grid& src) = default;
    Grid& operator=(const Grid& rhs) = default;
    
    template <typename E, size_t WIDTH2, size_t HEIGHT2>
    Grid(const Grid<E, WIDTH2, HEIGHT2>& src);
    
    template <typename E, size_t WIDTH2, size_t HEIGHT2>
    Grid& operator=(const Grid<E, WIDTH2, HEIGHT2>& rhs);
    
    void swap(Grid& other) noexcept;
    
    std::optional<T>& at(size_t x, size_t y);
    
    const std::optional<T>& at(size_t x, size_t y) const;
    
    size_t getHeight() const { return HEIGHT; }
    size_t getWidth() const { return WIDTH; }
    
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::optional<T> m_cells[WIDTH][HEIGHT];
};
```
将非模板化的拷贝构造函数和赋值运算符显式设置为默认(原因在于用户声明的析构函数)。这些方法只是将 `cells` 从源对象复制或赋值到目标对象，语义和两个一样大小的网格的语义完全一致。下面是模板化的拷贝构造函数：
```c++
template <typename T, size_t WIDTH, size_t HEIGHT>
template <typename E, size_t WIDTH2, size_t HEIGHT2>
Grid<T, WIDTH, HEIGHT>::Grid(const Grid<E, WIDTH2, HEIGHT2>& src)
{
    for (size_t i { 0 }; i < WIDTH; i++) 
        for (size_t j { 0 }; j < HEIGHT; j++) 
            if (i < WIDTH2 && j < HEIGHT2) m_cells[i][j] = src.at(i, j);
            else m_cells[i][j].reset();
}
```
该拷贝构造函数只从 `src` 在 `x` 维度和 `y` 维度上分别复制 `WIDTH` 和 `HEIGHT` 个元素，如果 `src` 在任何一个维度上都比这个指定值小，那么可以使用 `reset` 方法重置附加点中的 `std::optional` 对象。下面是 `swap` 和 `operator=` 实现：
```cpp
template <typename T, size_t WIDTH, size_t HEIGHT>
void Grid<T, WIDTH, HEIGHT>::swap(Grid& other) noexcept
{
    std::swap(m_cells, other.m_cells);
}
template <typename T, size_t WIDTH, size_t HEIGHT>
template <typename E, size_t WIDTH2, size_t HEIGHT2>
Grid<T, WIDTH, HEIGHT>& 
Grid<T, WIDTH, HEIGHT>::operator=(const Grid<E, WIDTH2, HEIGHT2>& rhs)
{
    Grid<T, WIDTH, HEIGHT> temp { rhs };
    swap(temp);
    return *this;
}
```
## Static Member
类模板可以声明 `static` 成员，类模板的每个实例都有一个独有的 `static` 对象，同类型的实例共用这个 `static` 对象。
```c++
template <typename T>
class Foo
{
public:
    static std::size_t count() { return ctr; }

private:
    static std::size_t ctr;
};

template <typename T>
size_t Foo<T>::ctr = 0;    // define and initialize ctr

// instantiates static members Foo<int>::ctr and Foo<int>::count
// all three objects share the same Foo<int>::ctr and Foo<int>::count members
Foo<int> fi, fi2, fi3;

auto ct = Foo<int>::count(); // 实例化 Foo<T>::count 
ct = fi.count(); // 使用Foo<T>::count(); 
ct = Foo::count();// 错误：使用哪个模板实例的 count? 
```
## Class Templates and Friends
当一个类包含一个友元声明时，类与友元各自是否是模板并无关联。如果一个类模板包含一个非模板友元，则友元可以访问所有类模板实例。如果友元自身是模板，则类可以给所有友元模板实例授予访问权限，也可以只授权给特定实例。
### Friends Of A Particular Instance
类模板与另一个模板间最常见的形式是建立对应实例及其友元间的友好关系。友元的声明用 `Blob` 的模板形参作为它们自己的模板实参，因此友元关系被限定在用相同类型实例化的 `Blob` 与 `BlobPtr` 与 `operator==` 之间。
```c++
// 为引用模板的一个特定实例，必须首先声明模板自身，模板声明包括模板参数列表
template <typename> class BlobPtr; // forward declarations needed for friend declarations in Blob
template <typename> class Blob;    // needed for parameters in operator==

template <typename T>
bool operator==(const Blob<T>&, const Blob<T>&);

template <typename T>
class Blob
{
    // 每个 Blob 实例将相同类型实例化的 BlobPtr 和相等运算符声明为友元
    friend class BlobPtr<T>;
    friend bool operator==<T>(const Blob<T>&, const Blob<T>&);
};

// BlobPtr<char> 和 operator==<char> 都是本对象的友元
// BlobPtr 的成员可以访问 ca 的非 public 部分
// 但 ca 对 ia 或 Blob 的任何其他实例都没有特殊访问权限
Blob<char> ca; 
Blob<int> ia;
```
### Friends Of All Instances
为让模板的所有实例成为友元，友元声明中必须使用与类模板本身不同的模板参数，或者让该模板包含非模板友元。当所有实例都是类的友元时，不需要前向声明，但相同类型才是友元的情况需要。
```c++
template <typename T> class Pal;

class C {
    friend class Pal<C>;    // 用类 C 实例化的 Pal 是 C 的友元
    // Pal2 的所有实例都是 C 的友元，不需要前向声明
    template <typename T> friend class Pal2;
};

template <typename T>
class C2 {
    // 每个 C2 实例将相同类型实例化的 Pal 声明为友元，需要前向声明
    friend class Pal<T>;
    // Pal2 的所有实例都是 C2 每个实例的友元，不需要前向声明
    template <typename X> friend class Pal2;
    // Pal3 是一个非模板类，它是 C2 所有实例的友元，不需要前向声明
    friend class Pal3;
};
```
`C++11` 中，类模板可以将模板类型参数声明为友元。
```c++
template <typename Type>
class Bar {
    friend Type;   // grants access to the type used to instantiate Bar
    // ...
};
```
此处将用来实例化 `Bar` 的类型声明为友元，因此，对于某个类型名 `Foo`，`Foo` 将成为 `Bar` 的友元。
## Class Template Specialization
对于特定类型，可以给类模板提供不同的实现。例如，`Grid` 的行为对 `const char*` 来说没有意义。拷贝构造函数和赋值运算符执行这种 `const char*` 指针类型的浅层复制，因此需要专门给 `const char*` 编写另一个实现，把 `C` 风格的字符串转换为 `Cpp` 字符串，并且将字符串存储在 `vector<vector<optional<string>>>` 中。
编写一个类模板的特化时，必须指明这是一个模板，以及正在为哪种特定的类型编写这个模板。
```cpp
template <>
class Grid<const char*>
{
public:
    explicit Grid(size_t width = DefaultWidth,
    size_t height = DefaultHeight);
    virtual ~Grid() = default;
    // Explicitly default a copy constructor and assignment operator.
    Grid(const Grid& src) = default;
    Grid& operator=(const Grid& rhs) = default;
    // Explicitly default a move constructor and assignment operator.
    Grid(Grid&& src) = default;
    Grid& operator=(Grid&& rhs) = default;
    std::optional<std::string>& at(size_t x, size_t y);
    const std::optional<std::string>& at(size_t x, size_t y) const;
    size_t getHeight() const { return m_height; }
    size_t getWidth() const { return m_width; }
    static const size_t DefaultWidth { 10 };
    static const size_t DefaultHeight { 10 };
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::vector<std::vector<std::optional<std::string>>> m_cells;
    size_t m_width { 0 }, m_height { 0 };
};
```
特化和派生不同，必须重新编写类的整个实现，不要求提供具有相同的名称或行为的方法。例如，Grid 的 `const char*` 特化在实现 `at` 方法时，返回的是 `optional<string>`，而非 `optional<const char*>`。
与模板定义不同，不必在每个方法定义之前重复 `template<>` 语法：
```cpp
Grid<const char*>::Grid(size_t width, size_t height)
 : m_width { width }, m_height { height }
{
    m_cells.resize(m_width);
    for (auto& column : m_cells) 
        column.resize(m_height);
}

void Grid<const char*>::verifyCoordinate(size_t x, size_t y) const
{
    if (x >= m_width) 
        throw std::out_of_range { std::format("{} must be less than {}.", x, m_width) };
    if (y >= m_height) 
        throw std::out_of_range { std::format("{} must be less than {}.", y, m_height) };
}

const std::optional<std::string>& Grid<const char*>::at(
 size_t x, size_t y) const
{
    verifyCoordinate(x, y);
    return m_cells[x][y];
}

std::optional<std::string>& Grid<const char*>::at(size_t x, size_t y)
{
    return const_cast<std::optional<std::string>&>(std::as_const(*this).at(x, y));
}
```
可以只特例化类模板的指定成员函数，而不用特例化整个模板。
```c++
template <typename T>
struct Foo {
    Foo(const T &t = T()): mem(t) { }
    void Bar() { /* ... */ }
    T mem;
};

template<>      // we're specializing a template
void Foo<int>::Bar()    // we're specializing the Bar member of Foo<int>
{
    // do whatever specialized processing that applies to ints
}

Foo<string> fs;     // instantiates Foo<string>::Foo()
fs.Bar();    // instantiates Foo<string>::Bar()
Foo<int> fi;    // instantiates Foo<int>::Foo()
fi.Bar();    // uses our specialization of Foo<int>::Bar()
```
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240124120108.png)
### Partial Specialization
可以编写部分特例化的类，这个类允许特例化部分模板参数，而不处理其他参数。例如，基本版本的 `Grid` 模板带有宽度和高度的非类型参数，可采用这种方式为 `C` 风格字符串特例化这个类模板:
```cpp
template <size_t WIDTH, size_t HEIGHT>
class Grid<const char*, WIDTH, HEIGHT>
{
public:
    Grid() = default;
    virtual ~Grid() = default;
    // Explicitly default a copy constructor and assignment operator.
    Grid(const Grid& src) = default;
    Grid& operator=(const Grid& rhs) = default;
    std::optional<std::string>& at(size_t x, size_t y);
    const std::optional<std::string>& at(size_t x, size_t y) const;
    size_t getHeight() const { return HEIGHT; }
    size_t getWidth() const { return WIDTH; }
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::optional<std::string> m_cells[WIDTH][HEIGHT];
};
```
这个模板只有两个参数 `WIDTH` 和 `HEIGHT`。然而，这个 `Grid` 类带有 3 个参数。因此，模板参数列表包含两个参数，而显式的 `Grid` 包含 3 个参数。实例化模板时仍然必须指定 3 个参数。不能只通过高度和宽度实例化模板：
```cpp
template <size_t WIDTH, size_t HEIGHT>
class Grid<const char*, WIDTH, HEIGHT>

Grid<int, 2, 2> myIntGrid; // Uses the original Grid
Grid<const char*, 2, 2> myStringGrid; // Uses the partial specialization
Grid<2, 3> test; // DOES NOT COMPILE! No type specified.
```
在部分特例化中，与完整特例化不同，在每个方法定义的前面要包含模板代码行，如下所示：
```cpp
template <size_t WIDTH, size_t HEIGHT>
const std::optional<std::string>&
 Grid<const char*, WIDTH, HEIGHT>::at(size_t x, size_t y) const
{
    verifyCoordinate(x, y);
    return m_cells[x][y];
}
```
可为可能的类型子集编写特例化的实现，而不需要为每种类型特例化。例如，可为所有的指针类型编写特例化的 `Grid` 类，这种特例化的拷贝构造函数和赋值运算符可对指针指向的对象执行深层复制，而不是保存网格中指针的浅层复制。
假设 `Grid` 成为所提供指针的拥有者，因此它在需要时自动释放内存，需要拷贝构造函数和拷贝赋值运算符：
```cpp
template <typename T>
class Grid<T*>
{
public:
    explicit Grid(size_t width = DefaultWidth, size_t height = DefaultHeight);
    virtual ~Grid() = default;
    // Copy constructor and copy assignment operator.
    Grid(const Grid& src);
    Grid& operator=(const Grid& rhs);
    // Explicitly default a move constructor and assignment operator.
    Grid(Grid&& src) = default;
    Grid& operator=(Grid&& rhs) = default;
    void swap(Grid& other) noexcept;
    std::unique_ptr<T>& at(size_t x, size_t y);
    const std::unique_ptr<T>& at(size_t x, size_t y) const;
private:
    void verifyCoordinate(size_t x, size_t y) const;
    std::vector<std::vector<std::unique_ptr<T>>> m_cells;
    size_t m_width { 0 }, m_height { 0 };
};
```
下述语法表明这个类是 `Grid` 类模板对所有指针类型的偏特化，只有 `T` 是指针类型的情况下才提供实现。
```cpp
template <typename T>
class Grid<T*>
```
如果像下面这样实例化网格，那么 `T` 实际上是 `int` 而非 `int*`。 这不够直观，但遗憾的是，这种语法就是这样使用的。下面是一个示例：
```cpp
Grid<int*> psGrid { 2, 2 }; // Uses the partial specialization for pointer types.

psGrid.at(0, 0) = make_unique<int>(1);
psGrid.at(0, 1) = make_unique<int>(2);
psGrid.at(1, 0) = make_unique<int>(3);
Grid<int*> psGrid2 { psGrid };
Grid<int*> psGrid3;
psGrid3 = psGrid2;
auto& element { psGrid2.at(1, 0) };
if (element) {
    cout << *element << endl; // 2
    *element = 6;
}
cout << *psGrid.at(1, 0) << endl; // psGrid is not modified. 3
cout << *psGrid2.at(1, 0) << endl; // psGrid2 is modified. 6
```
拷贝构造函数使用各个元素的拷贝构造函数进行深层复制：
```cpp
template <typename T>
Grid<T*>::Grid(const Grid& src)
 : Grid { src.m_width, src.m_height }
{
    // The ctor-initializer of this constructor delegates first to the
    // non-copy constructor to allocate the proper amount of memory.
    // The next step is to copy the data.
    for (size_t i { 0 }; i < m_width; i++) {
        for (size_t j { 0 }; j < m_height; j++) 
        // Make a deep copy of the element by using its copy constructor.
        if (src.m_cells[i][j]) 
            m_cells[i][j].reset(new T { *(src.m_cells[i][j]) });
    }
}
```
下述是对所有引用类型的偏特化，两个偏特化版本分别用于左值引用和右值引用类型：
```c++
// 通用版本
template <typename T>
struct remove_reference {
    typedef T type;
};

// 部分特例化版本
template <typename T>
struct remove_reference<T &>   // 左值引用
{
    typedef T type;
};

template <typename T>
struct remove_reference<T &&>  // 右值引用
{
    typedef T type;
};

int i;
// decltype(42)为int，使用原始模板 
remove_reference<decltype(42)>::type a;
// decltype(i)为int&，使用第一个部分特例化版本
remove_reference<decltype(i)>::type b;
// decltype(std::move(i))为int&&，使用第二个部分特例化版本 
remove_reference<decltype (std::move(i))>::type c;

// 三个变量 abc 均为 int 类型
```
下述是所有特例化的例子：
```c++
template<typename T, class N>
class TestClass {
public:
    static void comp(T num1, N num2) {
        cout << "standard class template" << endl;
    }
};

//对部分模板参数进行特化
template<class N>
class TestClass<int, N> {
public:
    static void comp(int num1, N num2) {
        cout << "partitial specialization" << endl;
    }
};

//将模板参数特化为指针
template<typename T, class N>
class TestClass<T*, N*> {
public:
    static void comp(T *num1, N *num2) {
        cout << "new partitial specialization" << endl;
    }
};

//将模板参数特化为另一个模板类
template<typename T, class N>
class TestClass<vector<T>, vector<N>> {
public:
    static void comp(const vector<T> &vecLeft, const vector<N> &vecRight) {
        cout << "to vector partitial specialization" << endl;
    }
};

int main() {
    //调用非特化版本
    TestClass<char, char>::comp('0', '1');

    //调用部分模板参数特化版本
    TestClass<int, char>::comp(30, '1');

    //调用模板参数特化为指针版本
    int a = 30;
    char c = '1';
    TestClass<int*, char*>::comp(&a, &c);

    //调用模板参数特化为另一个模板类版本
    vector<int> vecLeft{0};
    vector<int> vecRight{1, 2, 3};
    TestClass<vector<int>, vector<int>>::comp(vecLeft, vecRight);
}
```
## Deriving from Class Templates
可从类模板中派生。如果一个派生类从模板本身继承，那么这个派生类也必须是模板。此外，还可从类模板派生某个特定实例，这种情况下，这个派生类不需要是模板。下面针对前一种情况举一个例子，假设 `Grid` 类没有提供足够的棋盘功能。确切地讲，要给棋盘添加 `move` 方法，允许棋盘上的棋子从一个位置移动到另一个位置。下面是这个 `GameBoard` 模板的类定义：
```cpp
template <typename T>
class GameBoard : public Grid<T>
{
public:
    explicit GameBoard(size_t width = Grid<T>::DefaultWidth,
    size_t height = Grid<T>::DefaultHeight);
    void move(size_t xSrc, size_t ySrc, size_t xDest, size_t yDest);
};
```
这个 `GameBoard` 派生自 `Grid` 模板，因此继承了 `Grid` 模板的功能。不需要重写其他任何方法，也不需要添加拷贝构造函数、`operator=` 或析构函数，因为在 `GameBoard` 中没有任何动态分配的内存。 
继承的语法和普通继承一样，区别在于基类是 `Grid<T>`，而不是 `Grid`。设计这种语法的原因是 `GameBoard` 模板并没有真正地派生自通用的 `Grid` 模板。相反，`GameBoard` 模板对特定类型的每个实例化都派生自 `Grid` 对那种类型的实例化。
例如，如果使用 `ChessPiece` 类型实例化 `GameBoard`, 那么编译器也会生成 `Grid<ChessPiece>` 的代码。`：public Grid` 语法表明，这个类继承了  `Grid<T>` 实例化对类型参数 `T` 有意义的所有内容。虽然某些编译器并不强制它，但 `C++` 名称查找的规则要求使用 `this` 指针或 `Grid::` 来指定基类模板中的数据成员和方法。
```cpp
template <typename T>
GameBoard<T>::GameBoard(size_t width, size_t height)
 : Grid<T> { width, height } { }
 
template <typename T>
void GameBoard<T>::move(size_t xSrc, size_t ySrc, size_t xDest, size_t yDest)
{
    Grid<T>::at(xDest, yDest) = std::move(Grid<T>::at(xSrc, ySrc));
    Grid<T>::at(xSrc, ySrc).reset(); // Reset source cell
    // Or:
    // this->at(xDest, yDest) = std::move(this->at(xSrc, ySrc));
    // this->at(xSrc, ySrc).reset();
}
```
## Alias Templates
可使用类型别名给模板化的类赋予另一个名称。假定有如下类模板，可以定义如下类型别名，给定两个类模板的类型参数。
```cpp
template <typename T1, typename T2>
class MyClassTemplate { /* ... */ };

using OtherName = MyClassTemplate<int, double>;
```
还可以仅指定一些类型，其他类型则保持为模板类型参数，这称为别名模板：
```cpp
template <typename T1>
using OtherName = MyClassTemplate<T1, double>;
```
## Variable Templates
除了类模板、类方法模板和函数模板外，`Cpp` 还支持变量模板。语法如下: 
```cpp
template <typename T>
constexpr T pi { T { 3.141592653589793238462643383279502884 } };
```
这是 `pi` 值的可变模板。为了在某种类型中获得 `pi` 值，可以使用如下语法: 
```cpp
float piFloat { pi<float> };
auto piLongDouble { pi<long double> };
```
这样总会得到在所请求的类型中可表示的 `pi` 近似值。与其他类型的模板一样，变量模板也可以特化。
## Template Recursion
可以只编写一个一维网格。然后，利用另一个网格作为元素类型实例化 `Grid`, 创建任意维度的网格。这种 `Grid` 元素类型本身可以用网格作为元素类型进行实例化，以此类推。
```cpp
template <typename T>
class OneDGrid
{
public:
    explicit OneDGrid(size_t size = DefaultSize) { resize(size); }
    virtual ~OneDGrid() = default;
    T& operator[](size_t x) { return m_elements[x]; }
    const T& operator[](size_t x) const { return m_elements[x]; }
    void resize(size_t newSize) { m_elements.resize(newSize); }
    size_t getSize() const { return m_elements.size(); }
    static const size_t DefaultSize { 10 };
private:
    std::vector<T> m_elements;
};
OneDGrid<int> singleDGrid;
OneDGrid<OneDGrid<int>> twoDGrid;
OneDGrid<OneDGrid<OneDGrid<int>>> threeDGrid;
singleDGrid[3] = 5;
twoDGrid[3][3] = 5;
threeDGrid[3][3][3] = 5;
```
可将嵌套的每层 `OneDGrid` 想象为一个递归步骤，`int` 的 `OneDGrid` 是递归的基本情形。换句话说,三维网格是 `int` —维网格的一维网格的一维网格。用户不需要自己进行递归，可以编写一个类模板来自动进行递归。然后，可创建如下 `N` 维网格：
```cpp
NDGrid<int, 1> singleDGrid;
NDGrid<int, 2> twoDGrid;
NDGrid<int, 3> threeDGrid;
```
NDGrid 类模板需要元素类型和表示维度的整数作为参数。这里的关键问题在于，`NDGrid` 的元素类型不是模板参数列表中指定的元素类型，而是上一层递归的维度中指定的另一个 `NDGrid`。使用递归时，需要处理 `base case`。可编写维度为 1 的部分特例化的 `NDGrid`，其中元素类型不是另一个 `NDGrid`，而是模板参数指定的元素类型。 
下面是 `NDGrid` 模板定义和实现，模板递归实现最棘手的部分不是模板递归本身，而是网格中每个维度的正确大小。这个实现创建了 `V` 维网格，每个维度都一样大，为每个维度指定不同的大小要困难得多。然而，即使这样简化，用户也应该有能力创建指定大小的数组。因此，构造函数接收一个整数作为大小 参数。
然而，当动态重设子网格的 `vector` 时，不能将这个大小参数传递给子网格元素，因为 `vector` 使用默认的构造函数创建对象。因此，必须对 `vector` 的每个网格元素显式调用 `resize`。
注意 `m_elements` 是 `NDGrid<T，N - 1>` 的 `vector`。此外，`operator[]` 返回 `NDGrid` 类型的引用，而不是 `T`。
```cpp
template <typename T, size_t N>
class NDGrid
{
public:
    explicit NDGrid(size_t size = DefaultSize) { resize(size); }
    virtual ~NDGrid() = default;
    
    NDGrid<T, N-1>& operator[](size_t x) { return m_elements[x]; }
    const NDGrid<T, N-1>& operator[](size_t x) const { return m_elements[x]; }
    
    void resize(size_t newSize)
    {
        m_elements.resize(newSize);
        // Resizing the vector calls the 0-argument constructor for
        // the NDGrid<T, N-1> elements, which constructs
        // it with the default size. Thus, we must explicitly call
        // resize() on each of the elements to recursively resize all
        // nested Grid elements.
        for (auto& element : m_elements) 
        element.resize(newSize);
    }
    size_t getSize() const { return m_elements.size(); }
    static const size_t DefaultSize { 10 };
private:
    std::vector<NDGrid<T, N-1>> m_elements;
};
```
基本用例的模板定义是维度为 1 的部分特化，下面突出显示了定义和实现。请注意，必须重写很多代码，因为不能在特例化中继承任何实现，注意 `m_elements`、`operator[]` 与非特例化 `NDGrid` 之间的差异：
```cpp
template <typename T>
class NDGrid<T, 1>
{
public:
    explicit NDGrid(size_t size = DefaultSize) { resize(size); }
    virtual ~NDGrid() = default;
    T& operator[](size_t x) { return m_elements[x]; }
    const T& operator[](size_t x) const { return m_elements[x]; }
    void resize(size_t newSize) { m_elements.resize(newSize); }
    size_t getSize() const { return m_elements.size(); }
    static const size_t DefaultSize { 10 };
private:
    std::vector<T> m_elements;
};

NDGrid<int, 3> my3DGrid { 4 };
my3DGrid[2][1][2] = 5;
my3DGrid[1][1][1] = 5;
cout << my3DGrid[2][1][2] << endl;
```
## CRTP
奇异递归模板模式(`Curiously Recurring Template Pattern`，`CRTP`)是 `C++` 模板编程的一种惯用法：把派生类作为基类的模板参数，从而让基类可以使用派生类提供的方法。
这种方式一般有如下两种用途：
- 代码复用：由于子类派生于模板基类，因此可以复用基类的方法。
- 编译时多态：由于基类是一个模板类，能够获得传递进来的派生类，进而可以调用派生类的方法，达到多态的效果，与运行时多态相比没有虚表开销。
根据定义，样板代码通常是如下形式：
```c++
template<class T> struct Base { /*...*/ }; 
struct Derived : Base<Derived> { /*...*/ };
```
### Code Reuse
访问者模式(Visitor Pattern)是面向对象编程中一个经典的设计模式，这个模式的基本想法如下：假设拥有一个由不同种类的对象构成的对象结构，这些对象的类都拥有一个 `accept` 方法用来接受访问者对象；访问者是一个接口，它拥有一个 `visit` 方法，这个方法可以对访问到的对象结构中不同类型的元素做出不同的反应。
在对象结构的一次访问过程中，遍历整个对象结构，对每一个元素都调用 `accept` 方法，在每一个元素的 `accept` 方法中回调访问者的 `visit` 方法，从而使访问者得以处理对象结构的每一个元素。可以针对对象结构设计不同的访问者类来完成不同的操作，在编译器实现中往往涉及大量的访问者模式代码。
```c++
struct Visitor{
    virtual void visit(VideoFile&) = 0; // 函数重载机制，静态绑定 
    virtual void visit(TextFile&) = 0; 
    virtual ~Visitor() = default; 
};

struct Elem {
    virtual void accept(Visitor& visit) = 0; // 虚函数动态绑定
    virtual ~Elem() = default;
};
```
这里涉及两个多态结构的派发，即双重派发：
- 被访问对象的接口 `accept` 运行时接收 `visitor` 访问者对象，通过虚函数动态派发到对应的访问者，即动态绑定
- 然后访问者通过函数重载静态派发到对应的访问对象，即静态绑定
假如当前系统中存在两个元素 `File` 和 `Directory`，它们的对应实现可能为：
```c++
struct VideoFile : Elem ｛ 
    void accept(Visitor& visitor) override  // 虚函数动态绑定
    { visitor.visit(*this); } // 函数重载机制，静态绑定 
};

struct TextFile : Elem ｛ 
    void accept(Visitor& visitor) override // 虚函数动态绑定
    { visitor.visit(*this); } // 函数重载机制，静态绑定 
};
```
随着系统的演进，将来会有越来越多重复的 `accept` 实现，而它们都是简单地通过函数重载方式进行静态绑定。那么可否考虑将 `accept` 的实现都放到基类Elem中，从而减少这种重复的代码呢？答案是否定的，因为 `this` 类型实际上是该类的指针类型，如果放到基类中，那么 `this` 将为基类的指针，丢失类型信息后将无法静态绑定，也无法满足复用代码的要求。
虽然各个元素类产生了重复代码，而它们的差异点在于隐含的this类型，如果将该类型参数化，那么便能复用代码。通过使用奇异递归模板模式，基类的模板类型将会参数化派生类的类型，便能在静态分发的同时又能复用代码。重构后的代码如下：
```c++
template<typename Derived> struct AutoDispatchElem : Elem {
    void accept (Visitor& visitor) override
    { visitor.visit(static_cast<Derived&>(*this)); } 
};
struct VideoFile : AutoDispatchElem<VideoFile> { /*...*/};
struct TextFile : AutoDispatchElem<TextFile> { /*...* / };
```
由于模板基类 `AutoDispatchElem` 能够获得派生类的类型，通过将this类型静态转换到派生类的过程是安全的，进而能够重载到合适的 `visit` 函数上。而派生类继承自模板基类，也能够获得基类的 `accept` 实现，从而满足代码复用的要求。
### Static Polymorphism
```c++
template<typename Derived> 
struct Animal {
    void bark() { 
        static_cast<Derived&>(* this).barkImpl(); 
    } 
}; 
class Cat : public Animal<Cat> {
    friend Animal; // 使用class默认实现对外不可见，同时对Animal 友元，只让基类访问。 
    void barkImp1 () { cout << "Miaowing!" <<endl; }
};
class Dog : public Animal<Dog> { 
    friend Animal;
    void barkImpl() { cout << "Bow wow!" << endl; } 
};
```
动物基类 `Animal` 提供了一个接口 `bark` 供用户使用，而实现的时候转调到派生类中的 `barklmpl` 函数。用户可以实现一个函数 `play` 与这些动物进行交互。
```c++
template<typename T>
void play (Animal<T>& animal) { /*...*/animal.bark();/* ...*/} 
Cat cat; play(cat); // Miaowing!
Dog dog; play (dog);// Bow wow!
```
从 `play` 的实现来看，它接受一个统一的“抽象”接口类，而调用的时候，根据传入的实际类型是 `Cat` 还是 `Dog` 进行多态调用。由于类型是在编译时确定的，那么多态调用也是在编译时调用的。读者可能会疑问，为何不直接把 `play` 写成模板函数的形式？这样无需模板基类 `Animal` 也能实现静态多态。原因在于奇异递归模板模式的模板基类可以起到接口类的作用，它明确列出了该派生体系中所支持的一组操作，换句话说 `Animal<T>` 其实是对它所接受的类型、所支持的方法集合进行约束，而普通的模板函数对模板参数没有约束，需要使用高级技巧（如 `enable_if` 或 `concept`）进行约束。
## Variadic Templates
普通模板只可采取固定数量的模板参数，可变参数模板可接收可变数目的模板参数，用 `…` 来指出模板参数或函数参数表示一个包。在一个模板参数列表中，`class…` 或 `typename…` 指出接下来的参数表示多个类型的列表：
```cpp
template <typename... Types>
class MyVariadicTemplate { };
```
可用任何数量的类型实例化 `MyVariadicTemplate`，例如
```cpp
MyVariadicTemplate<int> instance1;
MyVariadicTemplate<string, double, vector<int>> instance2;
MyVariadicTemplate<> instance3;
// 为阻止用零个模板参数实例化可变参数模板，可以像下面这样编写模板:
template <typename T1, typename... Types>
class MyVariadicTemplate { };
```
可以使用 `sizeof…` 运算符获取参数包中的元素数量，`sizeof…` 返回一个常量表达式，而且不会对其实参求值。
```c++
template<typename ... Args>
void g(Args ... args) {
    cout << sizeof...(Args) << endl;    // number of type parameters
    cout << sizeof...(args) << endl;    // number of function parameters
}
```
### Type-Safe Variable-Length Argument Lists
可变参数模板允许创建类型安全的变长参数列表。下面例子定义的可变参数模板允许以类型安全的方式接收不同类型的可变数目的参数。函数 `processValues` 会处理变长参数列表中的每个值，对每个参数执行 `handleValue` 函数。这意味着必须对每种要处理的类型编写 `handleValue` 函数，例如下例中的 `int`、`double` 和 `string`。
用在模板参数列表中 `typename` 后面的 `...` 表示参数包，参数包可接收可变数目的参数，在函数参数列表中，如果一个参数的类型是模板参数包，则此参数也是函数参数包。
用在函数体中参数名 `args` 与函数参数列表中类型 `Tn` 后面的 `...` 表示参数包扩展。
```cpp
void handleValue(int value) { cout << "Integer: " << value << endl; }
void handleValue(double value) { cout << "Double: " << value << endl; }
void handleValue(string_view value) { cout << "String: " << value << endl; }

void processValues() // Base case to stop recursion
{ /* Nothing to do in this base case. */ }

template <typename T1, typename... Tn>
void processValues(T1 arg1, Tn... args)
{
    handleValue(arg1);
    processValues(args...);
}
```
下面将 `args` 函数参数包解包为不同的参数，通过逗号分隔参数，然后用这些展开的参数调用 `processValues` 函数。模板总是需要至少一个模板参数 `T1`，通过扩展模板参数包 `Tn` 生成函数参数列表，通过 `args...` 递归调用 `processValues` 的结果是每次调用都会少一个模板参数。 
```cpp
processValues(args...);
```
由于 `processValues` 函数的实现是递归的，因此需要采用一种方法停止递归。为此，实现一个接收零个参数的 `processValues` 函数。
重要的是要记住，这种变长参数列表是完全类型安全的。`processValues` 函数会根据实际类型自动调用正确的 `handleValue` 重载版本。`Cpp` 中也会像通常那样自动执行类型转换。例如，前面例子中  `1.1f` 的类型为 `float`。`processValues` 函数会调用 `handleValue(double value)`，因为从 `float` 到 `double` 的转换没有任何损失。然而，如果调用 `processValues` 时带有某种类型的参数，而这种类型没有对应的 `handleValue` 函数，编译器会产生错误。 
前面的实现存在一个小问题，由于这是一个递归的实现，因此每次递归调用 `processValues` 时都会复制参数。根据参数的类型，这种做法的代价可能会很高。可能会认为，向 `processValues` 函数 传递引用而不使用按值传递方法，就可以避免这种复制问题，但这样也无法通过字面量调用 `processValues`，因为不允许使用字面量引用，除非使用 `const` 引用。 为了在使用非 `const` 引用的同时也能使用字面量值，可使用转发引用：
```cpp
void processValues() // Base case to stop recursion
{ /* Nothing to do in this base case.*/ }

template <typename T1, typename... Tn>
void processValues(T1&& arg1, Tn&&... args)
{
    handleValue(forward<T1>(arg1));
    processValues(forward<Tn>(args)...);
}
```
`...` 运算符用于解开参数包，它在参数包中的每个参数上使用 `std::forward`，用逗号把它们隔 开。例如，假设 `args` 是一个参数包，有 3 个参数，分别对应 3 种类型。扩展后的调用如下：
```cpp
processValues(forward<A1>(a1),
 forward<A2>(a2),
 forward<A3>(a3));
```
下述第一个扩展操作扩展模板参数包，为 `print` 生成函数参数列表。编译器将模式 `const Args&` 应用到模板参数包 `Args` 中的每个元素上。因此该模式的扩展结果是一个以逗号分隔的零个或多个类型的列表，每个类型都形如 `const type&`。第二个扩展操作扩展函数参数包，扩展结果是一个由包中元素组成、以逗号分隔的列表。
```c++
// function to end the recursion and print the last element
// this function must be declared before the variadic version of print is defined
template<typename T>
ostream &print(ostream &os, const T &t) {
    return os << t;   // no separator after the last element in the pack
}

// this version of print will be called for all but the last element in the pack
template <typename T, typename... Args>
ostream &print(ostream &os, const T &t, const Args&... rest) // expand Args
{
    os << t << ", ";    
    return print(os, rest...);   // expand Args
}

ostream& print(ostream&, const int&, const string&, const int&);

print(cout, i, s, 42) // t = i rest = s, 42
print(cout, s, 42)    // t = s rest = 42
print(cout, 42)       // t = 42
```
下述调用 `print` 表示对函数参数包 `rest` 中的每个元素调用 `debug_rep`。扩展结果将是一个逗号分隔的 `debug_rep` 调用列表。
```c++
// call debug_rep on each argument in the call to print
template <typename... Args>
ostream &errorMsg(ostream &os, const Args&... rest) {
    // print(os, debug_rep(a1), debug_rep(a2), ..., debug_rep(an))
    return print(os, debug_rep(rest)...);
}

errorMsg(cerr, fcnName, code.num(), otherData, "other", item);
print (cerr, debug_rep(fcnName), debug_rep(code.num()),
				debug_rep(otherData), debug_rep("otherData") , debug_rep(item));

```
与之相对，下面的模式会编译失败：
```c++
// passes the pack to debug_rep; print(os, debug_rep(a1, a2, ..., an))
print(os, debug_rep(rest...));   // error: no matching function to call
```
这段代码的问题是在 `debug_rep` 调用中扩展 `rest`，它等价于：
```c++
print(cerr, debug_rep(fcnName, code.num (), otherData, "otherData", item)); 
```
在这个扩展中，试图用一个五个实参的列表来调用 `debug_rep`，但并不存在与此调用匹配的 `debug_rep` 版本。`debug_rep` 函数不是可变参数的，而且没有接受五个参数的 `debug_rep` 版本。
### Variable Number of Mixin Classes
参数包几乎可用在任何地方。例如，下面的代码使用一个参数包为 `MyClass` 类定义了可变数目的混入类。
```cpp
class Mixin1
{
public:
    Mixin1(int i) : m_value { i } {}
    virtual void mixin1Func() { cout << "Mixin1: " << m_value << endl; }
private:
    int m_value;
};

class Mixin2
{
public:
    Mixin2(int i) : m_value { i } {}
    virtual void mixin2Func() { cout << "Mixin2: " << m_value << endl; }
private:
    int m_value;
};

template <typename... Mixins>
class MyClass : public Mixins...
{
public:
    MyClass(const Mixins&... mixins) : Mixins { mixins }... {}
    virtual ~MyClass() = default;
};
```
上述代码首先定义两个混入类 `Mixin1` 和 `Mixin2` ，构造函数接收一个整数，然后保存这个整数，这两个类有一个函数用于打印特定实例的信息。`MyClass` 可变参数模板使用参数包接收可变数目的混入类。`MyClass` 继承所有的混入类，其构造函数接收同样数目的参数来初始化每一个继承的混入类。`...` 基本上接收运算符左边的内容，为参数包中的每个模板参数重复这些内容，并用逗号隔开。`MyClass` 可以这样使用：
```cpp
MyClass<Mixin1, Mixin2> a { Mixin1 { 11 }, Mixin2 { 22 } };
a.mixin1Func();
a.mixin2Func();

// 试图对 b 调用 Mixin2Func() 会产生编译错误，因为 b 并非继承自 Mixin2 类
MyClass<Mixin1> b { Mixin1 { 33 } };
b.mixin1Func();

//b.mixin2Func(); // Error: does not compile.
MyClass<> c;
//c.mixin1Func(); // Error: does not compile.
//c.mixin2Func(); // Error: does not compile.


// 这个程序的输出如下:
Mixin1: 11
Mixin2: 22
Mixin1: 33
```
### Forwarding Parameter Packet
在 `C++11` 中，可以组合使用可变参数模板和 `forward` 机制来编写函数，实现将其实参不变地传递给其他函数。
```c++
// fun has zero or more parameters each of which is
// an rvalue reference to a template parameter type
template<typename... Args>
void fun(Args&&... args)    // expands Args as a list of rvalue references
{
    // the argument to work expands both Args and args
    work(std::forward<Args>(args)...);
}
```
这里希望将 `fun` 的所有实参转发给另一个名为 `work` 的函数，假定由它完成函数的实际工作。类似 `emplace_back` 中对 `construct` 的调用，`work` 调用中的扩展既扩展模板参数包也扩展函数参数包。 
由于 `fun` 的参数是右值引用，因此可以传递给它任意类型的实参，由于使用 `std::forward` 传递这些实参，因此它们的所有类型信息在调用 `work` 时都会得到保持。
### Fold Expressions
`Ѳ` 可以是以下任意运算符：
```
+ - * / % ^ & | << >> += -= *= /= %= ^= &= |= <<= >>= = == != 
+ < > <= >= && || , .* ->*.
```
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240130155231.png)
以递归方式定义前面的 `processValnes` 函数模板，如下所示:
```cpp
void processValues() { /* Nothing to do in this base case.*/ }

template <typename T1, typename... Tn>
void processValues(T1 arg1, Tn... args)
{
    handleValue(arg1);
    processValues(args...);
}
```
由于以递归方式定义，因此需要 `base case` 来停止递归。使用折叠表达式，利用一元右折叠，通过单个函数模板来实现时不需要 `base case`：
```cpp
template <typename... Tn>
void processValues(const Tn&... args)
{
    (handleValue(args), ...);
}
```
`...` 触发折叠，扩展这一行，针对参数包中的每个参数调用 `handleValue`，对 `handleValue` 的每个调用用逗号分隔。例如，假设 `args` 是包含3 个参数的参数包。一 元右折叠扩展后的形式如下：
```cpp
(handleValue(a1), (handleValue(a2), handleValue(a3))); 
```
下面是另一个示例。`printValues` 函数模板将所有实参写入控制台，实参之间用换行符分开：
```cpp
template <typename... Values>
void printValues(const Values&... values)
{
    ((cout << values << endl), ...);
}
```
假设 `values` 是包含 3 个参数的参数包。一元右折叠扩展后的形式如下：
```cpp
((cout << v1 << endl), ((cout << v2 << endl), (cout << v3 << endl)));
```
在这些示例中，将折叠与逗号运算符结合使用，但实际上，折叠可与任何类型的运算符结合使用。例如，以下代码定义可变参数函数模板，使用二元左折叠计算传给它的所有值之和。二元左折叠始终需要一个 `Init` 值。因此，`sumValues` 有两个模板类型参数：一个是普通参数，用于指定 `Init` 的类型，另一个是参数包，可接收 0 个或多个实参。
```cpp
template <typename T, typename... Values>
double sumValues(const T& init, const Values&... values)
{
    return (init + ... + values);
}
```
假设 `values` 是包含3 个参数的参数包。二元左折叠扩展后的形式如下:
```cpp
return (((init + v1) + v2) + v3);

// 使用方式如下:
cout << sumValues(1, 2, 3.3) << endl;
cout << sumValues(1) << endl;
// 该函数模板至少需要一个参数，因此以下代码无法编译:
cout << sumValues() << endl;
```
`sumValues` 函数模板也可以按照一元左折叠定义，如下所示，这仍然需要在调用 `sumValues` 时提供至少一个参数。
```cpp
template <typename... Values>
double sumValues(const Values&... values) { return (... + values); }
```
长度为零的参数包允许一元折叠，但只能和逻辑与、逻辑或和逗号运算符结合使用。例如:
```cpp
template <typename... Values>
double allTrue(const Values&... values) { return (... && values); }

template <typename... Values>
double anyTrue(const Values&... values) { return (... || values); }


cout << allTrue(1, 1, 0) << allTrue(1, 1) << allTrue() << endl; // 011
cout << anyTrue(1, 1, 0) << anyTrue(0, 0) << anyTrue() << endl; // 100
```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```

```cpp

```





























































































































