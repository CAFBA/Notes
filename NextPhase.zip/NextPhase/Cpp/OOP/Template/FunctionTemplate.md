# FunctionTemplate
可以为独立函数编写模板。例如，可以编写一个通用函数，该函数在数组中查找一个值并返回这个值的索引：
```cpp
static const size_t NOT_FOUND { static_cast<size_t>(-1) };

template <typename T>
size_t Find(const T& value, const T* arr, size_t size)
{
    for (size_t i { 0 }; i < size; i++) 
        if (arr[i] == value) 
            return i; // Found it; return the index.
    return NOT_FOUND; // Failed to find it; return NOT_FOUND.
}

int myInt { 3 }, intArray[] {1, 2, 3, 4};
const size_t sizeIntArray { size(intArray) };
size_t res;
res = Find(myInt, intArray, sizeIntArray); // calls Find<int> by deduction.
res = Find<int>(myInt, intArray, sizeIntArray); // calls Find<int> explicitly.

// 函数模板也可以声明为 inline 或 constexpr，说明符放在模板参数列表之后，返回类型之前

// ok: inline specifier follows the template parameter list
template <typename T> 
inline T min(const T&, const T&);

// error: incorrect placement of the inline specifier
inline template <typename T> 
T min(const T&, const T&);
```
有时编译器知道数组的确切大小，例如, 基于栈的数组。用这种数组调用 `Find` 函数，就不需要传递数组的大小。为此，可添加如下函数模板。该实现仅把调用传递给前面的 `Find` 函数模板。这也说明函数模板可接收非类型的参数，与类模板一样。
```cpp
template <typename T, size_t N>
size_t Find(const T& value, const T (&arr)[N])
{
    return Find(value, arr, N);
}

int myInt { 3 }, intArray[] {1, 2, 3, 4};
size_t res { Find(myInt, intArray) };
```
## Template Type Parameter Conversion
与非模板函数一样，调用函数模板时传递的实参被用来初始化函数的形参。如果一个函数形参的类型使用模板类型参数，则编译器通常会生成新的模板实例而不是对实参进行类型转换，只有有限的几种类型转换会自动地应用于这些实参，从而直接调用，不生成新的实例：
- 顶层 `const` 会被忽略。
- 可以将一个非 `const` 对象的引用或指针传递给一个 `const` 引用或指针形参。
- 如果函数形参不是引用类型，则可以对数组或函数类型的实参应用正常的指针转换。数组实参可以转换为指向其首元素的指针，函数实参可以转换为该函数类型的指针。
```c++
template<typename T> 
T fobj(T, T);
template<typename T> 
T fref(const T&, const T&);

string s1("a value");
const string s2("another value"); 
// 下述调用不会生成新的实例
fobj(s1, s2);  // 调用 fobj(string, string) const 被忽略 
fref(s1, s2);  // 调用 fref(const string&, const string&) 将 s1 转换为 const 是允许的

int a[10], b[42]; 
fobj(a, b); // 调用 f(int*, int*)
fref(a, b); // 错误：如果形参是一个引用，则数组不会转换为指针
```
其他的类型转换，如算术转换、派生类向基类的转换以及用户定义的转换，都不能应用于模板类型参数。但函数模板中使用非模板类型定义的参数可以进行正常的类型转换：
```c++
template <typename T>
ostream &print(ostream &os, const T &obj) {
    return os << obj;
}

print(cout, 42);   // instantiates print(ostream&, int)
ofstream f("output");
print(f, 10);      // uses print(ostream&, int); converts f to ostream&
```
一个模板类型参数可以作为多个函数形参的类型，传递给这些形参的实参必须具有相同的类型，否则无法生成对应的实例：
```c++
template <typename T>
int compare(const T &v1, const T &v2)
{
    if (v1 < v2) return -1;
    if (v2 < v1) return 1;
    return 0;
}

long lng;
compare(lng, 1024);   // error: cannot instantiate compare(long, int)

// 这种情况下可以使用两个模板类型参数定义函数模板
template <typename A, typename B>
int flexibleCompare(const A& v1, const B& v2) {
    if (v1 < v2) return -1;
    if (v2 < v1) return 1;
    return 0;
}
```
但是对于显式指定模板类型参数的情况，可以生成对应实例：
```c++
// 下述调用会生成新的实例
long lng;
compare(lng, 1024);         // error: template parameters don't match
compare<long>(lng, 1024);   // ok: instantiates compare(long, long)
compare<int>(lng, 1024);    // ok: instantiates compare(int, int)
```
## Template Parameter Deduction
编译器根据传递给函数模板的实参来推导模板参数的类型，例如，如下 `add` 函数模板需要 3 个模板参数：返回值的类型以及两个操作数的类型，但由于模板参数 `T1` 和 `T2` 是函数的参数，编译器可以推导这两个参数，因此调用 `add` 时可仅显示指定返回值的类型。
```cpp
template <typename RetType, typename T1, typename T2>
RetType add(const T1& t1, const T2& t2) { return t1 + t2; }

auto result { add<long long, int, int>(1, 2) };
auto result { add<long long>(1, 2) };
```
由于调用时将按照从左到右的顺序与模板参数列表中的模板参数匹配，因此只有可以推导出来的尾部参数才可以不需要显示指定，而对于无法推导的模板参数，则必须在调用时显式指定。
假设以如下方式定义函数模板，则必须指定 `RetType`，因为编译器无法推导该类型，而且由于 `RetType` 是第 2 个参数，还需要显式指定 `T1`。
```cpp
template <typename T1, typename RetType, typename T2>
RetType add(const T1& t1, const T2& t2) { return t1 + t2; }

auto result { add<int, long long>(1, 2) };

// 也可提供返回类型模板参数的默认值，这样调用 add 时可不指定任何类型
template <typename RetType = long long, typename T1, typename T2>
RetType add(const T1& t1, const T2& t2) { return t1 + t2; }

auto result { add(1, 2) };
```
## Return Type of Function Templates
从 `Cpp14` 开始，可要求编译器自动推导函数的返回类型。因此，只需要编写如下 `add` 函数模板：
```cpp
template <typename T1, typename T2>
auto add(const T1& t1, const T2& t2) { return t1 + t2; }
```
但是，使用 `auto` 推导表达式类型时会去掉引用和 `const` 限定符，而 `decltype` 没有去除这些限定符。可使用 `dedtype(auto)` 编写 `add`，以避免去掉任何 `const` 和引用限定符。
```cpp
// decltype(getString()) s3 { getString() };
decltype(auto) s4 { getString() };

template <typename T1, typename T2>
decltype(auto) add(const T1& t1, const T2& t2) { return t1 + t2; }

template <typename T1, typename T2>
decltype(t1+t2) add(const T1& t1, const T2& t2) { return t1 + t2; }
```
在 `C++14` 之前，不支持推导函数的返回类型和 `decltype(auto)`，需要使用后置返回类型：
```cpp
template<typename T1, typename T2>
auto add(const T1& t1, const T2& t2) -> decltype(t1 + t2) { return t1 + t2; }

// a trailing return lets us declare the return type after the parameter list is seen
template <typename It>
auto fcn(It beg, It end) -> decltype(*beg)
{
    // process the range
    return *beg;   // return a reference to an element from the range
}
```
此例中通知编译器 `fcn` 的返回类型与解引用 `beg` 参数的结果类型相同。解引用运算符返回一个左值，因此通过 `decltype` 推断的类型为 `beg` 表示的元素的类型的引用。
## Function Template Specialization
在某些情况下，通用模板的定义对特定类型是不合适的，可能编译失败或者操作不正确。如果不希望或不能使用模板版本时，可以定义类或函数模板的特例化版本。
下述通过调用 `strcmp` 比较两个字符指针而非比较指针值，并用另一个版本重载 `compare` 函数来处理字符串字面常量：
```c++
// first version; can compare any two types
template <typename T>
int compare(const T&, const T&);

// second version to handle string literals
template<size_t N, size_t M>
int compare(const char (&)[N], const char (&)[M]);
```
但是，只有当传递给 `compare` 一个字符串字面常量或者一个数组时，编译器才会调用接受两个非类型模板参数的版本。如果传递给它字符指针，就会调用第一个版本：
```c++
const char *p1 = "hi", *p2 = "mom";
compare(p1, p2);        // calls the first template
compare("hi", "mom");   // calls the template with two nontype parameters
```
因为无法将一个指针转换为一个数组的引用，因此当参数是 `p1` 和 `p2` 时，第二个版本的 `compare` 是不可行的。为处理字符指针，可以为第一个版本的 `compare` 定义一个模板特例化版本。当定义一个特例化版本时，函数参数类型必须与一个先前声明的模板中对应的类型匹配。函数参数要求一个指向此类型的 `const&`，则 `const char*` 的 `const&` 是一个常量指针：
```c++
template <typename T>
bool compare(const T& p1, const T& p2) {
    cout << "Template" << endl;
}

// const char* 全特化版本
template <>
bool compare(const char* const &p1, const char* const &p2) {
    cout << "Template specialization" << endl;
}
```
### Partial Specialization
实现 `operator()` 用 `Functor` 代替：
```c++
// 借助类模板偏特化demo
template <typename A, typename B>
class F {
public:
    F(A a, B b): a_(a), b_(b) {}
    // 使用a_, b_作为函数的参数
    void operator() () { std::cout << "Normal version." << std::endl; }
private:
    A a_;
    B b_;
};

template <typename A>
class F<A, int> {
public:
    F(A a, int b): a_(a), b_(b) {}
    void operator() () { std::cout << "Partial version." << std::endl; }
private:
    A a_;
    int b_;
};

// 测试代码
int a = 10;
double b = 12;

F<int, double>(a, b)();   // 输出 Normal version.
F<int, int>(a, a)();      // 输出 Partial version.
```
另一种方法是使用 `Concepts`，对于偏特化的版本其 `requires B` 类型为 `int` 类型，所以在 `f(a, a)` 的调用中，编译器生成且直接匹配到这一个偏特化的版本：
```c++
template <typename A, typename B>
void f(A a, B b) {
    std::cout << "Normal version." << std::endl;
}

template <typename A, typename B>
requires std::integral<B>
void f(A a, B b) {
    std::cout << "Partial version." << std::endl;
}
// 测试代码
int a = 10;
double b = 12;
f(a, b); // Normal version.
f(a, a); // Partial version.
```
以下行为不是模板偏特化（函数模板偏特化是不允许的），而是函数重载:
```c++
template<typename T, class N> 
void compare(T num1, N num2) { ... }

// 这不是偏特化，这是函数重载
template<class N> 
void compare(int num1, N num2) { ... }

// 这也不是特化，而是重载
template<typename T, class N> 
void compare(T* num1, N* num2) { ... }

template<typename T, class N> 
void compare(std::vector<T>& vecLeft, std::vector<T>& vecRight) { ... }

int main()
{
    compare<int, int>(30,31);// compare<int,int>(int num1, int num2)
    compare(30,'1');        // compare<char>(int num1, char num2)

    int a = 30;
    char c = '1';
    compare(&a, &c);     // compare<int,char>(int* num1, char* num2)

    vector<int> vecLeft{0};
    vector<int> vecRight{1, 2, 3};
    compare<int,int>(vecLeft, vecRight); // compare<int,char>(int* num1, char* num2)
}
```
## Function Template Overloading
`Cpp` 允许编写函数模板特化，但禁止函数模板的偏特化，原因在于函数模板偏特化和函数重载决策的矛盾。定义特例化函数版本本质上是接管编译器的工作，为模板的一个特殊实例提供了定义，特例化并非重载，因此不影响函数匹配。
由于函数模板特化版本不参与重载解析，在和函数重载一起使用的时候，可能出现不符合预期的结果。因此一般使用可以使用非模板函数来重载函数模板。例如，假如想为 `const char*` 类型编写一个 `Find` 重载，以便与 `stcmp` 进行比较，而不是使用 `operators=`，因为 `=` 只会比较指针(地址)，而不是实际的字符串。下面是一个这样的重载：
```cpp
size_t Find(const char* value, const char** arr, size_t size) {
    for (size_t i { 0 }; i < size; i++)
        if (strcmp(arr[i], value) == 0)
            return i; // Found it; return the index.
    return NOT_FOUND; // Failed to find it; return NOT_FOUND.
}

const char* word { "two" };
const char* words[] { "one", "two", "three", "four" };
const size_t sizeWords { size(words) };
size_t res { Find(word, words, sizeWords) }; // Calls non-template function.

// 如果确实像下面这样显式地指定模板类型参数
// 那么函数模板将被 T=const char* 调用，而不是 const char* 的重载
res = Find<const char*>(word, words, sizeWords);
```
此外也可以用另一个模板重载函数，假设要编写一个特例化的 `Find` 函数模板，这个特例化对指针解除引用，对指向的对象直接调用 `operator==`，实现此行为的正确方法是为 `Find` 方法编写第二个函数模板：
```cpp
template <typename T>
size_t Find(T* value, T* const* arr, size_t size)
{
    for (size_t i { 0 }; i < size; i++) 
        if (*arr[i] == *value) 
            return i; // Found it; return the index
    return NOT_FOUND; // failed to find it; return NOT_FOUND
}
```
可在一个程序中定义原始的 `Find` 模板、针对指针类型的重载 `Find` 、针对 `const char*` 的重载 `Find`，在所有重载的版本之间，编译器总是选择最具体的函数版本。如果非模板化的版本与函数模 板实例化等价，编译器更偏向非模板化的版本。
```cpp
size_t res { NOT_FOUND };

int myInt { 3 }, intArray[] { 1, 2, 3, 4 };
size_t sizeArray { size(intArray) };
res = Find(myInt, intArray, sizeArray); // calls Find<int> by deduction
res = Find<int>(myInt, intArray, sizeArray); // calls Find<int> explicitly

double myDouble { 5.6 }, doubleArray[] { 1.2, 3.4, 5.7, 7.5 };
sizeArray = size(doubleArray);
res = Find(myDouble, doubleArray, sizeArray); // calls Find<double> by deduction
res = Find<double>(myDouble, doubleArray, sizeArray); // calls Find<double> explicitly

const char* word { "two" };
const char* words[] { "one", "two", "three", "four" };
sizeArray = size(words);
res = Find<const char*>(word, words, sizeArray);// calls Find<const char*> explicitly
res = Find(word, words, sizeArray);// calls overloaded Find for const char*s

int *intPointer { &myInt }, *pointerArray[] { &myInt, &myInt };
sizeArray = size(pointerArray);
res = Find(intPointer, pointerArray, sizeArray);// calls the overloaded Find for pointers

SpreadsheetCell cell1 { 10 };
SpreadsheetCell cellArray[] { SpreadsheetCell { 4 }, SpreadsheetCell { 10 } };
sizeArray = size(cellArray);
res = Find(cell1, cellArray, sizeArray);// calls Find<SpreadsheetCell> by deduction
res = Find<SpreadsheetCell>(cell1, cellArray, sizeArray);// calls Find<SpreadsheetCell> explicitly

SpreadsheetCell *cellPointer { &cell1 };
SpreadsheetCell *cellPointerArray[] { &cell1, &cell1 };
sizeArray = size(cellPointerArray);
res = Find(cellPointer, cellPointerArray, sizeArray);// Calls the overloaded Find for pointers
```
如果重载涉及函数模板，则函数匹配规则会受到一些影响：
对于一个调用，其候选函数包括所有模板实参推断成功的函数模板实例，候选的函数模板都是可行的，因为模板实参推断会排除任何不可行的模板。涉及类型转换时，模板与非模板函数按照类型转换来排序，但是可以用于函数模板调用的类型转换非常有限。
如果恰有一个函数提供比其他任何函数都更好的匹配，则选择此函数。但是如果多个函数都提供相同级别的匹配，则：
- 如果同级别的函数中只有一个是非模板函数，则选择此函数。
- 如果同级别的函数中没有非模板函数，而有多个函数模板，且其中一个模板比其他模板更特例化，则选择此模板，否则该调用有歧义。
在定义任何函数之前，应该声明所有重载的函数版本。这样编译器就不会因为未遇到你希望调用的函数而实例化一个并非你所需要的版本。
```c++
template <typename T> 
string debug_rep(const T &t);

// the following declaration must be in scope
// for the definition of debug_rep(char*) to do the right thing
string debug_rep(const string &);
string debug_rep(char *p)
{
    // if the declaration for the version that takes a const string& is not in scope
    // the return will call debug_rep(const T&) with T instantiated to string
    return debug_rep(string(p));
}
```
## Friend Function Templates of Class Templates
如果需要在类模板中重载运算符，函数模板会非常有用。例如，可以通过重载 `Grid` 类模板的加法运算符把两个网格加在一起。这样得到的网格大小与两个操作数中较小的网格相同。只有在两个网格都包含实际值时，才会将相应的网格相加。假设希望将 `operators+` 设置为独立的函数模板：
```cpp
template <typename T>
Grid<T> operator+(const Grid<T>& lhs, const Grid<T>& rhs)
{
    size_t minWidth { std::min(lhs.getWidth(), rhs.getWidth()) };
    size_t minHeight { std::min(lhs.getHeight(), rhs.getHeight()) };
    Grid<T> result { minWidth, minHeight };
    for (size_t y { 0 }; y < minHeight; ++y) {
        for (size_t x { 0 }; x < minWidth; ++x) {
            const auto& leftElement { lhs.m_cells[x][y] };
            const auto& rightElement { rhs.m_cells[x][y] };
            if (leftElement.has_value() && rightElement.has_value()) 
                result.at(x, y) = leftElement.value() + rightElement.value();
        }
    }
    return result;
}
```
这个实现的唯一问题是 `operator+` 访问 `Grid` 类的私有成员 `m_cells`，可将该运算符作为 Grid 类的友元。然而，`Grid` 类和 `operator+` 都是模板，因此需要 `operator+` 对每一种特定类型 `T` 的实例化都是 `Grid` 模板对这种类型实例化的友元：
```cpp
// Forward declare~ Grid template.
template <typename T> class Grid;

// Prototype for templatized operator+.
template <typename T>
Grid<T> operator+(const Grid<T>& lhs, const Grid<T>& rhs);

template <typename T>
class Grid
{
public:
    friend Grid operator+<T>(const Grid& lhs, const Grid& rhs);
};
```
上述语法表明，`operator+` 对类型 `T` 的实例是这个模板实例的友元。换句话说，类实例和函数实例之间存在一对一的友元映射关系。要注意 `operator+` 中显式的模板规范，这一语法告诉编译器， `operator+` 本身也是模板。
## Function Pointer
使用函数模板初始化函数指针或为函数指针赋值时，编译器用指针的类型来推断模板实参：
```c++
template <typename T> 
int compare(const T&, const T&);
// pf1 points to the instantiation int compare(const int&, const int&)
int (*pf1)(const int&, const int&) = compare;
```
如果编译器不能从函数指针类型确定模板实参，则会产生错误，使用显式模板实参可以消除调用歧义：
```c++
// overloaded versions of func; each takes a different function pointer type
void func(int(*)(const string&, const string&));
void func(int(*)(const int&, const int&));

func(compare);     // error: which instantiation of compare?

// ok: explicitly specify which version of compare to instantiate
func(compare<int>);    // passing compare(const int&, const int&)
```