# Inheritance && Polymorphism
## Access Specifier
继承方式**控制派生类用户对于基类成员的访问权限**：
- 如果使用公有继承，则基类的公有成员和受保护成员在派生类中属性不发生改变；
- 如果使用受保护继承，则基类的公有成员和受保护成员在派生类中变为受保护成员；
- 如果使用私有继承，则基类的公有成员和受保护成员在派生类中变为私有成员；
- 无论使用何种基础，只会继承基类的私有成员，并不能访问基类的私有成员；
假定 `D` 继承自 `B`：
- 只有当 `D`公有地继承 `B` 时，用户代码才能使用派生类到基类的转换。
- 不论 `D` 以什么方式继承 `B` ，`D` 的成员函数和友元都能使用派生类到基类的转换。
- 如果 `D` 继承 `B` 的方式是公有的或者受保护的，则 `D` 的派生类的成员函数和友元可以使用 `D` 到 `B` 的类型转换；反之，如果 `D` 继承 `B` 的方式是私有的，则不能使用。

| AccessSpecifier | Base Members | DerivedMembers | Derived Access | OutsideAcess |
| ---- | ---- | ---- | ---- | ---- |
| *public* | *public members* | *public members* | *yes* | *yes* |
|  | *protected members* | *protected members* | *yes* | *no* |
|  | *private members* |  | *no* | *no* |
| *protected* | *public members* | *protected members* | *yes* | *no* |
|  | *protected members* | *protected members* | *yes* | *no* |
|  | *private members* |  | *no* | *no* |
| *private* | *public members* | *private members* | *no* | *no* |
|  | *protected members* | *private members* | *no* | *no* |
|  | *private members* |  | *no* | *no* |
1. 基类成员的访问限定，派生类中不能超过继承方式。
2. 派生类的访问权限只取决于直接基类。
3. 外部只能访问 `public` 成员，`protected` 和 `private` 成员无法直接访问，派生类可以继承基类的 `private` 成员，但是派生类却无法直接访问。
5. 在基类中定义的成员，想被派生类访问，但是不想被外部访问，那么在基类中，则把相关成员定义成 `protected`；如果派生类和外部都不想被访问，那么在基类中，就把相关成员定义成 `private`。
6. 友元关系不能继承，每个类负责控制各自成员的访问权限。
7. 类的默认访问说明符是 `private`，在第一个访问说明符之前声明的所有成员的访问都是 `private` 的。
8. 默认情况下， `struct` 的访问说明符是 `public`，而 `class` 是 `private`，`class` 定义的派生类是私有继承的，而 `struct` 定义的派生类是公有继承的。
使用 `using` 声明可以改变派生类继承的某个名字的访问级别，如果一条 `using` 声明语句出现在：
- 类的 `private` 部分，则该名字只能被类的成员和友元访问。
- 类的 `public` 部分，则类的所有用户都能访问该名字。
- 类的 `protected` 部分，则该名字对于成员、友元和派生类是可访问的。
派生类只能为那些它可以访问的名字提供 `using` 声明。
```c++
class Base {
public:
    std::size_t size() const { return n; }
protected:
    std::size_t n;
};

class Derived : private Base { 
public:
    // maintain access levels for members related to the size of the object
    using Base::size;
protected:
    using Base::n;
};
```
因为 `Derived` 私有继承，所以默认情况下继承而来的成员 `size` 和 `n` 是 `Derived` 的私有成员。然而，使用 `using` 声明语句改变了这些成员的可访问性。改变之后，`Derived` 的用户将可以使用 `size` 成员，而 `Derived` 的派生类将能使用 `n`。
`C++11` 中，在类名后面添加 `final` 关键字可以禁止其他类继承它，成员函数后面添加 `final` 关键字则表明这是一个虚函数且该虚函数不可在派生类中被覆盖，如果有一点没有得到满足的话，编译器就会报错。`final` 和 `override` 关键字出现在形参列表（包括任何`const`或引用修饰符）以及尾置返回类型之后。
## Overriding Methods
派生类可以定义一个与基类中的虚函数名字相同但形参列表不同的函数，但编译器会认为该函数与基类中原有的函数是相互独立的，此时派生类的函数并没有覆盖掉基类中的版本。
只有基类中声明为 `virtual` 的方法才能被派生类正确地重写，为重写这个方法，需要在派生类的定义中重新声明这个方法，但是需要添加关键字 `oveiride`，并从派生类中删除关键字 `virtual`。一旦将方法或析构函数标记为 `virtual`，它们在所有派生类中就一直是 `virtual`，即使在派生类中删除 `virtual` 关键字。
派生类经常（但不总是）重写它继承的虚函数。如果派生类没有重写其基类中的某个虚函数，则该虚函数的行为类似于其他的普通成员，派生类会直接继承其在基类中的版本。C++标准并没有明确规定派生类的对象在内存中如何分布，一个对象中继承自基类的部分和派生类自定义的部分不一定是连续存储的。
> 在方法定义中，不需要在方法名前重复使用关键字 `virtual`。可以在重写方法的前面添加关键字 `virtual`，但这样做是多余的。
```cpp
class Base
{
public:
    virtual void someMethod() {}
};

class Derived : public Base
{
public: 
    void someMethod() override;
};
```
指针或引用可指向某个类或其派生类的对象，当使用指针或引用调用虚函数时，该调用将被动态绑定。根据引用或指针所绑定的对象类型不同，该调用可能执行基类的版本，也可能执行某个派生类的版本。
但即使基类的引用或指针指向的是派生类，也无法访问没有在基类中定义的，定义在派生类中的方法或成员。
```c++
class Base {
    public:
    virtual int fcn(); 
};

class D1 : public Base { 
    public:
    // D1 的 fcn 函数并没有覆盖 Base 的虚函数 fcn，原因是它们的形参列表不同
    // 实际上，D1 的 fcn 将隐藏 Base 的 fcn
    // 此时 D1 拥有两个 fcn 函数：一个是 D1 从 Base 继承而来的虚函数 fcn
    // 另一个是 D1 自己定义的接受一个 int 参数的非虚函数 fcn
    int fcn(int); 
    virtual void f2();
};

class D2 : public D1 { 
    public:
    int fcn(int); // 非虚函数，隐藏 D1::fcn(int)
    int fcn();    // 覆盖 Base 的虚函数 fcn
    void f2();    // 覆盖 D1 的虚函数 f2
};

Base bobj; D1 d1obj; D2 d2obj; 
Base *bp1 = &bobj, *bp2 = &d1obj, *bp3 = &d2obj; 

// 通过基类的指针调用，bp2 实际绑定的对象是 D1 类型
// 而 D1 并没有覆盖那个不接受实参的 fcn
// 所以通过 bp2 进行的调用将在运行时解析为 Base 定义的 fcn
bp1->fcn(); // 虚调用，将在运行时调用Base::fcn 
bp2->fcn(); // 虚调用，将在运行时调用Base::fcn 

// 因为 Base 类中没有f2，所以即使当前的指针指向一个派生类对象也无法调用
bp2->f2();  // 错误：Base 没有名为 f2 的成员
bp3->fcn(); // 虚调用，将在运行时调用D2::fcn

D1 *d1p = &d1obj; D2 *d2p = &d2obj; 
d1p->f2(); // 虚调用，将在运行时调用D1::f2
d2p->f2(); // 虚调用，将在运行时调用D2::f2
```
当基类的指针或引用指向派生类对象时，派生类保留其数据成员和重写的方法。但是通过类型转换将派生类对基类对象时，就会丢失其独有特征，重写方法和派生类数据的丢失称为截断 `slicing`。
```cpp
Derived myDerived;
Base assignedObject { myDerived }; // Assigns a Derived to a Base.
assignedObject.someMethod(); // Calls Base's version of someMethod()
```
在派生类中重写方法时，可能会调用基类的版本，此时需要使用作用域解析运算符防止无限递归调用：
```cpp
class WeatherPrediction {
public:
    virtual std::string getTemperature() const;
};

class MyWeatherPrediction : public WeatherPrediction {
public:
    std::string getTemperature() const override;
};

string MyWeatherPrediction::getTemperature() const {
    return getTemperature() + "\u00B0F"; // BUG
}

string MyWeatherPrediction::getTemperature() const {
    return WeatherPrediction::getTemperature() + "\u00B0F";
}
```
### Override
`C++11` 引入两个上下文关键字 `override` 和 `final`。这两个关键字的特点是它们是保留的，它们只是位于特定上下文才被视为关键字。对于 `override`，它只在成员函数声明结尾处才被视为关键字。这意味着如果以前写的代码里面已经用过 `override` 这个名字，那么换到 `C++11` 标准也无需修改代码。
派生类可以使用 `override` 显式注明成员函数是一个虚函数且重写基类中的该函数，如果 `override` 标记了某个函数，但该函数并没有重写已存在的虚函数，或基类中不存在这个虚函数，或该函数不是虚函数，编译器将报告错误。
基类可以向虚函数添加 `final` 可以防止派生类重写，`final` 也能用于类，这时这个类不能用作基类。
要想重写一个函数，必须满足下列要求：
- 基类函数必须是 `virtual`
- 基类和派生类函数名、必须完全一样（除非是析构函数)，函数形参类型必须完全一样，函数常量性 `constness` 必须完全一样，函数的引用限定符必须完全一样。
- 基类和派生类函数的返回值和异常说明必须兼容
如果没有 `oveitide` 关键字，可能会偶然创建一个新的虚方法，而不是重写基类的方法。
只修改 `Derive` 类但忘记更新 `Base`：
```cpp
class Base
{
public:
    virtual void someMethod(double d);
};
class Derived : public Base
{
public:
    virtual void someMethod(double d); 
    // virtual void someMethod(int i); 创建新的虚方法
};

Derived myDerived;
Base& ref { myDerived };
ref.someMethod(1.1); // Calls Base's version of someMethod()
```
注释的代码没有重写 `Base` 类的 `someMethod`, 而是创建了一个新的虚方法。
只修改 `Base` 类但忘记更新所有 `Derive`：
```cpp
class Base
{
public:
    virtual void someMethod(int i);
    // virtual void someMethod(double i);
};
class Derived : public Base
{
public:
    virtual void someMethod(int i); // 创建新的虚方法
};
```
### Special Cases in Overriding Methods
#### The Base Class Method Is static
在 C++中，不能重写静态方法。首先，方法不可能既是静态的又是虚的。出于这个原因，试图重写一个静态方法并不能得到预期的结果。如果派生类中存在的静态方法与基类中的静态方法同名，实际上这是两个独立的方法。
```cpp
class BaseStatic
{
public:
    static void beStatic() {
    cout << "BaseStatic being static." << endl; }
};
class DerivedStatic : public BaseStatic
{
public:
    static void beStatic() {
    cout << "DerivedStatic keepin' it static." << endl; }
};

// 由于静态方法属于类，因此调用两个类的同名方法时，将调用各自的方法
BaseStatic::beStatic();
DerivedStatic::beStatic();
```
用类名访问这些方法时一切都很正常。当涉及对象时，这一行为就不是那么明显。在 `C++` 中，可以使用对象调用静态方法，但由于方法是静态的，没有 `this` 指针，也无法访问对象本身，因此使用对象调用静态方法，等价于使用作用域解析符调用静态方法：
```cpp
DerivedStatic myDerivedStatic;
BaseStatic& ref { myDerivedStatic };
myDerivedStatic.beStatic();
ref.beStatic();

DerivedStatic keepin' it static.
BaseStatic being static.
```
对 `beStatic` 的第一次调用调用 `DerivedStatic` 版本，因为调用它的对象被显式地声明为 `DerivedStatic` 对象。但第二次调用中，`ref` 是一个指向 `DerivedStatic` 的 `BaseStatic` 引用。在此情况下，会调用 `BaseStatic` 版本的 `beStatic`。原因是当调用 静态方法时，`Cpp` 不关心对象实际上是什么，只关心编译期的类型。
综上，静态方法属于定义它的类，而不属于特定的对象。当类中的方法调用静态方法时，所调用的版本是通过正常的名称解析来决定的。当使用对象调用时，对象实际上并不涉及调用，只是用来判断编译期的类型。
#### The Base Class Method Is Overloaded
当指定名称和一组参数以重写某个方法时，编译器隐式地隐藏基类中同名方法的所有其他实例。 考虑下面的 `Derived` 类，它重写了一个方法，而没有重写相关的同级重载方法。
```cpp
class Base
{
public:
    virtual ~Base() = default;
    virtual void overload() { cout << "Base's overload()" << endl; }
    virtual void overload(int i) { 
        cout << "Base's overload(int i)" << endl; 
    }
};
class Derived : public Base
{
public:
    void overload() override {
        cout << "Derived's overload()" << endl; }
    };
Derived myDerived;
myDerived.overload(2); // Error! No matching method for overload(int).
```
如果试图用 `Derived` 对象调用以 `int` 值作为参数的 `overload` 版本，代码将无法编译，因为没有显式地重写这个方法。然而，使用 `Derived` 对象访问该版本的方法是可行的，只需要使用指向 `Base` 对象的指针或引用:
```cpp
Derived myDerived;
Base& ref { myDerived };
ref.overload(7);
```
在 `Cpp` 中，隐藏未实现的重载方法只是表象，显式声明为子类型实例的对象无法使用这些方法, 但可将其转换为基类类型，以使用这些方法。
如果只想改变一个方法，可以使用 `using` 关键字避免重载该方法的所有版本。在下面的代码中, `Derived` 类定义中使用了从 `Base` 类继承的一个 `overload` 版本，并显式地重写了另一个版本。
```cpp
class Derived : public Base
{
public:
    using Base::overload;
    void overload() override {
        cout << "Derived's overload()" << endl; 
    }
};
```
`using` 子句存在一定风险。假定在 `Base` 类中添加了第三个 `overload` 方法，本来应该在 `Derived` 类中重写这个方法。但由于使用了 `using` 子句，在派生类中没有重写这个方法不会被当作错误，`Derived` 类显式地说明接收父类其他所有的重载方法。因此为了避免歧义，应该重写所有版本的重载方法。
#### The Base Class Method Is private
重写 private 方法当然没有问题。记住方法的访问说明符会判断谁可以调用这些方法。
派生类无 法调用父类的 `private` 方法，并不意味着无法重写这个方法。实际上，在 `Cpp` 中，重写 `private` 方法允许派生类定义自身的独特性，在基类中会引用这种独特性，而 `Java` 和 `C#` 允许重写 `public` 和 `protected` 方法，但不能重写 `private` 方法。 例如，下面的类是汽车模拟程序的一部分，根据汽油消耗量和剩余的燃料计算汽车可以行驶的里程。
`getMilesLeft` 根据两个方法的返回结果执行计算，它是所谓的模板方法。通常，模板方法都不是虚方法。模板方法通过在基类中定义一些算法的骨架，并调用虚方法来完成相关信息的查询。在子类中，可以重写这些虚方法，并修改相关算法而不会真正修改基类中已定义的算法。
```cpp
class MilesEstimator
{
public:
    virtual ~MilesEstimator() = default;
    int getMilesLeft() const { return getMilesPerGallon() * getGallonsLeft(); }
    virtual void setGallonsLeft(int gallons) { m_gallonsLeft = gallons; }
    virtual int getGallonsLeft() const { return m_gallonsLeft; }
private:
    int m_gallonsLeft { 0 };
    virtual int getMilesPerGallon() const { return 20; }
};

MilesEstimator myMilesEstimator;
myMilesEstimator.setGallonsLeft(2);
cout << format("Normal estimator can go {} more miles.",
myMilesEstimator.getMilesLeft()) << endl;
Normal estimator can go 40 more miles.
```
为让这个模拟程序更有趣，可引入不同类型的车辆，或许是效率更高的汽车。现有的 `MilesEstimator` 假定所有的汽车燃烧一加仑的汽油可以跑 `20` 公里，这个值是从一个单独的方法返回的, 因此派生类可以重写这个方法。下面就是这样一个派生类：
```cpp
class EfficientCarMilesEstimator : public MilesEstimator {
private:
    int getMilesPerGallon() const override { return 35; }
};

EfficientCarMilesEstimator myEstimator;
myEstimator.setGallonsLeft(2);
cout << format("Efficient estimator can go {} more miles.",
myEstimator.getMilesLeft()) << endl;
Efficient estimator can go 70 more miles.
```
通过重写这个 `private` 方法，派生类完全修改了没有更改的现有 `public` 方法的行为。
基类中的 `getMilesLeft` 方法将自动调用 `getMilesPerGallon` 方法的重写版本，因此重写 `private` 或 `protected` 方法可在不做重大改动的情况下改变类的某些特性。
#### The Base Class Method Has Default Arguments
派生类与基类可以具有不同的默认参数，但使用的参数取决于声明的变量类型，而不是底层的对 象。下面是一个简单的派生类示例，派生类在重写的方法中提供了不同的默认参数：
```cpp
class Base
{
public:
    virtual ~Base() = default;
    virtual void go(int i = 2) {
        cout << "Base's go with i=" << i << endl; }
    };
class Derived : public Base
{
public:
    void go(int i = 7) override {
        cout << "Derived's go with i=" << i << endl; }
    };
```
如果调用 `Derived` 对象的 `go`，将执行 `Derived` 版本的 `go`，默认参数为 7。如果调用 `Base` 对象的 `go`，将执行 `Base` 版本的 `go`，默认参数为 2。然而，如果使用实际指向 `Derived` 对象的 `Base` 指针或 `Base` 引用调用 `go`，将调用 `Derived` 版本的 `go`，但实际使用 `Base` 版本的默认参数 2。 下面的示例显示了这种行为：
```cpp
Base myBase;
Derived myDerived;
Base& myBaseReferenceToDerived { myDerived };
myBase.go();
myDerived.go();
myBaseReferenceToDerived.go();
```
产生这种行为的原因是 `C++` 根据表达式的编译期类型(而非运行时类型)绑定默认参数。在 `C++` 中，默认参数不会被继承，如果上面的 `Derived` 类没有像父类那样提供默认参数，就用新的非零参数版本重载 `go` 方法。
因此，当重写具有默认参数的方法时，也应该提供默认参数，这个参数的值应该与基类版本相同。建议使用命名的常量作为默认值，这样可在派生类中使用同一个命名的常量。
#### The Base Class Method Has a Different Access Specification
可以采用两种方法修改方法的访问级别—可以加强限制，也可放宽限制。
为加强某个方法(或数据成员)的限制，有两种方法。一种方法是修改整个基类的访问说明符。另一种方法是在派生类中重新定义访问限制，下面的 `Shy` 类演示了这种方法:
```cpp
class Gregarious
{
public:
    virtual void talk() {
        cout << "Gregarious says hi!" << endl; }
    };
class Shy : public Gregarious
{
protected:
    void talk() override {
        cout << "Shy reluctantly says hello." << endl; 
    }
};
```
`Shy` 类中 `protected` 版本的 `talk` 方法适当地重写 `Gregarious::talk()` 方法。任何客户代码试图使用 `Shy` 对象调用 `talk` 都会导致编译错误。
```cpp
Shy myShy;
myShy.talk(); // Error! Attempt to access protected method.

Shy myShy;
Gregarious& ref { myShy };
ref.talk();
```
然而，这个方法并不是完全受保护的，可使用 `Gregarious` 引用或指针访问 `Shy::protected` 方法。
上例重新定义了派生类中的方法，因为它希望显示另一条消息，如果不希望修改实现，只想改变方法的访问级别，首选方法是在具有所需访问级别的派生类定义中添加 `using` 语句。
在派生类中放宽访问限制就比较容易，也更有意义。最简单的方法是提供一个 `public` 方法来调用基类的 `protected` 方法，如下所示。
```cpp
class Secret
{
protected:
    virtual void dontTell() { cout << "I'll never tell." << endl; }
};

class Blabber : public Secret
{
public:
    virtual void tell() { dontTell(); }
};
```
调用 `Blabber` 对象的 `public` 方法 `tell` 的客户代码可有效地访问 `Secret` 类的 `protected` 方法。当然，这并未真正改变 `dontTell` 的访问级别，只是提供了访问这个方法的公共方式。
也可在 `Blabber` 派生类中显式地重写 `dontTell`，并将这个方法设置为 `public`。这样做比降低访问级别更有意义，因为当使用基类指针或引用用时，可以清楚地表明发生的事情。例如，假定 `Blabber` 类实际上将 `dontTell` 方法设置为 `public`：
```cpp
class Blabber : public Secret
{
public:
    void dontTell() override { cout << "I'll tell all!" << endl; }
};

myBlabber.dontTell(); // Outputs "I'll tell all!"
```
如果不想更改重写方法的实现，只想更改访问级别，可使用 `using` 子句。例如:
```cpp
class Blabber : public Secret
{
public:
    using Secret::dontTell;
};

myBlabber.dontTell(); // Outputs "I'll never tell."
```
然而，在上述情况下，基类中的 `protected` 方法仍然是受保护的，因为使用 `Secret` 指针或引用调用 `Secret` 类的 `dontTell` 方法将无法通过编译。
```cpp
Blabber myBlabber;
Secret& ref { myBlabber };
Secret* ptr { &myBlabber };
ref.dontTell(); // Error! Attempt to access protected method.
ptr->dontTell(); // Error! Attempt to access protected method.
```
注意与上述对比，上述的 `protected::talk` 可以通过基类引用调用是因为在基类中是 `public`，而此处 `protected::dontTell` 仍然受保护是因为在基类中是 `protected`。
因此修改方法访问级别的唯一真正有用的方式是对 `protected` 方法提供较宽松的访问限制。
## Hide
当存在继承关系时，派生类的作用域嵌套在其基类的作用域之内。一个对象、引用或指针的静态类型决定该对象的哪些成员是可见的。即使静态类型与动态类型可能不一致（当使用基类的引用或指针时会发生这种情况），但是能使用哪些成员仍然是由静态类型决定的。
和其他作用域一样，如果派生类（即内层作用域）的成员与基类（即外层作用域）的某个成员同名，则派生类将在其作用域内隐藏该基类成员。即使派生类成员和基类成员的形参列表不一致，基类成员也仍然会被隐藏掉。
因为如果一个名字在派生类的作用域内无法正确解析，则编译器将继续在外层的基类作用域中寻找该名字的定义，派生类定义的同名名称在派生类的作用域内已经解析，不会去基类寻找，相当于将基类的同名名称隐藏。因此除了覆盖继承而来的虚函数之外，派生类最好不要重用其他定义在基类中的名字。
```c++
struct Base {
    int memfcn(); 
    void go() { cout << "go() called on Base" << endl; }
};
struct Derived : Base { 
    int memfcn(int); // 隐藏基类的 memfcn 
    void go() { cout << "go() called on Derived" << endl; }
};

Base b;
Derived d; 
b.memfcn();    // 调用 Base::memfcn 
d.memfcn(10);  // 调用 Derived::memfcn 

// 能使用哪些成员是由静态类型决定的，静态类型为 Derived
// 参数列表为空的 memfcn 被隐藏，因此没有参数列表为空的 memfcn，该调用错误
d.memfcn();

d.Base::memfcn(); // 正确：调用Base::memfcn 

Derived myDerived;
Base& ref { myDerived };

// 非虚方法不是动态绑定
ref.go(); // go called on Base
```
## Base And Derived
构造由内而外：`Derived` 构造函数首先调用 `Base` 的构造函数，然后才执行自己。
析构由外而内：`Derived` 的析构函数首先执行自己，然后才调用 `Base` 析构函数。
![image-20220514092105095](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20220514092105095.png)
### Ctor
创建对象时必须同时创建父类和包含于其中的对象。C++定义如下的创建顺序：
1. 如果某个类具有基类，则执行基类的默认构造函数。除非在 `ctor initializer` 中调用基类构造函数，此时调用这个构造函数而不是默认构造函数。 
2. 类的非静态数据成员按照声明的顺序创建。 
3. 执行该类的构造函数。
派生类初始化时将自动调用父类的默认构造函数，如果父类的默认构造函数不存在，或者希望使用其他构造函数，可在 `ctor initializer` 指定构造函数。
派生类的构造函数还可以通过 `ctor initializer` 来将实参传递给基类构造函数，但是无法传递数据成员。如果这么做，代码可以编译，但是在调用基类构造函数之后才会初始化数据成员。如果将数据成员作为参数传递给父类构造函数，数据成员不会初始化。
派生类构造函数只初始化它的直接基类，每个类各自控制其对象的初始化过程。`Base` 是 `D1` 的直接基类，是 `D2` 的间接基类，最终的派生类将包含它直接基类的子对象以及每个间接基类的子对象。
```c++
class Base { /* ... */ } ;
class D1: public Base { /* ... */ };
class D2: public D1 { /* ... */ };
```
如果想将某个类用作基类，则该类必须已经定义而非仅仅声明，这一规定的原因显而易见：派生类中包含并且可以使用它从基类继承而来的成员，为使用这些成员，派生类当然要知道它们是什么，该规定还有一层隐含的意思，即一个类不能派生它本身。
#### Virtual Ctor
任何除构造函数之外的非静态函数都可以是虚函数，构造函数不需要，也无法声明为 `virtual`，因为在创建对象时，总会明确地指定类。
友元不能是虚函数，因为友元不是类成员，而只有成员函数才能是虚函数。如果由于这个原因引起了设计问题，可以通过让友元函数使用虚成员函数来解决。
#### Inherited Constructors
可在派生类中使用 `using` 关键字显式地包含基类中定义的方法，这适用于普通类方法，也适用于构造函数。当 `using` 作用于构造函数时，将令编译器产生代码。对于基类的每个构造函数，编译器都会生成与其形参列表完全相同的派生类构造函数。
构造函数的 `using` 声明不会改变该函数的访问级别，不能指定 `explicit` 或 `constexpr` 属性。如果基类的构造函数是 `explicit` 或者 `constexpr`，则继承的构造函数也拥有相同的属性。
当一个基类构造函数含有默认实参时，这些实参并不会被继承。相反，派生类将获得多个继承的构造函数，其中每个构造函数分别省略掉一个含有默认实参的形参。例如，如果基类有一个接受两个形参的构造函数，其中第二个形参含有默认实参，则派生类将获得两个构造函数：一个构造函数接受两个没有默认实参的形参，另一个构造函数只接受一个形参，它对应于基类中最左侧的没有默认值的那个形参。
默认、拷贝和移动构造函数不会被继承，这些构造函数按照正常规则被合成。继承的构造函数不会被作为用户定义的构造函数来使用，因此，如果一个类只含有继承的构造函数，则它也将拥有一个合成的默认构造函数。
```cpp
class Base
{
public:
    virtual ~Base() = default;
    Base() = default;
    Base(std::string_view str);
};

class Derived : public Base
{
public:
    using Base::Base;
    Derived(int i); // 也可以从所有 Base 类中继承构造函数，而不定义任何构造函数
};

// using 语句从父类继承除默认构造函数外的其他所有构造函数
Base base { "Hello" }; // OK, calls string_view Base ctor.
Derived derived1 { 1 }; // OK, calls integer Derived ctor.
Derived derived2 { "Hello" }; // OK, calls inherited string_view Base ctor.
Derived derived3; // OK, calls inherited default Base ctor..
```
##### Hiding of Inherited Constructors
`Derived` 类定义的构造函数可与从 `Base` 类继承的构造函数有相同的参数列表。与所有的重写一样，此时 `Derived` 类的构造函数的优先级高于继承的构造函数。在下例中，`Derived` 类使用 `using` 关键字，继承 `Base` 类中除默认构造函数外的其他所有构造函数。然而，由于 `Derived` 类定义了一个使用浮点数作为参数的构造函数，从 `Base` 类继承的使用浮点数作为参数的构造函数被重写。
```cpp
class Base
{
public:
    virtual ~Base() = default;
    Base() = default;
    Base(std::string_view str);
    Base(float f);
};
class Derived : public Base
{
public:
    using Base::Base;
    Derived(float f); // Hides inherited float Base ctor.
};

Derived derived1 { "Hello" }; // OK, calls inherited string_view Base ctor.
Derived derived2 { 1.23f }; // OK, calls float Derived ctor.
Derived derived3; // OK, calls inherited default Base ctor.
```
因此使用 `using` 声明从基类继承构造函数有一些限制。
- 当从基类继承构造函数时，会继承除默认构造函数外的其他全部构造函数，不能只是继承基类构造函数的一个子集。
- 当继承构造函数时，无论 `using` 声明位于哪个访问规范下，都将使用与基类中相同的访问规范来继承。
##### Multiple Inheritance
在多重继承的情况下，如果一个基类的某个构造函数与另一个基类的构造函数具有相同的参数列表，就不可能从基类继承构造函数，因为那样会导致歧义。为解决这个问题，`Derived` 类必须显式地定义冲突的构造函数。例如，下面的 `Derived` 类试图继承 `Base1` 和 `Base2` 基类的所有构造函数，这会产生编译错误，因为使用浮点数作为参数的构造函数存在歧义。
```cpp
class Base1 {
public:
    virtual ~Base1() = default;
    Base1() = default;
    Base1(float f);
};

class Base2 {
public:
    virtual ~Base2() = default;
    Base2() = default;
    Base2(std::string_view str);
    Base2(float f);
};

class Derived : public Base1, public Base2 {
public:
    using Base1::Base1;
    using Base2::Base2;
    Derived(char c);
};
```
为解决这个问题，可在 `Derived` 类中显式声明冲突的构造函数，如下所示：
```cpp
class Derived : public Base1, public Base2
{
public:
    using Base1::Base1;
    using Base2::Base2;
    Derived(char c);
    Derived(float f);
};
// 在 Derived 类中显式声明的使用浮点数作为参数的构造函数
// 仍然可以在 ctor initializer 中调用 Basel 和 Base2构造函数
Derived::Derived(float f) : Base1 { f }, Base2 { f } {}
```
##### Initialization of Data Members
当使用继承的构造函数时，要确保所有成员变量都正确地初始化。比如，考虑下面 `Base` 和`Derived` 类的新定义。这个示例没有正确地初始化 `m_int` 数据成员：
```cpp
class Base
{
public:
    virtual ~Base() = default;
    Base(std::string_view str) : m_str { str } {}
private:
    std::string m_str;
};
class Derived : public Base
{
public:
    using Base::Base;
    Derived(int i) : Base { "" }, m_int { i } {}
private:
    int m_int;
};

// 调用 Derived(int i)构造函数初始化 Derived 类的 m_int 数据成员
// 并调用 Base 构造函数，用空字符串初始化 m_str 数据成员
Derived s1 { 2 };

// 调用从 Base 类继承的构造函数。然而，从 Base 类继承的构造函数只初始化 Base 类 
// m_str 成员变量，没有初始化 Derived 类的 m_int 成员变量，m_int 处于未初始化状态
Derived s2 { "Hello World" }; // 值不确定！
```
解决方法是使用类内成员初始化器，以下代码使用类内成员初始化器将 `m_int` 初始化为 0。`Derived(int i)` 构造函数仍可修改这一初始化行为，将 `m_int` 初始化为参数i的值。
```cpp
class Derived : public Base
{
public:
    using Base::Base;
    Derived(int i) : Base { "" }, m_int { i } {}
private:
    int m_int { 0 };
};
```
### Dtor
由于析构函数没有参数，因此始终可自动调用父类的析构函数。析构函数的调用顺序刚好与构造 函数相反：
1. 调用类的析构函数。
2. 销毁类的数据成员，销毁顺序与创建的顺序相反。
3. 如果有父类，调用父类的析构函数。
#### Virtual Dtor
基类声明虚析构函数，是为了确保在涉及到指针或引用的情况下释放派生对象时，能按正确的顺序调用析构函数，如果析构函数不是虚方法，默认的静态绑定将只调用指针本身类型的析构函数。
这说明当派生类对象经由一个基类指针被删除，而该基类没有虚析构函数，那么将只调用基类的析构函数，这只会释放派生类对象基类部分指向的内存，但不会释放派生类自身的部分。因此，需要将基类析构函数声明为虚函数，使得析构函数动态绑定，即先调用派生类的析构函数，然后再调用基类的析构函数。
上述的绑定不但对直接调用虚函数有效，对间接调用也有效，间接调用是指通过构造函数或析构函数调用另一个函数，如果构造函数或析构函数调用某个虚函数，则会执行与构造函数或析构函数所属类型相对应的虚函数版本：
```cpp
class Base
{
public:
    Base()  {
        cout << "Base()" << endl;
    }
    virtual ~Base() {
        go(); // 在基类中调用该方法，执行该方法的基类实现
        cout << "~Base()" << endl;
    }
    virtual void go() { cout << "go() called on Base" << endl; }
};

class Derived : public Base
{
public:
    Derived() {
        cout << "Derived()" << endl;
    }
    ~Derived() {
        go(); // 在派生类中调用该方法，执行该方法的派生类实现
        cout << "~Derived()" << endl;
    }
    void go() override { cout << "go() called on Derived" << endl; }
};

int main()
{
    Base* ptr { new Derived{} };
    delete ptr;
}
```
运行结果如下：
```
Base()
Derived()
go() called on Derived
~Derived()
go() called on Base
~Base()
```
## Non-public Inheritance
如果没有为父类指定任何访问说明符，就说明是类的 `private` 继承、结构的 `public` 继承。将父类的关系声明为 `protected`，意味着在派生类中，基类的所有 `public` 方法和数据成员都成为受保护的。与此类似，指定 `private` 继承意味着基类的所有 `public`、`protected` 方法和数据成员在派生类中都成为私有的。
## Pure Virtual Functions
纯虚函数在类定义中显式说明该方法不需要定义，并且带有纯虚函数的类不允许被实例化。由于纯虚函数没有定义，`ABI` 指定了一个特殊的函数 `__cxa_pure_virtual` 作为所有纯函数的占位符，对应的虚函数指针指向虚表中的这个占位符。
一个纯虚函数无须定义，在类内部虚函数声明语句的分号前添加 `=0` 可以将一个虚函数声明为纯虚函数：
```c++
double net_price(std::size_t) const = 0;
```
可以为纯虚函数提供定义，但函数体必须定义在类的外部。
具有至少一个纯虚方法的类称为抽象基类，因为这个类不能被实例化。编译器会强制接受这个事实：如果某个类包含一个或多个纯虚方法，就无法构建这种类型的对象，因此抽象基类提供了一种禁止其他代码直接实例化对象的方法，而它的派生类可以实例化对象，抽象基类负责定义接口，而后续的派生类可以覆盖该接口。
```cpp
export class SpreadsheetCell
{
public:
    virtual ~SpreadsheetCell() = default; // 析构函数显式设置为默认
    virtual void set(std::string_view value) = 0;
    virtual std::string getString() const = 0;
};

SpreadsheetCell cell; // Error! Attempts creating abstract class instance
unique_ptr<SpreadsheetCell> cell { new StringSpreadsheetCell{} };
```
## Multiple Inheritance
派生类的派生列表中可以包含多个基类，每个基类都包含一个可选的访问说明符。和单继承相同，如果访问说明符被省略，则关键字 `class` 对应的默认访问说明符是 `private`，关键字 `struct` 对应的是 `public`。
```cpp
class Baz public Foo, public Bar { /* Etc. */ };
```
由于列出了多个父类，`Baz` 对象具有如下特性：
- `Baz` 对象支持 `Foo` 和 `Bar` 类的 `public` 方法，并且包含这两个类的数据成员。
- `Baz` 类的方法有权访问 `Foo` 和 `Bar` 类的 `protected` 数据成员和方法。
- `Baz` 对象可以向上转型为 `Foo` 或 Bar 对象。
- 创建新的 `Baz` 对象将自动调用 `Foo` 和 `Bar` 类的默认构造函数，并按照类定义中列出的类顺序进行。
- 删除 `Baz` 对象将自动调用 `Foo` 和 `Bar` 类的析构函数，调用顺序与类在类定义中的顺序正好相反。
构造一个多重继承的派生类对象将同时构造并初始化它的所有基类子对象。派生类的构造函数初始值列表将实参分别传递给每个直接基类，其中基类的构造顺序与派生列表中基类的出现顺序一致，与构造函数初始值列表中基类的顺序无关。
```cpp
class Bear : public ZooAnimal { /* ... */ };
class Panda : public Bear, public Endangered { /* ... */ };

// explicitly initialize both base classes
Panda::Panda(std::string name, bool onExhibit)
    : Bear(name, onExhibit, "Panda"),
      Endangered(Endangered::critical) { }
// implicitly uses the Bear default constructor 
// to initialize the Bear subobject
Panda::Panda(): Endangered(Endangered::critical) { }
```
`C++11` 允许派生类从它的一个或多个基类中继承构造函数，但如果从多个基类中继承了相同的构造函数（即形参列表完全相同），程序会产生错误。
```cpp
struct Base1
{
    Base1() = default;
    Base1(const std::string&);
    Base1(std::shared_ptr<int>);
};

struct Base2
{
    Base2() = default;
    Base2(const std::string&);
    Base2(int);
};

// error: D1 attempts to inherit D1::D1 (const string&) from both base classes
struct D1: public Base1, public Base2
{
    using Base1::Base1;   // inherit constructors from Base1
    using Base2::Base2;   // inherit constructors from Base2
};

// 如果一个类从它的多个基类中继承了相同的构造函数
// 则必须为该构造函数定义其自己的版本
struct D2: public Base1, public Base2
{
    using Base1::Base1;    // inherit constructors from Base1
    using Base2::Base2;    // inherit constructors from Base2
    // D2 must define its own constructor that takes a string
    D2(const string &s): Base1(s), Base2(s) { }
    D2() = default;   // needed once D2 defines its own constructor
};
```
和单继承相同，多重继承的派生类如果定义了自己的拷贝/赋值构造函数和赋值运算符，则必须在完整的对象上执行这些操作。只有当派生类使用的是合成版本的拷贝、移动或赋值成员时，才会自动处理其基类部分。在合成版本的拷贝控制成员中，每个基类分别使用自己的对应成员隐式地完成构造、赋值或销毁等工作。
### Naming Collisions
```cpp
class Dog
{
public:
    virtual void bark() { cout << "Woof!" << endl; }
    virtual void eat() { cout << "The dog ate." << endl; }
};

class Bird
{
public:
    virtual void chirp() { cout << "Chirp!" << endl; }
    virtual void eat() { cout << "The bird ate." << endl; }
};

class DogBird : public Dog, public Bird { };
```
为消除歧义，可使用 `dynamic_cast` 显式地将对象向上转型(本质上是向编译器隐藏多余的方法 版本)，也可以使用作用域解析运算符：
```cpp
dynamic_cast<Dog&>(myConfusedAnimal).eat(); // Calls Dog::eat()
myConfusedAnimal.Dog::eat(); // Calls Dog::eat()

class DogBird : public Dog, public Bird
{
public:
    void eat() override {
        Dog::eat(); // Explicitly call Dog's version of eat()
    }
};

// 使用 using 语句显式指定在 DogBird 类中应继承哪个版本的 eat 方法
class DogBird : public Dog, public Bird
{
public:
    using Dog::eat; // Explicitly inherit Dog's version of eat()
};
```
### Ambiguous Base Classes
尽管在派生列表中同一个基类只能出现一次，但实际上派生类可以多次继承同一个类。
直接继承某个基类，然后通过另一个基类再次间接继承该类。例如，如果出于某种原因 `Bird` 类从 `Dog` 类继承，`DogBird` 类的代码将无法编译，因为 `Dog` 变成了歧义基类，其中的数据成员也可以引起歧义，如果 `Dog` 和 `Bird` 类具有同名的数据成员，当客户代码试图访问这个成员时，就会发生歧义错误。
```cpp
class Dog {};
class Bird : public Dog {};
class DogBird : public Bird, public Dog {}; // Error!
```
多个父类本身也可能有共同的父类，此时可能出现两个直接基类分别继承同一个间接基类的情况。例如 `Bird` 和 `Dog` 类可能都是 `Animal` 类的派生类。`Cpp` 允许这种类型的类层次结构，尽管仍然存在着名称歧义。例如，如果 `Animal` 类有一个公有方法 `sleep`，`DogBird` 对象无法调用这个方法，因为编译器不知道该调用 `Dog` 类继承的版本还是 `Bird` 类继承的版本。
使用菱形继承的最佳方法是将最顶部的类设置为抽象类，将所有方法都设置为纯虚方法。由于类只声明方法而不提供定义，在基类中没有方法可以调用，因此在这个层次上就没有歧义。
下例实现了菱形类层次结构，其中 `eat` 是每个派生类都必须定义的纯虚方法。`DogBird` 类仍然必须显式说明使用哪个父类的 `eat` 方法，但是 `Dog` 和 `Bird` 类引起歧义的原因是它们具有相同的方法，而不是因为从同一个类继承。
```cpp
class Animal {
public:
    virtual void eat() = 0;
};

class Dog : public Animal {
public:
    virtual void bark() { cout << "Woof!" << endl; }
    void eat() override { cout << "The dog ate." << endl; }
};

class Bird : public Animal {
public:
    virtual void chirp() { cout << "Chirp!" << endl; }
    void eat() override { cout << "The bird ate." << endl; }
};

class DogBird : public Dog, public Bird{
public:
    using Dog::eat;
};
```
## Virtual Base Classes
当多个基类拥有公共父类时，会发生歧义父类，解决办法是让共享的父类本身没有任何自有功能，这样就永远无法调用这个类的方法，因此也就不存在歧义。
默认情况下，派生类含有继承链上每个类对应的子部分。如果某个类在派生过程中出现了多次，则派生类中会包含该类的多个子对象。而虚继承可以让某个类共享它的基类，其中共享的基类子对象称为虚基类。在该机制下，不论虚基类在继承体系中出现多少次，派生类都只包含唯一一个共享的虚基类子对象，而且虚派生只影响从指定了虚基类的派生类中进一步派生出的类，它不会影响派生类本身。
因此如果希望被共享的父类拥有自己的功能，可以使用虚基类来解决这个问题。以下代码在 `Animal` 基类中添加了 `sleep` 方法，并修改了 `Dog` 和 Bird 类，从而将 `Animal` 作为虚基类继承。 
如果不使用 `virtual` 关键字，用 `DogBird` 对象调用 `sleep` 会产生歧义，从而导致编译错误。因为 `DogBird` 对象有 `Animal` 类的两个子对象，一个来自 `Dog` 类，另一个来自 `Bird` 类。然而，如果 `Animal` 被作为虚基类，`DogBird` 对象就只有 `Animal` 类的一个子对象，因此调用 `sleep` 也就不存在歧义。
```cpp
class Animal
{
public:
    virtual void eat() = 0;
    virtual void sleep() { cout << "zzzzz...." << endl; }
};
class Dog : public virtual Animal
{
public:
    virtual void bark() { cout << "Woof!" << endl; }
    void eat() override { cout << "The dog ate." << endl; }
};
class Bird : public virtual Animal
{
public:
    virtual void chirp() { cout << "Chirp!" << endl; }
    void eat() override { cout << "The bird ate." << endl; }
};
class DogBird : public Dog, public Bird
{
public:
    void eat() override { Dog::eat(); }
};

DogBird myConfusedAnimal;
myConfusedAnimal.sleep(); // Not ambiguous because of virtual base class.
```
构造含有虚基类的对象时，首先使用提供给最低层派生类构造函数的初始值初始化该对象的虚基类子部分，之后再按照直接基类在派生列表中出现的顺序依次对其初始化。
在虚派生中，虚基类是由最低层的派生类初始化的。继承体系中的每个类都可能在某个时刻成为最低层的派生类。只要能创建虚基类的派生类对象，该派生类的构造函数就必须初始化它的虚基类。即使虚基类不是派生类的直接基类，构造函数也可以进行初始化。
```cpp
Bear::Bear(std::string name, bool onExhibit)
    : ZooAnimal(name, onExhibit, "Bear") { }

Raccoon::Raccoon(std::string name, bool onExhibit)
    : ZooAnimal(name, onExhibit, "Raccoon") { }

Panda::Panda(std::string name, bool onExhibit)
    : ZooAnimal(name, onExhibit, "Panda"),
      Bear(name, onExhibit),
      Raccoon(name, onExhibit),
      Endangered(Endangered::critical),
      sleeping flag(false) { }
```
不论基类是不是虚基类，派生类对象都能被可访问基类的指针或引用操作。因为在每个共享的虚基类中只有唯一一个共享的子对象，所以该基类的成员可以被直接访问，而且不会产生二义性。此外，如果虚基类的成员只被一条派生路径覆盖，则也可以直接访问该成员。
但如果成员被多个基类覆盖，则一般情况下派生类必须为该成员定义新的版本。例如，假设类 `B` 定义了一个名为`X`的成员，`D1`和`D2`都从`B`虚继承得到，`D`继承了`D1` 和 `D2`。则在 `D` 的作用域中，`X`通过`D`的两个基类都是可见的。如果通过`D`的对象使用`X`，则有三种可能性：
- 如果`D1`和`D2`中都没有`X`的定义，则`X`会被解析为`B`的成员，此时不存在二义性。
- 如果`D1`和`D2`中的某一个定义了`X`，派生类的`X`会比共享虚基类`B`的`X`优先级更高，此时同样没有二义性。
- 如果`D1`和`D2`都定义了`X`，则直接访问`X`会产生二义性问题。
# VirtualFunction
## 动静态
变量声明时的类型或表达式生成的类型是静态类型，在编译时总是已知。变量或表达式表示的内存中对象的类型是动态类型，只有运行时才可知。如果表达式既不是引用也不是指针，则它的动态类型永远与静态类型一致。
当调用非虚函数时，会根据编译期的类型调用对应的方法，即在编译时进行绑定，这称为静态绑定。
因为指针是在运行阶段分配未命名的内存以存储值的，所以当通过指针或引用调用虚函数，且指针不进行向下转换时，会根据运行时期的类型进行绑定，即在运行时进行绑定，这称为动态绑定。
因为非引用或非指针的动静态类型一致，所以不通过指针或引用调用，依然是静态绑定。
## Virtual
因为直到运行时才能知道到底调用哪个版本的虚函数，所以所有虚函数都必须有定义。通常情况下，如果不使用某个函数，则无须为该函数提供定义。但是必须为每一个虚函数都提供定义，而不管它是否被用到，这是因为连编译器也无法确定到底会使用哪个虚函数。
成员函数如果没有被声明为虚函数，则其解析过程发生在编译阶段而非运行阶段。
### 虚函数与默认实参
虚函数可以有默认实参，每次函数调用的默认实参值由本次调用的静态类型决定。如果通过基类的指针或引用调用函数，则使用基类中定义的默认实参，即使实际运行的是派生类中的函数版本也是如此。
如果派生类函数依赖不同的实参，则程序结果将与预期不符。因此如果虚函数使用默认实参，则基类和派生类中定义的默认实参最好一致。
### 虚函数优缺点
- 实现 `C++` 的多态，提高代码的复用和接口的规范化。
- 当继承体系中增加派生类时，不需要修改使用者的代码。
- 类对象占用的内存空间大，尤其是在子类并没有对虚函数进行重写的时候，更加浪费空间。
- 可以通过地址的偏移来访问 `Private` 成员，破坏类的安全性。
- 运行性能下降，因为需要通过访问虚表找到真正执行的函数。
### 回避
使用作用域运算符 `::` 可以强制执行虚函数的某个版本，不进行动态绑定。
通常情况下，只有成员函数或友元中的代码才需要使用作用域运算符来回避虚函数的动态绑定机制。当一个派生类的虚函数调用它覆盖的基类的虚函数版本时，基类的版本通常完成继承层次中所有类型都要做的共同任务，而派生类中定义的版本需要执行一些与派生类本身密切相关的操作。如果一个派生类虚函数需要调用它的基类版本，但没有使用作用域运算符，则在运行时该调用会被解析为对派生类版本自身的调用，从而导致无限递归。
```c++
// calls the version from the base class regardless of the dynamic type of baseP
double undiscounted = baseP->Quote::net_price(42); // 该调用将在编译时完成解析。
```
## VirtualTable
每个具有虚方法的类都有一张虚表，这种类的每个对象都包含指向自身类类型的虚表的指针 `vptr`，虚表包含指向虚方法实现的指针，即类对象声明的虚方法的地址。
- 若派生类没有重新定义虚函数，派生类的 `vtbl` 将保存函数原始版本的地址
- 若派生类重新定义虚函数，派生类的 `vtbl` 将保存新函数的地址
- 若派生类定义新的虚函数，则该函数的地址也将被添加到 `vtbl` 中
### Single Inheritance
```c++
class Base {
public:
    virtual ~Base();
    virtual void Foo();
    virtual void Bar();
    double b;
};

class Derived : public Base {
public:
    void Foo() override; // override
    virtual void Baz(); // new virtual function
    double d;
  	
};
```
若一个类定义虚函数，那么编译器在编译阶段会构造 `vftable`，在表中存储虚函数的地址。每一个类对象将会有一个 `vptr`，由编译器在对象构造完成时生成，放在对象内存开始的部分，指向相应类类型的 `vftable` 中第一个虚函数的地址。当程序运行时，每一张虚函数表都会加载到内存的 `.rodata` 区。
当通过指针调用虚函数时，实际是通过 `vptr` 调用虚函数，在编译阶段无法得知基类指针指向内存中对象的类型，但编译器可以从 `vptr` 指向的地址开始计数，得到这个虚函数被放在虚表中的位置，之后在运行时期得知指向内存中对象的类型，通过这个类型的虚表与之前得到的位置，执行相应的函数调用：
```c++
Base *pB = new Derived();
pB->Foo(); // can't determine the exact type until runtime

// 运行时期将实际调用转换为下述代码
// 任何类的成员函数都是要转换为非成员函数，因此要在成员函数的第一个参数位置传入this指针
// 运行时期将知道指向内存中对象的类型，此时 pB 即 new Derived()
// 因此前往 Derived 的虚函数表
*(pB->vptr[2])(pB);
```
内存分布如下：
![image-20221211094721608](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221211094721608.png)
### Multiple Inheritance
```c++
struct Base1 {
    virtual ~Base1();
    virtual void Foo();
  	double b1;
};

struct Base2 {
    virtual ~Base2();
    virtual void Bar();
  	double b2;
};

struct Derived: public Base1, public Base2 {
    ~Derived();
    void Foo() override;
    double d;
};
```
使用基类指针寻址派生类时，基类为找到正确的派生类位置，会在当前派生类的基础上偏移另一个基类的字节数：
- 对第一个被继承的基类，即 `Base1`，不需要偏移。
- 对第二个被继承的基类，即 `Base2`，需要偏移基类 `Base1` 大小的位置。
在多重继承中，对每一个基类，派生类对象中都有相应的 `vptr`，由于 `vptr` 位于对象内存开始的地方，因此派生类对象中相应的 `vptr` 经过偏移后会指向派生类 `vftable` 中对应的虚函数开头。
下述 `pB` 将被被调整相应的偏移量从而指向 `Base2`。正是因为这种调整，`pB->Bar()` 才能通过 `pB` 找到对应的方法。
```c++
Base1* pB = new Derived();
pB->Foo(); // 不调整

Base2* pB = new Derived();
// 编译器会产生下述代码
// Derived* tmp = new Derived();
// Base2* pB = tmp + sizeof(Base1);
```
通过基指针删除派生类对象时，为在虚表中找到派生类对象的析构函数，也需要调整 `pB` 相应的偏移量，这通过 `thunk` 函数完成，可以在运行时进行调整，但是为提高运行时效率，`thunk` 函数是在编译时生成的，因为偏移量已经已知。
```cpp
Base1* pB = new Derived();
delete pB; // this is OK since pB points to the beginning

Base2* pB = new Derived();
delete pB; // it must be adjusted back to the beginning
```
`thunk` 函数可能是这样的:
```c++
void thunk_to_Derived_Desturctor(Base2* this) {
    this -= sizeof(Base1);
    Derived::~Derived(this);
}
```
内存分布如下，图中 `vftable` 末尾应为 `Base2::Bar()`：
![image-20221211100742636](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221211100742636.png)
虚表只记录虚函数，因此多重继承下，当第一个继承的基类没有虚函数时，编译器会将第一个有虚函数的基类移到虚表的前面，这个基类也称为主基类。
当 `Base1` 不再有任何虚函数时，内存分布变为下图：
![image-20221211103026599](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221211103026599.png)
### Virtual Inheritance
为解决菱形继承问题，`C++` 引入虚继承机制，以保证在菱形层次结构下基类只有一个副本。
```c++
struct VBase {
    virtual void Foo();
    double v;
};

struct Base1 : virtual public VBase {
    void Foo() override;
    virtual void Bar();
    double b1;
};

struct Base2 : virtual public VBase {
    virtual void Baz();
    double b2;
};

struct Derived: public Base1, public Base2 {
    double d;
};
```
要在派生对象中只保留一个虚拟基，可以将类拼接成两个部分：将在菱形继承案例中共享的虚基子对象和其他部分，此时 `Base1` 的内存布局如下，虚表中增加 `vbase offset` 和 `vcall offset`。
![image-20221211103434825](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221211103434825.png)
#### Virtual Base(Vbase) Offset
多重继承下，虚继承中会有不同的类继承虚基，因此要处理不同的偏移量。使用基类指针寻址派生类时，基类为找到正确的派生类位置，会在当前派生类的基础上偏移另一个基类的字节数，只不过非虚继承这个偏移量是已知的，如上所见，偏移量是上一个基类，只会有一个类层层继承，而虚继承下这个偏移量未知，需要额外的字段去记录。
假设正在使用一个 `VBase*` 的指针寻址一个 `Base1` 对象。为获得 `Base1` 的真实地址，指针通过这个偏移量进行调整。
```cpp
VBase *pV = new Base1();
// generated code
// Base1* tmp = new Base1();
// VBase* pV = tmp + vbase_offset;
// or 
// pV = tmp + *(tmp->vptr + index) // index is determined at compile time, -3 here
```
#### Virtual Call(Vcall) Offset
`Vcall Offset` 发挥着和 `Vbase Offset` 类似地作用，考虑下述代码：
```cpp
VBase *pV = new Base1();
pV->Foo();
```
同上，使用基类指针寻址派生类时，基类为找到正确的派生类位置，会在当前派生类的基础上偏移另一个基类的字节数。
`Foo()` 被重写，因此上述 `pV` 调用的是派生类 `Base1` 的虚方法，类似上述在 `thunk` 函数中所做的那样，将偏移量添加到 `*this` 指针并调用正确的函数实例。不同之处在于偏移量存储在 `vcall offset` 中，执行两个间接调用来调用函数，这种特殊的 `thunk` 被称为虚拟 `thunk`。生成的代码可能是：
```cpp
void virtual_thunk_to_Base1_Foo(VBase* this) {
    int vcall_offset = *(this->vptr + index); // every virtual call has a corresponding index
    this += vcall_offset;
    Base1::Foo(this);
}
```
可以发现，在指向时是加上这个偏移量，但用于调用函数时是减去这个偏移量，即 `Vcall Offset` 是负值。
`Derived` 类内存布局如下，将布局与 `Base1` 进行比较。由于 `int` 成员 `d` 和子对象 `Base2` ，`VBase` 的偏移量与 `Base1` 中的偏移量不同。为在 `Base1` 和 `Derived` 之间共享相同的 `thunk to Base1::Foo`，使用 `Vcall Offset` 和虚拟堆栈。这将导致更少的链接，这可能会导致更少的指令缓存失误。这样做的代价是在添加偏移量之前再增加一次负载。
![image-20221211103759296](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221211103759296.png)
### Pure Virtual Functions
纯虚函数不被实现，并且带有纯虚函数的类不允许被实例化。由于纯虚函数没有定义，`ABI` 指定一个特殊的函数 `__cxa_pure_virtual` 作为所有纯函数的占位符，对应的虚函数指针指向虚表中的这个占位符。
一个纯虚函数无须定义，在类内部虚函数声明语句的分号前添加 `=0` 可以将一个虚函数声明为纯虚函数。
```c++
// 可以为纯虚函数提供定义，但函数体必须定义在类的外部。
double net_price(std::size_t) const = 0;
```
含有纯虚函数的类是抽象基类，抽象基类负责定义接口，而后续的其他类可以覆盖该接口。虽然不能创建抽象基类的对象，但可以定义抽象基类的派生类对象，前提是这些类重写 `pure virtual` 函数。
### Other Components in the Virtual Table
#### Offset to Top
`top offset` 是从虚表指针到对象顶部的偏移量，特别是在 `dynamic_cast<>` 中使用。假设有一个 指向 `Derived` 对象的指针 `pB`：
```cpp
Base2 *pB = new Derived();
Derived* pD = dynamic_cast<Derived*>(pB);
```
因为 `pB` 的 `vptr` 指向自己的第一个虚函数的地址，而不是 `Derived` 的顶部。要将其强制转换，就要添加偏移量。方法如下面的伪 `C++` 代码所示：
```cpp
Derived* pD = pB + *(pB->vptr + index);
```
`index` 由编译器决定，因为整个虚表是在编译时构造的。`dynamic_cast<>` 只适用于多态类，即带有虚函数的类，如果 `Base2` 是非多态的，则没有虚表指针，强制转换将失败。
#### Typeinfo Pointer
`C++` 通过 `typeid` 操作符支持一种运行时类型信息机制。对于传入 `typeid` 的 `expression`，若 `expression` 是左值表达式且是一个多态类型的对象，则计算表达式，然后引用 `std::type_info` 对象，该对象表示表达式的动态类型，即虚表中的 `typeinfo` 指针所指向的对象。
因此如果 `NewpB` 只是一个指向 `Base2` 而不是 `Derived` 的指针，则不需要 `top offset`，编译器会访问对象的 `RTTI` 运行时类型标识，`dynamic_cast<T>` 将通过类型信息检查对象是否为 `T` 类型，如果是则继续执行强制转换。
```cpp
Base2 *NewpB = new Base2();
Derived* NewpD = dynamic_cast<Derived*>(pB);
```
`typeinfo pointer` 和 `top offset` 始终存在于虚拟表中，`typeinfo pointer`  必须指向同一个对象。
![image-20221211103741045](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/image-20221211103741045.png)
```c++
// 没有虚函数
cout << sizeof(Base) << endl;       // 4
cout << sizeof(Derive) << endl;     // 8
cout << typeid(pb).name() << endl;  // class Base*
cout << typeid(*pb).name() << endl; // class Base

// 有虚函数
cout << sizeof(Base) << endl;       // 8
cout << sizeof(Derive) << endl;     // 12
cout << typeid(pb).name() << endl;  // class Base*
// *pb 是左值表达式且是一个多态类型的对象，计算表达式，然后引用 std::type_info 对象，该对象表示表达式的动态类型
cout << typeid(*pb).name() << endl; // class Derive
```
