# ObjectLifeCycles
## Object Creation
数据部分访问状态是 `private`，这意味着只能通过 `MemberFunction` 来访问数据来完成初始化。而类设计假设在调用任何其他 `MemberFunction` 之前调用能够用于初始化的函数，为实现这种假设就需要特殊的成员函数 `Ctor`。
### Ctor
构造函数的名字和类名相同并没有返回类型，参数列表和函数体可能为空，不同的构造函数之间必须在参数数量或参数类型上有所区别。
构造函数不能被声明成 `const`，因为当创建类的一个 `const` 对象时，直到构造函数完成初始化过程，对象才能真正取得其常量属性，为完成初始化过程构造函数在 `const` 对象的构造过程需要向其写值。
可以使用对象来调用成员函数，但无法使用对象来调用构造函数，因为在构造函数构造出对象之前，对象是不存在的。因此构造函数被用来创建对象，而不能通过对象来调用。
```c++
// 显式，创建一个新的临时对象，然后复制给 stock1，随后调用析构函数，以删除该临时对象
// 若stock1对象已经存在，这条语句不是对stock1进行初始化，而是将新值赋给它
stock1 = Stock("Nifty Foods", 10, 50.0);
// 隐式
Stock stock1("NanoSmart", 12, 20.0);
```
### Default Constructors
默认构造函数控制默认初始化过程，不需要任何参数。只有当类没有声明任何构造函数时，编译器才会自动地生成默认构造函数，即 `Synthesized Default Constructors`，如果存在类内的初始值，用它来初始化成员，否则，默认初始化该成员。
```cpp
SpreadsheetCell myCell;     // Calls the default constructor.
SpreadsheetCell myCell { }; // Calls the default constructor.
SpreadsheetCell myCell();   // most vexing paree

auto smartCellp { make_unique<SpreadsheetCell>() };
SpreadsheetCell* myCellp { new SpreadsheetCell };
SpreadsheetCell* myCellp { new SpreadsheetCell { } };
SpreadsheetCell* myCellp{ new SpreadsheetCell() };
```
所有参数都有默认值的构造函数等同于默认构造函数。如果试图同时声明默认构造函数，以及具有多个参数并且所有参数都有默认值的构造函数，编 译器会报错。因为如果不指定任何参数，编译器不知道该调用哪个构造函数。
```c++
// 定义默认构造函数，在声明处为参数提供默认值（不能在定义处再次提供，只能在声明处提供）
Sales_data(const std::string &s = ''): bookNo(s) { }
// 使用默认实参的 constructor initialize list
Screen(const int& _x = 3, const double& _y = 3.1) : x(_x), y(_y) {};
```
#cpp11
为避免手动编写空的默认构造函数，可以使用 `default` 关键字，编译器会生成一个标准的由编译器生成的默认构造函数。为避免编译器生成默认构造函数，可以使用 `delete` 关键字，如果类的数据成员具有删除的默认构造函数, 则该类的默认构造函数也会自动删除。
### Constructor Initializers
构造函数初始化器出现在构造函数参数列表和构造函数体的左大括号之间。这个列表以冒号开始，由逗号分隔。列表中的每个元素都使用函数符号、统一初始化语法、调用基类构造函数，或者调用委托构造函数以初始化某个数据成员，数据成员的初始化按照它们在类定义中出现的顺序，而不是在构造函数初始化器中的顺序。
构造函数初始值列表中初始值的前后位置关系不会影响实际的初始化顺序：
```c++
class kk {
    int x;
    int y;
public:
    // 从构造函数初始值的形式上来看仿佛是先用val初始化了j，然后再用j初始化i。
    // 实际上，i先被初始化，因此这个初始值的效果是试图使用未定义的值j初始化i。
    kk(int val): j(val), i(j) {};
}
```
使用构造函数初始化器与在构造函数体内初始化数据成员不同。当 `C++` 建某个对象时，必须在调用构造函数前创建对象的所有数据成员。如果数据成员本身就是对象，那么在创建这些数据成员时，必须为其调用构造函数。在构造函数体内给某个对象赋值时，并没有真正创建这个对象，而只是改变对象的值，**构造函数初始化器允许在创建数据成员时直接赋初值**，这样做比在后面赋值效率高，因为赋值是先初始化再赋值。
除效率问题外更重要的是，某些数据类型必须在构造函数初始化器中或使用类内初始化器进行初始化。
- `const` 数据成员：`const` 变量创建后无法对其正确赋值，必须在创建时提供初始值
- 引用数据成员：如果不指向什么，引用将无法存在，且一旦创建，引用不得改变指向目标
- 没有默认构造函数的数据成员：如果类的数据成员是具有默认构造函数的类的对象，则不必在构造函数初始化器中显式初始化对象，如果不存在，就无法初始化该对象，必须显式调用它的某个构造函数。
- 没有默认构造函数的基类：
如果没有在构造函数初始化器中显式地初始化成员，则该成员将在构造函数体之前执行默认初始化。因此随着构造函数体一开始执行，初始化就完成了，初始化上述类型的唯一机会就是通过构造函数初始化器。
`C++11` 允许在声明数据成员时直接给予一个初始化表达式，当且仅当构造函数的初始化列表中不包含该数据成员时，这个数据成员就会自动使用初始化表达式进行初始化，但如果没有提供初始化表达式，则执行默认初始化：
```c++
class Complex {
public:
  Complex() {} // 第一个构造函数没有任何初始化列表，所以类数据成员的初始化全部类内初始值完成，re_ 和 im_ 都是 0
  Complex(float re) : re_(re) {} // 第二个构造函数提供了 re_ 的初始化，im_ 由类内初始值完成。
  Complex(float re, float im): re_(re) , im_(im) {} // 第三个构造函数则完全不使用类内初始值。
private:
  float re_{0};
  float im_{0};
};

Sales_data(const string &s): bookNo(s) { } // 等价于 units_sold、revenue是内置类型，执行默认初始化
Sales_data(const string &s): bookNo(s), units_sold(0), revenue(0) { } 
```
### Copy Constructors
拷贝构造函数允许所创建的对象是另一个对象的副本，采用源对象的 `const` 引用作为参数。如果没有编写拷贝构造函数，编译期会自动生成一个，依次将每个非 `static` 成员拷贝到正在创建的对象中，对类类型的成员，会调用其拷贝构造函数来拷贝，内置类型的成员则直接拷贝。
正如可以将编译器生成的默认构造函数设置为显式默认或显式删除，同样可以将编译器生成的拷贝构造函数设置为默认或者将其删除。如果类的数据成员具有删除的拷贝构造函数，则该类的拷贝构造函数也会自动删除。
如果一个构造函数的第一个参数是自身类类型的引用，且任何额外参数都有默认值，则此构造函数是拷贝构造函数：
```c++
class Foo {
public:
	Foo(const Foo&);
}
```
拷贝构造函数的参数必须是引用类型的，**如果拷贝构造函数中的参数不是一个引用**，那么按值传参意味着必须拷贝它的实参，但为拷贝实参，又需要调用拷贝构造函数，从而造成无穷递归地调用拷贝构造函数。
拷贝构造函数在几种情况下都会被隐式地使用，因此拷贝构造函数通常不应该是 `explicit` 的。如果需要调用拷贝函数的初始化值要求通过一个 `explicit` 的构造函数来进行类型转换，那么就不能使用拷贝初始化：
```c++
vector<int> v1(10);     // 正确：直接初始化
vector<int> v2 = 10;    // 错误：接受大小参数的构造函数是explicit的
void f(vector<int>);    // f 的参数进行拷贝初始化
f(10); 				    // 错误：不能用一个explicit的构造函数拷贝一个实参
f(vector<int>(10));     // 正确：从一个 int 显式构造一个临时 vector 
```
当使用直接初始化时，实际上是要求**编译器**使用普通的函数匹配来**选择与提供的参数最匹配的构造函数**。当使用拷贝初始化时，实际上是要求**编译器将右侧运算对象拷贝到正在创建的对象中**，如果需要的话还要进行类型转换。 
当派生类定义拷贝或移动操作时，该操作负责拷贝或移动包括基类成员在内的整个对象，通常使用对应的基类构造函数初始化对象的基类部分：
```c++
class Base { /* ... */ } ;
class D: public Base {
public:
    D(const D& d): Base(d)  { /* ... */ }
    D(D&& d): Base(std::move(d))  { /* ... */ }
};
// 假如没有调用基类的构造函数，则基类的部分被默认初始化而不是拷贝
D(const D& d)  { /* ... */ }
```
派生类的赋值运算符必须显式地为其基类部分赋值：
```c++
// Base::operator=(const Base&) is not invoked automatically
D &D::operator=(const D &rhs)
{
    Base::operator=(rhs);   // assigns the base part
    // assign the members in the derived class, as usual,
    // handling self-assignment and freeing existing resources as appropriate
    return *this;
}
```
### Initializer-List Constructors
初始化列表构造函数将 `initializer_list<T>` 作为第一个参数，并且没有任何其他参数(或者其他参数具有默认值)。在初始化列表构造函数的内部，可使用基于范围的 for 循环来访问初始化列表的元素。使用 `size` 方法可获取初始化列表中元素的数目。
### Delegating Constructors
考虑具有多个构造函数时，在一个构造函数中执行另一个构造函数。例如，以下面的方式让 `string` 构造函数调用 `double` 构造函数：
```cpp
class SpreadsheetCell {
    public:
    SpreadsheetCell(double initialValue);
    SpreadsheetCell(string_view initialValue);
    // Remainder of the class definition omitted for brevity
};
SpreadsheetCell::SpreadsheetCell(string_view initialValue) {
    SpreadsheetCell(stringToDouble(initialValue));
}
```
这看上去是合理的。因为可在类的一个方法中调用另一个方法。这段代码可以编译、链接并运行， 但结果并非预期的那样。显式调用 `SpreadsheetCell` 构造函数实际上新建了一个 `SpreadsheetCell` 类型的临时未命名对象，而并不是像预期的那样调用构造函数以初始化对象。
因此需要委托构造函数，使得构造函数初始化器调用同一个类的其他构造函数，这个调用不能放在构造函数体内，而必须放在构造函数初始化器中，且必须是列表中唯一的成员初始化器：
```cpp
SpreadsheetCell::SpreadsheetCell(string_view initialValue)
 : SpreadsheetCell { stringToDouble(initialValue) } {}
```
当使用委托构造函数时，要注意避免出现构造函数的递归。例如：
```cpp
class MyClass {
    MyClass(char c) : MyClass { 1.2 } { }
    MyClass(double d) : MyClass { 'm' } { }
};
```
第一个构造函数委托第二个构造函数，第二个构造函数又委托第一个构造函数。`Cpp` 标准没有定义此类代码的行为，这取决于编译器。
当一个构造函数委托给另一个构造函数时，受委托的构造函数的初始值列表和函数体被依次执行。在 `Sales_data` 类中，受委托的构造函数体恰好是空的。假如函数体包含有代码的话，将先执行这些代码，然后控制权才会交还给委托者的函数体。
```c++
class Sales_data {
public:
    // 非委托构造函数使用对应的实参初始化成员
    Sales_data(string s, unsigned cnt, double price):
        bookNo(s), units_sold(cnt), revenue(cnt * price) {} 
    // 其余构造函数全都委托给另一个构造函数
    Sales_data(): Sales_data("", 0, 0) {}
    Sales_data(string s): Sales_data(s, 0, 0) {} 
    // 委托给默认构造函数，默认构造函数又委托给三参数构造函数
    Sales_data(istream &is): Sales_data() { read(is, *this); } 
}; 
```
### Converting Constructors and Explicit Constructors
通过一个实参调用的构造函数定义了一条从构造函数的参数类型向类类型隐式转换的规则，把这种构造函数称作转换构造函数。只有接受一个参数的构造函数才能作为转换函数。下面的构造函数有两个参数，因此不能用来转换类型，然而，如果给第二个参数提供默认值，它便可用于转换。
```cpp
class SpreadsheetCell
{
    public:
    SpreadsheetCell() = default;
    SpreadsheetCell(double initialValue);
    SpreadsheetCell(std::string_view initialValue);
    SpreadsheetCell(const SpreadsheetCell& src);
    // Remainder omitted for brevity
};

SpreadsheetCell myCell { 4 };
myCell = 5;
myCell = "6"sv; // A string_view literal
```
单参数 `double` 和 `string_view` 构造函数可用于将 `double` 或 `string_view` 转换为 `SpreadsheetCell`。
这可能并不总是想要的行为。在可能发生隐式转换的程序上下文中，通过将构造函数或类型转换运算符声明为 `explicit`，可以防止编译器执行此类隐式转换。该规定存在一个例外，即如果表达式被用作条件，则编译器会将显式的类型转换自动应用于它。换句话说，当表达式出现在下列位置时，显式的类型转换将被隐式地执行：
- `if`、`while`、`for` 及 `do` 语句的条件部分 
- 逻辑运算符的运算对象 
- 三元运算符的条件表达式
向 `bool` 的类型转换通常用在条件部分，因此 `operator bool` 一般定义成 `explicit` 的，而在条件部分的显式的类型转换将被隐式地执行，因此只会限制除条件部分以外的情况。
`explicit` 关键字只在类定义中出现。当用 `explicit` 关键字声明构造函数时，它将只能以直接初始化的形式使用，因为发生隐式转换的一种情况是当执行拷贝初始化时。例如：
```cpp
class SpreadsheetCell
{
    public:
    SpreadsheetCell() = default;
    SpreadsheetCell(double initialValue);
    explicit SpreadsheetCell(std::string_view initialValue);
    SpreadsheetCell(const SpreadsheetCell& src);
    // Remainder omitted for brevity
};
```
在 `C++11` 之前，转换构造函数只能有一个参数，如 `SpreadsheetCell` 示例中所示。自 `C++11` 以来，由于支持列表初始化，转换构造函数可以有多个参数。假设有以下类:
```cpp
class MyClass
{
 public:
 MyClass(int) { }
 MyClass(int, int) { }
};

void process(const MyClass& c) { }

int main()
{
 process(1);
 process({ 1 });
 process({ 1, 2 });
}
```
这个类有两个构造函数，从 `C++11` 开始，它们都是转换构造函数。这些转换构造函数自动将给定参数转换为 `MyClass`。为了避免编译器执行此类隐式转换，两个转换构造函数都可以标记为`explicit`。有了这个变更，必须显式地执行这些转换：
```cpp
class MyClass
{
    public:
    explicit MyClass(int) { }
    explicit MyClass(int, int) { }
};

process(MyClass{ 1 });
process(MyClass{ 1, 2 });
```
#cpp20 
从 `Cpp20` 开始，可以将布尔参数传递给 `explicit`, 以将其转换为条件 `explicit`。语法如下:
```cpp
explicit(true) MyClass(int);
```
仅仅编写 `explidt(true)` 就等价于 `explicit`, 但它在使用类型萃取的泛型模板代码中更加有用。使用类型萃取，可以查询给定类型的某些属性，例如某个类型是否可转换为另一个类型。类型萃取的结果可以用作 `explicit` 的参数。
### Summary of Compiler-Generated Constructors
编译器为每个类自动生成默认构造函数和拷贝构造函数。然而，编译器自动生成的构造函数取决于自己定义的构造函数，对应的规则如表所示。注意默认构造函数和拷贝构造函数之间缺乏对称性。只要没有显式定义拷贝构造函数，编译器就会自动生成一个。另一方面，只要定义任何构造函数，编译器就不会生成默认构造函数。
![image.png](https://cafabapicgo.oss-cn-beijing.aliyuncs.com/Typora/20240107090010.png)

### MoveConstructor
移动构造函数的第一个参数是该类类型的右值引用，与拷贝构造函数一样，其他任何额外参数都必须有默认值。
除了完成资源移动，移动构造函数还必须确保移后源对象是可以安全销毁的。特别是，一旦资源完成移动，源对象必须不再指向被移动的资源——这些资源的所有权已经归属新创建的对象。
在函数的形参列表后面添加关键字noexcept可以指明该函数不会抛出任何异常。
对于构造函数，noexcept位于形参列表和初始化列表开头的冒号之间。在类的头文件声明和定义中（如果定义在类外）都应该指定noexcept。
```c++
StrVec::StrVec(StrVec &&s) noexcept: elements(s.elements), first_free(s.first_free), cap(s.cap) {
    s.elements = s.first_free = s.cap = nullptr; // 令 s 进入这样的状态—对其运行析构函数是安全的
}
```
与拷贝构造函数不同，移动构造函数不分配任何新内存；它接管给定的StrVec中的内存。在接管内存之后，它将给定对象中的指针都置为 nullptr。这样就完成了从给定对象的移动操作，此对象将继续存在。最终，移后源对象会被销毁，意味着将在其上运行析构函数。StrVec的析构函数在first_free上调用deallocate。如果忘记了改变s.first_free，则销毁移后源对象就会释放掉刚刚移动的内存。









































































## Object Destruction
当销毁对象时，会发生两件事：调用对象的析构函数，释放对象占用的内存。当栈中的对象超出作用域时，即当前的函数、方法或其他执行的代码块结束，对象会被销毁。换句话说，当代码遇到结束大括号时，这个大括号中所有创建**在栈中的对象都会被销毁**。栈中对象的销毁顺序与声明顺序(和构建顺序)相反。没有智能指针，**在自由存储区中分配的对象不会自动销毁**，必须对对象指针使用 `delete`, 从而调用析构函数并释放内存。
构造函数初始化对象的非 `static` 数据成员，析构函数释放对象使用的资源，并销毁对象的非 `static` 数据成员。它没有返回值，也不接受参数，由于析构函数不接受参数，因此它不能被重载。对一个给定类，只会有唯一一个析构函数。
在一个构造函数中，成员的初始化是在函数体执行之前完成的，且按照它们在类中出现的顺序进行初始化。在一个析构函数中，**首先执行函数体，然后销毁成员**。成员按初始化顺序的逆序销毁。成员是在析构函数体之后隐含的析构阶段中被销毁的。在整个对象销毁过程中，析构函数体是作为成员销毁步骤之外的另一部分而进行的。
当一个类未定义自己的析构函数时，编译器会为它定义一个合成析构函数。类似拷贝构造函数和拷贝赋值运算符，对于某些类，合成析构函数被用来阻止该类型的对象被销毁。如果不是这种情况，合成析构函数的函数体就为空。
在一个析构函数中，不存在类似构造函数中初始化列表的东西来控制成员如何销毁，析构部分是隐式的。成员销毁时发生什么完全依赖于成员的类型，销毁类类型的成员执行成员自己的析构函数。内置类型没有析构函数，因此销毁内置类型成员什么也不需要做，这也说明隐式销毁一个内置类型的指针成员不会 `delete` 它所指向的对象。
当一个对象被销毁时，就会自动调用其析构函数：
- 变量在离开其作用域时被销毁。
- 当一个对象被销毁时，其成员被销毁。
- 容器（无论是标准库容器还是数组）被销毁时，其元素被销毁。 
- 对于动态分配的对象，当对指向它的指针应用 `delete` 运算符时被销毁。 
- 对于临时对象，当创建它的完整表达式结束时被销毁。
综上：
- 栈中对象会自动销毁，调用析构函数释放内存，但对象的内置类型指针销毁时调用析构函数不会做任何事，因此需要手动 `delete`。
- 在自由存储区的对象不会自动销毁，析构函数不会执行，因此需要手动 `delete`。
- 指向一个对象的引用或指针离开作用域时不会自动销毁，析构函数不会执行，因此需要手动 `delete`。
## Assigning to Objects
在 `C++` 中，复制只在初始化对象时发生。如果一个已经具有值的对象被改写，称之为赋值。`C++` 提供的复制工具是拷贝构造函数，因为这是一个构造函数，所以只能用在创建对象时，而不能用于对象的赋值。`C++` 提供的赋值工具是赋值运算符，同样可显式地默认或删除编译器生成的赋值运算符。
如果没有编写自己的赋值运算符，`C++` 将自动生成一个，从而允许将对象赋给另一个对象。默认的 C++ 赋值行为几乎与默认的复制行为相同：以递归方式用源对象的每个数据成员并赋值给目标对象。
重载运算符的参数表示运算符的运算对象，某些运算符，包括赋值运算符，必须定义为成员函数。如果一个运算符是一个成员函数，其左侧运算对象就绑定到隐式的 `this` 参数。对于一个二元运算符，例如赋值运算符，其右侧运算对象的 `const` 引用作为显式参数传递：
```c++
class Foo {
public:
	Foo& operator=(const Foo&);
}
```
为与内置类型的赋值保持一致，赋值运算符通常返回一个指向其左侧运算对象的引用，标准库也通常要求保存在容器中的类型要具有赋值运算符，且其返回值是左侧运算对象的引用。
## Distinguishing Copying from Assignment
基本上，声明时会使用拷贝构造函数，赋值语句会使用赋值运算符：
```cpp
SpreadsheetCell myCell { 5 };

SpreadsheetCell anotherCell { myCell }; // Calls copy constructor
SpreadsheetCell aThirdCell = myCell; // Calls copy constructor

anotherCell = myCell; // Calls operator=
```
### Objects as Return Values
```cpp
string SpreadsheetCell::getString() const {
    return doubleToString(m_value);
}

SpreadsheetCell myCell2 { 5 };
string s1;
s1 = myCell2.getString(); // 赋值语句，s1 已被声明
```
当 `getString` 返回时，编译器实际上调用 `string` 拷贝构造函数，创建一个未命名的临时 `string` 对象。将结果赋给 `s1` 时，会调用 `s1` 的赋值运算符，将这个临时字符串作为参数。然后，这个临时的字符串对象被销毁。因此，这行代码针对两个不同的对象调用了拷贝构造函数和赋值运算符。不过 `RVO` 会在返回值时优化掉成本高昂的拷贝构造函数。
```cpp
SpreadsheetCell myCell3 { 5 };
string s2 = n ^ Cell3.getString(); // 声明语句，s2 之前从未出现
```
在此情况下，`getString` 返回时创建一个临时的未命名 `string` 对象。但现在 `s2` 调用的是拷贝构造函数，而不是赋值运算符。
### Copy Constructors Initializers
如果某个对象包含其他对象，编译器生成的拷贝构造函数会递归调用每个被包含对象的拷贝构造函数。当编写自己的拷贝构造函数时，**可使用前面所示的构造函数初始化器提供相同的语义**。如果在构造函数初始化器中省略某个数据成员，在执行构造函数体内的代码之前，编译器将对该成员执行默认的初始化(为对象调用默认构造函数)。这样，在执行构造函数体时，所有数据成员都己经初始化。
```cpp
// 此时使用的是赋值运算符而不是拷贝构造函数，因为它们已经初始化
SpreadsheetCell::SpreadsheetCell(const SpreadsheetCell& src) {
    m_value = src.m_value;
}
// 此时使用拷贝构造函数初始化 m_value
SpreadsheetCell::SpreadsheetCell(const SpreadsheetCell& src)
 : m_value { src.m_value } {}
```
综上，在下列情况下均会调用拷贝构造：
- 将一个对象作为实参传递给一个非引用类型的形参
- 从一个返回类型为非引用类型的函数返回一个对象
- 用花括号列表初始化一个数组中的元素或一个聚合类中的成员
- 在声明语句拷贝时





