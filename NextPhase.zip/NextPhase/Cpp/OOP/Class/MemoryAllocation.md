# Dynamic Memory Allocation In Objects
```cpp
export class Spreadsheet
{
public:
    Spreadsheet(size_t width, size_t height);
    void setCellAt(size_t x, size_t y, const SpreadsheetCell& cell);
    SpreadsheetCell& getCellAt(size_t x, size_t y);
private:
    bool inRange(size_t value, size_t upper) const;
    size_t m_width { 0 };
    size_t m_height { 0 };
    SpreadsheetCell** m_cells { nullptr };
};

void Spreadsheet::verifyCoordinate(size_t x, size_t y) const
{
    if (x >= m_width) 
        throw out_of_range { format("{} must be less than {}.", x, m_width) };
    if (y >= m_height) 
        throw out_of_range { format("{} must be less than {}.", y, m_height) };
}

void Spreadsheet::setCellAt(size_t x, size_t y, const SpreadsheetCell& cell)
{
    verifyCoordinate(x, y);
    m_cells[x][y] = cell;
}

SpreadsheetCell& Spreadsheet::getCellAt(size_t x, size_t y)
{
    verifyCoordinate(x, y);
    return m_cells[x][y];
}
```
## Ctor
```cpp
Spreadsheet::Spreadsheet(size_t width, size_t height)
 : m_width { width }, m_height { height }
{
    m_cells = new SpreadsheetCell*[m_width];
    for (size_t i { 0 }; i < m_width; i++) {
        m_cells[i] = new SpreadsheetCell[m_height];
    } // 动态分配二维数组的写法
}
```
## Dtor
如果不再需要动态分配的内存，就必须释放它们。如果在对象中动态分配了内存，就在析构函数中释放内存。当对象被销毁时，编译器确保调用析构函数。
```cpp
Spreadsheet::~Spreadsheet()
{
    for (size_t i { 0 }; i < m_width; i++) delete [] m_cells[i];
    delete [] m_cells;
    m_cells = nullptr;
}
```
## Copying
如果没有自行编写拷贝构造函数或赋值运算符，将自动生成。编译器生成的方法递归调用对象数据成员的拷贝构造函数或赋值运算符。然而对于基本类型，如int、double 和指针，只是提供按位复制或赋值：只是将数据成员从源对象直接复制或赋值到目标对象。当在对象内动态分配内存时，这样做会引发问题。
当使用自动生成的拷贝时：
```cpp
void printSpreadsheet(Spreadsheet s) { /* Code omitted for brevity. */ }

Spreadsheet s1 { 4, 3 };
printSpreadsheet(s1);
```
`Spreadsheet` 包含一个指针变量：`m_cells`，`Spreadsheet` 的浅复制向目标对象提供了一个`m_cells` 指针的副本，但没有复制底层数据。最终结果是 `s` 和 `s1` 都有一个指向同一数据的指针。如果 `s` 修改了 `m_cells` 所指的内容，这一改动也会在 `s1` 中表现出来。更糟糕的是，当函数 `printSpreadsheet` 退出时，会调用 `s` 的析构函数，释放 `m_cells` 所指的内存。现在 `s1` 拥有的指针所指的内存不再有效，即悬空指针。
当使用自动生成的赋值时：
```cpp
Spreadsheet s1 { 2, 2 }, s2 { 4, 3 };
s1 = s2;
```
不仅 `s1` 和 `s2` 中的 `m_cells` 指针指向同一内存，而且 `s1` 前面所指的内存被遗弃，即内存泄漏。
因此在类中动态分配内存后，应该编写自己的拷贝构造函数和赋值运算符提供深层的内存复制。
在类中动态分配内存时，如果只想禁止其他人复制对象或者为对象赋值，只需要显式地将 `copying` 标记为 `delete`。通过这种方法，当其他任何人按值传递对象时、从函数或方法返回对象时，或者为对象赋值时，编译器都会报错。
### Copy Constructor
这个拷贝构造函数的初始化器首先委托给非拷贝构造函数，以分配适当的内存量。之后，拷贝构造函数体复制实际值。两个步骤合到一起，对 `m_cells` 动态分配的二维数组进行了深层复制。
```cpp
Spreadsheet::Spreadsheet(const Spreadsheet& src)
 : Spreadsheet { src.m_width, src.m_height }
{
    for (size_t i { 0 }; i < m_width; i++) 
        for (size_t j { 0 }; j < m_height; j++) 
            m_cells[i][j] = src.m_cells[i][j];
}
```
### Assignment Operator
赋值之前若先删除自身指向的内存，再进行赋值新值，当出现自我赋值的情况时，就会出现问题：`this` 内的指针成员变量与传入对象的成员指针变量指向同一块堆内存，由于先释放 `this` 的内存，因此会出现将二者指向的同一个内存预先释放，则当之后将传入对象的成员指针变量传给 `this` 时，传入的是已经被删除的对象。
```cpp
class bitmap {...}; // bitmap 的 cctor 中的 new 可能抛出异常
class widget {
    bitmap* pb;
};
widget& operator=(const widget& rhs) {
    if(this == rhs) return* this; // 证同测试，赋予自我赋值安全
    delete pb; 					  // 销毁当前对象的 pb，若 *this 和 rhs 是同一个对象，则也删除 rhs.pb
    pb = new widget(*rhs.pb);     // 若 *this 和 rhs 是同一个对象，则传入的是已经被删除的对象
    return* this;
};
```
但证同测试只能保证新的赋值不会指向一个已经被删除的对象，但不具有异常安全性。例如，下述代码首先检查自我赋值，然后释放 `this` 对象的当前内存，此后分配新内存，最后复制各个元素。
但 `operator=` 中的 `new` 或类的 `cctor` 中的 `new` 可能会抛出异常，如果发生这种情况，将不再执行该方法的剩余部分而是从该方法中退出。此时，`this` 对象会持有一个指针指向一块被删除的内存（`new` 失败，自然没有新的 `m_cells`，但旧的 `m_cells` 已经被删除），因此如果在 `new` 过程发生异常的话，`this` 对象的内容可能已经被部分破坏，对象不再处于一个完整的状态。根本上说，该代码不能安全地处理异常！
```cpp
Spreadsheet& Spreadsheet::operator=(const Spreadsheet& rhs)
{
    if (this == &rhs) return *this;
    
    // Free the old memory
    for (size_t i { 0 }; i < m_width; i++) delete[] m_cells[i];
    
    delete[] m_cells;
    m_cells = nullptr;
    
    // Allocate new memory
    m_width = rhs.m_width;
    m_height = rhs.m_height;
    m_cells = new SpreadsheetCell*[m_width];
    
    for (size_t i { 0 }; i < m_width; i++) 
        m_cells[i] = new SpreadsheetCell[m_height];
    
    // Copy the data
    for (size_t i { 0 }; i < m_width; i++) 
        for (size_t j { 0 }; j < m_height; j++) 
            m_cells[i][j] = rhs.m_cells[i][j];
    return *this;
}
```
为防止 `new` 操作引发异常产生的问题，不采取证同测试，而是使用一个变量存储原本的指针来用于删除原本的内存， 并将删除 `this` 内的指针成员变量的操作延后，这样的话即使 `new` 所在语句抛出异常，`this` 对象持有的指针也不会失效：
```c++
widget& operator=(const widget& rhs) {
	widget* temp = pb; // 记录 this.pb
    // 即使 this.pb 和 rhs.pb 指向同一内存
    // 由于 this.pb 率先指向 new 创建的新内存，把原来的 this.pb 删除也没事
	pb = new widget(*rhs.pb); // 现在传入的不可能是已经被删除的对象
	delete temp; // 删除原先的 pb
	return *this;
};
```
此外，也可以使用复制和交换惯用方法，`Spreadsheet` 类添加 `swap` 方法，并提供一个非成员函数的 `swap` 版本使得各种标准库算法都可使用它：
```cpp
export class Spreadsheet
{
public:
    Spreadsheet& operator=(const Spreadsheet& rhs);
    void swap(Spreadsheet& other) noexcept;
    // Code omitted for brevity
};
```
要实现能安全处理异常的复制和交换惯用方法，要求 `swap` 函数永不抛出异常，因此将其标记为 `noexcept`，交换每个数据成员的 `swap` 方法的实现使用标准库中提供的中的 `std::swap`。
```cpp
void Spreadsheet::swap(Spreadsheet& other) noexcept
{
     std::swap(m_width, other.m_width);
     std::swap(m_height, other.m_height);
     std::swap(m_cells, other.m_cells);
}
```
非成员的 `swap` 函数只是简单地调用了 `swap` 方法
```cpp
void swap(Spreadsheet& first, Spreadsheet& second) noexcept
{
    first.swap(second);
}
```
现在就有了能安全处理异常的 `swap` 函数，它可用来实现赋值运算符：
```cpp
Spreadsheet& Spreadsheet::operator=(const Spreadsheet& rhs)
{
    Spreadsheet temp { rhs }; // Do all the work in a temporary instance
    swap(temp); // Commit the work with only non-throwing operations
    return *this;
}
```
先创建一份右边的副本 `temp`，然后用当前对象与这个副本交换。这个模式是实现赋值运算符的推荐方法，因为它保证异常安全性。这意味着如果发生任何异常，当前的 `Spreadsheet` 对象保持不变。这通过 3 个阶段来实现：
第一阶段创建一个临时副本。这不修改当前 `Spreadsheet` 对象的状态，因此，如果在这个阶段发生异常，不会出现问题。
第二阶段使用 `swap` 函数，将创建的临时副本与当前对象交换，`swap` 永远不会抛出异常。
第三阶段销毁临时对象(由于发生交换，现在包含原始对象)以清理内存。 
### Handling Moving with Move Semantics
为了对类增加移动语义，需要实现移动构造函数和移动赋值运算符。移动构造函数和移动赋值运算符应使用 `noexcept` 限定符标记，这告诉编译器，它们不会抛出任何异常。这对于与标准库兼容非常重要，因为如果实现了移动语义，标准库容器会移动存储的对象, 且确保不抛出异常。
移动构造函数只是简单地将默认构造的 `*this` 与给定的源对象进行交换。同样，移动赋值运算符将 `*this` 与给定的 `rhs` 对象进行交换：
```cpp
Spreadsheet::Spreadsheet(Spreadsheet&& src) noexcept
{
    swap(*this, src);
}

Spreadsheet& Spreadsheet::operator=(Spreadsheet&& rhs) noexcept
{
    swap(*this, rhs);
    return *this;
}
```
此时还需要修改析构函数，将源对象的 `m_cells` 指针设置为空指针，将源对象的 `m_width` 和 `m_height` 设置为 0，以防源对象的析构函数释放这片内存，因为新的对象现在拥有了这块内存：
```cpp
Spreadsheet::~Spreadsheet()
{
    for (size_t i { 0 }; i < m_width; i++) 
        delete[] m_cells[i];
    delete[] m_cells;
    m_cells = nullptr;
    m_width = m_height = 0;
}
```
### Swap Passed By Value
可以按值传递参数，无论是左值还是右值，构造参数时直接生成新的，对于左值，调用拷贝构造，新创建的形参对象是该左值的拷贝，引用计数加一，对于右值，调用移动构造，将右值移动到新创建的形参对象上，引用计数不变，因此规避可以规避证同测试。
在这个版本的赋值运算符中，参数并不是一个引用，将右侧运算对象以传值方式传递给赋值运算符。因此，`rhs` 是右侧运算对象的一个副本，参数传递时拷贝 `HasPtr` 的操作会分配该对象的一个新副本。 
```c++
class HasPtr {
public:
    explicit HasPtr(const std::string &s = std::string()) : ps(new std::string(s)), i(0) {}
    // 对ps指向的string，每个HasPtr对象都有自己的拷贝
    HasPtr(const HasPtr &p) : ps(new std::string(*p.ps)), i(p.i) {}
    HasPtr &operator=(HasPtr rhs);
    void swap(HasPtr &rhs);
    ~HasPtr() { delete ps; }
private:
  std::string *ps;
  int i;
};

void HasPtr::swap(HasPtr &rhs) {
    std::swap(ps, rhs.ps);
}

// 若非得按引用传递，则在函数体中先创建副本再交换
HasPtr &HasPtr::operator=(HasPtr rhs) {
    rhs.swap(*this);
    return *this;
}
```
在赋值运算符的函数体中，调用 `swap` 来交换 `rhs` 和 `*this` 中的数据成员。这个调用将左侧运算对象中原来保存的指针存入 `rhs` 中，并将 `rhs` 中原来的指针存入 `*this` 中。因此，在 `swap` 调用之后，`*this` 中的指针成员将指向新分配的对象——右侧运算对象中的一个副本，从而保证自我赋值的正确，代码中唯一可能抛出异常的是拷贝构造函数中的 `new` 表达式。如果真发生异常，它也会在改变左侧运算对象之前发生。
当赋值运算符结束时，临时对象将在函数执行交换操作结束后自动销毁，对象的析构函数将执行，释放掉左侧运算对象中原来的内存，就算传入同一对象，`this` 对象已经指向这个副本的新内存，释放原来的内存也没有问题。 
下述为不使用交换的方式实现，引入两个辅助方法 `cleanup` 和 `moveFrom`。前者在析构函数和移动赋值运算符中调用，后者用于把成员变量从源对象移动到目标对象，接着重置源对象。
```cpp
void Spreadsheet::cleanup() noexcept
{
    for (size_t i { 0 }; i < m_width; i++) 
        delete[] m_cells[i];
    delete[] m_cells;
    m_cells = nullptr;
    m_width = m_height = 0;
}

void Spreadsheet::moveFrom(Spreadsheet& src) noexcept
{ 
    // Shallow copy of data
    m_width = src.m_width;
    m_height = src.m_height;
    m_cells = src.m_cells;
    // Reset the source object, because ownership has been moved!
    src.m_width = 0;
    src.m_height = 0;
    src.m_cells = nullptr;
}
```
移动构造函数和移动赋值运算符都将 `m_cells` 的内存所有权从源对象移动到新对象，将源对象的`m_cells` 指针设置为空指针，将源对象的 `m_width` 和 `m_height` 设置为 0, 以防源对象的析构函数释放这片内存，因为新的对象现在拥有了这块内存。 
```cpp
// Move constructor
Spreadsheet::Spreadsheet(Spreadsheet&& src) noexcept
{
    moveFrom(src);
}

// Move assignment operator
Spreadsheet& Spreadsheet::operator=(Spreadsheet&& rhs) noexcept
{
    // Check for self-assignment
    if (this == &rhs) return *this;
    // Free the old memory and move ownership
    cleanup();
    moveFrom(rhs); 
    return *this; 
}
// 自我赋值检查确保以下代码在运行时不会导致崩溃
sheetl = std::move(sheetl);

// 定义在 <utility> 中的 exchange 可以用一个新的值替换原来的值，并返回原来的值
void Spreadsheet::moveFrom(Spreadsheet& src) noexcept
{
    // Move object data members 
    m_name = std::move(src.m__name);
    
    m_width = exchange(src.m_width, 0);
    m_height = exchange(src.m_height, 0);
    m_cells = exchange(src.m_cells, nullptr);
}
```
用 `swap` 实现移动构造函数和移动赋值运算符所需的代码更少。当加入新的数据成员时出现 bug 的可能性也更低，因为只需要升级 `swap` 函数，使其包括新的数据成员。
### In Derived Classes
当定义派生类时，必须注意拷贝构造函数和 `operator=`，如果派生类没有任何需要使用非默认拷贝构造函数或 `operator=` 的特殊数据(通常是指针)，无论基类是否有这类数据，都不需要它们。如果派生类省略了拷贝构造函数或 `operator=`，派生类中指定的数据成员就使用默认的拷贝构造函数或 `operator=`，基类中的数据成员使用基类的拷贝构造函数或 `operator=`。
另外，如果在派生类中指定了拷贝构造函数，就需要显式地链接到父类的拷贝构造函数，如果不这么做，将使用默认构造函数而不是不是拷贝构造函数初始化对象的父类部分。
```cpp
class Base
{
public:
    virtual ~Base() = default;
    Base() = default;
    Base(const Base& src) { }
};

class Derived : public Base
{
public:
    Derived() = default;
    Derived(const Derived& src) : Base { src } { }
};
```
与此类似，如果派生类重写了 `operator=`，则几乎总是需要调用父类版本的 `operator=`：
```cpp
Derived& Derived::operator=(const Derived& rhs)
{
    if (&rhs == this) return *this;
    Base::operator=(rhs); // Calls parent's operator=.
    // Do necessary assignments for derived class.
    return *this;
}
```
因此，如果派生类定义了自己的拷贝构造函数或 `operator＝`，需要显式引用基类版本。
如果在继承层次结构中需要复制功能，惯用的做法是实现多态 `clone` 方法，因为不能完全依靠标准拷贝构造函数和拷贝赋值运算符来满足需要。











