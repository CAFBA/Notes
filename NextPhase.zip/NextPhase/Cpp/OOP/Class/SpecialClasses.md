# Special Classes
## Nested Classes
一个类可以定义在另一个类的内部，前者被称为嵌套类或嵌套类型。嵌套类必须声明在类的内部，但是可以定义在类的内部或外部，在外层类之外定义嵌套类时，必须用外层类的名字限定嵌套类的名字。嵌套类的名字在外层类作用域中是可见的，在外层类作用域之外不可见。在嵌套类在其外层类之外完成真正的定义之前，它都是一个不完全类型。
普通的访问控制也适用于嵌套类定义。如果声明了一个 `private` 或 `protected` 嵌套类，这个类只能在外层类中使用。嵌套的类有权访问外层类中的所有 `private` 或 `protected` 成员，而外层类却只能访问嵌套类中的 `public` 成员。
外层类的对象和嵌套类的对象是相互独立的，在嵌套类对象中不包含任何外层类定义的成员，在外层类对象中也不包含任何嵌套类定义的成员，外层类对嵌套类的成员没有特殊的访问权限，嵌套类对外层类的成员也没有特殊的访问权限。
因此在 `Spreadsheet` 类外引用 `Cell` 必须用 `Spreadsheet::` 作用域限定名称，即使在方法定义时也是如此与返回类型中也是如此。
```c++
class Spreadsheet
{
public:
    class Cell
    {
    public:
        Cell() = default;
        Cell(double initialValue);
    };
    Spreadsheet(size_t width, size_t height,
    const SpreadsheetApplication& theApp);
};

Spreadsheet::Cell::Cell(double initialValue) : m_value { initialValue } { }

Spreadsheet::Cell& Spreadsheet::getCellAt(size_t x, size_t y)
{
    verifyCoordinate(x, y);
    return m_cells[x][y];
}
```
如果在 `Spreadsheet` 类中直接完整定义嵌套的 `Cell` 类，将使 `Spreadsheet` 类的定义略显臃肿。为缓解这一点，只需要在 `Spreadsheet` 中为 `Cell` 添加前置声明，然后独立地定义 `Cell` 类，如下所示：
```cpp
class Spreadsheet
{
public:
    class Cell;
    Spreadsheet(size_t width, size_t height,
    const SpreadsheetApplication& theApp);
};

class Spreadsheet::Cell
{
public:
    Cell() = default;
    Cell(double initialValue);
    // Omitted for brevity
};
```
## Local Classes
类可以定义在某个函数的内部，这种类被称为局部类，局部类定义的类型只能在定义它的作用域内可见。
局部类的所有成员（包括成员函数）都必须完整定义在类的内部，而且不允许声明静态数据成员，只能访问外层作用域定义的类型名、静态变量以及枚举成员，不能使用普通局部变量。
常规的访问保护规则对于局部类同样适用，外层函数对局部类的私有成员没有任何访问特权，局部类可以将外层函数声明为友元。
```c++
int a, val;
void foo(int val)
{
    static int si;
    enum Loc { a = 1024, b };
    // Bar is local to foo
    struct Bar
    {
        Loc locVal;    // ok: uses a local type name
        int barVal;
        void fooBar(Loc l = a)  // ok: default argument is Loc::a
        {
            barVal = val;    // error: val is local to foo
            barVal = ::val;  // ok: uses a global object
            barVal = si;     // ok: uses a static local object
            locVal = b;      // ok: uses an enumerator
        }
    };
    // . . .
}
```
可以在局部类的内部再嵌套一个类，局部类内的嵌套类也是一个局部类，必须遵循局部类的各种规定。此时嵌套类的定义可以出现在局部类之外，不过嵌套类必须定义在与局部类相同的作用域中。
```c
void foo()
{
    class Bar
    {
    public:
        class Nested;   // declares class Nested
    };

    // definition of Nested
    class Bar::Nested {};
}
```
## 聚合类
聚合类使得用户可以直接访问其成员，并且具有特殊的初始化语法形式。当一个类满足如下条件时，称之为聚合： 
- 所有成员都是 `public` 的。
- 没有定义任何构造函数。
- 没有类内初始值。
- 没有基类，也没有 `virtual` 函数。
可以提供一个花括号括起来的成员初始值列表，并用它初始化聚合类的数据成员，初始值的顺序必须与声明的顺序一致。
## 字面值常量类
除了算术类型、引用和指针外，某些类也是字面值类型。和其他类不同，字面值类型的类可能含有`constexpr` 函数成员。这样的成员必须符合 `constexpr` 函数的所有要求，它们是隐式 `const` 的。
数据成员都是字面值类型的聚合类是字面值常量类。如果一个类不是聚合类，但它符合下述要求，则它也是一个字面值常量类：
- 数据成员都必须是字面值类型
- 类必须至少含有一个 `constexpr` 构造函数，`constexpr` 构造函数必须初始化所有数据成员
- 如果一个数据成员含有类内初始值，则内置类型成员的初始值必须是一条常量表达式；或者如果成员属于某种类类型，则初始值必须使用成员自己的 `constexpr` 构造函数
- 类必须使用析构函数的默认定义，该成员负责销毁类的对象
尽管构造函数不能是 `const` 的，但是字面值常量类的构造函数可以是 `constexpr` 函数。事实上，一个字面值常量类必须至少提供一个 `constexpr` 构造函数。
通过前置关键字 `constexpr` 可以声明一个 `constexpr` 构造函数，`constexpr` 构造函数可以声明成 `default`。否则，`constexpr` 构造函数就必须既符合构造函数的要求（意味着不能包含返回语句），又符合 `constexpr` 函数的要求（意味着它能拥有的唯一可执行语句就是返回语句）。综合这两点可知，`constexpr` 构造函数体一般来说应该是空的。