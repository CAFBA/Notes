# Members
当在类的外部定义成员函数时，成员函数的定义必须与它的声明匹配。也就是说，返回类型、参数列表和函数名都得与类内部的声明保持一致。如果成员被声明成常量成员函数，那么它的定义也必须在参数列表后明确指定 `const` 属性。同时，类外部定义的成员的名字必须包含它所属的类名。
初始化对象数组的方案是，首先使用默认构造函数创建数组元素，然后花括号中的构造函数将创建临时对象，然后将临时对象的内容复制到相应的元素中。因此，要创建类对象数组，则这个类必须有默认构造函数。
## This
成员函数通过一个名为 `this` 的额外的隐式参数来访问调用它的那个对象。当调用一个成员函数时，用调用该函数的对象地址初始化 `this`。因为 `this` 总是指向调用它的那个对象，所以 `this` 本身是常量的指针，不允许改变 `this` 中保存的地址。
任何对类成员的直接访问都被看作 `this` 的隐式引用，也就是说，当 `isbn` 使用 `bookNo` 时，它隐式地使用 `this` 指向的成员，就像书写 `this->bookNo` 一样:
```c++
std::string isbn() const {
    return bookNo;
    // return this->bookNo;
}
```
## Static
静态变量在编译阶段就分配空间，对象还没有创建时，就已经分配空间，在程序的执行路径第一次经过变量定义语句时初始化，并且直到程序终止才被销毁，在此期间即使对象所在的函数结束执行也不会对它有影响。
### Members
有时让类的所有对象都包含某个变量的副本是没必要的。数据成员可能只对类有意义，而每个对象都拥有其副本是不合适的，这种情况可以使用 `static` 数据成员。不仅要在类定义中列出 `static` 类成员，还需要在源文件中为其分配内存。
因为静态数据成员不属于类的任何一个对象，所以它们并不是在创建类的对象时被定义的，这也意味着它们不是由类的构造函数初始化的，静态数据成员只能在全局作用域下定义，因此一旦它被定义，就将一直存在于程序的整个生命周期中。 
#### Inline
不能在类声明中初始化非 `const` 的静态成员变量，因为声明描述了如何分配内存，但并不分配内存。在类中仅仅是声明，没有定义所以没有分配空间，也就无法存储初始化的数据，所以在类的外面定义并初始化，实际上是给静态成员变量分配内存。
但从 `Cpp17` 开始，可将静态数据成员声明为 `inline` 并初始化，从而不必在类的外面为它们分配空间，即实现类内初始化。
```cpp
class Spreadsheet
{
private:
    static inline size_t ms_counter { 0 };
};
```
#### Const
类中的数据成员可声明为 `const`，意味着在创建并初始化后，数据成员的值不能再改变。如果某个常量只适用于类，应该使用 `static const` 数据成员，也称为类常量，而不是全局常量。
由于被 `const` 修饰的变量和字面值常量类型的 `constexpr` 一般不占有内存，所以 `const` 或 `constexpr` 的静态成员可以在类定义中定义和初始化，而不需要将其指定为内联变量，初始值必须是常量表达式。因为这些成员本身就是常量表达式，所以它们能用在所有适合于常量表达式的地方。
下述用一个初始化后的静态数据成员指定数组成员的维度：
```c++
class Account {
private:
    static constexpr int periodInt = 30;
    static constexpr double perDouble = 30.0;
    color periodEnum = red; // enumeration 也可以z
    double daily[periodInt];
};
constexpr int Account::periodInt;
```
如果某个静态成员的应用场景仅限于编译器可以替换它的值的情况，则一个初始化的 `const` 或 `constexpr` 静态成员不需要定义。相反，**如果将它用于值不能替换(引用)的场景中，则该成员必须有一条定义语句**，即：
- 若不需要取它的地址，则可以声明并使用而无须提供定义式
- 若需要取它的地址，则必须另外提供定义式，且在定义时不可重设初值（提供定义式即在运行期分配内存，因此可以取地址，但这也意味着会分配存储内存）
例如，如果 `period` 的唯一用途就是定义 `daily_tbl` 的维度，则不需要在 `Account` 外面专门定义 `period`。此时，如果忽略这条定义，那么对程序非常微小的改动也可能造成编译错误，因为程序找不到该成员的定义语句。需要把 `Account::period` 传递给一个接受 `const int&` 的函数时，必须定义 `period`。 
静态成员独立于任何对象。因此，在某些非静态数据成员可能非法的场合，静态成员却可以正常地使用。例如，可以使用静态成员作为默认实参，非静态数据成员不能作为默认实参，因为它的值本身属于对象的一部分，这么做的结果是无法真正提供一个对象以便从中获取成员的值，最终将引发错误。
```cpp
class Spreadsheet
{
public:
    static const size_t MaxHeight { 100 };
    static const size_t MaxWidth { 100 };
    Spreadsheet(size_t width = MaxWidth, size_t height = MaxHeight);
};
```
此外，静态数据成员可以是不完全类型。特别的，静态数据成员的类型可以就是它所属的类类型。而非静态数据成员则受到限制，只能声明成它所属类的指针或引用：
```c++
class Bar { 
    static Bar mem1; // 正确：静态成员可以是不完全类型
    Bar *mem2; 		 // 正确：指针成员可以是不完全类型
    Bar mem3;		 // 错误：数据成员必须是完全类型
};
```
`static` 修饰的成员，都是只保留一份，并且跟随对象，无论在哪个对象改变 `static` 成员的数据，在其他对象的 `static` 成员数据也会改变，因为就一份 `static` 的数据。同理，如果基类定义了一个静态成员，则在整个继承体系中只存在该成员的唯一定义。不论从基类中派生出来多少个派生类，对于每个静态成员来说都只存在唯一的实例。静态成员遵循通用的访问控制规则，如果基类中的成员是 `private` 的，则派生类无权访问它。假设某静态成员是可访问的，则既能通过基类使用它也能通过派生类使用它：
```c++
void Derived::f(const Derived &derived_obj) {
	Base::statmem(); // 正确：Base定义了 statmem 
	Derived::statmem(); // 正确：Derived 继承了 statmem
	// 静态成员是可访问的
	derived_obj.statmem(); // 通过 Derived 对象访问 
	statmem(); // 通过 this 对象访问
}
```
### Methods
`static` 方法不属于特定对象，因此没有 `this` 指针。当用某个特定对象调用 `static` 方法时，`static` 方法不会访问这个对象的非 `static` 数据成员。作为结果，静态成员函数不能声明成 `const` 的，而且也不能在 `static` 函数体内使用 `this` 指针。这一限制既适用于 `this` 的显式使用，也对调用非静态成员的隐式使用有效。
`static` 方法就像普通函数，唯一区别在于它可以访问类的 `private` 和 `protected` 的 `static` 成员。如果同一类型的其他对象对于 `static` 方法可见(例如传递对象的指针或引用作为参数)，那么 `static` 方法也可访问其他对象的 `private` 和 `protected` 的非 `static` 数据成员。
类中的任何方法都可像调用普通函数那样调用静态方法，如果要在类的外面调用静态方法，需要用类名和作用域解析运算符来限定方法的名称。
```c++
class Account {
    public:
    // 成员函数不用通过作用域运算符就能直接使用静态成员
    double calculate() {
        amount = amount * interestRate;
        return amount;
    }
    // 静态成员函数不能返回非静态成员（无论显式还是隐式），因为没有this指针
    // 即 Invalid use of member 'amount' in static member function
    static double rate() { 
        interestRate += amount;
        return interestRate; 
    }
    static void set_rate(double);
    private:
    double amount{1};
    static double interestRate;
};

// 静态数据成员定义在任何函数之外，但非静态成员必须通过构造函数完成初始化从而定义，不能在类外定义
double Account::interestRate = 10.0;

// 在类的外部定义静态成员时，不能重复static关键字
void Account::set_rate(double x) {
    interestRate = x;
}

int main() {
    Account test;
    // 可以使用作用域运算符直接访问静态成员函数
    cout << Account::rate() << endl;
    cout << test.calculate() << endl;
    // 可以使用类的对象、引用或者指针来访问静态成员
    test.set_rate(20.0);
    cout << test.calculate() << endl;
}
```
## Reference
下述在构造函数中，每个 `Spreadsheet` 都得到了一个应用程序引用。如果不指向某些事物，引用将无法存在，因此在构造函数的初始化器中必须给 `m_theApp` 指定一个值。
```cpp
export class Spreadsheet
{
public:
    Spreadsheet(size_t width, size_t height,
    const SpreadsheetApplication& theApp)
    : m_id { ms_counter++ }
    , m_width { std::min(width, MaxWidth) }
    , m_height { std::min(height, MaxHeight) }
    , m_theApp { theApp } {}
private:
     // Code omitted for brevity.
    const SpreadsheetApplication& m_theApp;
};
```
在拷贝构造函数中也必须初始化这个引用成员。由于 `Spreadsheet` 拷贝构造函数委托给非拷贝构造函数(初始化引用成员)，因此只需要修改拷贝构造函数的委托构造部分。
在初始化一个引用后，不能改变它指向的对象，因此无法在赋值运算符中对引用赋值。这意味着根据使用情形，可能无法为具有引用数据成员的类提供赋值运算符。如果属于这种情况，通常将赋值运算符标记为删除。 
## Friend
在为类重载二元运算符时，左侧的操作数应是调用对象，这样会带来必须固定顺序使用运算符的问题，可以通过与其操作顺序相反的非成员函数来匹配另一个操作顺序，但非成员函数无法访问私有部分，因此就需要赋予其访问私有部分的权利，即成为友元函数。
`C++` 允许某个类将其他类、其他类的成员函数或非成员函数声明为友元，友元可以访问类的 `protected`、`private` 数据成员和方法，即赋予与类的成员函数相同的访问权限。创建友元函数的第一步是将其原型放在类声明中，并在原型声明前加上关键字 `friend`。只有在类声明中的原型中才能使用 `friend` 关键字。除非函数定义也是原型，否则不能在函数定义中使用该关键字。
该原型意味着：
- 虽然该函数是在类声明中声明的，但它不是成员函数，因此不能使用成员运算符来调用，不需要使用限定符。
- 虽然该函数不是成员函数，但它与成员函数的访问权限相同。
如果一个类指定了友元类，则友元类的成员函数可以访问此类的所有成员：
```c++
class Tv {
  // 整个Remote类成为友元并不需要前向声明，因为友元语句本身已经指出Remote是一个类
  friend class Remote; 
  ...
};

class Remote {
  ...
};
```
另外，也可以做更严格的限制，只将特定的成员函数指定为另一个类的友元，但这样做必须小心排列各种声明和定义的顺序：
```c++
// Remote的方法提到了Tv对象，这意味着Tv定义应当位于Remote定义之前
// 由于代码中Tv定义在Remote后，因此Remote声明中只包含Tv方法声明，并将实际的定义放在Tv类之后
// 避开这种循环依赖的方法是使用前向声明
class Tv;
class Remote {
  set_chan(Tv& t, int c) { ... }
  void onoff(Tv& t);
};

class Tv {
    // 在编译器在Tv类的声明中看到Remote的一个方法被声明为Tv类的友元之前
    // 应该先看到Remote类的声明和set_chan()方法的声明
    // 否则，它无法知道Remote是一个类，而set_chan是这个类的方法
    // 因此应将Remote的定义放到Tv的定义前面
    friend void Remote::set_chan(Tv& t, int c);
    void onoff(Tv& t) { state = (state == On) ? Off : On; }
};

inline void Remote::onoff(Tv& t) { 
  t.onoff(); 
}
```
## Const
`const` 成员函数表明函数的执行过程不会修改调用对象的状态，也就是说，成员函数是一个只读操作。不能将 `static` 方法声明为 `const`，因为这是多余的。静态方法没有类的实例，因此不可能改变内部的值。
非 `const` 对象可调用 `const` 和非 `const` 成员函数。`const` 对象只能调用 `const` 成员函数，不能调用非 `const` 成员函数，因为非 `const` 成员函数可能会修改调用对象（即 `const` 对象）的状态。对于常量引用、常量指针也是如此，因为它们关联的对象是只读、不可修改的，所以对它们的任何操作也应该是只读、不可修改的。
当成员函数的 `const` 与 `non-const` 版本同时存在，`const` 对象只能调用 `const` 版本，`non-const` 对象只能调用 `non-const` 版本。
默认情况下，`this` 的类型是指向类的非常量的常量指针。例如在类 `Data` 的成员函数中，`this` 的类型是 `Data *const`。尽管 `this` 是隐式的，但它仍然需要遵循初始化规则，这意味着在默认情况下不能把 `this` 绑定到一个 `const` 对象上，这一情况也就使得不能在一个 `const` 对象上调用的 `non-const` 成员函数。 
```c++
string Data::func() const {
	return this->num;
}
// equal
string Data::func(const Data *const this) {
    return this->num;
}
```
只有将成员函数的 `this` 声明为指向常量的常量指针，才能使用 `const` 对象调用它，这通过在成员函数的参数列表后面添加 `const` 实现，这也同时说明一个 `const` 成员函数如果以引用的形式返回 `*this`，那么它的返回类型将是常量引用。
## Mutable
`volatile` 可以用来修饰任何变量，而 `mutable` 只能修饰类里面的成员变量，表示变量即使是在 `const` 成员函数里，也是可以修改的。换句话说，就是标记为 `mutable` 的成员不会改变对象的状态，也就是不影响对象的常量性，所以允许 `const` 成员函数改写 `mutable` 成员变量。
因为对象与普通的 `int`、`double` 不同，内部会有很多成员变量来表示状态，但因为封装特性，外界只能看到一部分状态，判断对象是否 `const` 应该由这些外部可观测的状态特征来决定。对于这些有特殊作用的成员变量，可以给它加上 `mutable` 修饰，解除 `const` 的限制，让任何成员函数都可以操作它。
```c++
class DemoClass final {
private:
    mutable mutex_type  m_mutex;    // mutable成员变量
public:
    void save_data() const          // const成员函数
    { ... }// do someting with m_mutex 
}
```


## Inline Methods
函数调用的处理过程：执行到函数调用时，程序将在调用后立即存储该指令的内存地址，并将函数参数赋值到堆栈，跳到标记函数起点的内存单元，执行函数代码（将返回值放到寄存器中)，然后跳回到被保存的指令。
普通函数有标准的函数调用过程，参数压栈，函数栈帧的开辟和退回的过程。而内联函数在编译过程中没有函数调用的开销，**编译器将使用相应的函数代码替换函数调用**，对于内联函数，无需跳到另一个位置执行代码再跳回来，可以减少处理函数调用的时间，并且不再生成相应的函数符号，但**代价是**占用更多的内存，可能增加目标码大小，即使拥有虚拟内存，`inline` 造成的代码膨胀亦会导致额外的换页行为，降低指令高速缓存装置的击中率，以及伴随这些而来的效率损失。
因此将大多数 `inlining` 限制在小型、被频繁调用的函数身上。这可使日后的调试过程和二进制升级更容易，也可使潜在的代码膨胀问题最小化，使程序的速度提升机会最大化。
在 `C++20` 模块之外，如果方法的定义直接放在类定义中，则该方法会隐式标记为 `inline`, 即使不 使用 `inline` 关键字。对于从 `C++20` 中的模块导出的类，情况不再如此。如果希望这些方法是内联的， 则需要使用 `inline` 关键字标记它们。
`inline` 只是对编译器的一个申请，不是强制命令，并不是所有的 `inline` 都被编译器处理成内联函数。大部分编译器拒绝将太过复杂（例如带有循环或递归）的函数 `inlining`，而**所有对 `virtual` 函数的调用（除非是最平淡无奇的）也都会使 `inlining` 落空**。因为 `virtual` 意味等待，直到运行期才确定调用哪个函数，而 `inline` 意味执行前，先将调用动作替换为被调用函数的本体。
**编译器通常不对通过函数指针而进行的调用实施 `inlining`**，因为使用函数指针意味着要取某个 `inline` 函数的地址，编译器通常必须为此函数生成一个 `outlined` 函数本体。这意味对 `inline` 函数的调用有可能被 `inlined`，也可能不被 `inlined`，取决于该调用的实施方式：
```c++
inline void f() // 假设编译器有意愿inline对f的调用
void(*pf)() = f；// pf指向f
f();  // 这个调用将被inlined，因为它是一个正常调用
pf(); // 这个调用或许不被inlined，因为它通过函数指针达成。
```
对于构造函数和析构函数来说，不应该将其 `inline`。
因为 `Derived` 构造函数至少一定会陆续调用其成员变量和 `base class` 两者的构造函数，而那些调用（它们自身也可能被 `inlined`）会影响编译器是否对空白函数 `Derived` 进行 `inlining`。
相同理由也适用于 `Base` 构造函数，所以如果它被 `inlined`，所有替换 `Base` 构造函数调用而插入的代码也都会被插入到 `Derived` 构造函数调用内（因为 `Derived` 构造函数调用 `Base` 构造函数）。
如果 `string` 构造函数恰巧也被 `inlined`，`Derived` 构造函数将获得五份 `string` 构造函数代码副本，每一份副本对应于 `Derived` 对象内的五个字符串（两个来自继承，三个来自自己的声明）之一。
这说明是否将 `Derived` 构造函数 `inline` 化并非是个轻松的决定。`类似思考也适用于Derived析构函数`，被 `Derived` 构造函数初始化的所有对象被一一销毁，无论以哪种方式进行。
```c++
class Base{ 
	public: ... 
	private:
		std::string bm1,bm2;
};
class Derived: public Base{
	public:
		Derived(){}
	private:
		std::string dm1,dm2,dm3;
}；
```
程序库设计者必须评估将函数声明为 `inline` 的冲击：`inline` 函数无法随着程序库的升级而升级。换句话说如果 `f` 是程序库内的一个 `inline` 函数，客户将f函数本体编进其程序中，一旦程序库设计者决定改变 `f`，所有用到f的客户端程序都必须重新编译。然而如果 `f` 是 `non-inline` 函数，一旦它有任何修改，客户端只需重新链接就好，远比重新编译的负担少很多。如果程序库采取动态连接，升级版函数甚至可以不知不觉地被应用程序吸纳。













## Enumerated Types
```cpp
class SpreadsheetCell
{
public:
    enum class Color { Red = 1, Green, Blue, Yellow };
    void setColor(Color color);
    Color getColor() const;
private:
    Color m_color { Color::Red };
};

void SpreadsheetCell::setColor(Color color) { m_color = color; }
SpreadsheetCell::Color SpreadsheetCell::getColor() const { return m_color; }

SpreadsheetCell myCell { 5 };
myCell.setColor(SpreadsheetCell::Color::Blue);
auto color { myCell.getColor() };
```
## Pointer to Class Member
**成员指针（pointer to member）是指可以指向类的非静态成员的指针**。成员指针的类型包括类的类型和成员的类型。初始化或者给成员指针赋值时，需要指定它所指向的成员，但是不指定该成员所属的对象。直到使用成员指针时，才提供成员所属的对象。
### Pointers to Data Members
声明成员指针时必须在`*`前添加`classname::`以表示当前定义的指针可以指向classname的成员。常规的访问控制规则对成员指针同样有效。数据成员一般是私有的，因此通常不能直接获得数据成员的指针。如果类希望外部代码能访问它的私有数据成员，可以定义一个函数，令其返回指向私有成员的指针。
```c++
class Screen {
public:
    typedef std::string::size_type pos;
    char get_cursor() const { return contents[cursor]; }
    char get() const;
    char get(pos ht, pos wd) const;
private:
    std::string contents;
    pos cursor;
    pos height, width;
}

// pdata can point to a string member of a const (or non const) Screen object
const string Screen::*pdata;
// 初始化或者给成员指针赋值时，需要指定它所指向的成员，但是不指定该成员所属的对象。
pdata = &Screen::contents;
// 直到使用成员指针时，才提供成员所属的对象
Screen myScreen, *pScreen = &myScreen;

// 成员指针使用`.*`和`->*`来获得其指向对象的成员。
// .* dereferences pdata to fetch the contents member from the object myScreen
auto s = myScreen.*pdata;
// ->* dereferences pdata to fetch contents from the object to which pScreen points
s = pScreen->*pdata;
```
### Pointers to Member Functions
类似于其他函数指针，指向成员函数的指针也需要指定目标函数的返回类型和形参列表。如果成员函数是`const`成员或引用成员，则指针也必须包含`const`或引用限定符。
```c++
// pmf is a pointer that can point to a Screen member function that is const
// that returns a char and takes no arguments
auto pmf = &Screen::get_cursor;

// 和普通函数指针不同，在成员函数和指向该成员的指针之间不存在自动转换规则。
// pmf points to a Screen member that takes no arguments and returns char
pmf = &Screen::get;    // must explicitly use the address-of operator
pmf = Screen::get;     // error: no conversion to pointer for member functions
```
如果成员函数存在重载问题，则必须显式声明指针指向的函数类型。
```cpp
char (Screen::*pmf2)(Screen::pos, Screen::pos) const;
pmf2 = &Screen::get;
```
成员函数指针使用`.*`和`->*`来调用类的成员函数。
```cpp
Screen myScreen, *pScreen = &myScreen;
// call the function to which pmf points on the object to which pScreen points
char c1 = (pScreen->*pmf)();
// passes the arguments 0, 0 to the two-parameter version of get on the object myScreen
char c2 = (myScreen.*pmf2)(0, 0);
```
### Pointers to Static Members
```c++
class Test {
public:
  void func() { cout << 1 << endl; }
  static void sta_func() { cout << 1 << endl; }
  int ma;
  static int mb;
};
int Test::ma;
```
指向成员变量的指针：
```c++
Test t1;
Test *t2 = new Test();
// 定义指针指向类的成员变量需要作用域运算符
int Test::*p = &Test::ma;
// 静态类成员变量就不需要作用域运算符
int *p1 = &Test::mb;

t1.*p = 20; // 依赖于对象
t2.*p = 30;
*p1 = 40; // 不依赖对象
```
指向成员方法的指针：
```c++
// 不使用 auto 就需要函数指针，需要作用域运算符
void (Test::*pfunc)() = &Test::func;
(t1.*pfunc)(); // 依赖于对象
(t2->*pfunc)();
// 静态成员函数不需要作用域运算符
void (*pfunc)() = &Test::func;
(*pfunc)() // 不依赖对象
```
### Using Member Functions as Callable Objects
成员指针不是一个可调用对象，不支持函数调用运算符。
```c++
auto fp = &string::empty;   // fp points to the string empty function
// error: must use .* or ->* to call a pointer to member
find_if(svec.begin(), svec.end(), fp);
```
可以使用两种方式（定义在头文件`functional`中）从成员函数指针获取可调用对象：
使用标准库模板`function`：定义一个`function`对象时，必须指定该对象所能表示的函数类型（即可调用对象的返回值和形参列表），而且如果可调用对象是一个成员函数（而不是函数对象），则该函数类型的**第一个形参必须表示该成员函数是在哪个对象上执行的**，就像成员函数有隐式参数 this 指针：
```cpp
function<bool (const string&)> fcn = &string::empty;
find_if(svec.begin(), svec.end(), fcn);

class myClass {
public:
    bool myFnc(int t, double y) {
        cout << "function" << endl;
        cout << t << y << endl;
        return true;
    }
};
// 根据指定的函数类型，通过对象和指针调用
myClass test;
function<bool (myClass, int, double)> ftn = &myClass::myFnc;
ftn(test, 10, 100.0); // 通过对象调用  
function<bool (myClass*, int, double)> ftn = &myClass::myFnc;
ftn(&test, 10, 100.0); // 通过指针调用
```
使用标准库功能`mem_fn`可以**让编译器推断成员的类型**。和`function`一样，`mem_fn`可以从成员指针生成可调用对象，但`mem_fn`可以根据成员指针的类型推断可调用对象的类型，无须显式指定。
```c++
find_if(svec.begin(), svec.end(), mem_fn(&string::empty));
// mem_fn 生成的可调用对象可以通过对象和指针调用。
myClass test;
auto f = mem_fn(&myClass::myFnc); // f takes a myClass or a myClass*
f(&test, 10, 100.0); // ok: passes a myClass object; f uses .* to call myFnc
f(test, 10, 100.0);  // ok: passes a pointer to myClass; f uses .-> to call myFnc
```
## Default
可以通过将拷贝控制成员定义为 `=default` 来显式地要求编译器生成合成的版本：
```c++
class Sales_data{ 
public:
    // 当在类内用 =default 修饰成员的声明时，合成的函数将隐式地声明为内联的
    Sales_data() = default;
    Sales_data(const Sales_data&) = default; 
    Sales_data& operator=(const Sales_data &); 
    ~Sales_data() = default; 
};
// 如果不希望合成的成员是内联函数，应该只对成员的类外定义使用=default
Sales_data& Sales_data::operator(const Sales_data &) = defaul;
```
`=default` 通常在多态基类中很有用，即通过操作的是哪个派生类对象来定义接口。多态基类通常有一个虚析构函数，因为如果它们非虚，一些操作（比如通过一个基类指针或者引用对派生类对象使用`delete`或者`typeid`）会产生未定义或错误结果。然而用户声明的析构函数会抑制编译器生成移动操作，所以如果该类需要具有移动性，就为移动操作加上 `=default`。声明移动会抑制拷贝生成，所以如果拷贝性也需要支持，再为拷贝操作加上 `=default`：
```cpp
class Base {
public:
    virtual ~Base() = default;              //使析构函数virtual
    
    Base(Base&&) = default;                 //支持移动
    Base& operator=(Base&&) = default;
    
    Base(const Base&) = default;            //支持拷贝
    Base& operator=(const Base&) = default;
};
```
实际上，就算编译器会生成拷贝和移动操作，生成的函数也如你所愿，也应该手动声明它们然后加上`= default`。比如，有一个类来表示字符串表，即一种支持使用整数 ID 快速查找字符串值的数据结构：
```cpp
class StringTable {
public:
    StringTable() {}
    …                   //插入、删除、查找等函数，但是没有拷贝/移动/析构功能
private:
    std::map<int, std::string> values;
};
```
假设这个类没有声明拷贝操作，没有移动操作，也没有析构，如果它们被用到编译器会自动生成。没错，很方便。后来需要在对象构造和析构中打日志，增加这种功能很简单：
```cpp
class StringTable {
public:
    StringTable()
    { makeLogEntry("Creating StringTable object"); }    //增加的

    ~StringTable()                                      //也是增加的
    { makeLogEntry("Destroying StringTable object"); }
    …                                               //其他函数同之前一样
private:
    std::map<int, std::string> values;              //同之前一样
};
```
看起来合情合理，但是声明析构有潜在的副作用：它阻止了移动操作的生成。然而，拷贝操作的生成是不受影响的。因此代码能通过编译，运行，也能通过功能测试。功能测试也包括移动功能，因为即使该类不支持移动操作，对该类的移动请求也能通过编译和运行。这个请求正如之前提到的，会转而由拷贝操作完成。
这意味着对 `StringTable` 对象的移动实际上是对对象的拷贝，即拷贝里面的 `std::map<int, std::string>` 对象。拷贝 `std::map<int, std::string>` 对象很可能比移动慢几个数量级。简单的加个析构就引入了极大的性能问题！对拷贝和移动操作显式加个 `=default`，问题将不再出现。
## Delete
可以通过将拷贝构造函数和拷贝赋值运算符定义为删除的函数来阻止拷贝。删除的函数是这样一种函数：虽然声明它们，但不能以任何方式使用它们，在函数的参数列表后面加上 `=delete` 来将它定义为删除的。
与 `=default` 不同，`=delete` 必须出现在函数第一次声明的时候，这个差异与这些声明的含义在逻辑上是吻合的。一个默认的成员只影响为这个成员而生成的代码，因此 `=default` 直到编译器生成代码时才需要。而另一方面，编译器需要知道一个函数是删除的，以便禁止试图使用它的操作。 
与 `=default` 的另一个不同之处是，可以对任何函数指定 `=delete` 从而引导函数匹配过程，但只能对编译器可以合成的默认构造函数或拷贝控制成员使用 `=default`。
**对于一个删除析构函数的类型，编译器将不允许定义该类型的变量或创建该类的临时对象**。而且，如果一个类有某个成员的类型删除了析构函数，也不能定义该类的变量或临时对象。因为如果一个成员的析构函数是删除的，则该成员无法被销毁。而如果一个成员无法被销毁，则对象整体也就无法被销毁了。 
对于删除了析构函数的类型，虽然不能定义这种类型的变量或成员，但可以动态分配这种类型的对象，但不能释放这些对象：
```c++
struct NoDtor {
    NoDtor()= default;
    ~NoDtor() = delete; // 不能销毁NoDtor 类型的对象
};
// 对于析构函数已删除的类型，不能定义该类型的变量或释放指向该类型动态分配对象的指针。
NoDtor nd;				// 错误：NoDtor的析构函数是删除的 
NoDtor *p= new NoDtor(); // 正确：但不能delete p 
delete p;				// 错误：NoDtor 的析构函数是删除的
```
## Prefer Deleted Functions To Private Undefined Ones
### Preventing Calls
在 `C++98` 中防止调用函数的方法是将它们声明为 `private` 成员函数并且不定义。
举个例子，在 `C++` 标准库 `iostream` 继承链的顶部是模板类 `basic_ios`。所有 `iostream` 和 `ostream` 类都继承此类（直接或者间接）。拷贝 `iostream` 和 `ostream` 是不合适的，因为这些操作应该怎么做是模棱两可的。比如一个 `istream` 对象，代表一个输入值的流，流中有一些已经被读取，有一些可能马上要被读取。如果一个 `iostream` 被拷贝，需要拷贝将要被读取的值和已经被读取的值吗？解决这个问题最好的方法是不定义这个操作，直接禁止拷贝流。
要使这些 `iostream` 和 `ostream` 类不可拷贝，`basic_ios` 在 `C++98` 中是这样声明的：
```cpp
template <class charT, class traits = char_traits<charT> >
class basic_ios : public ios_base {
public:

private:
    // 拷贝控制成员是 private 的，因此普通用户代码无法访问
    // 但友元和成员函数仍旧可以拷贝对象，因此需要声明但不定义
    basic_ios(const basic_ios& );           // not defined
    basic_ios& operator=(const basic_ios&); // not defined
};
```
为阻止友元和成员函数进行拷贝，可以将 `copying` 声明为 `private`，但并不定义它们，试图访问一个未定义的成员将在链接时引发缺少函数定义错误。试图拷贝对象的用户代码将在编译阶段被标记为错误，成员函数或友元函数中的拷贝操作将会导致链接时错误。
因此在 `C++11` 之前，声明但不定义 `private` 的 `copying`，将基类的拷贝构造函数和拷贝赋值运算符声明为 `private`（编译器将拒绝为其派生类生成 `copying`，因为派生类生成的 `copying` 无权处理基类的私有成员变量），可以预先阻止任何拷贝该类型对象的企图。
在 `C++11` 中有一种更好的方式达到相同目的：
```cpp
template <class charT, class traits = char_traits<charT> >
class basic_ios : public ios_base {
public:

    basic_ios(const basic_ios& ) = delete;
    basic_ios& operator=(const basic_ios&) = delete;
    …
};
```
删除这些函数和声明为私有成员可能看起来只是方式不同，别无其他区别。其实还有一些实质性意义。`deleted` 函数不能以任何方式被调用，即使在成员函数或者友元函数里面调用  `deleted`  函数也不能通过编译。这是较之 `C++98` 行为的一个改进，`C++98` 中不正确的使用这些函数在链接时才被诊断出来。
通常，`deleted`  函数被声明为 `public` 而不是 `private`，这也是有原因的。当客户端代码试图调用成员函数，`C++` 会在检查 `deleted` 状态前检查它的访问性。当客户端代码调用一个私有的 `deleted` 函数，一些编译器只会给出该函数是 `private` 的错误，而没有诸如该函数被 `deleted` 修饰的错误，即使函数的访问性不影响它是否能被使用。所以如果要将老代码的私有且未定义函数替换为 `deleted` 函数时请一并修改它的访问性为 `public`，这样可以让编译器产生更好的错误信息。
### Preventing Type Conversion
`deleted` 函数还有一个重要的优势是**任何**函数（包括实例化的函数）都可以标记为 `deleted` ，而只有成员函数可被标记为 `private`。假如有一个非成员函数，它接受一个整型参数，检查它是否为幸运数：
```cpp
bool isLucky(int number);
```
`C++` 有沉重的 `C` 包袱，使得含糊的、能被视作数值的任何类型都能隐式转换为 `int`，但是有一些调用可能是没有意义的：
```cpp
if (isLucky('a')) …         //字符'a'是幸运数？
if (isLucky(true)) …        //"true"是?
if (isLucky(3.5)) …         //难道判断它的幸运之前还要先截尾成3？
```
如果幸运数必须真的是整型，该禁止这些调用通过编译。
其中一种方法就是创建 `deleted` 重载函数，其参数就是想要过滤的类型：
```cpp
bool isLucky(int number);       //原始版本
bool isLucky(char) = delete;    //拒绝char
bool isLucky(bool) = delete;    //拒绝bool
bool isLucky(double) = delete;  //拒绝float和double
```
将 `float` 转换为 `int` 和 `double`，`C++` 更喜欢转换为 `double`。使用 `float` 调用 `isLucky` 因此会调用 `double` 重载版本，而不是 `int` 版本。
虽然 `deleted` 函数不能被使用，但它们还是存在于程序中。也即是说，重载决议会考虑它们。这也是为什么上面的函数声明导致编译器拒绝一些不合适的函数调用。
```cpp
if (isLucky('a')) …     //错误！调用deleted函数
if (isLucky(true)) …    //错误！
if (isLucky(3.5f)) …    //错误！
```
### Preventing Template Instantiation
另一个 `deleted` 函数用武之地（`private`成员函数做不到的地方）是禁止一些模板的实例化。假如要求一个模板仅支持原生指针：
```cpp
template<typename T>
void processPointer(T* ptr);
```
在指针的世界里有两种特殊情况。一是 `void*` 指针，因为没办法对它们进行解引用，或者加加减减等。另一种指针是 `char*`，因为它们通常代表 C 风格的字符串，而不是正常意义下指向单个字符的指针。这两种情况要特殊处理，在 `processPointer` 模板里面，假设正确的函数应该拒绝这些类型。也即是说，`processPointer` 不能被 `void*` 和 `char*` 调用。
要想确保这个很容易，使用 `delete` 标注模板实例，而且如果使用 `void*` 和 `char*` 调用 `processPointer` 就是无效的，按常理说 `const void*` 和`const char*` 也应该无效，所以这些实例也应该标注 `delete`：
```cpp
template<>
void processPointer<void>(void*) = delete;

template<>
void processPointer<char>(char*) = delete;

template<>
void processPointer<const void>(const void*) = delete;

template<>
void processPointer<const char>(const char*) = delete;
```
假设类里面有一个函数模板，可能想用 `private`（经典的 `C++98` 惯例）来禁止这些函数模板实例化，但是不能这样做，因为不能给特化的成员模板函数指定一个不同于主函数模板的访问级别。如果 `processPointer` 是类 `Widget` 里面的模板函数，想禁止它接受 `void*` 参数，那么通过下面这样 `C++98` 的方法就不能通过编译：
```cpp
class Widget {
public:
    …
    template<typename T>
    void processPointer(T* ptr)
    { … }

private:
    template<>                          //错误！
    void processPointer<void>(void*);
};
```
问题是模板特例化必须位于一个命名空间作用域，而不是类作用域。`deleted` 函数不会出现这个问题，因为它不需要一个不同的访问级别，且他们可以在类外被删除（因此位于命名空间作用域）：
```cpp
class Widget {
public:
    template<typename T>
    void processPointer(T* ptr)
    { … }

};

template<>                                          //还是public，
void Widget::processPointer<void>(void*) = delete;  //但是已经被删除了
```
事实上 C++98 的最佳实践即声明函数为`private`但不定义是在做C++11  `deleted` 函数要做的事情。作为模仿者，C++9 8的方法不是十全十美。它不能在类外正常工作，不能总是在类中正常工作，它的罢工可能直到链接时才会表现出来。所以请坚定不移的使用 `deleted` 函数。
## SpecailMemberFunc
`C++98` 有四个特殊成员函数：默认构造函数，析构函数，拷贝构造函数，拷贝赋值运算符。生成的特殊成员函数是隐式 `public` 且 `inline`，它们是非虚的，除非相关函数是在派生类中的析构函数，派生类继承了有虚析构函数的基类。在这种情况下，编译器为派生类生成的析构函数是虚的。
### Copy and Move
`C++11` 有两个新的特殊成员函数：移动构造函数和移动赋值运算符：
```cpp
class Widget {
public:
    …
    Widget(Widget&& rhs);               //移动构造函数
    Widget& operator=(Widget&& rhs);    //移动赋值运算符
    …
};
```
移动操作仅在需要的时候生成，如果生成，就会对类的 `non-static` 数据成员执行逐成员的移动。那意味着移动构造函数根据 `rhs` 参数里面对应的成员移动构造出新 `non-static` 部分，移动赋值运算符根据参数里面对应的 `non-static` 成员移动赋值。移动构造函数也移动构造基类部分（如果有的话），移动赋值运算符也是移动赋值基类部分。
当对一个数据成员或者基类使用移动构造或者移动赋值时，没有任何保证移动一定会真的发生。如果支持移动就会逐成员移动类成员和基类成员，如果不支持移动就执行拷贝操作。逐成员移动的核心是对对象使用`std::move`，然后函数决议时会选择执行移动还是拷贝操作。
像拷贝操作情况一样，如果自己声明移动操作，编译器就不会生成。然而它们生成的精确条件与拷贝操作的条件有点不同。
两个拷贝操作是独立的：声明一个不会限制编译器生成另一个。所以如果声明一个拷贝构造函数，但是没有声明拷贝赋值运算符，如果写的代码用到拷贝赋值，编译器会生成拷贝赋值运算符。同样的，如果声明拷贝赋值运算符但是没有拷贝构造函数，代码用到拷贝构造函数时编译器就会生成它。上述规则在 `C++98` 和 `C++11` 中都成立。
两个移动操作不是相互独立的。如果你声明其中一个，编译器就不再生成另一个。如果给类声明一个移动构造函数，就表明对于移动操作应怎样实现，与编译器应生成的默认逐成员移动有些区别。如果逐成员移动构造有些问题，那么逐成员移动赋值同样也可能有问题。所以声明移动构造函数阻止移动赋值运算符的生成，声明移动赋值运算符同样阻止编译器生成移动构造函数。
声明拷贝操作，编译器就不会生成移动操作。这种限制的解释是如果声明拷贝操作（构造或者赋值）就暗示着平常拷贝对象的方法（逐成员拷贝）不适用于该类，编译器会明白如果逐成员拷贝对拷贝操作来说不合适，逐成员移动也可能对移动操作来说不合适。
声明移动操作会使得编译器禁用自动生成的拷贝操作。毕竟，如果逐成员移动对该类来说不合适，也没有理由指望逐成员拷贝操作是合适的。
### Rule of Three
*Rule of Three*  指的是如果声明了拷贝构造函数，拷贝赋值运算符，或者析构函数三者之一，应该也声明其余两个，即用户接管拷贝操作的需求几乎都是因为该类会做其他资源的管理，这也几乎意味着
- 无论哪种资源管理如果在一个拷贝操作内完成，也应该在另一个拷贝操作内完成
- 类的析构函数也需要参与资源的管理（通常是释放）。
*Rule of Three* 带来的后果就是只要出现用户定义的析构函数就意味着简单的逐成员拷贝操作不适用于该类。那意味着如果一个类声明析构，拷贝操作可能不应该自动生成，因为它们做的事情可能是错误的。
*Rule of Three* 规则在 `C++11` 依然有效，再加上声明拷贝操作会阻止移动操作隐式生成，因此 `C++11` 不会为有用户定义的析构函数的类生成移动操作。所以仅当下面条件成立时才会生成移动操作（当需要时）：
+ 类中没有拷贝操作
+ 类中没有移动操作
+ 类中没有用户定义的析构
C++11对于特殊成员函数处理的规则如下：
+ **默认构造函数**：和 `C++98` 规则相同。仅当类不存在用户声明的构造函数时才自动生成。
+ **析构函数**：基本上和 `C++98` 相同；稍微不同的是现在析构默认 `noexcept`。和 `C++98` 一样，仅当基类析构为虚函数时该类析构才为虚函数。
+ **拷贝构造函数**：和 `C++98` 运行时行为一样：逐成员拷贝 `non-static` 数据。仅当类没有用户定义的拷贝构造时才生成。如果类声明了移动操作它就是 `delete` 的。当用户声明了拷贝赋值或者析构，该函数自动生成已被废弃。
+ **拷贝赋值运算符**：和 `C++98` 运行时行为一样：逐成员拷贝赋值 `non-static` 数据。仅当类没有用户定义的拷贝赋值时才生成。如果类声明了移动操作它就是 `delete` 的。当用户声明了拷贝构造或者析构，该函数自动生成已被废弃。
+ **移动构造函数**和**移动赋值运算符**：都对 `non-static` 数据执行逐成员移动。仅当类没有用户定义的拷贝操作，移动操作或析构时才自动生成。
而对于类中成员：
- 若类的某个成员的析构函数是删除的或不可访问的，会导致默认提供的析构函数、拷贝构造、拷贝赋值、构造函数被删除
- 若类的某个成员的拷贝构造/赋值是删除的或不可访问的，会导致默认提供的拷贝构造/赋值被删除。
- 非静态的 `const` 数据成员和引用类型数据成员会导致默认提供的拷贝构造、拷贝赋值、移动构造和移动赋值被删除。
- 没有初始化的非静态 `const` 数据成员和引用类型数据成员会导致默认提供的构造函数被删除。
注意没有成员函数**模版**阻止编译器生成特殊成员函数的规则。这意味着如果 `Widget` 是这样：
```cpp
class Widget {
    …
    template<typename T>                //从任何东西构造Widget
    Widget(const T& rhs);

    template<typename T>                //从任何东西赋值给Widget
    Widget& operator=(const T& rhs);
    …
};
```
假设正常生成它们的条件满足，编译器仍会生成移动和拷贝操作，即使可以模板实例化产出拷贝构造和拷贝赋值运算符的函数签名。[[UniversalRef#Avoid Overloading On Universal References#Template]]将会详细讨论它可能带来的后果。
**请记住：**
+ 特殊成员函数是编译器可能自动生成的函数：默认构造函数，析构函数，拷贝操作，移动操作。
+ 移动操作仅当类没有显式声明移动操作，拷贝操作，析构函数时才自动生成。
+ 拷贝构造函数仅当类没有显式声明拷贝构造函数时才自动生成，并且如果用户声明了移动操作，拷贝构造就是*delete*。拷贝赋值运算符仅当类没有显式声明拷贝赋值运算符时才自动生成，并且如果用户声明了移动操作，拷贝赋值运算符就是*delete*。当用户声明了析构函数，拷贝操作的自动生成已被废弃。
+ 成员函数模板不抑制特殊成员函数的生成。
### Rule of Zero
当声明了一个或多个特殊成员函数(析构函数、拷贝构造函数、移动构造函数、拷贝赋值运算符和移动赋值运算符)时，通常需要声明所有这些函数，这称为 `Rule of Five`。在现代 `Cpp` 中，需要接受 `Rule of zero`，在设计类时，应当使其不需要上述 5 个特殊成员函数，基本上，应当避免拥有任何旧式的、动态分配的内存。而改用现代结构，如标准库容器。`Rule of Five`规则应限于自定义资源获取即初始化(Resource Acquisition Is Initialization, RAII)类。RAII 类获取资源的所有权，并在正确的时间处理其释放。