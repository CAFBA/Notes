# Function Overloading
重载允许多个同名函数，这些函数的形参列表/函数签名不同，具体的参数类型，在编译期间就能确定，函数重载属于静态/编译时期的多态。
在 C++ 中不可以在一个函数中定义另一个函数，但**可以在一个函数中声明另一个函数**，这意味着如果在内层作用域中声明重载函数，它将隐藏外层作用域中声明的同名实体，导致同名的重载函数都会被隐藏，这也说明**重载函数必须保证在同一个作用域中**。
有时候两个形参列表看起来不一样，但实际上是相同的： 
```c++
// 每对声明的是同一个函数
Record lookup(const Account &acct); // 形参的名字仅仅起到帮助记忆的作用，有没有它并不影响形参列表的内容。
Record lookup(const Account&);      // 省略形参的名字

typedef Phone Telno;
Record lookup(const Phone&); 
Record lookup(const Telno&);        // Telno和Phone的类型相同，不是一种新类型，它只是Phone的别名而已
```
## Name Mangling
C++函数重载底层原理基于编译器的 `name mangling` 机制。
编译器需要为C++中的所有函数，在符号表中生成唯一的标识符，来区分不同的函数。而对于同名不同参的函数，编译器在进行 `name mangling` 操作时，会通过函数名和其参数类型生成唯一标识符，来支持函数重载。`name mangling` 后得到的函数标识符与返回值类型是无关的，因此函数重载与返回值类型无关。
比如，下面的几个同名函数 `func`：
```cpp
int    func(int i)           { return 0;     }
float  func(int i, float f)  { return i + f; }
double func(int i, double d) { return i+d;   }
```
在经过编译中的 `name mangling` 操作后，得到的符号表中和 `func` 有关的如下：
```cpp
$ g++ main.cc -o main.o && objdump -t main.o
main.o:     file format elf64-x86-64

SYMBOL TABLE:
0000000000001157 g     F .text  000000000000001c              _Z4funcid
000000000000113b g     F .text  000000000000001c              _Z4funcif
0000000000001129 g     F .text  0000000000000012              _Z4funci
0000000000001173 g     F .text  0000000000000016              main
...
```
其中， 前缀 `_z` 是GCC的规定，`4` 是函数名 `func` 的字符个数，`i` 表示第一个函数的参数类型 `int`，`f` 是第二个函数的参数类型 `float`，而 `d` 表示参数类型是 `double`。经过 `name mangling` 后可以发现，函数重载与返回值类型无关，仅与函数名和函数参数类型相关。
C编译器的 `name mangling` 规则与C++的不同：C语言的命名规则仅依赖于函数名，和函数参数类型无关。比如：
```c
int func(int val) {return 0; }
```
经过 `name mangling` 后得到的标识符是`func`：
```c
$ gcc name.c -o name.o && objdump  -t name.o | grep func
0000000000001129 g     F .text  0000000000000012              func
```
这就导致 C 编译器不支持函数重载。
## Name Mangling In Member Function
类` Number` 有成员函数 `add`，这个成员函数经过编译器转换后，编译器会将所有的成员函数转换为 `C-Style` 的函数。
```cpp
class Number { 
public:
  Number(int val = 0) : val_{0} {};

  int       val()            {return val_;}
  const int val() const      {return val_;}
  void      setVal(int val)  { val_ = val;}

  void add(const Number& rhs) { 
    val_ += rhs.val_;
  }
private:
  int val_{0};
};
```
为实现这一操作，就需要将在 `add` 函数的第一个参数前插入 `this` 指针：
```cpp
// _ZN6Number3addERKS_ 是经过 name mangling 后的唯一标识符
void _ZN6Number3addERKS_(Number* this, const Numer* rhs) { 
    this->val_ += rhs.val_;
}
```
同理，`setval` 函数也会被转换为：
```cpp
// _ZN6Number6setValEi 是经过 name mangling 后的唯一标识符
void _ZN6Number6setValEi(Number* this, int val) { 
    this->val_ = val;
}
```
其中，`_ZN` 是固定前缀，`6Number` 表示 `Number` 有 6 个字符，`3add` 表示 `add` 有 3 个字符，`E` 为 `Extral`，`i`则表示参数类型 `int`，`R` 表示引用，`K` 表示 `const`。
简而言之：
- 每个成员函数，都会在第一个参数前插入一个 `this` 指针，将成员函数转换为非成员函数；
- 每个成员函数，经过 `name mangling` 转换后，都会生成唯一的标识符，并且这个标识符只与函数名与函数参数类型有关。
因此 `val()` 函数能重载不是依赖于返回值类型不同，而是因为在经过编译器插入 `this` 指针后，会有不同的标识符，依然是依赖于参数类型不同：
```cpp
// _ZN6Number3valEv 、_ZNK6Number3valEv 是 val 经过 name mangling 后的唯一标识符
 _ZN6Number3valEv(Number* this);
 _ZNK6Number3valEv(const Number* this);
```
因此函数重载依然**只依赖于函数名及其参数类型，与返回值类型无关**。
此外，上述 `val()` 函数能重载是因为后置 `const` 导致 `this` 指针形参不同，因此**后置 `const` 会视作函数签名**，函数签名包括函数名、参数类型、参数个数、顺序以及它所在的类和命名空间。
## Const Parameter
`const` 与 `non-const` 的形参可以同时接收左值和右值，重复声明会有二义性错误：
```c++
int func(int i) { return 0; }         // 编译错误
float func(const int i) { return 0; } // 重复声明

int func(int* i) { return 0; }         // 编译错误
float func(int* const i) { return 0; } // 重复声明
```
但 `const&` 形参可以同时接收左值和右值，`non-const&` 的形参只能接收左值，并且当二者都接收左值时会通过其指向的是常量还是非常量进行区分，不会有二义性错误，**当传递一个非常量对象或者指向非常量对象的指针时，编译器会优先选用非常量版本的函数**：
```c++
// 对于接受引用或指针的函数来说，对象是常量还是非常量对应的形参不同
int func(int& i) { return 0; }         // 函数作用于int的引用
float func(const int& i) { return 0; } // 新函数，作用于常量引用
int func(int* i) { return 0; }         // 新函数，作用于指向int的指针 
int func(const int* i) { return 0; }   // 新函数，作用于指向常量的指针
int func(int&& i) { return 0; }         // 新函数，作用于int的右值引用
int func(const int&& i) { return 0; }   // 新函数，作用于常量右值引用
0000000000001129 g     F .text	0000000000000013              _Z4funcRi
000000000000113c g     F .text	0000000000000018              _Z4funcRKi
0000000000001167 g     F .text	0000000000000013              _Z4funcPKi
0000000000001154 g     F .text	0000000000000013              _Z4funcPi
0000000000001154 g     F .text	0000000000000013              _Z4funcOi
0000000000001167 g     F .text	0000000000000013              _Z4funcOKi
```
## Ref
在使用值传递的时候，被调用函数总是获得一个对应类型的值，从它的角度，调用者使用左值和右值没有区别。不会像引用传递一样，可以进行区别重载。**当涉及引用时，函数重载的调用按照实参是左值还是右值进行匹配，然后根据常量性进行优先级匹配**：
```c++
void test(int& x) {
  cout << "int &x" << endl;
}

// 不能没有const int &x，因为const不能转化为非const
void test(const int &x) {
  cout << "const int &x" << endl;
}

// 可以没有 int&& x，因为非常右值可以转化为常右值
void test(int&& x) {
  cout << "int &&x" << endl;
}

// 不能没有const int &x，因为 move(crr) 常右值不能转化为非常右值
void test(const int&& x) {
  cout << "const int &&x" << endl;
}

int main() {
  int &&rr = 10;
  const int &&crr = 10;
  test(rr); // call to int &x 因为rr是具名变量，是左值
  test(crr); // call to const int &x 因为crr是具名变量，是左值
  test(10); // call to int &&x 因为 10 是右值
  test(move(rr)); // call to int &&x 因为 move(rr) 是右值
  test(move(crr)); // call to const int &&x 因为 move(crr) 是常右值
}
```
引用形参与非引用形参的同时出现时，由于非引用形参左值右值都可以接收，因此会出现二义性：
```c++
void test(int x) {
  cout << "int &x" << endl;
}

void test(const int&& x) {
  cout << "const int &&x" << endl;
}

int main() {
  int &&rr = 10;
  test(10); // call to 'test' is ambiguous
  test(move(rr)); // call to 'test' is ambiguous
  test(rr); // rr 是左值，此时便不会有二义性
}
```
## Overloading Based On Const_cast
下述函数的参数和返回类型都是 `const string` 的引用，可以对两个非常量的 `string` 实参调用这个函数，但返回的结果仍然是 `const string` 的引用：
```c++
const string& shorterString(const string &s1, const string &s2) {
    cout << "const string &s1, const string &s2" << endl;
    return s1.size() <= s2.size() ? s1 : s2;
}
```
因此需要一个重载函数，使得实参不是常量时，得到的结果是一个普通的引用：
```c++
string& shorterString(string &s1, string &s2) {
    cout << "string &s1, string &s2" << endl;
    return s1.size() <= s2.size() ? s1 : s2;
}
```
可以通过 `const_cast` 实现这一点：
```c++
string& shorterString(string &s1, string &s2) {
    cout << "string &s1, string &s2" << endl;
    auto &r = shorterString(static_cast<const string &>(s1), static_cast<const string &>(s2));
    return const_cast<string&>(r);
}
```
## Choose
重载决议过程见[[Compile-Time Computing#函数重载]]
# Method Overloading
## Overloading Based On Const
当成员函数的 `const` 与 `non-const` 版本同时存在，`const` 对象只能调用 `const` 版本，`non-const` 对象只能调用 `non-const` 版本。
```c++
class A {
  const char& operator[](std::size_t pos) const { return t[pos]; } // const
  char& operator[](std::size_t pos) { return t[pos]; } // non-const
}

A tb("kkk");
cout << tb[0]; // non-const
tb[0] = 'x';   // no problem

const A ctb("kkk");
cout << ctb[0];// const
ctb[0] = 'x';  // error
```
通常情况下，`const` 版本和非 `const` 版本的实现是一样的。为避免代码重复，可使用 `const_cast()` 模式，使 `non-const` 调用其 `const` 兄弟，但 `non-const operator[]` 内部若只是调用 `operator[]`，会递归调用自己，因此需要明确指出调用的是 `const`，为此使用转型操作为其加上 `const`，这使得接下来调用 `operator[]` 时得以调用 `const` 版本，之后再从 `const operator[]` 返回值中移除 `const`。
但使 `const` 调用 `non-const` 会存在 `const` 相关危险，因为 `const` 成员函数承诺绝不改变其对象的逻辑状态，使 `const` 调用 `non-const`，对象可能因此被改动。
```c++
class A {
  const char& operator[](std::size_t pos) const {
    return t[pos];
  }
  char& operator[](std::size_t pos) {
    // 首先将调用此函数的对象(即*this)强制转化为指向const对象的引用
    // 再调用const版本，之后再将返回值的const去除
    return const_cast<char&> ( static_cast<const A&>(*this)[pos] );
  }
};

const SpreadsheetCell& Spreadsheet::getCellAt(size_t x, size_t y) const
{
    verifyCoordinate(x, y);
    return m_cells[x][y];
}

// 在 <utility> 中定义的 std::as_const() 将 *this 转换为const Spreadsheet&
SpreadsheetCell& Spreadsheet::getCellAt(size_t x, size_t y)
{
 return const_cast<SpreadsheetCell&>(as_const(*this).getCellAt(x, y));
}
```
## Explicitly Deleting Overloads
重载方法可被显式删除，可以用这种方法禁止调用具有特定参数的成员函数。
`SpreadsheetCell` 类有一个方法 `setValue(double)`，可按如下方式调用: 
```cpp
SpreadsheetCel1 cell; 
cell.setValue(1.23); 
cell.setValue(123); 
```
在第三行，编译器将整型值转换为 `double`，然后调用 `setValue()`。如果出于某些原因，不希望以整型调用 `setValue()` , 可以显式删除 `setValue()` 的整型重载版本：
```cpp
class SpreadsheetCell
{
public:
    void setValue(double value);
    void setValue(int) = delete;
};
```
## Ref-Qualified Methods
有时可以对右值赋值：
```c++
string s1, s2;
s1 + s2 = "wow!";
```
在旧标准中，没有办法阻止这种使用方式。为了维持向下兼容性，新标准库仍然允许向右值赋值。但是可以在自己的类中阻止这种行为，使用引用限定符规定左侧运算对象即 `*this` 必须是一个左值。这和在成员函数声明尾部添加一个 `const` 很相似，规定调用这个成员函数的对象即 `*this` 是 `const`。引用限定符也可以区分重载版本，而且可以综合引用限定符和 `const` 来区分一个成员函数的重载版本。
在非 `static` 成员函数的形参列表后面添加引用限定符可以**指定 `this` 的左值/右值属性**，从而限定成员函数只能用于左值或者右值。引用限定符可以是 `&` 或者 `&&`，分别表示 `this` 可以指向一个左值或右值对象。引用限定符必须同时出现在函数的声明和定义中。对于 `&` 限定的函数，只能将它用于左值；对于 `&&` 限定的函数，只能用于右值，因此可以显式指定调用某个方法的实例类型是临时实例还是非临时实例：
```c++
class Foo {
public:
    Foo &operator=(const Foo&) &; // may assign only to modifiable lvalues
    // other members of Foo
};

Foo &Foo::operator=(const Foo &rhs) & {
    // do whatever is needed to assign rhs to this object
    return *this;
}
Foo& retFoo(); // 返回一个引用，retFoo 是一个左值
Foo retVal();  // 返回一个值，retVal 是一个右值
Foo i, j;      // i 和 j 是左值
retFoo() = j;  // 正确：retFoo返回一个左值
retVa1() = j;  // 错误：retVal返回一个右值，=只能用于左值
i = retVal();  // 正确：可以将一个右值作为赋值操作的右侧运算对象
```
一个非 `static` 成员函数可以同时使用 `const` 和引用限定符，此时引用限定符跟在 `const` 限定符之后。
```c++
class Foo {
public:
    Foo someMem() & const;      // error: const qualifier must come first
    Foo anotherMem() const &;   // ok: const qualifier comes first
};
```
当定义 `const` 成员函数时，可以定义两个版本，唯一的差别是一个版本有 `const` 限定而另一个没有。引用限定的函数则不一样，**如果定义两个或两个以上具有相同名字和相同参数列表的成员函数，就必须对所有函数都加上引用限定符，或者所有都不加**：
```c++
class Foo {
public:
    Foo sorted() &&;
    Foo sorted() const;    // error: must have reference qualifier
    // Comp is type alias for the function type
    // that can be used to compare int values
    using Comp = bool(const int&, const int&);
    Foo sorted(Comp*);  // ok: different parameter list
};
```
本例中声明了一个没有参数的 `const` 版本的 `sorted`，此声明是错误的。因为 `Foo` 类中还有一个无参的 `sorted` 版本，它有一个引用限定符，因此 `const` 版本也必须有引用限定符。另一方面，接受一个比较操作指针的 `sorted` 版本是没问题的，因为两个函数都没有引用限定符。因此如果一个成员函数有引用限定符，则具有相同参数列表的所有版本都必须有引用限定符。
```c++
class Foo {
public:
    Foo sorted() &&; // 改变的右值
    Foo sorted() const &; // 可用于任何类型的FOO
private:
    vector<int> data; 
};
// 本对象为右值，因此可以原址排序
Foo Foo::sorted() && {
    sort(data.begin(), data.end()); 
    return *this;
}
// 本对象是const或是一个左值，哪种情况都不能对其进行原址排序
Foo Foo::sorted() const & {
    Foo ret(*this); // 拷贝一个副本 
    sort(ret.data.begin(), ret.data.end()); // 排序副本 
    return ret; // 返回副本 
}
```
当对一个右值执行 `sorted` 时，它可以安全地直接对 `data` 成员进行排序。对象是一个右值，意味着没有其他用户，因此可以改变对象。当对一个 `const` 右值或一个左值执行 `sorted` 时，不能改变对象，因此就需要在排序前拷贝 `data`。编译器会根据调用 `sorted` 的对象的左值/右值属性来确定使用哪个 `sorted` 版本：
```c++
retVal().sorted(); // retVal()是一个右值,调用Foo::sorted() && 
retFoo().sorted(); // retFoo()是一个左值，调用Foo::sorted() const＆ 
```
假设 `Widget` 类有一个 `std::vector` 数据成员，提供一个访问函数让客户端可以直接访问它：
```cpp
class Widget {
public:
    using DataType = vector<double>;   
    DataType& data() { return values; }
private:
    DataType values;
};
```
思考一下下面的客户端代码：
```cpp
Widget w;
auto vals1 = w.data();  //拷贝w.values到vals1
```
`data` 函数的返回值是一个左值引用 `vector<double>&`, 因为左值引用是左值，所以 `vals1` 是从左值初始化的。因此 `vals1` 由 `w.values` 拷贝构造而得。现在假设有一个创建 `Widget` 的工厂函数，
```cpp
Widget makeWidget();
```
想用 `makeWidget` 返回的 `Widget` 里的 `vector` 初始化一个变量：
```cpp
auto vals2 = makeWidget().data();   //拷贝Widget里面的值到vals2
```
`Widgets::data` 返回的是左值引用，但 `makeWidget` 返回的是临时对象，即右值，所以将其中的 `vector` 进行拷贝纯属浪费。最好是移动，但是因为 `data` 返回左值引用，`C++` 的规则要求编译器不得不生成一个拷贝。
所以需要指明当 `data` 被右值 `Widget` 对象调用的时候结果也应该是一个右值。现在就可以使用引用限定，为左值 `Widget` 和右值 `Widget` 写一个 `data` 的重载函数来达成这一目的：
```cpp
class Widget {
public:
    using DataType = std::vector<double>;
    …
    DataType& data() &              //对于左值Widgets,
    { return values; }              //返回左值
    
    DataType data() &&              //对于右值Widgets,
    { return std::move(values); }   //返回右值
private:
    DataType values;
};
```
注意 `data` 重载的返回类型是不同的，左值引用重载版本返回一个左值引用（即左值），右值引用重载返回一个临时对象（即右值）。这意味着现在客户端的行为和期望相符：
```cpp
auto vals1 = w.data();              //调用左值重载版本的Widget::data, 拷贝构造vals1
auto vals2 = makeWidget().data();   //调用右值重载版本的Widget::data, 移动构造vals2
```
## Covariant Returns Type
协变返回类型仅应用于虚函数中指针或引用类型的参数和返回值，只要满足协变规则，那么对于虚函数的参数也可以做类似处理：
- 如果基类虚函数返回的是内建数据类型，那么派生类重写的方法返回类型要与基类一致。
- 如果基类虚函数返回的是某个基类（自己或另一个基类）的指针或引用，那么派生类重写的方法返回类型可以是这个基类的派生类的指针或引用。
- 基类和派生类返回的引用或指针需要有向下派生的关系，例如基类返回的是 `CDerive` 的指针，而其基类返回的是 `CBase` 指针这种情况是不行的。
```c++
class A {
    public:
    virtual A& show(int n);
    // 如果返回类型是基类引用或指针，则可以修改为指向派生类的引用或指针
};
class B: public A {
    public:
    virtual B& show(int n);
};
```
如果基类和派生类处于平行层次结构中，使用这个特性可以带来便利。平行层次结构是指一个类层次结构与另一个类层次结构没有相交，但是存在联系。 
例如，考虑樱桃果园的模拟程序。可使用两个类层次结构模拟不同但明显相关的实际对象。第一 个类层次结构的基类为 `Cherry`，派生类为 `BingCherry`。与此类似，另一个类层次结构的基类为 `CherryTree`，派生类为 `BingCherryTree`。
现在假定 `CherryTree` 类有一个虚方法 `pick`, 这个虚方法从樱桃树上获取一个樱桃:
```cpp
Cherry* CherryTree::pick() { return new Cherry{}; }
```
`BingChenyTree` 类始终返回 `BingCherry` 对象，可通过修改返回类型，向这个类的潜在用户指明这一点：
```cpp
BingCherry* BingCherryTree::pick() {
    auto theCherry { make_unique<BingCherry>() };
    theCherry->polish();
    return theCherry.release();
}

// 否则只能利用 BingCheny 指针被自动转换为 Cheny 指针的方法
Cherry* BingCherryTree::pick() {
    auto theCherry { make_unique<BingCherry>() };
    theCherry->polish();
    return theCherry.release();
}
```
`printType` 是基类 `Cherry` 的虚方法，由 `BingCherryTree` 派生类重写，用于输出 `Cherry` 的类型。
```cpp
BingCherryTree theTree;
unique_ptr<Cherry> theCherry { theTree.pick() }; // 基类指针指向派生类
theCherry->printType();
```
由于 `BingCherry` 也是 `Cherry`，因此根据 `CherryTree` 版本的 `pick` 返回值调用的任何方法，仍然可以基于 `BingCherryTree` 版本的 `pick` 返回值进行调用。
为判断能否修改重写方法的返回类型，可以考虑已有代码是否能够继续运行，这称为里氏替换原则 `LSP`。在上例中，修改返回类型没有问题，因为已有代码中利用 `BingCheny` 指针被自动转换为 `Cheny`，使得 `pick` 方法总是返回 `Cherry*`，可以成功编译并正常运行。
将 `unique_ptr` 用作返回类型时，不能用于本例。原因在于 `unique_ptr` 是类模板，`unique_ptr<Cherry>` 和 `unique_ptr<BingCherry>` 这两个实例是完全不同的类型，完全无关。无法更改重写方法的返回类型来返回完全不同的类型。
## Adding Overloads of Virtual Base Class Methods
可以向派生类中添加基类虚方法的新重载。也就是说，可以使用新原型在派生类中添加虚方法的重载，但继续继承基类版本。该技术使用 `using` 声明将方法的基类定义显式包含在派生类中：
```cpp
class Base {
public:
    virtual void someMethod();
};

class Derived : public Base {
public:
    using Base::someMethod; // Explicitly inherits the Base version.
    virtual void someMethod(int i); // Adds a new overload of someMethod().
};
```
> 由于参数列表不一致，因此这不是重写虚方法而是重载虚方法。
# Operator Overloading
## Choices in Operator Overloading
### Choosing Argument Quantities
重载运算符函数的参数数量与该运算符作用的运算对象数量一样多，除重载函数调用运算符 `operator()` 之外，其他重载运算符不能含有默认实参。一元运算符有一个参数，二元运算符有两个。对于二元运算符来说，左侧运算对象传递给第一个参数，而右侧运算对象传递给第二个参数。
如果一个运算符函数是成员函数，则它的左侧运算对象绑定到隐式的 `this` 指针上，因此，成员运算符函数的显式参数数量比运算符的运算对象总数少一个。
### Method or Global Function
首先，要决定运算符应该实现为类的方法还是全局函数(通常是类的友元)。当运算符是类的方法时，运算符表达式的左侧必须是这个类的对象。当编写全局函数时，运算符表达式的左侧可以是不同类型的对象。一般有三种选择：
1. 必须为方法的运算符：语言要求一些运算符必须是类中的方法，因为这些运算符在类的外部没有意义。例如，`operator*` 类绑定得非常紧密，不能出现在其他地方。
2. 必须为全局函数的运算符：如果允许运算符左侧的变量是除了自定义的类之外的任何类型，那么必须将这个运算符定义为全局函数。这条规则适用于 `operator>>` 和 `operator<<`，这两个运算符的左侧是 `iostream` 对象，而不是自定义类的对象。此外，可交换的二元运算符允许运算符左侧的变量不是自定义类的对象。
3. 既可为方法又可为全局函数的运算符：把所有运算符都定义为方法，除非根据以上描述必须定义为全局函数。这条规则的一个主要优点是，方法可以是虚方法，但全局函数不能是虚函数。因此，如果准备在继承树中编写重载的运算符，应尽可能将这些运算符定义为方法。
将重载的运算符定义为方法时，如果这个运算符不修改对象，应将方法标记为 `const`，使得 `const` 对象可以调用这个方法。 
将重载的运算符定义为全局函数时，将其放在同样包含编写运算符的类的名称空间中。
### Choosing Argument Types
参数类型的选择有一些限制，因为大多数运算符不能修改参数数量。例如，`operator/` 在作为全局函数的情况下必须总是接收两个参数，在作为类方法的情况下必须总是接收一个参数。如果不遵循这条规则，编译器会生成错误。
真正需要选择的地方在于判断是按值还是按引用接收参数，以及是否需要把参数标记为 `const`。除非函数需要传入对象的一份拷贝，否则应按引用接收每一个非基本类型的参数。除非要真正修改参数，否则将每个参数都设置为 `const`。
### Summary of Overloadable Operators
英文版：原书 540 电子书 582
中文版：原书 441 电子书 471
## Implicit Conversions
```cpp
SpreadsheetCell operator+(const SpreadsheetCell& cell) const
{
 return SpreadsheetCell { getValue() + cell.getValue() };
}
```
当编译器看到下面这行时，就会试着查找 `SpreadsheetCell` 类中名为 `operator+` 并将另一个 `SpreadsheetCell` 对象作为参数的方法，或者查找用两 个 `SpreadsheetCell` 对象作为参数、名为 `operator+` 的全局函数。
```cpp
SpreadsheetCell aThirdCell { myCell + anotherCell };
// 如果 SpreadsheetCell 类包含 operator+ 方法，上述代码就会转换为
SpreadsheetCell aThirdCell { myCell.operator+(anotherCell) };
```
编译器会试着查找合适的 `operator+`，而不是只查找指定类型的那个 `operator+`。为找到`operator+`，编译器还试图查找合适的类型转换。若 `SpreadsheetCell` 类拥有转换构造函数可以将 `double` 转换为 `SpreadsheetCell`。那么当编译器看到 `SpreadsheetCell` 试图与 `double` 值相加时，会用 `double` 值作为参数的 `SpreadsheetCell` 构造函数构建一个临时的 `SpreadsheetCell` 对象，传递给 `operator+`。
```cpp
SpreadsheetCell myCell { 4 }, aThirdCell;
aThirdCell = myCell + 5.6;
```
由于必须创建临时对象，隐式使用构造函数的效率不高。为避免与 `double` 值相加时隐式地使用构造函数，可编写第二个 `operator+`，如下所示
```cpp
SpreadsheetCell operator+(double rhs) const
{
    return SpreadsheetCell { getValue() + rhs };
}
```
隐式转换允许使用 `operator+` 方法将 `SpreadsheetCell` 对象与 `int` 和 `double` 值相加。然而，这个运算符不具有互换性，如下所示：
```cpp
aThirdCell = myCell + 5.6; // Works fine.
aThirdCell = myCell + 4; // Works fine.
aThirdCell = 5.6 + myCell; // FAILS TO COMPILE!
aThirdCell = 4 + myCell; // FAILS TO COMPILE!
```
当 `SpreadsheetCell` 对象在运算符的左边时，隐式转换正常运行，但在右边时无法运行。加法是可交换的，因此这里存在错误。问题在于必须在 `SpreadsheetCell` 对象上调用 `operator+` 方法，对象必须在 `operator+` 的左边。
然而，如果用不局限于某个特定对象的全局 `operator+` 替换类内的 `operator+` 方法，上面的代码就可以运行：
```cpp
SpreadsheetCell operator+(const SpreadsheetCell& lhs, const SpreadsheetCell& rhs)
{
 return SpreadsheetCell { lhs.getValue() + rhs.getValue() };
}

aThirdCell = 4.5 + 5.5;
alhirdCell = 10; // 先进行内置类型的 double 相加，再将其转换为类对象
```
为让赋值操作继续，运算符右边应该是 `SpreadsheetCell` 对象。编译器找到非 `explicit` 的由用户定义的用 `double` 值作为参数的构造函数，然后用这个构造函数隐式地将 `double` 值转换为一个临时 `SpreadsheetCell` 对象，最后调用赋值运算符。
## Rvalue References
对于大部分运算符来说，编写一个使用普通左值引用的版本以及一个使用右值引用的版本都是有意义的，但是否真正有意义取决于类的实现细节。
例如移动赋值运算符的原型几乎一致，但使用了右值引用。这个运算符会修改参数，因此不能传递 `const` 参数。
```cpp
T& operator=(const T&);
T& operator=(T&&);
```
例如通过 `operator+` 避免不必要的内存分配。例如标准库中的 string 类利用右值引用实现 `operator+`：
```cpp
string operator+(string&& lhs, string&& rhs);
```
这个运算符的实现会重用其中一个参数的内存，因为这些参数是以右值引用传递的。也就是说，这两个参数表示的都是 `operator+` 完成之后销毁的临时对象。上述的实现具有以下效果：
```cpp
return move(lhs.append(rhs));
return move(rhs.insert(0, lhs));
```
`string` 定义了几个 `operator+` 重载，接收两个 `string` 作为参数，带有不同的左值和右值引用的组合，如下：
```cpp
string operator+(const string& lhs, const string& rhs); // No memory reuse.
string operator+(string&& lhs, const string& rhs); // Can reuse memory of lhs.
string operator+(const string& lhs, string&& rhs); // Can reuse memory of rhs.
string operator+(string&& lhs, string&& rhs); // Can reuse memory of lhs or rhs.
```
## Arithmetic Operators
###  Arithmetic Operator
```c++
// 成员函数版本
Complex operator+(const Complex &rhs) const {
    return Complex(this->numerator + rhs.numerator, this->denominator + rhs.denominator);
} 

// 成员函数防止隐式转换版本
Complex operator+(int rhs) const {
    return Complex(this->numerator + rhs); // 用于 Complex + 5
}

// 全局函数版本，通常为友元
Complex operator+(const Complex &lhs, const Complex &rhs) {
    return Complex(lhs.numerator + rhs.numerator, lhs.denominator + rhs.denominator);
}

// 全局函数防止隐式转换版本
Complex operator+(int lhs, const Complex &rhs) {
  return Complex(rhs.numerator + lhs); // 用于 5 + Complex
}
```
### Unary Minus and Unary Plus
一元负号运算符对其操作数取反，而一元正号运算符直接返回操作数。可以对一元正号运算符或一元负号运算符生成的结果应用一元正号或一元负号运算符。这些运算符不改变调用它们的对象，所以应把它们标记为 `const`。 
下例将一元 `operator-` 运算符重载为 `SpreadsheetCell` 类的成员函数。一元正号运算符通常执行恒等运算，因此这个类没有重载这个运算符。
```cpp
SpreadsheetCell SpreadsheetCell::operator-() const
{
    return SpreadsheetCell { -getValue() };
}
```
`operator-` 没有修改操作数，因此这个方法必须构造一个新的带有相反值的 SpreadsheetCell 对象， 并返回这个对象的副本。因此，这个运算符不能返回引用。可按以下方式使用这个运算符
```cpp
SpreadsheetCell c1 { 4 };
SpreadsheetCell c3 { -c1 };
```
### Increment and Decrement
前缀版本的 `operator++` 和 `operator--` 不接收参数，而后缀版本的接收一个不使用的 `int` 类型参数。前缀形式的结果值和操作数的最终值一致，因此前缀递增和前缀递减返回被调用对象的引用。然而后缀版本的递增操作和递减操作返回的结果值和操作数的最终值不同，因此不能返回引用：
```c++
Complex& Complex::operator++() { // Prefix
    this->numerator += 1;
    this->denominator += 1;
    return *this;
}

const Complex Complex::operator++(int) { // Postfix
    return Complex(this->numerator++, this->denominator++);
}

Complex& Complex::operator--() {
    this->numerator -= 1;
    this->denominator -= 1;
    return *this;
}

const Complex Complex::operator--(int) {
    return Complex(this->numerator--, this->denominator--);
}
```
后置式必须返回 `const` 对象，如果不这样，以下动作是合法的：
```c++
UPInt i; 
i++++;
//实施后置式increment操作符两次。这和以下动作相同：
i.operator++(0).operator++(0);
```
- `C++` 对于 `int` 并不允许连续两次使用后置式 `increment` 操作符
- 即使能够两次施行后置式，`operator++` 的第二个调用动作施行于第一个调用动作的返回对象身上，第二个 `operator++` 所改变的对象是第一个 `operator++` 返回的对象，而不是原对象。
因此其返回 `const` 对象，若第一次调用 `operator++` 所返回的 `const` 对象，将被用来进行 `operator++` 的第二次调用，会由于 `operator++` 是个 `non-const member function` 无法调用。
## Arithmetic Shorthand Operator
与基本算术运算符不同，简写算术运算符会改变运算符左边的对象，而不是创建一个新对象，它们生成的结果是对被修改对象的引用，这一点与赋值运算符类似。简写算术运算符的左边总要有一个对象，因此应该将其作为方法而不是全局函数。
简写算术运算符比其对应版本效率高，因为对应版本通常必须返回一个新对象，因此会负担一个临时对象的构造和析构成本。至于简写算术运算符则是直接将结果写入其左端自变量，所以不需要产生一个临时对象来放置返回值。
```c++
Complex& operator+=(const Complex &rhs) {
    this->numerator += rhs.numerator;
    this->denominator += rhs.denominator;
    return *this;
}

Complex& operator-=(const Complex &rhs) {
    this->numerator -= rhs.numerator;
    this->denominator -= rhs.denominator;
    return *this;
}
```
基于实现其对应版本，应注意使其触发 `(N)RVO`：
```c++
Complex operator+(const Complex &rhs) const {
    return Complex(*this) += rhs;
}
Complex operator-(const Complex &rhs) const {
    return Complex(*this) -= rhs;
}

// 全局函数允许隐式类型转换的版本
Complex operator+(const Complex &lhs, const Complex &rhs) {
    return Complex(lhs) += rhs;
}
```
表达式 `Complex(lhs)` 调用 `Complex` 的 `copy constructor` 产生一个临时对象，其值和 `lhs` 相同，这个临时对象然后被用来调用 `operator+=`，并以 `rhs` 作为自变量，运算结果则被`operator+` 返回。
## Logical Operator
建议不要重载逻辑运算符。这些运算符并不应用于单个类型，而是整合布尔表达式的结果。此外，重载这些运算符时，会失去短路求值，原因是在将运算符左侧和右侧的值绑定至重载的 `&&` 和 `||` 运算符之前，必须对运算符的左侧和右侧进行求值。因此，一般对特定类型重载这些运算符都没有意义。
## Comparison Operators
如果为一个类型实现可比较的运算，真正需要实现的只有 `<` 和 `=` 两种，其他四种关系都能通过这两个组合而成，此外在 `Cpp20` 之前的六个比较运算符应该是全局函数，这样就可以在运算符的左侧和右侧参数上使用隐式转换，同时声明为友元使其可以使用其 `private` 成员，否则需要通过成员函数获取：
```c++
class Point{
    int x; 
    int y;
    friend bool operator==(const Point& lhs, const Point& rhs){ 
        return std::tie(lhs.x, lhs.y) == std::tie(rhs.x, rhs.y); 
    } 
    friend bool operator<(const Point& lhs, const Point& rhs) { 
        return std::tie(lhs.x, lhs.y) < std::tie(rhs.x, rhs.y);
    } 
    friend bool operator!=(const Point& lhs, const Point& rhs) { 
        return !(lhs == rhs); 
    }
    friend bool operator>(const Point& lhs, const Point& rhs) { 
        return rhs < lhs; 
    }
    friend bool operator<=(const Point& lhs, const Point& rhs) { 
        return !(lhs > rhs);
    }
    friend bool operator>=(const Point& lhs, const Point& rhs) { 
        return !(lhs < rhs); 
    }
};
```
`Point` 类之间的大小关系通过字典序方式比较，首先比较第一个字段 `x`，若第一个字段相等，则比较第二个字段 `y`。这里使用由标准库提供的 `std::tie` 模板函数将字段打包成元组，标准库为元组定义了一系列比较操作符，按照给定类型的先后顺序进行比较，借助它可轻松实现任意多个字段的字典序比较。
但为每个可比较的类实现六个操作符是件烦琐的事情，而且如果这个类存在转换构造函数，那么当前实现的六个比较函数都可以通过隐式转换与其它类型进行比较，这种隐式转换可能效率低下，因为必须创建临时对象，可以通过显式实现与其它类型进行比较的函数来避免这种情况：
```cpp
bool operator==(const Point& lhs, const Point& rhs);
bool operator==(double, const Point& rhs);
bool operator==(const Point& lhs, double);
```
可以通过两种方法进行简化：奇异递归模板与飞船运算符。
### CRTP
利用奇异递归模板模式可以复用这种代码，只需要派生类提供打包元组的接口，由模板基类基于元组实现所有的比较操作符：
```c++
template<typename Derived>
struct Comparable ｛ // 需要派生类Derived提供tie接口
    friend bool operator==(const Derived& lhs, const Derived& rhs) {
        return lhs.tie() == rhs.tie();
    }
    friend bool operator<(const Derived& lhs, const Derived& rhs) { 
        return lhs.tie() < rhs.tie();
    }
    // 省略剩余4个操作符的定义 
};

struct Point : Comparable<Point> { 
    Point(int x, int y): x(x), y(y) { }
    int x; int y; // 使用std::tie打包成元组给基类使用 
    auto tie() const { 
        return std::tie(x, y); 
    } 
};
```
### <=>
```c++
struct Point { 
    Point(int x, int y): x(x), y(y) { }
    int x; int y; // 编译器按照字段声明的顺序进行比较，auto推导为strong
    friend auto operator<=>(const Point& lhs, const Point& rhs) = default;
};
```
## Insertion And Extraction Operators
在编写插入和提取运算符前，需要决定如何将自定义的类向流输出，以及如何从流中提取自定义的类。插入和提取运算符左侧的对象是 `istream` 或 `ostream`，而不是 `SpreadsheetCell` 对象。
假设输入输出运算符是某个类的成员，则它们也必须是 `istream` 或 `ostream` 的成员。但`istream` 类或 `ostream` 属于标准库，不能向其添加方法，因此，如果希望为类自定义 IO 运算符，必须将其定义成非成员函数，此外，`IO` 运算符通常需要读写类的非公有数据成员，所以 `IO` 运算符一般被声明为友元。
```cpp
std::ostream& operator<<(std::ostream& ostr, const SpreadsheetCell& cell) {
    ostr << cell.getValue(); 
    return ostr;
}
```
插入运算符的第一个形参是 `non-const ostream` 的引用，因为向流写入内容会改变其状态，形参是引用是因为无法直接复制一个 `ostream` 对象。第二个形参是 `const` 引用，因为插入运算符不会修改写入的 `SpreadsheetCell` 对象，并且希望避免复制实参。这个运算符能应用于文件输出流、字符串输出流和 `cout` 等
```cpp
std::istream& operator>>(std::istream& istr, SpreadsheetCell& cell){
    double value;
    istr >> value;
    cell.set(value);
    return istr;
}
```
提取运算符的第一个形参是 `non-const istream` 的引用，第二个形参是 `non-const` 引用，因为提取运算符会修改 `SpreadsheetCell` 对象，本身的目的就是将数据读入到这个对象中。这个运算符能应用于文件输入流、字符串输入流和 `cin`。
这两个运算符返回的都是第一个参数传入的流的引用，所以这两个运算符的调用可以嵌套。
输入运算符必须处理输入可能失败的情况，而输出运算符不需要。在执行输入运算符时可能发生下列错误： 
- 当流含有错误类型的数据时读取操作可能失败。
- 当读取操作到达文件末尾或者遇到输入流的其他错误时也会失败。在程序中没有逐个检查每个读取操作，而是等读取了所有数据后赶在使用这些数据前一次性检查。
```c++
istream& operator>>(istream &is, Sales_data &item) {
    double price; // 不需要初始化，因为将先读入数据到price，之后才使用它
    is >> item.bookNo >> item.units_sold >> price;
    if (is) item.revenue = item.units_sold * price;
    else item ＝ Sales_data(); // 输入失败：对象被赋予默认的状态
    return is;
}
```
如果读取操作失败，则值 `price` 将是未定义的。因此，在使用前 `price` 需要首先检查输入流的合法性，然后才能执行计算并将结果存入。如果发生了错误，无须在意到底是哪部分输入失败，只要将一个新的默认初始化的 `Sales_data` 对象赋予 `item` 从而将其重置为空 `Sales_data` 就可以了。
## Subscripting Operator
为了与下标的原始定义兼容，下标运算符通常以所访问元素的引用作为返回值，这样做的好处是下标可以出现在赋值运算符的任意一端。同时定义下标运算符的常量版本和非常量版本，当作用于一个常量对象时，下标运算符返回常量引用以确保不会给返回的对象赋值。 
```c++
class StrVec {
public:
    const std::string& operator[](std::size_t n) const { return elements[n]; }
    std::string& operator[](std::size_t n) { return elements[n]; }
private:
    std::string *elements; // 指向数组首元素的指针
};
```
`const_cast() pattern`：
```c++
class A {
    const std::string& operator[](std::size_t n) const { return elements[n]; }
    std::string& operator[](std::size_t n) {
        return const_cast<std::string&> ( static_cast<const A&>(*this)[n] );
    }
};
```
不能重载下标运算符以便接收多个参数。如果要提供接收多个索引的下标访问功能，可使用 函数调用运算符。
 ## Function Call Operator
C++允许重载函数调用运算符，写作 `operator()`。如果在自定义的类中编写了一个 `operator()`, 那么这个类的对象就可以当成函数指针使用，包含函数调用运算符的类对象称为函数对象，或简称为仿函数，只能将这个运算符重载为类中的非静态方法。
```cpp
class FunctionObject
{
public:
    int operator() (int param); // Function call operator
    int doSquare(int param); // Normal method
};

int FunctionObject::operator() (int param)
{
    return doSquare(param);
}

int FunctionObject::doSquare(int param)
{
    return param * param;
}
```
通过遵循一般的方法重载规则，可为类编写任意数量的 `operator()`。例如，可向`FunctionObject` 类添加一个带 `string_view` 参数的 `operator()`。
```cpp
int operator()(int param);
void operator()(std::string_view str);
```
相比全局函数，函数对象的好处较为复杂。有两个主要好处：
- 对象可在对其函数调用运算符的重复调用之间，在数据成员中保存信息。例如，函数对象可用于记录每次通过函数调用运算符调用采集到的数字连续总和。
- 可通过设置数据成员来自定义函数对象的行为。例如，可编写一个函数对象，比较函数调用运算符的参数和数据成员的值。这个数据成员是可配置的，因此这个对象可自定义为执行任何比较操作。
```c++
class PrintString {
public:
    PrintString(ostream &o = cout, char c = ''): os(o), sep(c) {}
    void operator()(const string &s) const { os << s << sep; }
private:
    ostream &os; // 用于写入的目的流
    char sep;    // 用于将不同输出隔开的字符
};

PrintString printer; // 使用默认值，打印到cout
printer(s); // 在cout中打印s，后面跟一个空格
PrintString errors(cerr, '\n'); // 在cerr中打印s，后面跟一个换行符
errors(s);
for_each(vs.begin (), vs.end (), PrintString(cerr, '\n'));
```
## Dereferencing Operators
### Implementing operator*
`*` 解除对指针的引用，允许直接访问这个指针指向的值，`->` 是使用 `*` 解除引用之后再使用成员运算符的简写。为了使类的对象行为和指针一致，可以在类中重载解除引用运算符。
当解除对指针的引用时，经常希望能访问这个指针指向的内存。如果那块内存包含一种简单类型, 例如 `int`，那么应该可直接修改这个值。如果内存中包含更复杂的类型，例如对象，那么应该能通过 `.` 访问对象的数据成员或方法。为提供这些语义，`operator*` 应该返回一个引用:
```cpp
template <typename T> 
class Pointer
{
public:
    T& operator*() { return *m_ptr; }
    const T& operator*() const { return *m_ptr; }
};
```
`operator*` 返回的是底层普通指针指向的对象或变量的引用。与重载下标运算符一样，同时提供方法的 `const` 版本和非 `const` 版本。
### Implementing operator–>
应用箭头运算符的结果应该是对象的成员或方法。然而，要实现这一 点，应该能够实现`operator*` 和 `operator.`，而 `C++` 不允许重载 `operator.`，不可能编写单个 原型来捕获任何可能选择的成员或方法。因此，`C++` 将 `operator–>` 当成一种特例。
对于形如 `point->mem` 的表达式来说，`point` 必须是指向类对象的指针或者是一个重载 `operator->` 的类的对象。
如果 `point` 是指针，则应用内置的箭头运算符，表达式等价于 `(*point).mem`。首先解引用该指针，然后从所得的对象中获取指定的成员。如果 `point` 所指的类型没有名为 `mem` 的成员，程序会发生错误。 
```c++
(*point).mem;
```
如果 `point` 是重载 `operator->` 的类的一个对象，则使用 `point.operator->()` 的结果来获取 `mem`。其中，如果该结果是一个指针，则应用内置的箭头运算符，如果该结果本身含有重载的 `operator->()`，则重复调用当前步骤。最终，当这一过程结束时程序或者返回了所需的内容，或者返回一些表示程序错误的信息。
```c++
(point.operator->())->mem;
```
从中可看出，`C++` 给重载的 `operator–>` 返回的任何结果应用了另一个 `operator–>` ，因此，箭头运算符返回一个指向对象的指针或者重载 `operator–>` 运算符的某个类的对象：
```c++
template <typename T> 
class Pointer
{
public:
    // 返回一个指向对象的指针
    T* operator->() { return m_ptr; }
    const T* operator->() const { return m_ptr; }
};

class StrBlobPtr {
public:
    // 返回一个重载 operator–> 运算符的某个类的对象
    string* operator->() const {
        // 调用解引用运算符并返回解引用结果元素的地址
        return &this->operator*(); 
    }
}
```
### Operator.* And Operator–>*
在 `C++` 中，获得类的数据成员和方法的地址，以获得指向这些数据成员和方法的指针是完全合法的。然而，不能在没有对象的情况下访问非静态数据成员或调用非静态方法。类的数据成员和方法的重点在于它们依附于对象。因此，通过指针调用方法或访问数据成员时，必须在对象的上下文中解除对指针的引用。`C++` 不允许重载 `operator.*`，但可以重载 `operator–>*`。
## Conversion Operators
转换运算符必须定义成类的成员函数，没有返回类型、没有参数、名为 `operator typeName()`，`typeName` 是对象将被转换成的类型，一般被定义成 `const` 成员，因为通常不应该改变待转换对象的内容，通过将其声明为 `explicit` 可以防止编译器执行隐式转换。
转换运算符可以面向任意类型（除 `void` 之外）进行定义，只要该类型能作为函数的返回类型。因此，不允许转换成数组或者函数类型，但允许转换成指针（包括数组指针及函数指针）或者引用类型。尽管类型转换函数不负责指定返回类型，但实际上每个类型转换函数都会返回一个对应类型的值。
```cpp
SpreadsheetCell::operator double() const
{
 return getValue();
}

SpreadsheetCell cell { 1.23 };
double d1 { cell }; 

SpreadsheetCell::operator string() const
{
    return doubleToString(getValue());
}
// string 提供了构造函数，下面的方法不起作用
string str { cell };
// 改为赋值初始化（实际调用拷贝构造函数）或显式转换
string str1 = cell;
string str2 { static_cast<string>(cell) };
```
尽管编译器一次只能执行一个用户定义的类型转换，但是隐式的用户定义类型转换可以置于一个内置类型转换之前或之后，并与其一起使用。因此，可以将任何算术类型传递给 `SmallInt` 的构造函数。类似的，也能使用类型转换运算符将一个 `SmallInt` 对象转换成 `int`，然后再将所得的 `int` 转换成任何其他算术类型：
```c++
class SmallInt {
public:
    SmallInt(int i = 0):val(i) { // 向类类型的转换
        if(i < 0 || i > 255) throw out_of_range("Bad SmallInt value"); 
    }
    operator int() const { return val; } // 从类类型向其他类型的转换
    SmallInt operator+(const SmallInt&, const SmallInt&);
private:
	std::size_t val; 
};

// 内置类型转换将 double 实参转换成 int，然后调用 SmallInt(int) 构造函数
SmallInt si = 3.14;

SmallInt s1, s2;
SmallInt s3 = s1 + s2;    // uses overloaded operator+
int i = s3 + 0;            // error: ambiguous
```
可以指定 `auto` 并让编译器推导类型而不是显式指定转换运算符返回的类型，具有 `auto` 返回类型推导的方法实现必须对类的用户可见。因此，需要将实现直接放在类的定义中。此外，`auto` 会移除引用和 `const` 限定符。因此如果 `operator auto` 返回类型 `T` 的引用，则推导出的类型将通过值方式返回 `T`, 从而生成一份拷贝。如果需要，可以显式地添加引用和 `const` 限定符：
```cpp
operator auto() const { return getValue(); }
operator const auto&() const { /* ... */ }
```
在 `C++` 标准的早期版本中，如果类想定义一个向 `bool` 的类型转换，会遇到一个问题：因为 `bool` 是一种算术类型，所以类类型的对象转换成 `bool` 后就能被用在任何需要算术类型的上下文中。这样的类型转换可能引发意想不到的结果，特别是当 `istream` 含有向 `bool` 的类型转换，例如有非 `explicit` 的转换构造函数，但没有重载 `operator bool` 时，下面的代码仍将编译通过：
```c++
int i;
cin << i; // 若bool类型转换不是显式的，对于编译器来说这是合法的
```
这段程序试图将输出运算符作用于输入流。因为 `istream` 本身并没有定义 `<<`，所以本来代码应该产生错误。然而，该代码能使用 `istream` 的 `bool` 类型转换运算符将 `cin` 转换成 `bool`，而这个 `bool` 值接着会被提升成 `int` 并用作内置的左移运算符的左侧运算对象。这样一来，提升后的 `bool` 值最终会被左移 4。这一结果显然与预期大相径庭。
在标准库的早期版本中，`IO` 类型定义了向 `void*` 的转换规则来避免上述转换成移位的情况。在 `C++11` 新标准下，`IO` 标准库通过定义一个向 `bool` 的显式类型转换实现同样的目的。无论什么时候在条件中使用流对象，都会使用为 `IO` 类型定义的 `operator bool`。例如： 
```c++
while(cin >> value);
```
`while` 语句的条件执行输入运算符，它负责将数据读入到 `value` 并返回 `cin`。为了对条件求值，`cin` 被 `istream` 的 `operator bool` 类型转换函数隐式地执行转换。如果 `cin` 的条件状态是 `good`，则该函数返回为真；否则该函数返回为假。
### Solving Ambiguity Problems with Explicit Conversion Operators
为 `SpreadsheetCell` 对象编写 `double` 转换运算符时会引入多义性问题。例如：
```cpp
SpreadsheetCell cell { 6.6 };
double d1 { cell + 3.3 };
```
问题在于，编译器不知道应该通过 `operator double` 将 `cell` 对象转换为 `double` 类型，再执行 `double` 加法，还是通过 `double` 构造函数将 3.3 转换为 `SpreadsheetCell`，再执行 `SpreadsheetCell` 加法，这存在二义性。
在 `C++11` 之前，通常解决这个难题的方法是将构造函数标记为 `explicit`，以避免使用这个构造函数进行自动转换。然而，有时候希望进行从 `double` 到 `SpreadsheetCell` 的自动类型转换。自 `C++11` 以后,可将 `double` 类型转换运算符标记为 `explicit` 以解决这个问题：
```cpp
explicit operator double() const;
```
### Conversions for Boolean Expressions
有时，能将对象用在布尔表达式中会非常有用：
```cpp
if (ptr != nullptr) { /* Perform some dereferencing action. */ }
if (ptr) { /* Perform some dereferencing action. */
```
因此需要给类添加一个转换运算符，将它转换为指针类型。然后，对这种类型和 `nullptr` 所做的比较操作，以及单个对象在 `if` 语句中的形式都会触发这个对象向指针类型的转换。转换运算符常用的指针类型为 `void*`，因为这种指针类型除在布尔表达式中测试外，不能执行其他操作。
```cpp
operator void*() const { return m_ptr; }
// 下面的代码可成功编译，并能完成预期的任务:
void process(Pointer<SpreadsheetCell>& p)
{
 if (p != nullptr) { cout << "not nullptr" << endl; }
 if (p != NULL) { cout << "not NULL" << endl; }
 if (p) { cout << "not nullptr" << endl; }
 if (!p) { cout << "nullptr" << endl; }
}
```
另一种方法是重载 `operator bool`：
```cpp
operator bool() const { return m_ptr != nullptr; }
// 下面的代码可成功编译，并能完成预期的任务:
if (p != NULL) { cout << "not NULL" << endl; }
if (p) { cout << "not nullptr" << endl; }
if (!p) { cout << "nullptr" << endl; }
```
然而，使用 `operator bool` 时，下面和 `nullptr` 的比较会导致编译错误:
```cpp
if (p != nullptr) { cout << "not nullptr" << endl; } // Error
```
因为 `nullptr` 有自己的类型 `nullptr_t`，这种类型没有自动转换为整数 0，编译器找不到接收 `Pointer` 对象和 `nullptr_t` 对象的 `operator!=`，可将这样的 `operator!=` 实现为 `Pointer` 类的友元：
```cpp
<typename T>
class Pointer
{
public:
    // Omitted for brevity
    template <typename T>
    friend bool operator!=(const Pointer<T>& lhs, std::nullptr_t rhs);
};
template <typename T>
bool operator!=(const Pointer<T>& lhs, std::nullptr_t rhs)
{
    return lhs.m_ptr != rhs;
}
```
然而，实现这个 `operator!=` 后，下面的比较会无法工作，因为编译器不知道该用哪个：
```cpp
if (p != NULL) { cout << "not NULL" << endl; }
```
通过这个例子，可能得出以下结论：`operator bool` 从技术上看只适用于不表示指针的对象，以及转换为指针类型并没有意义的对象。但是，添加转换至 `bool` 类型的转换运算符会产生其他一些无法预知的后果。当条件允许时，`Cpp` 会使用类型提升规则将 `bool` 类型自动转换为 `int` 类型。因此，采用 `operator bool` 时，下面的代码可编译运行：
```cpp
Pointer<SpreadsheetCell> anotherSmartCell { new SpreadsheetCell { 5.0 } };
int i { anotherSmartCell }; // Converts Pointer to bool to int.
```
这通常并不是期望或需要的行为。为阻止此类赋值，通常会显式删除到 `int`、`long` 和 `long long` 等类型的转换运算符，但这显得十分凌乱。因此，建议使用 `operator void*`。
### Mutiple Conversion
在两种情况下可能产生多重转换路径：
- `A`类定义了一个接受`B`类对象的转换构造函数，同时`B`类定义了一个转换目标是`A`类的类型转换运算符。
```c++
// usually a bad idea to have mutual conversions between two class types
struct B;
struct A
{
  A() = default;
  A(const B&); // converts a B to an A
  // other members
};

struct B
{
  operator A() const; // also converts a B to an A
  // other members
};
// 该调用可以使用以B为参数的A的构造函数，也可以使用B当中把B转换成A的类型转换运算符。
A f(const A&);
B b;
A a = f(b);    // error ambiguous: f(B::operator A()) or f(A::A(const B&))
```
可以通过显式调用类型转换运算符或转换构造函数解决二义性问题，但不能使用强制类型转换，因为强制类型转换本身也存在二义性。
  ```c++
  A a1 = f(b.operator A());    // ok: use B's conversion operator
  A a2 = f(A(b));     // ok: use A's constructor
  ```
- 类定义了多个类型转换规则，而这些转换涉及的类型本身可以通过其他类型转换联系在一起。
```c++
struct A
{
  A(int = 0);     // usually a bad idea to have two
  A(double);      // conversions from arithmetic types
  operator int() const;       // usually a bad idea to have two
  operator double() const;    // conversions to arithmetic types
  // other members
};

void f2(long double);
A a;
f2(a);    // error ambiguous: f(A::operator int())
        // or f(A::operator double())
long lg;
A a2(lg);   // error ambiguous: A::A(int) or A::A(double)
```
在对 `f2` 的调用中，哪个类型转换都无法精确匹配 `long double`。然而这两个类型转换都可以使用，只要后面再执行一次生成 `long double` 的标准类型转换即可。因此，在上面的两个类型转换中哪个都不比另一个更好，调用将产生二义性。 
当试图用 `long` 初始化 `a2` 时也遇到了同样问题，哪个构造函数都无法精确匹配 `long` 类型。它们在使用构造函数前都要求先将实参进行类型转换： 
- 先执行 `long` 到 `double` 的标准类型转换，再执行 `A(double)`
- 先执行 `long` 到 `int` 的标准类型转换，再执行 `A(int)`
编译器没办法区分这两种转换序列的好坏，因此该调用将产生二义性。因此通常情况下，不要为类定义相同的类型转换，也不要在类中定义两个及两个以上转换源或转换目标都是算术类型的转换。
调用f2及初始化a2的过程之所以会产生二义性，根本原因是它们所需的标准类型转换级别一致。使用两个用户定义的类型转换时，如果转换前后存在标准类型转换，则由标准类型转换决定最佳匹配。
```c++
short s = 42; // 把 short 提升成int 优于把short转换成 double 
A a3(s); // 使用A::A（int） 
```
如果在调用重载函数时需要使用构造函数或者强制类型转换来改变实参的类型，通常意味着程序设计存在不足。调用重载函数时，如果需要额外的标准类型转换，则该转换只有在所有可行函数都请求同一个用户定义类型转换时才有用。如果所需的用户定义类型转换不止一个，即使其中一个调用能精确匹配而另一个调用需要额外的标准类型转换，也会产生二义性错误。
```c++
struct C
{
    C(int);
    // other members
};

struct D
{
    D(double);
    // other members
};

void manip2(const C&);
void manip2(const D&);
// error ambiguous: two different user-defined conversions could be used
manip2(10);    // manip2(C(10) or manip2(D(double(10)))
// 调用者可以显式地构造正确的类型从而消除二义性:
manip2(C(10));
```
其中 `C` 和 `D` 都包含接受 `int` 的构造函数，两个构造函数各自匹配 `manip` 的一个版本。因此调用将具有二义性：它的含义可能是把 `int` 转换成 `C`，然后调用 `manip` 的第一个版本；也可能是把 int 转换成 `D`，然后调用 `manip` 的第二个版本。 
要想正确地设计类的重载运算符、转换构造函数及类型转换函数，必须加倍小心。尤其是当类同时定义了类型转换运算符及重载运算符时特别容易产生二义性:
- 不要令两个类执行相同的类型转换：如果Foo类有一个接受Bar类对象的构造函数，则不要在Bar类中再定义转换目标是Foo类的类型转换运算符。
- 避免转换目标是内置算术类型的类型转换。特别是当你已经定义了一个转换成算术类型的类型转换时，接下来 
- 不要再定义接受算术类型的重载运算符。如果用户需要使用这样的运算符，则类型转换操作将转换你的类型的对象，然后使用内置的运算符。 
- 不要定义转换到多种算术类型的类型转换。让标准类型转换完成向其他算术类型转换的工作。 
因此，除了显式地向 bool 类型的转换之外，应该尽量避免定义类型转换函数并尽可能地限制那些非显式构造函数。
## Memory Allocation And Deallocation Operators
标准库函数 `operator new` 和 `operator delete` 并没有重载 `new` 或 `delete`，可重载 `operator new` 和 `operator delete` 来控制内存的分配和释放，但不能重载 `new` 表达式和 `delete` 表达式。因此，可自定义实际的内存分配和释放，但不能自定义构造函数和析构函数的调用，提供新的 `operator new` 函数和 `operator delete` 函数的目的在于改变内存分配的方式，但是不管怎样都不能改变 `new` 和 `delete` 的基本含义。
有 6 种不同形式的 `new` 表达式，每种形式都有对应的 `operator new`，其中 `placement new` 被 `C++` 标准禁止重载：
```cpp
void* operator new(size_t size);
void* operator new[](size_t size);
void* operator new(size_t size, const std::nothrow_t&) noexcept;
void* operator new[](size_t size, const std::nothrow_t&) noexcept;

void* operator new(size_t size, void* p) noexcept;
void* operator new[](size_t size, void* p) noexcept;
```
只可调用两种不同形式的 `delete` 表达式 `delete` 和 `delete[]`，没有 `nothrow` 和 `placement` 形式，`nothrow` 和 `placement` 形式只有在构造函数抛出异常时才会使用，在这种情况下，调用构造函数之前分配内存时使用的 `operator new` 对应的 `operator delete` 会被调用，如果正常地删除指针，`delete` 会调用 `operator delete` 或 `operator delete[]`，绝不会调用 `nothrow` 或 `placement` 形式。因为 `C++` 标准指出，从 `delete` 抛出异常的行为是未定义的，例如 `delete` 调用的析构函数就可能会抛出异常。
也就是说，`delete` 永远都不应该抛出异常。因此 `nothrow` 版本的 `operator delete` 是多余的；而 `placement` 版本的 `delete` 应该是一个空操作，因为在 `placement new` 中并没有分配内存，因此也不需要释放内存。 
下面是对应于 `operator new` 重载的 6 个 `operator delete` 重载的原型：
```cpp
void operator delete(void* ptr) noexcept;
void operator delete[](void* ptr) noexcept;
void operator delete(void* ptr, const std::nothrow_t&) noexcept;
void operator delete[](void* ptr, const std::nothrow_t&) noexcept;
void operator delete(void* ptr, void*) noexcept;
void operator delete[](void* ptr, void*) noexcept;
```
### Overloading operator new and operator delete
一般重载特定类的 `operator new` 和 `operator delete`。仅当分配或释放特定类的对象时，才会调用这些重载的运算符。
`operator new` 和 `operator new[]` 函数的返回类型必须是 `void*`，第一个形参的类型必须是`size_t` 且不能有默认实参。编译器调用 `operator new` 时，用存储指定类型对象所需的字节数初始化 `size_t` 形参，调用 `operator new[]` 时，传入函数的则是存储数组中所有元素所需的空间。
`operator delete` 和 `operator delete[]` 函数的返回类型必须是 `void`，第一个形参的类型必须是 `void*`，函数被调用时，编译器会用指向待释放内存的指针来初始化 `void*` 形参。
下面这个类重载了 4 个非 `placement` 形式的 `operator new` 和 `operator delete`：
```cpp
class MemoryDemo
{
public:
    virtual ~MemoryDemo() = default;
    
    void* operator new(size_t size);
    void operator delete(void* ptr) noexcept;
    
    void* operator new[](size_t size);
    void operator delete[](void* ptr) noexcept;
    
    void* operator new(size_t size, const std::nothrow_t&) noexcept;
    void operator delete(void* ptr, const std::nothrow_t&) noexcept;
    
    void* operator new[](size_t size, const std::nothrow_t&) noexcept;
    void operator delete[](void* ptr, const std::nothrow_t&) noexcept;
};

void* MemoryDemo::operator new(size_t size)
{
    cout << "operator new" << endl;
    return ::operator new(size);
}

void MemoryDemo::operator delete(void* ptr) noexcept
{
    cout << "operator delete" << endl;
    ::operator delete(ptr);
}

void* MemoryDemo::operator new[](size_t size)
{
    cout << "operator new[]" << endl;
    return ::operator new[](size);
}

void MemoryDemo::operator delete[](void* ptr) noexcept
{
    cout << "operator delete[]" << endl;
    ::operator delete[](ptr);
}

void* MemoryDemo::operator new(size_t size, const nothrow_t&) noexcept
{
    cout << "operator new nothrow" << endl;
    return ::operator new(size, nothrow);
}

void MemoryDemo::operator delete(void* ptr, const nothrow_t&) noexcept
{
    cout << "operator delete nothrow" << endl;
    ::operator delete(ptr, nothrow);
}

void* MemoryDemo::operator new[](size_t size, const nothrow_t&) noexcept
{
    cout << "operator new[] nothrow" << endl;
    return ::operator new[](size, nothrow);
}

void MemoryDemo::operator delete[](void* ptr, const nothrow_t&) noexcept
{
    cout << "operator delete[] nothrow" << endl;
    ::operator delete[](ptr, nothrow);
}

MemoryDemo* mem { new MemoryDemo{} };
delete mem;
mem = new MemoryDemo[10];
delete [] mem;
mem = new (nothrow) MemoryDemo{};
delete mem;
mem = new (nothrow) MemoryDemo[10];
delete [] mem;
```
将 `operator` 函数定义为类的成员时，它们是隐式静态的，无须显式地声明 `static`。因为`operator new` 用在对象构造之前，`operator delete` 用在对象销毁之后，所以它们必须是静态成员，而且不能操纵类的任何数据成员。
```c++
void *operator new(size_t size)
{
    if (void *mem = malloc(size)) return mem;
    else throw bad_alloc();
}

void *operator new[](size_t size)
{
    if (void *mem = malloc(size)) return mem;
    else throw bad_alloc();
}

void operator delete(void *mem) noexcept {
    free(mem);
}

void operator delete[](void *mem) noexcept {
    free(mem);
}
```
一般情况下最好重载所有不同形式的 `operator new`，从而避免内存分配的不一致。如果不想提供任何实现，可使用 `delete` 显式地删除函数，以避免别人使用。
```cpp
class MyClass
{
public:
    void* operator new(size_t size) = delete;
    void* operator new[](size_t size) = delete;
};
```
### With Extra Parameters
除了重载标准形式的 `operator new` 外，还可编写带额外参数的版本。这些额外参数可用于向内存分配例程传递各种标志或计数器。例如，一些运行时库在调试模式中使用这种形式，在分配对象的内存时提供文件名和行号，这样在发生内存泄漏时，便可识别出发生问题的分配内存的那行代码。
```cpp
void* MemoryDemo::operator new(size_t size, int extra)
{
    cout << "operator new with extra int: " << extra << endl;
    return ::operator new(size);
}

void MemoryDemo::operator delete(void* ptr, int extra) noexcept
{
    cout << "operator delete with extra int: " << extra << endl;
    return ::operator delete(ptr);
}
```
编写带有额外参数的重载 `operator new` 时，编译器会自动允许编写对应的 `new` 表达式。`new` 的额外参数以函数调用的语法传递。因此，可编写这样的代码：
```cpp
MemoryDemo* memp { new(5) MemoryDemo{} };
delete memp;
```
定义带有额外参数的 `operator new` 时，还应该定义带有额外参数的对应 `operator delete`。然而不能自己调用这个带有额外参数的 `operator delete`，只有在使用了带有额外参数的 `operator new` 且对象的构造函数抛出异常时，才调用这个 `operator delete`。
### With Size of Memory as Parameter
将 `operator delete` 或 `operator delete[]` 定义为类的成员时，可以包含另一个类型为`size_t` 的形参，它的初始值是第一个形参所指向对象的字节数，`size_t` 形参可用于删除继承体系中的对象。如果基类有一个虚析构函数，则传递给` operator delete` 的字节数会因待删除指针所指向对象的动态类型不同而有所区别，实际运行的 `operator delete` 函数版本也由对象的动态类型决定。
只需要声明带有额外大小参数的 `operator delete` 原型。如果类声明了两个一样版本的 `operator delete`，只不过一个接收大小参数，另一个不接收，那么不接收大小参数的版本总是会被调用。如果需要使用带有大小参数的版本，只编写那个版本。
可独立地将任何版本的 `operator delete` 替换为接收大小参数的 `operator delete` 版本。下面是 `MemoryDemo` 类的定义，将其中的第一个 `operator delete` 改为接收要释放的内存大小作为参数：
```cpp
class MemoryDemo
{
public:
    void* operator new(size_t size);
    void operator delete(void* ptr, size_t size) noexcept;
};

void MemoryDemo::operator delete(void* ptr, size_t size) noexcept
{
    cout << "operator delete with size " << size << endl;
    ::operator delete(ptr);
}
```
这个 `operator delete` 的实现调用没有大小参数的全局 `operator delete`，因为并不存在接收这个大小参数的全局 `operator delete`。
## User-defined Literal Operators
用户定义的字面量通过编写字面量运算符来实现。字面量运算符可以 `raw` 模式和 `cooked` 模式工作。在 `raw` 模式下，字面量运算符接收字符序列，在 `cooked` 模式下，字面量运算符接收特定的解释类型。
例如 0x23 字面量被 `raw` 运算符接收为字符 '0'，'x'，'2'，'3'，而 `cooked` 运算符接收为整数 35。像 3.14 这样的字面量被 `raw` 运算符接收为字符 '3'，'.'，'1'，'4'，而 `cooked` 运算符接收的是浮点数 3.14。
### Cooked-Mode Literal Operator
`cooked` 模式的字面量运算符应该具有以下任意一种：
- 处理数值：`unsigned long long`、`long double`、`char`、`wchar_t`、`char8_t`、`charl6_t` 或 `char32_t` 的类型参数。 
- 处理字符串：两个参数，第一个是字符数组，第二个是字符数组的长度。
下例为用户义的字面量运算符 `_i` 实现了 `cooked` 字面量运算符，来定义复数字面量：
```cpp
complex<long double> operator"" _i(long double d)
{
 return complex<long double> { 0, d };
}

complex<long double> c1 { 9.634_i };
auto c2 { 1.23_i }; // c2 has as type complex<long double>
```
下例为用户定义的字面量运算符 `_s` 实现了 cooked 字面量运算符，来定义 `std::string` 字面量:
```cpp
string operator"" _s(const char* str, size_t len)
{
 return string(str, len);
}

string str1 { "Hello World"_s };
auto str2 { "Hello World"_s }; // str2 has as type string

// 如果没有_8 字面量运算符，auto 类型推导会推导出 const char*：
auto str3 { "Hello World" }; // str3 has as type const char
```
### Raw-Mode Literal Operator
`raw` 模式的字面量运算符需要一个 `const char*` 类型的参数，即以 0 为终止符的 C 风格的字符串参数：
```cpp
complex<long double> operator"" _i(const char* p)
{
 // Implementation omitted; it requires parsing the C-style
 // string and converting it to a complex number.
}
```
使用 `raw` 模式字面量运算符的方式与 `cooked` 版本相同。`raw` 模式字面量运算符只能处理非字符串字面量。例如，`123_i` 可以用 `raw` 模式的字面来实现，但是 `"1.23"_1` 却不能。后者需要带有两个参数的 `cooked` 字面量运算符：以零结束的字符串和它的长度。 